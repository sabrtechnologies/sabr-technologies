#!/bin/bash
# Restart Leon cleanly via systemd (Leon runs as a user-service unit so
# `restart_self` can SIGTERM itself and systemd brings him right back).
#
# The old kill+nohup-setsid approach was a footgun: it raced with
# systemd's auto-restart and produced two brain processes that fought
# over port 8000, VRAM, and the actuator socket.
set -e

UNIT="leon.service"

echo "=== Restarting $UNIT (systemd-managed) ==="
systemctl --user restart "$UNIT"

# Tear down any orphan MCP server subprocesses claude -p left running.
pkill -KILL -f 'leon_mcp_server.py' 2>/dev/null || true

echo "=== Waiting for /api/leon/tools ==="
for i in {1..60}; do
    if curl -sS -m 2 http://localhost:8000/api/leon/tools > /dev/null 2>&1; then
        echo "    ready in ${i}s"
        break
    fi
    sleep 1
done

PID=$(systemctl --user show -p MainPID --value "$UNIT" 2>/dev/null || true)
RSS=$(ps -p "$PID" -o rss= 2>/dev/null | tr -d ' ' || echo '?')
echo "=== Brain up — PID $PID, RSS ${RSS} KB ==="
systemctl --user status "$UNIT" 2>&1 | head -6
