#!/usr/bin/env bash
# Stage the LATEST BUILT sabr-installer binaries into landing/installers/ so
# the public wizard serves them from
# sabrtechnologies.com/download/installer/<os>.
#
# WHY RUN ARTIFACTS, NOT RELEASE ASSETS:
# build-installer.yml only attaches assets to a GitHub Release on a v* tag.
# Every untagged fix builds fine and is never published — which on
# 2026-07-30 handed a paying customer a binary sixteen minutes older than
# the fix written for his exact crash. Newest successful run wins.
# Override with RUN_ID=<id> to stage a specific build.
set -euo pipefail
# 2026-08-11: was sabrtechnologies/leon-brain. That repo is a FOSSIL — its
# build-installer workflow is disabled_manually, so "newest successful run" is
# frozen forever at pre-move code. Running this against it would silently
# overwrite the staged binaries with stale ones and hand them to customers
# through the wizard's /download/installer/{os} route. The installer is built
# from leon-brain-vps now.
REPO=sabrtechnologies/leon-brain-vps
DEST=/opt/leon-brain/landing/installers
mkdir -p "$DEST"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

RUN_ID="${RUN_ID:-$(gh run list --repo "$REPO" --workflow build-installer.yml \
  --status success --limit 1 --json databaseId -q '.[0].databaseId')}"
[ -n "$RUN_ID" ] || { echo "[fail] no successful build-installer run found"; exit 1; }
echo "[info] staging from run $RUN_ID"
gh run view "$RUN_ID" --repo "$REPO" --json headSha,displayTitle,createdAt \
  -q '"[info] \(.createdAt) \(.headSha[0:8]) \(.displayTitle)"'
gh run download "$RUN_ID" --repo "$REPO" -D "$TMP"

staged=0
stage() {  # stage <found-path> <dest-name>
  [ -f "$1" ] || return 0
  cmp -s "$1" "$DEST/$2" && { echo "[same] $2"; staged=$((staged+1)); return 0; }
  mv -f "$1" "$DEST/$2"; echo "[new ] $2"; staged=$((staged+1))
}
stage "$(find "$TMP" -name sabr-installer        -type f | head -1)" sabr-installer-linux
stage "$(find "$TMP" -name SabrInstaller.exe     -type f | head -1)" SabrInstaller.exe
stage "$(find "$TMP" -name SabrInstaller-macos.zip -type f | head -1)" SabrInstaller-macos.zip
[ "$staged" -eq 3 ] || { echo "[fail] expected 3 binaries, staged $staged"; exit 1; }

# Intel Mac build (macos-13 runner, added in e9c3b6a). Deliberately staged
# AFTER the 3-binary gate and not counted by it: builds made before that
# commit have no Intel artifact, and hard-failing on its absence would break
# staging for every older run. But an Intel build that CI produces and the
# staging script silently drops is worse than no build at all — that's how
# the artifact reached the runner and never reached a customer. So: stage it
# when it exists, say so loudly when it doesn't.
INTEL_SRC="$(find "$TMP" -name SabrInstaller-macos-intel.zip -type f | head -1)"
if [ -n "$INTEL_SRC" ]; then
  stage "$INTEL_SRC" SabrInstaller-macos-intel.zip
  echo "[info] Intel Mac build staged — the download page must offer it as an"
  echo "       explicit choice; UA sniffing CANNOT tell Apple Silicon from Intel"
  echo "       (both report 'Intel Mac OS X 10_15_7')."
else
  echo "[warn] no SabrInstaller-macos-intel.zip in this run — Intel Mac buyers"
  echo "       will be handed the arm64 zip and hit 'not supported on this Mac'."
fi

chmod 644 "$DEST"/* 2>/dev/null || true

echo "[ok] staged. sha256 of what the public now downloads:"
( cd "$DEST" && sha256sum SabrInstaller.exe sabr-installer-linux \
    SabrInstaller-macos.zip \
    $([ -f SabrInstaller-macos-intel.zip ] && echo SabrInstaller-macos-intel.zip) )
