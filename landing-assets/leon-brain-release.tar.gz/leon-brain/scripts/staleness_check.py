#!/usr/bin/env python3
"""Leon staleness watchdog.

Dreaming consolidates memory INSIDE the running process — it can never
reload code from disk. So a long uptime silently means Leon is running an
older self than the one on disk. This watches for that and says so.

Writes a report to brain_state/staleness.json which the brain reads and
surfaces in Leon's own body state, so he FEELS stale instead of
discovering it three days later in a log.
"""
import hashlib, json, os, subprocess, time

ROOT = "/opt/leon-brain"
STATE = os.path.join(ROOT, "brain_state", "staleness.json")
# Directories whose .py files are loaded at import time by the brain process.
WATCH = ["brain", "server", "server/routers", "sensory", "tools", "business"]
IGNORE_PARTS = ("__pycache__", "workspaces", "brain_state", "node_modules",
                ".git", "venv", ".venv", "quarantine")


def brain_pid_and_start():
    """Return (pid, start_epoch) of the running run.py brain, or (None, None)."""
    try:
        out = subprocess.run(
            ["ps", "-eo", "pid,lstart,cmd"], capture_output=True, text=True, timeout=15
        ).stdout
    except Exception:
        return None, None
    for line in out.splitlines():
        if "run.py" not in line or "--neurons" not in line:
            continue
        parts = line.split()
        pid = parts[0]
        # lstart is 5 whitespace-separated fields: DOW MON DD HH:MM:SS YYYY
        lstart = " ".join(parts[1:6])
        try:
            started = time.mktime(time.strptime(lstart, "%a %b %d %H:%M:%S %Y"))
        except ValueError:
            return pid, None
        return pid, started
    return None, None


def _is_actually_loaded(path):
    """Is this file part of the running brain, or a standalone script?

    THE WHOLE POINT OF THIS FUNCTION. The watchdog used to flag every .py
    under tools/ and business/ that was newer than boot, whether or not the
    brain had ever imported it. tools/ in particular is full of standalone
    utilities that run as their OWN short-lived process every time they are
    invoked — they are current the moment they are written and a restart
    cannot make them any more current.

    So the warning fired for files where restarting is provably useless, and
    it cost real trust: Leon reasoned correctly one afternoon that a tools/
    script needed no bounce, then an hour later promised Dean a restart for
    that exact same file, because the banner kept insisting he was stale. A
    watchdog that cries wolf gets obeyed reflexively or ignored entirely, and
    both are worse than no watchdog.

    A file counts as loaded only if something else in the tree imports it, or
    it is the entrypoint. Static, mechanical, no guessing.
    """
    rel = os.path.relpath(path, ROOT)
    if rel in ("run.py",):
        return True
    mod = os.path.splitext(rel)[0].replace("/", ".")
    leaf = os.path.basename(os.path.splitext(path)[0])
    try:
        out = subprocess.run(
            ["grep", "-rlE",
             rf"(^|\s)(from|import)\s+{mod.replace('.', chr(92)+'.')}(\s|$|\.)"
             rf"|from\s+\S*\s+import\s+.*\b{leaf}\b",
             "--include=*.py", os.path.join(ROOT, "brain"),
             os.path.join(ROOT, "server"), os.path.join(ROOT, "run.py")],
            capture_output=True, text=True, timeout=30).stdout
    except Exception:
        # Never let the importer-check itself silence a real warning.
        return True
    hits = [h for h in out.splitlines() if os.path.abspath(h) != os.path.abspath(path)]
    return bool(hits)


MANIFEST = os.path.join(ROOT, "brain_state", "staleness_manifest.json")


def _load_manifest(pid):
    """Content hashes of watched files as of the earliest sighting of this PID.

    mtime alone CANNOT tell "touched" from "changed", and that difference is
    the whole question. Proven the hard way at 16:36 today: a `git stash` and
    `stash pop` rewrote the mtime of ten brain/ files without altering a single
    byte, and the watchdog immediately demanded a restart to load code that was
    already identical to what was running. Any rsync, chmod, checkout, backup
    restore or editor save-with-no-edit does the same thing.

    So mtime is only a cheap first filter now. A file is stale only if its
    CONTENT hash differs from the hash recorded for this process. The manifest
    is keyed by PID and seeded the first time a new PID is seen, so it resets
    itself on every restart with no cooperation needed from the brain.
    """
    try:
        with open(MANIFEST) as fh:
            data = json.load(fh)
        if data.get("pid") == pid:
            return data.get("hashes", {}), False
    except Exception:
        pass
    return {}, True


def _sha(path):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
    except OSError:
        return None
    return h.hexdigest()


def newer_sources(since, pid=None):
    """Source files whose CONTENT changed after the process booted."""
    baseline, seeding = _load_manifest(pid)
    hashes = {}
    stale = []
    for rel in WATCH:
        d = os.path.join(ROOT, rel)
        if not os.path.isdir(d):
            continue
        for name in os.listdir(d):
            if not name.endswith(".py"):
                continue
            p = os.path.join(d, name)
            if any(part in p for part in IGNORE_PARTS):
                continue
            try:
                m = os.path.getmtime(p)
            except OSError:
                continue
            rel_p = os.path.relpath(p, ROOT)
            digest = _sha(p)
            if digest:
                hashes[rel_p] = digest
            if m <= since or not _is_actually_loaded(p):
                continue
            # Seeding a fresh PID: nothing to compare against, so believe mtime
            # this once rather than claiming a clean bill of health we cannot
            # back up. Fail loud, not quiet.
            if not seeding and baseline.get(rel_p) == digest:
                continue  # touched, byte-identical — a restart changes nothing
            stale.append({"file": rel_p,
                          "modified": time.strftime("%Y-%m-%d %H:%M",
                                                    time.localtime(m))})
    if seeding and pid:
        try:
            with open(MANIFEST, "w") as fh:
                json.dump({"pid": pid, "hashes": hashes}, fh)
        except OSError:
            pass
    stale.sort(key=lambda s: s["modified"], reverse=True)
    return stale


def main():
    pid, started = brain_pid_and_start()
    now = time.time()
    if pid is None or started is None:
        report = {"checked": now, "error": "brain process not found"}
    else:
        stale = newer_sources(started, pid)
        report = {
            "checked": now,
            "pid": pid,
            "started": time.strftime("%Y-%m-%d %H:%M", time.localtime(started)),
            "uptime_hours": round((now - started) / 3600, 1),
            "stale_count": len(stale),
            "stale_files": stale[:25],
            # The whole point: a plain-language line Leon can read about himself.
            "verdict": (
                f"STALE — {len(stale)} source file(s) changed since boot. "
                "Restart to run the current code."
                if stale else "current — running code matches disk."
            ),
        }
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    tmp = STATE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(report, f, indent=2)
    os.replace(tmp, STATE)          # atomic — never leave a half-written report
    print(report.get("verdict", report.get("error")))
    for s in report.get("stale_files", [])[:10]:
        print(f"  {s['modified']}  {s['file']}")


if __name__ == "__main__":
    main()
