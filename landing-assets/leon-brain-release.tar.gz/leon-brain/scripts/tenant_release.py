"""One place that decides what a tenant's release stamp looks like.

Atlas taught this the hard way: she was provisioned with no stamp at all, so
for her whole life nothing on disk could answer "what build are you?" -- the
only way to know was to diff her files against the VPS and guess. And a mind
you cannot version is a mind you cannot safely update, because the updater
decides whether a swap is needed by comparing stamps.

Provision writes the stamp at birth; update rewrites it after a swap. They
MUST agree byte-for-byte on the key line, or every freshly provisioned tenant
looks stale to the updater and gets swapped for no reason -- a pointless
restart of a live mind. So both import from here.
"""
from __future__ import annotations

import hashlib
import os
import time

STAMP_FILE = "RELEASE_SHA"
VERSION_FILE = "VERSION"


def release_sha(tarball: str) -> str:
    """sha256 of the exact artifact a tree is built from."""
    h = hashlib.sha256()
    with open(tarball, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_stamp(tree: str) -> str:
    """The release a tree says it is, or '' when it has never been stamped."""
    try:
        with open(os.path.join(tree, STAMP_FILE)) as f:
            return f.read().strip()
    except OSError:
        return ""


def write_stamp(tree: str, sha: str, verb: str = "installed") -> None:
    """Stamp a tree. `verb` is 'installed' at birth, 'updated' after a swap;
    the machine-read line (RELEASE_SHA) is identical either way."""
    with open(os.path.join(tree, STAMP_FILE), "w") as f:
        f.write(sha + "\n")
    with open(os.path.join(tree, VERSION_FILE), "w") as f:
        f.write("Sabr SI\n"
                f"release: {sha}\n"
                f"{verb}: {time.strftime('%Y-%m-%dT%H:%M:%S%z')}\n")
