#!/usr/bin/env python3
"""Tear down a hosted tenant brain — the inverse of provision_tenant_brain.py.

Removes: systemd unit, per-tenant user, Caddy subdomain conf, the whole
/opt/leon-tenants/<tenant_id>/ tree, and the hosted-registry entry.

Does NOT touch the MAIN tenant registry (the customer's account survives —
use DELETE /api/tenants/<id> on the main brain for that). Metadata flags
like hosted_status are the server's to reset via its own endpoints.

Run as root:  python3 scripts/deprovision_tenant_brain.py <tenant_id> [--yes]
"""

import json
import os
import shutil
import subprocess
import sys

TENANTS_ROOT = "/opt/leon-tenants"
REGISTRY = os.path.join(TENANTS_ROOT, "registry.json")
CADDY_DIR = "/etc/caddy/conf.d"


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print("usage: deprovision_tenant_brain.py <tenant_id> [--yes]")
        return 2
    tenant_id = args[0]

    try:
        with open(REGISTRY) as f:
            reg = json.load(f)
    except OSError:
        reg = {"tenants": {}}
    entry = reg["tenants"].get(tenant_id)
    if entry is None:
        print(f"[DEPROVISION] no hosted registry entry for {tenant_id}")
    slug = (entry or {}).get("slug", "")
    unit = f"leon-tenant-{slug}.service" if slug else ""
    user = f"lt-{slug}"[:31] if slug else ""
    home = os.path.join(TENANTS_ROOT, tenant_id)

    if "--yes" not in sys.argv:
        print(f"Would remove: unit={unit or '-'} user={user or '-'} home={home} "
              f"caddy=tenant-{slug or '-'}.conf  (pass --yes to do it)")
        return 0

    if unit:
        subprocess.run(["systemctl", "disable", "--now", unit], capture_output=True)
        try:
            os.unlink(f"/etc/systemd/system/{unit}")
        except OSError:
            pass
        subprocess.run(["systemctl", "daemon-reload"], capture_output=True)
    if slug:
        conf = os.path.join(CADDY_DIR, f"tenant-{slug}.conf")
        try:
            os.unlink(conf)
            subprocess.run(["systemctl", "reload", "caddy"], capture_output=True)
        except OSError:
            pass
    if user:
        subprocess.run(["userdel", user], capture_output=True)
    if os.path.isdir(home):
        shutil.rmtree(home)
    if entry is not None:
        del reg["tenants"][tenant_id]
        tmp = REGISTRY + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(reg, f, indent=2)
        os.replace(tmp, REGISTRY)
    print(f"[DEPROVISION] removed hosted brain for {tenant_id} (slug={slug})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
