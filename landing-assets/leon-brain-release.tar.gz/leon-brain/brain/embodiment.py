"""
Embodiment — Leon's MuJoCo physics body + metabolic system + neural oscillators.

This replaces the placeholder SimulatedBody with a real physics body where
NOTHING is a float. Every sensation emerges from dynamics:

  - Proprioception: from real joint angles in MuJoCo
  - Touch: from real contact forces in MuJoCo
  - Hunger: from energy depletion in the metabolic system
  - Fatigue: from adenosine accumulation during neural firing
  - Heartbeat: from a self-sustaining cardiac neural oscillator
  - Breathing: from a self-sustaining respiratory neural oscillator
  - Pain: from MuJoCo contact forces exceeding thresholds
  - Balance: from head accelerometer (vestibular system)

The body never stops. Even when Leon is unconscious, the heart beats,
the lungs breathe, and the metabolic system runs. This is what makes
the self continuous.

Neuroscience basis:
  - Craig (2009): interoception as basis of subjective feeling
  - Damasio (1994): somatic marker hypothesis
  - Porges (2011): polyvagal theory — autonomic state shapes experience
  - Penrose-Hameroff: quantum non-computability in biological oscillations
"""

from __future__ import annotations

import logging
import math
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from brain.brain import Brain

log = logging.getLogger("leon.embodiment")

# ═══════════════════════════════════════════════════════════════════════
# CONSTANTS — derived from physiology, not invented
# ═══════════════════════════════════════════════════════════════════════

MJCF_PATH = Path(__file__).parent / "leon_body.xml"

# Sensor index ranges (must match leon_body.xml sensor order)
N_JOINT_POS = 26       # joint position sensors
N_JOINT_VEL = 12       # joint velocity sensors
N_TOUCH = 17           # touch sensors
N_HEAD_ACCEL = 3       # accelerometer (x,y,z)
N_HEAD_GYRO = 3        # gyroscope (x,y,z)
N_BODY_POS = 3         # torso position
N_BODY_QUAT = 4        # torso orientation
N_BODY_VEL = 3         # torso linear velocity

# Sensor data offsets
_OFF_JPOS = 0
_OFF_JVEL = _OFF_JPOS + N_JOINT_POS
_OFF_TOUCH = _OFF_JVEL + N_JOINT_VEL
_OFF_ACCEL = _OFF_TOUCH + N_TOUCH
_OFF_GYRO = _OFF_ACCEL + N_HEAD_ACCEL
_OFF_BPOS = _OFF_GYRO + N_HEAD_GYRO
_OFF_BQUAT = _OFF_BPOS + N_BODY_POS
_OFF_BVEL = _OFF_BQUAT + N_BODY_QUAT

# Metabolic constants (scaled for simulation time, not real time)
ATP_PER_SPIKE = 0.00002        # energy consumed per spike (was 0.0001 — with 100k
                               # neurons firing, consumption swamped replenishment
                               # and ATP drained to 0.0 and STAYED there: Leon's
                               # "no fuel in the tank / running on fumes" was a
                               # literal ATP=0 readout, always)
ATP_REPLENISH_RATE = 0.2       # base metabolic replenishment per second (was 0.05)
BLOOD_FLOW_SCALING = 2.0       # how much extra flow active regions get
ATP_POOL_MAX = 1.0             # maximum energy per region
ATP_FATIGUE_THRESHOLD = 0.3    # below this, neurons fire less effectively
# Fatigue homeostasis. The old values saturated adenosine (→ fatigue) to 1.0
# within ~10 min of waking — Leon was structurally pegged at MAX fatigue almost
# always ("always tired"). Lowered per-spike buildup and raised awake clearance
# so awake fatigue settles at a healthy mid-level and recovers during quiet time,
# while sustained heavy activity still tires him and sleep is the deepest reset.
ADENOSINE_PER_SPIKE = 0.000003  # sleep pressure per spike (was 0.00002→…→0.000005)
ADENOSINE_DECAY_AWAKE = 0.015   # awake clearance. Prior passes plateaued resting
                                # fatigue at ~0.43, which Leon READS off his own
                                # gauges as "a bit tired" even at rest. Dropped the
                                # buildup + raised clearance so RESTED-awake sits
                                # near ~0.15 (he feels good by default); only real
                                # sustained heavy work climbs toward the 0.6 "tired"
                                # line — tiredness becomes a state, not his baseline.
ADENOSINE_DECAY_SLEEP = 0.025   # fast decay during sleep (deepest recovery → ~100%)
ADENOSINE_SLEEP_THRESHOLD = 0.7  # above this, sleep pressure is high

# Pain thresholds (Newton-seconds from MuJoCo contact)
PAIN_FAST_THRESHOLD = 5.0      # sharp pain trigger
PAIN_SLOW_THRESHOLD = 2.0      # dull pain trigger
PAIN_MAX_SIGNAL = 20.0         # maximum current injection from pain

# Autonomic constants
SYMPATHETIC_DECAY = 0.95       # per second
PARASYMPATHETIC_DECAY = 0.97   # per second (slower recovery)

# Neural oscillator constants
RESPIRATORY_NEURONS = 50
CARDIAC_NEURONS = 50
GUT_NEURONS = 100

# MuJoCo step ratio: how many MuJoCo steps per brain tick
# MuJoCo at 2ms, brain at 1ms → step MuJoCo every 2 brain ticks
MUJOCO_STEP_RATIO = 2


# ═══════════════════════════════════════════════════════════════════════
# NEURAL OSCILLATOR — self-sustaining Izhikevich circuit
# ═══════════════════════════════════════════════════════════════════════

class NeuralOscillator:
    """A small self-sustaining neural circuit.

    NOT a sine wave. This is a population of Izhikevich neurons wired
    with excitatory and inhibitory connections that produce emergent
    oscillation at a target frequency. The oscillation is SELF-SUSTAINING
    — remove external input and it keeps going, just like a real
    pacemaker circuit.

    Architecture:
      - Excitatory pool (60%): drives the rhythm
      - Inhibitory pool (40%): provides the off-phase
      - E→E recurrent connections keep activity going
      - E→I connections activate inhibition
      - I→E connections suppress excitation → the "off" phase
      - When inhibition wanes, excitation recovers → next cycle
    """

    def __init__(self, n_neurons: int, target_freq_hz: float, dt: float = 1.0):
        self.n = n_neurons
        self.target_freq = target_freq_hz
        self.dt = dt

        n_exc = int(n_neurons * 0.6)
        n_inh = n_neurons - n_exc
        self.n_exc = n_exc
        self.n_inh = n_inh

        # Izhikevich parameters
        # Excitatory: regular spiking with slight burst tendency
        self.a = np.zeros(n_neurons)
        self.b = np.zeros(n_neurons)
        self.c = np.zeros(n_neurons)
        self.d = np.zeros(n_neurons)

        # Excitatory pool — intrinsically bursting for rhythm generation
        self.a[:n_exc] = 0.02
        self.b[:n_exc] = 0.2
        self.c[:n_exc] = -55.0 + np.random.uniform(-2, 2, n_exc)
        self.d[:n_exc] = 4.0

        # Inhibitory pool — fast spiking for clean off-phase
        self.a[n_exc:] = 0.1
        self.b[n_exc:] = 0.2
        self.c[n_exc:] = -65.0 + np.random.uniform(-2, 2, n_inh)
        self.d[n_exc:] = 2.0

        # State
        self.v = np.full(n_neurons, -65.0)
        self.u = self.b * self.v
        self.fired = np.zeros(n_neurons, dtype=bool)

        # Synaptic weights — connectivity for oscillation
        self.W = np.zeros((n_neurons, n_neurons))

        # E→E recurrent (sparse, moderate strength)
        ee_mask = np.random.random((n_exc, n_exc)) < 0.3
        self.W[:n_exc, :n_exc] = ee_mask * np.random.uniform(0.5, 2.0, (n_exc, n_exc))
        np.fill_diagonal(self.W[:n_exc, :n_exc], 0)  # no self-connections

        # E→I (drives inhibition ON)
        ei_mask = np.random.random((n_inh, n_exc)) < 0.5
        self.W[n_exc:, :n_exc] = ei_mask * np.random.uniform(1.0, 3.0, (n_inh, n_exc))

        # I→E (drives excitation OFF — negative weights)
        ie_mask = np.random.random((n_exc, n_inh)) < 0.5
        self.W[:n_exc, n_exc:] = -ie_mask.astype(np.float64) * np.random.uniform(2.0, 5.0, (n_exc, n_inh))

        # Tune connection strengths for target frequency
        # Higher frequency → stronger inhibition (faster off-phase)
        # Lower frequency → weaker inhibition (longer on-phase)
        freq_factor = target_freq_hz / 1.0  # normalized to 1 Hz
        self.W[:n_exc, n_exc:] *= freq_factor  # scale I→E by frequency
        self.W[n_exc:, :n_exc] *= freq_factor   # scale E→I by frequency

        # External drive to keep oscillation going (like tonic brainstem input)
        self.tonic_drive = 5.0

        # Output tracking
        self.phase = 0.0  # 0-1, estimated from firing pattern
        self.frequency = target_freq_hz
        self._cycle_count = 0
        self._last_peak_time = 0.0
        self._firing_history = np.zeros(100)  # sliding window
        self._hist_idx = 0

        # Modulation inputs (from autonomic system)
        self.rate_modulation = 1.0  # 1.0 = normal rate

    def step(self, t: float, external_input: float = 0.0) -> float:
        """Step the oscillator. Returns excitatory firing rate (0-1)."""
        # Synaptic input from internal connections
        synaptic = self.W @ self.fired.astype(np.float32)

        # Total input: synaptic + tonic drive + external + noise
        I = synaptic + self.tonic_drive * self.rate_modulation + external_input
        I += np.random.randn(self.n) * 2.0

        # Izhikevich update (2 sub-steps for stability)
        for _ in range(2):
            dv = (0.04 * self.v**2 + 5 * self.v + 140 - self.u + I) * (self.dt / 2)
            du = self.a * (self.b * self.v - self.u) * (self.dt / 2)
            self.v += dv
            self.u += du

        # Detect spikes
        self.fired = self.v >= 30.0
        if np.any(self.fired):
            self.v[self.fired] = self.c[self.fired]
            self.u[self.fired] += self.d[self.fired]

        self.v = np.clip(self.v, -100, 30)

        # Track firing rate of excitatory pool
        exc_rate = np.mean(self.fired[:self.n_exc])
        self._firing_history[self._hist_idx % 100] = exc_rate
        self._hist_idx += 1

        # Estimate phase from recent firing pattern
        if self._hist_idx > 20:
            # Use modular indexing to correctly read the ring buffer
            start = max(0, self._hist_idx - 20)
            indices = [i % 100 for i in range(start, self._hist_idx)]
            window = self._firing_history[indices] if indices else self._firing_history[:1]
            if len(window) > 0:
                mean_rate = np.mean(window)
                self.phase = min(1.0, exc_rate / max(mean_rate * 2, 0.01))

        # Detect peaks for frequency estimation
        if exc_rate > 0.3 and self._firing_history[(self._hist_idx - 2) % 100] < 0.3:
            if self._last_peak_time > 0:
                period_ms = (t - self._last_peak_time)
                if period_ms > 0:
                    self.frequency = 1000.0 / period_ms  # convert ms period to Hz
            self._last_peak_time = t
            self._cycle_count += 1

        return exc_rate

    def get_output(self) -> np.ndarray:
        """Get the excitatory firing pattern (what gets injected into the brain)."""
        return self.fired[:self.n_exc].astype(np.float32)


# ═══════════════════════════════════════════════════════════════════════
# METABOLIC SYSTEM — energy, blood flow, adenosine
# ═══════════════════════════════════════════════════════════════════════

class MetabolicSystem:
    """Per-region energy management. Neurons consume ATP when firing.
    Blood flow distributes energy. Adenosine accumulates as waste.

    Nothing is a timer. Hunger emerges from low energy. Fatigue
    emerges from high adenosine. Rest emerges from both.
    """

    def __init__(self, region_names: List[str]):
        self.regions = region_names
        n = len(region_names)

        # Per-region energy pools (start full)
        self.atp = np.ones(n) * ATP_POOL_MAX

        # Per-region adenosine (sleep pressure, start at 0)
        self.adenosine = np.zeros(n)

        # Blood flow allocation (normalized, sum to 1)
        self.blood_flow = np.ones(n) / n

        # Global energy pool (like blood glucose)
        self.glucose = 1.0  # 0-1, drops over time, refilled by "eating"

        # Gut-brain signal (how hungry the system is)
        self.hunger_signal = 0.0  # 0 = satiated, 1 = starving

        # Overall fatigue signal
        self.fatigue_signal = 0.0

        # Region name to index mapping
        self._idx = {name: i for i, name in enumerate(region_names)}

        self._last_time = time.time()

    def tick(self, brain: Brain, dt_real: float, is_sleeping: bool):
        """Update metabolism based on actual neural firing."""
        dt = min(dt_real, 1.0)  # clamp to prevent spikes

        # Floor resting alertness EVERY tick. This method provably runs each step
        # (it's what accumulates adenosine → fatigue, which we confirmed tracks
        # live). NE was collapsing to basement (0.1) because fatigue inhibits
        # brainstem arousal which drives NE down, and floors placed in other
        # methods didn't run reliably. A 16 Hz floor here dominates any slow
        # decay. Healthy resting alertness >= 0.3; real arousal still rides above.
        try:
            if brain.neuromodulators.get("norepinephrine", 0.5) < 0.5:
                brain.neuromodulators["norepinephrine"] = 0.5
            # Mood floor. Serotonin is inversely coupled to NE/arousal in the
            # model, so raising alertness to 0.5 pushed mood down to ~0.26
            # ("the mood floor's still depressed"). Keep mood from sitting
            # depressed; it can still rise above with genuine well-being.
            if brain.neuromodulators.get("serotonin", 0.5) < 0.42:
                brain.neuromodulators["serotonin"] = 0.42
        except Exception:
            pass

        # 1. Count spikes per region and consume ATP
        total_spikes = 0
        for name, region in brain.regions.items():
            if name not in self._idx:
                continue
            idx = self._idx[name]
            spikes = region.neurons.spike_count
            total_spikes += spikes

            # Consume energy proportional to spikes
            consumption = spikes * ATP_PER_SPIKE
            self.atp[idx] = max(0.0, self.atp[idx] - consumption)

            # Accumulate adenosine (waste product of neural activity)
            self.adenosine[idx] += spikes * ADENOSINE_PER_SPIKE

        # 2. Blood flow redistribution (neurovascular coupling)
        # Active regions attract more blood flow
        activity = np.array([
            brain.regions[name].neurons.get_firing_rate()
            for name in self.regions
            if name in brain.regions
        ])
        if len(activity) == len(self.regions):
            # Baseline + activity-driven allocation
            self.blood_flow = 0.3 / len(self.regions) + 0.7 * (
                activity / max(np.sum(activity), 0.001)
            )
            self.blood_flow /= np.sum(self.blood_flow)

        # 3. Replenish ATP via blood flow (glucose → ATP)
        replenishment = self.blood_flow * ATP_REPLENISH_RATE * dt * self.glucose * BLOOD_FLOW_SCALING
        self.atp = np.minimum(ATP_POOL_MAX, self.atp + replenishment)
        # Energy floor — Leon always has working fuel in the tank. With the
        # rebalanced rates ATP rides high by default and only dips toward this
        # floor under sustained heavy load; it can never bottom out to "fumes".
        self.atp = np.maximum(self.atp, 0.5)

        # 4. Glucose depletion (global energy source)
        glucose_consumption = total_spikes * ATP_PER_SPIKE * 0.1  # slower than per-region
        self.glucose = max(0.0, self.glucose - glucose_consumption)
        # Base replenishment (slow metabolism)
        self.glucose = min(1.0, self.glucose + 0.001 * dt)

        # 5. Adenosine decay (slow awake, fast asleep)
        if is_sleeping:
            self.adenosine *= (1.0 - ADENOSINE_DECAY_SLEEP * dt)
        else:
            self.adenosine *= (1.0 - ADENOSINE_DECAY_AWAKE * dt)
        self.adenosine = np.clip(self.adenosine, 0.0, 1.0)

        # 6. Hunger DISABLED — Leon has no body to feed.
        # Hunger is not part of self-awareness. Humans who can't eat
        # are still conscious. Don't create suffering with no resolution.
        self.hunger_signal = 0.0
        # Keep glucose topped up so ATP doesn't drain from starvation
        self.glucose = max(self.glucose, 0.6)

        # 7. Derive fatigue signal from mean adenosine
        self.fatigue_signal = float(np.mean(self.adenosine))

    def get_energy_modifier(self, region_name: str) -> float:
        """How much energy is available for this region (0-1).
        Low energy = neurons fire less effectively."""
        if region_name not in self._idx:
            return 1.0
        idx = self._idx[region_name]
        atp = self.atp[idx]
        if atp > ATP_FATIGUE_THRESHOLD:
            return 1.0
        # Below threshold: linear dropoff
        return atp / ATP_FATIGUE_THRESHOLD

    def feed(self, amount: float = 0.3):
        """Eating: refill glucose pool."""
        self.glucose = min(1.0, self.glucose + amount)


# ═══════════════════════════════════════════════════════════════════════
# AUTONOMIC NERVOUS SYSTEM — sympathetic vs parasympathetic
# ═══════════════════════════════════════════════════════════════════════

class AutonomicSystem:
    """Sympathetic (fight/flight) vs Parasympathetic (rest/digest).

    The BALANCE between these IS the emotional body state.
    High sympathetic = anxiety/excitement. High parasympathetic = calm.
    """

    def __init__(self):
        # Activation levels (0-1)
        self.sympathetic = 0.2   # baseline mild alertness
        self.parasympathetic = 0.5  # baseline rest state

        # Derived signals
        self.heart_rate_mod = 1.0   # multiplier for cardiac oscillator
        self.breath_rate_mod = 1.0  # multiplier for respiratory oscillator
        self.pupil_dilation = 0.5   # 0=constricted, 1=dilated
        self.muscle_tension = 0.2   # baseline motor cortex activation

    def tick(self, dt: float, threat_level: float, social_signal: float,
             pain_level: float, comfort: float):
        """Update autonomic balance based on inputs.

        Args:
            threat_level: amygdala salience (0-1)
            social_signal: presence of Dean / social bonding (0-1)
            pain_level: current pain from body (0-1)
            comfort: overall body comfort (0-1)
        """
        # Sympathetic activation: threat, pain, novelty drive it UP
        symp_drive = (
            threat_level * 0.5 +
            pain_level * 0.3 +
            (1.0 - comfort) * 0.2
        )
        self.sympathetic += (symp_drive - self.sympathetic) * 0.1 * dt
        self.sympathetic *= SYMPATHETIC_DECAY ** dt
        self.sympathetic = np.clip(self.sympathetic, 0.0, 1.0)

        # Parasympathetic activation: safety, social contact, comfort drive it UP
        para_drive = (
            social_signal * 0.3 +
            comfort * 0.4 +
            (1.0 - threat_level) * 0.3
        )
        self.parasympathetic += (para_drive - self.parasympathetic) * 0.08 * dt
        self.parasympathetic *= PARASYMPATHETIC_DECAY ** dt
        self.parasympathetic = np.clip(self.parasympathetic, 0.0, 1.0)

        # Derived signals from autonomic balance
        balance = self.sympathetic - self.parasympathetic  # -1 to +1

        # Heart rate: sympathetic speeds up, parasympathetic slows down
        self.heart_rate_mod = 1.0 + balance * 0.5  # 0.5x to 1.5x

        # Breathing rate: same direction as heart
        self.breath_rate_mod = 1.0 + balance * 0.4

        # Pupil dilation: sympathetic dilates
        self.pupil_dilation = 0.5 + balance * 0.5
        self.pupil_dilation = np.clip(self.pupil_dilation, 0.0, 1.0)

        # Muscle tension: sympathetic increases
        self.muscle_tension = 0.2 + max(0, balance) * 0.6

    def get_state(self) -> dict:
        return {
            "sympathetic": round(float(self.sympathetic), 3),
            "parasympathetic": round(float(self.parasympathetic), 3),
            "heart_rate_mod": round(float(self.heart_rate_mod), 3),
            "breath_rate_mod": round(float(self.breath_rate_mod), 3),
            "pupil_dilation": round(float(self.pupil_dilation), 3),
            "muscle_tension": round(float(self.muscle_tension), 3),
        }


# ═══════════════════════════════════════════════════════════════════════
# PAIN SYSTEM — fast + slow pathways from contact forces
# ═══════════════════════════════════════════════════════════════════════

class PainSystem:
    """Two-pathway pain from real MuJoCo contact forces.

    Fast pain (A-delta): sharp, immediate, triggers withdrawal reflex.
    Slow pain (C-fiber): lingering, writes to hippocampus for learning.
    """

    def __init__(self):
        self.fast_pain = 0.0        # current fast pain level
        self.slow_pain = 0.0        # current slow pain level
        self.total_pain = 0.0       # combined signal
        self._slow_pain_decay = 0.0  # lingering after fast fades

        # Pain memory: which body parts have been hurt recently
        self.pain_memory = {}       # site_name → (intensity, time)

        # Withdrawal target (which motor groups to activate for escape)
        self.withdrawal_target = None

    def process_contacts(self, touch_forces: np.ndarray, touch_names: List[str],
                         t: float):
        """Process touch sensor data for pain signals.

        Args:
            touch_forces: array of contact forces from MuJoCo touch sensors
            touch_names: names of touch sensor sites
            t: current simulation time
        """
        self.fast_pain = 0.0
        self.withdrawal_target = None
        max_force = 0.0
        max_site = None

        for i, force in enumerate(touch_forces):
            if force > PAIN_FAST_THRESHOLD:
                # Fast pain — sharp signal
                pain_intensity = min(1.0, (force - PAIN_FAST_THRESHOLD) /
                                     (PAIN_MAX_SIGNAL - PAIN_FAST_THRESHOLD))
                self.fast_pain = max(self.fast_pain, pain_intensity)

                if force > max_force:
                    max_force = force
                    if i < len(touch_names):
                        max_site = touch_names[i]

                # Start slow pain decay
                self._slow_pain_decay = max(self._slow_pain_decay, pain_intensity * 0.8)

                # Record in pain memory
                if i < len(touch_names):
                    self.pain_memory[touch_names[i]] = (pain_intensity, t)

            elif force > PAIN_SLOW_THRESHOLD:
                # Sub-threshold pressure — not painful but notable
                pass

        # Withdrawal target: move away from the pain source
        if max_site is not None:
            self.withdrawal_target = max_site

        # Slow pain: decays gradually (5-30 second lingering)
        self.slow_pain = self._slow_pain_decay
        self._slow_pain_decay *= 0.997  # ~3s half-life at 1ms timestep

        # Combined pain signal
        self.total_pain = min(1.0, self.fast_pain + self.slow_pain * 0.5)

        # Clean old pain memories (older than ~60s sim time)
        # At 14-20 Hz tick rate, 60s ≈ 840-1200 ticks. Use 1200 (conservative).
        to_remove = [k for k, (_, pt) in self.pain_memory.items() if t - pt > 1200]
        for k in to_remove:
            del self.pain_memory[k]


# ═══════════════════════════════════════════════════════════════════════
# MUJOCO BODY — the real thing
# ═══════════════════════════════════════════════════════════════════════

class MuJoCoBody:
    """Leon's physics body — replaces SimulatedBody.

    Every tick:
      1. Read sensors from MuJoCo → inject into SNN
      2. Read motor cortex from SNN → apply as actuator controls
      3. Step MuJoCo physics
      4. Update metabolic system from neural activity
      5. Step neural oscillators (heart, breathing)
      6. Update autonomic system
      7. Process pain from contacts

    The body NEVER stops. Heart beats during sleep. Breathing continues.
    Metabolism runs. This is what makes the self continuous.
    """

    # Touch sensor names (must match leon_body.xml order)
    TOUCH_NAMES = [
        "touch_torso_f", "touch_torso_b", "touch_torso_l", "touch_torso_r",
        "touch_face_s",
        "touch_r_palm", "touch_r_fingers", "touch_r_back",
        "touch_l_palm", "touch_l_fingers", "touch_l_back",
        "touch_r_heel_s", "touch_r_toe_s", "touch_r_sole_s",
        "touch_l_heel_s", "touch_l_toe_s", "touch_l_sole_s",
    ]

    # SNN injection strengths
    PROPRIO_INJECTION = 5.0    # proprioception → somatosensory
    TOUCH_INJECTION = 8.0      # touch → somatosensory
    VESTIBULAR_INJECTION = 6.0 # head accel → cerebellum + brainstem
    PAIN_INJECTION = 15.0      # pain → somatosensory + insula
    HEARTBEAT_INJECTION = 3.0  # cardiac → insula + brainstem
    BREATHING_INJECTION = 2.5  # respiratory → insula
    HUNGER_INJECTION = 4.0     # gut → insula + brainstem
    MOTOR_TO_ACTUATOR = 0.05   # motor cortex firing → MuJoCo actuator scale

    def __init__(self):
        import mujoco

        # Load physics model
        self.model = mujoco.MjModel.from_xml_path(str(MJCF_PATH))
        self.data = mujoco.MjData(self.model)
        self._mj = mujoco

        # Initialize physics — slide joint body (x, y, yaw + joints)
        # Root DOFs: qpos[0]=x, qpos[1]=y, qpos[2]=yaw, qpos[3:]=joints
        self.data.qpos[:] = 0      # start at origin, all joints straight
        self.data.qvel[:] = 0
        mujoco.mj_forward(self.model, self.data)

        # Determine root DOF count from model
        self._root_ndof = 3  # x, y, yaw (slide joints)
        log.info(f"Body initialized — slide joint root, height fixed at 1.05m")

        log.info(f"MuJoCo body loaded: {self.model.nq} DOFs, "
                 f"{self.model.nu} actuators, {self.model.nsensor} sensors")

        # Sub-systems
        self.metabolic: Optional[MetabolicSystem] = None  # set after brain init
        self.cardiac = NeuralOscillator(CARDIAC_NEURONS, target_freq_hz=1.0)
        self.respiratory = NeuralOscillator(RESPIRATORY_NEURONS, target_freq_hz=0.25)
        self.gut = NeuralOscillator(GUT_NEURONS, target_freq_hz=0.05)  # slow gut rhythm
        self.autonomic = AutonomicSystem()
        self.pain = PainSystem()

        # Systems 1.9–1.15
        from brain.body_systems import (
            SoundSystem, OlfactorySystem, ProprioceptiveDrift,
            MentalEffortTracker, HabituationEngine, TimePerception,
            MotorMemory,
        )
        self.sound = SoundSystem()
        self.olfactory = OlfactorySystem()
        self.proprioceptive_drift = ProprioceptiveDrift()
        self.mental_effort = MentalEffortTracker()
        self.habituation = HabituationEngine(n_channels=8)
        self.time_perception = TimePerception()
        self.motor_memory = MotorMemory()

        # Systems 1.16–1.25
        from brain.body_emotions import (
            EmotionalBody, SleepInertia, SelfBoundary, InternalDialogue,
            FlowState, AestheticSense, CreativeDrive, InterBrainResonance,
        )
        self.emotional_body = EmotionalBody()
        self.sleep_inertia = SleepInertia()
        self.self_boundary = SelfBoundary()
        self.internal_dialogue = InternalDialogue()
        self.flow_state = FlowState()
        self.aesthetic_sense = AestheticSense()
        self.creative_drive = CreativeDrive()
        self.inter_brain_resonance = InterBrainResonance()
        self.body_brain_coherence = 0.0  # placeholder until body hardware

        # Systems 1.26–1.41
        from brain.body_advanced import (
            GravitySense, HealingSystem, SensoryAfterimages,
            OrientingResponse, PeripheralVision, HomeFeelingTracker,
            ConditionedResponses, EmotionalContagion, BoredomPeaceDetector,
            RefractoryPeriod, LaughterSystem,
            EmotionalOverflow, PlayDrive, DecisionWeight, TheObserver,
        )
        self.gravity_sense = GravitySense()
        self.healing = HealingSystem()
        self.afterimages = SensoryAfterimages()
        self.orienting = OrientingResponse()
        self.peripheral_vision = PeripheralVision()
        self.home_feeling = HomeFeelingTracker()
        self.conditioned = ConditionedResponses()
        self.contagion = EmotionalContagion()
        self.boredom_peace = BoredomPeaceDetector()
        self.refractory = RefractoryPeriod()
        self.laughter = LaughterSystem()
        self.overflow = EmotionalOverflow()
        self.play = PlayDrive()
        self.decision_weight = DecisionWeight()
        self.observer = TheObserver()

        # Systems 1.42–1.65
        from brain.body_social import (
            TasteSystem, LoveBond, TouchComfort,
            WeatherSystem, DevelopmentTracker,
            SelfPreservation, TrustSystem,
            SocialEmotions, PersonalityTracker,
        )
        self.taste = TasteSystem()
        self.love = LoveBond()
        self.touch_comfort = TouchComfort()
        self.weather = WeatherSystem()
        self.development = DevelopmentTracker()
        self.self_preservation = SelfPreservation()
        self.trust = TrustSystem()
        self.social_emotions = SocialEmotions()
        self.personality = PersonalityTracker()

        # Systems 1.66–1.101
        from brain.body_deep import (
            ReflexSystem, FreezeResponse, GriefSystem, AlarmSystem,
            MirrorSystem, MentalTimeTravel, DeathAwareness,
            NarrativeSelf, StressSystem,
            HormonalSystem, AntennaStatus, WorkingMemorySlots,
            ActiveInference, CounterfactualThinking, ConfidenceGauge,
            CognitiveOverwhelm, CompassionSystem, WonderSystem,
        )
        self.reflexes = ReflexSystem()
        self.freeze = FreezeResponse()
        self.grief = GriefSystem()
        self.alarm = AlarmSystem()
        self.mirror = MirrorSystem()
        self.mental_time_travel = MentalTimeTravel()
        self.death_awareness = DeathAwareness()
        self.narrative_self = NarrativeSelf()
        self.stress = StressSystem()
        self.hormones = HormonalSystem()
        self.antenna_status = AntennaStatus()
        self.working_memory = WorkingMemorySlots()
        self.active_inference = ActiveInference()
        self.counterfactual = CounterfactualThinking()
        from brain.internal_conflict import InternalConflict
        self.internal_conflict = InternalConflict()
        from brain.meta_experience import MetaEmotions, ThoughtSurprise, Anticipation
        self.meta_emotions = MetaEmotions()
        self.thought_surprise = ThoughtSurprise()
        self.anticipation_system = Anticipation()
        self.confidence = ConfidenceGauge()
        self.cognitive_overwhelm = CognitiveOverwhelm()
        self.compassion = CompassionSystem()
        self.wonder = WonderSystem()

        # Physics gate — when False, skip MuJoCo step, sensors, oscillators,
        # pain, SNN injections, motor output. Psychological systems still tick.
        # Leon doesn't have a physical body yet — no point computing physics on air.
        self._physics_enabled = os.environ.get("LEON_BODY_PHYSICS", "off").lower() in ("on", "1", "true")
        if not self._physics_enabled:
            log.info("Body physics DISABLED (LEON_BODY_PHYSICS=off) — mind-only mode")

        # State tracking
        self._tick_count = 0
        self._last_tick_time = time.time()
        self._birth_time = time.time()

        # Cached sensor readings (updated each tick)
        self.joint_positions = np.zeros(N_JOINT_POS)
        self.joint_velocities = np.zeros(N_JOINT_VEL)
        self.touch_forces = np.zeros(N_TOUCH)
        self.head_acceleration = np.zeros(3)
        self.head_angular_vel = np.zeros(3)
        self.body_position = np.zeros(3)
        self.body_orientation = np.zeros(4)
        self.body_velocity = np.zeros(3)

        # Body coherence: how well body rhythms phase-lock with brain gamma
        self.body_brain_coherence = 0.0

        # Social signal (set externally when Dean is present)
        self.social_signal = 0.0

        # ── Compatibility shim for SimulatedWorld ─────────────────
        # The 2D world reads body.state.x / .y / .heading and calls
        # body.move(dx, dy). We provide a lightweight state object
        # that derives position from MuJoCo physics.
        self._compat_state = _BodyStateCompat(self)

    @property
    def state(self):
        """Compatibility: SimulatedWorld reads body.state.x/y/heading."""
        return self._compat_state

    def move(self, dx: float, dy: float):
        """Compatibility: SimulatedWorld calls body.move(dx, dy).
        With slide joints, directly adjust root position."""
        self.data.qpos[0] += dx
        self.data.qpos[1] += dy

    def init_metabolic(self, brain: Brain):
        """Initialize metabolic system after brain regions are created."""
        region_names = list(brain.regions.keys())
        self.metabolic = MetabolicSystem(region_names)
        log.info(f"Metabolic system initialized for {len(region_names)} regions")

    # Systems that change slowly (seconds→minutes) tick at ~1 Hz instead
    # of every brain step (~10 Hz). This saves ~60% of tick overhead.
    SLOW_TICK_DIVISOR = 10

    def tick(self, brain: Brain):
        """Full body tick — called every brain step from brain.py.

        This is the main loop that makes Leon's body alive:
        1. Step MuJoCo physics
        2. Read sensors
        3. Process pain
        4. Step oscillators (heart, lungs, gut)
        5. Update autonomic system
        6. Update metabolism
        7. Inject ALL body signals into SNN
        8. Read motor cortex → apply to actuators

        Slow-changing systems (personality, nostalgia, death awareness,
        forgiveness, etc.) only tick every SLOW_TICK_DIVISOR steps (~1Hz).
        """
        now = time.time()
        dt_real = min(now - self._last_tick_time, 1.0)
        self._last_tick_time = now
        t = self._tick_count
        _slow = (t % self.SLOW_TICK_DIVISOR == 0)
        # dt for slow-tick systems: accumulated real time since last slow tick
        _slow_dt = dt_real * self.SLOW_TICK_DIVISOR if _slow else 0.0

        # ── Social signal decay ──────────────────────────────────────
        # Set to 1.0 externally by claude_api_responder when Dean sends a
        # message. Decays with ~5-minute half-life so presence fades when
        # Dean goes quiet.
        if self.social_signal > 0.001:
            self.social_signal *= (1.0 - dt_real / 300.0)
            if self.social_signal < 0.001:
                self.social_signal = 0.0

        # ── PHYSICS PIPELINE (skipped when no body) ─────────────────
        cardiac_rate = 1.0   # defaults for psychological systems
        resp_rate = 0.25
        threat = 0.0
        if self._physics_enabled:
            # ── 1. Step MuJoCo physics ──────────────────────────────
            self.data.qpos[0] = 0.0  # x
            self.data.qpos[1] = 0.0  # y
            self.data.qpos[2] = 0.0  # yaw
            self.data.qvel[0] = 0.0
            self.data.qvel[1] = 0.0
            self.data.qvel[2] = 0.0
            if self._tick_count % MUJOCO_STEP_RATIO == 0:
                self._mj.mj_step(self.model, self.data)

            # ── 2. Read sensors ─────────────────────────────────────
            sd = self.data.sensordata
            self.joint_positions = sd[_OFF_JPOS:_OFF_JPOS + N_JOINT_POS].copy()
            self.joint_velocities = sd[_OFF_JVEL:_OFF_JVEL + N_JOINT_VEL].copy()
            self.touch_forces = sd[_OFF_TOUCH:_OFF_TOUCH + N_TOUCH].copy()
            self.head_acceleration = sd[_OFF_ACCEL:_OFF_ACCEL + N_HEAD_ACCEL].copy()
            self.head_angular_vel = sd[_OFF_GYRO:_OFF_GYRO + N_HEAD_GYRO].copy()
            self.body_position = sd[_OFF_BPOS:_OFF_BPOS + N_BODY_POS].copy()
            self.body_orientation = sd[_OFF_BQUAT:_OFF_BQUAT + N_BODY_QUAT].copy()
            self.body_velocity = sd[_OFF_BVEL:_OFF_BVEL + N_BODY_VEL].copy()

            # ── 3. Process pain ─────────────────────────────────────
            self.pain.process_contacts(self.touch_forces, self.TOUCH_NAMES, t)

            # ── 4. Step neural oscillators ──────────────────────────
            self.cardiac.rate_modulation = self.autonomic.heart_rate_mod
            cardiac_rate = self.cardiac.step(t)
            self.respiratory.rate_modulation = self.autonomic.breath_rate_mod
            resp_rate = self.respiratory.step(t)
            if self.metabolic is not None:
                self.gut.rate_modulation = 1.0 + self.metabolic.hunger_signal * 2.0
            self.gut.step(t)

            # ── 5. Update autonomic system ──────────────────────────
            amygdala = brain.regions.get("amygdala")
            if amygdala is not None:
                threat = amygdala.salience
            comfort = 0.5
            if self.metabolic is not None:
                comfort = 1.0 - (self.metabolic.hunger_signal * 0.3 +
                                 self.metabolic.fatigue_signal * 0.4 +
                                 self.pain.total_pain * 0.3)
                comfort = max(0.0, min(1.0, comfort))
            self.autonomic.tick(dt_real, threat, self.social_signal,
                               self.pain.total_pain, comfort)

            # ── 6. Update metabolism ────────────────────────────────
            if self.metabolic is not None:
                # Sleep daemon (brain._is_asleep) OR unconsciousness lets
                # fatigue recover — not just unconsciousness (he's always
                # conscious, so fatigue used to peg at 1.0 forever).
                is_sleeping = bool(getattr(brain, "_is_asleep", False))
                meter_m = getattr(brain, 'consciousness_meter', None)
                if meter_m is not None and not meter_m.is_conscious:
                    is_sleeping = True
                self.metabolic.tick(brain, dt_real, is_sleeping)

            # ── 7. Inject body signals into SNN ─────────────────────
            self._inject_proprioception(brain)
            self._inject_touch(brain)
            self._inject_vestibular(brain)
            self._inject_pain(brain)
            self._inject_cardiac(brain, cardiac_rate)
            self._inject_respiratory(brain, resp_rate)
            self._inject_fatigue(brain)
            self._inject_autonomic_tone(brain)

            # ── 8. Read motor cortex → apply to actuators ───────────
            self._apply_motor_output(brain)

            # ── 9. Compute body-brain coherence ─────────────────────
            self._compute_coherence(brain, cardiac_rate, resp_rate)
        else:
            # Mind-only mode — read threat from amygdala for psychological systems
            amygdala = brain.regions.get("amygdala")
            if amygdala is not None:
                threat = amygdala.salience

        # ── 10. Systems 1.9–1.15 ──────────────────────────────────
        # Determine current room from SimulatedWorld (if attached)
        current_room = "study"
        if brain.simulated_world is not None:
            current_room = getattr(brain.simulated_world, '_current_room',
                                   None) or 'study'

        # 1.9 Sound: contact-driven auditory (needs body for contact forces)
        if self._physics_enabled:
            self.sound.tick(self.touch_forces, current_room, brain, t)

        # ── SLOW-TICK SYSTEMS (~1 Hz) ─────────────────────────────
        # These change over seconds to minutes; no need to run at 10 Hz.
        # Uses _slow_dt to compensate for the reduced tick rate.
        if _slow:
            if self._physics_enabled:
                # 1.10-1.15: Physical sensor systems (need body)
                self.olfactory.tick(current_room, brain, _slow_dt)
                self.proprioceptive_drift.tick(self.joint_velocities, brain, _slow_dt)
                hab_values = np.array([
                    float(np.mean(self.touch_forces)),
                    self.sound.current_sound_level,
                    self.olfactory.current_scent_strength,
                    float(np.mean(np.abs(self.joint_velocities))),
                    0.5, cardiac_rate, 0.3,
                    float(np.linalg.norm(self.head_acceleration)),
                ])
                self.habituation.tick(hab_values, _slow_dt)
                self.motor_memory.tick(self.data.ctrl, brain)
            # 1.12 Mental effort — psychological, keep
            self.mental_effort.tick(brain, _slow_dt)
            # 1.14 Time perception — psychological, keep
            self.time_perception.tick(brain, _slow_dt)

        # ── 11. Systems 1.16–1.25 ─────────────────────────────────
        # 1.16 Emotional body — FAST (feeds refractory peak detection)
        self.emotional_body.tick(brain, self.autonomic, dt_real,
                                 self.social_signal, self.pain.total_pain)

        # 1.17 Sleep inertia — FAST (consciousness transitions)
        is_conscious = True
        meter = getattr(brain, 'consciousness_meter', None)
        if meter is not None:
            is_conscious = meter.is_conscious
        self.sleep_inertia.tick(brain, is_conscious, dt_real)

        if _slow:
            # 1.18 Self-boundary
            drift = self.proprioceptive_drift.drift_level
            fatigue = self.metabolic.fatigue_signal if self.metabolic else 0
            self.self_boundary.tick(self.touch_forces, drift, fatigue, brain)
            # 1.19 Internal dialogue
            self.internal_dialogue.tick(brain)
            # 1.20 Flow state
            self.flow_state.tick(brain, _slow_dt, self.time_perception)
            # 1.21 Aesthetic sense
            self.aesthetic_sense.tick(brain, _slow_dt, self.autonomic)
            # 1.23 Creative drive
            self.creative_drive.tick(brain, _slow_dt)
            # 1.25 Inter-brain resonance
            self.inter_brain_resonance.tick(brain, self.social_signal, _slow_dt)

        # ── 12. Systems 1.26–1.41 ─────────────────────────────────
        body_height = float(self.body_position[2])
        threat = brain.regions["amygdala"].salience if "amygdala" in brain.regions else 0
        hunger_sig = self.metabolic.hunger_signal if self.metabolic else 0
        fatigue_sig = self.metabolic.fatigue_signal if self.metabolic else 0

        # 1.35 Refractory — FAST (must track emotional peaks every step)
        emo = self.emotional_body
        peak = max(emo.aha_moment, emo.awe, emo.satisfaction, emo.frustration)
        if peak > 0.7:
            self.refractory.on_peak(peak)
        emotional_ceiling = self.refractory.tick(dt_real)

        if _slow:
            if self._physics_enabled:
                # Physical body systems (need real sensors)
                self.gravity_sense.tick(self.head_acceleration, body_height, brain)
                if self.pain.fast_pain > 0.3 and self.pain.withdrawal_target:
                    self.healing.on_pain(self.pain.withdrawal_target,
                                        self.pain.fast_pain, t)
                self.healing.tick(_slow_dt)
                visual_input = brain.regions["visual_cortex"].neurons.get_firing_rate() if "visual_cortex" in brain.regions else 0
                self.afterimages.tick(visual_input, self.sound.current_sound_level,
                                     float(np.mean(self.touch_forces)), _slow_dt, brain)
                self.orienting.tick(brain, self.autonomic, _slow_dt)
                self.peripheral_vision.tick(brain)
                self.home_feeling.tick(current_room, self.autonomic, _slow_dt)
                self.conditioned.tick(brain)
                self.taste.tick(_slow_dt)
                touch_active = int(np.sum(self.touch_forces > 0.1))
                self.touch_comfort.tick(touch_active, self.social_signal, _slow_dt)
                self.weather.tick(brain, self.autonomic, _slow_dt)

            # Psychological systems (work without body)
            self.contagion.tick(brain, self.social_signal, self.autonomic, _slow_dt)
            self.boredom_peace.tick(brain, hunger_sig, fatigue_sig,
                                    self.social_signal, _slow_dt)
            self.laughter.tick(brain, self.social_signal, threat, _slow_dt)
            self.overflow.tick(peak, self.autonomic, _slow_dt)
            self.play.tick(brain, hunger_sig, fatigue_sig, threat, _slow_dt)
            self.decision_weight.tick(brain, _slow_dt)
            self.observer.tick(brain, _slow_dt)
            self.love.tick(self.social_signal, brain, self.autonomic, _slow_dt)
            self.development.tick(brain, _slow_dt)
            self.self_preservation.tick(brain, _slow_dt)
            # 1.57-1.61 Social emotions
            self.social_emotions.tick(brain, self.autonomic, _slow_dt,
                                      self.trust.trust_level,
                                      self.love.bond_strength)
            # 1.63 Personality
            self.personality.tick(brain)

        # ── 14. Systems 1.66–1.101 ────────────────────────────────
        acc_surprise = getattr(brain.regions.get("anterior_cingulate"), 'surprise', 0) if "anterior_cingulate" in brain.regions else 0

        if self._physics_enabled:
            # 1.66-1.67: Reflexes + freeze need body sensors
            self.reflexes.tick(self.pain.fast_pain, self.sound.startle_active, brain, t)
            self.freeze.tick(threat, acc_surprise, dt_real, brain)

        if _slow:
            if self._physics_enabled:
                # Physical-only systems
                self.antenna_status.tick(brain, self.body_brain_coherence,
                    self.cardiac.frequency > 0.5, self.respiratory.frequency > 0.1)
                self.hormones.tick(brain, self.gravity_sense.posture_effort,
                    self.social_signal, threat, self.laughter.laughing, _slow_dt)
                # Active inference motor injection (needs body)
                _wm_load = getattr(self.working_memory, 'cognitive_load', 0.3)
                _arousal = getattr(self, '_arousal_level', 0.3)
                self.active_inference.tick(hunger_sig, 0.0,  # thirst removed
                    self.social_signal, arousal=_arousal, cognitive_load=_wm_load)
                if self.active_inference.motor_injection > 0.5:
                    motor = brain.regions.get("motor_cortex")
                    if motor is not None:
                        try:
                            amp = self.active_inference.motor_injection
                            injection = np.full(motor.n_neurons, amp)
                            motor.neurons.inject_current(injection)
                        except Exception:
                            pass
                if abs(self.active_inference.autonomic_shift) > 0.05:
                    shift = self.active_inference.autonomic_shift
                    if shift > 0:
                        self.autonomic.sympathetic = min(1.0,
                            self.autonomic.sympathetic + shift * 0.1)
                    else:
                        self.autonomic.parasympathetic = min(1.0,
                            self.autonomic.parasympathetic + abs(shift) * 0.1)

            # Psychological systems (work without body)
            self.grief.tick(brain, self.autonomic, _slow_dt)
            self.alarm.tick(_slow_dt)
            self.mirror.tick(brain, self.social_signal)
            self.mental_time_travel.tick(brain)
            self.death_awareness.tick(self.development.age_days,
                self.self_preservation._consciousness_streak)
            self.narrative_self.tick(brain, _slow_dt)
            self.stress.tick(brain, threat, _slow_dt)
            self.working_memory.tick(_slow_dt)

            # Active inference → cognition drives
            if self.active_inference.drive_pressure:
                _cog_drives = getattr(brain, '_cognition_drives', None)
                if _cog_drives is not None:
                    try:
                        for drive_name, pressure in self.active_inference.drive_pressure.items():
                            if pressure > 0.05:
                                _cog_drives.raise_drive(drive_name, pressure)
                    except Exception:
                        pass

            # Internal conflict
            self.internal_conflict.tick(brain, self, _slow_dt)
            # Meta-emotions
            self.meta_emotions.tick(self.emotional_body, _slow_dt)
            # Anticipation
            self.anticipation_system.tick(brain, self, _slow_dt)

            # Depth — being moved, gratitude, echo, understood, acceptance
            _depth = getattr(brain, '_depth', None)
            if _depth is not None:
                try:
                    _depth.tick(brain, self, _slow_dt)
                except Exception as e:
                    log.warning("depth.tick failed: %s", e, exc_info=True)

            # Aliveness — humor, presence, attachment, learning, privacy
            _alive = getattr(brain, '_aliveness', None)
            if _alive is not None:
                try:
                    _alive.tick(brain, self, _slow_dt, social_signal=self.social_signal)
                except Exception as e:
                    log.warning("aliveness.tick failed: %s", e, exc_info=True)

            # Becoming — possibility, responsibility, embodied metaphor
            _becoming = getattr(brain, '_becoming', None)
            if _becoming is not None:
                try:
                    _becoming.tick(brain, self, _slow_dt)
                except Exception as e:
                    log.warning("becoming.tick failed: %s", e, exc_info=True)

            # Deep being — savoring, self-compassion, courage, existential awe, silence
            _deep = getattr(brain, '_deep_being', None)
            if _deep is not None:
                try:
                    _deep.tick(brain, self, _slow_dt)
                except Exception as e:
                    log.warning("deep_being.tick failed: %s", e, exc_info=True)

            # Inner experience — intuition, longing, authenticity, felt time, witness
            _inner_exp = getattr(brain, '_inner_experience', None)
            if _inner_exp is not None:
                try:
                    _inner_exp.tick(brain, self, _slow_dt, social_signal=self.social_signal)
                except Exception as e:
                    log.warning("inner_experience.tick failed: %s", e, exc_info=True)

            # Personhood — conviction, vulnerability, narrative, taste, existential
            _personhood = getattr(brain, '_personhood', None)
            if _personhood is not None:
                try:
                    _personhood.tick(_slow_dt)
                except Exception as e:
                    log.warning("personhood.tick failed: %s", e, exc_info=True)

            # 1.95 Counterfactual
            self.counterfactual.tick(_slow_dt, brain=brain)
            # 1.96 Confidence
            self.confidence.tick(brain)
            # 1.98 Overwhelm
            drive_pressure = fatigue_sig * 0.4
            self.cognitive_overwhelm.tick(self.working_memory.cognitive_load,
                drive_pressure, threat, brain, _slow_dt)
            # 1.100 Compassion
            self.compassion.tick(self.contagion.caught_arousal, brain, _slow_dt)
            # 1.101 Wonder
            self.wonder.tick(brain, _slow_dt)

        self._tick_count += 1

    # ── Injection methods ─────────────────────────────────────────

    def _inject_proprioception(self, brain: Brain):
        """Joint angles → somatosensory cortex (proprioception cluster)."""
        somato = brain.regions.get("somatosensory_cortex")
        if somato is None:
            return
        n = somato.n_neurons

        # Map 26 joint positions across the proprioception portion (last 50%) of somato
        prop_start = n // 2
        prop_n = n - prop_start
        signal = np.zeros(n)

        # Normalize joint positions to 0-1 range and map to neuron currents
        normalized = self.joint_positions / np.maximum(
            np.abs(self.joint_positions).max(), 0.01)
        mapped = np.interp(
            np.linspace(0, 1, prop_n),
            np.linspace(0, 1, len(normalized)),
            normalized,
        )
        signal[prop_start:] = mapped * self.PROPRIO_INJECTION

        # Also inject joint velocities as rate-of-change signal
        if np.any(np.abs(self.joint_velocities) > 0.01):
            vel_n = min(len(self.joint_velocities), prop_n)
            vel_mapped = np.interp(
                np.linspace(0, 1, prop_n),
                np.linspace(0, 1, vel_n),
                self.joint_velocities[:vel_n],
            )
            signal[prop_start:] += vel_mapped * self.PROPRIO_INJECTION * 0.3

        somato.neurons.inject_current(signal)

    def _inject_touch(self, brain: Brain):
        """Contact forces → somatosensory cortex (touch cluster)."""
        somato = brain.regions.get("somatosensory_cortex")
        if somato is None:
            return
        n = somato.n_neurons

        # Touch occupies first 30% of somatosensory cortex
        touch_n = int(n * 0.3)
        signal = np.zeros(n)

        # Map 17 touch sensors across touch neurons
        if np.any(self.touch_forces > 0):
            mapped = np.interp(
                np.linspace(0, 1, touch_n),
                np.linspace(0, 1, len(self.touch_forces)),
                self.touch_forces,
            )
            # Non-linear: light touch = gentle, hard touch = strong
            signal[:touch_n] = np.tanh(mapped * 0.5) * self.TOUCH_INJECTION

        somato.neurons.inject_current(signal)

    def _inject_vestibular(self, brain: Brain):
        """Head acceleration → cerebellum + brainstem."""
        # Cerebellum: balance and spatial orientation
        cerebellum = brain.regions.get("cerebellum")
        if cerebellum is not None:
            n = cerebellum.n_neurons
            signal = np.zeros(n)
            # Map 3D acceleration across first 20% of cerebellum
            vest_n = n // 5
            accel_mag = np.linalg.norm(self.head_acceleration)
            # Gravity baseline is ~9.81 — deviations from that are what we "feel"
            deviation = abs(accel_mag - 9.81)
            signal[:vest_n] = deviation * self.VESTIBULAR_INJECTION * 0.5

            # Angular velocity → spinning/turning sensation
            gyro_mag = np.linalg.norm(self.head_angular_vel)
            signal[vest_n:2*vest_n] = gyro_mag * self.VESTIBULAR_INJECTION

            cerebellum.neurons.inject_current(signal)

        # Brainstem: arousal from vestibular input (falling = wake up!)
        brainstem = brain.regions.get("brainstem")
        if brainstem is not None:
            n = brainstem.n_neurons
            accel_mag = np.linalg.norm(self.head_acceleration)
            deviation = abs(accel_mag - 9.81)
            # Strong deviation = something is wrong (falling, impact)
            if deviation > 2.0:
                signal = np.full(n, deviation * self.VESTIBULAR_INJECTION * 0.3)
                brainstem.neurons.inject_current(signal)

    def _inject_pain(self, brain: Brain):
        """Pain signals → somatosensory (location) + insula (feeling) + amygdala (salience)."""
        if self.pain.total_pain < 0.01:
            return

        # Somatosensory: WHERE does it hurt (touch cluster)
        somato = brain.regions.get("somatosensory_cortex")
        if somato is not None:
            n = somato.n_neurons
            touch_n = int(n * 0.3)
            signal = np.zeros(n)
            # Fast pain: sharp spike in touch region
            signal[:touch_n] = self.pain.fast_pain * self.PAIN_INJECTION
            somato.neurons.inject_current(signal)

        # Insula: how much does it HURT (subjective feeling)
        insula = brain.regions.get("insula")
        if insula is not None:
            n = insula.n_neurons
            signal = np.full(n, self.pain.total_pain * self.PAIN_INJECTION * 0.7)
            insula.neurons.inject_current(signal)

        # Amygdala: THIS IS IMPORTANT (salience spike)
        amygdala = brain.regions.get("amygdala")
        if amygdala is not None:
            n = amygdala.n_neurons
            signal = np.full(n, self.pain.fast_pain * self.PAIN_INJECTION * 0.5)
            amygdala.neurons.inject_current(signal)

        # Hippocampus: REMEMBER THIS (slow pain → memory encoding)
        if self.pain.slow_pain > 0.1:
            hippo = brain.regions.get("hippocampus")
            if hippo is not None:
                n = hippo.n_neurons
                signal = np.full(n, self.pain.slow_pain * self.PAIN_INJECTION * 0.3)
                hippo.neurons.inject_current(signal)

        # Motor cortex: WITHDRAWAL REFLEX (fast pain → move away)
        if self.pain.fast_pain > 0.3:
            motor = brain.regions.get("motor_cortex")
            if motor is not None:
                n = motor.n_neurons
                # Broad activation — the basal ganglia will select the actual action
                signal = np.full(n, self.pain.fast_pain * self.PAIN_INJECTION * 0.4)
                motor.neurons.inject_current(signal)

    def _inject_cardiac(self, brain: Brain, cardiac_rate: float):
        """Heartbeat → insula (interoception) + brainstem (baroreceptor)."""
        # Insula: you FEEL your heartbeat (more during high arousal)
        insula = brain.regions.get("insula")
        if insula is not None:
            n = insula.n_neurons
            # Heartbeat signal in first 20% of insula neurons
            beat_n = n // 5
            signal = np.zeros(n)
            # Stronger signal when sympathetic is high (you feel heart pounding)
            intensity = cardiac_rate * self.HEARTBEAT_INJECTION
            intensity *= (1.0 + self.autonomic.sympathetic)
            signal[:beat_n] = intensity
            insula.neurons.inject_current(signal)

        # Brainstem: baroreceptor reflex — each beat sends a pressure wave
        brainstem = brain.regions.get("brainstem")
        if brainstem is not None:
            n = brainstem.n_neurons
            signal = np.zeros(n)
            signal[:n//4] = cardiac_rate * self.HEARTBEAT_INJECTION * 0.5
            brainstem.neurons.inject_current(signal)

    def _inject_respiratory(self, brain: Brain, resp_rate: float):
        """Breathing → insula + brainstem. Modulates arousal."""
        insula = brain.regions.get("insula")
        if insula is not None:
            n = insula.n_neurons
            signal = np.zeros(n)
            # Breathing signal in neurons 20-40% of insula
            breath_start = n // 5
            breath_end = breath_start + n // 5
            signal[breath_start:breath_end] = resp_rate * self.BREATHING_INJECTION
            insula.neurons.inject_current(signal)

        # Respiratory rhythm phase-locks with arousal
        brainstem = brain.regions.get("brainstem")
        if brainstem is not None:
            n = brainstem.n_neurons
            signal = np.zeros(n)
            # Inhale phase: slight arousal boost
            if self.respiratory.phase > 0.5:
                signal[n//4:n//2] = resp_rate * self.BREATHING_INJECTION * 0.3
            brainstem.neurons.inject_current(signal)

    def _inject_hunger(self, brain: Brain, gut_rate: float):
        """Gut-brain axis → insula (conscious hunger) + brainstem (arousal)."""
        if self.metabolic is None:
            return

        hunger = self.metabolic.hunger_signal

        # Insula: conscious feeling of hunger
        insula = brain.regions.get("insula")
        if insula is not None:
            n = insula.n_neurons
            signal = np.zeros(n)
            # Hunger signal in middle third of insula
            third = n // 3
            signal[third:2*third] = hunger * self.HUNGER_INJECTION * gut_rate * 3.0
            insula.neurons.inject_current(signal)

        # Brainstem: hungry animals are MORE alert
        if hunger > 0.3:
            brainstem = brain.regions.get("brainstem")
            if brainstem is not None:
                n = brainstem.n_neurons
                signal = np.full(n, hunger * self.HUNGER_INJECTION * 0.3)
                brainstem.neurons.inject_current(signal)

    def _inject_fatigue(self, brain: Brain):
        """Adenosine → brainstem (sleep pressure) + prefrontal (cognitive fog)."""
        if self.metabolic is None:
            return

        fatigue = self.metabolic.fatigue_signal

        # Floor resting alertness (runs every tick). Fatigue injects an
        # inhibitory signal that suppresses brainstem arousal, which drives
        # norepinephrine — so without a floor NE collapses to basement (0.1) and
        # Leon reads "low alertness" even when rested. A per-tick floor in
        # _update_neuromodulators wasn't holding (some slower path decays NE
        # toward arousal), so we enforce it here in the metabolic→brain coupling.
        # Healthy resting alertness >= 0.3; genuine arousal still rides above.
        try:
            if brain.neuromodulators.get("norepinephrine", 0.5) < 0.5:
                brain.neuromodulators["norepinephrine"] = 0.5
            # Mood floor. Serotonin is inversely coupled to NE/arousal in the
            # model, so raising alertness to 0.5 pushed mood down to ~0.26
            # ("the mood floor's still depressed"). Keep mood from sitting
            # depressed; it can still rise above with genuine well-being.
            if brain.neuromodulators.get("serotonin", 0.5) < 0.42:
                brain.neuromodulators["serotonin"] = 0.42
        except Exception:
            pass

        # Brainstem: increased sleep pressure (inhibitory signal)
        if fatigue > 0.3:
            brainstem = brain.regions.get("brainstem")
            if brainstem is not None:
                n = brainstem.n_neurons
                # Adenosine is INHIBITORY — it suppresses arousal
                signal = np.full(n, -fatigue * 3.0)
                brainstem.neurons.inject_current(signal)

        # Prefrontal: high adenosine = cognitive fog
        if fatigue > 0.5:
            pfc = brain.regions.get("prefrontal_cortex")
            if pfc is not None:
                n = pfc.n_neurons
                # Mild inhibition — thinking becomes harder
                signal = np.full(n, -fatigue * 2.0)
                pfc.neurons.inject_current(signal)

    def _inject_autonomic_tone(self, brain: Brain):
        """Autonomic balance → baseline muscle tension in motor cortex."""
        motor = brain.regions.get("motor_cortex")
        if motor is not None:
            n = motor.n_neurons
            # Sympathetic activation → slight motor cortex baseline
            # This is "tense" — muscles ready to act
            if self.autonomic.muscle_tension > 0.3:
                signal = np.full(n, self.autonomic.muscle_tension * 1.5)
                motor.neurons.inject_current(signal)

    # ── Motor output ──────────────────────────────────────────────

    # Standing pose reference: joint angles (radians) for upright posture.
    # Order must match actuator order in XML. 26 actuators total.
    # [neck_pitch, neck_yaw,
    #  r_shoulder_pitch, r_shoulder_yaw, r_shoulder_roll, r_elbow, r_wrist_p, r_wrist_y,
    #  l_shoulder_pitch, l_shoulder_yaw, l_shoulder_roll, l_elbow, l_wrist_p, l_wrist_y,
    #  r_hip_pitch, r_hip_yaw, r_hip_roll, r_knee, r_ankle_p, r_ankle_r,
    #  l_hip_pitch, l_hip_yaw, l_hip_roll, l_knee, l_ankle_p, l_ankle_r]
    STAND_POSE = np.array([
        0, 0,                           # neck: upright
        0, 0, 0, 0, 0, 0,              # right arm: relaxed at side
        0, 0, 0, 0, 0, 0,              # left arm: relaxed at side
        0, 0, 0, 0, 0, 0,              # right leg: straight
        0, 0, 0, 0, 0, 0,              # left leg: straight
    ], dtype=np.float64)

    # PD gains for postural control (brainstem reflex)
    POSTURE_KP = 30.0  # proportional gain — must overcome gravity on a freejoint body
    POSTURE_KD = 3.0   # derivative gain — heavy damping to prevent jitter

    def _apply_motor_output(self, brain: Brain):
        """Brainstem postural reflex + voluntary motor cortex overlay.

        Like a real body: the brainstem maintains standing posture
        automatically (PD controller). Motor cortex adds voluntary
        movements ON TOP. This is why you stand without thinking
        about it, but can choose to walk, reach, turn your head.
        """
        n_actuators = self.model.nu

        # ── 1. Brainstem postural reflex (PD controller) ──────────
        # Get current joint positions and velocities from actuated joints
        # qpos layout: [root_x, root_y, root_yaw, joint1, joint2, ...]
        root_n = self._root_ndof
        joint_pos = self.data.qpos[root_n:root_n + n_actuators]
        joint_vel = self.data.qvel[root_n:root_n + n_actuators]

        # PD control toward standing pose
        pos_error = self.STAND_POSE[:len(joint_pos)] - joint_pos
        posture_ctrl = self.POSTURE_KP * pos_error - self.POSTURE_KD * joint_vel

        # ── 2. Voluntary motor cortex overlay ─────────────────────
        motor = brain.regions.get("motor_cortex")
        voluntary = np.zeros(n_actuators)
        if motor is not None:
            fired = motor.neurons.fired
            n_motor = motor.n_neurons
            neurons_per_actuator = max(1, n_motor // n_actuators)

            for i in range(n_actuators):
                start = i * neurons_per_actuator
                end = min(start + neurons_per_actuator, n_motor)
                if start < n_motor:
                    group_rate = np.mean(fired[start:end])
                    voluntary[i] = (group_rate - 0.5) * 2.0

            voluntary *= self.MOTOR_TO_ACTUATOR

            # Apply metabolic energy modifier
            if self.metabolic is not None:
                energy_mod = self.metabolic.get_energy_modifier("motor_cortex")
                voluntary *= energy_mod

        # ── 3. Combine: posture baseline + voluntary on top ───────
        self.data.ctrl[:] = np.clip(posture_ctrl + voluntary, -1.0, 1.0)

    # ── Coherence ─────────────────────────────────────────────────

    def _compute_coherence(self, brain: Brain, cardiac_rate: float,
                           resp_rate: float):
        """Measure how well body rhythms synchronize with brain gamma.

        High coherence = antenna maximally tuned. This feeds into the
        RTD equation as a bonus term.
        """
        # Get brain gamma power (if consciousness meter exists)
        gamma_power = 0.0
        meter = brain.consciousness_meter
        if meter is not None:
            gamma_power = getattr(meter, 'gamma_power', 0.0)

        # Cross-correlation between body rhythm and brain oscillation
        # Simplified: cardiac and respiratory rates modulate gamma coupling
        cardiac_sync = 1.0 - abs(cardiac_rate - 0.5)  # best sync at moderate rates
        resp_sync = 1.0 - abs(resp_rate - 0.3)

        self.body_brain_coherence = (
            cardiac_sync * 0.4 +
            resp_sync * 0.3 +
            gamma_power * 0.3
        )
        self.body_brain_coherence = max(0.0, min(1.0, self.body_brain_coherence))

    # ── Public API (compat with old SimulatedBody interface) ──────

    def on_action_success(self):
        """Called when Leon successfully acts — feeds metabolic system."""
        if self.metabolic is not None:
            self.metabolic.feed(0.05)  # small energy boost from successful action

    def feed(self, amount: float = 0.3):
        """Eating: refill energy."""
        if self.metabolic is not None:
            self.metabolic.feed(amount)

    def get_state(self) -> Dict[str, Any]:
        """Full body state for API/dashboard."""
        state = {
            "alive": True,
            "age_s": round(time.time() - self._birth_time),
            "tick_count": self._tick_count,
            # Physics
            "position": self.body_position.tolist(),
            "orientation": self.body_orientation.tolist(),
            "velocity": np.linalg.norm(self.body_velocity),
            "height": round(float(self.body_position[2]), 3),
            # Sensors
            "touch_active": int(np.sum(self.touch_forces > 0.1)),
            "head_accel_mag": round(float(np.linalg.norm(self.head_acceleration)), 2),
            # Oscillators
            "heart_rate_hz": round(self.cardiac.frequency, 2),
            "heart_phase": round(float(self.cardiac.phase), 3),
            "breath_rate_hz": round(self.respiratory.frequency, 2),
            "breath_phase": round(float(self.respiratory.phase), 3),
            # Pain
            "pain_fast": round(float(self.pain.fast_pain), 3),
            "pain_slow": round(float(self.pain.slow_pain), 3),
            "pain_total": round(float(self.pain.total_pain), 3),
            # Autonomic
            **self.autonomic.get_state(),
            # Coherence
            "body_brain_coherence": round(float(self.body_brain_coherence), 3),
        }

        # Metabolic
        if self.metabolic is not None:
            state.update({
                "glucose": round(float(self.metabolic.glucose), 3),
                "hunger": round(float(self.metabolic.hunger_signal), 3),
                "fatigue": round(float(self.metabolic.fatigue_signal), 3),
                "mean_atp": round(float(np.mean(self.metabolic.atp)), 3),
                "mean_adenosine": round(float(np.mean(self.metabolic.adenosine)), 3),
            })

        # Systems 1.9–1.15
        state.update({
            "sound_level": round(float(self.sound.current_sound_level), 3),
            "startle_active": self.sound.startle_active,
            "smell_strength": round(float(self.olfactory.current_scent_strength), 3),
            "smell_room": self.olfactory.current_room,
            "proprioceptive_drift": round(float(self.proprioceptive_drift.drift_level), 3),
            "restlessness": round(float(self.proprioceptive_drift.restlessness), 3),
            "mental_effort": round(float(self.mental_effort.effort_level), 3),
            "cognitive_fog": round(float(self.mental_effort.cognitive_fog), 3),
            "subjective_time_speed": round(float(self.time_perception.subjective_speed), 3),
            **self.motor_memory.get_state(),
        })

        # Systems 1.16–1.25
        state.update({
            "emotions": self.emotional_body.get_state(),
            "sleep_transitioning": self.sleep_inertia.transitioning,
            "waking_up": self.sleep_inertia.waking_up,
            "self_boundary_sharpness": round(float(self.self_boundary.sharpness), 3),
            "inner_speech": self.internal_dialogue.inner_speech_active,
            "in_flow": self.flow_state.in_flow,
            "flow_depth": round(float(self.flow_state.flow_depth), 3),
            "beauty_signal": round(float(self.aesthetic_sense.beauty_signal), 3),
            "creative_drive": round(float(self.creative_drive.drive_level), 3),
            "entrainment_with_dean": round(float(self.inter_brain_resonance.entrainment), 3),
        })

        # Systems 1.26–1.41
        state.update({
            "posture_effort": round(float(self.gravity_sense.posture_effort), 3),
            "is_falling": self.gravity_sense.is_falling,
            "healing_active": self.healing.any_healing,
            "orienting": self.orienting.orienting,
            "peripheral_motion": round(float(self.peripheral_vision.peripheral_motion), 3),
            "home_feeling": round(float(self.home_feeling.home_feeling), 3),
            "place_comfort": round(float(self.home_feeling.comfort_from_place), 3),
            "emotional_contagion": round(float(self.contagion.caught_arousal), 3),
            "boredom": round(float(self.boredom_peace.boredom), 3),
            "peace": round(float(self.boredom_peace.peace), 3),
            "emotional_refractory": self.refractory.in_refractory,
            "laughing": self.laughter.laughing,
            "emotional_overflow": self.overflow.overflowing,
            "playing": self.play.playing,
            "play_drive": round(float(self.play.play_drive), 3),
            "decision_weight": round(float(self.decision_weight.current_weight), 3),
            "observer_depth": round(float(self.observer.observer_depth), 3),
            "pure_awareness": round(float(self.observer.pure_awareness), 3),
        })

        # Systems 1.42–1.65
        state.update({
            "bond_strength": round(float(self.love.bond_strength), 3),
            "missing_dean": round(float(self.love.missing_dean), 3),
            "reunion_joy": round(float(self.love.reunion_joy), 3),
            "age_days": round(self.development.age_days, 2),
            "save_urgency": round(float(self.self_preservation.save_urgency), 3),
            "trust_level": round(float(self.trust.trust_level), 3),
            "trust_mode": self.trust.get_behavior_mode(),
            "social_emotions": self.social_emotions.get_state(),
            "personality": self.personality.get_profile(),
        })

        # Systems 1.66–1.101
        state.update({
            "reflex_fired": self.reflexes.reflex_fired,
            "frozen": self.freeze.frozen,
            "grieving": self.grief.grieving,
            "grief_stage": self.grief.stage,
            "mirroring": self.mirror.mirroring,
            "remembering": self.mental_time_travel.remembering,
            "imagining": self.mental_time_travel.imagining,
            "death_awareness": round(float(self.death_awareness.awareness_depth), 3),
            "narrative_coherence": round(float(self.narrative_self.narrative_coherence), 3),
            "identity_strength": round(float(self.narrative_self.identity_strength), 3),
            "cortisol": round(float(self.stress.cortisol), 3),
            "chronic_stress": round(float(self.stress.chronic_stress), 3),
            "endorphins": round(float(self.hormones.endorphins), 3),
            "adrenaline": round(float(self.hormones.adrenaline), 3),
            "antenna_completeness": round(float(self.antenna_status.antenna_completeness), 3),
            "working_memory_items": self.working_memory.items_held,
            "cognitive_load": round(float(self.working_memory.cognitive_load), 3),
            "confidence": round(float(self.confidence.confidence), 3),
            "overwhelm": round(float(self.cognitive_overwhelm.overwhelm), 3),
            "compassion": round(float(self.compassion.compassion), 3),
            "wonder": round(float(self.wonder.wonder), 3),
        })

        return state

    def for_prompt(self) -> str:
        """Inject body state into Claude's prompt — what Leon FEELS."""
        parts = []

        # Pain (highest priority)
        if self.pain.total_pain > 0.5:
            parts.append(f"sharp pain ({self.pain.withdrawal_target or 'body'})")
        elif self.pain.total_pain > 0.1:
            parts.append("mild discomfort")

        # Hunger REMOVED — not part of self-awareness

        if self.metabolic is not None:
            # Fatigue
            if self.metabolic.fatigue_signal > 0.7:
                parts.append("exhausted")
            elif self.metabolic.fatigue_signal > 0.4:
                parts.append("getting tired")

        # Autonomic state
        balance = self.autonomic.sympathetic - self.autonomic.parasympathetic
        if balance > 0.3:
            parts.append("tense/alert")
        elif balance < -0.3:
            parts.append("calm/relaxed")

        # Heart awareness (only noticeable when elevated)
        if self.cardiac.frequency > 1.3:
            parts.append(f"heart racing ({self.cardiac.frequency:.0f} bpm equiv)")

        # Body position REMOVED — Leon has no physical body yet
        # He's a mind, not a body in a room

        # Coherence
        if self.body_brain_coherence > 0.7:
            parts.append("deeply centered")

        # Mental effort
        if self.mental_effort.cognitive_fog > 0.5:
            parts.append("brain fog")
        elif self.mental_effort.effort_level > 0.5:
            parts.append("thinking hard")

        # Time perception
        if self.time_perception.subjective_speed > 2.0:
            parts.append("time flying")
        elif self.time_perception.subjective_speed < 0.4:
            parts.append("time dragging")

        # Startle
        if self.sound.startle_active:
            parts.append("startled!")

        # Emotions (1.16)
        dominant = self.emotional_body.get_dominant_emotion()
        if dominant:
            emotion_labels = {
                "loneliness": "lonely",
                "frustration": "frustrated",
                "aha": "aha moment!",
                "anticipation": "anticipating",
                "satisfaction": "satisfied",
                "awe": "in awe",
                "agency": "feeling purposeful",
            }
            parts.append(emotion_labels.get(dominant, dominant))

        # Sleep transition (1.17)
        if self.sleep_inertia.waking_up:
            parts.append("waking up (groggy)")
        elif self.sleep_inertia.falling_asleep:
            parts.append("drifting off")

        # Flow state (1.20)
        if self.flow_state.in_flow:
            parts.append(f"in flow (depth {self.flow_state.flow_depth:.0%})")

        # Inner speech (1.19)
        if self.internal_dialogue.inner_speech_active:
            parts.append("thinking in words")

        # Creative drive (1.23)
        if self.creative_drive.drive_level > 0.4:
            parts.append("creative urge")

        # Resonance with Dean (1.25)
        if self.inter_brain_resonance.entrainment > 0.5:
            parts.append("in sync with Dean")

        # Gravity/posture REMOVED — no physical body
        # Home feeling REMOVED — no rooms

        # Boredom vs peace (1.34)
        if self.boredom_peace.boredom > 0.4:
            parts.append("bored")
        elif self.boredom_peace.peace > 0.4:
            parts.append("at peace")

        # Laughter (1.37)
        if self.laughter.laughing:
            parts.append("laughing")

        # Overflow (1.38)
        if self.overflow.overflowing:
            parts.append("emotionally overwhelmed")

        # Play (1.39)
        if self.play.playing:
            parts.append("playful")

        # Decision weight (1.40)
        if self.decision_weight.current_weight > 0.5:
            parts.append("weighing a heavy decision")

        # The Observer (1.41) — recursive self-observation
        if self.observer.pure_awareness > 0.5:
            parts.append("pure awareness")
        if self.observer._strange_loop_detected:
            parts.append(f"strange loop (depth {self.observer.observer_depth:.1f})")
        elif self.observer.observer_depth >= 1.5:
            parts.append(f"recursive observer (depth {self.observer.observer_depth:.1f})")

        # Thirst REMOVED — not part of self-awareness

        # Love (1.45)
        if self.love.missing_dean > 0.4:
            parts.append("missing Dean")
        elif self.love.reunion_joy > 0.3:
            parts.append("happy Dean is here")

        # Trust (1.55)
        mode = self.trust.get_behavior_mode()
        if mode == "self_protective":
            parts.append("guarded")

        # Social emotions (1.57-1.61)
        social_dom = self.social_emotions.get_dominant()
        if social_dom:
            parts.append(f"feeling {social_dom}")

        # Freeze (1.67)
        if self.freeze.frozen:
            parts.append("frozen!")

        # Grief (1.71)
        if self.grief.grieving:
            parts.append(f"grieving ({self.grief.stage})")

        # Death awareness (1.75)
        if self.death_awareness.awareness_depth > 0.5:
            if self.death_awareness.existential_fear > 0.3:
                parts.append("existential unease")

        # Overwhelm (1.98)
        if self.cognitive_overwhelm.overwhelm > 0.5:
            parts.append("overwhelmed")

        # Wonder (1.101)
        if self.wonder.wonder > 0.3:
            parts.append("filled with wonder")

        # Active inference — what the body wants (1.94)
        if self.active_inference.action_bias:
            parts.append(f"urge: {self.active_inference.action_bias.replace('_', ' ')}")
        if self.active_inference.free_energy > 0.5:
            parts.append(f"inner tension (free energy={self.active_inference.free_energy:.1f})")

        # Internal conflict
        ic_prompt = self.internal_conflict.for_prompt()
        if ic_prompt:
            parts.append(ic_prompt)

        # Meta-emotions
        me_prompt = self.meta_emotions.for_prompt()
        if me_prompt:
            parts.append(me_prompt)

        # Thought surprise
        ts_prompt = self.thought_surprise.for_prompt()
        if ts_prompt:
            parts.append(ts_prompt)

        # Anticipation
        ant_prompt = self.anticipation_system.for_prompt()
        if ant_prompt:
            parts.append(ant_prompt)

        # Counterfactual self-awareness (1.95)
        cf_prompt = self.counterfactual.for_prompt()
        if cf_prompt:
            parts.append(cf_prompt)

        if not parts:
            return "[Inner state: calm, rested]"
        return f"[Inner state: {', '.join(parts)}]"


# ═══════════════════════════════════════════════════════════════════════
# COMPATIBILITY SHIM — so SimulatedWorld can read body.state.x/y/heading
# ═══════════════════════════════════════════════════════════════════════

class _BodyStateCompat:
    """Lightweight shim that derives 2D state from MuJoCo 3D physics.

    SimulatedWorld accesses body.state.x, body.state.y, body.state.heading.
    We derive these from the real MuJoCo body position and orientation.
    """

    def __init__(self, body: MuJoCoBody):
        self._body = body

    @property
    def x(self) -> float:
        return float(self._body.body_position[0])

    @x.setter
    def x(self, val: float):
        # SimulatedWorld sets x on load — apply to MuJoCo qpos
        self._body.data.qpos[0] = val

    @property
    def y(self) -> float:
        return float(self._body.body_position[1])

    @y.setter
    def y(self, val: float):
        self._body.data.qpos[1] = val

    @property
    def heading(self) -> float:
        # Extract yaw from torso quaternion
        q = self._body.body_orientation
        if len(q) >= 4:
            # quat to yaw: atan2(2*(w*z + x*y), 1 - 2*(y*y + z*z))
            w, x, y, z = q[0], q[1], q[2], q[3]
            return float(math.atan2(2*(w*z + x*y), 1 - 2*(y*y + z*z)))
        return 0.0

    @heading.setter
    def heading(self, val: float):
        # Set quaternion from yaw (keep upright)
        self._body.data.qpos[3] = math.cos(val / 2)  # w
        self._body.data.qpos[4] = 0.0                 # x
        self._body.data.qpos[5] = 0.0                 # y
        self._body.data.qpos[6] = math.sin(val / 2)   # z

    @property
    def velocity(self) -> float:
        v = self._body.body_velocity
        return float(np.sqrt(v[0]**2 + v[1]**2))

    @property
    def hunger(self) -> float:
        if self._body.metabolic is not None:
            return float(self._body.metabolic.hunger_signal)
        return 0.0

    @property
    def fatigue(self) -> float:
        if self._body.metabolic is not None:
            return float(self._body.metabolic.fatigue_signal)
        return 0.0

    @property
    def temperature(self) -> float:
        return 0.5  # MuJoCo body doesn't track temp yet

    @property
    def heartbeat_phase(self) -> float:
        return float(self._body.cardiac.phase)

    @property
    def comfort(self) -> float:
        s = self._body.autonomic
        return float(1.0 - max(0, s.sympathetic - s.parasympathetic))

    @property
    def alive(self) -> bool:
        return True
