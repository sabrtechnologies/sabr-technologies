"""Durable owner work queue, walked by the existing action-cue tick (no new scheduler).

Ledger item 30 (plus item 28: the boot path acts on the resume note). The ledger
file was not in the checkout this was written in, so the job text is the spec.

Each owner request is one entry in STATE_DIR/private_out/work_queue.json:
    {id, goal, done_when, state, job_id, blocked_on, resume_at, attempts, ...}

Rules, applied once per tick:
  * One entry is active at a time. The real job status is read before any launch;
    an uncertain lookup never relaunches.
  * A worker exiting is not completion. An entry is done only when done_when
    passes. When one finishes, the next queued entry starts in the same tick.
  * Session/usage limit -> state 'waiting', resume_at = provider reset time,
    relaunch at resume_at with the previous notes. No message from Dean needed.
  * Any other failure (planner/model error, vanished job, refused launch) ->
    relaunch once, then blocked.
  * done_when fails after the job finished (review bounce) -> relaunch once with
    the review text as the task, then blocked.
  * At most MAX_ATTEMPTS launches per cause, then blocked_on holds one plain
    question for Dean. Never loops.
  * Boot reads the queue first and continues the top entry immediately, using
    its resume note (the entry's notes) instead of waiting for "continue".
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import ntpath
import posixpath
import threading
import time
from pathlib import Path

MAX_ATTEMPTS = 2           # wording only ("failed twice"); the cap is MAX_LAUNCHES
MAX_LAUNCHES = 2           # Dean 10-19 rule (b): launches per entry, all causes, then blocked
VERIFYING = "done_when verification"  # rule (a): shipped, done_when not yet confirmed
LIMIT_FALLBACK_S = 3600.0  # reset time unknown -> look again in an hour
LIVE_JOB_STATES = ("queued", "running", "starting", "reviewing")
_lock = threading.RLock()
_LIMIT = re.compile(r"usage limit|session limit|rate.?limit|quota|limit reached|\b429\b|"
                    r"out of (?:credits|usage)|limit resets", re.I)


_WINDOWS_ABS = re.compile(r"^(?:[A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])")


def is_laptop_folder(folder) -> bool:
    """A Windows absolute path (C:\\... , C:/... or UNC) lives on Dean's laptop."""
    return isinstance(folder, str) and bool(_WINDOWS_ABS.match(folder.strip()))


def is_absolute_folder(folder) -> bool:
    """POSIX (/...) or Windows (C:\\...) absolute, independent of the host OS."""
    if not isinstance(folder, str) or not folder.strip():
        return False
    folder = folder.strip()
    return is_laptop_folder(folder) or (posixpath.isabs(folder) and not folder.startswith("//")) \
        or (ntpath.isabs(folder) and bool(ntpath.splitdrive(folder)[0]))


def path() -> Path:
    from brain import action_cues as ac
    return Path(ac.STATE_DIR) / "private_out" / "work_queue.json"


def load() -> list:
    p = path()
    try:
        if p.is_symlink():
            raise ValueError("work queue must not be a symlink")
        if hasattr(os, "geteuid"):  # POSIX: owned by Leon's user (root on the VPS)
            st = p.stat()
            if st.st_uid != os.geteuid() or st.st_mode & 0o022:
                raise ValueError("work queue must be owned by Leon's user and not group/world writable")
        data = json.loads(p.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    return list(data.get("entries", [])) if isinstance(data, dict) else []


def save(entries: list) -> None:
    p = path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp-%d" % os.getpid())
    tmp.write_text(json.dumps({"version": 1, "entries": entries}, indent=1), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, p)


def enqueue(goal, done_when, *, task, folder, provider, model, effort,
            execution_location="vps", entry_id=None, now=None):
    """Add one owner request. Provider/model/effort are stored and used exactly."""
    for name, value in (("goal", goal), ("done_when", done_when), ("task", task),
                        ("folder", folder), ("model", model), ("effort", effort)):
        if not isinstance(value, str) or not value.strip():
            raise ValueError("work queue entry needs " + name)
    if provider not in ("codex", "claude"):
        raise ValueError("explicit subscription provider required")
    if not is_absolute_folder(folder):
        raise ValueError("folder must be absolute (/... or C:\\...): %r" % folder)
    if is_laptop_folder(folder):
        execution_location = "laptop"  # a C:\ folder only exists on Dean's laptop
    reroute = None
    if execution_location == "vps":
        question = vps_catalog_question(provider, model)
        if question:
            if not LAPTOP_FALLBACK_FOLDER:
                return {"ok": False, "refused": True, "question": question}
            reroute = question
            execution_location, folder = "laptop", LAPTOP_FALLBACK_FOLDER
            task = task + "\n\n" + LAPTOP_REROUTE_NOTE
    with _lock:
        entries = load()
        eid = entry_id or "wq-" + hashlib.sha256(goal.encode()).hexdigest()[:12]
        existing = next((e for e in entries if e["id"] == eid), None)
        if existing:
            return existing
        entry = dict(id=eid, goal=goal, done_when=done_when, state="queued", job_id=None,
                     blocked_on="", resume_at=None, attempts={}, launches=0, task=task,
                     notes="", folder=folder, provider=provider, model=model, effort=effort,
                     execution_location=execution_location, created=now or time.time(),
                     history=[])
        if reroute:
            _note(entry, entry["created"], "auto-routed vps -> laptop: " + reroute)
        save(entries + [entry])
        return entry


def sync_owner_goals(now=None):
    """Enroll root-authored owner goals (owner-goal-plan.json) that carry done_when.

    The plan is the existing owner-request record (root-owned, Leon-only). Goals
    without done_when keep their old followthrough path, so nothing runs twice.
    Provider/model/effort/folder come from the plan exactly; paused or expired
    goals are not enrolled.
    """
    from brain import owner_goal_continuation as og
    added = []
    for goal in og.goals():
        gid, done_when = goal.get("id"), goal.get("done_when")
        if not isinstance(gid, str) or not isinstance(done_when, str) or goal.get("paused"):
            continue
        if (now or time.time()) >= float(goal.get("expires_at", 0)):
            continue
        step = (goal.get("steps") or [{}])[0]
        task = "%s\n\nObjective: %s\nNext step: %s" % (
            goal.get("owner_instruction", ""), goal.get("objective", ""), step.get("next_step", ""))
        try:
            added.append(enqueue(goal.get("objective") or gid, done_when, task=task,
                                 folder=step.get("folder") or "", provider=goal.get("provider"),
                                 model=goal.get("model") or "", effort=goal.get("effort") or "",
                                 execution_location=step.get("execution_location", "vps"),
                                 entry_id="goal-" + gid, now=now))
        except ValueError as exc:
            print("[WORK-QUEUE] owner goal %s not enrolled: %s" % (gid, exc), flush=True)
    return added


# -- ledger item 33a: goals are the queue ---------------------------------------
#
# Dean edits the ledger; nothing else does. This module only reads it. The
# ledger file was not in the job checkout, so its path is configurable and the
# format accepted is the numbered-item form the job text uses:
#     33a GOALS ARE THE QUEUE. First sentence is the goal. ...
#     Done when: <acceptance line>          (also "Acceptance:")
# An item is closed when its header carries DONE/CLOSED/SHIPPED/[x] or is
# struck through (~~...~~). A tag such as [priority:safety] overrides the
# keyword classifier.

LEDGER_PATH = os.environ.get("LEON_WORK_LEDGER") or str(
    Path(__file__).resolve().parents[1] / "LEDGER.md")
LEDGER_DEFAULTS = dict(folder=os.environ.get("LEON_LEDGER_FOLDER", "/opt/leon-brain"),
                       provider=os.environ.get("LEON_LEDGER_PROVIDER", "claude"),
                       model=os.environ.get("LEON_LEDGER_MODEL", ""),
                       effort=os.environ.get("LEON_LEDGER_EFFORT", ""))
PRIORITIES = {"safety": 0, "dean_blocking": 1, "customer": 2, "internal": 3}
OWNER_REQUEST_PRIORITY = PRIORITIES["dean_blocking"]  # Dean asked in chat: he is waiting on it
_ITEM = re.compile(r"^\s*(?:[-*]\s*)?(?:#+\s*)?(?:\*\*)?(?:item\s+)?(\d+[a-z]?)[.):]?(?:\*\*)?\s+(.+)$", re.I)
_ACCEPT = re.compile(r"^\s*(?:[-*]\s*)?(?:\*\*)?(?:done[ _]when|acceptance)(?:\*\*)?\s*:\s*(.+)$", re.I)
# Closed marker only at the start or end of the header: "... when SHIPPED, ..." stays open.
_CLOSED = re.compile(r"^[\W_]*(?:DONE|CLOSED|SHIPPED)\b|\b(?:DONE|CLOSED|SHIPPED)[\W_]*$|\[[xX]\]|^~~")  # capitals only
_TAG = re.compile(r"\[(?:priority:\s*)?(safety|dean[_-]blocking|customer|internal)\]", re.I)
_CLASS_WORDS = (
    ("safety", r"safety|secret|leak|credential|security|guard|data loss|wipe|unsafe|privacy"),
    ("dean_blocking", r"dean[- ]block|blocks dean|blocking dean|dean is waiting|dean can't|dean cannot|ask dean"),
    ("customer", r"customer|client|installer|checkout|refund|user-facing|public|release"),
)


def _first_sentence(text):
    m = re.match(r"(.+?[.!?])(?:\s|$)", text.strip())
    return (m.group(1) if m else text.strip())[:300]


def classify(text):
    """Priority class name: an explicit tag wins, else keyword heuristics."""
    tag = _TAG.search(text or "")
    if tag:
        return tag.group(1).lower().replace("-", "_")
    for name, words in _CLASS_WORDS:
        if re.search(words, text or "", re.I):
            return name
    return "internal"


def parse_ledger(text):
    """Ledger text -> [{id, goal, done_when, done_when_added, open, priority_class, order, body}]."""
    items, cur = [], None
    for line in (text or "").splitlines():
        m = _ITEM.match(line)
        if m and not _ACCEPT.match(line):
            cur = {"id": m.group(1).lower(), "header": m.group(2).strip(), "lines": [m.group(2)]}
            items.append(cur)
        elif cur is not None:
            cur["lines"].append(line)
    out = []
    for order, it in enumerate(items):
        body = "\n".join(it["lines"]).strip()
        header = re.sub(r"\[[^\]]*\]", "", it["header"]).strip(" ~*")
        accept = next((a.group(1).strip() for a in map(_ACCEPT.match, it["lines"]) if a), None)
        goal = _first_sentence(re.sub(r"\s+", " ", " ".join(
            l for l in it["lines"] if not _ACCEPT.match(l)).replace(it["header"], header, 1)))
        out.append(dict(id=it["id"], goal=goal,
                        done_when=accept or "The work for ledger item %s is committed with passing "
                                            "tests and the goal holds: %s" % (it["id"], goal),
                        done_when_added=accept is None,
                        open=not _CLOSED.search(it["header"]),
                        priority_class=classify(body), order=order, body=body[:4000]))
    return out


def read_ledger(ledger_path=None):
    p = Path(ledger_path or LEDGER_PATH)
    try:
        return p.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None


def sync_ledger(now=None, ledger_path=None):
    """Upsert open ledger items into the queue; never writes the ledger.

    Closed or vanished items are marked done/removed, never deleted. Runtime
    fields (state, attempts, job_id, notes, resume_note, history) are kept.
    Returns {added, updated, closed} ids, or None when there is no ledger.
    """
    text = read_ledger(ledger_path)
    if text is None:
        return None
    now = now or time.time()
    items = parse_ledger(text)
    seen = {}
    for it in items:  # a repeated number: the first occurrence wins
        seen.setdefault(it["id"], it)
    report = {"added": [], "updated": [], "closed": []}
    with _lock:
        entries = load()
        by_id = {e.get("ledger_id"): e for e in entries if e.get("ledger_id")}
        for lid, it in seen.items():
            e = by_id.get(lid)
            fields = dict(goal=it["goal"], done_when=it["done_when"],
                          done_when_added=it["done_when_added"], priority=PRIORITIES[it["priority_class"]],
                          priority_class=it["priority_class"], ledger_order=it["order"],
                          task="Ledger item %s:\n%s" % (lid, it["body"]))
            if e is None:
                if not it["open"]:
                    continue
                e = dict(id="ledger-" + lid, ledger_id=lid, state="queued", job_id=None, blocked_on="",
                         resume_at=None, attempts={}, launches=0, notes="", created=now, history=[],
                         execution_location="laptop" if is_laptop_folder(LEDGER_DEFAULTS["folder"]) else "vps",
                         **LEDGER_DEFAULTS)
                e.update(fields)
                _note(e, now, "added from ledger")
                entries.append(e)
                report["added"].append(lid)
                continue
            if any(e.get(k) != v for k, v in fields.items()):
                e.update(fields)
                report["updated"].append(lid)
            if it["open"] and e.get("state") == "removed":
                e["state"] = "queued"
                _note(e, now, "back in the ledger")
            elif not it["open"] and e.get("state") not in ("done", "running"):
                e.update(state="done", finished=now, resume_at=None)
                _note(e, now, "closed in the ledger")
                report["closed"].append(lid)
        for lid, e in by_id.items():
            if lid not in seen and e.get("state") not in ("done", "removed", "running"):
                e.update(state="removed", resume_at=None)
                _note(e, now, "no longer in the ledger")
                report["closed"].append(lid)
        _drop_stale_ranks(entries, [by_lid for by_lid in report["added"]], now)
        save(entries)
    return report


def _drop_stale_ranks(entries, added_lids, now):
    """A hand order never holds back a newer, higher-priority item.

    If an item just added from the ledger outranks (by priority class) any
    hand-ranked entry, the hand order is cleared and the priority rules apply.
    """
    ranked = [e for e in entries if "rank" in e]
    if not ranked or not added_lids:
        return
    new = [e for e in entries if e.get("ledger_id") in added_lids]
    best_new = min(e.get("priority", PRIORITIES["internal"]) for e in new)
    if any(e.get("priority", OWNER_REQUEST_PRIORITY) > best_new for e in ranked):
        for e in ranked:
            e.pop("rank", None)
            _note(e, now, "hand order cleared: higher-priority ledger item arrived")


def _order_key(indexed):
    i, e = indexed
    if "rank" in e:  # Leon reordered by hand: that order holds
        return (0, e["rank"], 0, i)
    pri = e.get("priority", OWNER_REQUEST_PRIORITY)
    return (1, pri, e.get("ledger_order", -1) if e.get("ledger_id") else -1, i)


def ordered(entries):
    """Entries in work order: (priority, ledger order); hand reorders first."""
    return [e for _, e in sorted(enumerate(entries), key=_order_key)]


def reorder(entry_id, position, reason, now=None):
    """Move a not-finished entry to position (0 = next) with a one-line reason in its notes."""
    if not isinstance(reason, str) or not reason.strip() or "\n" in reason.strip():
        raise ValueError("reorder needs a one-line reason")
    now = now or time.time()
    with _lock:
        entries = load()
        live = [e for e in ordered(entries) if e.get("state") in ("queued", "waiting", "running")]
        entry = next((e for e in live if e.get("id") == entry_id), None)
        if entry is None:
            return {"ok": False, "error": "no unfinished work queue entry: %s" % entry_id}
        live.remove(entry)
        live.insert(max(0, min(int(position), len(live))), entry)
        for rank, e in enumerate(live):
            e["rank"] = rank
        entry["notes"] = ((entry.get("notes") or "") + "\n[reordered to %d] %s" % (
            position, reason.strip()[:200])).strip()[-6000:]
        _note(entry, now, "reordered to %d: %s" % (position, reason.strip()[:200]))
        save(entries)
        return {"ok": True, "order": [e["id"] for e in live]}


# -- outside world: each is one call that tests replace ----------------------

def job_status(job_id):
    if not str(job_id).startswith("vps-"):
        return laptop_job_status(job_id)
    from server import native_jobs
    body = native_jobs.call("status", {"job_id": job_id})
    if body.get("ok") and body.get("job_id") == job_id:
        return body
    if body.get("error") == "no such job: " + job_id:
        return {"job_id": job_id, "state": "missing", "error": "job vanished from the queue"}
    raise RuntimeError("job lookup uncertain for %s; no relaunch" % job_id)


def job_text(job_id):
    try:
        from server import coding_jobs
        body = coding_jobs.job_result(job_id)
        return body.get("result") or body.get("error") or ""
    except Exception:
        return ""


def laptop_job_status(job_id):
    """A laptop job's state from the existing job feed; uncertain reads raise."""
    from server import coding_jobs
    body = coding_jobs.job_result(job_id)
    job = body.get("job") or {}
    if job.get("job_id") == job_id and job.get("state"):
        # The review verdict rides along: done + APPROVE is shipped (rule a).
        return {"job_id": job_id, "state": job["state"], "hermes": job.get("hermes") or {}}
    if "no such job" in str(body.get("error") or ""):
        return {"job_id": job_id, "state": "missing", "error": "job vanished from the queue"}
    raise RuntimeError("laptop job lookup uncertain for %s; no relaunch" % job_id)


def launch(entry, request_id, task):
    """Customer projects stay local; the original installation retains host routing."""
    from brain.origin import is_original
    if not is_original():
        from server import native_jobs
        if not native_jobs.enabled():
            return {"ok": False, "error": "Local customer coding is unavailable; no job launched."}
        return native_launch(entry, request_id, task)
    if is_laptop_folder(entry.get("folder")):
        return laptop_launch(entry, request_id, task)
    return native_launch(entry, request_id, task)


NATIVE_TOOLS = Path(__file__).resolve().parents[1] / "tools" / "native_jobs"


def _native_module(name):
    """Import a tools/native_jobs module; they import their siblings by bare name."""
    import importlib
    import sys
    if str(NATIVE_TOOLS) not in sys.path:
        sys.path.insert(0, str(NATIVE_TOOLS))
    return importlib.import_module(name)


def vps_catalog_question(provider, model):
    """None if model is in the VPS provider catalog the runner validates against,
    else a question for Dean naming the alternatives."""
    catalog = _native_module("provider_router").supported_catalog()
    models = [m.get("model") for m in (catalog.get(provider) or []) if isinstance(m, dict)]
    if model in models:
        return None
    options = ", ".join(m for m in models if m) or "none installed"
    return ("Model %s isn't in the VPS %s catalog, so a VPS job would be refused. "
            "Use one of: %s? Or run it with execution_location laptop?" % (model, provider, options))


LAPTOP_FALLBACK_FOLDER = os.environ.get("LEON_LAPTOP_FALLBACK_FOLDER", r"C:\Users\pazzo\item30\leon-brain")
LAPTOP_REROUTE_NOTE = ("NOTE: the VPS job catalog could not take this model, so this job was routed to the "
                       "laptop. Do any server steps over the brain's own shell, not from this job.")


def reroute_to_laptop(entry, now):
    """A VPS entry whose model the VPS catalog lacks runs on the laptop instead.

    Returns True when rerouted. Catalog read errors leave the entry alone.
    """
    if (entry.get("execution_location", "vps") != "vps" or is_laptop_folder(entry.get("folder"))
            or not LAPTOP_FALLBACK_FOLDER):
        return False
    try:
        question = vps_catalog_question(entry.get("provider"), entry.get("model"))
    except Exception:
        return False
    if not question:
        return False
    entry.update(execution_location="laptop", folder=LAPTOP_FALLBACK_FOLDER)
    if LAPTOP_REROUTE_NOTE not in entry.get("task", ""):
        entry["task"] = entry.get("task", "") + "\n\n" + LAPTOP_REROUTE_NOTE
    _note(entry, now, "auto-routed vps -> laptop: " + question)
    return True


LAPTOP_SSH_HOST = "laptop"  # /root/.ssh/config alias (owner_facts: always `ssh laptop`)
LAPTOP_PYTHON = r"C:\Program Files\Python311\python.exe"
LAPTOP_START_SCRIPT = "C:/Users/pazzo/LeonBridge/laptop_start_job.py"
LAPTOP_START_TIMEOUT_S = 120


def laptop_ssh_argv():
    """Remote shell is PowerShell: call the quoted exe with &; args go on stdin only."""
    return ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", LAPTOP_SSH_HOST,
            "&", "'%s'" % LAPTOP_PYTHON, "-I", LAPTOP_START_SCRIPT]


def laptop_launch(entry, request_id, task):
    """Make the LAPTOP run leon_jobs_mcp.start (the coding_job_start code) over ssh.

    The request marker lets an uncertain outcome be found again by task text.
    """
    import subprocess
    args = {"execution_location": "laptop", "folder": entry.get("folder"),
            "task": "[owner-request:%s] %s" % (request_id, task),
            "provider": entry.get("provider"), "model": entry.get("model"),
            "effort": entry.get("effort"), "project": entry.get("project")}
    payload = json.dumps({k: v for k, v in args.items() if v is not None})
    try:
        done = subprocess.run(laptop_ssh_argv(), input=payload, capture_output=True,
                              text=True, timeout=LAPTOP_START_TIMEOUT_S)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "laptop start timed out after %ss" % LAPTOP_START_TIMEOUT_S}
    except OSError as exc:
        return {"ok": False, "error": "ssh to laptop failed: %s" % exc}
    lines = [l for l in (done.stdout or "").lstrip("\ufeff").splitlines() if l.strip()]
    result = None
    if lines:
        try:
            result = json.loads(lines[-1])
        except ValueError:
            result = None
    if not isinstance(result, dict):
        detail = (done.stderr or "").strip() or (lines[-1] if lines else "no output")
        return {"ok": False, "error": "laptop start failed (exit %s): %s" % (done.returncode, detail[:500])}
    if done.returncode or not result.get("ok") or not result.get("job_id"):
        err = result.get("error") or (done.stderr or "").strip() or "no job_id returned"
        return {"ok": False, "error": "laptop start refused (exit %s): %s" % (done.returncode, str(err)[:500])}
    return result


def native_launch(entry, request_id, task):
    from server import native_jobs
    return native_jobs.call("start", {
        "request_id": request_id, "task": task, "folder": entry["folder"],
        "provider": entry["provider"], "model": entry["model"], "effort": entry["effort"],
        "execution_location": entry.get("execution_location", "vps")})


def followthrough_busy():
    """True while any coding job runs: a followthrough job, or any laptop/VPS job.

    One job at a time. An unreadable job list counts as busy (never launch blind).
    """
    from brain import action_cues as ac
    from brain import job_followthrough as ft
    if any(ft.managed(c) and c.get("status") == "running" for c in ac._load()):
        return True
    try:
        from server import coding_jobs
        body = coding_jobs.list_jobs(100)
    except Exception:
        return True
    if not body.get("ok"):
        return True
    return bool(body.get("running_count")) or any(
        j.get("state") in LIVE_JOB_STATES for j in body.get("jobs") or [])


def provider_reset(provider, now):
    """Reset time from the existing routing/limit evidence; None if not limited now."""
    try:
        from server.routers.workspaces import _provider_relay
        data = _provider_relay()
    except Exception:
        return None
    if provider == "codex":
        usage = data.get("codex") or {}
        if float(usage.get("used_percent") or 0) >= 100:
            return float(usage.get("resets_at") or 0) or None
        return None
    reset = float(data.get("claude_resets_at") or 0)
    return reset if reset > now else None


_SHIPPED_LINE = re.compile(r"^\W*SHIPPED\b", re.M)
_NOT_SHIPPED = re.compile(r"^\W*NOT SHIPPED\b", re.M)


def shipped(status, text):
    """Outcome shipped = job done AND (review APPROVE, or a SHIPPED status line
    with no NOT SHIPPED line). The old check only looked at the first 400
    characters, so results opening with a runner note ('[auto-resumed ...]')
    or carrying a free-text done_when were read as not shipped and relaunched."""
    if status.get("state") != "done":
        return False
    verdict = str((status.get("hermes") or {}).get("verdict") or status.get("verdict") or "").upper()
    if verdict == "APPROVE":
        return True
    text = text or ""
    return bool(_SHIPPED_LINE.search(text)) and not _NOT_SHIPPED.search(text)


def check_done(entry, text):
    """done_when forms: 'shipped', 'result_contains:<text>', 'path_exists:<path>'.

    Returns (passed, review_text). Unknown forms never pass.
    """
    rule = entry["done_when"].strip()
    head = (text or "").lstrip()[:400]
    if rule == "shipped":
        ok = head.upper().startswith("SHIPPED") or (
            bool(_SHIPPED_LINE.search(text or "")) and not _NOT_SHIPPED.search(text or ""))
        return ok, "" if ok else "Worker did not report SHIPPED: " + head[:300]
    if rule.startswith("result_contains:"):
        needle = rule.split(":", 1)[1].strip()
        ok = bool(needle) and needle in (text or "")
        return ok, "" if ok else "Result is missing the required evidence: " + needle
    if rule.startswith("path_exists:"):
        target = rule.split(":", 1)[1].strip()
        ok = bool(target) and os.path.exists(target)
        return ok, "" if ok else "Required output not found: " + target
    return False, "done_when check '%s' is not one Leon can verify" % rule


# -- the walk ----------------------------------------------------------------

def _note(entry, now, event):
    entry.setdefault("history", []).append({"t": now, "event": event[:300]})
    entry["history"] = entry["history"][-20:]


def _block(entry, now, question):
    entry.update(state="blocked", blocked_on=question, resume_at=None)
    _note(entry, now, "blocked: " + question)


def _question(entry, cause):
    goal = entry["goal"]
    if cause == "limit":
        return "'%s' hit the usage limit %d times. Keep waiting, or switch provider?" % (goal, MAX_ATTEMPTS)
    if cause == "launches":
        return "'%s' was launched %d times without finishing (%s). Try a different approach, or drop it?" % (
            goal, MAX_LAUNCHES, (entry.get("last_error") or entry.get("last_review") or "")[:160])
    if cause == "review":
        return "'%s' failed its done check twice (%s). What should done look like?" % (
            goal, (entry.get("last_review") or "")[:160])
    return "'%s' failed twice (%s). Should I try a different approach, or drop it?" % (
        goal, (entry.get("last_error") or "")[:160])


def _merge_notes(entry, text):
    notes = (entry.get("notes") or "") + "\n[previous attempt %s]\n%s" % (
        entry.get("job_id") or "-", (text or "")[:2000])
    return notes[-6000:]


def _resume_task(entry):
    if entry.get("resume_note"):
        # Leon's turn ended/was cut off with this work unfinished: act on the
        # note now, without Dean typing "continue". Consumed by this launch.
        entry["notes"] = ((entry.get("notes") or "") + "\n[turn stopped mid-work]\n"
                          + entry.pop("resume_note"))[-6000:]
    if not entry.get("notes"):
        return entry["task"]
    return ("%s\n\nRESUME: a previous attempt stopped. Continue from these notes; "
            "do not redo verified work.\n%s" % (entry["task"], entry["notes"]))


SILENT_S = 60


def _engine_silent(status, now):
    """True only when the runner is reported dead (alive is False, not unknown)
    AND the newest progress timestamp is at least SILENT_S old."""
    if status.get("alive") is not False:
        return False
    stamps = [status.get(k) for k in ("progress_at", "plan_mtime", "events_mtime", "updated")]
    stamps = [float(s) for s in stamps if isinstance(s, (int, float))]
    if not stamps:
        return False  # no evidence of quiet: leave it alone
    return now - max(stamps) >= SILENT_S


def _structured_note(entry, reply):
    """Resume note: WHAT, WHERE, NEXT STEP; capped at 2000 characters."""
    tail = (reply or "").strip()[-600:] or "(turn was cut off before a reply)"
    where = "job %s" % entry["job_id"] if entry.get("job_id") else "no live job"
    where += ", folder %s" % (entry.get("folder") or "-")
    note = "WHAT: %s\nWHERE: %s\nNEXT STEP: continue from: %s" % (
        (entry.get("goal") or entry.get("task") or "")[:600], where, tail)
    return note[:2000]


def _start(entry, now, task, why):
    """Launch one attempt. why is 'first', 'resume' or the failure cause being retried."""
    if not entry.get("model") or not entry.get("effort"):
        return _block(entry, now, "Which model and effort should '%s' use? None is saved." % entry["goal"])
    if followthrough_busy():
        # One job at a time across both systems: never launch beside an active
        # followthrough job. No attempt is counted; the next tick tries again.
        if entry.get("state") == "running":
            entry.update(state="waiting", resume_at=now, job_id=None)
        entry["waiting_for"] = "another coding job is running"
        entry["busy_wait"] = True  # not a Dean-worthy wait: no dashboard notice
        return
    entry.pop("busy_wait", None)
    if reroute_to_laptop(entry, now) and LAPTOP_REROUTE_NOTE not in task:
        task = task + "\n\n" + LAPTOP_REROUTE_NOTE
    if launch_count(entry) >= MAX_LAUNCHES:  # rule (b): 2 per entry, every cause
        entry.update(state="queued", job_id=None)
        return _block(entry, now, _question(entry, "launches"))
    rid = "%s-%d" % (entry["id"], int(entry.get("launches", 0)) + 1)
    try:
        body = launch(entry, rid, task)
    except Exception as exc:
        body = {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}
    entry["launches"] = int(entry.get("launches", 0)) + 1
    if body.get("ok") and is_laptop_folder(entry.get("folder")) and not body.get("job_id"):
        # Admitted but no id: never relaunch blind; Dean looks at the jobs board.
        entry.update(state="queued", job_id=None)
        return _block(entry, now, "The laptop accepted '%s' (request %s) but returned no job id. "
                                  "Is it running on the jobs board? Requeue only if not." % (entry["goal"], rid))
    if body.get("ok"):
        jid = body.get("job_id") or "vps-" + hashlib.sha256(rid.encode()).hexdigest()[:24]
        entry.update(state="running", job_id=jid, resume_at=None, blocked_on="",
                     started=now, current_task=task)
        _note(entry, now, "launched %s (%s)" % (jid, why))
        return
    entry.update(state="queued", job_id=None)
    _note(entry, now, "launch refused: " + str(body.get("error"))[:200])
    _failed(entry, now, "launch refused: " + str(body.get("error") or "unknown"))


def launch_count(entry):
    """Launches since Dean's last requeue, from the entry's own history."""
    events = entry.get("history") or []
    since = max((i for i, h in enumerate(events) if h.get("event") == "requeued by Dean"), default=-1)
    from_history = sum(1 for h in events[since + 1:] if str(h.get("event", "")).startswith(
        ("launched ", "launch refused")))
    # history is capped at 20 rows; the counter keeps the floor honest
    from_counter = int(entry.get("launches", 0)) - int(entry.get("launch_base", 0))
    return max(from_history, from_counter)


def _count(entry, cause):
    attempts = entry.setdefault("attempts", {})
    attempts[cause] = attempts.get(cause, 0) + 1
    return attempts[cause]


def _hosted_fallback(entry, now, text):
    """Claude/Codex are limited: continue this entry on the hosted OpenAI-compatible API (laptop folders only)
    instead of waiting for the reset (ledger item 36). Returns True when a hosted launch was started."""
    import os
    if os.environ.get("LEON_JOBS_HOSTED_FALLBACK", "1").strip() == "0":
        return False
    if entry.get("provider") == "hosted" or not is_laptop_folder(entry.get("folder")):
        return False
    try:
        from brain.providers import local_openai_adapter as lai
        if not lai.api_key_from_env("hosted"):
            return False
        model = (os.environ.get("LEON_HOSTED_AI_MODEL") or "").strip() or lai.DEFAULT_HOSTED_MODEL
    except Exception:
        return False
    # Job admission only knows claude/codex. Flipping an entry to "hosted" made
    # the laptop fall through to its own profile defaults, which launched a real
    # Codex job at high effort with a qwen model name (job 1020-144231-da78,
    # HTTP 400). Never hand a provider the runner cannot admit.
    try:
        coding_selection = _native_module("coding_selection")
        if "hosted" not in tuple(getattr(coding_selection, "PROVIDERS", ())):
            _note(entry, now, "hosted API cannot run coding jobs (admission knows only %s); waiting for the reset"
                  % ", ".join(getattr(coding_selection, "PROVIDERS", ())))
            return False
    except Exception:
        return False
    entry.update(hosted_fallback_from=entry.get("provider"), provider="hosted", model=model, effort="default")
    _note(entry, now, "provider limit: continuing on the hosted API (%s) instead of waiting for the reset" % model)
    _start(entry, now, _resume_task(entry), "limit")
    return True


def _failed(entry, now, text):
    """Route one failed attempt to its cause (entry is not running)."""
    entry["notes"] = _merge_notes(entry, text)
    if _LIMIT.search(text or ""):
        if _hosted_fallback(entry, now, text):
            return
        _count(entry, "limit")
        if launch_count(entry) >= MAX_LAUNCHES:
            return _block(entry, now, _question(entry, "limit"))
        reset = provider_reset(entry["provider"], now) or now + LIMIT_FALLBACK_S
        entry.update(state="waiting", resume_at=reset, job_id=None, blocked_on="",
                     waiting_for="usage limit; resumes %s" % time.strftime("%Y-%m-%d %H:%M", time.localtime(reset)))
        _note(entry, now, "usage limit; resume_at %s" % reset)
        return
    entry["last_error"] = (text or "unknown error")[:300]
    _count(entry, "error")  # kept for the board; the cap is launch_count (rule b)
    if launch_count(entry) >= MAX_LAUNCHES:
        return _block(entry, now, _question(entry, "error"))
    _start(entry, now, _resume_task(entry), "error")


def _advance(entry, now):
    """Move the active entry along. Uncertain job lookups raise (no relaunch)."""
    if entry["state"] == "waiting":
        if now < float(entry.get("resume_at") or 0):
            return
        reset = provider_reset(entry["provider"], now)
        if reset and reset > now:
            entry["resume_at"] = reset
            return
        _start(entry, now, _resume_task(entry), "resume")
        return
    status = job_status(entry["job_id"])
    state = status.get("state")
    if state in LIVE_JOB_STATES:
        if not _engine_silent(status, now):
            return
        # Item 33b: the job says live but its runner is gone and quiet for
        # 60 s. Resume from the notes; counts toward the 2-launch cap.
        entry["notes"] = _merge_notes(entry, _structured_note(
            entry, "engine went silent (runner gone, no progress for %ds)" % SILENT_S))
        _note(entry, now, "job %s engine silent; resuming" % entry["job_id"])
        _start(entry, now, _resume_task(entry), "silent")
        return
    lost_to_restart = entry.pop("boot_resume", False)
    if state == "missing" and lost_to_restart:
        # Case (a): the worker died with Leon's restart. Not a failure; resume
        # from the notes without touching any attempt budget.
        entry["restarts"] = int(entry.get("restarts", 0)) + 1
        entry["notes"] = _merge_notes(entry, "worker lost to Leon restart; continue from here")
        _note(entry, now, "job %s lost to restart; resuming" % entry["job_id"])
        _start(entry, now, _resume_task(entry), "restart")
        return
    text = (job_text(entry["job_id"]) if state != "missing" else "") or status.get("error") or ""
    if state != "done":
        _failed(entry, now, text or "job %s ended %s" % (entry["job_id"], state))
        return
    passed, review = check_done(entry, text)
    if not passed and shipped(status, text):
        # Rule (a), Dean 10-19: shipped (done + review APPROVE) is never NOT
        # SHIPPED and never relaunched. done_when that Leon can't check by
        # itself (free-text ledger acceptance) waits in verification.
        entry.update(state=VERIFYING, finished=now, blocked_on="", resume_at=None,
                     last_review=review)
        _note(entry, now, "job %s shipped; done_when verification pending" % entry["job_id"])
        return
    if passed:
        entry.update(state="done", finished=now, blocked_on="", resume_at=None)
        _note(entry, now, "done_when passed")
        return
    entry["last_review"] = review
    entry["notes"] = _merge_notes(entry, text)
    _count(entry, "review")
    if launch_count(entry) >= MAX_LAUNCHES:
        return _block(entry, now, _question(entry, "review"))
    _start(entry, now, "%s\n\nREVIEW BOUNCED: %s\nFix exactly this, then report.\n\nNotes:\n%s"
           % (entry["task"], review, entry["notes"]), "review")


def tick(now=None):
    """One walk of the queue, called from the existing action-cue watcher."""
    from brain import job_followthrough as ft
    if ft.stop_reason():
        return None
    # Dean 10-19 20:16: laptop RAM hold. Entries stay queued; nothing launches
    # until Dean says memory is back and this file is removed.
    if (Path(__file__).resolve().parent.parent / "brain_state" / "work_queue_hold").exists():
        return None
    now = now or time.time()
    with _lock:
        try:
            sync_owner_goals(now)
        except Exception as exc:
            print("[WORK-QUEUE] owner goal sync failed: %s: %s" % (type(exc).__name__, exc), flush=True)
        try:
            sync_ledger(now)
        except Exception as exc:  # a bad ledger never stops the current queue
            print("[WORK-QUEUE] ledger sync failed: %s: %s" % (type(exc).__name__, exc), flush=True)
        entries = load()
        if not entries:
            return None
        for _ in range(len(entries) + 1):
            active = next((e for e in entries if e.get("state") in ("running", "waiting")), None)
            if active:
                try:
                    _advance(active, now)
                    active.pop("lookup_error", None)
                except Exception as exc:
                    active["lookup_error"] = str(exc)[:240]
                    break
                if active.get("state") in ("running", "waiting"):
                    break
                continue  # finished or blocked: the next entry starts in this same tick
            nxt = next((e for e in ordered(entries) if e.get("state") == "queued"), None)
            if not nxt:
                break
            _start(nxt, now, _resume_task(nxt), "first" if not nxt.get("launches") else "resume")
            if nxt.get("state") in ("running", "waiting", "queued"):
                break
        _notify_changes(entries, now)
        save(entries)
        return snapshot(entries)


# -- Dean-facing notices, requeue, resume notes (ledger item 32) ---------------

NOTIFY_STATES = ("blocked", "waiting")


def notify_dean(text):
    """One dashboard line through the existing unsolicited-speech gate."""
    from server.helpers import broadcast_response
    return bool(broadcast_response(text, source="work_queue", user_label="(work queue)",
                                   audio=False, force=True))


BLOCKED_REPEAT_S = 24 * 3600  # item 33d: a blocked question repeats once a day


def should_notify(entry, now):
    """Item 33d, the single decision point: which event (if any) Dean hears now.

    Only four events reach Dean: started, finished, blocked, waiting. Each is
    sent once; a blocked entry repeats its question once every 24h. Every
    other state or repeated tick returns None.
    """
    state = entry.get("state")
    last = entry.get("notified_state")
    if state == "running":
        if last != "running" or entry.get("notified_job") != entry.get("job_id"):
            return "started"
        return None
    if state == "done":
        # only fresh finishes: old done entries never announce on upgrade
        if last != "done" and now - float(entry.get("finished") or 0) < BLOCKED_REPEAT_S:
            return "finished"
        return None
    if state == "blocked":
        if last != "blocked" or now - float(entry.get("notified_at") or 0) >= BLOCKED_REPEAT_S:
            return "blocked"
        return None
    if state == "waiting":
        if last != "waiting" and not entry.get("busy_wait"):
            return "waiting"
        return None
    return None


def _notice(entry, event=None):
    event = event or {"running": "started", "done": "finished"}.get(entry["state"], entry["state"])
    goal = entry.get("goal") or entry.get("id") or "unnamed entry"
    if event == "started":
        return "Work queue started: '%s' (job %s)." % (goal, entry.get("job_id") or "-")
    if event == "finished":
        return "Work queue finished: '%s' (job %s)." % (goal, entry.get("job_id") or "-")
    if event == "blocked":
        # goal, exact error and question always present (item 32 bug: never silent)
        return "Work queue blocked: '%s'. Error: %s. Question: %s" % (
            goal, entry.get("last_error") or entry.get("last_review") or "none recorded",
            entry.get("blocked_on") or "what should I do next?")
    return "Work queue waiting: '%s' (%s). Error: %s. Question: none; I resume on my own." % (
        goal, entry.get("waiting_for") or "waiting", entry.get("last_error") or "none")


def _notify_changes(entries, now):
    """Send the events should_notify picks; a failed send never breaks tick."""
    for entry in entries:
        event = should_notify(entry, now)
        if not event:
            continue
        try:
            sent = notify_dean(_notice(entry, event))
        except Exception as exc:
            sent = False
            print("[WORK-QUEUE] notice failed: %s: %s" % (type(exc).__name__, exc), flush=True)
        if sent:
            entry.update(notified_state=entry.get("state"), notified_job=entry.get("job_id"),
                         notified_at=now)
            _note(entry, now, "told Dean: " + event)


def requeue(entry_id, now=None):
    """Dean's reset: attempts, error and notice cleared, back to queued."""
    now = now or time.time()
    with _lock:
        entries = load()
        entry = next((e for e in entries if e.get("id") == entry_id), None)
        if entry is None:
            return {"ok": False, "error": "no such work queue entry: %s" % entry_id}
        if entry.get("state") == "running":
            return {"ok": False, "error": "entry is running; let its job finish first"}
        entry.update(state="queued", attempts={}, job_id=None, blocked_on="", resume_at=None,
                     last_error="", last_review="", notified_state=None, notified_at=None, notified_job=None,
                     lookup_error=None)
        entry.pop("busy_wait", None)
        entry["launch_base"] = int(entry.get("launches", 0))  # fresh 2-launch budget
        _note(entry, now, "requeued by Dean")
        save(entries)
        return {"ok": True, "id": entry_id, "state": "queued"}


def record_resume(note, entry_id=None, now=None):
    """Leon's turn ended or was cut off with owner work unfinished.

    Saves a resume note on that entry (default: the top unfinished one). The
    next tick launches it with the note; no "continue" from Dean.
    """
    now = now or time.time()
    with _lock:
        entries = load()
        entry = next((e for e in entries if (e.get("id") == entry_id if entry_id else
                      e.get("state") in ("running", "waiting", "queued"))), None)
        if entry is None or entry.get("state") in ("done", "blocked"):
            return None
        entry["resume_note"] = (note or "turn ended before the work finished")[:2000]
        if entry.get("state") == "waiting" and not str(entry.get("waiting_for") or "").startswith("usage limit"):
            entry["resume_at"] = now  # plain stop: the next tick resumes it
        if entry.get("state") == "running":
            # its live job keeps going; the note rides with the next attempt
            entry["boot_resume"] = True
        _note(entry, now, "resume note recorded")
        save(entries)
        return entry["id"]


EVIDENCE_QUOTE_MAX = 800


def add_evidence(quote, source="tool", entry_id=None, now=None):
    """Ledger item 33c: store quoted source output (git log, job record, systemd
    status, results file) in the active entry's notes as '[verified source X] ...'.

    Active entry = running, else waiting, else queued (or entry_id). Quote is
    capped and the notes keep the existing 6000-char cap. Returns the entry id.
    """
    now = now or time.time()
    quote = (quote or "").strip()
    if not quote:
        return None
    with _lock:
        entries = load()
        if entry_id:
            entry = next((e for e in entries if e.get("id") == entry_id), None)
        else:
            entry = None
            for st in ("running", "waiting", "queued"):
                entry = next((e for e in entries if e.get("state") == st), None)
                if entry:
                    break
        if entry is None or entry.get("state") in ("done", "blocked"):
            return None
        line = "\n[verified source %s] %s" % ((source or "tool")[:40], quote[:EVIDENCE_QUOTE_MAX])
        entry["notes"] = ((entry.get("notes") or "") + line)[-6000:]
        _note(entry, now, "evidence recorded: " + (source or "tool")[:40])
        save(entries)
        return entry["id"]


def on_turn_end(reply, now=None):
    """Called when any Leon turn ends (also cut-off ones, which end with no reply).

    If owner work is still unfinished and no job is carrying it, record a
    resume note so the next tick relaunches it. A running entry's job is left
    alone (it is still doing the work).
    """
    with _lock:
        entries = load()
        top = next((e for e in entries if e.get("state") in ("running", "waiting", "queued")), None)
    if top is None or top.get("state") == "running":
        return None
    return record_resume("Leon's turn ended with this work unfinished.\n" + _structured_note(top, reply),
                         entry_id=top["id"], now=now)


def boot(now=None):
    """After a self-restart: read the queue first and continue the top entry now.

    The entry's notes are its resume note; a waiting entry whose reset has
    passed relaunches with them, a queued one starts, a running one is
    reconciled against the real job status. Dean does not need to type continue.
    """
    now = now or time.time()
    with _lock:
        entries = load()
        top = next((e for e in entries if e.get("state") in ("running", "waiting", "queued")), None)
        if top is not None:
            _note(top, now, "boot: continuing from resume note")
            if top.get("state") == "running":
                top["boot_resume"] = True
            save(entries)
    print("[WORK-QUEUE] boot: %s" % (top["id"] if top else "empty"), flush=True)
    return tick(now)


def snapshot(entries=None):
    """Board view. State comes from the last real job lookup, never from a claim."""
    rows = entries if entries is not None else load()
    view = [{k: e.get(k) for k in ("id", "goal", "done_when", "state", "job_id", "blocked_on",
                                     "resume_at", "attempts", "lookup_error", "last_error")}
            for e in rows]
    for e in view:  # next time the tick will act on a waiting entry
        e["next_wake"] = e["resume_at"] if e["state"] == "waiting" else None
    counts = {}
    for e in view:
        counts[e["state"]] = counts.get(e["state"], 0) + 1
    return {"entries": view, "counts": counts}
