"""Per-call adapter to the installed speech queue; no owner, worker or store."""
import sys
import threading
import time
import uuid


def retire(owner):
    """Effect-free output fence; draining inference stays on the existing thread."""
    current = getattr(owner, '_speech_candidate', None)
    if current is not None:
        current.retired.set()


class candidate:
    def __init__(self, owner, prefix):
        self.owner = owner
        self.response_id = prefix + uuid.uuid4().hex
        self.queue = sys.modules.get('brain.voice.speech_queue')
        self.selected = bool(self.queue is not None and (
            self.queue.arbitration_active() or self.queue.admissions_frozen()))
        self.retired = threading.Event()
        self.turn = None
        self._claimed = False
        self._published = False
        self._eligible = False
        self._admission_attempted = False

    def __enter__(self):
        if not self.selected or self._stopped():
            return self
        if not self.owner._speech_candidate_lock.acquire(blocking=False):
            return self
        self._claimed = True
        previous = self.owner._speech_candidate
        if previous is not None and previous.turn is not None and not previous.retired.is_set():
            turn = previous.turn
            if not turn.cancelled.is_set() and (not turn.completed.is_set()
                    or time.monotonic() < turn.playback_until):
                return self
        self.owner._speech_candidate = self
        if self._stopped() or self.queue.admissions_frozen() or not self.queue.arbitration_active():
            return self
        self._eligible = True
        return self

    def admit(self):
        """Reserve audio only after local salience/context gates selected work."""
        if not self.selected or self.turn is not None:
            return self.current()
        if not self.current():
            return False
        self._admission_attempted = True
        try:
            self.turn = self.queue.start_response(self._synthesize, self.response_id,
                                                  self._send, priority=30)
            # Selection is latched. Losing the binding cannot choose inline TTS.
            if not self.turn.arbitration or self._stopped():
                self.retired.set()
        except Exception:
            self.retired.set()
        return self.current()

    def _stopped(self):
        stop = getattr(self.owner, '_stop', None)
        return self.retired.is_set() or (stop is not None and stop.is_set())

    def current(self):
        if self._stopped():
            return False
        if not self.selected:
            return True
        if self.turn is None:
            return (self._eligible and not self._admission_attempted
                    and self.queue.arbitration_active() and not self.queue.admissions_frozen())
        return bool(self.turn is not None and self.turn.arbitration
            and self.queue.arbitration_active() and self.queue.delivery_allowed(
                self.turn.event({'response_id': self.response_id})))

    def _synthesize(self, text, *, cancelled):
        if self._stopped() or cancelled():
            return None
        return self.owner.tts_for_text(text, cancelled=lambda: self._stopped() or cancelled())

    def _send(self, payload):
        # Cancellation frames must still clear an already-delivered generation.
        if payload.get('type') != 'brain_audio_cancel':
            if self._stopped() or not self.queue.arbitration_active():
                return
            if not self.queue.delivery_allowed(payload):
                return
        self.owner.notify(payload)

    def collect(self, selection, **kwargs):
        from brain import inference_narration
        if not self.admit():
            return ()
        if self.selected:
            original = kwargs.get('preflight')
            def preflight(request, token):
                self.turn.bind_interrupt(lambda: token.cancel('proactive_speech_interrupted'))
                if not self.current():
                    token.cancel('proactive_speech_retired')
                    return False
                return original(request, token) if original is not None else True
            kwargs['preflight'] = preflight
        events = inference_narration.collect(selection, **kwargs)
        return events if self.current() else ()

    def publish(self, text, sentences, *, user, model=None, **metadata):
        """Called only after narration and caller content filters have completed."""
        if not self.selected or not self.current():
            return False
        def send(payload):
            if not self.current():
                return False
            self._send(self.turn.event({'response_id': self.response_id, **payload}))
            return True
        if not send({'type': 'brain_response_start', 'user': user,
                     'from_proactive': True, **metadata}):
            return False
        if model is not None:
            if not send({'type': 'brain_response_model', 'model': model.model, 'tier': model.tier}):
                return False
        if not send({'type': 'brain_response_delta', 'text': text}):
            return False
        for index, sentence in enumerate(sentences):
            if not self.current():
                return False
            self.turn.submit(sentence, index)
        if not send({'type': 'brain_response_end', 'response': text, 'audio_pending': True}):
            return False
        self._published = True
        self.turn.finish()
        return True

    def __exit__(self, *error):
        try:
            if self.turn is not None and (error[0] is not None or not self._published or self._stopped()):
                self.retired.set()
                self.turn.cancel()
        finally:
            if self._claimed:
                self.owner._speech_candidate_lock.release()
