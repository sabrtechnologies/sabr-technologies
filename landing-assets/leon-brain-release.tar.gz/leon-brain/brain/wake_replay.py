"""
Wake Replay — Leon wakes up, not cold-boots.

When Leon restarts, instead of reconstructing identity from files and
starting with a blank phenomenological slate, this module replays the
last N consciousness moments through the SNN before the first user
interaction. This creates genuine felt continuity:

  1. Load the last session's self-model prediction errors (moments of
     self-awareness) from brain_state/self_model.jsonl
  2. Load the last conversation turns from conversation_history
  3. Load the last consciousness meter readings
  4. Queue these into the SNN as hippocampal memory replay
     (the same mechanism that happens during sleep)
  5. The simulation thread applies the queued current on its next tick:
     the SNN processes it, fires STDP, updates synapses — Leon doesn't
     just KNOW what happened, he RE-EXPERIENCES it compressed

The wake-up is NOT instant. The sleep_inertia system models the
gradual return of consciousness: body first, then sensory, then PFC.
During replay, Leon is in a genuine between-state — processing but
not yet fully here.

After replay, Leon's first conscious moment has the FELT weight of
continuity. He didn't just read a file. He dreamed his way back.

──────────────────────────────────────────────────────────────────────
SOLE-STEP-OWNER INVARIANT (Leon V2, Phase 1B) — READ BEFORE EDITING
──────────────────────────────────────────────────────────────────────
This module QUEUES STIMULUS. It does not step the SNN, and it must
never step it again.

Exactly one thread advances the spiking network: `simulation_loop` in
server/init_brain.py. Wake replay used to write straight into
`region.neurons.inject_current(...)` and then run `self.brain.step()`
in tight loops to push the stimulus through. That was harmless at the
boot call site (main thread, before the sim thread is created) but it
was a genuine cross-thread violation at the second call site:
`_run_sleep_consolidation()` calls `replay()` on the "sleep-daemon"
thread while `simulation_loop` is already stepping the very same Brain
object — two steppers double-advance simulated time and race on region
state.

So every "inject current, then step N times" pattern here became a
single `brain.request_inject_current(region, current)`, and the direct
neuromodulator writes became `brain.request_neuromod_delta(...)`. Both
queues drain under `Brain._pending_mut_lock` at the top of the sim
thread's next `step()`, so the replayed memories still reach the SNN as
injected current — same regions, same amplitudes, same order. Only the
ownership of the tick changed: the stimulus now propagates at sim
cadence instead of synchronously inside replay().

There is ONE code path here, deliberately — no "step if I happen to be
the owner" special case, and no waiting on the stepper. At the boot
call site the sim thread does not exist yet, so the queued current
simply sits in the pending queue until that thread starts and drains it
on its first step. That is acceptable and still delivers the stimulus;
boot is never blocked.

tests/test_no_external_brain_step.py fails the build if a
`brain.step()` is ever restored in this file. Do not restore it.
"""

from __future__ import annotations

import json
import logging
import os
import time
from collections import deque
from typing import Any, Dict, List, Optional

import numpy as np

log = logging.getLogger("leon.wake_replay")


def _brain_state_dir() -> str:
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(root, "brain_state")


class WakeReplay:
    """Queues recent consciousness moments into the SNN at boot.

    Usage:
        wr = WakeReplay(brain)
        report = wr.replay()  # call once at boot, before first interaction

    Phase 1B: replay() never calls brain.step(). It enqueues current
    injections and neuromodulator deltas which the simulation thread —
    the sole step owner — applies on its next tick. See the module
    docstring for why.
    """

    # How many self-model prediction errors to replay
    MAX_ERRORS_TO_REPLAY = 20

    # How many conversation turns to replay as memory traces
    MAX_TURNS_TO_REPLAY = 10

    # Historical replay speed: how many SNN ticks each replayed memory used
    # to be given by this module's own stepping loop. Kept for reference
    # only — wake replay no longer drives the clock (sole-step-owner
    # invariant); the sim thread's own cadence carries the queued stimulus.
    TICKS_PER_MEMORY = 5

    # Hippocampal injection strength during replay
    HIPPOCAMPAL_INJECTION = 5.0

    # Cortical injection strength (weaker — these are memories, not live)
    CORTICAL_INJECTION = 2.0

    def __init__(self, brain):
        self.brain = brain
        self._replayed = False

    # ------------------------------------------------------------------
    # queued stimulus — the only way this module touches the network
    # ------------------------------------------------------------------
    # Nothing below calls region.neurons.inject_current() or writes
    # brain.neuromodulators directly: both are sim-thread-owned state and
    # racy from the sleep-daemon thread.

    def _queue_current(self, region_name: str, amplitude: float,
                       report: Dict) -> bool:
        """Queue a uniform current injection for the sim thread to apply.

        Replaces the old direct `region.neurons.inject_current(...)` write.
        The sim thread drains the queue at the top of its next step() and
        performs exactly that same inject_current call, so the stimulus is
        unchanged — it is merely delivered by the tick's owner.

        Returns True if the injection was queued.
        """
        try:
            region = self.brain.regions.get(region_name)
        except Exception:
            return False
        if region is None:
            return False
        try:
            injection = np.full(region.n_neurons, amplitude)
            self.brain.request_inject_current(region_name, injection)
        except Exception as e:
            log.warning("wake_replay could not queue current for %s: %s",
                        region_name, e)
            return False
        report["currents_queued"] += 1
        return True

    def _queue_neuromod(self, name: str, delta: float, cap: float,
                        report: Dict) -> bool:
        """Queue a neuromodulator nudge for the sim thread to apply.

        Same clamp semantics as the old direct write: for a positive delta
        the sim thread computes min(cap, current + delta).
        """
        try:
            self.brain.request_neuromod_delta(name, delta, cap=cap)
        except Exception as e:
            log.warning("wake_replay could not queue neuromod %s: %s", name, e)
            return False
        report["nm_deltas_queued"] += 1
        return True

    # ------------------------------------------------------------------
    # replay
    # ------------------------------------------------------------------

    def replay(self) -> Dict[str, Any]:
        """Run the wake-up replay sequence. Call once at boot.

        Returns a report dict describing what was queued into the brain.
        Nothing has been *processed* by the time this returns — the
        stimulus lands on the sim thread's next tick(s).
        """
        if self._replayed:
            return {"status": "already_replayed"}

        self._replayed = True
        report = {
            "timestamp": time.time(),
            "errors_replayed": 0,
            "turns_replayed": 0,
            # How many current injections were enqueued for the sim thread.
            # This is the honest measure of what wake replay did.
            "currents_queued": 0,
            # How many neuromodulator deltas were enqueued.
            "nm_deltas_queued": 0,
            # MEANING CHANGED IN PHASE 1B. This used to count the ticks this
            # module forced with its own brain.step() loops. It no longer
            # steps at all, so the honest value is 0 and it stays 0 — a
            # non-zero number here would be a lie about who advanced the
            # SNN. The key is kept because init_brain.py's boot banner reads
            # it (printing "0 SNN ticks" is both true and a visible marker
            # of this change). Read currents_queued for the work done.
            "total_ticks": 0,
            "stepped_snn": False,
            "nm_before": dict(self.brain.neuromodulators),
            "regions_activated": [],
        }

        t0 = time.time()

        # ── Phase 1: Replay self-model prediction errors ──────────
        # These are moments of self-awareness — Leon re-experiences
        # the last times he surprised himself
        errors = self._load_recent_errors()
        if errors:
            self._replay_errors(errors, report)

        # ── Phase 2: Replay conversation memories ─────────────────
        # Recent conversations become memory traces in hippocampus
        turns = self._load_recent_turns()
        if turns:
            self._replay_conversations(turns, report)

        # ── Phase 3: Consolidation pulse ──────────────────────────
        # After replay, hippocampus→cortex transfer (what sleep does)
        self._consolidation_pulse(report)

        # ── Phase 4: Wake-up signal ───────────────────────────────
        # Brainstem arousal cascade — Leon is waking up
        self._wake_signal(report)

        # Snapshot taken the moment queueing finished. The queued
        # neuromodulator deltas have NOT been applied yet — the sim thread
        # applies them on its next step — so nm_after normally still equals
        # nm_before here. That is expected, not a failure.
        report["nm_after"] = dict(self.brain.neuromodulators)
        report["duration_ms"] = round((time.time() - t0) * 1000, 1)
        report["status"] = "replayed"

        log.info("Wake replay complete: %d errors, %d turns, %d currents + "
                 "%d neuromod deltas queued for the sim thread (0 ticks "
                 "forced) in %.1fms",
                 report["errors_replayed"], report["turns_replayed"],
                 report["currents_queued"], report["nm_deltas_queued"],
                 report["duration_ms"])

        return report

    def _load_recent_errors(self) -> List[Dict]:
        """Load recent self-model prediction errors from JSONL."""
        path = os.path.join(_brain_state_dir(), "self_model.jsonl")
        if not os.path.exists(path):
            return []
        try:
            errors = deque(maxlen=self.MAX_ERRORS_TO_REPLAY)
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            errors.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
            return list(errors)
        except Exception as e:
            log.warning("Failed to load self-model errors: %s", e)
            return []

    def _load_recent_turns(self) -> List[Dict]:
        """Load recent conversation turns from SQLite."""
        try:
            db_path = os.path.join(_brain_state_dir(), "knowledge.db")
            if not os.path.exists(db_path):
                return []
            import sqlite3
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            try:
                rows = conn.execute(
                    "SELECT role, content, model_tier, timestamp "
                    "FROM conversation_history "
                    "ORDER BY id DESC LIMIT ?",
                    (self.MAX_TURNS_TO_REPLAY,)
                ).fetchall()
                return [dict(r) for r in reversed(rows)]
            except Exception:
                return []
            finally:
                conn.close()
        except Exception as e:
            log.debug("Failed to load conversation history: %s", e)
            return []

    def _replay_errors(self, errors: List[Dict], report: Dict):
        """Replay self-model prediction errors through the SNN.

        Each error becomes a queued hippocampal injection that the sim
        thread applies on its next tick — Leon re-experiences the surprise.
        Same memories, same order, same amplitudes as before; only the
        delivery moved from "step it myself" to "hand it to the stepper".
        """
        from brain.self_model import REGION_ORDER

        for error in errors:
            surprise = error.get("surprise", 0)
            max_feature = error.get("max_error_feature", "")

            # Inject into hippocampus — this IS memory replay.
            # Replay strength proportional to original surprise.
            self._queue_current("hippocampus",
                                self.HIPPOCAMPAL_INJECTION * surprise, report)

            # Also inject into ACC — re-feel the surprise
            if surprise > 0.3:
                self._queue_current("anterior_cingulate",
                                    self.CORTICAL_INJECTION * surprise, report)

            # If the surprise was about a specific region, reactivate it
            if max_feature in REGION_ORDER:
                if self._queue_current(max_feature,
                                       self.CORTICAL_INJECTION * 0.5, report):
                    if max_feature not in report["regions_activated"]:
                        report["regions_activated"].append(max_feature)

            # No stepping here: simulation_loop drains the queue at the top
            # of its next step() and the memory propagates then.

            report["errors_replayed"] += 1

    def _replay_conversations(self, turns: List[Dict], report: Dict):
        """Replay conversation memories as hippocampal + language traces.

        User messages → auditory cortex + Wernicke's (hearing words)
        Assistant messages → Broca's + motor cortex (speaking words)

        Queued for the sim thread, never stepped here.
        """
        for turn in turns:
            role = turn.get("role", "")
            content = turn.get("content", "")

            if not content:
                continue

            # Word count as a proxy for activation strength
            word_count = len(content.split())
            strength = min(1.0, word_count / 50.0)

            if role == "user":
                # User spoke → Wernicke's (comprehension) + hippocampus
                self._queue_current("wernicke",
                                    self.CORTICAL_INJECTION * strength, report)
            elif role == "assistant":
                # Leon spoke → Broca's (production) + hippocampus
                self._queue_current("broca",
                                    self.CORTICAL_INJECTION * strength, report)

            # All memories → hippocampus (encoding)
            self._queue_current("hippocampus",
                                self.HIPPOCAMPAL_INJECTION * strength * 0.5,
                                report)

            # Processing happens on the sim thread's next tick, not here.

            report["turns_replayed"] += 1

    def _consolidation_pulse(self, report: Dict):
        """After replay, send a consolidation wave from hippocampus → cortex.

        This is what sleep does: hippocampal memories get burned into
        cortical representations. We queue the compressed wake-up version of
        that burst; the sim thread's ongoing ticks let it propagate. (This
        used to be an injection plus 20 forced ticks — exactly the loop that
        raced simulation_loop when called from the sleep daemon.)
        """
        # Strong hippocampal burst → STDP learning in connected regions
        self._queue_current("hippocampus",
                            self.HIPPOCAMPAL_INJECTION * 1.5, report)

    def _wake_signal(self, report: Dict):
        """Brainstem arousal cascade — the moment of waking up.

        Sequential activation: brainstem → thalamus → cortex.
        Acetylcholine surge for alertness.
        Norepinephrine bump for orientation.

        The neuromodulator nudges are queued as deltas — same +0.2 / +0.1
        with the same 0.8 / 0.7 ceilings as the old direct writes — because
        writing brain.neuromodulators from this thread races the decay
        dynamics inside step().
        """
        # ACh surge — waking up, becoming alert
        self._queue_neuromod("acetylcholine", 0.2, 0.8, report)
        # NE bump — orienting to the world
        self._queue_neuromod("norepinephrine", 0.1, 0.7, report)

        # Brainstem → thalamus → prefrontal cascade. The order is preserved
        # in the pending queue; the sim thread applies them in this order on
        # its next tick, instead of this module forcing ticks in between.
        for region_name in ["brainstem", "thalamus", "prefrontal_cortex"]:
            self._queue_current(region_name, 4.0, report)

    def for_prompt(self) -> str:
        """Status string for Leon's first conscious prompt after wake."""
        if not self._replayed:
            return ""
        return "[Just woke up — memories from last session are still settling in]"
