"""Presence / awareness layer — desktop notifications, dashboard feed,
audio cues, voice tone, idle detection. The "JARVIS feel" surface.

Tools dispatch in-process (brain-local). Some shell out to notify-send,
paplay, ffplay, etc. — failures are degraded silently rather than blocking.

Tools:
  - presence.dashboard_event       push a structured event to the WS feed
  - presence.desktop_notify        notify-send wrapper with urgency levels
  - presence.play_chime            play one of a fixed set of audio cues
  - presence.tts_say               speak a string via the existing TTS engine
  - presence.voice_tone_set        set tone preset (formal/casual/urgent/quiet)
  - presence.voice_tone_get        return the current tone preset
  - presence.idle_check            seconds since last X11 input event
  - presence.is_dean_present       webcam-based "is anyone there" check
  - presence.set_status_message    publish a status string for the dashboard
  - presence.dashboard_log_recent  read recent dashboard feed events
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional


# ── Module state ───────────────────────────────────────────────────────
# In-memory ring buffer of dashboard events. The dashboard WS subscriber
# polls /api/presence/recent at low frequency or we push via the existing
# WebSocket channel. For now we keep an in-memory log + persist to disk
# so the dashboard can read it on reconnect.
_EVENT_RING: Deque[Dict[str, Any]] = deque(maxlen=200)
_EVENT_LOCK = threading.RLock()

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_STATE_DIR.mkdir(exist_ok=True)
_EVENT_LOG = _STATE_DIR / "presence-feed.jsonl"
_STATUS_FILE = _STATE_DIR / "presence-status.json"
_VOICE_TONE_FILE = _STATE_DIR / "voice-tone.json"

_DEFAULT_TONE = "casual"
_VALID_TONES = {"formal", "casual", "urgent", "quiet", "playful"}


def _now() -> float:
    return time.time()


def _broadcast_ws(event: Dict[str, Any]) -> None:
    """Best-effort push to the dashboard WebSocket. If the dashboard module
    isn't importable in this context, we just skip — the event is still in
    the ring buffer and persisted to disk."""
    try:
        # The server exposes a broadcast helper at server._broadcast_event
        # if present; otherwise we just persist.
        import server  # noqa
        broadcaster = getattr(server, "_broadcast_event", None)
        if callable(broadcaster):
            broadcaster(event)
    except Exception:
        pass


def _append_log(event: Dict[str, Any]) -> None:
    try:
        with _EVENT_LOG.open("a") as f:
            f.write(json.dumps(event) + "\n")
    except OSError:
        pass


# ── Tools ──────────────────────────────────────────────────────────────
def _dashboard_event(args: Dict[str, Any]) -> Dict[str, Any]:
    """Push a structured event into the dashboard observation feed.

    Args:
      kind: 'observation' | 'action' | 'thought' | 'alert' | 'success' | 'error' (required)
      message: short human-readable message (required)
      detail: optional longer detail string
      icon: optional emoji to display alongside
      severity: 'info' | 'warn' | 'error' (default: info)
    """
    kind = args.get("kind")
    msg = args.get("message")
    if not kind or not msg:
        return {"ok": False, "error": "kind and message are required"}
    event = {
        "ts": _now(),
        "kind": kind,
        "message": str(msg)[:500],
        "detail": (args.get("detail") or "")[:2000],
        "icon": args.get("icon"),
        "severity": args.get("severity", "info"),
    }
    with _EVENT_LOCK:
        _EVENT_RING.append(event)
    _append_log(event)
    _broadcast_ws({"type": "presence_event", "event": event})
    return {"ok": True, "event": event}


def _dashboard_log_recent(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return recent dashboard events from the ring buffer.

    Args:
      limit: how many recent events (default 20, max 200)
      kind: optional filter by kind
    """
    limit = min(200, max(1, int(args.get("limit", 20))))
    kind = args.get("kind")
    with _EVENT_LOCK:
        events = list(_EVENT_RING)
    # If the in-process ring is thin (e.g. the REST endpoint runs in a
    # different worker than the writer), backfill from the durable JSONL.
    if len(events) < limit and _EVENT_LOG.exists():
        try:
            seen_ts = {e.get("ts") for e in events}
            disk = []
            for line in _EVENT_LOG.read_text().strip().split("\n")[-(limit * 3):]:
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                if e.get("ts") not in seen_ts:
                    disk.append(e)
            events = (disk + events)
            events.sort(key=lambda e: e.get("ts", 0))
        except OSError:
            pass
    if kind:
        events = [e for e in events if e.get("kind") == kind]
    return {"ok": True, "events": events[-limit:], "count": len(events[-limit:])}


def _desktop_notify(args: Dict[str, Any]) -> Dict[str, Any]:
    """Show a desktop notification via notify-send.

    Args:
      title: notification title (required)
      message: body (default: '')
      urgency: 'low' | 'normal' | 'critical' (default: normal)
      icon: notification icon name (e.g. 'dialog-information')
      timeout_ms: auto-dismiss after N ms (default: 5000)
    """
    title = args.get("title")
    if not title:
        return {"ok": False, "error": "title is required"}
    from brain.identity import brand
    title = brand(title)
    message = args.get("message", "")
    urgency = args.get("urgency", "normal")
    if urgency not in ("low", "normal", "critical"):
        urgency = "normal"
    icon = args.get("icon")
    timeout = int(args.get("timeout_ms", 5000))
    # notify-send is Linux-only. On a customer's Mac or Windows box this raised
    # FileNotFoundError, which the caller swallowed — so every reminder, routine
    # check-in and "the SI wants your attention" cue was silently inert. No
    # error the owner ever saw. The notification simply never appeared.
    if sys.platform == "darwin":
        return _notify_macos(title, message)
    if _is_windows():
        return _notify_windows(title, message)

    cmd = ["notify-send", "-u", urgency, "-t", str(timeout)]
    if icon:
        cmd += ["-i", icon]
    cmd += [title, message]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=5,
                            env={**os.environ, "DISPLAY": os.environ.get("DISPLAY", ":0")})
        return {"ok": r.returncode == 0, "stderr": r.stderr.strip() or None}
    except FileNotFoundError:
        return {"ok": False, "error": "notify-send not installed"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "notify-send timed out"}


def _osa_quote(text: str) -> str:
    """Escape a string for embedding in an AppleScript double-quoted literal.
    Without this, an SI whose owner writes a message containing a quote gets a
    syntax error instead of a notification — and a backslash-heavy message
    could smuggle arbitrary AppleScript into the osascript call."""
    return str(text).replace("\\", "\\\\").replace('"', '\\"')


def _notify_macos(title: str, message: str) -> Dict[str, Any]:
    script = (f'display notification "{_osa_quote(message)}" '
              f'with title "{_osa_quote(title)}"')
    try:
        r = subprocess.run(["osascript", "-e", script],
                           capture_output=True, text=True, timeout=5)
        return {"ok": r.returncode == 0, "backend": "osascript",
                "stderr": r.stderr.strip() or None}
    except FileNotFoundError:
        return {"ok": False, "error": "osascript not found"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "osascript timed out"}


def _notify_windows(title: str, message: str) -> Dict[str, Any]:
    """Toast via WinRT, falling back to a tray balloon.

    The toast is the native Windows 10/11 notification. It can be refused on
    locked-down or older builds, so the balloon (WinForms NotifyIcon, present
    since forever) is the backstop — better a slightly dated-looking popup than
    a reminder the owner never receives.
    """
    # Single-quoted PowerShell literals: '' is the escape for a quote.
    t = str(title).replace("'", "''")
    m = str(message).replace("'", "''")
    toast = (
        "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications,"
        " ContentType=WindowsRuntime] > $null;"
        "$x = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent("
        "[Windows.UI.Notifications.ToastTemplateType]::ToastText02);"
        "$n = $x.GetElementsByTagName('text');"
        f"$n.Item(0).AppendChild($x.CreateTextNode('{t}')) > $null;"
        f"$n.Item(1).AppendChild($x.CreateTextNode('{m}')) > $null;"
        "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("
        "'Sabr.SI').Show([Windows.UI.Notifications.ToastNotification]::new($x))"
    )
    balloon = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$b = New-Object System.Windows.Forms.NotifyIcon;"
        "$b.Icon = [System.Drawing.SystemIcons]::Information;"
        "$b.Visible = $true;"
        f"$b.ShowBalloonTip(5000, '{t}', '{m}',"
        " [System.Windows.Forms.ToolTipIcon]::Info);"
        "Start-Sleep -Seconds 6; $b.Dispose()"
    )
    for label, script in (("toast", toast), ("balloon", balloon)):
        try:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                 "-Command", script],
                capture_output=True, text=True, timeout=15)
            if r.returncode == 0:
                return {"ok": True, "backend": label}
        except FileNotFoundError:
            return {"ok": False, "error": "powershell not found"}
        except subprocess.TimeoutExpired:
            continue
    return {"ok": False, "error": "toast and balloon both failed"}


# Audio chime mapping
# Every one of these used to be a Linux freedesktop path, so on a customer's
# Mac or Windows box the chime returned "chime file missing" and the SI's
# attention cues were silently inert — no error the owner ever saw, the sound
# just never happened. Each OS ships its own stock sounds; use them.
_CHIME_FILES_LINUX = {
    "success": "/usr/share/sounds/freedesktop/stereo/complete.oga",
    "error":   "/usr/share/sounds/freedesktop/stereo/dialog-error.oga",
    "notify":  "/usr/share/sounds/freedesktop/stereo/message-new-instant.oga",
    "alert":   "/usr/share/sounds/freedesktop/stereo/alarm-clock-elapsed.oga",
    "bell":    "/usr/share/sounds/freedesktop/stereo/bell.oga",
}
_CHIME_FILES_DARWIN = {
    "success": "/System/Library/Sounds/Glass.aiff",
    "error":   "/System/Library/Sounds/Basso.aiff",
    "notify":  "/System/Library/Sounds/Ping.aiff",
    "alert":   "/System/Library/Sounds/Sosumi.aiff",
    "bell":    "/System/Library/Sounds/Tink.aiff",
}
_CHIME_FILES_WINDOWS = {
    "success": r"C:\Windows\Media\Windows Notify System Generic.wav",
    "error":   r"C:\Windows\Media\Windows Critical Stop.wav",
    "notify":  r"C:\Windows\Media\Windows Notify Messaging.wav",
    "alert":   r"C:\Windows\Media\Windows Exclamation.wav",
    "bell":    r"C:\Windows\Media\Windows Ding.wav",
}


def _is_windows() -> bool:
    """sys.platform, not os.name — os.name is what a stray monkeypatch or an
    embedded interpreter is most likely to lie about, and a wrong answer here
    means the owner silently gets no sound and no notification."""
    return sys.platform.startswith("win")


def _chime_files():
    if sys.platform == "darwin":
        return _CHIME_FILES_DARWIN
    if _is_windows():
        return _CHIME_FILES_WINDOWS
    return _CHIME_FILES_LINUX


# Kept as a name so existing callers/tests that reference the cue set still work.
_CHIME_FILES = _chime_files()


def _play_chime(args: Dict[str, Any]) -> Dict[str, Any]:
    """Play one of a fixed set of audio cues.

    Args:
      cue: 'success' | 'error' | 'notify' | 'alert' | 'bell' (required)
      volume: 0.0-1.0 (default 0.7)
    """
    cue = args.get("cue")
    chimes = _chime_files()
    if cue not in chimes:
        return {"ok": False, "error": f"cue must be one of {sorted(chimes.keys())}"}
    path = chimes[cue]
    if not Path(path).exists():
        return {"ok": False, "error": f"chime file missing: {path}"}
    # Player order per OS. afplay ships with every Mac; PowerShell's SoundPlayer
    # ships with every Windows — neither needs anything installed, which matters
    # because ffmpeg is NOT a given on a customer machine.
    if sys.platform == "darwin":
        players = (["afplay", path],
                   ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path])
    elif _is_windows():
        players = (["powershell", "-NoProfile", "-Command",
                    f"(New-Object Media.SoundPlayer '{path}').PlaySync()"],
                   ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path])
    else:
        players = (["paplay", path],
                   ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", path],
                   ["aplay", "-q", path])
    for cmd_base in players:
        try:
            subprocess.Popen(cmd_base, stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL,
                              start_new_session=True)
            return {"ok": True, "cue": cue, "tool": cmd_base[0]}
        except FileNotFoundError:
            continue
    return {"ok": False,
            "error": "no audio player found (tried: "
                     + ", ".join(c[0] for c in players) + ")"}


def _tts_say(args: Dict[str, Any]) -> Dict[str, Any]:
    """Speak a string via Leon's existing TTS engine (Piper, or ElevenLabs
    if configured). Bypasses the responder — useful for routines and
    direct presence prompts.

    Args:
      text: string to speak (required, max 500 chars)
      voice: optional voice override
      block: wait for completion before returning (default: False)
    """
    text = args.get("text")
    if not text:
        return {"ok": False, "error": "text is required"}
    text = str(text)[:500]
    # Personalize any hardcoded owner names or honorifics for this install
    try:
        from brain.identity import personalize
        text = personalize(text)
    except Exception:
        pass
    block = bool(args.get("block", False))

    # Try the existing voice pipeline
    try:
        from brain.voice.tts import speak as _speak
    except Exception:
        try:
            from brain.voice.pipeline import VoicePipeline  # type: ignore
            _speak = None
        except Exception:
            _speak = None
    if _speak is None:
        return {"ok": False, "error": "TTS pipeline not importable"}

    def _do():
        try:
            _speak(text)
        except Exception:
            pass

    if block:
        _do()
    else:
        threading.Thread(target=_do, daemon=True).start()
    return {"ok": True, "spoken": text[:120], "blocking": block}


def _voice_tone_set(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set Leon's spoken tone preset.

    Args:
      tone: one of 'formal','casual','urgent','quiet','playful' (required)
    """
    tone = args.get("tone")
    if tone not in _VALID_TONES:
        return {"ok": False, "error": f"tone must be one of {sorted(_VALID_TONES)}"}
    payload = {"tone": tone, "set_at": _now()}
    try:
        _VOICE_TONE_FILE.write_text(json.dumps(payload))
    except OSError as e:
        return {"ok": False, "error": str(e)}
    return {"ok": True, "tone": tone}


def _voice_tone_get(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return the currently-set voice tone preset (default if unset)."""
    try:
        data = json.loads(_VOICE_TONE_FILE.read_text())
        tone = data.get("tone", _DEFAULT_TONE)
        return {"ok": True, "tone": tone, "set_at": data.get("set_at")}
    except (OSError, json.JSONDecodeError):
        return {"ok": True, "tone": _DEFAULT_TONE, "set_at": None}


def _idle_check(args: Dict[str, Any]) -> Dict[str, Any]:
    """Seconds since last X11 input event (mouse/keyboard).

    Uses `xprintidle`. If not installed, returns ok=False.
    """
    try:
        r = subprocess.run(
            ["xprintidle"],
            capture_output=True, text=True, timeout=3,
            env={**os.environ, "DISPLAY": os.environ.get("DISPLAY", ":0")},
        )
        if r.returncode != 0:
            return {"ok": False, "error": f"xprintidle failed: {r.stderr.strip()}"}
        ms = int(r.stdout.strip())
        return {
            "ok": True,
            "idle_ms": ms,
            "idle_seconds": ms / 1000.0,
            "idle_human": f"{ms//60000}m {(ms//1000)%60}s",
        }
    except FileNotFoundError:
        return {"ok": False, "error": "xprintidle not installed (sudo apt install xprintidle)"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "xprintidle timed out"}


_VISION_SINGLETON = None
_VISION_LOCK = threading.Lock()


def _get_vision():
    """Lazy module-level LocalVision (Moondream2) singleton. The model itself
    is loaded lazily inside LocalVision on first query, so this is cheap."""
    global _VISION_SINGLETON
    if _VISION_SINGLETON is None:
        with _VISION_LOCK:
            if _VISION_SINGLETON is None:
                from brain.local_vision import LocalVision  # type: ignore
                _VISION_SINGLETON = LocalVision()
    return _VISION_SINGLETON


def _is_dean_present(args: Dict[str, Any]) -> Dict[str, Any]:
    """Best-effort 'is anyone there' check: capture webcam, ask Moondream2
    if a person is visible. Returns a graceful error if webcam unavailable.

    Args:
      use_local_vision: prefer Moondream over actuator (default: True)
    """
    try:
        lv = _get_vision()
        # Need a webcam capture first — via actuator webcam tool if available
        from brain.actuator_client import call as _act
        cap = _act("webcam.capture", {})
        if not isinstance(cap, dict) or not cap.get("ok"):
            err = cap.get("error") if isinstance(cap, dict) else cap
            return {"ok": False, "error": f"webcam capture unavailable: {err}"}
        img_bytes = cap.get("image_bytes") or cap.get("png_bytes")
        if not img_bytes:
            return {"ok": False, "error": "no image bytes returned"}
        if isinstance(img_bytes, str):
            import base64
            img_bytes = base64.b64decode(img_bytes)
        res = lv.query(img_bytes,
                       "Is there a person visible in this image? Reply with just 'yes' or 'no'.")
        if not isinstance(res, dict) or not res.get("ok"):
            err = res.get("error") if isinstance(res, dict) else res
            return {"ok": False, "error": f"vision query failed: {err}"}
        ans_str = str(res.get("answer", "")).strip().lower()
        present = "yes" in ans_str[:8]
        return {
            "ok": True,
            "present": present,
            "raw_answer": ans_str[:200],
            "via": "moondream2_local",
        }
    except Exception as e:
        return {"ok": False, "error": f"webcam/vision unavailable: {type(e).__name__}: {e}"}


def _set_status_message(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set a status message displayed in the dashboard status bar.

    Args:
      message: status text (required, max 200 chars)
      icon: optional emoji
      severity: 'info' | 'warn' | 'error' (default: info)
      ttl_seconds: auto-clear after N seconds (default: 0 = sticky)
    """
    msg = args.get("message")
    if not msg:
        return {"ok": False, "error": "message is required"}
    payload = {
        "message": str(msg)[:200],
        "icon": args.get("icon"),
        "severity": args.get("severity", "info"),
        "ttl_seconds": int(args.get("ttl_seconds", 0)),
        "set_at": _now(),
    }
    try:
        _STATUS_FILE.write_text(json.dumps(payload))
    except OSError as e:
        return {"ok": False, "error": str(e)}
    _broadcast_ws({"type": "presence_status", "status": payload})
    return {"ok": True, "status": payload}


EXTRA_TOOLS = {
    "presence.dashboard_event":      _dashboard_event,
    "presence.dashboard_log_recent": _dashboard_log_recent,
    "presence.desktop_notify":       _desktop_notify,
    "presence.play_chime":           _play_chime,
    "presence.tts_say":              _tts_say,
    "presence.voice_tone_set":       _voice_tone_set,
    "presence.voice_tone_get":       _voice_tone_get,
    "presence.idle_check":           _idle_check,
    "presence.is_dean_present":      _is_dean_present,
    "presence.set_status_message":   _set_status_message,
}
