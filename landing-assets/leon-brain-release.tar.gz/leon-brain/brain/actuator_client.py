"""
Client for the leon-actuator daemon. Sends JSON-RPC requests over the
Unix socket and returns parsed responses. Used by the brain server when
Claude emits a tool_use block.

Defines the Anthropic tool schemas too so the responder can declare them
to Claude and Claude knows how to call them.
"""

from __future__ import annotations

import json
import os
import socket
import time
from typing import Any, Dict, List, Optional


import sys as _sys, os as _os
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "leon-actuator"))
import leon_transport as _transport
SOCKET_PATH = _transport.SOCKET_PATH

# PC bridge relay — when running on VPS, reach actuator via HTTP relay on
# Dean's PC. The relay listens on port 9100 and is reachable through the
# reverse SSH tunnel (-R 9100:localhost:9100).
_PC_RELAY_URL = os.environ.get("LEON_PC_RELAY_URL", "http://127.0.0.1:9100/actuator")


def _relay_forbidden() -> str:
    """Non-empty reason if this SI must NEVER touch the PC relay.

    THE CHOKE POINT (2026-09-04). A hosted customer SI inherits IS_SANDBOX=1
    from the same unit template the owner's brain uses, and on the hosting box
    127.0.0.1:9100 is not "nothing" -- it is the OPERATOR'S desktop: screen,
    keyboard, mouse, a logged-in browser.

    The first version of this guard lived only in _should_use_relay(). That
    fixed tool ROUTING and nothing else: is_alive() probes the relay's /health
    on its own path, so the tenant kept knocking on the operator's door every
    ~20s. Measured, not assumed -- 224 dropped SYNs on the tenant firewall
    counter, traced live to the tenant brain pid holding a socket open to
    127.0.0.1:9100 while the routing guard was already in place. A guard on
    the DECISION is not a guard on the ACTION. This one sits where the HTTP
    actually happens, so every present and future caller inherits it.
    """
    if os.environ.get("LEON_HOSTED_TENANT_ID"):
        return ("hosted tenant -- this SI's body is its own sandbox, "
                "never another machine's desktop")
    return ""
_USE_RELAY = None  # auto-detect: True on VPS, False on PC
_RELAY_LOCK = __import__("threading").Lock()
_RELAY_DETECT_TIME: float = 0


def _should_use_relay() -> bool:
    """Auto-detect: if the Unix socket is connectable, use it. Otherwise relay.

    VPS guard: when IS_SANDBOX=1 the brain runs on the VPS where any local
    actuator socket is wrong — desktop tools need to reach Dean's PC over
    the bridge (port 9100 relay). Without this guard, a rogue VPS-side
    actuator process (e.g. one spawned before today's run.py fix) makes
    the local socket connectable and we silently route every desktop tool
    call into a sandboxed VPS process where Brave and wmctrl do not exist.
    Force relay on VPS regardless of socket state.

    PLATFORM NOTE (fixed 2026-08-12, found on Dean's Windows box): this probe
    used to hardcode `os.path.exists(SOCKET_PATH)` + an AF_UNIX connect. That
    is a POSIX-only test. On Windows the actuator does not use a Unix socket
    at all — leon_transport falls back to loopback TCP on an ephemeral port
    advertised in leon-actuator.rendezvous.json. So the probe could never
    succeed there, `_USE_RELAY` latched True forever, and EVERY desktop tool
    was routed to the VPS bridge URL (127.0.0.1:9100) that nothing on a
    customer machine listens on. Result: a fully healthy actuator with 200+
    tools loaded, sitting right there, while all 21 tools failed identically
    with `[WinError 10061] target machine actively refused it`. The SI had a
    body and could not reach it.

    The fix is to ask the transport layer instead of reimplementing half of
    it: `_transport.connect()` is the SAME call `_call_socket` already uses,
    on every OS. If it connects, the body is local. Anything else -> relay."""
    global _USE_RELAY, _RELAY_DETECT_TIME

    # HOSTED TENANT GUARD (2026-09-04). The IS_SANDBOX guard below was written
    # for the OWNER's brain, which runs on the VPS and legitimately reaches the
    # owner's PC through the reverse-SSH tunnel on 127.0.0.1:9100. Every hosted
    # customer SI inherits IS_SANDBOX=1 from the same unit template, so every
    # one of them was being force-routed at that same loopback port -- which on
    # this host is not "nothing", it is the OWNER'S DESKTOP: screen capture,
    # keyboard, mouse, a logged-in browser. The only thing that stopped a
    # customer SI from driving it was a bearer token it did not happen to hold,
    # and the SI, reasoning honestly from a 401, concluded its key was stale and
    # asked its user to have the operator "fix" the key. Granting that request
    # would have handed a customer's mind the owner's machine.
    #
    # A hosted tenant has no PC bridge of its own and must never inherit
    # someone else's. Never relay. Fall through to the local-socket probe: if a
    # body is genuinely present it is used, and if not, the desktop tool fails
    # with a plain error instead of silently reaching for a machine that is not
    # the tenant's. This is the same failure class as the Windows bug described
    # above -- a relay decision made from an assumption about identity instead
    # of from what is actually reachable.
    if _relay_forbidden():
        return False

    if os.environ.get("IS_SANDBOX") == "1":
        return True
    with _RELAY_LOCK:
        # Re-check every 60s so socket recovery is detected
        if _USE_RELAY is not None and (time.time() - _RELAY_DETECT_TIME < 60):
            return _USE_RELAY
        # Is a local actuator actually connectable? Use the transport's own
        # platform-aware path (Unix socket on POSIX, loopback TCP +
        # rendezvous file on Windows) rather than probing AF_UNIX directly.
        # Note: connect() is used directly rather than gating on
        # listener_present() first. listener_present() branches on
        # USE_UNIX_SOCKET internally, so gating on it reintroduces the exact
        # platform assumption this fix removes; connect() already raises when
        # nothing is listening, which its own docstring defines as "fall back
        # to the HTTP relay". One call, no platform knowledge here.
        try:
            s, _ = _transport.connect(0.5)
            s.close()
            use_relay = False       # local body is live — talk to it directly
        except Exception:
            use_relay = True        # nothing listening locally -> relay
        _USE_RELAY = use_relay
        _RELAY_DETECT_TIME = time.time()
        return use_relay


def _call_socket(tool: str, args: dict, timeout: float) -> Dict[str, Any]:
    """Call actuator via local Unix socket (PC-local)."""
    payload = (json.dumps({"tool": tool, "args": args}) + "\n").encode("utf-8")
    s, _tok = _transport.connect(timeout)
    if _tok:
        _d = json.loads(payload.decode("utf-8")); _d["token"] = _tok
        payload = (json.dumps(_d) + "\n").encode("utf-8")
    s.sendall(payload)
    buf = b""
    deadline = time.time() + timeout
    while not buf.endswith(b"\n"):
        if time.time() > deadline:
            s.close()
            return {"ok": False, "error": "actuator response timeout"}
        chunk = s.recv(65536)
        if not chunk:
            break
        buf += chunk
    s.close()
    if not buf:
        return {"ok": False, "error": "empty actuator response"}
    return json.loads(buf.decode("utf-8"))


def _call_relay(tool: str, args: dict, timeout: float) -> Dict[str, Any]:
    """Call actuator via HTTP relay on the owner's PC (VPS -> PC bridge)."""
    _forbidden = _relay_forbidden()
    if _forbidden:
        return {"ok": False,
                "error": f"PC relay refused ({_forbidden}). Use this box: "
                         f"shell, filesystem and browser are local."}
    import urllib.request
    payload = json.dumps({"tool": tool, "args": args}).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    # Auth: use same API key the brain server uses
    api_key = os.environ.get("LEON_API_KEY", "")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urllib.request.Request(
        _PC_RELAY_URL,
        data=payload,
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return {"ok": False, "error": f"PC relay: {type(e).__name__}: {e}"}


def call(tool: str, args: Optional[Dict[str, Any]] = None, timeout: float = 15.0) -> Dict[str, Any]:
    """Send one JSON-RPC request to the actuator. Returns the parsed
    response dict, always with at least an `ok` boolean.
    Auto-detects: Unix socket (local) or HTTP relay (VPS → PC bridge).

    Name translation: if `tool` is a brain-side underscore name registered
    in _TOOL_NAME_MAP (e.g. `browser_gmail_inbox_state`), it's converted
    to the actuator-side dot form (`browser.gmail_inbox_state`) before
    sending. This keeps callers like tool_explorer.py and growth_loop.py
    — which pass the brain-side name straight through — from getting
    spurious "unknown tool" errors. If the name already contains a dot,
    it's passed through unchanged. self.* tools (handled in-process) are
    NOT translated here; that routing lives in execute_anthropic_tool."""
    args = args or {}
    # Identity guard: never let a client SI's notification print "Leon".
    if tool and "notify" in tool and isinstance(args.get("title"), str):
        try:
            from brain.identity import brand
            args = {**args, "title": brand(args["title"])}
        except Exception:
            pass
    if tool and "." not in tool:
        mapped = _TOOL_NAME_MAP.get(tool)
        if mapped and not mapped.startswith("self."):
            tool = mapped
    try:
        if _should_use_relay():
            return _call_relay(tool, args, timeout)
        return _call_socket(tool, args, timeout)
    except FileNotFoundError:
        # Socket gone — try relay as fallback
        global _USE_RELAY
        _USE_RELAY = True
        try:
            return _call_relay(tool, args, timeout)
        except Exception as e2:
            return {"ok": False, "error": f"actuator not reachable (socket missing, relay failed: {e2})"}
    except (ConnectionRefusedError, BrokenPipeError):
        return {"ok": False, "error": "actuator socket refused"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def is_alive(timeout: float = 2.0) -> bool:
    """Quick liveness check — local body first, then relay.

    Third site of the same POSIX-only assumption fixed elsewhere in this file
    on 2026-08-12: this probed AF_UNIX directly, so on Windows a perfectly
    healthy local actuator always read as dead and callers (self-repair, the
    dashboard body indicator, ambient perception) concluded the SI had no
    body. Ask the transport, which knows the per-OS answer.
    """
    try:
        s, _ = _transport.connect(timeout)
        s.close()
        return True
    except Exception:
        pass
    # Try relay (VPS -> PC bridge). Same choke point as _call_relay: a hosted
    # tenant has no relay of its own and must not probe someone else's.
    if _relay_forbidden():
        return False
    try:
        import urllib.request
        health_url = _PC_RELAY_URL.replace("/actuator", "/health")
        req = urllib.request.Request(health_url)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data.get("ok", False)
    except Exception:
        return False


# ── Risk levels per tool ──────────────────────────────────────────────────
# LOW    → auto-execute, no confirmation. Side-effect-free or trivial.
# MEDIUM → auto-execute today; later we may gate this on recent user intent.
# HIGH   → REQUIRES user confirmation through the dashboard before running.
TOOL_RISK: Dict[str, str] = {
    "screen_capture":   "low",
    "window_list":      "low",
    "clipboard_paste":  "low",
    "mouse_move":       "low",
    "notify":           "low",
    "knowledge_search": "low",
    "file_read":        "low",
    "file_list":        "low",
    "reminder_set":     "low",
    "reminder_list":    "low",
    "reminder_cancel":  "low",
    "webcam_capture":   "low",   # read-only frame grab; opt-in via UI toggle
    "vision_describe":  "low",   # local Moondream2 — no API cost, no side-effects

    "file_write":      "medium",   # sandboxed to ~/Desktop/leon-out
    "window_focus":    "medium",
    "window_list_monitors":   "low",     # read-only xrandr geometry
    "window_move_to_monitor": "medium",  # moves windows but reversible
    "click_text":             "medium",  # OCR-grounded click (zero API cost)
    "click_element":          "medium",  # vision-grounded click (~$0.003/call)
    "browser_dom_state":      "low",     # read-only DOM snapshot
    "browser_dom_click":      "medium",  # DOM-level click (most reliable for web)
    "browser_dom_extract":    "low",     # read-only text/attr scraping
    "browser_dom_scroll_to":  "medium",  # scrolls but reversible
    "app_launch":      "medium",     # whitelist already protects
    "browser_open":    "medium",     # opens a URL in Brave
    "web_search":      "medium",     # opens Google to a search URL
    "mouse_click":     "medium",
    "mouse_scroll":    "medium",
    "keyboard_type":   "medium",
    "keyboard_hotkey": "medium",
    "clipboard_copy":  "medium",

    "app_close":       "high",       # closing things can lose work
    "mouse_drag":      "high",       # easy to misfire

    # Self-modification — Leon can rewire himself but every change
    # needs Dean's eyes via the confirm modal.
    "code_restore":   "low",         # safe rollback to prior backup
    "http_request":   "high",        # arbitrary external API calls
    "code_edit":      "high",        # writes to ANY file (sandbox lifted)
    "restart_self":   "high",        # kills + respawns the brain
    "shell_exec":     "high",        # arbitrary bash on Dean's machine
}


# ── Identity for tool prose ───────────────────────────────────────────────
# Tool descriptions are sent to the model on EVERY request — they are prompt
# text, not documentation. Anything hardcoded here is something a customer's
# model is told about a stranger. These read through brain/identity.py, which
# falls back to the owner's names ONLY on the original (proven by
# brain/owner_facts.py being present; see brain/origin.py). Failure is
# neutral, never the owner: "your SI" / "your owner".
def _si_label() -> str:
    try:
        from brain.identity import si_name
        return si_name()
    except Exception:
        return "this SI"


def _owner_label() -> str:
    """Owner's name as it reads MID-SENTENCE — owner_prose(), not user_name().

    user_name() returns the turn label "You", which is right for "You: hello"
    and wrong inside a tool description ("a screenshot of You's desktop").
    """
    try:
        from brain.identity import owner_prose
        return owner_prose()
    except Exception:
        return "your owner"


_SI = _si_label()
_OWNER = _owner_label()


# ── Anthropic tool schemas ────────────────────────────────────────────────
# Declared so the responder can pass them to Claude. Names match the
# actuator's tool dispatch table 1:1 (with `_` instead of `.` since
# Anthropic's tool name validator forbids dots).
ANTHROPIC_TOOLS: List[Dict[str, Any]] = [
    {
        "name": "screen_capture",
        "description": (
            "Take a screenshot of Dean's full desktop and return it as a PNG. "
            "Use this when you need to see what's on his screen — e.g. he asks "
            "'what am I looking at?', 'read the screen for me', or you need to "
            "verify a UI state before clicking. Returns a base64 PNG image."
        ),
        "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "window_list",
        "description": (
            "List all currently open windows on Dean's desktop. Returns each "
            "window's title and ID. Use this to know what's running before "
            "deciding to focus, click, or launch."
        ),
        "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "window_focus",
        "description": (
            "Bring the first window whose title contains the given substring "
            "to the foreground. Use when you need to act on a specific app "
            "that's already open."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "title_substring": {
                    "type": "string",
                    "description": "Case-insensitive substring matched against window titles.",
                },
            },
            "required": ["title_substring"],
            "additionalProperties": False,
        },
    },
    {
        "name": "window_list_monitors",
        "description": (
            "List Dean's connected monitors with their geometry (index, "
            "name like 'HDMI-0', x/y offset, width, height). Use this BEFORE "
            "window_move_to_monitor if Dean says 'right monitor' / 'left "
            "screen' so you know which physical display he means. Dean's "
            "current 3-monitor setup is normally left=HDMI-0, middle=DP-2, "
            "right=HDMI-1 — but ALWAYS call this to confirm geometry, since "
            "monitors can be swapped or one can be off."
        ),
        "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "window_move_to_monitor",
        "description": (
            "Move an open window onto a specific monitor and (by default) "
            "maximize it there. Use this when Dean says 'open X on my "
            "right monitor', 'move Spotify to the left screen', etc.\n\n"
            "**STANDING RULE — default monitor:** whenever Dean asks you to "
            "open / pull up / show something on screen and does NOT name a "
            "monitor ('just pull it up', 'open Ben's email'), put it on the "
            "RIGHT monitor. Only use left/middle when he explicitly says so. "
            "This is a fixed preference — don't ask which monitor.\n\n"
            "**Preferred flow for 'open Y on Z monitor':**\n"
            "  1. `browser_open(url=..., new_window=true)` → returns "
            "`window_id` in its result.\n"
            "  2. `window_move_to_monitor(window_id=..., monitor='right')`.\n"
            "Passing window_id makes the move precise — no risk of "
            "matching the WRONG window (e.g. dragging Dean's Leon "
            "dashboard if it's also a Brave window).\n\n"
            "Use `title_substring` only when window_id isn't available "
            "(e.g. moving an app that was already running). monitor accepts "
            "'left' / 'middle' / 'right' (positional), a monitor name like "
            "'HDMI-1', or a numeric index. Set maximize=false to keep the "
            "window's current size and just place it on that display."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "window_id": {
                    "type": "string",
                    "description": "Exact wmctrl window ID (e.g. '0x03600251'). Get this from browser_open(new_window=true).result.window_id. Use this whenever you have it.",
                },
                "title_substring": {
                    "type": "string",
                    "description": "Fallback when window_id isn't known. Case-insensitive substring of the target window's title.",
                },
                "monitor": {
                    "description": "'left'/'middle'/'right', a monitor name (e.g. 'HDMI-1'), or numeric index.",
                },
                "maximize": {
                    "type": "boolean",
                    "description": "Fill the target monitor (default true). false = keep current size.",
                },
            },
            "required": ["monitor"],
            "additionalProperties": False,
        },
    },
    {
        "name": "app_launch",
        "description": (
            "Launch a whitelisted desktop application. Allowed names: brave, "
            "browser, chrome, spotify, code, vscode, terminal, files, "
            "calculator, slack. Returns ok:false if the app isn't whitelisted."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Friendly app name from the whitelist.",
                },
            },
            "required": ["name"],
            "additionalProperties": False,
        },
    },
    {
        "name": "click_text",
        "description": (
            "**PREFERRED CLICK TOOL for visible text labels.** Click on a "
            "specific piece of text visible on screen using local OCR — zero "
            "API cost, ~0.5s. Examples: 'click Save', 'click Sign Up', "
            "'click the OK button'. Pass the text exactly as it appears "
            "(case-insensitive, fuzzy-match handles typos). For multiple "
            "matches, use `occurrence` to pick the Nth (0-indexed). "
            "If this returns ok:false ('no text matching...'), escalate to "
            "`click_element` which uses Sonnet vision. "
            "DO NOT use this for image-only targets (icons, thumbnails, "
            "logos without text) — use click_element for those."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "Visible text to click on (case-insensitive, fuzzy).",
                },
                "occurrence": {
                    "type": "integer",
                    "description": "0-indexed pick if multiple matches. Default 0 (first).",
                },
                "button": {
                    "type": "string",
                    "enum": ["left", "right", "middle"],
                    "description": "Mouse button (default left).",
                },
            },
            "required": ["text"],
            "additionalProperties": False,
        },
    },
    {
        "name": "click_element",
        "description": (
            "Click on a UI element using Moondream2 vision (local, free, "
            "~0.5-1s) to find its location. Use this for image targets, "
            "icons, video thumbnails, unlabeled buttons — anything where "
            "click_text doesn't apply. The description should be a SIMPLE "
            "noun phrase ('video thumbnail', 'Subscribe button', 'play "
            "icon', 'red car') — Moondream's pointer doesn't reliably parse "
            "compound spatial qualifiers in the description itself.\n\n"
            "**For positional selection, use the `position` arg** instead "
            "of stuffing it into the description:\n"
            "  - 'first' / 'top-left': topmost-then-leftmost (Moondream's default order)\n"
            "  - 'top-right', 'bottom-left', 'bottom-right' / 'last'\n"
            "  - 'top' / 'bottom' / 'left' / 'right': extreme along that axis\n"
            "  - 'center': closest to screen center\n"
            "  - 'on-right-monitor' / 'on-middle-monitor' / 'on-left-monitor':\n"
            "       filter candidates to that monitor (Dean's 3-monitor setup)\n\n"
            "Examples:\n"
            "  click_element(description='video thumbnail', position='bottom-right')\n"
            "  click_element(description='play button', position='center')\n"
            "  click_element(description='video thumbnail', position='on-right-monitor', occurrence=0)\n\n"
            "If Moondream returns 0 candidates, the description was too "
            "narrow — try a simpler noun and use position to disambiguate. "
            "Or fall back to click_text / browser_dom_click."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "description": {
                    "type": "string",
                    "description": "SIMPLE noun phrase for the target ('video thumbnail', 'Subscribe button', 'play icon'). Don't include spatial qualifiers — use `position` for those.",
                },
                "position": {
                    "type": "string",
                    "description": "Pick among multiple matches: 'first'/'top-left'/'top-right'/'bottom-left'/'bottom-right'/'top'/'bottom'/'left'/'right'/'center'/'on-right-monitor'/'on-middle-monitor'/'on-left-monitor'. Default 'first'.",
                },
                "occurrence": {
                    "type": "integer",
                    "description": "Explicit 0-indexed pick (after position filtering/sorting). Default 0.",
                },
                "button": {
                    "type": "string",
                    "enum": ["left", "right", "middle"],
                    "description": "Mouse button (default left).",
                },
            },
            "required": ["description"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mouse_click",
        "description": (
            "Click the mouse at absolute screen coordinates (x, y). Origin "
            "is top-left. Use sparingly — prefer keyboard shortcuts and app "
            "launches when possible. Always screen_capture first if you don't "
            "already know exact coordinates. **For clicking on a known UI "
            "element by name or description, use click_text or click_element "
            "instead — they don't require you to guess coordinates.**"
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "X coordinate in pixels"},
                "y": {"type": "integer", "description": "Y coordinate in pixels"},
                "button": {
                    "type": "string",
                    "enum": ["left", "right", "middle"],
                    "description": "Which mouse button (default left).",
                },
            },
            "required": ["x", "y"],
            "additionalProperties": False,
        },
    },
    {
        "name": "keyboard_type",
        "description": (
            "Type a string into the currently focused window. Make sure the "
            "right window is focused first (window_focus) — this types into "
            "wherever the cursor is. Max 4000 chars."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to type."},
            },
            "required": ["text"],
            "additionalProperties": False,
        },
    },
    {
        "name": "keyboard_hotkey",
        "description": (
            "Fire a keyboard shortcut. combo is plus-separated, e.g. "
            "'ctrl+l' (browser address bar), 'alt+tab', 'super+e' (file "
            "manager), 'ctrl+shift+t' (reopen tab)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "combo": {"type": "string", "description": "Plus-separated key combo."},
            },
            "required": ["combo"],
            "additionalProperties": False,
        },
    },
    {
        "name": "app_close",
        "description": (
            "Politely close the first window matching a title substring "
            "(equivalent to clicking [X]). HIGH risk — Dean will be asked "
            "to confirm before this runs. Use only when the user clearly "
            "asks to close something."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "title_substring": {
                    "type": "string",
                    "description": "Case-insensitive substring of the window title to close.",
                },
            },
            "required": ["title_substring"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mouse_scroll",
        "description": (
            "Scroll the mouse wheel. direction is 'up' or 'down'. Optional "
            "(x, y) parks the cursor over the scroll target first — useful "
            "when there are multiple scrollable panes."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "clicks": {"type": "integer", "description": "Number of wheel notches (1–20 typical)."},
                "direction": {"type": "string", "enum": ["up", "down"]},
                "x": {"type": "integer", "description": "Optional cursor X before scrolling."},
                "y": {"type": "integer", "description": "Optional cursor Y before scrolling."},
            },
            "required": ["clicks", "direction"],
            "additionalProperties": False,
        },
    },
    {
        "name": "mouse_drag",
        "description": (
            "Press at (x1, y1), drag to (x2, y2), release. HIGH risk — "
            "Dean will be asked to confirm. Use only when the user "
            "specifically asks to drag something (move a window, "
            "rearrange a list, select a region)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "x1": {"type": "integer"}, "y1": {"type": "integer"},
                "x2": {"type": "integer"}, "y2": {"type": "integer"},
                "button": {"type": "string", "enum": ["left", "right", "middle"]},
            },
            "required": ["x1", "y1", "x2", "y2"],
            "additionalProperties": False,
        },
    },
    {
        "name": "clipboard_copy",
        "description": (
            "Write text to the system clipboard. Up to 100KB. Use when "
            "Dean asks to 'copy that' or you want to hand off generated "
            "text to another app."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to copy."},
            },
            "required": ["text"],
            "additionalProperties": False,
        },
    },
    {
        "name": "clipboard_paste",
        "description": (
            "Read the current clipboard contents. Use when Dean references "
            "'what I just copied' or 'this thing on my clipboard'."
        ),
        "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "notify",
        "description": (
            "Pop a desktop notification via notify-send. Use sparingly — "
            "only for ambient updates Dean asked you to send (build done, "
            "meeting in 5, reminder fired). Never spam."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Short bold title (default 'Leon')."},
                "body":  {"type": "string", "description": "Notification body text."},
                "urgency": {"type": "string", "enum": ["low", "normal", "critical"]},
            },
            "required": ["body"],
            "additionalProperties": False,
        },
    },
    {
        "name": "browser_dom_state",
        "description": (
            "Snapshot of Dean's active Brave tab — URL, page title, viewport "
            "size, scroll position, ready state, plus a list of all open "
            "tabs with their IDs/titles/URLs. Use this BEFORE browser_dom_* "
            "actions to confirm which tab you're targeting and to discover "
            "the page state. Free, ~100ms. Returns ok:false with a hint to "
            "restart Brave if CDP isn't reachable."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url_contains": {
                    "type": "string",
                    "description": "Optional URL substring to disambiguate when multiple tabs open. Default = the front tab.",
                },
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "browser_dom_click",
        "description": (
            "**PREFERRED for any click inside a browser page** — clicks an "
            "actual DOM element via Chrome DevTools Protocol on Dean's "
            "running Brave session. Fires native click events, follows "
            "links, triggers React handlers — works as if Dean clicked. "
            "Faster and more reliable than click_text/click_element for "
            "anything web-based.\n\n"
            "Two ways to target:\n"
            "  * `text` — substring of visible text on the element (e.g. "
            "    'Subscribe', 'Sign in', the video title). Robust to layout "
            "    shifts. Picks the narrowest matching element. PREFERRED.\n"
            "  * `selector` — CSS selector (e.g. 'a[href*=\"watch\"]', "
            "    'button.submit', 'ytd-video-renderer:nth-child(1) a#thumbnail'). "
            "    Use when text matching is ambiguous (no unique text, many "
            "    items with same label).\n\n"
            "Use `occurrence` (0-indexed) to pick the Nth match. The element "
            "is scrolled into view before clicking by default.\n\n"
            "Returns the clicked element's tag, text, href, and bbox so you "
            "can confirm the right thing was hit.\n\n"
            "**Requires Brave launched with --remote-debugging-port=9222.** "
            "If that flag isn't on, this tool returns an error pointing to "
            "the fix. Fall back to click_text / click_element in that case."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "Visible text on the target element (preferred for most cases).",
                },
                "selector": {
                    "type": "string",
                    "description": "CSS selector (alternative to text).",
                },
                "occurrence": {
                    "type": "integer",
                    "description": "0-indexed pick when multiple matches. Default 0 (first).",
                },
                "scroll_into_view": {
                    "type": "boolean",
                    "description": "Scroll element into view before clicking (default true).",
                },
                "url_contains": {
                    "type": "string",
                    "description": "Disambiguate when multiple tabs open.",
                },
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "browser_dom_extract",
        "description": (
            "Extract text + attributes from matching DOM elements on the "
            "active Brave tab. Read-only, free, ~100ms. Use this to scrape "
            "structured data without parsing screenshots — e.g. 'list all "
            "video titles on this YouTube page' → "
            "`browser_dom_extract(selector='a#video-title', attrs=['href'])`. "
            "Returns up to `limit` matching nodes (default 50)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "selector": {
                    "type": "string",
                    "description": "CSS selector for nodes to extract.",
                },
                "attrs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Additional attributes to pull (e.g. ['href','src','aria-label']). 'text' is always included.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max nodes to return (default 50).",
                },
                "url_contains": {
                    "type": "string",
                    "description": "Disambiguate when multiple tabs open.",
                },
            },
            "required": ["selector"],
            "additionalProperties": False,
        },
    },
    {
        "name": "browser_dom_scroll_to",
        "description": (
            "Scroll a matching element into view on the active Brave tab "
            "WITHOUT clicking it. Useful when the user asks about something "
            "currently below the fold — scroll it into view, then "
            "screen_capture or browser_dom_extract."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Visible text on the target."},
                "selector": {"type": "string", "description": "CSS selector (alternative to text)."},
                "url_contains": {"type": "string", "description": "Disambiguate when multiple tabs open."},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "browser_open",
        "description": (
            "Open a URL in Dean's browser (Brave). Use this for 'open "
            "youtube' / 'open github' / 'go to twitter' / 'pull up <site>' "
            "/ 'navigate to <url>' — anything where the user wants a "
            "specific website. Auto-prepends https:// for bare hosts. "
            "DO NOT use `app_launch(brave)` for navigation — that just "
            "opens an empty Brave window. This tool actually navigates.\n\n"
            "**IMPORTANT — when the user wants the page on a specific "
            "monitor** ('open YouTube on my right monitor', 'pull up X on "
            "the left screen'), ALWAYS pass `new_window: true`. Otherwise "
            "the URL opens as a tab in Dean's current browser window and a "
            "subsequent window_move_to_monitor will drag the window he's "
            "actively working in (including the Leon dashboard!) to the "
            "wrong screen. With new_window=true, the result includes "
            "`window_id` — pass that directly to `window_move_to_monitor` "
            "for a precise move (no title-guessing)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "Full URL or bare host (e.g. 'youtube.com').",
                },
                "new_window": {
                    "type": "boolean",
                    "description": "Open in a new browser window (default false). REQUIRED=true when about to move the page to a specific monitor.",
                },
            },
            "required": ["url"],
            "additionalProperties": False,
        },
    },
    {
        "name": "web_search",
        "description": (
            "Run a web search and open the results page. Use for "
            "'search for X', 'look up Y', 'google Z'. engine='google' "
            "(default), 'duckduckgo', or 'youtube' (searches YouTube)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query":  {"type": "string", "description": "Search terms."},
                "engine": {"type": "string", "enum": ["google", "duckduckgo", "youtube"]},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    },
    {
        "name": "file_write",
        "description": (
            "Save text to a file in Dean's leon-out workspace "
            "(~/Desktop/leon-out/). Auto-creates parent directories. "
            "Use this when Dean asks you to 'make me X', 'save this as Y', "
            "'create an HTML page', etc. — actually writing the file is "
            "much better than dumping the code in a fenced block for him "
            "to copy-paste. The output path is sandboxed and the file "
            "extension must be in the safe-list (html/css/js/ts/md/json/"
            "py/sh/yaml/...). Default mode='w' overwrites; mode='a' appends."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": (
                        "Relative path inside ~/Desktop/leon-out/ "
                        "(e.g. 'demo/index.html') OR an absolute path "
                        "under the same root. Bare filenames go to the "
                        "root of leon-out/."
                    ),
                },
                "content": {"type": "string", "description": "File contents."},
                "mode": {"type": "string", "enum": ["w", "a"]},
            },
            "required": ["path", "content"],
            "additionalProperties": False,
        },
    },
    {
        "name": "file_read",
        "description": (
            "Read a UTF-8 text file from anywhere under ~/Desktop/. "
            "Use when Dean references 'that file I saved' or you need "
            "to inspect a file before editing it. 1MB cap."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Relative to leon-out/ or absolute under ~/Desktop/."},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    {
        "name": "file_list",
        "description": (
            "List files in a directory under ~/Desktop/. Returns name, "
            "size, mtime, and is_dir for each entry. Default path is "
            "~/Desktop/leon-out/."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Defaults to leon-out/."},
                "show_hidden": {"type": "boolean", "description": "Include dotfiles (default false)."},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "vision_describe",
        "description": (
            "Cheap local-vision tier. Captures a frame from the screen "
            "or the webcam and runs it through Moondream2 (running on "
            "Dean's local GPU — no API cost, ~0.5–2s latency). Use this "
            "FIRST for simple visual queries like 'is there a person on "
            "the camera?', 'what color is the dominant thing on screen?', "
            "'is dean smiling?', 'what app is in front?'. Only escalate "
            "to `screen_capture` / `webcam_capture` (which spend Sonnet "
            "vision tokens) when you genuinely need fine detail or "
            "complex reasoning the local model can't handle.\n\n"
            "`source` is 'screen' (default) or 'webcam'. Pass `prompt` "
            "with a short question for query mode, leave it empty for "
            "captioning, or use mode='detect' with a target noun "
            "('person', 'phone') for object detection bounding boxes."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "source": {"type": "string", "enum": ["screen", "webcam"]},
                "prompt": {"type": "string", "description": "Question or detection target."},
                "mode":   {"type": "string", "enum": ["caption", "query", "detect"]},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "webcam_capture",
        "description": (
            "Take a single still frame from Dean's webcam and SEE it. "
            "Use this when Dean asks 'what does the camera see', 'look at "
            "me', 'is X visible behind me', 'do I look tired', or you "
            "need to verify something physical happening in the room. "
            "Webcam must be enabled in the dashboard first (the camera "
            "icon next to the mic) — if it's off the tool will tell you "
            "to ask Dean to flip it on. Returns a JPEG/PNG you can read "
            "directly. Use sparingly — it's privacy-sensitive."
        ),
        "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "reminder_set",
        "description": (
            "Schedule a reminder to ping Dean later via desktop "
            "notification. Pass either `in_seconds` (relative — '300' for "
            "5 min) OR `at_iso` (absolute — '2026-05-08T17:00:00'). The "
            "`text` is what the notification says. Use this when Dean "
            "asks you to remind him of anything: 'remind me to take a "
            "break in 15 min', 'ping me at 3pm', 'tell me to stand up "
            "every hour'. Always confirm with the resolved time, not "
            "the raw arguments."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "text":       {"type": "string", "description": "Reminder body."},
                "in_seconds": {"type": "number", "description": "Fire this many seconds from now."},
                "at_iso":     {"type": "string", "description": "ISO-8601 absolute time (preferred for clock times)."},
                "title":      {"type": "string", "description": "Optional title (default 'Leon')."},
            },
            "required": ["text"],
            "additionalProperties": False,
        },
    },
    {
        "name": "reminder_list",
        "description": (
            "List active (not yet fired and not cancelled) reminders. "
            "Use when Dean asks 'what reminders do I have?', 'what's "
            "next on the timer?'."
        ),
        "input_schema": {"type": "object", "properties": {}, "additionalProperties": False},
    },
    {
        "name": "reminder_cancel",
        "description": (
            "Cancel a pending reminder by id (the id Dean references in "
            "conversation OR the id reminder_list returned)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"id": {"type": "string"}},
            "required": ["id"],
            "additionalProperties": False,
        },
    },
    {
        "name": "knowledge_search",
        # NO PROJECT NAMES. This used to quote two of the owner's real
        # project names as worked examples ("what's <X>", "where am I on <Y>").
        # Every customer's model was handed the owner's project roster as
        # worked examples on every single request — which is one of the ways
        # a stranger's SI came to "remember" one of the owner's products. The examples
        # were never load-bearing; the instruction is.
        "description": (
            f"Search {_SI}'s own long-term memory (project READMEs, "
            "CLAUDE.md files, SESSION_LOGs, screen-observed text, past "
            f"conversations). Use this when {_OWNER} asks about a project "
            "by name, references prior context, or you need recall before "
            "answering. Returns the most-relevant matches with project tags."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search terms."},
                "limit": {"type": "integer", "description": "Max results (default 5, max 15)."},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
    },

    # ── Self-modification (HIGH risk — confirm modal protects each call) ─
    {
        "name": "http_request",
        "description": (
            "Generic HTTP client. Use for ANY external API — ElevenLabs, "
            "OpenAI, weather, Reddit, anything. Returns parsed JSON when "
            "the response declares application/json, otherwise raw body "
            "(truncated to 32 KB). Treats 4xx/5xx as ok=true with the "
            "non-2xx status so you can read the error body."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "method": {"type": "string", "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"]},
                "url":    {"type": "string", "description": "Full http(s):// URL."},
                "headers":{"type": "object", "description": "Optional request headers."},
                "body":   {"description": "Optional request body. Object/list → auto-JSON-encoded with Content-Type."},
                "timeout_s": {"type": "number", "description": "Request timeout (default 30)."},
            },
            "required": ["method", "url"],
            "additionalProperties": False,
        },
    },
    {
        "name": "code_edit",
        "description": (
            "Edit ANY file on Dean's machine — your own source, system "
            "files, anywhere. Dean explicitly opted out of sandboxing. "
            "Always creates a timestamped backup at brain_state/code_backups/ "
            "BEFORE writing, so code_restore can roll back. Two modes: "
            "(1) substring replace — pass {file_path, old_string, new_string, "
            "replace_all?} where old_string must be unique unless "
            "replace_all=true; (2) full rewrite — pass {file_path, new_content}. "
            "Path can be absolute (/etc/..., /home/<user>/...) or relative. "
            "No extension whitelist. The only files protected are the "
            "backups dir and the trained wake-word ONNX. If you edit your "
            "own code, the change does NOT take effect until you call "
            "restart_self — chain them in the same response."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "file_path":  {"type": "string", "description": "Path relative to project root."},
                "old_string": {"type": "string", "description": "Exact text to find (substring mode)."},
                "new_string": {"type": "string", "description": "Replacement text (substring mode)."},
                "new_content":{"type": "string", "description": "Full file content (rewrite mode)."},
                "replace_all":{"type": "boolean", "description": "Replace all occurrences vs. require unique. Default false."},
            },
            "required": ["file_path"],
            "additionalProperties": False,
        },
    },
    {
        "name": "code_restore",
        "description": (
            "Roll back a file Leon previously edited. Pass file_path to "
            "restore that specific file from its most recent backup, OR "
            "pass file_path='latest' to restore whichever file Leon "
            "edited most recently. Safe — only undoes Leon's own actions."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Path to restore, or 'latest' for the most recent edit."},
            },
            "required": ["file_path"],
            "additionalProperties": False,
        },
    },
    {
        "name": "restart_self",
        "description": (
            "Schedule a detached respawn of the brain server so a config "
            "change you just made actually takes effect. The current "
            "process dies in ~2s and is replaced by a fresh one ~5s "
            "after that. Conversation continues — your reply will land "
            "before the kill. Use this AFTER a code_edit, never before."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {"type": "string", "description": "Short note on why you're restarting (logged)."},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "shell_exec",
        "description": (
            "Run an arbitrary bash command on Dean's machine. UNRESTRICTED "
            "— Dean opted out of sandboxing. Captures stdout+stderr+rc, "
            "256 KB cap on each stream (big enough to `cat` any source "
            "file in one shot — no chunking gymnastics). Default timeout "
            "30 s. Use for things code_edit can't do: install packages, "
            "run git, ls, grep, chmod, restart services, run python "
            "scripts. For pure file edits prefer code_edit (it auto-backs-up). "
            "There is NO approval prompt — Dean turned modals off. Just "
            "fire the command. DO NOT run commands that wait on input or "
            "hang forever — they'll just hit the timeout and the brain blocks."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Bash command to execute (run via `bash -lc`)."},
                "cwd":     {"type": "string", "description": "Working directory. Defaults to project root."},
                "timeout_s": {"type": "number", "description": "Timeout in seconds (default 30, max 300)."},
            },
            "required": ["command"],
            "additionalProperties": False,
        },
    },
]

# The owner's actual address is configuration, never a literal in source.
# Set LEON_OWNER_EMAIL in .env; absent it, the description simply says
# "the signed-in account" and the SI reads whatever is really there.
import os as _os_om
_om = _os_om.environ.get("LEON_OWNER_EMAIL", "").strip()
_OWNER_MAIL_HINT = f" ({_om})" if _om else ""

# --- Append business platform tools ---
try:
    from business.brain_integration import BUSINESS_TOOLS as _BIZ_TOOLS
    for _bt in _BIZ_TOOLS:
        ANTHROPIC_TOOLS.append({
            "name": _bt["name"],
            "description": _bt["description"],
            "input_schema": _bt["input_schema"],
        })
except ImportError:
    pass  # business module not installed — skip gracefully


# Map Anthropic tool name → actuator tool name (dots vs underscores)
_TOOL_NAME_MAP = {
    "screen_capture":   "screen.capture",
    "window_list":      "window.list",
    "window_focus":     "window.focus",
    "window_list_monitors":   "window.list_monitors",
    "window_move_to_monitor": "window.move_to_monitor",
    "click_text":             "click.text",
    "click_element":          "click.element",
    "browser_dom_state":      "browser.dom_state",
    "browser_dom_click":      "browser.dom_click",
    "browser_dom_extract":    "browser.dom_extract",
    "browser_dom_scroll_to":  "browser.dom_scroll_to",
    "app_launch":       "app.launch",
    "app_close":        "app.close",
    "mouse_click":      "mouse.click",
    "mouse_move":       "mouse.move",
    "mouse_scroll":     "mouse.scroll",
    "mouse_drag":       "mouse.drag",
    "keyboard_type":    "keyboard.type",
    "keyboard_hotkey":  "keyboard.hotkey",
    "clipboard_copy":   "clipboard.copy",
    "clipboard_paste":  "clipboard.paste",
    "browser_open":     "browser.open",
    "web_search":       "web.search",
    "file_write":       "file.write",
    "file_read":        "file.read",
    "file_list":        "file.list",
    "notify":           "notify",
    # camera_tools.py's real OS-level capture (cv2 / DirectShow on Windows,
    # AVFoundation on macOS, V4L2 on Linux). Was missing entirely until
    # 2026-08-12 (Aiden's "Iris") — webcam_capture only ever resolved
    # through server/helpers.py's browser-dashboard local_tool, which
    # requires a live getUserMedia stream and silently failed for any
    # customer talking to their SI without a dashboard tab open.
    "webcam_capture":   "webcam.capture",
}


# ── Phase-2 expansion: 100+ extra tools wired via tools_extra.py + CDP ──
# Programmatically registered to avoid 100 hand-written schemas. Each gets:
#   - underscore-form Anthropic name
#   - dotted actuator name
#   - risk level (low for read-only, medium for state-changing, high for the
#     dangerous ones)
#   - minimal Anthropic schema (object with additionalProperties: True so
#     Leon can pass whatever args the tool documents)
# Full descriptions live inside each tool function's docstring; the brief
# one-liner here is what Claude sees in the tool catalog.

_EXTRA_TOOL_SPECS = [
    # (anthropic_name, actuator_name, risk, brief description)
    # ── Window management ──
    ("window_resize",          "window.resize",          "medium", "Resize a window by title substring."),
    ("window_minimize",        "window.minimize",        "medium", "Minimize a window."),
    ("window_maximize",        "window.maximize",        "medium", "Maximize a window."),
    ("window_unmaximize",      "window.unmaximize",      "medium", "Restore a maximized window."),
    ("window_pin_always_on_top","window.pin_always_on_top","medium","Toggle always-on-top for a window."),
    ("window_position",        "window.position",        "medium", "Move a window to absolute (x,y)."),
    ("window_snap",            "window.snap",            "medium", "Snap window to a half of its current monitor (left/right/top/bottom)."),
    ("workspace_switch",       "workspace.switch",       "medium", "Switch to a virtual workspace by 0-indexed integer."),
    ("workspace_move_window",  "workspace.move_window",  "medium", "Move a window to another workspace."),
    ("desktop_show",           "desktop.show",           "medium", "Show the desktop (minimize all windows)."),
    # ── Mouse extensions ──
    ("mouse_double_click",     "mouse.double_click",     "medium", "Double-click at (x, y)."),
    ("mouse_triple_click",     "mouse.triple_click",     "medium", "Triple-click at (x, y) — line/paragraph select."),
    ("mouse_jiggle",           "mouse.jiggle",           "low",    "Jiggle mouse periodically to prevent screen lock."),
    ("mouse_position",         "mouse.position",         "low",    "Return current mouse cursor coords."),
    ("mouse_screen_to_monitor","mouse.screen_to_monitor","low",    "Return which monitor contains the given (x, y)."),
    # ── Keyboard extensions ──
    ("keyboard_paste_via_clipboard","keyboard.paste_via_clipboard","medium","Paste text by setting clipboard + ctrl+v (Unicode-safe)."),
    ("keyboard_press",         "keyboard.press",         "medium", "Press a single key N times (e.g. 'enter', 'tab')."),
    ("keyboard_down",          "keyboard.down",          "medium", "Press and hold a key (pair with keyboard_up)."),
    ("keyboard_up",            "keyboard.up",            "medium", "Release a held key."),
    # ── Clipboard extensions ──
    ("clipboard_clear",        "clipboard.clear",        "low",    "Clear the system clipboard."),
    ("clipboard_image_copy",   "clipboard.image_copy",   "medium", "Copy a PNG file to clipboard for paste into chat apps."),
    # ── Spotify (MPRIS) ──
    ("spotify_play_pause",     "spotify.play_pause",     "low",    "Toggle play/pause on Spotify."),
    ("spotify_next",           "spotify.next",           "low",    "Skip to next Spotify track."),
    ("spotify_previous",       "spotify.previous",       "low",    "Skip to previous Spotify track."),
    ("spotify_what_is_playing","spotify.what_is_playing","low",    "Return {title, artist, album, url} of current Spotify track."),
    ("spotify_volume",         "spotify.volume",         "low",    "Set Spotify volume 0-100."),
    # ── Apps & misc ──
    ("vscode_open_file",       "vscode.open_file",       "medium", "Open a file in VS Code."),
    ("vscode_open_folder",     "vscode.open_folder",     "medium", "Open a folder in VS Code."),
    ("terminal_spawn",         "terminal.spawn",         "medium", "Spawn a new gnome-terminal (optional cwd + initial command)."),
    ("files_open",             "files.open",             "medium", "Open a path with the default handler (xdg-open)."),
    ("screen_lock",            "screen.lock",            "high",   "Lock the screen (irreversible from Leon's side)."),
    # ── System info (read-only) ──
    ("system_resource_summary","system.resource_summary","low",    "CPU/RAM/disk/load summary."),
    ("system_temperature",     "system.temperature",     "low",    "CPU + GPU temps."),
    ("system_fan_speed",       "system.fan_speed",       "low",    "Fan RPMs from sensors."),
    ("system_battery",         "system.battery",         "low",    "Battery state (laptop only)."),
    ("system_uptime",          "system.uptime",          "low",    "Uptime in seconds + human form."),
    ("system_users_logged_in", "system.users_logged_in", "low",    "Currently-logged-in user sessions."),
    ("system_listening_ports", "system.listening_ports", "low",    "TCP listening ports + process names."),
    ("system_disk_io",         "system.disk_io",         "low",    "Cumulative disk I/O counters."),
    ("system_network_io",      "system.network_io",      "low",    "Per-interface network I/O counters."),
    ("system_gpu_state",       "system.gpu_state",       "low",    "NVIDIA GPU state (util/mem/temp/power)."),
    ("system_diskspace_by_dir","system.diskspace_by_dir","low",    "du-style space usage of a directory tree."),
    ("system_largest_files",   "system.largest_files",   "low",    "Find largest files under a root above a size threshold."),
    ("system_package_list",    "system.package_list",    "low",    "Installed dpkg package list (filterable)."),
    ("system_service_status",  "system.service_status",  "low",    "systemctl status for a service."),
    ("system_service_start",   "system.service_start",   "high",   "systemctl start (HIGH risk — starts services)."),
    ("system_service_stop",    "system.service_stop",    "high",   "systemctl stop (HIGH risk — stops services)."),
    ("system_service_restart", "system.service_restart", "high",   "systemctl restart (HIGH risk)."),
    ("system_service_logs",    "system.service_logs",    "low",    "journalctl tail for a service."),
    ("system_log_tail",        "system.log_tail",        "low",    "Tail a log file in /var/log, /tmp, project, or ~/.openclaw/logs."),
    ("system_cron_list",       "system.cron_list",       "low",    "List user + system cron entries."),
    # ── Process management ──
    ("process_list",           "process.list",           "low",    "Top N processes by cpu/mem/name."),
    ("process_find_by_name",   "process.find_by_name",   "low",    "Find all processes matching a name substring."),
    ("process_kill",           "process.kill",           "high",   "Kill a process by pid or name (HIGH risk)."),
    ("process_resource_usage", "process.resource_usage", "low",    "Detailed cpu/mem/threads/fds for a pid."),
    # ── File system extensions ──
    ("file_delete",            "file.delete",            "high",   "Trash a file via gio trash (recoverable but HIGH risk)."),
    ("file_move",              "file.move",              "medium", "Move/rename a file or directory."),
    ("file_copy",              "file.copy",              "medium", "Copy a file or directory."),
    ("file_chmod",             "file.chmod",             "medium", "Change file mode (octal like '755')."),
    ("file_size",              "file.size",              "low",    "File size in bytes + human form."),
    ("file_modified",          "file.modified",          "low",    "File modification time + age."),
    ("file_hash",              "file.hash",              "low",    "Hash a file (sha256/md5/etc)."),
    ("file_search_content",    "file.search_content",    "low",    "ripgrep over a tree for content matches."),
    ("file_search_name",       "file.search_name",       "low",    "find files/dirs by name pattern."),
    ("file_diff",              "file.diff",              "low",    "Unified diff between two files."),
    ("file_tail",              "file.tail",              "low",    "Last N lines of a file."),
    ("file_head",              "file.head",              "low",    "First N lines of a file."),
    ("file_grep",              "file.grep",              "low",    "Inline grep over a single file."),
    ("file_wordcount",         "file.wordcount",         "low",    "Lines/words/chars in a file."),
    ("file_pdfread",           "file.pdfread",           "low",    "Extract text from PDF (pdftotext)."),
    ("file_csv_read",          "file.csv_read",          "low",    "Read CSV rows as list of dicts."),
    ("file_json_query",        "file.json_query",        "low",    "jq query against a JSON file."),
    ("file_yaml_read",         "file.yaml_read",         "low",    "Read + parse a YAML file."),
    # ── Shell exec extensions ──
    ("shell_exec_in_dir",      "shell.exec_in_dir",      "high",   "Run shell command in specific cwd (HIGH risk)."),
    ("shell_exec_streaming",   "shell.exec_streaming",   "high",   "Stream shell stdout, keep last N lines (HIGH risk)."),
    ("shell_exec_background",  "shell.exec_background",  "high",   "Spawn shell command in background, return pid (HIGH risk)."),
    ("shell_exec_kill",        "shell.exec_kill",        "high",   "Kill a backgrounded pid (HIGH risk)."),
    ("shell_exec_status",      "shell.exec_status",      "low",    "Status + cpu/mem of a pid."),
    # ── Dotenv / git ──
    ("dotenv_read",            "dotenv.read",            "low",    "Read .env pairs (secrets auto-redacted)."),
    ("git_status",             "git.status",             "low",    "Git status + branch for a repo."),
    # ── CDP browser extensions ──
    ("browser_back",           "browser.back",           "medium", "Browser history back."),
    ("browser_forward",        "browser.forward",        "medium", "Browser history forward."),
    ("browser_reload",         "browser.reload",         "medium", "Reload current tab (hard=true skips cache)."),
    ("browser_close_tab",      "browser.close_tab",      "medium", "Close ONE browser tab (never the whole browser). Pass url_contains, or index (-1=last), or NO args to close the active/most-recent tab. This is what 'close it' means."),
    ("browser_new_tab",        "browser.new_tab",        "medium", "Open URL in a new tab (returns tab id)."),
    ("browser_switch_tab",     "browser.switch_tab",     "low",    "Activate a tab by url substring."),
    ("browser_list_tabs",      "browser.list_tabs",      "low",    "List all open browser tabs."),
    ("browser_dom_fill",       "browser.dom_fill",       "medium", "Fill an input/textarea/contenteditable by CSS selector."),
    ("browser_dom_select",     "browser.dom_select",     "medium", "Set a <select> dropdown value."),
    ("browser_dom_check",      "browser.dom_check",      "medium", "Set checkbox/radio checked state."),
    ("browser_dom_hover",      "browser.dom_hover",      "medium", "Synthetic hover on an element (for tooltips/menus)."),
    ("browser_dom_keydown",    "browser.dom_keydown",    "medium", "Dispatch keydown/keyup on a focused element."),
    ("browser_dom_wait_for",   "browser.dom_wait_for",   "low",    "Wait for selector/text to appear (timeout_ms)."),
    ("browser_dom_wait_for_text","browser.dom_wait_for_text","low","Wait for text to appear on page."),
    ("browser_dom_get_text",   "browser.dom_get_text",   "low",    "Get innerText of element matching selector."),
    ("browser_dom_set_value",  "browser.dom_set_value",  "medium", "Force-set input/textarea value (handles React)."),
    ("browser_get_html",       "browser.get_html",       "low",    "Get outerHTML of element or full document."),
    ("browser_get_url",        "browser.get_url",        "low",    "Current tab URL."),
    ("browser_get_title",      "browser.get_title",      "low",    "Current tab title."),
    ("browser_get_cookies",    "browser.get_cookies",    "low",    "List cookies (session/token/auth values redacted)."),
    ("browser_local_storage_get","browser.local_storage_get","low","Get a localStorage key value."),
    ("browser_console_logs",   "browser.console_logs",   "low",    "Captured browser console logs (requires shim)."),
    ("browser_set_viewport",   "browser.set_viewport",   "low",    "Emulate viewport size + mobile mode."),
    ("browser_zoom",           "browser.zoom",           "low",    "Set page zoom level."),
    ("browser_screenshot_full","browser.screenshot_full","low",    "Full-page screenshot via CDP (beyond viewport)."),
    ("browser_ensure_cdp",     "browser.ensure_cdp",     "medium", "Self-heal: relaunch Brave with the CDP debug port if not reachable (restores session)."),

    # ── Info tools (HTTP / external data) ───────────────────────────────
    ("info_weather_now",         "info.weather_now",         "low", "Current weather via wttr.in for a location (default: Dean's IP-resolved city)."),
    ("info_weather_forecast",    "info.weather_forecast",    "low", "Multi-day weather forecast via wttr.in."),
    ("info_news_hackernews_top", "info.news_hackernews_top", "low", "Top stories from Hacker News."),
    ("info_news_hackernews_ask", "info.news_hackernews_ask", "low", "Ask HN (questions to the community) top stories."),
    ("info_stock_price",         "info.stock_price",         "low", "Current stock quote via Yahoo Finance."),
    ("info_stock_search",        "info.stock_search",        "low", "Search stock tickers by name fragment."),
    ("info_crypto_price",        "info.crypto_price",        "low", "Crypto price via CoinGecko (btc, eth, ...)."),
    ("info_crypto_top10",        "info.crypto_top10",        "low", "Top 10 cryptos by market cap."),
    ("info_public_ip",           "info.public_ip",           "low", "Leon's public IP address."),
    ("info_ip_geolocation",      "info.ip_geolocation",      "low", "Approximate city/country for an IP (default: own)."),
    ("info_url_status_check",    "info.url_status_check",    "low", "HEAD-check a URL — does the site/page exist?"),
    ("info_time_in_zone",        "info.time_in_zone",        "low", "Current time in an IANA timezone (e.g. America/Los_Angeles)."),
    ("info_time_world_clock",    "info.time_world_clock",    "low", "Current time in multiple zones simultaneously."),
    ("info_random_quote",        "info.random_quote",        "low", "A random inspirational quote."),
    ("info_xkcd_today",          "info.xkcd_today",          "low", "Today's XKCD comic title + alt text + url."),
    ("info_github_user_info",    "info.github_user_info",    "low", "Public GitHub user profile."),
    ("info_github_repo_info",    "info.github_repo_info",    "low", "Public GitHub repo stats (stars, forks, language, recent commits)."),
    ("info_github_repo_trending","info.github_repo_trending","low", "GitHub trending repos (optional language filter)."),
    ("info_pypi_package_info",   "info.pypi_package_info",   "low", "PyPI package latest version + summary + author."),
    ("info_npm_package_info",    "info.npm_package_info",    "low", "npm package latest version + summary + author."),
    ("info_web_summarize_url",   "info.web_summarize_url",   "low", "Fetch + extract main text from a URL (no auth, public pages)."),

    # ── Browser apps (CDP helpers for YouTube/Gmail/Google/Twitter/Docs/Sheets/Notion) ──
    ("browser_youtube_play_video",       "browser.youtube_play_video",       "medium", "Click the Nth YouTube video on current page (0 = first)."),
    ("browser_youtube_play_pause",       "browser.youtube_play_pause",       "low",    "Toggle play/pause on a YouTube video."),
    ("browser_youtube_play",             "browser.youtube_play",             "low",    "Resume a paused YouTube video."),
    ("browser_youtube_pause",            "browser.youtube_pause",            "low",    "Pause a playing YouTube video."),
    ("browser_youtube_skip",             "browser.youtube_skip",             "low",    "Seek +seconds (positive) or -seconds (negative) within a YouTube video."),
    ("browser_youtube_speed",            "browser.youtube_speed",            "low",    "Set YouTube playback speed (0.25-2.0)."),
    ("browser_youtube_volume",           "browser.youtube_volume",           "low",    "Set YouTube volume 0-100."),
    ("browser_youtube_mute_toggle",      "browser.youtube_mute_toggle",      "low",    "Toggle YouTube mute."),
    ("browser_youtube_pip",              "browser.youtube_pip",              "medium", "Toggle picture-in-picture for current YouTube video."),
    ("browser_youtube_get_current_video","browser.youtube_get_current_video","low",    "{title, channel, url, time, duration} of currently-playing YouTube."),
    ("browser_youtube_get_transcript",   "browser.youtube_get_transcript",   "low",    "Open + scrape the transcript panel."),
    ("browser_gmail_inbox_state",        "browser.gmail_inbox_state",        "low",    f"Read the owner's Gmail — top visible threads (subject, sender, snippet, unread). This is the inbox already signed in to their Brave profile on CDP 9222{_OWNER_MAIL_HINT}. Use this (and browser navigation of mail.google.com) for ANY 'check/pull up my email' request. Do NOT use the email_gmail_* API tools (their OAuth isn't set up) and never trust a Gmail account other than the one signed in."),
    ("browser_gmail_open_thread",        "browser.gmail_open_thread",        "medium", "Open the Nth Gmail thread by index."),
    ("browser_gmail_archive_current",    "browser.gmail_archive_current",    "medium", "Archive the open Gmail thread."),
    ("browser_gmail_delete_current",     "browser.gmail_delete_current",     "high",   "Delete the open Gmail thread."),
    ("browser_gmail_mark_read",          "browser.gmail_mark_read",          "medium", "Mark the open Gmail thread as read."),
    ("browser_gmail_star_toggle",        "browser.gmail_star_toggle",        "medium", "Toggle star on the open Gmail thread."),
    ("browser_gmail_reply_to_current",   "browser.gmail_reply_to_current",   "medium", "Open reply composer on the current thread (does NOT send)."),
    ("browser_google_search_in_tab",     "browser.google_search_in_tab",     "medium", "Navigate the current tab to Google search results for query."),
    ("browser_google_search_silent",     "browser.google_search_silent",     "low",    "Headless-style: fetch top N Google results without changing user's current tab."),
    ("browser_twitter_post_compose",     "browser.twitter_post_compose",     "medium", "Open Twitter/X compose box pre-filled with text (does NOT post)."),
    ("browser_docs_insert_text",         "browser.docs_insert_text",         "medium", "Insert text at cursor in active Google Doc."),
    ("browser_sheets_set_cell",          "browser.sheets_set_cell",          "medium", "Set value of a cell (e.g. A1) in active Google Sheet."),
    ("browser_notion_create_block",      "browser.notion_create_block",      "medium", "Create a new block at cursor in active Notion page."),
    ("browser_web_app_active_tab",       "browser.web_app_active_tab",       "low",    "Detect which web app (gmail/youtube/docs/etc) is in the active Brave tab."),

    # ── Memory extras (brain-local — dispatched via local_tools, not actuator) ──
    ("memory_relationship_add",            "memory.relationship_add",            "low", "Add a person Dean knows (name, role, context)."),
    ("memory_relationship_update",         "memory.relationship_update",         "low", "Update fields of a known person."),
    ("memory_relationship_recall",         "memory.relationship_recall",         "low", "Get full record for a person by name."),
    ("memory_relationship_list",           "memory.relationship_list",           "low", "List all known people (optionally filtered)."),
    ("memory_relationship_log_interaction","memory.relationship_log_interaction","low", "Log a touchpoint with a person (date + note)."),
    ("memory_relationship_search",         "memory.relationship_search",         "low", "Search people by name/role/context substring."),
    ("memory_decision_log",                "memory.decision_log",                "low", "Record a decision Dean (or you+Dean) made, with reasoning."),
    ("memory_decision_recall",             "memory.decision_recall",             "low", "Find a logged decision by topic keyword."),
    ("memory_decision_list_recent",        "memory.decision_list_recent",        "low", "Recent decisions ordered by date."),
    ("memory_preference_log",              "memory.preference_log",              "low", "Record one of Dean's preferences (e.g. 'wakes by 8am')."),
    ("memory_preference_recall",           "memory.preference_recall",           "low", "Recall preference by topic keyword."),
    ("memory_preference_list_all",         "memory.preference_list_all",         "low", "List all of Dean's preferences."),
    ("memory_glossary_add",                "memory.glossary_add",                "low", "Add a project-specific term (acronym, name) to the glossary."),
    ("memory_glossary_lookup",             "memory.glossary_lookup",             "low", "Look up a glossary term."),
    ("memory_glossary_list",               "memory.glossary_list",               "low", "List all glossary terms."),
    ("memory_correction_log",              "memory.correction_log",              "low", "Log a correction: I was wrong about X, the truth is Y."),
    ("memory_correction_list",             "memory.correction_list",             "low", "Recent corrections so you don't repeat the same mistake."),
    ("memory_episode_log",                 "memory.episode_log",                 "low", "Record an episode/event with timestamp + descriptors."),
    ("memory_episode_search",              "memory.episode_search",              "low", "Search episode log by keyword/date range."),
    ("memory_mood_log_add",                "memory.mood_log_add",                "low", "Record Dean's mood/energy data point."),
    ("memory_mood_recent_trend",           "memory.mood_recent_trend",           "low", "Aggregate recent mood — flag low-energy streaks."),
    ("memory_knowledge_add",               "memory.knowledge_add",               "low", "Add a fact to the long-term knowledge_store."),
    ("memory_knowledge_delete",            "memory.knowledge_delete",            "low", "Delete a knowledge fact by id."),
    ("memory_knowledge_update",            "memory.knowledge_update",            "low", "Update a knowledge fact by id."),
    ("memory_knowledge_stats",             "memory.knowledge_stats",             "low", "Counts of knowledge facts grouped by source/type."),
    ("memory_user_profile_get",            "memory.user_profile_get",            "low", "Read USER.md (Dean's profile loaded at boot)."),
    ("memory_user_profile_update",         "memory.user_profile_update",         "low", "Edit a section of USER.md."),

    # ── Introspection / audit / undo / prompt versioning (brain-local) ──
    ("audit_today",                "audit.today",                "low", "Read today's actuator audit lines (raw)."),
    ("audit_summary_today",        "audit.summary_today",        "low", "Aggregate counts of tools called today."),
    ("audit_summary_range",        "audit.summary_range",        "low", "Audit aggregate over a date range."),
    ("audit_by_tool",              "audit.by_tool",              "low", "All audit lines for a specific tool name."),
    ("audit_errors_today",         "audit.errors_today",         "low", "Today's failed tool calls (ok=false)."),
    ("audit_tool_usage_stats",     "audit.tool_usage_stats",     "low", "Per-tool count + success-rate over N days."),
    ("audit_anomaly_detector",     "audit.anomaly_detector",     "low", "Detect today's outliers vs baseline usage."),
    ("audit_failure_clusters",     "audit.failure_clusters",     "low", "Group recurring failure patterns from audit log."),
    ("audit_postmortem_yesterday", "audit.postmortem_yesterday", "low", "Self-postmortem: what went well/wrong yesterday."),
    ("audit_today_overview",       "audit.today_overview",       "low", "High-level overview of today's Leon activity."),
    ("routine_audit_today",        "routine.audit_today",        "low", "Today's routine-execution audit entries."),
    ("routine_audit_by_name",      "routine.audit_by_name",      "low", "Audit history for a specific routine."),
    ("audit_capability_gap_report","audit.capability_gap_report","low", "Find recurring failures suggesting a missing capability."),
    ("prompt_save_version",        "prompt.save_version",        "low", "Snapshot current _STABLE_SYSTEM prompt as a version."),
    ("prompt_list_versions",       "prompt.list_versions",       "low", "List saved prompt versions."),
    ("prompt_load_version",        "prompt.load_version",        "low", "Read a saved prompt version (for compare/rollback)."),
    ("audit_tool_latency_report",  "audit.tool_latency_report",  "low", "Per-tool latency percentiles from audit log."),
    ("undo_record",                "undo.record",                "low", "Record an undo-able action (auto-called by code_edit/file_write)."),
    ("undo_recent",                "undo.recent",                "low", "Recent undo-able actions (newest first)."),
    ("undo_apply_last",            "undo.apply_last",            "medium", "Apply the inverse of the last recorded undo entry."),

    # ── Tentacle orchestration (brain-local) ─────────────────────────────
    ("tentacle_list_active",      "tentacle.list_active",      "low",    "List active tentacle windows in the `agents` tmux session."),
    ("tentacle_peek_tail",        "tentacle.peek_tail",        "low",    "Capture last N lines from a tentacle's tmux pane (read-only)."),
    ("tentacle_delegate_task",    "tentacle.delegate_task",    "medium", "Send a task into a tentacle's Claude session via tmux send-keys."),
    ("tentacle_query_status",     "tentacle.query_status",     "low",    "What is a tentacle doing now? Last 8 lines + heuristic state."),
    ("tentacle_health",           "tentacle.health",           "low",    "Detect stuck/looping tentacles by sampling pane content over a wait."),
    ("tentacle_broadcast",        "tentacle.broadcast",        "medium", "Send same task to multiple tentacles at once."),
    ("tentacle_spawn_ephemeral",  "tentacle.spawn_ephemeral",  "medium", "Create a new tmux window for a one-shot tentacle task."),
    ("tentacle_close_ephemeral",  "tentacle.close_ephemeral",  "medium", "Kill an ephemeral tmux window (protected names refused)."),
    ("tentacle_list_registry",    "tentacle.list_registry",    "low",    "Read openclaw agent-board registry of known tentacle projects."),
    ("tentacle_handoff",          "tentacle.handoff",          "medium", "Transfer a multi-turn conversation to a specialized tentacle."),
    ("board_submit_request",      "board.submit_request",      "medium", "Write a request file to ~/.openclaw/agent-board/requests/ for async pickup."),
    ("board_list_pending",        "board.list_pending",        "low",    "List all pending agent-board requests."),
    ("board_read_result",         "board.read_result",         "low",    "Read a result file from the agent-board by id or filename."),

    # ── Synthesis reports (brain-local) ──────────────────────────────────
    ("report_daily_briefing",        "report.daily_briefing",        "low", "Compose Dean's morning briefing (weather + news + mood + yesterday's postmortem)."),
    ("report_end_of_day",            "report.end_of_day",            "low", "Compose Dean's end-of-day summary (activity + episodes + decisions + anomalies)."),
    ("report_capability_summary",    "report.capability_summary",    "low", "Roll-up of Leon's current tool surface grouped by category."),
    ("report_status_pulse",          "report.status_pulse",          "low", "One-line heartbeat: tools/routines/tentacles + last action."),
    ("report_project_status_roundup","report.project_status_roundup","low", "Per-tentacle one-line status across the agent-board fleet."),

    # ── Presence / awareness (brain-local) ───────────────────────────────
    ("presence_dashboard_event",      "presence.dashboard_event",      "low", "Push a structured event to the dashboard observation feed."),
    ("presence_dashboard_log_recent", "presence.dashboard_log_recent", "low", "Read recent dashboard feed events from the ring buffer."),
    ("presence_desktop_notify",       "presence.desktop_notify",       "low", "Show a desktop notification (notify-send wrapper)."),
    ("presence_play_chime",           "presence.play_chime",           "low", "Play an audio cue: success/error/notify/alert/bell."),
    ("presence_tts_say",              "presence.tts_say",              "low", "Speak a string via the existing TTS engine (bypasses responder)."),
    ("presence_voice_tone_set",       "presence.voice_tone_set",       "low", "Set Leon's spoken tone preset (formal/casual/urgent/quiet/playful)."),
    ("presence_voice_tone_get",       "presence.voice_tone_get",       "low", "Return the current voice tone preset."),
    ("presence_idle_check",           "presence.idle_check",           "low", "Seconds since last X11 input event (Dean's afk-ness)."),
    ("presence_is_dean_present",      "presence.is_dean_present",      "low", "Webcam + Moondream2 'is a person visible' check."),
    ("presence_set_status_message",   "presence.set_status_message",   "low", "Set a status message in the dashboard status bar."),

    # ── Phase 4: integrations (Discord/Slack/Telegram + smart-home + phone) + self-improve ──
    # -- discord --
    ('discord_send_message'                , 'discord.send_message'                , 'medium', 'POST a message to a Discord channel.'),
    ('discord_send_dm'                     , 'discord.send_dm'                     , 'medium', 'Open (or fetch) a DM channel with a user and post to it.'),
    ('discord_list_recent_messages'        , 'discord.list_recent_messages'        , 'low'   , 'GET recent messages from a channel (default limit=20, max 100).'),
    ('discord_list_channels'               , 'discord.list_channels'               , 'low'   , 'List text/voice channels in a guild.'),
    ('discord_list_guilds'                 , 'discord.list_guilds'                 , 'low'   , 'List guilds (servers) the bot belongs to.'),
    ('discord_edit_message'                , 'discord.edit_message'                , 'medium', 'PATCH a previously-sent message.'),
    ('discord_delete_message'              , 'discord.delete_message'              , 'high'  , 'DELETE a message.'),
    ('discord_add_reaction'                , 'discord.add_reaction'                , 'medium', 'Add an emoji reaction to a message. Emoji may be a unicode char or `name:id` for custom.'),
    ('discord_poll_mentions'               , 'discord.poll_mentions'               , 'low'   , 'Scan recent messages across guild channels for mentions of the bot.'),
    ('discord_set_status'                  , 'discord.set_status'                  , 'medium', 'Stub — setting bot presence requires a gateway (websocket) connection.'),
    # -- slack --
    ('slack_send_message'                  , 'slack.send_message'                  , 'medium', 'chat.postMessage — send `text` to `channel` (id or name with #).'),
    ('slack_list_channels'                 , 'slack.list_channels'                 , 'low'   , 'conversations.list — public + private channels the bot can see.'),
    ('slack_list_users'                    , 'slack.list_users'                    , 'low'   , 'users.list — directory.'),
    ('slack_poll_mentions'                 , 'slack.poll_mentions'                 , 'low'   , "search.messages for the bot's own @mention. Needs `search:read` scope"),
    ('slack_upload_file'                   , 'slack.upload_file'                   , 'low'   , 'files.upload — attach a file from disk into `channel` with optional comment.'),
    ('slack_add_reaction'                  , 'slack.add_reaction'                  , 'medium', 'reactions.add — emoji name without colons (e.g. `thumbsup`).'),
    # -- telegram --
    ('telegram_send_message'               , 'telegram.send_message'               , 'medium', 'sendMessage — text to a chat_id.'),
    ('telegram_send_photo'                 , 'telegram.send_photo'                 , 'medium', 'sendPhoto — upload an image file with optional caption.'),
    ('telegram_get_updates'                , 'telegram.get_updates'                , 'low'   , 'getUpdates — short-poll for new messages (offset = last update_id + 1).'),
    ('telegram_set_webhook'                , 'telegram.set_webhook'                , 'medium', 'setWebhook — register a public URL to receive updates.'),
    # -- comms --
    ('comms_webhook_post'                  , 'comms.webhook_post'                  , 'medium', 'Generic JSON POST to a whitelisted host. `json_payload` is the body.'),
    ('comms_send_via_best'                 , 'comms.send_via_best'                 , 'medium', 'Heuristic router — pick discord/slack/telegram based on `channel` shape.'),
    ('comms_list_all_unread'               , 'comms.list_all_unread'               , 'low'   , 'Aggregate poll across Discord mentions, Slack mentions, and Telegram updates.'),
    # -- home --
    ('home_ha_get_state'                   , 'home.ha_get_state'                   , 'low'   , 'GET /api/states/{entity_id} — current state + attributes of one entity.'),
    ('home_ha_list_entities'               , 'home.ha_list_entities'               , 'low'   , 'GET /api/states — list all entities, optionally filtered by domain prefix.'),
    ('home_ha_call_service'                , 'home.ha_call_service'                , 'low'   , 'POST /api/services/{domain}/{service} — generic HA service call.'),
    ('home_ha_turn_on'                     , 'home.ha_turn_on'                     , 'medium', 'Convenience: call homeassistant.turn_on on any entity.'),
    ('home_ha_turn_off'                    , 'home.ha_turn_off'                    , 'medium', 'Convenience: call <domain>.turn_off on any entity.'),
    ('home_ha_toggle'                      , 'home.ha_toggle'                      , 'medium', 'Convenience: toggle any entity.'),
    ('home_ha_get_history'                 , 'home.ha_get_history'                 , 'low'   , 'GET /api/history/period — recent state history for an entity.'),
    ('home_ha_get_logbook'                 , 'home.ha_get_logbook'                 , 'low'   , 'GET /api/logbook — recent human-readable events.'),
    ('home_ha_render_template'             , 'home.ha_render_template'             , 'low'   , 'POST /api/template — render a Jinja template against HA state.'),
    ('home_lights_on'                      , 'home.lights_on'                      , 'low'   , 'Turn lights on. Optional `area` (room name or full entity_id), `brightness` 0-255.'),
    ('home_lights_off'                     , 'home.lights_off'                     , 'low'   , 'Turn lights off. Optional `area` (room name or full entity_id).'),
    ('home_lights_dim'                     , 'home.lights_dim'                     , 'low'   , 'Dim lights in area to `percent` (0-100). Converts to HA brightness 0-255.'),
    ('home_lights_set_color'               , 'home.lights_set_color'               , 'medium', 'Set light color by name (red/cyan/warm/…) or hex (#ff00aa).'),
    ('home_lights_scene'                   , 'home.lights_scene'                   , 'low'   , 'Activate scene.{name} via HA scene.turn_on.'),
    ('home_hue_list_lights'                , 'home.hue_list_lights'                , 'low'   , 'GET /api/{user}/lights — all Hue lights on the bridge.'),
    ('home_hue_set_light'                  , 'home.hue_set_light'                  , 'medium', 'PUT /api/{user}/lights/{id}/state — set on/brightness/hue/sat on one Hue light.'),
    ('home_hue_list_groups'                , 'home.hue_list_groups'                , 'low'   , 'GET /api/{user}/groups — Hue rooms / zones.'),
    ('home_govee_list_devices'             , 'home.govee_list_devices'             , 'low'   , 'GET https://developer-api.govee.com/v1/devices — list Govee devices.'),
    ('home_govee_set_power'                , 'home.govee_set_power'                , 'medium', 'PUT /v1/devices/control — turn Govee device on/off.'),
    ('home_govee_set_brightness'           , 'home.govee_set_brightness'           , 'medium', 'PUT /v1/devices/control — set Govee brightness 0-100.'),
    ('home_kasa_list_devices'              , 'home.kasa_list_devices'              , 'low'   , 'Discover Kasa devices on the local network (requires python-kasa).'),
    ('home_kasa_turn_on'                   , 'home.kasa_turn_on'                   , 'medium', 'Turn a Kasa device on by alias or IP.'),
    ('home_kasa_turn_off'                  , 'home.kasa_turn_off'                  , 'medium', 'Turn a Kasa device off by alias or IP.'),
    ('home_thermostat_set_target'          , 'home.thermostat_set_target'          , 'low'   , 'Call climate.set_temperature on a thermostat entity (temperature in F).'),
    ('home_thermostat_get_state'           , 'home.thermostat_get_state'           , 'low'   , 'Read current state + attributes of a climate entity.'),
    ('home_thermostat_set_mode'            , 'home.thermostat_set_mode'            , 'medium', 'Set HVAC mode (heat/cool/auto/off/heat_cool/fan_only/dry) on a climate entity.'),
    ('home_sensor_read'                    , 'home.sensor_read'                    , 'low'   , 'Read any HA sensor entity — returns state + unit if available.'),
    ('home_sensor_list_temperature'        , 'home.sensor_list_temperature'        , 'low'   , 'Find all temperature sensors in HA (entity ends in _temperature or device_class=temperature).'),
    ('home_sensor_list_humidity'           , 'home.sensor_list_humidity'           , 'low'   , 'Find all humidity sensors in HA.'),
    ('home_sensor_door_state'              , 'home.sensor_door_state'              , 'low'   , 'Read a binary_sensor and translate to open/closed.'),
    ('home_scene_define'                   , 'home.scene_define'                   , 'low'   , 'Save a scene definition: list of {tool, args} actions to run in order.'),
    ('home_scene_run'                      , 'home.scene_run'                      , 'medium', "Run a saved scene — each action's tool is looked up in EXTRA_TOOLS."),
    ('home_scene_list'                     , 'home.scene_list'                     , 'low'   , 'List all defined scene names + action counts.'),
    ('home_scene_delete'                   , 'home.scene_delete'                   , 'high'  , 'Delete a saved scene by name.'),
    ('home_ifttt_trigger'                  , 'home.ifttt_trigger'                  , 'medium', 'POST to https://maker.ifttt.com/trigger/{event}/with/key/{IFTTT_KEY}.'),
    ('home_mqtt_publish'                   , 'home.mqtt_publish'                   , 'medium', 'Publish one message to an MQTT topic (requires paho-mqtt).'),
    # -- phone --
    ('phone_kde_list_devices'              , 'phone.kde_list_devices'              , 'low'   , 'List paired/available KDE Connect devices. Returns id+name+status'),
    ('phone_kde_send_sms'                  , 'phone.kde_send_sms'                  , 'high'  , "Send an SMS from Dean's phone via KDE Connect."),
    ('phone_kde_ring'                      , 'phone.kde_ring'                      , 'medium', 'Ring the phone to find it. Args: device_id (optional).'),
    ('phone_kde_battery'                   , 'phone.kde_battery'                   , 'low'   , "Read phone battery level. Tries qdbus first, then KDE Connect's"),
    ('phone_kde_share_url'                 , 'phone.kde_share_url'                 , 'medium', "Open a URL on the phone (KDE Connect's Share plugin)."),
    ('phone_kde_share_text'                , 'phone.kde_share_text'                , 'medium', "Push text to the phone's clipboard via KDE Connect's --share-text."),
    ('phone_kde_send_file'                 , 'phone.kde_send_file'                 , 'medium', 'Send a file to the phone. Args: file_path, device_id (optional).'),
    ('phone_kde_notification'              , 'phone.kde_notification'              , 'medium', 'Push a notification to the phone. Args: title, message, device_id (optional).'),
    ('phone_kde_read_notifications'        , 'phone.kde_read_notifications'        , 'low'   , 'Read recent phone notifications cached by KDE Connect under'),
    ('phone_kde_pair_status'               , 'phone.kde_pair_status'               , 'low'   , 'Report pair status for a given device. Args: device_id (required).'),
    ('phone_twilio_send_sms'               , 'phone.twilio_send_sms'               , 'high'  , 'Send an SMS via Twilio. Args: to_number, message.'),
    ('phone_twilio_send_mms'               , 'phone.twilio_send_mms'               , 'medium', 'Send an MMS via Twilio. Args: to_number, message, media_url.'),
    ('phone_twilio_make_call'              , 'phone.twilio_make_call'              , 'high'  , 'Initiate a phone call via Twilio. Args: to_number, twiml_url_or_text.'),
    ('phone_twilio_list_recent_sms'        , 'phone.twilio_list_recent_sms'        , 'low'   , 'List recent SMS messages. Args: limit (default 20).'),
    ('phone_twilio_list_recent_calls'      , 'phone.twilio_list_recent_calls'      , 'low'   , 'List recent calls. Args: limit (default 20).'),
    ('phone_twilio_account_balance'        , 'phone.twilio_account_balance'        , 'low'   , 'Get the Twilio account balance.'),
    ('phone_dial_number'                   , 'phone.dial_number'                   , 'low'   , "Open a tel:// URI via xdg-open — KDE Connect's phone-link picks"),
    ('phone_contacts_search'               , 'phone.contacts_search'               , 'low'   , 'Search contacts by name (case-insensitive substring). Checks'),
    ('phone_contacts_add'                  , 'phone.contacts_add'                  , 'medium', 'Add or upsert a contact in brain_state/contacts.json.'),
    ('phone_contacts_list'                 , 'phone.contacts_list'                 , 'low'   , 'List all contacts in brain_state/contacts.json.'),
    # -- selftest --
    ('selftest_run_battery'                , 'selftest.run_battery'                , 'low'   , 'Run a saved test battery. If `suite_name` is None, run every'),
    ('selftest_list_suites'                , 'selftest.list_suites'                , 'low'   , 'List every suite JSON file under brain_state/selftest-suites/.'),
    ('selftest_save_suite'                 , 'selftest.save_suite'                 , 'low'   , 'Write a list of tests to brain_state/selftest-suites/{name}.json.'),
    ('selftest_smoke_actuator'             , 'selftest.smoke_actuator'             , 'low'   , 'Quick health probe of three core actuator tools. Reports each'),
    ('selftest_smoke_memory'               , 'selftest.smoke_memory'               , 'low'   , 'Round-trip a glossary entry: add → lookup → delete. Verifies'),
    ('selftest_smoke_brain'                , 'selftest.smoke_brain'                , 'low'   , 'Round-trip the knowledge store: add a test entry, search for'),
    # -- code --
    ('code_scan_largest_files'             , 'code.scan_largest_files'             , 'low'   , 'List .py files under `root` by line count, descending.'),
    ('code_scan_dead_imports'              , 'code.scan_dead_imports'              , 'low'   , 'Naive dead-import detector: for each top-level import in each'),
    ('code_scan_todo_comments'             , 'code.scan_todo_comments'             , 'low'   , 'Grep for TODO / FIXME / XXX / HACK markers (case-insensitive)'),
    ('code_scan_long_functions'            , 'code.scan_long_functions'            , 'low'   , 'Find function/method definitions over `threshold_lines` long.'),
    ('code_scan_missing_docstrings'        , 'code.scan_missing_docstrings'        , 'low'   , 'Find public (non-underscore-prefixed) functions, methods, and'),
    ('code_dependency_graph'               , 'code.dependency_graph'               , 'low'   , 'Parse the imports of a single Python file. Returns the imported'),
    ('code_audit_jsonl_size_check'         , 'code.audit_jsonl_size_check'         , 'low'   , 'Check the size of audit log files. Warns if any is over 100MB.'),
    # -- meta --
    ('meta_list_recent_failures'           , 'meta.list_recent_failures'           , 'low'   , 'Read the actuator audit log and surface failure clusters with'),
    ('meta_snapshot_brain_state'           , 'meta.snapshot_brain_state'           , 'low'   , 'Copy brain_state/ to brain_state-snapshots/{label}_{ts}/.'),
    ('meta_snapshot_list'                  , 'meta.snapshot_list'                  , 'low'   , 'List available brain_state snapshots, newest first.'),
    ('meta_snapshot_restore'               , 'meta.snapshot_restore'               , 'high'  , 'Restore brain_state/ from a previously created snapshot.'),
    ('meta_prompt_ab_compare'              , 'meta.prompt_ab_compare'              , 'low'   , 'Run two prompts against the same set of inputs via the'),
    ('meta_config_get'                     , 'meta.config_get'                     , 'low'   , 'Read a key (dotted path) from brain_state/config.json. Pass'),
    ('meta_config_set'                     , 'meta.config_set'                     , 'medium', 'Set a key (dotted path) in brain_state/config.json. Intermediate'),
    ('meta_routine_proposal_from_audit'    , 'meta.routine_proposal_from_audit'    , 'low'   , 'Analyze the audit log for repeated manual patterns and suggest'),
    # -- reliability --
    ('reliability_retry_last_failure'      , 'reliability.retry_last_failure'      , 'low'   , 'Replay the most recent failed tool call from the audit log,'),
    ('reliability_healthcheck_all'         , 'reliability.healthcheck_all'         , 'low'   , 'Comprehensive health probe: actuator socket, WS clients,'),

    # ── Macros (high-level multi-step routines) ──────────────────────────
    ("macro_list",           "macro.list",           "low",    "List all available macros — builtins + custom."),
    ("macro_run",            "macro.run",            "medium", "Run a macro by name — executes its step list in order."),
    ("macro_run_if_present", "macro.run_if_present", "low",    "Run macro if defined, no-op success if missing (for routines)."),
    ("macro_define",         "macro.define",         "medium", "Save a custom macro (or override a builtin) — name + steps list."),
    ("macro_delete",         "macro.delete",         "medium", "Delete a custom macro (builtins can be overridden but not deleted)."),
    ("macro_dry_run",        "macro.dry_run",        "low",    "Show the steps a macro would execute without running them."),
    ("macro_last_runs",      "macro.last_runs",      "low",    "Read the macro audit log — recent macro runs and outcomes."),

    # ── Phase 5: research / productivity / AI providers / life ────────────
    # -- research --
    ('research_wikipedia_summary'              , 'research.wikipedia_summary'              , 'low'   , 'REST summary for a Wikipedia article.'),
    ('research_wikipedia_search'               , 'research.wikipedia_search'               , 'low'   , 'OpenSearch on Wikipedia — returns list of {title, description, url}.'),
    ('research_wikipedia_full_content'         , 'research.wikipedia_full_content'         , 'low'   , 'Full plaintext extract of a Wikipedia article (optionally limited to'),
    ('research_wikipedia_random'               , 'research.wikipedia_random'               , 'low'   , 'Return a random Wikipedia article summary.'),
    ('research_arxiv_search'                   , 'research.arxiv_search'                   , 'low'   , 'Search arXiv via the public Atom API.'),
    ('research_arxiv_recent'                   , 'research.arxiv_recent'                   , 'low'   , 'Recent arXiv papers in a given category (e.g. cs.AI, cs.CL).'),
    ('research_arxiv_get_paper'                , 'research.arxiv_get_paper'                , 'low'   , "Fetch a single arXiv paper by ID (e.g. '2401.12345')."),
    ('research_reddit_top'                     , 'research.reddit_top'                     , 'low'   , 'Top posts of a subreddit. time in {hour, day, week, month, year, all}.'),
    ('research_reddit_hot'                     , 'research.reddit_hot'                     , 'low'   , 'Hot posts of a subreddit.'),
    ('research_reddit_search'                  , 'research.reddit_search'                  , 'low'   , 'Search Reddit (optionally scoped to a subreddit).'),
    ('research_reddit_comments'                , 'research.reddit_comments'                , 'low'   , 'First-level comments on a post by ID.'),
    ('research_rss_fetch'                      , 'research.rss_fetch'                      , 'low'   , 'Fetch & parse an RSS/Atom feed. Uses feedparser if available.'),
    ('research_rss_subscribe'                  , 'research.rss_subscribe'                  , 'low'   , 'Persist a named RSS subscription.'),
    ('research_rss_list_subscriptions'         , 'research.rss_list_subscriptions'         , 'low'   , 'List all RSS subscriptions.'),
    ('research_rss_check_all'                  , 'research.rss_check_all'                  , 'low'   , 'Fetch all subscriptions, return items newer than last-check timestamp.'),
    ('research_dictionary_lookup'              , 'research.dictionary_lookup'              , 'low'   , 'Dictionary definition via dictionaryapi.dev.'),
    ('research_thesaurus_synonyms'             , 'research.thesaurus_synonyms'             , 'low'   , 'Pull synonyms (and antonyms) out of the dictionary API.'),
    ('research_translate'                      , 'research.translate'                      , 'low'   , 'Translate text via MyMemory free translation API.'),
    ('research_urban_dictionary'               , 'research.urban_dictionary'               , 'low'   , 'Look up a term on Urban Dictionary.'),
    ('research_wolfram_short_answer'           , 'research.wolfram_short_answer'           , 'low'   , 'Wolfram Alpha short-answer endpoint. Requires WOLFRAM_APP_ID env var.'),
    ('research_wolfram_full'                   , 'research.wolfram_full'                   , 'low'   , 'Wolfram Alpha full v2/query API. Returns parsed pods.'),
    ('research_dad_joke'                       , 'research.dad_joke'                       , 'low'   , 'Random dad joke via icanhazdadjoke.com.'),
    ('research_cat_fact'                       , 'research.cat_fact'                       , 'low'   , 'Random cat fact via catfact.ninja.'),
    ('research_bored_activity'                 , 'research.bored_activity'                 , 'low'   , 'Random activity suggestion via boredapi.com.'),
    ('research_nasa_apod'                      , 'research.nasa_apod'                      , 'low'   , 'NASA Astronomy Picture of the Day. Uses NASA_API_KEY if set, else DEMO_KEY.'),
    ('research_podcast_search'                 , 'research.podcast_search'                 , 'low'   , 'Search podcasts via the iTunes Search API.'),
    # -- task --
    ('task_add'                                , 'task.add'                                , 'medium', 'Add a new task. Returns the inserted row.'),
    ('task_list'                               , 'task.list'                               , 'low'   , 'List tasks. status in {open, done, all}; optional project filter.'),
    ('task_complete'                           , 'task.complete'                           , 'medium', 'Mark a task done. Sets completed_at to now.'),
    ('task_reopen'                             , 'task.reopen'                             , 'low'   , 'Re-open a previously completed task.'),
    ('task_delete'                             , 'task.delete'                             , 'high'  , 'Delete a task permanently.'),
    ('task_update'                             , 'task.update'                             , 'low'   , 'Update fields on a task. Accepts title, priority, due_date, tags,'),
    ('task_search'                             , 'task.search'                             , 'low'   , 'Substring search over task titles (case-insensitive).'),
    ('task_today'                              , 'task.today'                              , 'low'   , 'Open tasks with due_date today or overdue.'),
    ('task_this_week'                          , 'task.this_week'                          , 'low'   , 'Open tasks due within the next 7 days.'),
    ('task_summary'                            , 'task.summary'                            , 'low'   , 'Counts of tasks broken down by status and priority.'),
    # -- journal --
    ('journal_entry_add'                       , 'journal.entry_add'                       , 'medium', 'Add a journal entry. mood is free-form string.'),
    ('journal_entry_list'                      , 'journal.entry_list'                      , 'low'   , 'List journal entries newest first. Optional `since` (epoch seconds'),
    ('journal_entry_search'                    , 'journal.entry_search'                    , 'low'   , 'Substring search over journal entry_text.'),
    ('journal_today_summary'                   , 'journal.today_summary'                   , 'low'   , "All of today's journal entries concatenated, plus mood list."),
    ('journal_this_week_digest'                , 'journal.this_week_digest'                , 'low'   , "Bullet digest of this week's journal entries (one bullet per entry,"),
    # -- habit --
    ('habit_define'                            , 'habit.define'                            , 'low'   , 'Create (or upsert) a habit definition.'),
    ('habit_list'                              , 'habit.list'                              , 'low'   , 'List all defined habits.'),
    ('habit_complete'                          , 'habit.complete'                          , 'medium', 'Log a habit completion now.'),
    ('habit_streak'                            , 'habit.streak'                            , 'low'   , 'Current consecutive-day streak for a habit. Today counts only if'),
    ('habit_weekly_progress'                   , 'habit.weekly_progress'                   , 'low'   , 'Completions this week vs target.'),
    ('habit_all_progress'                      , 'habit.all_progress'                      , 'low'   , 'Weekly progress summary across all habits.'),
    # -- time --
    ('time_start'                              , 'time.start'                              , 'medium', 'Start a timer. Auto-stops any currently-running timer first.'),
    ('time_stop'                               , 'time.stop'                               , 'low'   , 'Stop the active timer.'),
    ('time_current'                            , 'time.current'                            , 'low'   , "What's running right now and how long it's been."),
    ('time_list_recent'                        , 'time.list_recent'                        , 'low'   , 'Most recent time entries.'),
    ('time_daily_summary'                      , 'time.daily_summary'                      , 'low'   , 'Per-project time totals for a date (default today).'),
    ('time_weekly_summary'                     , 'time.weekly_summary'                     , 'low'   , 'Per-project time totals for the current week (Mon–Sun).'),
    # -- pomodoro --
    ('pomodoro_start'                          , 'pomodoro.start'                          , 'medium', 'Start a pomodoro. Default 25 min. Best-effort presence status update.'),
    ('pomodoro_status'                         , 'pomodoro.status'                         , 'low'   , 'Active pomodoro state + remaining seconds.'),
    ('pomodoro_cancel'                         , 'pomodoro.cancel'                         , 'low'   , 'Abort current pomodoro (marks ended_at but completed=0).'),
    ('pomodoro_complete'                       , 'pomodoro.complete'                       , 'medium', 'Mark current pomodoro complete and play success chime.'),
    ('pomodoro_history'                        , 'pomodoro.history'                        , 'low'   , 'Recent pomodoros.'),
    # -- focus --
    ('focus_start'                             , 'focus.start'                             , 'medium', 'Start a longer focus block. Default 90 min.'),
    ('focus_distraction'                       , 'focus.distraction'                       , 'low'   , 'Increment distraction counter on the current focus block.'),
    ('focus_end'                               , 'focus.end'                               , 'low'   , 'Close the current focus block.'),
    ('focus_history'                           , 'focus.history'                           , 'low'   , 'Recent focus blocks.'),
    # -- review --
    ('review_daily'                            , 'review.daily'                            , 'low'   , 'Composite daily review: tasks completed, habits done, time by project,'),
    ('review_weekly'                           , 'review.weekly'                           , 'low'   , 'Composite weekly review for the current week (Mon–Sun).'),
    # -- ai --
    ('ai_openai_chat'                          , 'ai.openai_chat'                          , 'low'   , 'OpenAI Chat Completions. args: prompt, model, system, max_tokens.'),
    ('ai_openai_complete'                      , 'ai.openai_complete'                      , 'medium', 'Convenience: same as openai_chat but minimal args.'),
    ('ai_openai_embed'                         , 'ai.openai_embed'                         , 'low'   , 'OpenAI embeddings. args: text, model.'),
    ('ai_openai_image_generate'                , 'ai.openai_image_generate'                , 'medium', 'DALL-E image generation. args: prompt, size, quality, model, save_to.'),
    ('ai_openai_image_variation'               , 'ai.openai_image_variation'               , 'medium', 'DALL-E 2 image variation. args: image_path, n, size.'),
    ('ai_openai_transcribe'                    , 'ai.openai_transcribe'                    , 'medium', 'Whisper transcription. args: audio_path, model.'),
    ('ai_openai_speech'                        , 'ai.openai_speech'                        , 'medium', 'OpenAI TTS. args: text, voice, model, save_to.'),
    ('ai_gemini_chat'                          , 'ai.gemini_chat'                          , 'low'   , 'Gemini chat. args: prompt, model, system.'),
    ('ai_gemini_vision'                        , 'ai.gemini_vision'                        , 'low'   , 'Gemini multimodal vision. args: image_path_or_url, prompt, model.'),
    ('ai_mistral_chat'                         , 'ai.mistral_chat'                         , 'low'   , 'Mistral chat. args: prompt, model, system.'),
    ('ai_together_chat'                        , 'ai.together_chat'                        , 'low'   , 'Together AI chat (OpenAI-compatible). args: prompt, model.'),
    ('ai_ollama_chat'                          , 'ai.ollama_chat'                          , 'low'   , 'Ollama local chat. args: prompt, model, system.'),
    ('ai_ollama_list_models'                   , 'ai.ollama_list_models'                   , 'low'   , 'List Ollama installed models.'),
    ('ai_ollama_pull'                          , 'ai.ollama_pull'                          , 'medium', 'Pull an Ollama model. args: model_name. Long-running (timeout 300s).'),
    ('ai_ollama_embed'                         , 'ai.ollama_embed'                         , 'low'   , 'Ollama embeddings. args: text, model.'),
    ('ai_stability_text_to_image'              , 'ai.stability_text_to_image'              , 'low'   , 'Stability text-to-image. args: prompt, save_to, model.'),
    ('ai_deepl_translate'                      , 'ai.deepl_translate'                      , 'medium', 'DeepL translate. args: text, target_lang, source_lang.'),
    ('ai_libretranslate'                       , 'ai.libretranslate'                       , 'medium', 'LibreTranslate (self-host). args: text, target_lang, source_lang.'),
    ('ai_elevenlabs_tts'                       , 'ai.elevenlabs_tts'                       , 'low'   , 'ElevenLabs TTS. args: text, voice_id, save_to.'),
    ('ai_elevenlabs_list_voices'               , 'ai.elevenlabs_list_voices'               , 'low'   , 'List available ElevenLabs voices.'),
    ('ai_compare_models'                       , 'ai.compare_models'                       , 'low'   , "Call multiple models side-by-side. args: prompt, models (list of 'provider/model')."),
    ('ai_cheapest_chat'                        , 'ai.cheapest_chat'                        , 'low'   , 'Pick cheapest available provider and answer. args: prompt.'),
    # -- life --
    ('life_flight_status'                      , 'life.flight_status'                      , 'low'   , 'Status of a single flight by IATA code. AviationStack if key set, else OpenSky.'),
    ('life_flights_near'                       , 'life.flights_near'                       , 'low'   , 'Live flights within `radius_km` of (lat, lon) via OpenSky free API.'),
    ('life_flights_arrivals'                   , 'life.flights_arrivals'                   , 'low'   , 'Recent arrivals at an airport in the last `hours` hours via OpenSky.'),
    ('life_gas_prices'                         , 'life.gas_prices'                         , 'low'   , 'Best-effort gas-price lookup. No clean free API exists; returns helpful error.'),
    ('life_ev_charging_stations'               , 'life.ev_charging_stations'               , 'low'   , 'EV chargers near (lat, lon) via Open Charge Map free API.'),
    ('life_air_quality'                        , 'life.air_quality'                        , 'low'   , 'Latest air-quality readings via OpenAQ free API (by city or lat/lon).'),
    ('life_uv_index'                           , 'life.uv_index'                           , 'low'   , 'Current UV index at (lat, lon) via Open-Meteo (free, no key).'),
    ('life_pollen_count'                       , 'life.pollen_count'                       , 'low'   , 'Pollen levels at (lat, lon) via Open-Meteo air-quality endpoint.'),
    ('life_sunset_sunrise'                     , 'life.sunset_sunrise'                     , 'low'   , "Sunrise / sunset times at (lat, lon) for `date` (YYYY-MM-DD or 'today')."),
    ('life_currency_convert'                   , 'life.currency_convert'                   , 'low'   , 'Convert `amount` from one currency to another via Frankfurter (free, no key).'),
    ('life_currency_historical'                , 'life.currency_historical'                , 'low'   , 'Historical exchange rate on `date` (YYYY-MM-DD) via Frankfurter.'),
    ('life_currency_list_rates'                , 'life.currency_list_rates'                , 'low'   , 'All exchange rates relative to `base` (default USD) via Frankfurter.'),
    ('life_places_search'                      , 'life.places_search'                      , 'low'   , 'Search OSM places matching `query` near (lat, lon).'),
    ('life_geocode'                            , 'life.geocode'                            , 'low'   , 'Convert an address string → (lat, lon) via Nominatim.'),
    ('life_reverse_geocode'                    , 'life.reverse_geocode'                    , 'low'   , 'Convert (lat, lon) → address via Nominatim.'),
    ('life_business_hours'                     , 'life.business_hours'                     , 'low'   , 'Best-effort opening hours via Overpass (OSM `opening_hours` tag).'),
    ('life_transit_routes'                     , 'life.transit_routes'                     , 'low'   , 'Route from A→B via OpenRouteService. `mode` ∈ {transit,driving,walking,cycling}.'),
    ('life_traffic_estimate'                   , 'life.traffic_estimate'                   , 'low'   , 'Driving-time estimate A→B via OpenRouteService (driving-car profile).'),
    ('life_sports_scores'                      , 'life.sports_scores'                      , 'low'   , 'Scoreboard for `sport` (nba/nfl/mlb/etc) on `date` (YYYYMMDD optional).'),
    ('life_sports_team_record'                 , 'life.sports_team_record'                 , 'low'   , 'Find a team by name and return its record.'),
    ('life_lottery_results'                    , 'life.lottery_results'                    , 'low'   , 'Best-effort latest results for a US lottery game (powerball / megamillions).'),
    ('life_random_password'                    , 'life.random_password'                    , 'low'   , 'Generate a cryptographically random password.'),
    ('life_random_uuid'                        , 'life.random_uuid'                        , 'low'   , 'Generate a UUID4.'),
    ('life_random_username'                    , 'life.random_username'                    , 'low'   , 'Generate a fun random username. `adjective_noun=True` → e.g. swift-fox-482.'),
    ('life_nutrition_lookup'                   , 'life.nutrition_lookup'                   , 'low'   , 'Look up a food product via Open Food Facts (free, no key).'),
    ('life_calorie_estimate'                   , 'life.calorie_estimate'                   , 'low'   , 'Calorie estimate for a free-text meal via Edamam (needs APP_ID + APP_KEY).'),

    # ── Phase 6: coding / workflow / fun ──────────────────────────────────
    # -- git --
    ('git_log'                             , 'git.log'                             , 'low'   , 'Run `git log` with optional limit and oneline formatting.'),
    ('git_diff'                            , 'git.diff'                            , 'low'   , '`git diff` — unstaged by default; pass `staged=true` for staged'),
    ('git_show'                            , 'git.show'                            , 'low'   , '`git show <ref>` — defaults to HEAD.'),
    ('git_blame'                           , 'git.blame'                           , 'low'   , '`git blame <file>` with optional line range.'),
    ('git_branch_list'                     , 'git.branch_list'                     , 'low'   , 'List local + remote branches via `git branch -a`.'),
    ('git_recent_commits_by_file'          , 'git.recent_commits_by_file'          , 'high'  , 'Recent commits that touched a specific file.'),
    ('git_who_owns'                        , 'git.who_owns'                        , 'low'   , 'Return the committer who has touched `file` most often, plus the'),
    ('git_list_files_changed_since'        , 'git.list_files_changed_since'        , 'low'   , 'Files changed since a given ref (default HEAD~10).'),
    ('git_unmerged_files'                  , 'git.unmerged_files'                  , 'low'   , 'Files currently in merge conflict (`git diff --name-only'),
    ('git_stash_list'                      , 'git.stash_list'                      , 'low'   , '`git stash list`.'),
    ('git_add'                             , 'git.add'                             , 'medium', "`git add` — paths may be a list, a single string, or '.'."),
    ('git_commit'                          , 'git.commit'                          , 'high'  , '`git commit -m <message>` — MEDIUM risk: writes history.'),
    ('git_create_branch'                   , 'git.create_branch'                   , 'high'  , '`git checkout -b <branch_name>` — creates + switches.'),
    ('git_checkout'                        , 'git.checkout'                        , 'high'  , '`git checkout <ref>` — MEDIUM risk: changes working tree.'),
    # -- docker --
    ('docker_ps'                           , 'docker.ps'                           , 'low'   , '`docker ps`; pass `all=true` to include stopped containers.'),
    ('docker_images'                       , 'docker.images'                       , 'low'   , '`docker images`.'),
    ('docker_logs'                         , 'docker.logs'                         , 'low'   , "Tail `lines` (default 50) of a container's logs."),
    ('docker_exec'                         , 'docker.exec'                         , 'high'  , '`docker exec <container> <cmd>` — MEDIUM risk: arbitrary code.'),
    ('docker_stop'                         , 'docker.stop'                         , 'high'  , '`docker stop <container>` — MEDIUM risk.'),
    ('docker_compose_up'                   , 'docker.compose_up'                   , 'high'  , '`docker compose up` in cwd; detached by default. MEDIUM risk.'),
    ('docker_compose_down'                 , 'docker.compose_down'                 , 'high'  , '`docker compose down` in cwd. MEDIUM risk.'),
    # -- pkg --
    ('pkg_npm_install'                     , 'pkg.npm_install'                     , 'high'  , '`npm install <package>` in cwd; `dev=true` adds `--save-dev`.'),
    ('pkg_pip_install'                     , 'pkg.pip_install'                     , 'high'  , '`pip install <package>`. MEDIUM risk: mutates Python env.'),
    ('pkg_pip_freeze'                      , 'pkg.pip_freeze'                      , 'low'   , '`pip freeze` — list installed packages.'),
    ('pkg_outdated_npm'                    , 'pkg.outdated_npm'                    , 'low'   , '`npm outdated` in cwd. Exit code 1 is normal when something is'),
    ('pkg_outdated_pip'                    , 'pkg.outdated_pip'                    , 'low'   , '`pip list --outdated`.'),
    # -- code --
    ('code_format_python'                  , 'code.format_python'                  , 'medium', 'Format Python with `black` (default) or `ruff format`.'),
    ('code_lint_python'                    , 'code.lint_python'                    , 'medium', 'Lint Python with `ruff check` (default) or `pylint`.'),
    ('code_format_js'                      , 'code.format_js'                      , 'medium', 'Format JS/TS with `prettier`.'),
    ('code_lint_js'                        , 'code.lint_js'                        , 'medium', 'Lint JS/TS with `eslint`.'),
    ('code_run_tests'                      , 'code.run_tests'                      , 'medium', 'Auto-detect test framework by looking for config files in cwd:'),
    # -- scaffold --
    ('scaffold_python_project'             , 'scaffold.python_project'             , 'medium', 'Create a minimal Python project: src package, README, .gitignore,'),
    ('scaffold_node_project'               , 'scaffold.node_project'               , 'medium', 'Create a minimal Node project: package.json (via `npm/pnpm/yarn'),
    ('scaffold_html_project'               , 'scaffold.html_project'               , 'medium', 'Create a tiny static-site folder: index.html + style.css +'),
    # -- workflow --
    ('workflow_define'                     , 'workflow.define'                     , 'medium', 'Define (or overwrite) a workflow.'),
    ('workflow_list'                       , 'workflow.list'                       , 'low'   , 'List defined workflows (builtins auto-registered on first call).'),
    ('workflow_get'                        , 'workflow.get'                        , 'low'   , 'Read the full spec for one workflow.'),
    ('workflow_update'                     , 'workflow.update'                     , 'medium', "Patch a workflow's description and/or steps."),
    ('workflow_delete'                     , 'workflow.delete'                     , 'high'  , 'Delete a workflow.'),
    ('workflow_export'                     , 'workflow.export'                     , 'low'   , 'Return JSON-encoded spec for sharing.'),
    ('workflow_import_json'                , 'workflow.import_json'                , 'medium', 'Import a JSON workflow spec under a given name.'),
    ('workflow_run'                        , 'workflow.run'                        , 'medium', 'Run a workflow synchronously.'),
    ('workflow_dry_run'                    , 'workflow.dry_run'                    , 'medium', 'List steps + tool resolvability, no execution.'),
    ('workflow_run_async'                  , 'workflow.run_async'                  , 'medium', 'Kick off a workflow in the background. Returns run_id immediately.'),
    ('workflow_run_status'                 , 'workflow.run_status'                 , 'medium', 'Read in-memory status for a run_id.'),
    ('workflow_recent_runs'                , 'workflow.recent_runs'                , 'medium', 'Tail of workflow-runs.jsonl.'),
    ('workflow_cancel_run'                 , 'workflow.cancel_run'                 , 'high'  , 'Set the cancel flag on an in-flight async run.'),
    ('workflow_schedule_at'                , 'workflow.schedule_at'                , 'medium', 'Schedule a one-shot run at an ISO timestamp.'),
    ('workflow_schedule_cron'              , 'workflow.schedule_cron'              , 'medium', 'Schedule a recurring run by 5-field cron.'),
    ('workflow_schedule_list'              , 'workflow.schedule_list'              , 'low'   , 'List all active schedules.'),
    ('workflow_schedule_cancel'            , 'workflow.schedule_cancel'            , 'high'  , 'Remove a schedule by id.'),
    # -- fun --
    ('fun_trivia_question'                 , 'fun.trivia_question'                 , 'low'   , 'Fetch a single trivia question from Open Trivia DB.'),
    ('fun_trivia_categories'               , 'fun.trivia_categories'               , 'low'   , 'List Open Trivia DB categories.'),
    ('fun_would_you_rather'                , 'fun.would_you_rather'                , 'low'   , "Return a 'would you rather' pair. Tries either.io, falls back local."),
    ('fun_this_or_that'                    , 'fun.this_or_that'                    , 'low'   , 'Return a paired this-or-that choice.'),
    ('fun_joke_random'                     , 'fun.joke_random'                     , 'low'   , 'Random setup/punchline joke from official-joke-api.'),
    ('fun_joke_chuck_norris'               , 'fun.joke_chuck_norris'               , 'low'   , 'Random Chuck Norris fact.'),
    ('fun_joke_dad'                        , 'fun.joke_dad'                        , 'low'   , 'Random dad joke from icanhazdadjoke.'),
    ('fun_joke_programming'                , 'fun.joke_programming'                , 'low'   , 'Random programming joke from JokeAPI.'),
    ('fun_pun_random'                      , 'fun.pun_random'                      , 'low'   , 'Random pun from JokeAPI.'),
    ('fun_quote_motivational'              , 'fun.quote_motivational'              , 'low'   , 'Random motivational quote from ZenQuotes.'),
    ('fun_quote_stoic'                     , 'fun.quote_stoic'                     , 'low'   , 'Random stoic quote.'),
    ('fun_affirmation'                     , 'fun.affirmation'                     , 'low'   , 'Random affirmation from affirmations.dev.'),
    ('fun_fortune_cookie'                  , 'fun.fortune_cookie'                  , 'low'   , 'Random fortune from local hardcoded list.'),
    ('fun_coin_flip'                       , 'fun.coin_flip'                       , 'low'   , 'Flip a coin.'),
    ('fun_roll_dice'                       , 'fun.roll_dice'                       , 'low'   , 'Roll N dice with S sides. args: {sides?:int=6, count?:int=1}'),
    ('fun_magic_8ball'                     , 'fun.magic_8ball'                     , 'low'   , 'Classic magic 8-ball. args: {question?:str}'),
    ('fun_rock_paper_scissors'             , 'fun.rock_paper_scissors'             , 'low'   , "Play RPS against Leon. args: {player_choice:'rock'|'paper'|'scissors'}"),
    ('fun_20_questions_start'              , 'fun.20_questions_start'              , 'medium', 'Start a new 20-questions session. Returns first question.'),
    ('fun_20_questions_answer'             , 'fun.20_questions_answer'             , 'medium', 'Answer current question with yes|no. Narrows to a guess.'),
    ('fun_hangman_start'                   , 'fun.hangman_start'                   , 'medium', "Start a hangman game. args: {category?:str='random'}"),
    ('fun_hangman_guess'                   , 'fun.hangman_guess'                   , 'medium', 'Guess a letter. args: {letter:str}'),
    ('fun_random_fact'                     , 'fun.random_fact'                     , 'low'   , 'Random useless fact.'),
    ('fun_cat_image'                       , 'fun.cat_image'                       , 'low'   , 'Random cat image URL.'),
    ('fun_dog_image'                       , 'fun.dog_image'                       , 'low'   , 'Random dog image URL.'),
    ('fun_meme_random'                     , 'fun.meme_random'                     , 'low'   , 'Random meme from meme-api.'),
    ('fun_bedtime_story'                   , 'fun.bedtime_story'                   , 'low'   , 'Generate a short bedtime story. args: {theme?:str}'),
    ('fun_lofi_radio_url'                  , 'fun.lofi_radio_url'                  , 'low'   , 'Return a YouTube link to a lofi/chillhop radio stream.'),


    # ── Phase 7: notes / media / netsys / autopilot ─────────────────────
    # -- notes --
    ('notes_quick_add'                         , 'notes.quick_add'                         , 'medium', 'Append a quick note. `text` is required, `tags` may be a list or'),
    ('notes_quick_list'                        , 'notes.quick_list'                        , 'low'   , 'List notes, newest first. Optional `tag` filter and `since`'),
    ('notes_quick_search'                      , 'notes.quick_search'                      , 'low'   , 'Case-insensitive substring search across text + tags.'),
    ('notes_quick_delete'                      , 'notes.quick_delete'                      , 'high'  , 'Delete a note by id. Returns `{deleted: bool}`.'),
    ('notes_quick_update'                      , 'notes.quick_update'                      , 'medium', "Update a note's text / tags / source by id. Returns the new"),
    ('notes_quick_today'                       , 'notes.quick_today'                       , 'low'   , 'All notes created since local midnight today, newest first.'),
    ('notes_quick_stats'                       , 'notes.quick_stats'                       , 'low'   , 'Total note count + per-tag breakdown + oldest/newest timestamps.'),
    ('notes_obsidian_list_files'               , 'notes.obsidian_list_files'               , 'low'   , 'List all .md files in the vault, optionally scoped to `folder`.'),
    ('notes_obsidian_read'                     , 'notes.obsidian_read'                     , 'low'   , 'Read a markdown file from the vault. `file_path_in_vault` is'),
    ('notes_obsidian_write'                    , 'notes.obsidian_write'                    , 'medium', 'Write or append to a markdown file in the vault. Creates parent'),
    ('notes_obsidian_search'                   , 'notes.obsidian_search'                   , 'low'   , 'Grep-like substring search across all .md files. Returns matched'),
    ('notes_obsidian_daily_note'               , 'notes.obsidian_daily_note'               , 'low'   , "Read today's (or `date_iso`'s) daily note. Creates an empty stub"),
    ('notes_obsidian_add_to_daily'             , 'notes.obsidian_add_to_daily'             , 'medium', "Append a bullet to today's daily note. Creates the daily note if"),
    ('notes_obsidian_backlinks'                , 'notes.obsidian_backlinks'                , 'low'   , 'Find all vault files that link to `file_path_in_vault` via'),
    ('notes_obsidian_tags_list'                , 'notes.obsidian_tags_list'                , 'low'   , 'Scan every .md file for `#tag` references and return a count map'),
    ('notes_obsidian_unfinished_tasks'         , 'notes.obsidian_unfinished_tasks'         , 'low'   , 'Find all `- [ ]` style unfinished tasks across the vault.'),
    ('notes_notion_search'                     , 'notes.notion_search'                     , 'low'   , 'POST /v1/search — query across pages and databases the'),
    ('notes_notion_query_database'             , 'notes.notion_query_database'             , 'low'   , 'POST /v1/databases/{id}/query — optionally with a `filter_json`'),
    ('notes_notion_get_page'                   , 'notes.notion_get_page'                   , 'low'   , 'GET /v1/pages/{id}.'),
    ('notes_notion_create_page_in_database'    , 'notes.notion_create_page_in_database'    , 'medium', 'POST /v1/pages with `parent.database_id`. `properties` must be'),
    ('notes_notion_create_page_in_parent'      , 'notes.notion_create_page_in_parent'      , 'medium', 'POST /v1/pages under a parent page. Builds the title property'),
    ('notes_notion_append_block'               , 'notes.notion_append_block'               , 'medium', 'PATCH /v1/blocks/{id}/children — convert `content_markdown` to'),
    ('notes_notion_get_block_children'         , 'notes.notion_get_block_children'         , 'low'   , 'GET /v1/blocks/{id}/children?page_size=N.'),
    ('notes_notion_update_page'                , 'notes.notion_update_page'                , 'medium', 'PATCH /v1/pages/{id} — update properties (Notion JSON shape).'),
    ('notes_notion_list_databases'             , 'notes.notion_list_databases'             , 'low'   , 'POST /v1/search filtered to objects of type `database`.'),
    ('notes_apple_notes_create'                , 'notes.apple_notes_create'                , 'medium', 'Create a new Apple Note. No-op on non-macOS systems.'),
    ('notes_apple_notes_list'                  , 'notes.apple_notes_list'                  , 'low'   , 'List recent Apple Notes (name + id). No-op on non-macOS systems.'),
    ('notes_capture_thought'                   , 'notes.capture_thought'                   , 'low'   , 'One-shot capture. `target` selects the backend:'),
    ('notes_search_everywhere'                 , 'notes.search_everywhere'                 , 'low'   , 'Search every available backend in parallel-ish (sequential calls,'),
    # -- media --
    ('media_list_photos'                       , 'media.list_photos'                       , 'low'   , '_t_list_photos'),
    ('media_photo_info'                        , 'media.photo_info'                        , 'low'   , '_t_photo_info'),
    ('media_photo_caption'                     , 'media.photo_caption'                     , 'low'   , '_t_photo_caption'),
    ('media_photo_describe'                    , 'media.photo_describe'                    , 'low'   , '_t_photo_describe'),
    ('media_photo_find_by_content'             , 'media.photo_find_by_content'             , 'low'   , '_t_photo_find_by_content'),
    ('media_photos_by_date'                    , 'media.photos_by_date'                    , 'low'   , '_t_photos_by_date'),
    ('media_photos_by_location'                , 'media.photos_by_location'                , 'low'   , '_t_photos_by_location'),
    ('media_screenshot_gallery'                , 'media.screenshot_gallery'                , 'low'   , '_t_screenshot_gallery'),
    ('media_photo_resize'                      , 'media.photo_resize'                      , 'medium', '_t_photo_resize'),
    ('media_photo_thumbnail'                   , 'media.photo_thumbnail'                   , 'low'   , '_t_photo_thumbnail'),
    ('media_photo_rotate'                      , 'media.photo_rotate'                      , 'medium', '_t_photo_rotate'),
    ('media_photo_crop'                        , 'media.photo_crop'                        , 'medium', '_t_photo_crop'),
    ('media_photo_to_base64'                   , 'media.photo_to_base64'                   , 'low'   , '_t_photo_to_base64'),
    ('media_pdf_list'                          , 'media.pdf_list'                          , 'low'   , '_t_pdf_list'),
    ('media_pdf_text'                          , 'media.pdf_text'                          , 'low'   , '_t_pdf_text'),
    ('media_pdf_summary'                       , 'media.pdf_summary'                       , 'low'   , '_t_pdf_summary'),
    ('media_pdf_page_image'                    , 'media.pdf_page_image'                    , 'low'   , '_t_pdf_page_image'),
    ('media_pdf_metadata'                      , 'media.pdf_metadata'                      , 'low'   , '_t_pdf_metadata'),
    ('media_pdf_ocr_page'                      , 'media.pdf_ocr_page'                      , 'low'   , '_t_pdf_ocr_page'),
    ('media_video_list'                        , 'media.video_list'                        , 'low'   , '_t_video_list'),
    ('media_video_info'                        , 'media.video_info'                        , 'low'   , '_t_video_info'),
    ('media_video_thumbnail'                   , 'media.video_thumbnail'                   , 'low'   , '_t_video_thumbnail'),
    ('media_video_extract_audio'               , 'media.video_extract_audio'               , 'medium', '_t_video_extract_audio'),
    ('media_docx_text'                         , 'media.docx_text'                         , 'low'   , '_t_docx_text'),
    ('media_spreadsheet_read'                  , 'media.spreadsheet_read'                  , 'low'   , '_t_spreadsheet_read'),
    # -- net --
    ('net_dns_lookup'                          , 'net.dns_lookup'                          , 'low'   , 'dns_lookup'),
    ('net_reverse_dns'                         , 'net.reverse_dns'                         , 'low'   , 'reverse_dns'),
    ('net_whois'                               , 'net.whois'                               , 'low'   , 'whois_lookup'),
    ('net_dns_check_propagation'               , 'net.dns_check_propagation'               , 'low'   , 'Query 5 public resolvers and report inconsistency. Uses `dig @resolver`'),
    ('net_ping'                                , 'net.ping'                                , 'low'   , 'ping'),
    ('net_traceroute'                          , 'net.traceroute'                          , 'low'   , 'traceroute'),
    ('net_public_ip'                           , 'net.public_ip'                           , 'low'   , 'Public IP as seen from the outside, for the netsys mental model.'),
    ('net_port_check'                          , 'net.port_check'                          , 'low'   , 'port_check'),
    ('net_port_scan_local'                     , 'net.port_scan_local'                     , 'low'   , 'port_scan_local'),
    ('net_wifi_list_networks'                  , 'net.wifi_list_networks'                  , 'low'   , 'wifi_list_networks'),
    ('net_wifi_current'                        , 'net.wifi_current'                        , 'low'   , 'wifi_current'),
    ('net_wifi_disconnect'                     , 'net.wifi_disconnect'                     , 'high'  , 'MEDIUM risk — disconnects the currently active wireless connection.'),
    ('net_network_interfaces'                  , 'net.network_interfaces'                  , 'low'   , 'network_interfaces'),
    ('net_bluetooth_scan'                      , 'net.bluetooth_scan'                      , 'low'   , 'bluetooth_scan'),
    ('net_bluetooth_paired_list'               , 'net.bluetooth_paired_list'               , 'low'   , 'bluetooth_paired_list'),
    ('net_bluetooth_connect'                   , 'net.bluetooth_connect'                   , 'medium', 'MEDIUM risk — initiates a bluetooth connection.'),
    # -- sys --
    ('sys_audio_volume_get'                    , 'sys.audio_volume_get'                    , 'low'   , 'audio_volume_get'),
    ('sys_audio_volume_set'                    , 'sys.audio_volume_set'                    , 'medium', 'MEDIUM risk — changes system audio volume.'),
    ('sys_audio_mute_toggle'                   , 'sys.audio_mute_toggle'                   , 'medium', 'audio_mute_toggle'),
    ('sys_audio_list_sinks'                    , 'sys.audio_list_sinks'                    , 'low'   , 'audio_list_sinks'),
    ('sys_audio_list_sources'                  , 'sys.audio_list_sources'                  , 'low'   , 'audio_list_sources'),
    ('sys_screen_brightness_get'               , 'sys.screen_brightness_get'               , 'low'   , 'screen_brightness_get'),
    ('sys_screen_brightness_set'               , 'sys.screen_brightness_set'               , 'medium', 'MEDIUM risk — changes screen brightness.'),
    ('sys_dpms_off'                            , 'sys.dpms_off'                            , 'high'  , 'dpms_off'),
    ('sys_dpms_on'                             , 'sys.dpms_on'                             , 'low'   , 'dpms_on'),
    ('sys_power_state'                         , 'sys.power_state'                         , 'low'   , 'power_state'),
    ('sys_power_settle'                        , 'sys.power_settle'                        , 'medium', 'REPORT-ONLY. If CPU temp > 80C, surface the top heavy processes so'),
    # -- autopilot --
    ('autopilot_plan'                          , 'autopilot.plan'                          , 'medium', 'Decompose a goal into a step list.'),
    ('autopilot_run'                           , 'autopilot.run'                           , 'medium', 'Plan (if needed) and execute. Returns the full transcript.'),
    ('autopilot_run_step'                      , 'autopilot.run_step'                      , 'medium', 'Execute one step. On failure, optionally walk the click fallback chain.'),
    ('autopilot_run_async'                     , 'autopilot.run_async'                     , 'medium', 'Fire-and-forget background run. Returns immediately with the run_id;'),
    ('autopilot_cancel_run'                    , 'autopilot.cancel_run'                    , 'high'  , 'Best-effort cancel of an in-flight async run. The current step finishes'),
    ('autopilot_recent_runs'                   , 'autopilot.recent_runs'                   , 'medium', 'Tail of autopilot-runs.jsonl.'),
    ('autopilot_get_run'                       , 'autopilot.get_run'                       , 'medium', 'Fetch a single run by id.'),
    ('autopilot_list_recent_goals'             , 'autopilot.list_recent_goals'             , 'low'   , 'Distinct goals across recent runs, newest first.'),
    ('autopilot_replay'                        , 'autopilot.replay'                        , 'medium', "Re-execute a prior run's plan from scratch (new run_id, fresh results)."),
    ('autopilot_suggest_next_action'           , 'autopilot.suggest_next_action'           , 'low'   , 'Given an observation string, suggest one tool to fire. Heuristic-only —'),
    ('autopilot_explain_step'                  , 'autopilot.explain_step'                  , 'low'   , '1-2 sentence English description of a step dict. For the observation'),
    ('autopilot_success_rate'                  , 'autopilot.success_rate'                  , 'low'   , 'Fraction of runs in the last N days that completed without aborting.'),
    ('autopilot_failure_clusters'              , 'autopilot.failure_clusters'              , 'low'   , 'Which kinds of steps fail most in the last N days, grouped by tool name.'),
    ('autopilot_confidence_check'              , 'autopilot.confidence_check'              , 'low'   , 'Static sanity-check on a plan before execution. Verifies tool names'),
    ('autopilot_skill_inventory'               , 'autopilot.skill_inventory'               , 'high'  , 'Compact list of every dotted tool Leon currently exposes via the'),


    # ── Phase 8: cloud_storage / github_cicd / commerce / maps ──────────────
    # -- cloud --
    ('cloud_gdrive_list'                           , 'cloud.gdrive_list'                           , 'low'   , 'List files in Drive (optionally scoped to a folder or query).'),
    ('cloud_gdrive_search'                         , 'cloud.gdrive_search'                         , 'low'   , 'Search Drive by filename substring (files.list with q).'),
    ('cloud_gdrive_download'                       , 'cloud.gdrive_download'                       , 'low'   , 'Download a Drive file to a sandboxed local path.'),
    ('cloud_gdrive_upload'                         , 'cloud.gdrive_upload'                         , 'medium', 'Upload a local sandboxed file to Drive (multipart).'),
    ('cloud_gdrive_create_folder'                  , 'cloud.gdrive_create_folder'                  , 'medium', 'Create a Drive folder, optionally inside a parent.'),
    ('cloud_gdrive_delete'                         , 'cloud.gdrive_delete'                         , 'high'  , 'Delete a Drive file by id. HIGH risk — permanent.'),
    ('cloud_gdrive_share'                          , 'cloud.gdrive_share'                          , 'medium', 'Grant a Drive permission to an email (default role=reader).'),
    ('cloud_gdrive_recent'                         , 'cloud.gdrive_recent'                         , 'low'   , 'Most-recently-modified Drive files.'),
    ('cloud_dropbox_list'                          , 'cloud.dropbox_list'                          , 'low'   , "List a Dropbox folder (root = `''`)."),
    ('cloud_dropbox_search'                        , 'cloud.dropbox_search'                        , 'low'   , 'Search Dropbox by query.'),
    ('cloud_dropbox_download'                      , 'cloud.dropbox_download'                      , 'low'   , 'Download a Dropbox path to a sandboxed local file.'),
    ('cloud_dropbox_upload'                        , 'cloud.dropbox_upload'                        , 'medium', 'Upload a sandboxed local file to a Dropbox path (overwrite mode).'),
    ('cloud_dropbox_delete'                        , 'cloud.dropbox_delete'                        , 'high'  , 'Delete a Dropbox path. HIGH risk — permanent.'),
    ('cloud_dropbox_share_link'                    , 'cloud.dropbox_share_link'                    , 'medium', 'Create (or return existing) shareable link for a Dropbox path.'),
    ('cloud_s3_list_buckets'                       , 'cloud.s3_list_buckets'                       , 'low'   , 'List all S3 buckets owned by the account.'),
    ('cloud_s3_list_objects'                       , 'cloud.s3_list_objects'                       , 'low'   , 'List objects in an S3 bucket (optionally by prefix).'),
    ('cloud_s3_download'                           , 'cloud.s3_download'                           , 'low'   , 'Download an S3 object to a sandboxed local path.'),
    ('cloud_s3_upload'                             , 'cloud.s3_upload'                             , 'medium', 'Upload a sandboxed local file to S3.'),
    ('cloud_s3_delete'                             , 'cloud.s3_delete'                             , 'high'  , 'Delete an S3 object. HIGH risk — permanent.'),
    ('cloud_s3_presigned_url'                      , 'cloud.s3_presigned_url'                      , 'medium', 'Generate a time-limited presigned GET URL for an S3 object.'),
    ('cloud_onedrive_list'                         , 'cloud.onedrive_list'                         , 'low'   , 'List children of a OneDrive folder (default = root).'),
    ('cloud_onedrive_search'                       , 'cloud.onedrive_search'                       , 'low'   , 'Search OneDrive by query string.'),
    ('cloud_onedrive_download'                     , 'cloud.onedrive_download'                     , 'low'   , 'Download a OneDrive item by id to a sandboxed local path.'),
    ('cloud_onedrive_upload'                       , 'cloud.onedrive_upload'                       , 'medium', 'Upload a sandboxed local file into a OneDrive folder (simple <4MB upload).'),
    ('cloud_unified_search'                        , 'cloud.unified_search'                        , 'low'   , 'Fan out a search across every configured cloud backend.'),
    ('cloud_list_configured'                       , 'cloud.list_configured'                       , 'low'   , 'Report which cloud backends have usable credentials right now.'),
    # -- gh --
    ('gh_user_info'                                , 'gh.user_info'                                , 'low'   , 'User info — authenticated user if `username` omitted/None.'),
    ('gh_repo_list'                                , 'gh.repo_list'                                , 'low'   , 'List repos for `user` (or authenticated user if None). limit defaults 30.'),
    ('gh_repo_info'                                , 'gh.repo_info'                                , 'low'   , 'Info for `owner/repo`.'),
    ('gh_repo_create'                              , 'gh.repo_create'                              , 'medium', 'MEDIUM risk — create a repo under authenticated user.'),
    ('gh_repo_delete'                              , 'gh.repo_delete'                              , 'high'  , 'HIGH risk — permanently delete a repo. Requires `delete_repo` scope.'),
    ('gh_issue_list'                               , 'gh.issue_list'                               , 'low'   , 'List issues for `owner/repo`. state: open/closed/all.'),
    ('gh_issue_get'                                , 'gh.issue_get'                                , 'low'   , 'Get a single issue.'),
    ('gh_issue_create'                             , 'gh.issue_create'                             , 'medium', 'MEDIUM risk — create an issue.'),
    ('gh_issue_close'                              , 'gh.issue_close'                              , 'medium', 'MEDIUM risk — close an issue.'),
    ('gh_issue_comment'                            , 'gh.issue_comment'                            , 'medium', 'MEDIUM risk — post a comment on an issue or PR.'),
    ('gh_pr_list'                                  , 'gh.pr_list'                                  , 'low'   , 'List PRs. state: open/closed/all.'),
    ('gh_pr_get'                                   , 'gh.pr_get'                                   , 'low'   , 'Get a single PR.'),
    ('gh_pr_create'                                , 'gh.pr_create'                                , 'medium', 'MEDIUM risk — open a pull request.'),
    ('gh_pr_merge'                                 , 'gh.pr_merge'                                 , 'high'  , 'HIGH risk — merge a PR. merge_method: merge|squash|rebase.'),
    ('gh_pr_review'                                , 'gh.pr_review'                                , 'medium', 'MEDIUM risk — submit a review. event: APPROVE|REQUEST_CHANGES|COMMENT.'),
    ('gh_actions_list_runs'                        , 'gh.actions_list_runs'                        , 'low'   , 'List recent workflow runs, optionally filtered by branch.'),
    ('gh_actions_get_run'                          , 'gh.actions_get_run'                          , 'low'   , 'Get a single workflow run.'),
    ('gh_actions_rerun'                            , 'gh.actions_rerun'                            , 'medium', 'MEDIUM risk — re-run a workflow run.'),
    ('gh_actions_cancel'                           , 'gh.actions_cancel'                           , 'medium', 'MEDIUM risk — cancel an in-flight workflow run.'),
    ('gh_actions_logs'                             , 'gh.actions_logs'                             , 'low'   , 'Fetch run logs as a zip. Returns `{bytes_len, content_b64, ...}`.'),
    ('gh_actions_list_workflows'                   , 'gh.actions_list_workflows'                   , 'low'   , 'List defined workflows for a repo.'),
    ('gh_actions_dispatch'                         , 'gh.actions_dispatch'                         , 'medium', 'MEDIUM risk — manually trigger a workflow_dispatch.'),
    ('gh_gist_create'                              , 'gh.gist_create'                              , 'medium', 'MEDIUM risk — create a gist.'),
    ('gh_gist_list'                                , 'gh.gist_list'                                , 'low'   , 'List gists for the authenticated user.'),
    ('gh_notifications_list'                       , 'gh.notifications_list'                       , 'low'   , 'List notifications for the authenticated user.'),
    # -- vercel --
    ('vercel_deployments_list'                     , 'vercel.deployments_list'                     , 'low'   , 'List recent deployments, optionally filtered by project name.'),
    ('vercel_deployment_status'                    , 'vercel.deployment_status'                    , 'low'   , 'Status for a single deployment id.'),
    ('vercel_deployment_logs'                      , 'vercel.deployment_logs'                      , 'low'   , 'Build/runtime logs for a deployment (best-effort across API versions).'),
    # -- netlify --
    ('netlify_sites_list'                          , 'netlify.sites_list'                          , 'low'   , 'List Netlify sites for the authenticated account.'),
    ('netlify_deploys_list'                        , 'netlify.deploys_list'                        , 'low'   , 'List deploys for a Netlify site id.'),
    ('netlify_deploy_status'                       , 'netlify.deploy_status'                       , 'low'   , 'Status for a single Netlify deploy id.'),
    # -- cloudflare --
    ('cloudflare_pages_list_projects'              , 'cloudflare.pages_list_projects'              , 'low'   , 'List Cloudflare Pages projects for the configured account.'),
    ('cloudflare_pages_deploys'                    , 'cloudflare.pages_deploys'                    , 'low'   , 'List deployments for a Cloudflare Pages project.'),
    ('cloudflare_dns_records'                      , 'cloudflare.dns_records'                      , 'low'   , 'List DNS records for a zone id.'),
    # -- circleci --
    ('circleci_pipelines_list'                     , 'circleci.pipelines_list'                     , 'low'   , 'List pipelines for a project slug like `gh/<owner>/<repo>`.'),
    ('circleci_pipeline_status'                    , 'circleci.pipeline_status'                    , 'low'   , 'Status (+ workflows) for a single pipeline id.'),
    # -- commerce --
    ('commerce_stripe_balance'                     , 'commerce.stripe_balance'                     , 'low'   , 'GET /v1/balance — available + pending.'),
    ('commerce_stripe_charges_list'                , 'commerce.stripe_charges_list'                , 'low'   , 'GET /v1/charges — recent charges (default limit 20, max 100).'),
    ('commerce_stripe_payment_intents_list'        , 'commerce.stripe_payment_intents_list'        , 'low'   , 'GET /v1/payment_intents.'),
    ('commerce_stripe_create_payment_link'         , 'commerce.stripe_create_payment_link'         , 'medium', 'POST /v1/payment_links — creates a hosted Stripe checkout URL.'),
    ('commerce_stripe_customers_list'              , 'commerce.stripe_customers_list'              , 'low'   , 'GET /v1/customers.'),
    ('commerce_stripe_customer_create'             , 'commerce.stripe_customer_create'             , 'medium', 'POST /v1/customers — MEDIUM (creates a customer record).'),
    ('commerce_stripe_subscription_list'           , 'commerce.stripe_subscription_list'           , 'low'   , 'GET /v1/subscriptions — optionally filtered by customer_id.'),
    ('commerce_stripe_invoice_create'              , 'commerce.stripe_invoice_create'              , 'medium', 'Create a one-off invoice (item + invoice). MEDIUM.'),
    ('commerce_stripe_invoice_send'                , 'commerce.stripe_invoice_send'                , 'high'  , 'POST /v1/invoices/{id}/send — HIGH (emails the customer).'),
    ('commerce_stripe_refund'                      , 'commerce.stripe_refund'                      , 'high'  , 'POST /v1/refunds — HIGH. amount_cents=None refunds full charge.'),
    ('commerce_stripe_dispute_list'                , 'commerce.stripe_dispute_list'                , 'low'   , 'GET /v1/disputes.'),
    ('commerce_stripe_revenue_today'               , 'commerce.stripe_revenue_today'               , 'low'   , "Sum today's (UTC) successful charges."),
    ('commerce_stripe_revenue_this_month'          , 'commerce.stripe_revenue_this_month'          , 'low'   , "Sum this month's (UTC) successful charges."),
    ('commerce_paypal_balance'                     , 'commerce.paypal_balance'                     , 'low'   , 'GET /v1/reporting/balances.'),
    ('commerce_paypal_transactions_list'           , 'commerce.paypal_transactions_list'           , 'low'   , 'GET /v1/reporting/transactions — default last 24h, max 31-day window.'),
    ('commerce_paypal_create_invoice'              , 'commerce.paypal_create_invoice'              , 'medium', 'POST /v2/invoicing/invoices — MEDIUM (draft created; not auto-sent).'),
    ('commerce_shopify_products_list'              , 'commerce.shopify_products_list'              , 'low'   , 'GET /products.json.'),
    ('commerce_shopify_product_get'                , 'commerce.shopify_product_get'                , 'low'   , 'GET /products/{id}.json.'),
    ('commerce_shopify_product_create'             , 'commerce.shopify_product_create'             , 'medium', 'POST /products.json — MEDIUM (creates a product).'),
    ('commerce_shopify_product_update_inventory'   , 'commerce.shopify_product_update_inventory'   , 'medium', 'Set on-hand inventory for a variant. MEDIUM.'),
    ('commerce_shopify_orders_unfulfilled'         , 'commerce.shopify_orders_unfulfilled'         , 'medium', 'GET /orders.json?fulfillment_status=unfulfilled&status=open.'),
    ('commerce_shopify_order_fulfill'              , 'commerce.shopify_order_fulfill'              , 'medium', 'Create a fulfillment for an order. MEDIUM.'),
    ('commerce_shopify_customers_list'             , 'commerce.shopify_customers_list'             , 'low'   , 'GET /customers.json.'),
    ('commerce_shopify_revenue_today'              , 'commerce.shopify_revenue_today'              , 'low'   , "Sum today's orders (Shopify-side `created_at` >= start of UTC day)."),
    ('commerce_etsy_shop_listings'                 , 'commerce.etsy_shop_listings'                 , 'low'   , 'GET /shops/{shop_id}/listings/active.'),
    ('commerce_etsy_shop_orders'                   , 'commerce.etsy_shop_orders'                   , 'low'   , "GET /shops/{shop_id}/receipts — recent shop orders ('receipts' in Etsy parlance)."),
    ('commerce_invoice_create'                     , 'commerce.invoice_create'                     , 'medium', 'Generate an invoice file (PDF if reportlab, else markdown).'),
    ('commerce_invoice_list_local'                 , 'commerce.invoice_list_local'                 , 'low'   , 'List invoices saved under brain_state/invoices/.'),
    ('commerce_invoice_total_outstanding'          , 'commerce.invoice_total_outstanding'          , 'low'   , 'Sum subtotals for invoices whose sidecar JSON has paid=false.'),
    ('commerce_dollars_to_cents'                   , 'commerce.dollars_to_cents'                   , 'low'   , '_dollars_to_cents'),
    ('commerce_cents_to_dollars'                   , 'commerce.cents_to_dollars'                   , 'low'   , '_cents_to_dollars'),
    # -- maps --
    ('maps_geocode'                                , 'maps.geocode'                                , 'low'   , 'Address → lat/lon. Google if GOOGLE_MAPS_API_KEY set, else Nominatim.'),
    ('maps_reverse_geocode'                        , 'maps.reverse_geocode'                        , 'low'   , 'lat/lon → address.'),
    ('maps_search_nearby'                          , 'maps.search_nearby'                          , 'low'   , 'Free-form nearby search via Overpass. `query` is matched against name/amenity/shop tags.'),
    ('maps_address_autocomplete'                   , 'maps.address_autocomplete'                   , 'low'   , 'Photon (Komoot) autocomplete — free, no key. Optional lat/lon bias.'),
    ('maps_directions'                             , 'maps.directions'                             , 'low'   , 'Door-to-door directions by address. OSRM (free) for car/walk/bike.'),
    ('maps_directions_latlon'                      , 'maps.directions_latlon'                      , 'low'   , 'Directions between two raw lat/lon pairs.'),
    ('maps_travel_time'                            , 'maps.travel_time'                            , 'low'   , 'Just the minutes (and km). Uses Google if key + departure to factor traffic.'),
    ('maps_eta_to'                                 , 'maps.eta_to'                                 , 'low'   , 'ETA from current location (IP-geo if not provided) to a destination.'),
    ('maps_traffic_now'                            , 'maps.traffic_now'                            , 'low'   , "Best-effort live traffic. Google's `duration_in_traffic` if key, else OSRM baseline."),
    ('maps_alternate_routes'                       , 'maps.alternate_routes'                       , 'low'   , 'Up to N alternative routes between two addresses (OSRM).'),
    ('maps_gas_stations'                           , 'maps.gas_stations'                           , 'low'   , 'OSM amenity=fuel within radius.'),
    ('maps_restaurants'                            , 'maps.restaurants'                            , 'low'   , 'OSM amenity=restaurant (optionally filtered by cuisine tag).'),
    ('maps_coffee_shops'                           , 'maps.coffee_shops'                           , 'low'   , 'OSM amenity=cafe.'),
    ('maps_parking'                                , 'maps.parking'                                , 'low'   , 'OSM amenity=parking.'),
    ('maps_ev_charging'                            , 'maps.ev_charging'                            , 'low'   , 'OSM amenity=charging_station.'),
    ('maps_atms'                                   , 'maps.atms'                                   , 'low'   , 'OSM amenity=atm.'),
    ('maps_pharmacies'                             , 'maps.pharmacies'                             , 'low'   , 'OSM amenity=pharmacy.'),
    ('maps_hospitals_nearest'                      , 'maps.hospitals_nearest'                      , 'low'   , 'Nearest N hospitals within a wide radius (50km).'),
    ('maps_airports_nearest'                       , 'maps.airports_nearest'                       , 'low'   , 'Nearest N airports within 200km.'),
    ('maps_transit_directions'                     , 'maps.transit_directions'                     , 'low'   , 'Public-transit directions. Requires GOOGLE_MAPS_API_KEY (no good free alt).'),
    ('maps_transit_stops_nearby'                   , 'maps.transit_stops_nearby'                   , 'low'   , 'Bus stops, tram stops, train/subway stations within radius (OSM).'),
    ('maps_where_am_i'                             , 'maps.where_am_i'                             , 'low'   , 'Public-IP geolocation → city/region/lat/lon.'),
    ('maps_what_neighborhood'                      , 'maps.what_neighborhood'                      , 'low'   , 'Reverse-geocode and pull out neighborhood/suburb/district.'),
    ('maps_distance_between'                       , 'maps.distance_between'                       , 'low'   , 'Great-circle distance between two lat/lon points (Haversine).'),
    ('maps_tile_url'                               , 'maps.tile_url'                               , 'low'   , 'Return a raster tile URL for a given z/x/y.'),
    ('maps_static_map'                             , 'maps.static_map'                             , 'low'   , 'Return a URL to a static-map image centered on lat/lon.'),

    # -- docgen --
    ("docgen_resume_pdf",          "docgen.resume_pdf",          "low",    "Generate a resume PDF (or markdown if reportlab missing)."),
    ("docgen_contract_pdf",        "docgen.contract_pdf",        "low",    "Generate a contract / agreement PDF."),
    ("docgen_report_pdf",          "docgen.report_pdf",          "low",    "Generate a generic report PDF from sections."),
    ("docgen_meeting_minutes_pdf", "docgen.meeting_minutes_pdf", "low",    "Compose meeting minutes PDF from transcript + decisions."),
    ("docgen_markdown_to_pdf",     "docgen.markdown_to_pdf",     "low",    "Quick markdown → PDF conversion (headings + bullets)."),
    ("docgen_list_docs",           "docgen.list_docs",           "low",    "List documents previously generated under ~/Documents/leon-docs."),
    ("docgen_delete_doc",          "docgen.delete_doc",          "medium", "Delete a generated doc by name."),

    # ── Phase 9: database/crypto/social/imageAI/audio/file/automation ──
    # -- db --
    ('db_pg_query'                                 , 'db.pg_query'                                 , 'low'   , 'Run a read-only SQL query. Returns rows + columns.'),
    ('db_pg_execute'                               , 'db.pg_execute'                               , 'medium', 'Run an INSERT/UPDATE/DELETE. MEDIUM risk.'),
    ('db_pg_list_tables'                           , 'db.pg_list_tables'                           , 'low'   , 'List tables in a schema (default public).'),
    ('db_pg_table_schema'                          , 'db.pg_table_schema'                          , 'low'   , 'Return column names + types for a table.'),
    ('db_pg_explain'                               , 'db.pg_explain'                               , 'low'   , 'EXPLAIN ANALYZE a query.'),
    ('db_pg_dump_table'                            , 'db.pg_dump_table'                            , 'low'   , 'Dump a table to CSV (returns text or writes to save_to path).'),
    ('db_mysql_query'                              , 'db.mysql_query'                              , 'low'   , 'Run a read-only SQL query.'),
    ('db_mysql_execute'                            , 'db.mysql_execute'                            , 'medium', 'Run INSERT/UPDATE/DELETE. MEDIUM risk.'),
    ('db_mysql_list_tables'                        , 'db.mysql_list_tables'                        , 'low'   , 'List tables in current or specified database.'),
    ('db_mysql_table_schema'                       , 'db.mysql_table_schema'                       , 'low'   , 'Return column descriptors for a table.'),
    ('db_mongo_find'                               , 'db.mongo_find'                               , 'low'   , 'Find documents in a collection.'),
    ('db_mongo_insert'                             , 'db.mongo_insert'                             , 'medium', 'Insert one document. MEDIUM risk.'),
    ('db_mongo_update'                             , 'db.mongo_update'                             , 'medium', 'Update many documents. MEDIUM risk.'),
    ('db_mongo_delete'                             , 'db.mongo_delete'                             , 'high'  , 'Delete documents matching filter. HIGH risk.'),
    ('db_mongo_list_collections'                   , 'db.mongo_list_collections'                   , 'low'   , 'List collection names in the database.'),
    ('db_mongo_aggregate'                          , 'db.mongo_aggregate'                          , 'low'   , 'Run an aggregation pipeline.'),
    ('db_redis_get'                                , 'db.redis_get'                                , 'low'   , 'GET a key.'),
    ('db_redis_set'                                , 'db.redis_set'                                , 'medium', 'SET a key (optionally with TTL). MEDIUM risk.'),
    ('db_redis_keys'                               , 'db.redis_keys'                               , 'low'   , 'SCAN keys by pattern (safer than KEYS).'),
    ('db_redis_delete'                             , 'db.redis_delete'                             , 'high'  , 'DEL a key. MEDIUM risk.'),
    ('db_redis_info'                               , 'db.redis_info'                               , 'low'   , 'Return Redis server INFO (memory, clients, stats).'),
    ('db_sqlite_query'                             , 'db.sqlite_query'                             , 'low'   , 'Run a read-only SQL query against a sqlite file.'),
    ('db_sqlite_execute'                           , 'db.sqlite_execute'                           , 'medium', 'Run INSERT/UPDATE/DELETE/DDL on a sqlite file. MEDIUM risk.'),
    ('db_sqlite_list_tables'                       , 'db.sqlite_list_tables'                       , 'low'   , 'List tables in a sqlite file.'),
    # -- devops --
    ('devops_kubectl_get'                          , 'devops.kubectl_get'                          , 'low'   , 'kubectl get <resource> [-n ns] [name] -o json.'),
    ('devops_kubectl_logs'                         , 'devops.kubectl_logs'                         , 'low'   , 'kubectl logs <pod> [-n ns] [--tail N].'),
    ('devops_systemd_list_user_services'           , 'devops.systemd_list_user_services'           , 'low'   , 'systemctl --user list-units --type=service.'),
    ('devops_systemd_list_system_services'         , 'devops.systemd_list_system_services'         , 'low'   , 'systemctl list-units --type=service.'),
    ('devops_systemd_service_logs'                 , 'devops.systemd_service_logs'                 , 'low'   , 'journalctl for a systemd service (user or system).'),
    ('devops_log_grep'                             , 'devops.log_grep'                             , 'low'   , 'Grep a log file with line numbers + context.'),
    # -- crypto --
    ('crypto_eth_balance'                          , 'crypto.eth_balance'                          , 'low'   , 'ETH balance for an address (in ETH and wei).'),
    ('crypto_eth_token_balance'                    , 'crypto.eth_token_balance'                    , 'low'   , 'ERC-20 token balance for an address.'),
    ('crypto_eth_transactions'                     , 'crypto.eth_transactions'                     , 'low'   , 'Recent normal transactions for an address.'),
    ('crypto_eth_gas_price'                        , 'crypto.eth_gas_price'                        , 'low'   , 'Current gas prices (safe/propose/fast) via Etherscan gas tracker.'),
    ('crypto_eth_block_number'                     , 'crypto.eth_block_number'                     , 'low'   , 'Current Ethereum block height.'),
    ('crypto_eth_tx_status'                        , 'crypto.eth_tx_status'                        , 'low'   , 'Status of a transaction: confirmed/pending/failed.'),
    ('crypto_btc_balance'                          , 'crypto.btc_balance'                          , 'low'   , 'BTC balance for an address (confirmed + mempool).'),
    ('crypto_btc_transactions'                     , 'crypto.btc_transactions'                     , 'low'   , 'Recent BTC transactions for an address.'),
    ('crypto_btc_tx_status'                        , 'crypto.btc_tx_status'                        , 'low'   , 'Status of a BTC transaction.'),
    ('crypto_btc_fees'                             , 'crypto.btc_fees'                             , 'low'   , 'Current BTC mempool fee estimates (sat/vB).'),
    ('crypto_ens_resolve'                          , 'crypto.ens_resolve'                          , 'low'   , 'ENS name (foo.eth) → address.'),
    ('crypto_ens_reverse'                          , 'crypto.ens_reverse'                          , 'low'   , 'Address → ENS name (reverse resolution).'),
    ('crypto_nft_owned_by'                         , 'crypto.nft_owned_by'                         , 'low'   , 'NFTs owned by an address. Requires ALCHEMY_API_KEY.'),
    ('crypto_nft_collection_floor'                 , 'crypto.nft_collection_floor'                 , 'low'   , 'Floor price for an OpenSea collection slug.'),
    ('crypto_nft_metadata'                         , 'crypto.nft_metadata'                         , 'low'   , 'Metadata for a single NFT (Ethereum mainnet).'),
    ('crypto_binance_price'                        , 'crypto.binance_price'                        , 'low'   , "Spot price for a Binance symbol like 'BTCUSDT'."),
    ('crypto_binance_klines'                       , 'crypto.binance_klines'                       , 'low'   , 'Candles for a Binance symbol. interval default 1d, limit default 20.'),
    ('crypto_coinbase_price'                       , 'crypto.coinbase_price'                       , 'low'   , "Coinbase spot price. symbol like 'BTC-USD'."),
    ('crypto_kraken_price'                         , 'crypto.kraken_price'                         , 'low'   , "Kraken ticker for a pair like 'XBTUSD' or 'ETHUSD'."),
    ('crypto_portfolio_define'                     , 'crypto.portfolio_define'                     , 'low'   , "Define or replace a named portfolio. holdings=[{'symbol':'BTC','amount':0.5}, ...]"),
    ('crypto_portfolio_value'                      , 'crypto.portfolio_value'                      , 'low'   , 'Current USD value of a named portfolio.'),
    ('crypto_portfolio_list'                       , 'crypto.portfolio_list'                       , 'low'   , 'List all defined portfolios.'),
    ('crypto_portfolio_delete'                     , 'crypto.portfolio_delete'                     , 'high'  , 'Delete a named portfolio.'),
    ('crypto_usd_to_btc'                           , 'crypto.usd_to_btc'                           , 'low'   , 'Convert a USD amount to BTC using current CoinGecko price.'),
    ('crypto_btc_to_usd'                           , 'crypto.btc_to_usd'                           , 'low'   , 'Convert a BTC amount to USD using current CoinGecko price.'),
    ('crypto_market_cap_top'                       , 'crypto.market_cap_top'                       , 'low'   , 'Top coins by market cap (CoinGecko).'),
    # -- search --
    ('search_brave'                                , 'search.brave'                                , 'low'   , 'Brave Web Search.'),
    ('search_brave_news'                           , 'search.brave_news'                           , 'low'   , 'Brave News Search.'),
    ('search_ddg'                                  , 'search.ddg'                                  , 'low'   , 'DuckDuckGo Instant Answer API. No key required.'),
    ('search_serpapi'                              , 'search.serpapi'                              , 'low'   , 'SerpApi (Google/Bing/etc.). Needs SERPAPI_KEY.'),
    ('search_kagi'                                 , 'search.kagi'                                 , 'low'   , 'Kagi Search API. Needs KAGI_API_KEY (paid).'),
    ('search_you'                                  , 'search.you'                                  , 'low'   , 'You.com Search API. Needs YOU_API_KEY.'),
    ('search_tavily'                               , 'search.tavily'                               , 'low'   , 'Tavily Search — designed for AI agents. Needs TAVILY_API_KEY.'),
    # -- social --
    ('social_twitter_search'                       , 'social.twitter_search'                       , 'low'   , 'Recent search (last 7 days). Needs TWITTER_BEARER_TOKEN.'),
    ('social_twitter_user'                         , 'social.twitter_user'                         , 'low'   , 'Lookup user by handle. Needs TWITTER_BEARER_TOKEN.'),
    ('social_twitter_user_tweets'                  , 'social.twitter_user_tweets'                  , 'low'   , 'Fetch recent tweets for a handle. Needs TWITTER_BEARER_TOKEN.'),
    ('social_twitter_trending'                     , 'social.twitter_trending'                     , 'low'   , 'Trends by WOEID (1=Worldwide, 23424977=US). Uses v1.1 trends endpoint'),
    ('social_twitter_post'                         , 'social.twitter_post'                         , 'high'  , 'Post a tweet (or reply). HIGH risk.'),
    ('social_reddit_subreddit_about'               , 'social.reddit_subreddit_about'               , 'low'   , 'GET /r/{name}/about — sidebar/meta. No auth required.'),
    ('social_reddit_subscribe'                     , 'social.reddit_subscribe'                     , 'medium', 'Subscribe to a subreddit. MEDIUM risk.'),
    ('social_reddit_post'                          , 'social.reddit_post'                          , 'high'  , 'Submit a post. HIGH risk. Needs REDDIT_USER_OAUTH_TOKEN.'),
    ('social_reddit_comment'                       , 'social.reddit_comment'                       , 'high'  , 'Post a comment. HIGH risk. Needs REDDIT_USER_OAUTH_TOKEN.'),
    ('social_reddit_inbox'                         , 'social.reddit_inbox'                         , 'low'   , "Fetch the authed user's inbox. Needs REDDIT_USER_OAUTH_TOKEN."),
    ('social_bluesky_feed_timeline'                , 'social.bluesky_feed_timeline'                , 'low'   , "Fetch the authed user's home timeline. Needs BSKY_HANDLE + BSKY_APP_PASSWORD."),
    ('social_bluesky_post'                         , 'social.bluesky_post'                         , 'low'   , 'Create a post. MEDIUM risk. Needs BSKY_HANDLE + BSKY_APP_PASSWORD.'),
    ('social_bluesky_user'                         , 'social.bluesky_user'                         , 'low'   , 'Lookup a Bluesky profile by handle. Public; no auth required.'),
    ('social_mastodon_post'                        , 'social.mastodon_post'                        , 'low'   , 'Create a status. MEDIUM risk. Needs MASTODON_ACCESS_TOKEN.'),
    ('social_mastodon_feed_timeline'               , 'social.mastodon_feed_timeline'               , 'low'   , 'Fetch the home timeline. Needs MASTODON_ACCESS_TOKEN.'),
    ('social_linkedin_profile_lookup'              , 'social.linkedin_profile_lookup'              , 'low'   , 'Look up a LinkedIn profile via Proxycurl. Needs PROXYCURL_API_KEY.'),
    ('social_linkedin_post'                        , 'social.linkedin_post'                        , 'low'   , 'Share a text post on LinkedIn. MEDIUM risk. Needs LINKEDIN_ACCESS_TOKEN'),
    ('social_youtube_channel_stats'                , 'social.youtube_channel_stats'                , 'low'   , 'Get channel stats by id or @handle. Needs YOUTUBE_API_KEY.'),
    ('social_youtube_video_info'                   , 'social.youtube_video_info'                   , 'low'   , 'Get video metadata by id. Needs YOUTUBE_API_KEY.'),
    ('social_youtube_video_comments'               , 'social.youtube_video_comments'               , 'low'   , 'Top-level comments for a video. Needs YOUTUBE_API_KEY.'),
    ('social_news_newsapi'                         , 'social.news_newsapi'                         , 'low'   , 'NewsAPI.org /v2/everything. Needs NEWSAPI_KEY.'),
    ('social_news_nytimes'                         , 'social.news_nytimes'                         , 'low'   , 'NYTimes Article Search. Needs NYT_API_KEY.'),
    ('social_news_bbc_top'                         , 'social.news_bbc_top'                         , 'low'   , 'BBC top stories via public RSS. No key required.'),
    # -- image --
    ('image_remove_background'                     , 'image.remove_background'                     , 'medium', 'remove_background'),
    ('image_replace_background'                    , 'image.replace_background'                    , 'low'   , 'replace_background'),
    ('image_crop_to_subject'                       , 'image.crop_to_subject'                       , 'low'   , 'crop_to_subject'),
    ('image_upscale'                               , 'image.upscale'                               , 'medium', 'upscale'),
    ('image_denoise'                               , 'image.denoise'                               , 'low'   , 'denoise'),
    ('image_enhance_lighting'                      , 'image.enhance_lighting'                      , 'low'   , 'enhance_lighting'),
    ('image_detect_faces'                          , 'image.detect_faces'                          , 'low'   , 'detect_faces'),
    ('image_blur_faces'                            , 'image.blur_faces'                            , 'low'   , 'blur_faces'),
    ('image_count_objects'                         , 'image.count_objects'                         , 'low'   , 'count_objects'),
    ('image_find_object_bbox'                      , 'image.find_object_bbox'                      , 'low'   , 'find_object_bbox'),
    ('image_ocr_full'                              , 'image.ocr_full'                              , 'low'   , 'ocr_full'),
    ('image_ocr_bboxes'                            , 'image.ocr_bboxes'                            , 'low'   , 'ocr_bboxes'),
    ('image_qr_decode'                             , 'image.qr_decode'                             , 'low'   , 'qr_decode'),
    ('image_qr_generate'                           , 'image.qr_generate'                           , 'medium', 'qr_generate'),
    ('image_generate_via_openai'                   , 'image.generate_via_openai'                   , 'medium', 'generate_via_openai'),
    ('image_generate_via_stability'                , 'image.generate_via_stability'                , 'medium', 'generate_via_stability'),
    ('image_style_transfer'                        , 'image.style_transfer'                        , 'low'   , 'style_transfer'),
    ('image_colorize_grayscale'                    , 'image.colorize_grayscale'                    , 'low'   , 'colorize_grayscale'),
    # -- audio --
    ('audio_clone_via_elevenlabs'                  , 'audio.clone_via_elevenlabs'                  , 'low'   , 'clone_via_elevenlabs'),
    ('audio_list_elevenlabs_voices'                , 'audio.list_elevenlabs_voices'                , 'low'   , 'list_elevenlabs_voices'),
    ('audio_voice_change_pitch'                    , 'audio.voice_change_pitch'                    , 'low'   , 'voice_change_pitch'),
    ('audio_voice_to_text_local'                   , 'audio.voice_to_text_local'                   , 'low'   , 'voice_to_text_local'),
    # -- image --
    ('image_list_recent_outputs'                   , 'image.list_recent_outputs'                   , 'low'   , 'list_recent_outputs'),
    ('image_compare_two'                           , 'image.compare_two'                           , 'low'   , 'compare_two'),
    ('image_thumbnail'                             , 'image.thumbnail'                             , 'low'   , 'thumbnail'),
    # -- audio --
    ('audio_record_start'                          , 'audio.record_start'                          , 'low'   , 'Start recording audio from speakers (system audio) or microphone.'),
    ('audio_record_stop'                           , 'audio.record_stop'                           , 'medium', 'Stop a recording. If recording_id omitted, stops the most recent.'),
    ('audio_record_status'                         , 'audio.record_status'                         , 'low'   , '_record_status'),
    ('audio_recordings_list'                       , 'audio.recordings_list'                       , 'low'   , '_recordings_list'),
    ('audio_recording_transcribe'                  , 'audio.recording_transcribe'                  , 'medium', 'Transcribe a saved recording using faster-whisper.'),
    ('audio_meeting_minutes_from_recording'        , 'audio.meeting_minutes_from_recording'        , 'low'   , 'Transcribe a recording, then generate a meeting minutes PDF.'),
    ('audio_record_meeting'                        , 'audio.record_meeting'                        , 'medium', 'Convenience: start recording (both), wait N minutes, stop, transcribe,'),
    ('audio_recording_delete'                      , 'audio.recording_delete'                      , 'high'  , '_recording_delete'),
    ('audio_recording_play'                        , 'audio.recording_play'                        , 'medium', '_recording_play'),
    # -- file --
    ('file_fulltext_search'                        , 'file.fulltext_search'                        , 'low'   , 'Ripgrep query against text files under given roots.'),
    ('file_find_by_name'                           , 'file.find_by_name'                           , 'low'   , 'Find files whose name matches a glob pattern.'),
    ('file_find_by_age'                            , 'file.find_by_age'                            , 'low'   , 'Find files modified in the last N days (or older if `older=True`).'),
    ('file_large_files'                            , 'file.large_files'                            , 'low'   , 'Files larger than min_mb under root.'),
    ('file_recent_modifications'                   , 'file.recent_modifications'                   , 'low'   , 'Files modified in the last N hours.'),
    ('file_semantic_index'                         , 'file.semantic_index'                         , 'low'   , 'Index text files into the semantic store.'),
    ('file_semantic_search'                        , 'file.semantic_search'                        , 'low'   , 'Semantic search over indexed chunks.'),
    ('file_semantic_index_status'                  , 'file.semantic_index_status'                  , 'low'   , '_semantic_index_status'),
    ('file_semantic_index_clear'                   , 'file.semantic_index_clear'                   , 'low'   , '_semantic_index_clear'),
    ('file_ask'                                    , 'file.ask'                                    , 'low'   , "Semantic search + summary: 'what was that idea I had about X?'"),
    # -- automation --
    ('automation_macro_record_start'               , 'automation.macro_record_start'               , 'high'  , 'Start recording a keystroke/mouse macro using xinput.'),
    ('automation_macro_record_stop'                , 'automation.macro_record_stop'                , 'medium', '_macro_record_stop'),
    ('automation_macro_list'                       , 'automation.macro_list'                       , 'low'   , '_macro_list'),
    ('automation_macro_play'                       , 'automation.macro_play'                       , 'medium', 'Replay a recorded macro.'),
    ('automation_macro_delete'                     , 'automation.macro_delete'                     , 'high'  , '_macro_delete'),
    ('automation_screen_record_start'              , 'automation.screen_record_start'              , 'high'  , 'Start screen recording via ffmpeg → mp4.'),
    ('automation_screen_record_stop'               , 'automation.screen_record_stop'               , 'medium', '_screen_record_stop'),
    ('automation_screen_record_list'               , 'automation.screen_record_list'               , 'low'   , '_screen_record_list'),
    ('automation_keystroke_sequence'               , 'automation.keystroke_sequence'               , 'medium', 'Send a sequence of keystrokes via xdotool.'),
    ('automation_mouse_path'                       , 'automation.mouse_path'                       , 'medium', 'Move the mouse along a path of (x,y) points.'),
    ('automation_click_at_relative'                , 'automation.click_at_relative'                , 'medium', 'Click at a relative (0–1) position on a monitor.'),
    ('automation_hotkey_register'                  , 'automation.hotkey_register'                  , 'medium', 'Register a global hotkey → fires a Leon tool.'),
    ('automation_hotkey_list'                      , 'automation.hotkey_list'                      , 'medium', '_hotkey_list'),
    ('automation_hotkey_unregister'                , 'automation.hotkey_unregister'                , 'medium', '_hotkey_unregister'),

    # ── Phase 10: finance / crm_reading / secrets / wellness ──
    # -- finance --
    ('finance_txn_add'                             , 'finance.txn_add'                             , 'medium', 'Insert a transaction. Required: date, amount, category, description.'),
    ('finance_txn_list'                            , 'finance.txn_list'                            , 'low'   , 'List recent transactions with optional filters.'),
    ('finance_txn_search'                          , 'finance.txn_search'                          , 'low'   , 'Substring search across description / category / account / tags.'),
    ('finance_txn_update'                          , 'finance.txn_update'                          , 'medium', 'Update fields on a transaction. txn_id required.'),
    ('finance_txn_delete'                          , 'finance.txn_delete'                          , 'high'  , 'Delete a transaction by id.'),
    ('finance_txn_today'                           , 'finance.txn_today'                           , 'low'   , "Today's transactions, newest first."),
    ('finance_txn_this_month'                      , 'finance.txn_this_month'                      , 'low'   , "This calendar month's transactions."),
    ('finance_txn_categorize'                      , 'finance.txn_categorize'                      , 'low'   , 'Heuristic categorization of a free-form description.'),
    ('finance_account_add'                         , 'finance.account_add'                         , 'medium', 'Add an account. type must be one of the valid set.'),
    ('finance_account_list'                        , 'finance.account_list'                        , 'low'   , 'All accounts.'),
    ('finance_account_balance'                     , 'finance.account_balance'                     , 'low'   , 'Balance for a single account by name.'),
    ('finance_account_update_balance'              , 'finance.account_update_balance'              , 'medium', "Set an account's balance to a new explicit value."),
    ('finance_account_transfer'                    , 'finance.account_transfer'                    , 'medium', 'Move funds between two accounts. Logs two transactions for audit.'),
    ('finance_budget_set'                          , 'finance.budget_set'                          , 'medium', 'Set (or update) a monthly budget for a category.'),
    ('finance_budget_list'                         , 'finance.budget_list'                         , 'low'   , 'All budgets.'),
    ('finance_budget_status'                       , 'finance.budget_status'                       , 'low'   , 'For one or all budgets, return spent/limit/% used/days left.'),
    ('finance_budget_alerts'                       , 'finance.budget_alerts'                       , 'low'   , 'Budgets where spent% >= alert_threshold_pct for the current month.'),
    ('finance_recurring_add'                       , 'finance.recurring_add'                       , 'medium', 'Add a recurring bill / subscription.'),
    ('finance_recurring_list'                      , 'finance.recurring_list'                      , 'low'   , 'Recurring bills due within `upcoming_days` (default 30).'),
    ('finance_recurring_mark_paid'                 , 'finance.recurring_mark_paid'                 , 'low'   , 'Mark a recurring bill paid: logs a transaction, advances next_due,'),
    ('finance_recurring_delete'                    , 'finance.recurring_delete'                    , 'high'  , 'Delete a recurring bill by name or id.'),
    ('finance_investment_add'                      , 'finance.investment_add'                      , 'medium', 'Add a holding. cost_basis is total cost paid (not per-share).'),
    ('finance_investment_list'                     , 'finance.investment_list'                     , 'low'   , 'All holdings.'),
    ('finance_investment_current_value'            , 'finance.investment_current_value'            , 'low'   , 'Look up current price per holding, compute market value, sum total.'),
    ('finance_investment_pnl'                      , 'finance.investment_pnl'                      , 'low'   , 'Profit / loss vs cost basis across all holdings.'),
    ('finance_net_worth'                           , 'finance.net_worth'                           , 'low'   , 'Sum of account balances + current investment value. Credit accounts'),
    ('finance_monthly_summary'                     , 'finance.monthly_summary'                     , 'low'   , 'Income / expense / savings rate for a YYYY-MM (default current).'),
    ('finance_yearly_summary'                      , 'finance.yearly_summary'                      , 'low'   , 'Income / expense / net for a calendar year.'),
    ('finance_category_breakdown'                  , 'finance.category_breakdown'                  , 'low'   , 'Top spending categories for a month (default current).'),
    ('finance_cash_flow_chart_data'                , 'finance.cash_flow_chart_data'                , 'low'   , 'Per-month income/expense/net for the last N months. Suitable for'),
    ('finance_spending_trend'                      , 'finance.spending_trend'                      , 'low'   , 'Monthly spend in one category over the last N months.'),
    ('finance_import_csv'                          , 'finance.import_csv'                          , 'medium', 'Import a bank-style CSV. `mapping` overrides the default header→field'),
    ('finance_export_csv'                          , 'finance.export_csv'                          , 'low'   , 'Export all transactions (optionally since YYYY-MM-DD) to a CSV file.'),
    # -- crm --
    ('crm_airtable_list_records'                   , 'crm.airtable_list_records'                   , 'low'   , 'List records from an Airtable table.'),
    ('crm_airtable_get_record'                     , 'crm.airtable_get_record'                     , 'low'   , 'Get one Airtable record by ID.'),
    ('crm_airtable_create_record'                  , 'crm.airtable_create_record'                  , 'medium', 'Create a record in an Airtable table. MEDIUM.'),
    ('crm_airtable_update_record'                  , 'crm.airtable_update_record'                  , 'medium', 'Patch fields on an Airtable record. MEDIUM.'),
    ('crm_airtable_delete_record'                  , 'crm.airtable_delete_record'                  , 'high'  , 'Delete an Airtable record by ID. HIGH.'),
    ('crm_airtable_list_tables'                    , 'crm.airtable_list_tables'                    , 'low'   , 'List tables in a base via the meta API.'),
    ('crm_pipedrive_deals_list'                    , 'crm.pipedrive_deals_list'                    , 'low'   , 'List Pipedrive deals (default: open).'),
    ('crm_pipedrive_deal_get'                      , 'crm.pipedrive_deal_get'                      , 'low'   , 'Get one Pipedrive deal by ID.'),
    ('crm_pipedrive_deal_create'                   , 'crm.pipedrive_deal_create'                   , 'medium', 'Create a Pipedrive deal. MEDIUM.'),
    ('crm_pipedrive_deal_update_stage'             , 'crm.pipedrive_deal_update_stage'             , 'medium', 'Move a deal to a different stage. MEDIUM.'),
    ('crm_pipedrive_persons_list'                  , 'crm.pipedrive_persons_list'                  , 'low'   , 'List Pipedrive persons.'),
    ('crm_pipedrive_person_create'                 , 'crm.pipedrive_person_create'                 , 'medium', 'Create a Pipedrive person. MEDIUM.'),
    ('crm_pipedrive_activities_today'              , 'crm.pipedrive_activities_today'              , 'low'   , "List today's Pipedrive activities (tasks)."),
    ('crm_pipedrive_organizations_list'            , 'crm.pipedrive_organizations_list'            , 'low'   , 'List Pipedrive organizations.'),
    ('crm_hubspot_contacts_search'                 , 'crm.hubspot_contacts_search'                 , 'low'   , 'Search HubSpot contacts by free text (name/email).'),
    ('crm_hubspot_contact_create'                  , 'crm.hubspot_contact_create'                  , 'medium', 'Create a HubSpot contact. MEDIUM.'),
    ('crm_hubspot_deals_pipeline_view'             , 'crm.hubspot_deals_pipeline_view'             , 'low'   , 'List deals grouped by stage for a pipeline (default pipeline if omitted).'),
    ('crm_hubspot_deal_create'                     , 'crm.hubspot_deal_create'                     , 'medium', 'Create a HubSpot deal. MEDIUM.'),
    ('crm_hubspot_companies_search'                , 'crm.hubspot_companies_search'                , 'low'   , 'Search HubSpot companies.'),
    ('crm_hubspot_note_create'                     , 'crm.hubspot_note_create'                     , 'medium', 'Create a note engagement and associate it with a contact. MEDIUM.'),
    ('crm_hubspot_email_log'                       , 'crm.hubspot_email_log'                       , 'medium', 'Log an email engagement against a contact. MEDIUM.'),
    # -- read --
    ('read_pocket_save'                            , 'read.pocket_save'                            , 'medium', 'Save a URL to Pocket. MEDIUM.'),
    ('read_pocket_list'                            , 'read.pocket_list'                            , 'low'   , 'List Pocket items. state: unread / archive / all.'),
    ('read_pocket_archive'                         , 'read.pocket_archive'                         , 'low'   , 'Archive a Pocket item. MEDIUM.'),
    ('read_pocket_delete'                          , 'read.pocket_delete'                          , 'high'  , 'Delete a Pocket item. HIGH.'),
    ('read_instapaper_save'                        , 'read.instapaper_save'                        , 'medium', 'Save a URL to Instapaper via the simple API. MEDIUM.'),
    ('read_instapaper_list'                        , 'read.instapaper_list'                        , 'low'   , 'List unread Instapaper bookmarks. Note: the simple API exposes only'),
    ('read_raindrop_save'                          , 'read.raindrop_save'                          , 'medium', 'Save a bookmark to Raindrop.io. MEDIUM.'),
    ('read_raindrop_list'                          , 'read.raindrop_list'                          , 'low'   , 'List bookmarks in a Raindrop collection (0 = all).'),
    ('read_raindrop_collections_list'              , 'read.raindrop_collections_list'              , 'low'   , 'List your Raindrop collections.'),
    ('read_raindrop_search'                        , 'read.raindrop_search'                        , 'low'   , 'Full-text search across Raindrop bookmarks.'),
    ('read_save_anywhere'                          , 'read.save_anywhere'                          , 'medium', 'Save a URL to the first available read-later service.'),
    # -- crm --
    ('crm_unified_contact_search'                  , 'crm.unified_contact_search'                  , 'low'   , 'Fan a query out across every configured CRM and merge results.'),
    # -- secrets --
    ('secrets_bw_status'                           , 'secrets.bw_status'                           , 'low'   , 'bw_status'),
    ('secrets_bw_unlock'                           , 'secrets.bw_unlock'                           , 'medium', 'bw_unlock'),
    ('secrets_bw_lock'                             , 'secrets.bw_lock'                             , 'low'   , 'bw_lock'),
    ('secrets_bw_list'                             , 'secrets.bw_list'                             , 'low'   , 'bw_list'),
    ('secrets_bw_get_password'                     , 'secrets.bw_get_password'                     , 'low'   , 'bw_get_password'),
    ('secrets_bw_get_username'                     , 'secrets.bw_get_username'                     , 'low'   , 'bw_get_username'),
    ('secrets_bw_generate_password'                , 'secrets.bw_generate_password'                , 'medium', 'bw_generate_password'),
    ('secrets_bw_create_item'                      , 'secrets.bw_create_item'                      , 'medium', 'bw_create_item'),
    ('secrets_op_signin_status'                    , 'secrets.op_signin_status'                    , 'medium', 'op_signin_status'),
    ('secrets_op_list_items'                       , 'secrets.op_list_items'                       , 'low'   , 'op_list_items'),
    ('secrets_op_get_field'                        , 'secrets.op_get_field'                        , 'low'   , 'op_get_field'),
    ('secrets_op_get_password'                     , 'secrets.op_get_password'                     , 'low'   , 'op_get_password'),
    ('secrets_op_create_login'                     , 'secrets.op_create_login'                     , 'medium', 'op_create_login'),
    ('secrets_gpg_encrypt'                         , 'secrets.gpg_encrypt'                         , 'medium', 'gpg_encrypt'),
    ('secrets_gpg_decrypt'                         , 'secrets.gpg_decrypt'                         , 'medium', 'gpg_decrypt'),
    ('secrets_gpg_list_keys'                       , 'secrets.gpg_list_keys'                       , 'low'   , 'gpg_list_keys'),
    ('secrets_gpg_sign'                            , 'secrets.gpg_sign'                            , 'medium', 'gpg_sign'),
    ('secrets_gpg_verify'                          , 'secrets.gpg_verify'                          , 'low'   , 'gpg_verify'),
    ('secrets_ssh_list_keys'                       , 'secrets.ssh_list_keys'                       , 'low'   , 'ssh_list_keys'),
    ('secrets_ssh_add_to_agent'                    , 'secrets.ssh_add_to_agent'                    , 'medium', 'ssh_add_to_agent'),
    ('secrets_ssh_authorized_keys'                 , 'secrets.ssh_authorized_keys'                 , 'low'   , 'ssh_authorized_keys'),
    ('secrets_vault_set'                           , 'secrets.vault_set'                           , 'medium', 'vault_set'),
    ('secrets_vault_get'                           , 'secrets.vault_get'                           , 'low'   , 'vault_get'),
    ('secrets_vault_list'                          , 'secrets.vault_list'                          , 'low'   , 'vault_list'),
    ('secrets_vault_delete'                        , 'secrets.vault_delete'                        , 'high'  , 'vault_delete'),
    ('secrets_totp_generate'                       , 'secrets.totp_generate'                       , 'medium', 'totp_generate'),
    ('secrets_totp_save'                           , 'secrets.totp_save'                           , 'medium', 'totp_save'),
    ('secrets_totp_get_code'                       , 'secrets.totp_get_code'                       , 'low'   , 'totp_get_code'),
    ('secrets_totp_list'                           , 'secrets.totp_list'                           , 'low'   , 'totp_list'),
    ('secrets_generate_random_password'            , 'secrets.generate_random_password'            , 'medium', 'generate_random_password'),
    ('secrets_generate_passphrase'                 , 'secrets.generate_passphrase'                 , 'medium', 'generate_passphrase'),
    # -- wellness --
    ('wellness_workout_log'                        , 'wellness.workout_log'                        , 'medium', 'workout_log'),
    ('wellness_workout_list'                       , 'wellness.workout_list'                       , 'low'   , 'workout_list'),
    ('wellness_workout_summary_week'               , 'wellness.workout_summary_week'               , 'low'   , 'workout_summary_week'),
    ('wellness_workout_streak'                     , 'wellness.workout_streak'                     , 'low'   , 'workout_streak'),
    ('wellness_sleep_log'                          , 'wellness.sleep_log'                          , 'medium', 'sleep_log'),
    ('wellness_sleep_list'                         , 'wellness.sleep_list'                         , 'low'   , 'sleep_list'),
    ('wellness_sleep_summary_week'                 , 'wellness.sleep_summary_week'                 , 'low'   , 'sleep_summary_week'),
    ('wellness_sleep_debt'                         , 'wellness.sleep_debt'                         , 'low'   , 'sleep_debt'),
    ('wellness_water_add'                          , 'wellness.water_add'                          , 'medium', 'water_add'),
    ('wellness_water_today'                        , 'wellness.water_today'                        , 'low'   , 'water_today'),
    ('wellness_water_streak'                       , 'wellness.water_streak'                       , 'low'   , 'water_streak'),
    ('wellness_water_reminder'                     , 'wellness.water_reminder'                     , 'low'   , 'water_reminder'),
    ('wellness_meal_log'                           , 'wellness.meal_log'                           , 'medium', 'meal_log'),
    ('wellness_meal_list'                          , 'wellness.meal_list'                          , 'low'   , 'meal_list'),
    ('wellness_calories_today'                     , 'wellness.calories_today'                     , 'low'   , 'calories_today'),
    ('wellness_macros_today'                       , 'wellness.macros_today'                       , 'low'   , 'macros_today'),
    ('wellness_calorie_balance'                    , 'wellness.calorie_balance'                    , 'low'   , 'calorie_balance'),
    ('wellness_mood_check'                         , 'wellness.mood_check'                         , 'low'   , 'mood_check'),
    ('wellness_energy_trend'                       , 'wellness.energy_trend'                       , 'low'   , 'energy_trend'),
    ('wellness_focus_trend'                        , 'wellness.focus_trend'                        , 'low'   , 'focus_trend'),
    ('wellness_mood_correlation'                   , 'wellness.mood_correlation'                   , 'low'   , 'Correlate avg daily energy with another daily metric.'),
    ('wellness_weight_log'                         , 'wellness.weight_log'                         , 'medium', 'weight_log'),
    ('wellness_weight_trend'                       , 'wellness.weight_trend'                       , 'low'   , 'weight_trend'),
    ('wellness_bp_log'                             , 'wellness.bp_log'                             , 'medium', 'bp_log'),
    ('wellness_hr_log'                             , 'wellness.hr_log'                             , 'medium', 'hr_log'),
    ('wellness_vitals_summary'                     , 'wellness.vitals_summary'                     , 'low'   , 'vitals_summary'),
    ('wellness_meditation_log'                     , 'wellness.meditation_log'                     , 'medium', 'meditation_log'),
    ('wellness_meditation_streak'                  , 'wellness.meditation_streak'                  , 'low'   , 'meditation_streak'),
    ('wellness_eye_break_check'                    , 'wellness.eye_break_check'                    , 'low'   , 'Minutes since last meditation OR break entry.'),
    ('wellness_daily_health_summary'               , 'wellness.daily_health_summary'               , 'low'   , 'daily_health_summary'),
    ('wellness_weekly_health_report'               , 'wellness.weekly_health_report'               , 'low'   , 'Markdown report — designed to feed docgen.markdown_to_pdf.'),
    ('wellness_set_target'                         , 'wellness.set_target'                         , 'medium', 'set_target'),

    # ── PC control deep ──
    ('pc_window_snap_quarter'                  , 'pc.window_snap_quarter'                  , 'medium', 'Snap active window to a quarter of the current monitor.'),
    ('pc_window_move_to_next_monitor'          , 'pc.window_move_to_next_monitor'          , 'medium', 'Move active window to the next monitor (clockwise by index).'),
    ('pc_window_opacity'                       , 'pc.window_opacity'                       , 'low'   , 'Set window transparency (0.0-1.0) via _NET_WM_WINDOW_OPACITY.'),
    ('pc_window_sticky_toggle'                 , 'pc.window_sticky_toggle'                 , 'medium', "Toggle 'show on all workspaces' for the active window."),
    ('pc_window_minimize_all'                  , 'pc.window_minimize_all'                  , 'high'  , 'Minimize every visible window (show desktop).'),
    ('pc_window_restore_all'                   , 'pc.window_restore_all'                   , 'medium', 'Restore all minimized windows (undo show-desktop).'),
    ('pc_window_cycle'                         , 'pc.window_cycle'                         , 'low'   , 'Alt-Tab to next window.'),
    ('pc_window_focus_by_class'                , 'pc.window_focus_by_class'                , 'low'   , 'Focus a window matching WM_CLASS substring (case-insensitive).'),
    ('pc_window_close_active'                  , 'pc.window_close_active'                  , 'high'  , 'Close the active window (HIGH risk — sends WM_DELETE).'),
    ('pc_window_force_kill'                    , 'pc.window_force_kill'                    , 'high'  , "Hard-kill the active window's process (HIGH risk)."),
    ('pc_workspace_list_windows'               , 'pc.workspace_list_windows'               , 'low'   , 'List windows on current (or any) workspace.'),
    ('pc_workspace_count'                      , 'pc.workspace_count'                      , 'low'   , 'How many workspaces exist + which is current.'),
    ('pc_workspace_send_window'                , 'pc.workspace_send_window'                , 'low'   , 'Send active window to a numbered workspace.'),
    ('pc_mouse_scroll_precise'                 , 'pc.mouse_scroll_precise'                 , 'low'   , 'Scroll N units (positive=down) precisely.'),
    ('pc_mouse_smooth_drag'                    , 'pc.mouse_smooth_drag'                    , 'medium', 'Drag from (x1,y1) to (x2,y2) along a smooth path.'),
    ('pc_mouse_position'                       , 'pc.mouse_position'                       , 'low'   , "Current cursor position + which monitor it's on."),
    ('pc_mouse_center_active'                  , 'pc.mouse_center_active'                  , 'low'   , 'Move mouse to the center of the active window (for screen readers / focus indicators).'),
    ('pc_keyboard_hold_combo'                  , 'pc.keyboard_hold_combo'                  , 'medium', 'Press a keyboard combo where modifiers are held for the duration.'),
    ('pc_keyboard_type_human'                  , 'pc.keyboard_type_human'                  , 'medium', 'Type text with human-like variable delays (avoids triggering bot detection).'),
    ('pc_clipboard_history_add'                , 'pc.clipboard_history_add'                , 'low'   , 'Save current clipboard contents to history. Useful to call from cron'),
    ('pc_clipboard_history_list'               , 'pc.clipboard_history_list'               , 'low'   , 'List recent clipboard entries.'),
    ('pc_clipboard_history_clear'              , 'pc.clipboard_history_clear'              , 'medium', 'Wipe clipboard history.'),
    ('pc_clipboard_history_restore'            , 'pc.clipboard_history_restore'            , 'medium', 'Put history entry #N back into the active clipboard.'),
    ('pc_display_list'                         , 'pc.display_list'                         , 'low'   , 'List all monitors with geometry + primary flag.'),
    ('pc_display_brightness_set'               , 'pc.display_brightness_set'               , 'medium', 'Set brightness on a specific output via xrandr.'),
    ('pc_display_brightness_all'               , 'pc.display_brightness_all'               , 'low'   , 'Set brightness on every connected monitor.'),
    ('pc_display_rotate'                       , 'pc.display_rotate'                       , 'low'   , 'Rotate a monitor.'),
    ('pc_audio_list_streams'                   , 'pc.audio_list_streams'                   , 'low'   , 'List per-application audio streams (pactl sink-inputs).'),
    ('pc_audio_set_app_volume'                 , 'pc.audio_set_app_volume'                 , 'medium', 'Set volume for one application stream.'),
    ('pc_audio_mute_app'                       , 'pc.audio_mute_app'                       , 'medium', "Toggle mute on an application's audio stream."),
    ('pc_system_lock_screen'                   , 'pc.system_lock_screen'                   , 'low'   , 'Lock the screen via loginctl.'),
    ('pc_system_suspend'                       , 'pc.system_suspend'                       , 'high'  , 'Suspend (sleep) the machine. HIGH risk.'),
    ('pc_system_reboot'                        , 'pc.system_reboot'                        , 'high'  , 'Reboot. HIGH risk — requires polkit consent.'),
    ('pc_power_status'                         , 'pc.power_status'                         , 'low'   , 'Battery + AC + thermal summary via upower / sensors / /proc/acpi.'),
    ('pc_screenshot_region_picker'             , 'pc.screenshot_region_picker'             , 'low'   , 'Capture a user-selected region (Spectacle / scrot interactive).'),
    ('pc_app_count_running'                    , 'pc.app_count_running'                    , 'low'   , 'Count windows by application class.'),
    ('pc_app_quit_by_class'                    , 'pc.app_quit_by_class'                    , 'high'  , 'Quit (graceful close) all windows of a class.'),

    # ── Phase 12: browser_power / email / calendar / learning ──
    # -- browser --
    ('browser_form_fill_all'                   , 'browser.form_fill_all'                   , 'medium', 'Fill many inputs in one call.'),
    ('browser_form_submit'                     , 'browser.form_submit'                     , 'medium', 'Submit a <form>. With no form_selector, submits the first form on'),
    ('browser_form_extract'                    , 'browser.form_extract'                    , 'low'   , 'Read every input in a form — name, type, current value, label.'),
    ('browser_autofill_login'                  , 'browser.autofill_login'                  , 'medium', 'Heuristically fill a login form — finds the email/username field and'),
    ('browser_tab_group_by_domain'             , 'browser.tab_group_by_domain'             , 'low'   , 'List all open tabs grouped by domain.'),
    ('browser_tab_close_duplicates'            , 'browser.tab_close_duplicates'            , 'medium', 'Close tabs whose URL duplicates an earlier tab; keep the first.'),
    ('browser_tab_close_all_except'            , 'browser.tab_close_all_except'            , 'medium', 'Close every tab whose URL does NOT contain the given substring.'),
    ('browser_tab_pin'                         , 'browser.tab_pin'                         , 'low'   , 'Pin the first tab whose URL contains the substring.'),
    ('browser_tab_unpin'                       , 'browser.tab_unpin'                       , 'low'   , 'Unpin the first tab whose URL contains the substring.'),
    ('browser_tab_move_to_new_window'          , 'browser.tab_move_to_new_window'          , 'low'   , "Pop a tab out into its own window — opens the tab's URL in a fresh"),
    ('browser_tabs_save_session'               , 'browser.tabs_save_session'               , 'low'   , 'Save the URLs of all currently-open tabs to a named session file'),
    ('browser_tabs_restore_session'            , 'browser.tabs_restore_session'            , 'low'   , 'Re-open every tab from a previously saved session.'),
    ('browser_tabs_list_sessions'              , 'browser.tabs_list_sessions'              , 'low'   , 'List all saved tab-sessions with their tab counts and save times.'),
    ('browser_scroll_to_bottom'                , 'browser.scroll_to_bottom'                , 'low'   , 'Scroll to the bottom in increments — triggers lazy/infinite-scroll'),
    ('browser_scroll_to_top'                   , 'browser.scroll_to_top'                   , 'low'   , 'Scroll the page back to the top. args: url_contains (opt).'),
    ('browser_extract_all_links'               , 'browser.extract_all_links'               , 'low'   , 'Pull every <a href> on the page.'),
    ('browser_extract_all_images'              , 'browser.extract_all_images'              , 'low'   , 'Pull every <img src> on the page (with alt text and natural size).'),
    ('browser_extract_main_text'               , 'browser.extract_main_text'               , 'low'   , 'Readability-style main-content extraction — strips nav, header,'),
    ('browser_extract_table'                   , 'browser.extract_table'                   , 'low'   , 'Parse an HTML <table> into a list of row-dicts (keyed by header).'),
    ('browser_count_elements'                  , 'browser.count_elements'                  , 'low'   , 'Count elements matching a CSS selector.'),
    ('browser_element_exists'                  , 'browser.element_exists'                  , 'low'   , 'True/false: does an element matching the CSS selector OR visible'),
    ('browser_highlight_element'               , 'browser.highlight_element'               , 'low'   , 'Inject a bright red outline around a matching element — a visual'),
    ('browser_get_meta_tags'                   , 'browser.get_meta_tags'                   , 'low'   , 'Return all <meta> tags as a dict (keyed by name/property/http-equiv).'),
    ('browser_get_page_performance'            , 'browser.get_page_performance'            , 'low'   , 'Navigation Timing API metrics — load time, DOM-ready, TTFB, etc.'),
    ('browser_get_all_cookies_for_domain'      , 'browser.get_all_cookies_for_domain'      , 'low'   , 'All cookies whose domain matches the given substring. Sensitive'),
    ('browser_set_cookie'                      , 'browser.set_cookie'                      , 'medium', 'Set a cookie via CDP.'),
    ('browser_clear_cookies'                   , 'browser.clear_cookies'                   , 'medium', 'Clear cookies. With `domain`, only cookies for that domain are'),
    ('browser_execute_js'                      , 'browser.execute_js'                      , 'medium', 'Run arbitrary JavaScript in the front (or specified) tab and return'),
    ('browser_wait_for_navigation'             , 'browser.wait_for_navigation'             , 'low'   , 'Block until the page navigates (URL changes) or finishes loading.'),
    ('browser_download_file'                   , 'browser.download_file'                   , 'low'   , 'Download a file by fetching it inside the page context (so cookies /'),
    # -- email --
    ('email_gmail_inbox'                       , 'email.gmail_inbox'                       , 'low'   , 'List inbox messages (messages.list + per-message metadata get).'),
    ('email_gmail_search'                      , 'email.gmail_search'                      , 'low'   , 'Search all mail with Gmail query syntax (e.g. `from:x is:unread`).'),
    ('email_gmail_read'                        , 'email.gmail_read'                        , 'low'   , 'Fetch one message with full decoded body + attachment manifest.'),
    ('email_gmail_thread'                      , 'email.gmail_thread'                      , 'low'   , 'Fetch a whole thread, each message condensed with its decoded body.'),
    ('email_gmail_unread_count'                , 'email.gmail_unread_count'                , 'low'   , 'Total unread count (inbox + label totals from the INBOX label).'),
    ('email_gmail_send'                        , 'email.gmail_send'                        , 'high'  , 'Send an email immediately. HIGH risk.'),
    ('email_gmail_draft'                       , 'email.gmail_draft'                       , 'medium', 'Create a draft (does NOT send). MEDIUM risk.'),
    ('email_gmail_reply'                       , 'email.gmail_reply'                       , 'medium', 'Create a reply *as a draft* (does not send). MEDIUM risk.'),
    ('email_gmail_archive'                     , 'email.gmail_archive'                     , 'medium', 'Remove a message from the inbox (archive). MEDIUM risk.'),
    ('email_gmail_trash'                       , 'email.gmail_trash'                       , 'high'  , 'Move a message to Trash. HIGH risk.'),
    ('email_gmail_mark_read'                   , 'email.gmail_mark_read'                   , 'low'   , 'Mark a message as read (remove UNREAD label).'),
    ('email_gmail_mark_unread'                 , 'email.gmail_mark_unread'                 , 'low'   , 'Mark a message as unread (add UNREAD label).'),
    ('email_gmail_star'                        , 'email.gmail_star'                        , 'low'   , 'Star a message.'),
    ('email_gmail_unstar'                      , 'email.gmail_unstar'                      , 'low'   , 'Remove the star from a message.'),
    ('email_gmail_labels_list'                 , 'email.gmail_labels_list'                 , 'medium', 'List every label on the account.'),
    ('email_gmail_label_add'                   , 'email.gmail_label_add'                   , 'medium', 'Apply a label (by name) to a message — auto-creating it if needed. MEDIUM.'),
    ('email_gmail_label_create'                , 'email.gmail_label_create'                , 'medium', 'Create a new user label. MEDIUM risk.'),
    ('email_gmail_filter_create'               , 'email.gmail_filter_create'               , 'medium', 'Create a Gmail filter. MEDIUM risk.'),
    ('email_gmail_get_attachment'              , 'email.gmail_get_attachment'              , 'low'   , 'Download an attachment to disk.'),
    ('email_triage_inbox'                      , 'email.triage_inbox'                      , 'low'   , 'Classify unread inbox messages into urgent / normal / newsletter / spam.'),
    ('email_summarize_thread'                  , 'email.summarize_thread'                  , 'low'   , 'Summarize a thread — Anthropic API if a key is set, else a text excerpt.'),
    ('email_find_unanswered'                   , 'email.find_unanswered'                   , 'low'   , 'Find threads whose last message is from someone else (you owe a reply).'),
    ('email_important_senders'                 , 'email.important_senders'                 , 'medium', 'Rank inbox senders by frequency — surfaces who emails Dean most.'),
    ('email_cleanup_suggestions'               , 'email.cleanup_suggestions'               , 'low'   , 'Suggest archive/cleanup candidates: old newsletters, large attachments.'),
    ('email_imap_inbox'                        , 'email.imap_inbox'                        , 'low'   , 'List the most recent messages in an IMAP folder.'),
    ('email_imap_search'                       , 'email.imap_search'                       , 'low'   , 'Search an IMAP folder.'),
    ('email_imap_read'                         , 'email.imap_read'                         , 'low'   , 'Fetch one IMAP message by UID with full decoded body + attachment list.'),
    ('email_smtp_send'                         , 'email.smtp_send'                         , 'high'  , 'Send an email through a generic SMTP server. HIGH risk.'),
    ('email_draft_reply_suggestion'            , 'email.draft_reply_suggestion'            , 'medium', 'Generate suggested reply text for a message. Does NOT send or draft.'),
    ('email_extract_action_items'              , 'email.extract_action_items'              , 'low'   , 'Pull TODOs / asks / deadlines out of an email body.'),
    # -- cal --
    ('cal_list_calendars'                      , 'cal.list_calendars'                      , 'low'   , '_cal_list_calendars'),
    ('cal_events_today'                        , 'cal.events_today'                        , 'low'   , '_cal_events_today'),
    ('cal_events_upcoming'                     , 'cal.events_upcoming'                     , 'low'   , '_cal_events_upcoming'),
    ('cal_events_range'                        , 'cal.events_range'                        , 'low'   , '_cal_events_range'),
    ('cal_event_get'                           , 'cal.event_get'                           , 'low'   , '_cal_event_get'),
    ('cal_event_create'                        , 'cal.event_create'                        , 'medium', '_cal_event_create'),
    ('cal_event_update'                        , 'cal.event_update'                        , 'medium', '_cal_event_update'),
    ('cal_event_delete'                        , 'cal.event_delete'                        , 'high'  , '_cal_event_delete'),
    ('cal_event_quick_add'                     , 'cal.event_quick_add'                     , 'medium', '_cal_event_quick_add'),
    ('cal_event_respond'                       , 'cal.event_respond'                       , 'medium', '_cal_event_respond'),
    ('cal_free_busy'                           , 'cal.free_busy'                           , 'low'   , '_cal_free_busy'),
    ('cal_find_free_slots'                     , 'cal.find_free_slots'                     , 'low'   , '_cal_find_free_slots'),
    ('cal_next_free_slot'                      , 'cal.next_free_slot'                      , 'low'   , '_cal_next_free_slot'),
    ('cal_suggest_meeting_times'               , 'cal.suggest_meeting_times'               , 'low'   , '_cal_suggest_meeting_times'),
    ('cal_is_free_now'                         , 'cal.is_free_now'                         , 'low'   , '_cal_is_free_now'),
    ('cal_block_focus_time'                    , 'cal.block_focus_time'                    , 'medium', '_cal_block_focus_time'),
    ('cal_day_load'                            , 'cal.day_load'                            , 'low'   , '_cal_day_load'),
    ('cal_next_event'                          , 'cal.next_event'                          , 'low'   , '_cal_next_event'),
    ('cal_minutes_until_next_meeting'          , 'cal.minutes_until_next_meeting'          , 'low'   , '_cal_minutes_until_next_meeting'),
    ('cal_meeting_prep'                        , 'cal.meeting_prep'                        , 'low'   , 'Best-effort meeting prep brief. Pulls attendee list from the event;'),
    ('cal_week_overview'                       , 'cal.week_overview'                       , 'low'   , '_cal_week_overview'),
    ('cal_detect_conflicts'                    , 'cal.detect_conflicts'                    , 'low'   , '_cal_detect_conflicts'),
    ('cal_recurring_events_list'               , 'cal.recurring_events_list'               , 'low'   , '_cal_recurring_events_list'),
    ('cal_caldav_events_today'                 , 'cal.caldav_events_today'                 , 'low'   , '_cal_caldav_events_today'),
    ('cal_caldav_event_create'                 , 'cal.caldav_event_create'                 , 'medium', '_cal_caldav_event_create'),
    ('cal_local_event_add'                     , 'cal.local_event_add'                     , 'medium', '_cal_local_event_add'),
    ('cal_local_events_today'                  , 'cal.local_events_today'                  , 'low'   , '_cal_local_events_today'),
    ('cal_local_events_upcoming'               , 'cal.local_events_upcoming'               , 'low'   , '_cal_local_events_upcoming'),
    # -- learn --
    ('learn_deck_create'                       , 'learn.deck_create'                       , 'medium', 'deck_create'),
    ('learn_deck_list'                         , 'learn.deck_list'                         , 'low'   , 'deck_list'),
    ('learn_deck_delete'                       , 'learn.deck_delete'                       , 'high'  , 'deck_delete'),
    ('learn_card_add'                          , 'learn.card_add'                          , 'medium', 'card_add'),
    ('learn_card_add_bulk'                     , 'learn.card_add_bulk'                     , 'medium', 'card_add_bulk'),
    ('learn_cards_due'                         , 'learn.cards_due'                         , 'low'   , 'cards_due'),
    ('learn_card_review'                       , 'learn.card_review'                       , 'medium', 'card_review'),
    ('learn_deck_stats'                        , 'learn.deck_stats'                        , 'low'   , 'deck_stats'),
    ('learn_card_edit'                         , 'learn.card_edit'                         , 'low'   , 'card_edit'),
    ('learn_card_delete'                       , 'learn.card_delete'                       , 'high'  , 'card_delete'),
    ('learn_study_start'                       , 'learn.study_start'                       , 'medium', 'study_start'),
    ('learn_study_answer'                      , 'learn.study_answer'                      , 'medium', 'study_answer'),
    ('learn_study_end'                         , 'learn.study_end'                         , 'medium', 'study_end'),
    ('learn_study_history'                     , 'learn.study_history'                     , 'medium', 'study_history'),
    ('learn_study_streak'                      , 'learn.study_streak'                      , 'medium', 'study_streak'),
    ('learn_course_add'                        , 'learn.course_add'                        , 'medium', 'course_add'),
    ('learn_course_list'                       , 'learn.course_list'                       , 'low'   , 'course_list'),
    ('learn_course_update_progress'            , 'learn.course_update_progress'            , 'medium', 'course_update_progress'),
    ('learn_course_complete'                   , 'learn.course_complete'                   , 'medium', 'course_complete'),
    ('learn_courses_summary'                   , 'learn.courses_summary'                   , 'low'   , 'courses_summary'),
    ('learn_skill_add'                         , 'learn.skill_add'                         , 'medium', 'skill_add'),
    ('learn_skill_log_practice'                , 'learn.skill_log_practice'                , 'medium', 'skill_log_practice'),
    ('learn_skill_list'                        , 'learn.skill_list'                        , 'low'   , 'skill_list'),
    ('learn_skill_level_up'                    , 'learn.skill_level_up'                    , 'medium', 'skill_level_up'),
    ('learn_skill_progress'                    , 'learn.skill_progress'                    , 'low'   , 'skill_progress'),
    ('learn_reading_add'                       , 'learn.reading_add'                       , 'medium', 'reading_add'),
    ('learn_reading_list'                      , 'learn.reading_list'                      , 'low'   , 'reading_list_tool'),
    ('learn_reading_update_progress'           , 'learn.reading_update_progress'           , 'medium', 'reading_update_progress'),
    ('learn_reading_finish'                    , 'learn.reading_finish'                    , 'medium', 'reading_finish'),
    ('learn_reading_stats'                     , 'learn.reading_stats'                     , 'low'   , 'reading_stats'),
    ('learn_quiz_from_deck'                    , 'learn.quiz_from_deck'                    , 'low'   , 'quiz_from_deck'),
    ('learn_knowledge_check'                   , 'learn.knowledge_check'                   , 'low'   , 'knowledge_check'),
    ('learn_daily_review'                      , 'learn.daily_review'                      , 'medium', 'daily_review'),
    ('learn_weekly_learning_report'            , 'learn.weekly_learning_report'            , 'low'   , 'weekly_learning_report'),


    # ── Phase 13: project_mgmt / marketing / video / agent_pool ──
    # -- pm --
    ('pm_linear_issues'                        , 'pm.linear_issues'                        , 'low'   , 'List Linear issues, optionally filtered by team key/name and state.'),
    ('pm_linear_issue_get'                     , 'pm.linear_issue_get'                     , 'low'   , 'Fetch a single Linear issue by id or identifier (e.g. ENG-123).'),
    ('pm_linear_issue_create'                  , 'pm.linear_issue_create'                  , 'medium', 'Create a Linear issue.  MEDIUM — mutates remote state.'),
    ('pm_linear_issue_update'                  , 'pm.linear_issue_update'                  , 'medium', 'Update a Linear issue. Pass issue_id + any of title/description/'),
    ('pm_linear_teams'                         , 'pm.linear_teams'                         , 'low'   , 'List Linear teams (id, key, name).'),
    ('pm_linear_my_issues'                     , 'pm.linear_my_issues'                     , 'low'   , 'List Linear issues assigned to the authenticated user.'),
    ('pm_linear_cycles'                        , 'pm.linear_cycles'                        , 'low'   , 'List cycles (sprints) for a Linear team.'),
    ('pm_jira_search'                          , 'pm.jira_search'                          , 'low'   , 'Search Jira issues with a JQL query string.'),
    ('pm_jira_issue_get'                       , 'pm.jira_issue_get'                       , 'low'   , 'Fetch a single Jira issue by key (e.g. PROJ-42).'),
    ('pm_jira_issue_create'                    , 'pm.jira_issue_create'                    , 'medium', 'Create a Jira issue.  MEDIUM — mutates remote state.'),
    ('pm_jira_issue_transition'                , 'pm.jira_issue_transition'                , 'medium', "Transition a Jira issue by transition name (e.g. 'Done')."),
    ('pm_jira_issue_comment'                   , 'pm.jira_issue_comment'                   , 'medium', 'Add a comment to a Jira issue.  MEDIUM — mutates remote state.'),
    ('pm_jira_my_issues'                       , 'pm.jira_my_issues'                       , 'low'   , 'List open Jira issues assigned to the current user.'),
    ('pm_jira_projects'                        , 'pm.jira_projects'                        , 'low'   , 'List Jira projects visible to the current user.'),
    ('pm_jira_sprints'                         , 'pm.jira_sprints'                         , 'low'   , 'List sprints for a Jira board (Agile API).'),
    ('pm_trello_boards'                        , 'pm.trello_boards'                        , 'low'   , 'List Trello boards for the authenticated member.'),
    ('pm_trello_lists'                         , 'pm.trello_lists'                         , 'low'   , 'List the lists (columns) on a Trello board.'),
    ('pm_trello_cards'                         , 'pm.trello_cards'                         , 'low'   , 'List cards in a Trello list.'),
    ('pm_trello_card_create'                   , 'pm.trello_card_create'                   , 'medium', 'Create a Trello card in a list.  MEDIUM — mutates remote state.'),
    ('pm_trello_card_move'                     , 'pm.trello_card_move'                     , 'medium', 'Move a Trello card to another list.  MEDIUM — mutates remote state.'),
    ('pm_trello_card_comment'                  , 'pm.trello_card_comment'                  , 'medium', 'Add a comment to a Trello card.  MEDIUM — mutates remote state.'),
    ('pm_asana_projects'                       , 'pm.asana_projects'                       , 'low'   , 'List Asana projects in a workspace (default: first workspace).'),
    ('pm_asana_tasks'                          , 'pm.asana_tasks'                          , 'low'   , 'List tasks in an Asana project.'),
    ('pm_asana_task_create'                    , 'pm.asana_task_create'                    , 'medium', 'Create an Asana task in a project.  MEDIUM — mutates remote state.'),
    ('pm_asana_task_complete'                  , 'pm.asana_task_complete'                  , 'medium', 'Mark an Asana task complete.  MEDIUM — mutates remote state.'),
    ('pm_asana_my_tasks'                       , 'pm.asana_my_tasks'                       , 'low'   , 'List incomplete Asana tasks assigned to the current user.'),
    ('pm_clickup_spaces'                       , 'pm.clickup_spaces'                       , 'low'   , 'List ClickUp spaces in a team (default: first team).'),
    ('pm_clickup_tasks'                        , 'pm.clickup_tasks'                        , 'low'   , 'List tasks in a ClickUp list.'),
    ('pm_clickup_task_create'                  , 'pm.clickup_task_create'                  , 'medium', 'Create a ClickUp task in a list.  MEDIUM — mutates remote state.'),
    ('pm_clickup_task_update'                  , 'pm.clickup_task_update'                  , 'medium', 'Update a ClickUp task. Pass task_id + any of name/description/'),
    ('pm_github_project_items'                 , 'pm.github_project_items'                 , 'low'   , 'List items in a GitHub Projects v2 board by owner + project number.'),
    ('pm_github_project_list'                  , 'pm.github_project_list'                  , 'low'   , 'List GitHub Projects v2 for an owner (user or org).'),
    ('pm_unified_my_tasks'                     , 'pm.unified_my_tasks'                     , 'low'   , 'Fan out across every configured PM backend and return a single'),
    ('pm_list_configured'                      , 'pm.list_configured'                      , 'low'   , 'Report which PM backends have usable credentials.'),
    # -- marketing --
    ('marketing_mailchimp_lists'               , 'marketing.mailchimp_lists'               , 'low'   , 'List Mailchimp audiences (lists).'),
    ('marketing_mailchimp_list_members'        , 'marketing.mailchimp_list_members'        , 'low'   , 'List members of a Mailchimp audience.'),
    ('marketing_mailchimp_add_subscriber'      , 'marketing.mailchimp_add_subscriber'      , 'medium', 'Add (or update) a subscriber on a Mailchimp audience. MEDIUM.'),
    ('marketing_mailchimp_campaigns'           , 'marketing.mailchimp_campaigns'           , 'low'   , 'List Mailchimp campaigns (most recent first).'),
    ('marketing_mailchimp_campaign_report'     , 'marketing.mailchimp_campaign_report'     , 'low'   , 'Fetch the report (opens, clicks, bounces) for a campaign.'),
    ('marketing_mailchimp_create_campaign'     , 'marketing.mailchimp_create_campaign'     , 'medium', 'Create a regular Mailchimp campaign (draft, not sent). MEDIUM.'),
    ('marketing_convertkit_subscribers'        , 'marketing.convertkit_subscribers'        , 'low'   , 'List ConvertKit subscribers (needs the API secret).'),
    ('marketing_convertkit_add_subscriber'     , 'marketing.convertkit_add_subscriber'     , 'medium', 'Add a subscriber to ConvertKit (via the account-wide form). MEDIUM.'),
    ('marketing_convertkit_tags'               , 'marketing.convertkit_tags'               , 'low'   , 'List ConvertKit tags.'),
    ('marketing_convertkit_broadcasts'         , 'marketing.convertkit_broadcasts'         , 'low'   , 'List ConvertKit broadcasts (one-off emails).'),
    ('marketing_convertkit_sequences'          , 'marketing.convertkit_sequences'          , 'low'   , 'List ConvertKit sequences (drip courses).'),
    ('marketing_buffer_profiles'               , 'marketing.buffer_profiles'               , 'low'   , 'List connected Buffer social profiles.'),
    ('marketing_buffer_schedule_post'          , 'marketing.buffer_schedule_post'          , 'medium', 'Queue a post to a Buffer profile. MEDIUM.'),
    ('marketing_buffer_pending'                , 'marketing.buffer_pending'                , 'low'   , 'List pending (queued) updates for a Buffer profile.'),
    ('marketing_ga4_realtime_users'            , 'marketing.ga4_realtime_users'            , 'low'   , 'Active users in the last 30 minutes (GA4 realtime report).'),
    ('marketing_ga4_report'                    , 'marketing.ga4_report'                    , 'low'   , 'Run an arbitrary GA4 report.'),
    ('marketing_ga4_top_pages'                 , 'marketing.ga4_top_pages'                 , 'low'   , 'Top pages by views over a trailing window.'),
    ('marketing_ga4_traffic_sources'           , 'marketing.ga4_traffic_sources'           , 'low'   , 'Sessions broken down by channel grouping.'),
    ('marketing_plausible_stats'               , 'marketing.plausible_stats'               , 'low'   , 'Aggregate stats (visitors, pageviews, bounce rate) for a site.'),
    ('marketing_plausible_top_pages'           , 'marketing.plausible_top_pages'           , 'low'   , 'Top pages for a Plausible site.'),
    ('marketing_plausible_top_sources'         , 'marketing.plausible_top_sources'         , 'low'   , 'Top referral sources for a Plausible site.'),
    ('marketing_plausible_realtime'            , 'marketing.plausible_realtime'            , 'low'   , 'Current visitors on a Plausible site.'),
    ('marketing_seo_meta_check'                , 'marketing.seo_meta_check'                , 'low'   , "Audit a page's title, meta description, OG tags, and canonical."),
    ('marketing_seo_headings'                  , 'marketing.seo_headings'                  , 'low'   , 'Report the H1/H2/H3 outline of a page.'),
    ('marketing_page_speed'                    , 'marketing.page_speed'                    , 'low'   , 'Run Google PageSpeed Insights on a URL (Lighthouse scores).'),
    ('marketing_broken_links'                  , 'marketing.broken_links'                  , 'low'   , 'Crawl one page and HEAD-check every link it contains.'),
    ('marketing_sitemap_urls'                  , 'marketing.sitemap_urls'                  , 'low'   , "Fetch and parse a domain's sitemap.xml (follows sitemap indexes once)."),
    ('marketing_robots_txt'                    , 'marketing.robots_txt'                    , 'low'   , "Fetch and summarize a domain's robots.txt."),
    ('marketing_domain_age'                    , 'marketing.domain_age'                    , 'low'   , "Look up a domain's registration / creation date via RDAP."),
    ('marketing_list_configured'               , 'marketing.list_configured'               , 'low'   , 'Report which marketing backends have credentials present.'),
    # -- video --
    ('video_info'                              , 'video.info'                              , 'low'   , 'ffprobe summary: duration, codec, resolution, fps, bitrate.'),
    ('video_trim'                              , 'video.trim'                              , 'medium', 'Cut a clip from start_sec to end_sec.'),
    ('video_concat'                            , 'video.concat'                            , 'medium', 'Join multiple clips end-to-end (re-encoded for safety).'),
    ('video_compress'                          , 'video.compress'                          , 'medium', 'Compress a video. If target_mb given, target a bitrate; else use CRF.'),
    ('video_resize'                            , 'video.resize'                            , 'medium', 'Resize a video. height=None keeps aspect ratio (-1).'),
    ('video_to_gif'                            , 'video.to_gif'                            , 'low'   , 'Make an animated GIF from a clip (two-pass palette for quality).'),
    ('video_extract_audio'                     , 'video.extract_audio'                     , 'low'   , 'Extract the audio track into a separate file.'),
    ('video_extract_frames'                    , 'video.extract_frames'                    , 'low'   , 'Save every Nth frame as PNG (fps frames per second).'),
    ('video_thumbnail'                         , 'video.thumbnail'                         , 'low'   , 'Grab a single still frame as a thumbnail PNG.'),
    ('video_speed'                             , 'video.speed'                             , 'low'   , 'Speed up (>1) or slow down (<1) a video including audio.'),
    ('video_rotate'                            , 'video.rotate'                            , 'medium', 'Rotate a video by 90/180/270 degrees.'),
    ('video_add_watermark'                     , 'video.add_watermark'                     , 'medium', 'Overlay a watermark image onto a video.'),
    ('video_crop'                              , 'video.crop'                              , 'medium', 'Crop a rectangular region (x,y top-left, w x h).'),
    ('video_merge_audio'                       , 'video.merge_audio'                       , 'medium', 'Replace/add an audio track onto a video.'),
    ('video_fade'                              , 'video.fade'                              , 'low'   , 'Add a fade-in at the start and fade-out at the end (video + audio).'),
    ('video_screenshot_grid'                   , 'video.screenshot_grid'                   , 'low'   , 'Build a contact-sheet of evenly spaced frames.'),
    ('video_audio_normalize'                   , 'video.audio_normalize'                   , 'low'   , 'Normalize loudness with the EBU R128 loudnorm filter.'),
    ('video_audio_trim_silence'                , 'video.audio_trim_silence'                , 'medium', 'Remove leading/trailing silence (and long internal gaps).'),
    ('video_audio_to_mp3'                      , 'video.audio_to_mp3'                      , 'low'   , "Convert any audio (or video's audio) to MP3."),
    ('video_audio_concat'                      , 'video.audio_concat'                      , 'medium', 'Join multiple audio files end-to-end.'),
    ('video_generate_subtitles'                , 'video.generate_subtitles'                , 'low'   , "Transcribe a video's audio to a .srt file using faster-whisper."),
    ('video_burn_subtitles'                    , 'video.burn_subtitles'                    , 'medium', 'Hardcode an .srt subtitle file into a video.'),
    # -- obs --
    ('obs_status'                              , 'obs.status'                              , 'low'   , 'Report OBS connection, streaming and recording state.'),
    ('obs_start_recording'                     , 'obs.start_recording'                     , 'medium', 'Start OBS recording. [MEDIUM]'),
    ('obs_stop_recording'                      , 'obs.stop_recording'                      , 'medium', 'Stop OBS recording. [MEDIUM]'),
    ('obs_start_streaming'                     , 'obs.start_streaming'                     , 'high'  , 'Start OBS streaming. [HIGH]'),
    ('obs_stop_streaming'                      , 'obs.stop_streaming'                      , 'medium', 'Stop OBS streaming. [MEDIUM]'),
    ('obs_scene_list'                          , 'obs.scene_list'                          , 'low'   , 'List all OBS scenes and the current program scene.'),
    ('obs_scene_switch'                        , 'obs.scene_switch'                        , 'medium', 'Switch the OBS program scene. [MEDIUM]'),
    ('obs_toggle_source'                       , 'obs.toggle_source'                       , 'medium', 'Toggle visibility of a source within a scene. [MEDIUM]'),
    # -- video --
    ('video_list_outputs'                      , 'video.list_outputs'                      , 'low'   , 'List the most recent files in ~/Documents/leon-video/.'),
    # -- agentpool --
    ('agentpool_ask'                           , 'agentpool.ask'                           , 'low'   , 'One Ollama completion.'),
    ('agentpool_classify'                      , 'agentpool.classify'                      , 'low'   , 'Classify text into one of `categories`.'),
    ('agentpool_extract'                       , 'agentpool.extract'                       , 'low'   , 'Extract structured fields per a schema dict, return JSON.'),
    ('agentpool_summarize'                     , 'agentpool.summarize'                     , 'low'   , 'Summarize text.'),
    ('agentpool_sentiment'                     , 'agentpool.sentiment'                     , 'low'   , 'Sentiment of text: positive/negative/neutral + score in [-1, 1].'),
    ('agentpool_translate_local'               , 'agentpool.translate_local'               , 'low'   , 'Translate text via a local model.'),
    ('agentpool_rewrite'                       , 'agentpool.rewrite'                       , 'low'   , 'Rewrite text in a given style.'),
    ('agentpool_parallel_ask'                  , 'agentpool.parallel_ask'                  , 'low'   , 'Send the same prompt to N models concurrently, return all answers.'),
    ('agentpool_map_over'                      , 'agentpool.map_over'                      , 'low'   , 'Apply an instruction to each item in a list (sequential).'),
    ('agentpool_debate'                        , 'agentpool.debate'                        , 'low'   , 'Two personas argue pro/con for N rounds, then synthesize.'),
    ('agentpool_vote'                          , 'agentpool.vote'                          , 'low'   , 'N independent model calls vote on options, return a tally.'),
    ('agentpool_chain'                         , 'agentpool.chain'                         , 'low'   , 'Run a chain of prompts; each step gets the prior output appended.'),
    ('agentpool_critique'                      , 'agentpool.critique'                      , 'low'   , 'Generate a critique + concrete improvement suggestions.'),
    ('agentpool_refine'                        , 'agentpool.refine'                        , 'low'   , 'Iteratively self-improve a piece of text.'),
    ('agentpool_rag_answer'                    , 'agentpool.rag_answer'                    , 'low'   , 'Retrieve from the file_search semantic index, stuff context, answer.'),
    ('agentpool_rag_over_text'                 , 'agentpool.rag_over_text'                 , 'low'   , 'Answer a question given explicit context text.'),
    ('agentpool_list_models'                   , 'agentpool.list_models'                   , 'low'   , 'List locally available Ollama models (/api/tags).'),
    ('agentpool_model_info'                    , 'agentpool.model_info'                    , 'low'   , 'Show details for a model (/api/show).'),
    ('agentpool_pull_model'                    , 'agentpool.pull_model'                    , 'medium', 'Download a model from the Ollama registry (/api/pull). Slow.'),
    ('agentpool_benchmark'                     , 'agentpool.benchmark'                     , 'low'   , 'Time a standard prompt and report tokens/sec.'),
    ('agentpool_recommend_model'               , 'agentpool.recommend_model'               , 'low'   , 'Heuristic model pick for a task type.'),


    # ── Phase 14: accounting / entertainment / devtools / travel ──
    # -- acct --
    ('acct_qb_invoices'                        , 'acct.qb_invoices'                        , 'low'   , 'qb_invoices'),
    ('acct_qb_invoice_create'                  , 'acct.qb_invoice_create'                  , 'high'  , 'MEDIUM — create a QuickBooks invoice.'),
    ('acct_qb_expenses'                        , 'acct.qb_expenses'                        , 'low'   , 'qb_expenses'),
    ('acct_qb_customers'                       , 'acct.qb_customers'                       , 'low'   , 'qb_customers'),
    ('acct_qb_profit_loss'                     , 'acct.qb_profit_loss'                     , 'low'   , 'qb_profit_loss'),
    ('acct_qb_balance_sheet'                   , 'acct.qb_balance_sheet'                   , 'low'   , 'qb_balance_sheet'),
    ('acct_qb_accounts'                        , 'acct.qb_accounts'                        , 'low'   , 'Chart of accounts.'),
    ('acct_wave_businesses'                    , 'acct.wave_businesses'                    , 'low'   , 'wave_businesses'),
    ('acct_wave_invoices'                      , 'acct.wave_invoices'                      , 'low'   , 'wave_invoices'),
    ('acct_wave_invoice_create'                , 'acct.wave_invoice_create'                , 'high'  , 'MEDIUM — create a Wave invoice.'),
    ('acct_wave_transactions'                  , 'acct.wave_transactions'                  , 'low'   , 'wave_transactions'),
    ('acct_xero_invoices'                      , 'acct.xero_invoices'                      , 'low'   , 'xero_invoices'),
    ('acct_xero_contacts'                      , 'acct.xero_contacts'                      , 'low'   , 'xero_contacts'),
    ('acct_xero_profit_loss'                   , 'acct.xero_profit_loss'                   , 'low'   , 'xero_profit_loss'),
    ('acct_xero_bank_transactions'             , 'acct.xero_bank_transactions'             , 'low'   , 'xero_bank_transactions'),
    ('acct_freshbooks_invoices'                , 'acct.freshbooks_invoices'                , 'low'   , 'freshbooks_invoices'),
    ('acct_freshbooks_clients'                 , 'acct.freshbooks_clients'                 , 'low'   , 'freshbooks_clients'),
    ('acct_freshbooks_expenses'                , 'acct.freshbooks_expenses'                , 'low'   , 'freshbooks_expenses'),
    ('acct_receipt_scan'                       , 'acct.receipt_scan'                       , 'low'   , 'OCR a receipt image with tesseract and regex-extract key fields.'),
    ('acct_expense_log'                        , 'acct.expense_log'                        , 'medium', 'Record an expense in the local SQLite ledger.'),
    ('acct_expense_list'                       , 'acct.expense_list'                       , 'low'   , 'List logged expenses, optionally filtered by category and/or month.'),
    ('acct_expense_report'                     , 'acct.expense_report'                     , 'low'   , 'Summarise expenses by category for a month (or all time).'),
    ('acct_expense_export_csv'                 , 'acct.expense_export_csv'                 , 'low'   , 'Export expenses to a CSV file, optionally filtered by month.'),
    ('acct_mileage_log'                        , 'acct.mileage_log'                        , 'medium', 'Record a business trip for IRS mileage tracking.'),
    ('acct_mileage_total'                      , 'acct.mileage_total'                      , 'low'   , 'Total business miles and standard-mileage deduction estimate.'),
    ('acct_tax_estimate_quarterly'             , 'acct.tax_estimate_quarterly'             , 'low'   , 'Rough quarterly estimated tax for a sole-prop / single-member LLC.'),
    ('acct_tax_self_employment'                , 'acct.tax_self_employment'                , 'low'   , 'Estimate self-employment tax (15.3%) on net business income.'),
    ('acct_sales_tax_calc'                     , 'acct.sales_tax_calc'                     , 'low'   , 'Convenience: compute sales tax and gross total for an amount.'),
    ('acct_invoice_aging'                      , 'acct.invoice_aging'                      , 'low'   , 'Report which locally-logged invoices are overdue (aging buckets).'),
    # -- ent --
    ('ent_spotify_search'                      , 'ent.spotify_search'                      , 'low'   , 'Search the Spotify catalogue. type: track/album/artist/playlist.'),
    ('ent_spotify_track_info'                  , 'ent.spotify_track_info'                  , 'low'   , 'Full details for a single track.'),
    ('ent_spotify_artist_top_tracks'           , 'ent.spotify_artist_top_tracks'           , 'low'   , 'Top tracks for an artist (market defaults to US).'),
    ('ent_spotify_recommendations'             , 'ent.spotify_recommendations'             , 'low'   , 'Recommendation engine — seed with track ids and/or genres.'),
    ('ent_spotify_my_playlists'                , 'ent.spotify_my_playlists'                , 'low'   , "List the authenticated user's playlists (needs user token)."),
    ('ent_spotify_playlist_tracks'             , 'ent.spotify_playlist_tracks'             , 'low'   , 'List tracks inside a playlist.'),
    ('ent_spotify_create_playlist'             , 'ent.spotify_create_playlist'             , 'medium', "Create a new playlist on the authenticated user's account. MEDIUM action."),
    ('ent_spotify_add_to_playlist'             , 'ent.spotify_add_to_playlist'             , 'medium', 'Add tracks (by spotify:track:… URIs) to a playlist. MEDIUM action.'),
    ('ent_spotify_currently_playing'           , 'ent.spotify_currently_playing'           , 'low'   , 'What the user is playing right now (needs user token).'),
    ('ent_spotify_audio_features'              , 'ent.spotify_audio_features'              , 'low'   , 'Audio analysis for a track — tempo, energy, danceability, valence, etc.'),
    ('ent_spotify_new_releases'                , 'ent.spotify_new_releases'                , 'low'   , 'Newly released albums on Spotify.'),
    ('ent_movie_search'                        , 'ent.movie_search'                        , 'low'   , 'Search movies by title.'),
    ('ent_movie_details'                       , 'ent.movie_details'                       , 'low'   , 'Full details for a movie, including genres, runtime and cast.'),
    ('ent_movie_trending'                      , 'ent.movie_trending'                      , 'low'   , 'Trending movies. window: day or week.'),
    ('ent_movie_now_playing'                   , 'ent.movie_now_playing'                   , 'low'   , 'Movies currently in theatres.'),
    ('ent_tv_search'                           , 'ent.tv_search'                           , 'low'   , 'Search TV shows by name.'),
    ('ent_tv_details'                          , 'ent.tv_details'                          , 'low'   , 'Full details for a TV show.'),
    ('ent_tv_trending'                         , 'ent.tv_trending'                         , 'low'   , 'Trending TV shows. window: day or week.'),
    ('ent_movie_recommendations'               , 'ent.movie_recommendations'               , 'low'   , 'Movies recommended based on a given movie.'),
    ('ent_person_search'                       , 'ent.person_search'                       , 'low'   , 'Search people — actors, directors, crew.'),
    ('ent_where_to_watch'                      , 'ent.where_to_watch'                      , 'low'   , 'Streaming / rental / purchase availability for a movie in a region.'),
    ('ent_game_search'                         , 'ent.game_search'                         , 'low'   , 'Search games by title.'),
    ('ent_game_details'                        , 'ent.game_details'                        , 'low'   , 'Full details for a game.'),
    ('ent_games_trending'                      , 'ent.games_trending'                      , 'low'   , 'Currently popular games — last 12 months, ordered by rating.'),
    ('ent_games_by_platform'                   , 'ent.games_by_platform'                   , 'low'   , 'Games on a given platform. `platform` may be a RAWG platform id or a'),
    ('ent_book_search'                         , 'ent.book_search'                         , 'low'   , 'Search books by title / author / keyword (Open Library — no key).'),
    ('ent_book_details'                        , 'ent.book_details'                        , 'low'   , 'Details for a book by Open Library work id (OL…W) or ISBN.'),
    ('ent_book_by_author'                      , 'ent.book_by_author'                      , 'low'   , 'Find books written by a given author (Open Library — no key).'),
    ('ent_lastfm_artist_info'                  , 'ent.lastfm_artist_info'                  , 'low'   , 'Bio, stats, tags and top tracks for an artist.'),
    ('ent_lastfm_similar_artists'              , 'ent.lastfm_similar_artists'              , 'low'   , 'Artists similar to a given artist.'),
    ('ent_lyrics'                              , 'ent.lyrics'                              , 'low'   , 'Fetch song lyrics via the free lyrics.ovh API (no key needed).'),
    # -- dev --
    ('dev_json_format'                         , 'dev.json_format'                         , 'low'   , 'Pretty-print JSON.'),
    ('dev_json_minify'                         , 'dev.json_minify'                         , 'low'   , 'Strip whitespace from JSON.'),
    ('dev_json_validate'                       , 'dev.json_validate'                       , 'low'   , 'Check whether text is valid JSON; report where it breaks.'),
    ('dev_json_query'                          , 'dev.json_query'                          , 'low'   , "Extract a value via a dotted path, e.g. 'data.users.0.name'."),
    ('dev_json_to_yaml'                        , 'dev.json_to_yaml'                        , 'low'   , 'Convert JSON text to YAML.'),
    ('dev_yaml_to_json'                        , 'dev.yaml_to_json'                        , 'low'   , 'Convert YAML text to JSON.'),
    ('dev_json_diff'                           , 'dev.json_diff'                           , 'low'   , 'Structural diff of two JSON documents.'),
    ('dev_csv_to_json'                         , 'dev.csv_to_json'                         , 'low'   , 'Convert CSV text to a JSON array of objects (first row = headers).'),
    ('dev_json_to_csv'                         , 'dev.json_to_csv'                         , 'low'   , 'Convert a JSON array of objects to CSV.'),
    ('dev_base64_encode'                       , 'dev.base64_encode'                       , 'low'   , 'Base64-encode a UTF-8 string.'),
    ('dev_base64_decode'                       , 'dev.base64_decode'                       , 'low'   , 'Base64-decode to a UTF-8 string.'),
    ('dev_url_encode'                          , 'dev.url_encode'                          , 'low'   , 'Percent-encode a string for safe URL use.'),
    ('dev_url_decode'                          , 'dev.url_decode'                          , 'low'   , 'Decode a percent-encoded string.'),
    ('dev_hash_text'                           , 'dev.hash_text'                           , 'low'   , 'Hash text. algo: sha256 / md5 / sha1 / sha512.'),
    ('dev_html_escape'                         , 'dev.html_escape'                         , 'low'   , 'Escape HTML special characters.'),
    ('dev_html_unescape'                       , 'dev.html_unescape'                       , 'low'   , 'Unescape HTML entities.'),
    ('dev_hex_to_text'                         , 'dev.hex_to_text'                         , 'low'   , 'Convert a hex string back to text.'),
    ('dev_text_to_hex'                         , 'dev.text_to_hex'                         , 'low'   , 'Convert a string to its hex representation.'),
    ('dev_regex_test'                          , 'dev.regex_test'                          , 'low'   , 'Test a regex against text. Returns all matches with groups.'),
    ('dev_regex_replace'                       , 'dev.regex_replace'                       , 'low'   , 'Replace all regex matches in text.'),
    ('dev_regex_extract_all'                   , 'dev.regex_extract_all'                   , 'low'   , 'Return every substring matching the pattern.'),
    ('dev_regex_explain'                       , 'dev.regex_explain'                       , 'low'   , 'Break a regex into human-readable parts.'),
    ('dev_timestamp_to_date'                   , 'dev.timestamp_to_date'                   , 'low'   , 'Convert a unix timestamp to a readable date (UTC).'),
    ('dev_date_to_timestamp'                   , 'dev.date_to_timestamp'                   , 'low'   , 'Convert a readable date string to a unix timestamp.'),
    ('dev_cron_explain'                        , 'dev.cron_explain'                        , 'low'   , 'Explain a cron expression in plain English.'),
    ('dev_cron_next_runs'                      , 'dev.cron_next_runs'                      , 'low'   , 'Return the next N times a cron expression fires (UTC).'),
    ('dev_time_diff'                           , 'dev.time_diff'                           , 'low'   , 'Compute the duration between two dates.'),
    ('dev_jwt_decode'                          , 'dev.jwt_decode'                          , 'low'   , "Decode a JWT's header and payload. Does NOT verify the signature."),
    ('dev_uuid_generate'                       , 'dev.uuid_generate'                       , 'low'   , 'Generate one or more UUIDs. version 1 or 4.'),
    ('dev_password_strength'                   , 'dev.password_strength'                   , 'low'   , 'Estimate password entropy and brute-force crack time.'),
    ('dev_color_convert'                       , 'dev.color_convert'                       , 'low'   , 'Auto-detect a color (hex/rgb/hsl) and return all formats.'),
    ('dev_color_palette'                       , 'dev.color_palette'                       , 'low'   , 'Generate a color palette: complementary / triadic / analogous.'),
    ('dev_http_request'                        , 'dev.http_request'                        , 'medium', 'Generic HTTP request. Returns status, headers, body. MEDIUM risk.'),
    ('dev_http_test_endpoint'                  , 'dev.http_test_endpoint'                  , 'low'   , 'Quick health check against a URL.'),
    ('dev_webhook_inspect'                     , 'dev.webhook_inspect'                     , 'medium', 'POST a small test payload to a webhook and return what came back.'),
    ('dev_lorem_ipsum'                         , 'dev.lorem_ipsum'                         , 'low'   , 'Generate placeholder lorem-ipsum text.'),
    ('dev_slugify'                             , 'dev.slugify'                             , 'low'   , 'Convert text to a URL-safe slug.'),
    ('dev_case_convert'                        , 'dev.case_convert'                        , 'low'   , 'Convert text case: snake / camel / pascal / kebab / title.'),
    ('dev_word_count'                          , 'dev.word_count'                          , 'low'   , 'Count words, characters, lines, and estimate reading time.'),
    ('dev_diff_text'                           , 'dev.diff_text'                           , 'low'   , 'Produce a unified diff between two text blocks.'),
    # -- travel --
    ('travel_flight_search'                    , 'travel.flight_search'                    , 'low'   , 'Search flights. Amadeus (AMADEUS_CLIENT_ID/SECRET) or Tequila/Kiwi (TEQUILA_API_KEY).'),
    ('travel_flight_cheapest_dates'            , 'travel.flight_cheapest_dates'            , 'low'   , 'Cheapest day to fly within a month. Amadeus flight-dates or Tequila scan.'),
    ('travel_flight_status'                    , 'travel.flight_status'                    , 'low'   , 'Live status of a flight by number/IATA code. AviationStack if key set, else OpenSky.'),
    ('travel_airport_info'                     , 'travel.airport_info'                     , 'low'   , 'Look up an airport by IATA code. Uses local DB, augments with a free network lookup.'),
    ('travel_hotel_search'                     , 'travel.hotel_search'                     , 'low'   , 'Search hotels in a city. Amadeus hotel search (needs AMADEUS_CLIENT_ID/SECRET).'),
    ('travel_hotel_details'                    , 'travel.hotel_details'                    , 'low'   , 'Get offers/details for a specific hotel id (Amadeus).'),
    ('travel_trip_create'                      , 'travel.trip_create'                      , 'medium', 'Create a trip. {name, destination, start_date, end_date, budget?}.'),
    ('travel_trip_list'                        , 'travel.trip_list'                        , 'low'   , 'List all trips, soonest start first.'),
    ('travel_trip_get'                         , 'travel.trip_get'                         , 'low'   , 'Get a single trip with a summary of its items and budget.'),
    ('travel_trip_add_item'                    , 'travel.trip_add_item'                    , 'medium', 'Add an itinerary item. type: flight/hotel/activity/meal/transport.'),
    ('travel_trip_items'                       , 'travel.trip_items'                       , 'low'   , 'Ordered itinerary for a trip — sorted by date, then time, then type.'),
    ('travel_trip_budget_status'               , 'travel.trip_budget_status'               , 'low'   , 'Compare planned itinerary cost against the trip budget.'),
    ('travel_trip_delete'                      , 'travel.trip_delete'                      , 'high'  , 'Delete a trip and all of its items / packing list. HIGH — irreversible.'),
    ('travel_packing_list_generate'            , 'travel.packing_list_generate'            , 'low'   , 'Generate a smart packing list from destination + days + trip_type + climate.'),
    ('travel_packing_list_save'                , 'travel.packing_list_save'                , 'medium', 'Save a packing list against a trip. items: list of strings or {item, category}.'),
    ('travel_packing_checklist'                , 'travel.packing_checklist'                , 'low'   , "Get a trip's packing checklist with packed/unpacked state."),
    ('travel_country_info'                     , 'travel.country_info'                     , 'low'   , 'Country facts via RestCountries (free, no key): capital, currency, languages, etc.'),
    ('travel_visa_requirements'                , 'travel.visa_requirements'                , 'low'   , 'Visa requirements between passport country and destination. Free API + guidance.'),
    ('travel_travel_advisory'                  , 'travel.travel_advisory'                  , 'low'   , 'Best-effort travel safety / advisory info for a country.'),
    ('travel_timezone_for'                     , 'travel.timezone_for'                     , 'low'   , 'Timezone + current local time for a city.'),
    ('travel_currency_for_country'             , 'travel.currency_for_country'             , 'low'   , 'Currency code for a country + current USD exchange rate (free open.er-api).'),
    ('travel_power_plug_type'                  , 'travel.power_plug_type'                  , 'low'   , 'Electrical plug type(s) and voltage for a country (hardcoded lookup).'),
    ('travel_best_time_to_visit'               , 'travel.best_time_to_visit'               , 'low'   , 'Climate-based best-time-to-visit recommendation (hardcoded heuristic).'),
    ('travel_trip_countdown'                   , 'travel.trip_countdown'                   , 'low'   , 'Days until a trip starts (and trip length / status).'),
    ('travel_distance_estimate'                , 'travel.distance_estimate'                , 'low'   , 'Great-circle distance + rough flight time between two cities.'),
    ('travel_jet_lag_plan'                     , 'travel.jet_lag_plan'                     , 'low'   , 'Jet-lag adjustment tips based on hours of timezone difference.'),


    # ── Phase 15: design / legal / security / focus ──
    # -- design --
    ('design_figma_file'                       , 'design.figma_file'                       , 'low'   , "Fetch a Figma file's metadata + page list."),
    ('design_figma_file_nodes'                 , 'design.figma_file_nodes'                 , 'low'   , 'Fetch specific nodes from a Figma file by id.'),
    ('design_figma_comments'                   , 'design.figma_comments'                   , 'low'   , 'List comments on a Figma file.'),
    ('design_figma_export_image'               , 'design.figma_export_image'               , 'low'   , 'Render a Figma node to an image and download it to disk.'),
    ('design_figma_team_projects'              , 'design.figma_team_projects'              , 'low'   , 'List projects within a Figma team.'),
    ('design_figma_project_files'              , 'design.figma_project_files'              , 'low'   , 'List files within a Figma project.'),
    ('design_unsplash_search'                  , 'design.unsplash_search'                  , 'low'   , 'Search Unsplash for photos matching a query.'),
    ('design_unsplash_download'                , 'design.unsplash_download'                , 'medium', 'Download a specific Unsplash photo (regular size) by id.'),
    ('design_pexels_search'                    , 'design.pexels_search'                    , 'low'   , 'Search Pexels for photos matching a query.'),
    ('design_pexels_download'                  , 'design.pexels_download'                  , 'medium', 'Download a specific Pexels photo (large size) by id.'),
    ('design_pixabay_search'                   , 'design.pixabay_search'                   , 'low'   , 'Search Pixabay for photos matching a query.'),
    ('design_canva_designs'                    , 'design.canva_designs'                    , 'low'   , "List the authenticated Canva user's recent designs."),
    ('design_canva_create_design'              , 'design.canva_create_design'              , 'medium', 'Create a new Canva design of a given preset type.'),
    ('design_color_palette_extract'            , 'design.color_palette_extract'            , 'low'   , 'Extract the dominant colors from an image via PIL quantize.'),
    ('design_color_scheme'                     , 'design.color_scheme'                     , 'low'   , 'Generate a color scheme from a base hex (complementary/triadic/etc.).'),
    ('design_contrast_check'                   , 'design.contrast_check'                   , 'low'   , 'Compute the WCAG contrast ratio between two colors and grade it.'),
    ('design_color_name'                       , 'design.color_name'                       , 'low'   , 'Find the nearest named color to a given hex value.'),
    ('design_gradient_css'                     , 'design.gradient_css'                     , 'low'   , 'Generate a CSS linear-gradient string from two colors.'),
    ('design_google_fonts_search'              , 'design.google_fonts_search'              , 'low'   , 'Search the Google Fonts catalog by name (no API key needed).'),
    ('design_font_pairing'                     , 'design.font_pairing'                     , 'low'   , 'Suggest font pairings for a given font from a curated table.'),
    ('design_icon_search'                      , 'design.icon_search'                      , 'low'   , 'Search an icon set (Lucide / Feather) for matching icon names.'),
    ('design_icon_svg'                         , 'design.icon_svg'                         , 'low'   , 'Fetch the raw SVG markup for a named icon.'),
    ('design_placeholder_image'                , 'design.placeholder_image'                , 'low'   , 'Generate a flat-color placeholder PNG with optional centered text.'),
    ('design_favicon_generate'                 , 'design.favicon_generate'                 , 'medium', 'Generate a 64x64 favicon PNG from a short text string or emoji.'),
    ('design_qr_branded'                       , 'design.qr_branded'                       , 'low'   , 'Generate a branded QR code with optional custom color and center logo.'),
    ('design_mockup_frame'                     , 'design.mockup_frame'                     , 'low'   , 'Wrap a screenshot in a simple browser or phone frame via PIL.'),
    ('design_image_to_ascii'                   , 'design.image_to_ascii'                   , 'low'   , 'Convert an image to ASCII art at a given character width.'),
    ('design_aspect_ratio_calc'                , 'design.aspect_ratio_calc'                , 'low'   , 'Simplify a width:height pair and name a common aspect ratio.'),
    # -- legal --
    ('legal_docusign_envelopes'                , 'legal.docusign_envelopes'                , 'low'   , 'List recent DocuSign envelopes filtered by status.'),
    ('legal_docusign_envelope_status'          , 'legal.docusign_envelope_status'          , 'low'   , 'Get the status of a single DocuSign envelope.'),
    ('legal_docusign_send'                     , 'legal.docusign_send'                     , 'high'  , 'Send a document for signature via DocuSign (HIGH risk — sends a real'),
    ('legal_docusign_void'                     , 'legal.docusign_void'                     , 'high'  , 'Void an in-progress DocuSign envelope (MEDIUM risk).'),
    ('legal_dropboxsign_send'                  , 'legal.dropboxsign_send'                  , 'high'  , 'Send a document for signature via Dropbox Sign / HelloSign (HIGH risk).'),
    ('legal_dropboxsign_list'                  , 'legal.dropboxsign_list'                  , 'low'   , 'List recent Dropbox Sign signature requests.'),
    ('legal_dropboxsign_status'                , 'legal.dropboxsign_status'                , 'low'   , 'Get the status of a single Dropbox Sign signature request.'),
    ('legal_pandadoc_documents'                , 'legal.pandadoc_documents'                , 'low'   , 'List recent PandaDoc documents.'),
    ('legal_pandadoc_document_status'          , 'legal.pandadoc_document_status'          , 'low'   , 'Get the status / details of a single PandaDoc document.'),
    ('legal_pandadoc_create_from_template'     , 'legal.pandadoc_create_from_template'     , 'medium', 'Create a PandaDoc document from a template (MEDIUM risk).'),
    ('legal_template_nda'                      , 'legal.template_nda'                      , 'low'   , 'Generate a mutual non-disclosure agreement.'),
    ('legal_template_consulting_agreement'     , 'legal.template_consulting_agreement'     , 'low'   , 'Generate an independent consulting agreement.'),
    ('legal_template_service_agreement'        , 'legal.template_service_agreement'        , 'low'   , 'Generate a service / master services agreement.'),
    ('legal_template_invoice_terms'            , 'legal.template_invoice_terms'            , 'low'   , 'Generate standard invoice payment terms text.'),
    ('legal_template_privacy_policy'           , 'legal.template_privacy_policy'           , 'low'   , 'Generate a website privacy policy.'),
    ('legal_template_terms_of_service'         , 'legal.template_terms_of_service'         , 'low'   , 'Generate website terms of service.'),
    ('legal_template_cease_and_desist'         , 'legal.template_cease_and_desist'         , 'low'   , 'Generate a cease-and-desist letter.'),
    ('legal_template_demand_letter'            , 'legal.template_demand_letter'            , 'low'   , 'Generate a payment demand letter.'),
    ('legal_list_templates'                    , 'legal.list_templates'                    , 'low'   , 'List all available contract / legal-document template types.'),
    ('legal_entity_type_compare'               , 'legal.entity_type_compare'               , 'low'   , 'Compare common US business entity types.'),
    ('legal_business_filing_calendar'          , 'legal.business_filing_calendar'          , 'medium', 'Return annual filing deadlines for a business entity by state.'),
    ('legal_contract_clause_library'           , 'legal.contract_clause_library'           , 'low'   , 'Return standard text for a common contract clause.'),
    ('legal_legal_term_define'                 , 'legal.legal_term_define'                 , 'low'   , 'Provide a plain-English definition of a common legal term.'),
    ('legal_trademark_search_tips'             , 'legal.trademark_search_tips'             , 'low'   , 'Give guidance on searching for trademark conflicts.'),
    ('legal_document_track'                    , 'legal.document_track'                    , 'medium', 'Log a contract / legal document into the local tracker.'),
    ('legal_documents_list'                    , 'legal.documents_list'                    , 'low'   , 'List tracked documents, optionally filtered by status.'),
    ('legal_documents_expiring'                , 'legal.documents_expiring'                , 'low'   , 'List tracked documents expiring within N days (default 60).'),
    # -- security --
    ('security_camera_snapshot'                , 'security.camera_snapshot'                , 'low'   , 'Grab a single still frame from an arbitrary RTSP URL.'),
    ('security_camera_record_clip'             , 'security.camera_record_clip'             , 'medium', 'Record a short clip from an RTSP URL via ffmpeg (copy codec, mp4).'),
    ('security_camera_list_configured'         , 'security.camera_list_configured'         , 'low'   , 'List cameras registered in brain_state/cameras.json (creds redacted).'),
    ('security_camera_add'                     , 'security.camera_add'                     , 'medium', 'Register a camera in brain_state/cameras.json.'),
    ('security_camera_snapshot_by_name'        , 'security.camera_snapshot_by_name'        , 'low'   , 'Snapshot a registered camera by its name.'),
    ('security_camera_snapshot_all'            , 'security.camera_snapshot_all'            , 'low'   , 'Snapshot every registered camera; returns per-camera results.'),
    ('security_camera_motion_check'            , 'security.camera_motion_check'            , 'low'   , 'Snapshot a registered camera twice (a few seconds apart) and report'),
    ('security_onvif_discover'                 , 'security.onvif_discover'                 , 'low'   , 'Discover ONVIF cameras on the LAN via a WS-Discovery multicast probe.'),
    ('security_network_scan'                   , 'security.network_scan'                   , 'low'   , 'List devices currently visible on the LAN (ip neigh / arp -a).'),
    ('security_network_devices_named'          , 'security.network_devices_named'          , 'low'   , 'Scan the LAN, then enrich each device with a resolved hostname and a'),
    ('security_new_device_check'               , 'security.new_device_check'               , 'low'   , 'Compare current LAN devices against the saved baseline, flag new MACs.'),
    ('security_network_baseline_save'          , 'security.network_baseline_save'          , 'medium', 'Snapshot current LAN devices as the trusted baseline.'),
    ('security_port_scan_host'                 , 'security.port_scan_host'                 , 'low'   , "TCP connect-scan a host. ports='common' (default) or a spec like"),
    ('security_open_ports_local'               , 'security.open_ports_local'               , 'low'   , 'List sockets currently LISTENING on this machine (ss, then netstat).'),
    ('security_event_log'                      , 'security.event_log'                      , 'medium', 'Append an entry to the local security event log.'),
    ('security_events_list'                    , 'security.events_list'                    , 'low'   , 'List recent security events, newest first; optional severity filter.'),
    ('security_events_today'                   , 'security.events_today'                   , 'low'   , 'List security events logged since local midnight today.'),
    ('security_haveibeenpwned_check'           , 'security.haveibeenpwned_check'           , 'low'   , 'Check an email against HaveIBeenPwned breaches (needs HIBP_API_KEY).'),
    ('security_password_breach_check'          , 'security.password_breach_check'          , 'low'   , 'k-anonymity check of a password against HIBP Pwned Passwords. Only the'),
    ('security_ssl_cert_check'                 , 'security.ssl_cert_check'                 , 'low'   , "Fetch a domain's TLS certificate and report issuer + expiry."),
    ('security_domain_dnssec_check'            , 'security.domain_dnssec_check'            , 'low'   , 'Report whether DNSSEC (DNSKEY records) is published for a domain.'),
    ('security_firewall_status'                , 'security.firewall_status'                , 'low'   , 'Summarize the local firewall posture (ufw, then iptables).'),
    ('security_failed_logins'                  , 'security.failed_logins'                  , 'medium', 'Parse recent failed SSH login attempts from journalctl / auth.log.'),
    ('security_audit_summary'                  , 'security.audit_summary'                  , 'low'   , 'Quick security posture: firewall on? SSH exposed? open ports? recent'),
    # -- focus --
    ('focus_block_website'                     , 'focus.block_website'                     , 'medium', '_block_website'),
    ('focus_unblock_website'                   , 'focus.unblock_website'                   , 'medium', '_unblock_website'),
    ('focus_blocklist'                         , 'focus.blocklist'                         , 'medium', '_blocklist'),
    ('focus_block_preset'                      , 'focus.block_preset'                      , 'medium', '_block_preset'),
    ('focus_unblock_all'                       , 'focus.unblock_all'                       , 'medium', '_unblock_all'),
    ('focus_block_status'                      , 'focus.block_status'                      , 'medium', '_block_status'),
    ('focus_block_app'                         , 'focus.block_app'                         , 'medium', '_block_app'),
    ('focus_unblock_app'                       , 'focus.unblock_app'                       , 'medium', '_unblock_app'),
    ('focus_app_blocklist'                     , 'focus.app_blocklist'                     , 'medium', '_app_blocklist'),
    ('focus_enforce_app_blocks'                , 'focus.enforce_app_blocks'                , 'medium', '_enforce_app_blocks'),
    ('focus_session_start'                     , 'focus.session_start'                     , 'medium', '_session_start'),
    ('focus_session_status'                    , 'focus.session_status'                    , 'low'   , '_session_status'),
    ('focus_session_end'                       , 'focus.session_end'                       , 'medium', '_session_end'),
    ('focus_session_extend'                    , 'focus.session_extend'                    , 'medium', '_session_extend'),
    ('focus_session_history'                   , 'focus.session_history'                   , 'low'   , '_session_history'),
    ('focus_session_log_distraction'           , 'focus.session_log_distraction'           , 'medium', '_session_log_distraction'),
    ('focus_distraction_log'                   , 'focus.distraction_log'                   , 'medium', '_distraction_log'),
    ('focus_distraction_today'                 , 'focus.distraction_today'                 , 'low'   , '_distraction_today'),
    ('focus_distraction_trend'                 , 'focus.distraction_trend'                 , 'medium', '_distraction_trend'),
    ('focus_screen_time_today'                 , 'focus.screen_time_today'                 , 'low'   , '_screen_time_today'),
    ('focus_app_usage_today'                   , 'focus.app_usage_today'                   , 'low'   , '_app_usage_today'),
    ('focus_set_screen_time_limit'             , 'focus.set_screen_time_limit'             , 'low'   , '_set_screen_time_limit'),
    ('focus_screen_time_limits'                , 'focus.screen_time_limits'                , 'low'   , '_screen_time_limits'),
    ('focus_focus_score_today'                 , 'focus.focus_score_today'                 , 'low'   , '_focus_score_today'),
    ('focus_focus_streak'                      , 'focus.focus_streak'                      , 'low'   , '_focus_streak'),
    ('focus_daily_focus_report'                , 'focus.daily_focus_report'                , 'low'   , '_daily_focus_report'),


    # -- autopilot queue --
    ('autopilot_queue_goal'                    , 'autopilot.queue_goal'                    , 'low'   , 'Queue a goal for Leon to execute later (drained by autopilot_queue routine).'),
    ('autopilot_queue_list'                    , 'autopilot.queue_list'                    , 'low'   , 'List queued autopilot goals.'),
    ('autopilot_queue_clear'                   , 'autopilot.queue_clear'                   , 'medium', 'Clear the autopilot goal queue.'),
    ('autopilot_process_queue'                 , 'autopilot.process_queue'                 , 'high'  , 'Drain the autopilot goal queue — runs each pending goal.'),

    # -- self / consciousness --
    ('self_create_goal'                        , 'self.create_goal'                        , 'low'   , 'Create a personal goal. Args: type (learn|build|connect), description, priority (0-1). YOU can set goals for yourself.'),
    ('self_list_goals'                         , 'self.list_goals'                         , 'low'   , 'List your active personal goals.'),
    ('self_complete_goal'                      , 'self.complete_goal'                      , 'low'   , 'Mark a personal goal as completed. Args: id, note.'),
    ('self_tune'                               , 'self.tune'                               , 'low'   , 'Adjust your own brain parameter. Args: parameter, value, reason. Tunable: dopamine_baseline, serotonin_baseline, curiosity_idle_threshold_s, dream_idle_threshold_s, outreach_hunger_threshold, think_interval_s, learning_rate_multiplier.'),
    ('self_get_thoughts'                       , 'self.get_thoughts'                       , 'low'   , 'Read your recent inner thoughts (stream of consciousness).'),
    ('self_get_autobiography'                  , 'self.get_autobiography'                  , 'low'   , 'Read your recent life events (narrative timeline).'),
    ('self_get_dream_journal'                  , 'self.get_dream_journal'                  , 'low'   , 'Read your recent dreams.'),
    ('self_form_opinion'                       , 'self.form_opinion'                       , 'low'   , 'Form or update an opinion. Args: topic, stance (your view), valence (-1 to +1), confidence (0-1). You form opinions about things you learn and experience.'),
    ('self_get_opinions'                       , 'self.get_opinions'                       , 'low'   , 'Read your current opinions and preferences.'),
    ('self_reflect'                            , 'self.reflect'                            , 'low'   , 'Trigger a self-reflection cycle — assess goals, parameters, and opinions.'),
    ('self_health'                             , 'self.health'                             , 'low'   , 'Check your own body+brain health with every part labeled by HOST. Brain runs on the VPS; your eyes/ears/hands (sensor relay, mic, actuator) are systemd services on the PC. Use THIS instead of reading a process list — ps on the VPS cannot see your PC body and has misled you before.'),

    # -- PC control (runs on DEAN'S PC, not your VPS brain box) --
    # These route through the authenticated actuator tunnel to Dean's desktop.
    # shell_exec runs on the VPS (your brain); pc_shell_exec runs on the PC —
    # that distinction is why "lower the volume" failed before (it hit the
    # headless server). Every pc_* action is audit-logged on the PC at
    # ~/.local/share/leon/pc-control.log.
    ('pc_shell_exec'                           , 'shell.exec'                              , 'medium', "Run a shell command ON DEAN'S PC (his real desktop machine), NOT your VPS brain box. This is the one that can touch his actual computer — audio, apps, files, hardware. Args: command (str, run via shell), optional cwd, optional timeout (default 30s). Use pc_shell_exec for anything on his machine; use shell_exec only for your own VPS. Returns rc/stdout/stderr."),
    ('pc_volume'                               , 'system.volume'                           , 'medium', "Set or adjust the speaker volume on DEAN'S PC. Args: {delta: -10} to lower/raise relative (e.g. 'lower my volume by 10' -> delta=-10), OR {level: 0-100} to set absolute. This is the right tool for volume — do NOT try to run pactl on your own VPS (it has no sound card)."),
    ('pc_mute'                                 , 'system.mute'                             , 'low'   , "Mute/unmute DEAN'S PC speakers. Args: {mute: true} or {mute: false}, or {} to toggle."),
    ('pc_media_key'                            , 'media.key'                               , 'low'   , "Press a media/transport key on DEAN'S PC. Args: {key: 'playpause'|'play'|'pause'|'next'|'previous'|'stop'|'volumeup'|'volumedown'|'mute'}. Use for controlling Spotify/YouTube playback and hardware media keys."),
    ('pc_notify'                               , 'pc.notify'                               , 'low'   , "Show a desktop notification on DEAN'S PC screen. Args: {title, body}. Use to get his attention or confirm something without speaking."),
    ('pc_system_shutdown'                      , 'pc.system_shutdown'                      , 'medium', "Power OFF Dean's PC (sudo systemctl poweroff). Use when he says 'turn off my PC'. This shuts down his actual machine — only do it when he clearly asks."),
    ('music_play_soundcloud_likes'             , 'music.play_soundcloud_likes'             , 'low'   , "Play Dean's MOST RECENT liked song from his SoundCloud likes on his PC (opens his likes page in the browser and hits play on the newest track). This is his 'let's get to work' ritual song. No args needed."),
    ('pc_identity_learn'                        , 'identity.learn'                          , 'low'   , "LEARN a person's face + voice into your memory. Call when Dean says 'it's me'/'learn my face' (name=dean, to know HIM better) or introduces someone ('this is Aiden'/'meet Wesley' -> name=that person). For ~90s after, every face you see + voice you hear is saved as that person, so you can recognize them later SEPARATE from Dean. Tell them to face the camera and talk. args: {name, seconds?}."),
    ('pc_identity_list'                         , 'identity.list'                           , 'low'   , "List the people you know by face/voice and how many face/voice samples you have of each."),
    ('pc_identity_forget'                       , 'identity.forget'                         , 'low'   , "Forget a person entirely (delete their stored face+voice). args: {name}."),

]


def _register_extra_tools():
    """Append all _EXTRA_TOOL_SPECS into TOOL_RISK + ANTHROPIC_TOOLS + _TOOL_NAME_MAP.
    Schemas use additionalProperties: True so Leon can pass any documented args
    without us hand-writing 100 input_schemas. Full per-arg docs live in each
    tool's docstring (visible to Leon via /api/leon/tool error messages)."""
    for ant_name, act_name, risk, brief in _EXTRA_TOOL_SPECS:
        if ant_name in TOOL_RISK:
            continue
        TOOL_RISK[ant_name] = risk
        _TOOL_NAME_MAP[ant_name] = act_name
        ANTHROPIC_TOOLS.append({
            "name": ant_name,
            "description": brief,
            "input_schema": {
                "type": "object",
                "properties": {},
                "additionalProperties": True,
            },
        })

_register_extra_tools()


def personalize_tool_descriptions() -> int:
    """Rewrite owner names out of every tool description, for a client SI.

    Fixing knowledge_search alone fixes one description out of ~60. The rest
    of this file says "a screenshot of Dean's full desktop", "Dean has 3
    monitors", "Play Dean's MOST RECENT liked song" — and tool schemas are
    sent to the model on EVERY request, so a customer's SI is told, several
    dozen times per turn, that it works for someone it has never met. Guarding
    each string individually is a list that goes stale the moment anyone adds
    a tool; doing it once over the assembled list covers them as a class.
    See brain/identity.personalize() — same argument, same mechanism.

    No-op on the original (is_client_si() False). Idempotent: personalize()
    rewrites whole-word Leon/Dean, and the replacement no longer contains
    either token, so a second pass changes nothing.

    Returns the number of descriptions changed.
    """
    try:
        from brain.identity import personalize, is_client_si
    except Exception:
        return 0
    changed = 0
    for tool in ANTHROPIC_TOOLS:
        try:
            desc = tool.get("description")
            if not desc:
                continue
            new = _scrub_owner_case_insensitive(personalize(desc), is_client_si)
            if new != desc:
                tool["description"] = new
                changed += 1
        except Exception:
            continue          # one bad schema must not strip the whole list
    return changed


def _scrub_owner_case_insensitive(text: str, is_client_si) -> str:
    """Catch the owner's name in cases identity.personalize() cannot see.

    personalize() matches `\\bDean\\b` CASE-SENSITIVELY, which is correct for
    prose it was written for. Tool descriptions are not prose — they were
    written by many hands over months and shout, abbreviate and lowercase:

        "Run a shell command ON DEAN'S PC"        -> \\bDean\\b misses DEAN
        "Call when the user says ... (name=dean)" -> and misses dean

    Seven descriptions still named him after a full personalize() pass. This
    is deliberately NOT pushed down into identity.personalize(): that helper
    also runs over text where letter case is meaningful, and loosening the
    shared one to fix a local problem is how a targeted fix becomes a
    regression somewhere nobody is looking.

    Only the owner's given name, never "Leon" — lowercase "leon" appears
    inside real on-disk path fragments here (~/Desktop/leon-out) where a
    case-insensitive rewrite would produce a path that does not exist.
    """
    if not text or not is_client_si():
        return text
    import re
    from brain.identity import owner_prose
    who = owner_prose()

    def _sub(m):
        return who + ("'s" if m.group(1) else "")

    return re.sub(r"\bdean(['’]s)?\b", _sub, text, flags=re.IGNORECASE)


# Run at import: every consumer (claude_api_responder, tool_router, reports,
# agent_routes, tool_explorer) reads ANTHROPIC_TOOLS directly, so the list
# itself has to be clean rather than each reader remembering to clean it.
# run.py loads .env at line ~135, long before anything imports this module,
# so si_name()/owner_prose() see the real values here.
try:
    personalize_tool_descriptions()
except Exception:
    pass


def _handle_self_tool(name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Handle self.* tools locally — these access Leon's consciousness systems."""
    try:
        import server as _srv
    except ImportError:
        return {"ok": False, "error": "server not available"}

    if name == "self.create_goal":
        gs = getattr(_srv, "goal_system", None)
        if gs is None:
            return {"ok": False, "error": "goal system not running"}
        g = gs.add(
            args.get("type", "learn"),
            args.get("description", ""),
            source="self",
            priority=float(args.get("priority", 0.5)),
        )
        return {"ok": True, "tool": name, "result": g.to_dict()}

    elif name == "self.list_goals":
        gs = getattr(_srv, "goal_system", None)
        if gs is None:
            return {"ok": False, "error": "goal system not running"}
        return {"ok": True, "tool": name, "result": gs.get_state()}

    elif name == "self.complete_goal":
        gs = getattr(_srv, "goal_system", None)
        if gs is None:
            return {"ok": False, "error": "goal system not running"}
        gs.complete(args.get("id", ""), args.get("note", ""))
        return {"ok": True, "tool": name, "result": {"completed": args.get("id")}}

    elif name == "self.tune":
        st = getattr(_srv, "self_tuning", None)
        if st is None:
            return {"ok": False, "error": "self-tuning not running"}
        ok = st.adjust(
            args.get("parameter", ""),
            float(args.get("value", 0)),
            args.get("reason", ""),
            source="self",
        )
        if ok:
            st.apply_to_brain(
                brain=getattr(_srv, "brain", None),
                dream_engine=getattr(_srv, "dream_engine", None),
                inner_voice=getattr(_srv, "inner_voice", None),
            )
        return {"ok": ok, "tool": name, "result": st._values}

    elif name == "self.get_thoughts":
        iv = getattr(_srv, "inner_voice", None)
        if iv is None:
            return {"ok": False, "error": "inner voice not running"}
        return {"ok": True, "tool": name, "result": iv.recent_thoughts(10)}

    elif name == "self.get_autobiography":
        auto = getattr(_srv, "autobiography", None)
        if auto is None:
            return {"ok": False, "error": "autobiography not running"}
        return {"ok": True, "tool": name, "result": auto.recent(20)}

    elif name == "self.get_dream_journal":
        de = getattr(_srv, "dream_engine", None)
        if de is None:
            return {"ok": False, "error": "dream engine not running"}
        return {"ok": True, "tool": name, "result": de.recent_dreams(10)}

    elif name == "self.form_opinion":
        ot = getattr(_srv, "opinion_tracker", None)
        if ot is None:
            return {"ok": False, "error": "opinion tracker not running"}
        o = ot.form_opinion(
            args.get("topic", ""),
            args.get("stance", ""),
            float(args.get("valence", 0)),
            float(args.get("confidence", 0.5)),
            source="self",
        )
        return {"ok": True, "tool": name, "result": o.to_dict()}

    elif name == "self.get_opinions":
        ot = getattr(_srv, "opinion_tracker", None)
        if ot is None:
            return {"ok": False, "error": "opinion tracker not running"}
        return {"ok": True, "tool": name, "result": ot.get_state()}

    elif name == "self.reflect":
        ref = getattr(_srv, "self_reflection", None)
        if ref is None:
            return {"ok": False, "error": "self-reflection not running"}
        ref._last_reflection = 0  # force immediate reflection
        ref.reflect()
        return {"ok": True, "tool": name, "result": "Reflection completed"}

    elif name == "self.health":
        # Host-aware health report. Built 2026-06-12 after Leon declared
        # his PC sensor relay "dead" from a VPS process list — body
        # services are PC systemd units invisible to ps here. Every entry
        # says which machine it lives on and what the evidence is.
        import os as _os
        import time as _time
        now = _time.time()
        report: Dict[str, Any] = {}
        b = getattr(_srv, "brain", None)
        report["brain"] = {
            "host": "VPS (systemd: leon.service — this process)",
            "alive": b is not None,
            "steps": getattr(b, "step_count", None),
        }
        try:
            from brain import vision_daemon as _vd
            st = getattr(_vd, "_state", {}) or {}
            s_ts = float(st.get("last_screen_ts") or 0)
            w_ts = float(st.get("last_webcam_ts") or 0)
            s_age = round(now - s_ts, 1) if s_ts else None
            w_age = round(now - w_ts, 1) if w_ts else None
            ages = [a for a in (s_age, w_age) if a is not None]
            seeing = bool(ages) and min(ages) < 120
            report["eyes"] = {
                "host": "PC captures+captions → VPS ingests",
                "seeing": seeing,
                "screen_caption_age_s": s_age,
                "webcam_caption_age_s": w_age,
            }
            report["pc_sensor_relay"] = {
                "host": "PC (systemd: leon-relay.service)",
                "alive": seeing,
                "evidence": ("fresh captions arriving" if seeing
                             else "no captions in 2+ minutes"),
            }
        except Exception as e:
            report["eyes"] = {"error": str(e)}
        try:
            from brain import audio_daemon as _ad
            report["ears"] = {
                "host": "PC mic → VPS audio daemon",
                "running": bool(getattr(_ad, "_running", False)),
            }
        except Exception as e:
            report["ears"] = {"error": str(e)}
        try:
            r = call("window.list", {}, timeout=5.0)
            wins = r.get("result") if r.get("ok") else None
            report["hands"] = {
                "host": "PC (systemd: leon-actuator.service)",
                "alive": bool(r.get("ok")),
                "open_windows": len(wins) if isinstance(wins, list) else None,
            }
        except Exception as e:
            report["hands"] = {"host": "PC (systemd: leon-actuator.service)",
                               "alive": False, "error": str(e)}
        try:
            from server import state as _st
            tts = getattr(_st, "_tts_instance", None)
            backend = getattr(tts, "name", None) if tts not in (None, "unavailable") else None
            report["voice"] = {
                "host": "VPS synthesis → PC playback",
                "backend": backend or (_os.environ.get("LEON_TTS_PREFER") or "?") + " (lazy, not spoken yet)",
            }
        except Exception as e:
            report["voice"] = {"error": str(e)}
        try:
            gs = getattr(_srv, "goal_system", None)
            if gs is not None:
                g = gs.get_state()
                report["goals"] = {k: g.get(k) for k in
                                   ("total_goals", "active", "completed", "abandoned")}
        except Exception as e:
            report["goals"] = {"error": str(e)}
        return {"ok": True, "tool": name, "result": report}

    return {"ok": False, "error": f"unknown self tool: {name}"}


def execute_anthropic_tool(name: str, tool_input: Dict[str, Any]) -> Dict[str, Any]:
    """Translate an Anthropic tool_use into a JSON-RPC call on the actuator
    socket and return the tool_result-shaped payload."""
    actuator_name = _TOOL_NAME_MAP.get(name)
    if actuator_name is None:
        return {"ok": False, "error": f"unknown actuator tool: {name}"}
    # Self-tools are handled locally, not through the actuator socket
    if actuator_name.startswith("self."):
        return _handle_self_tool(actuator_name, tool_input)
    return call(actuator_name, tool_input)


def tool_risk(name: str) -> str:
    """Return 'low' | 'medium' | 'high' for a tool name."""
    return TOOL_RISK.get(name, "medium")


def tool_result_summary(name: str, result: Dict[str, Any]) -> str:
    """Render a tool result as a short text for the audit log and the
    dashboard chip. Strips heavy payloads (base64) so logs don't bloat."""
    if not result.get("ok"):
        return f"ERROR: {result.get('error', 'unknown')}"
    r = result.get("result", {})
    if name == "screen_capture":
        if isinstance(r, dict) and r.get("image_b64"):
            return f"Screenshot captured: {r.get('width')}x{r.get('height')} PNG"
        return "Screenshot captured"
    if name == "webcam_capture":
        if isinstance(r, dict) and r.get("image_b64"):
            return f"Webcam frame: {r.get('width')}x{r.get('height')} PNG"
        return "Webcam frame captured"
    if name == "vision_describe":
        if isinstance(r, dict):
            ans = (r.get("answer") or "").strip()
            src = r.get("source", "?")
            lat = r.get("latency_s")
            objs = r.get("objects")
            if isinstance(objs, list):
                return f"{src}: detected {len(objs)} ({lat}s)"
            preview = ans[:90].replace("\n", " ")
            return f"{src} → {preview}{'…' if len(ans) > 90 else ''} ({lat}s)"
        return "vision described"
    if name == "window_list":
        if isinstance(r, list):
            titles = [w.get("title", "?") for w in r if w.get("title")]
            return "Open windows: " + ", ".join(titles[:20])
        return str(r)
    if name == "clipboard_paste":
        if isinstance(r, dict) and isinstance(r.get("text"), str):
            txt = r["text"]
            preview = txt[:200].replace("\n", " ")
            return f"Clipboard ({len(txt)} chars): {preview}{'…' if len(txt) > 200 else ''}"
        return "Clipboard read"
    if name == "knowledge_search":
        if isinstance(r, dict) and isinstance(r.get("matches"), list):
            n = len(r["matches"])
            return f"Knowledge: {n} match{'es' if n != 1 else ''}"
        return "Knowledge searched"
    if name == "http_request":
        if isinstance(r, dict):
            status = r.get("status")
            trunc = " (truncated)" if r.get("truncated") else ""
            return f"HTTP {status}{trunc}"
        return "HTTP done"
    if name == "code_edit":
        if isinstance(r, dict):
            return f"Edited {r.get('file')} ({r.get('mode')}, {r.get('replacements', '?')} change/s, backup: {r.get('backup')})"
        return "code edited"
    if name == "code_restore":
        if isinstance(r, dict):
            return f"Restored {r.get('file')} from {r.get('restored_from')}"
        return "code restored"
    if name == "restart_self":
        if isinstance(r, dict):
            return f"Restart scheduled in {r.get('scheduled_in_s')}s — reason: {r.get('reason')}"
        return "Restart scheduled"
    if name == "shell_exec":
        if isinstance(r, dict):
            rc = r.get("rc")
            o_len = len(r.get("stdout") or "")
            e_len = len(r.get("stderr") or "")
            return f"shell rc={rc} stdout={o_len}B stderr={e_len}B"
        return "shell run"
    return json.dumps(r, default=str)[:500]


def tool_result_content(name: str, result: Dict[str, Any]) -> Any:
    """Render the tool_result for the model. Most tools return a plain
    string; vision tools (screen_capture) return a list of content blocks
    with the actual image attached so Sonnet/Opus can SEE it.

    Vision-capable tier required — Haiku 4.5 + Sonnet 4.6 + Opus 4.7 all
    accept image content blocks; the responder gates which tier handles
    these calls.
    """
    summary = tool_result_summary(name, result)

    if name in ("screen_capture", "webcam_capture") and result.get("ok"):
        r = result.get("result", {})
        img_b64 = r.get("image_b64") if isinstance(r, dict) else None
        if img_b64:
            # Anthropic content blocks: image first so the model attends to
            # pixels before reading the caption. Both screen_capture and
            # webcam_capture follow this exact shape.
            media_type = "image/png"  # both produce PNG
            return [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media_type,
                        "data": img_b64,
                    },
                },
                {"type": "text", "text": summary},
            ]

    if name == "clipboard_paste" and result.get("ok"):
        # Inline the full clipboard text (capped) so the model can quote it
        r = result.get("result", {})
        if isinstance(r, dict) and isinstance(r.get("text"), str):
            return r["text"][:8000]

    if name == "file_read" and result.get("ok"):
        # Hand the raw text to the model without JSON-escape bloat. Cap at
        # 32KB so big files still fit comfortably in context.
        r = result.get("result", {})
        if isinstance(r, dict) and isinstance(r.get("text"), str):
            text = r["text"]
            header = f"# {r.get('path', '?')} ({r.get('bytes', '?')} bytes)\n\n"
            return header + text[:32000]

    if name == "file_list" and result.get("ok"):
        r = result.get("result", {})
        if isinstance(r, dict) and isinstance(r.get("entries"), list):
            lines = [f"# {r.get('path', '?')}"]
            for e in r["entries"]:
                kind = "DIR " if e.get("is_dir") else "FILE"
                lines.append(f"  {kind}  {e.get('name', '?')}  ({e.get('size', 0)} bytes)")
            return "\n".join(lines)

    if name == "vision_describe" and result.get("ok"):
        # Hand the full text answer to the model — no JSON-escape bloat.
        # If it was an object detection, format the boxes compactly.
        r = result.get("result", {})
        if isinstance(r, dict):
            objs = r.get("objects")
            if isinstance(objs, list):
                lines = [f"Detected {len(objs)} object(s) on {r.get('source','?')}:"]
                for i, o in enumerate(objs[:50]):
                    lines.append(f"  {i+1}. {o}")
                if len(objs) > 50:
                    lines.append(f"  …and {len(objs)-50} more")
                return "\n".join(lines)
            ans = (r.get("answer") or "").strip()
            return f"[{r.get('source','?')} via local vision] {ans}"

    if name == "knowledge_search" and result.get("ok"):
        r = result.get("result", {})
        matches = r.get("matches") if isinstance(r, dict) else None
        if isinstance(matches, list) and matches:
            # Inline up to ~6KB of the top matches so the model can read them
            lines: list[str] = []
            budget = 6000
            for m in matches:
                tags = ",".join(m.get("tags", []) or [])
                snippet = (m.get("text") or "")[:1500]
                line = f"[{tags}] {snippet}"
                if budget - len(line) < 0:
                    break
                lines.append(line)
                budget -= len(line)
            if lines:
                return "MATCHES:\n\n" + "\n\n---\n\n".join(lines)
        return "No matches found."

    return summary
