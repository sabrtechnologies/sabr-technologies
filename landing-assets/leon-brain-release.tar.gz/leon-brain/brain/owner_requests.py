"""Chat entry point into the durable owner work queue (ledger item 31).

Before this, entries only came from owner-goal-plan.json, which Dean never
writes, so an idea he said in chat never reached brain/work_queue.py. This tool
is how the conversation brain puts it there. It writes only through
work_queue.enqueue (atomic save); the tick/boot walk, attempt caps and the
one-job-at-a-time guard are unchanged.
"""
import hashlib
import re
import time

DEFAULT_FOLDER = "/opt/leon-brain"
DEFAULT_PROVIDER = "claude"
TERMINAL_STATES = ("done", "blocked")

TOOL = {
    "name": "queue_owner_request",
    "description": (
        "Put something Dean asked for in chat onto your durable work queue, so it is "
        "carried across restarts, usage limits and failures until its done check passes "
        "(one job at a time, walked by your action-cue tick). Needs goal (short name), "
        "done_when ('shipped', 'result_contains:<text>' or 'path_exists:<path>'), task "
        "(the full instruction for the worker), and model and effort (the selected coding "
        "settings, passed unchanged). Optional: folder (default /opt/leon-brain), provider "
        "(claude or codex, default claude), execution_location (default vps). If an open "
        "entry with the same goal already exists it is returned with deduped=true instead "
        "of adding a second. Returns the entry id and state."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "goal": {"type": "string", "description": "Short name of what Dean wants."},
            "done_when": {"type": "string", "description": "shipped | result_contains:<text> | path_exists:<path>"},
            "task": {"type": "string", "description": "Full instruction for the coding worker."},
            "model": {"type": "string", "description": "Selected coding model, passed unchanged."},
            "effort": {"type": "string", "description": "Selected reasoning effort, passed unchanged."},
            "folder": {"type": "string", "description": "Absolute project folder (default /opt/leon-brain)."},
            "provider": {"type": "string", "enum": ["claude", "codex"]},
            "execution_location": {"type": "string", "description": "Where the job runs (default vps)."},
        },
        "required": ["goal", "done_when", "task", "model", "effort"],
        "additionalProperties": False,
    },
}


def _norm(goal):
    return re.sub(r"\s+", " ", (goal or "").strip()).lower()


def queue_owner_request(args):
    from brain import work_queue as wq

    if not isinstance(args, dict):
        return {"ok": False, "error": "queue_owner_request needs an arguments object."}
    extra = set(args) - set(TOOL["input_schema"]["properties"])
    if extra:
        return {"ok": False, "error": "Unknown argument(s): " + ", ".join(sorted(extra))}
    clean = {}
    for key in ("goal", "done_when", "task", "model", "effort"):
        value = args.get(key)
        if not isinstance(value, str) or not value.strip():
            return {"ok": False, "error": "queue_owner_request requires a non-empty %s." % key}
        clean[key] = value.strip()
    provider = str(args.get("provider") or DEFAULT_PROVIDER).strip()
    if provider not in ("claude", "codex"):
        return {"ok": False, "error": "provider must be claude or codex."}
    folder = str(args.get("folder") or DEFAULT_FOLDER).strip()
    if not wq.is_absolute_folder(folder):
        return {"ok": False, "error": "folder must be an absolute path (/opt/... or C:\\...), got %r." % folder}
    location = str(args.get("execution_location") or "vps").strip()
    if wq.is_laptop_folder(folder):
        location = "laptop"

    with wq._lock:
        entries = wq.load()
        key = _norm(clean["goal"])
        same = [e for e in entries if _norm(e.get("goal")) == key]
        open_entry = next((e for e in same if e.get("state") not in TERMINAL_STATES), None)
        if open_entry:
            return {"ok": True, "id": open_entry["id"], "state": open_entry.get("state"), "deduped": True}
        # enqueue keys ids on the goal hash; a finished/blocked entry for the same
        # goal must not swallow a new request, so that case gets a fresh id.
        default_id = "wq-" + hashlib.sha256(clean["goal"].encode()).hexdigest()[:12]
        entry_id = None
        if same or any(e.get("id") == default_id for e in entries):
            entry_id = "wq-%d-%d" % (int(time.time()), len(entries))
        try:
            entry = wq.enqueue(clean["goal"], clean["done_when"], task=clean["task"], folder=folder,
                               provider=provider, model=clean["model"], effort=clean["effort"],
                               execution_location=location, entry_id=entry_id)
        except ValueError as exc:
            return {"ok": False, "error": str(exc)}
    if entry.get("ok") is False:
        return entry  # refused before any write, e.g. model not in the VPS catalog
    return {"ok": True, "id": entry["id"], "state": entry["state"], "deduped": False}


def requeue_owner_request(args):
    """Dean said retry: reset attempts/error and put the entry back in the queue."""
    from brain import work_queue as wq
    entry_id = (args or {}).get("id") if isinstance(args, dict) else None
    if not isinstance(entry_id, str) or not entry_id.strip():
        return {"ok": False, "error": "requeue needs the entry id."}
    return wq.requeue(entry_id.strip())


EXTRA_TOOLS = {"queue.owner_request": queue_owner_request,
               "queue.requeue": requeue_owner_request}
