"""Pure Windows path validation shared by the server and laptop actuator.

Kept as two identical files: brain/conversation_paths.py for the server and
leon-actuator/conversation_paths.py for the laptop, whose actuator runs from
its own folder with no brain/ package. tests/test_conversation_open_path.py
fails if the copies differ.
"""
import ntpath
import re

SAFE_OPEN_EXTENSIONS = frozenset(('txt', 'md', 'log', 'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'))
PRIVATE_DIRS = frozenset(('.ssh', '.claude', '.codex', '.hermes', '.gnupg', 'secure'))


def validate_windows_target(raw, home):
    if not isinstance(raw, str) or not raw or len(raw) > 1024 or any(ord(c) < 32 for c in raw):
        raise ValueError('invalid Windows path')
    if not re.match(r'^[A-Za-z]:[\\/]', raw) or raw.startswith(('\\\\', '//')):
        raise ValueError('an absolute Windows drive path is required')
    full = ntpath.normpath(raw.replace('/', '\\'))
    base = ntpath.normpath(home).rstrip('\\')
    if full.casefold() != base.casefold() and not full.casefold().startswith(base.casefold() + '\\'):
        raise ValueError('path is outside the laptop home')
    if ':' in full[2:] or any(c in full for c in '*?"<>|'):
        raise ValueError('invalid Windows path')
    for part in full.split('\\')[1:]:
        if part.endswith((' ', '.')) or part.casefold() in PRIVATE_DIRS:
            raise ValueError('private or ambiguous Windows path')
        if re.fullmatch(r'(con|prn|aux|nul|com[0-9¹²³]|lpt[0-9¹²³])(?:\..*)?', part, re.I):
            raise ValueError('Windows device names are not paths')
    return full


def must_reveal(path):
    return ntpath.splitext(path)[1].lower().lstrip('.') not in SAFE_OPEN_EXTENSIONS
