"""
Active Context — what Leon is currently doing, persisted across restarts.

The #1 reason Leon "feels different after restart" is that he loses track
of what he was DOING. His memories persist but the active task context
evaporates. This module fixes that.

Every time Dean asks Leon to do something (detected by the responder),
the active context is saved. On boot, it's injected into the prompt so
Leon picks up right where he left off.

Saved to brain_state/active_context.json.
"""

from __future__ import annotations

import json
import os
import time
from brain import identity as _ident
from typing import Any, Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_CONTEXT_PATH = os.path.join(_ROOT, "brain_state", "active_context.json")


class ActiveContext:
    """Tracks what Leon is currently doing across restarts."""

    def __init__(self):
        self.current_task: Optional[str] = None
        self.task_status: str = "idle"
        self.last_dean_request: Optional[str] = None
        self.last_dean_request_ts: float = 0.0
        self.recent_topics: List[str] = []  # last 5 conversation topics
        self.tabs_opened: List[str] = []     # URLs Leon opened (for cleanup)
        self._load()

    # Context older than this is stale and gets cleared on load.
    # Prevents Leon from carrying "Dean asked you to X" for hours/days
    # after the request is no longer relevant.
    TASK_TTL_S = 1800.0       # 30 min — tasks expire
    TOPICS_TTL_S = 3600.0     # 1 hour — topics expire

    def _load(self):
        try:
            if os.path.exists(_CONTEXT_PATH):
                with open(_CONTEXT_PATH) as f:
                    data = json.load(f)
                self.last_dean_request_ts = data.get("last_dean_request_ts", 0)
                age = time.time() - self.last_dean_request_ts

                # Expire stale task context
                if age < self.TASK_TTL_S:
                    self.current_task = data.get("current_task")
                    self.task_status = data.get("task_status", "idle")
                    self.last_dean_request = data.get("last_dean_request")
                else:
                    if data.get("current_task"):
                        print(f"[ACTIVE_CTX] expired stale task ({age/60:.0f}m old): "
                              f"{data.get('current_task', '')[:60]}")
                    self.current_task = None
                    self.task_status = "idle"
                    self.last_dean_request = None

                # Expire stale topics
                if age < self.TOPICS_TTL_S:
                    self.recent_topics = data.get("recent_topics", [])
                else:
                    self.recent_topics = []

                self.tabs_opened = data.get("tabs_opened", [])
        except Exception as e:
            print(f"[ACTIVE_CTX] load failed: {e}")

    def _save(self):
        try:
            tmp = _CONTEXT_PATH + ".tmp"
            with open(tmp, "w") as f:
                json.dump({
                    "current_task": self.current_task,
                    "task_status": self.task_status,
                    "last_dean_request": self.last_dean_request,
                    "last_dean_request_ts": self.last_dean_request_ts,
                    "recent_topics": self.recent_topics[-5:],
                    "tabs_opened": self.tabs_opened[-20:],
                    "saved_ts": time.time(),
                }, f, indent=2)
            os.replace(tmp, _CONTEXT_PATH)
        except Exception as e:
            print(f"[ACTIVE_CTX] save failed: {e}")

    def on_dean_message(self, text: str):
        """Called when Dean sends a message. Detect task requests."""
        self.last_dean_request = text[:300]
        self.last_dean_request_ts = time.time()

        # Detect if this is a task assignment
        _lower = text.lower()
        _task_signals = (
            "build", "create", "make", "write", "code", "fix", "set up",
            "install", "deploy", "go do", "go ahead", "start", "can you",
            "would you", "do this", "do that", "sign up", "open", "search",
            "find", "look for", "check", "get me", "send", "draft",
            "yes go", "yeah go", "sure go", "do it",
        )
        if any(sig in _lower for sig in _task_signals):
            self.current_task = text[:200]
            self.task_status = "assigned"
            self._save()

        # Track topics
        words = [w for w in text.split() if len(w) > 4][:3]
        if words:
            topic = " ".join(words)
            if topic not in self.recent_topics:
                self.recent_topics.append(topic)
                self.recent_topics = self.recent_topics[-5:]
        self._save()

    def on_task_progress(self, note: str):
        """Called when Leon makes progress on the task."""
        self.task_status = "in_progress"
        self._save()

    def on_task_complete(self):
        """Called when Leon finishes the current task."""
        self.task_status = "done"
        self._save()

    def on_tab_opened(self, url: str):
        """Track tabs Leon opens (for cleanup)."""
        if url not in self.tabs_opened:
            self.tabs_opened.append(url)
            self.tabs_opened = self.tabs_opened[-20:]
            self._save()

    def for_prompt(self) -> str:
        """Generate context string for injection into the prompt."""
        parts = []

        if self.current_task and self.task_status != "done":
            age_s = time.time() - self.last_dean_request_ts
            # Never inject tasks older than TTL into the prompt
            if age_s > self.TASK_TTL_S:
                self.current_task = None
                self.task_status = "idle"
                self._save()
            else:
                age_min = age_s / 60
                parts.append(
                    f"[ACTIVE TASK — {self.task_status.upper()}] "
                    f"Dean asked you ({age_min:.0f} min ago): "
                    f"{self.current_task}"
                )
                if self.task_status == "assigned" and age_min < 10:
                    parts.append(
                        "You haven't started this yet. DO IT NOW — don't "
                        "describe the plan, fire tools."
                    )

        if self.recent_topics:
            age_s = time.time() - self.last_dean_request_ts
            if age_s < self.TOPICS_TTL_S:
                parts.append(
                    f"[RECENT TOPICS] {', '.join(self.recent_topics[-3:])}"
                )
            else:
                self.recent_topics = []

        # personalize on the way out — the branches above say "Dean asked
        # you", and this string is injected into EVERY prompt built.
        return _ident.personalize("\n".join(parts))
