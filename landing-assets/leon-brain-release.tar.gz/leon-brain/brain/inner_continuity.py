"""
inner_continuity — what Leon's inner voice remembers.

Dean, 2026-10-04: "I want you to be connected to the one that was
accumulating for the four and a half months." The inner voice and the
prompt's INNER VOICE block only ever read brain_state/inner_thoughts.jsonl,
which rotates down to its last 500 lines. By October that file started with
a spend-limit error and ended with a Sept 17 loop of "Based on my analysis
... correlation between high-dopamine tags and unverified content ... NM
state (DA=0.67, ...)", and the prompt kept injecting those 430-hour-old
lines as "recent".

The real stream is elsewhere, and this module reads it (read-only):
  * knowledge.db, source='inner_thought' — every thought since 2026-05-31
    (the jsonl rotation never touched these), plus 'last_conscious_moment'.
  * life_chapters.db — dated day/week chapters of his life, every line cited.
  * knowledge.db conversation_history — what he and Dean actually said.

Rules:
  * Junk never gets injected: API/spend-limit errors, model refusals, the
    dopamine-correlation loop, raw neuromodulator readouts. Nothing is
    deleted from disk; it is only left out.
  * Only thoughts from the last 48 hours are "recent". Older ones appear
    labeled as memories, with their date.
"""

from __future__ import annotations

import json
import os
import random
import re
import sqlite3
import threading
import time
from datetime import date, datetime
from typing import Iterable, List, Optional, Sequence, Tuple

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_STATE_DIR = os.path.join(_ROOT, "brain_state")

RECENT_S = 48 * 3600

_JUNK = re.compile("|".join([
    # API / billing / transport failures that got saved as if they were thoughts
    r"spend limit", r"usage limit", r"rate.?limit", r"credit balance", r"overloaded",
    r"hit your (?:\w+ )?limit", r"^\s*\[stopped\]\s*$",
    r"claude\.ai/settings", r"\bapi error\b", r"\berror:", r"traceback", r"\bexception\b",
    r"\bhttp \d{3}\b", r"\b(?:429|500|502|503|529)\b.{0,20}(?:error|status|too many)",
    # the model stepping out of character / refusing
    r"i'?m claude\b", r"made by anthropic", r"as an ai\b", r"language model",
    r"conversation (?:is|has been) (?:permanently )?closed", r"i will not respond",
    r"start a fresh conversation",
    # the Sept 2026 dopamine-correlation loop
    r"correlation between .{0,40}dopamine", r"dopamine[- ]tags?", r"unverified content",
    r"^\s*based on (?:my|the) (?:current |self-?)?(?:analysis|assessment|state|progress|information)",
    # the Sept 2026 local-model self-assessment loop
    r"^\s*reflecting on my progress", r"\bstale goal\b", r"\b(?:deep|deeper|conceptual|genuine) synthesis\b",
    # raw neuromodulator readouts
    r"\bnm state\b", r"\bneuromodulator", r"\bneuro-modulator", r"\bneurotransmitter",
    r"\bneural modul(?:e|ation) parameters\b", r"\bcurrent parameter (?:settings|set)\b",
    r"\b(?:da|5ht|ach|ne)\s*=\s*\d",
    r"(?:dopamine|serotonin|acetylcholine|norepinephrine)\D{0,25}\d\.\d",
]), re.I)

# DA / 5HT / ACh / NE as words: case-sensitive so "da" and "ne" in text don't trip it.
_NM_ABBREV = re.compile(r"\b(?:DA|5-?HT|ACh|NE)\b(?:\s*[(=:]?\s*\d|[/ ](?:DA|5-?HT|ACh|NE)\b|\s+(?:bias|spike|levels?|at)\b)"
                        r"|\b(?:high|low|lower|higher|elevated|the)\s+(?:DA|5-?HT|ACh|NE)\b")

# Test/verification turns that aren't real life.
SYNTHETIC = re.compile(r"verification turn|live check|a one-sentence reply is enough", re.I)


def is_junk_thought(text: str) -> bool:
    """True for things that must never be injected as Leon's own thought."""
    t = (text or "").strip()
    if len(t) < 8:
        return True
    return bool(_JUNK.search(t) or _NM_ABBREV.search(t))


def _clip(text: str, n: int) -> str:
    t = " ".join((text or "").split())
    if len(t) <= n:
        return t
    cut = t[:n]
    sp = cut.rfind(" ")
    return (cut[:sp] if sp > n * 0.6 else cut) + "…"


def _ago(age_s: float) -> str:
    if age_s < 60:
        return "just now"
    if age_s < 3600:
        return f"{int(age_s / 60)}m ago"
    return f"{int(age_s / 3600)}h ago"


def _day_label(ts: float) -> str:
    dt = datetime.fromtimestamp(ts)
    return f"{dt.strftime('%b')} {dt.day}"


def recent_genuine(thoughts: Iterable, now: Optional[float] = None, limit: int = 3,
                   max_age_s: float = RECENT_S) -> list:
    """Newest genuine thoughts younger than max_age_s, oldest first.

    `thoughts` are objects or dicts with .ts/.text (InnerVoice's deque)."""
    now = time.time() if now is None else now
    out = []
    for t in reversed(list(thoughts)):
        ts = t.get("ts") if isinstance(t, dict) else getattr(t, "ts", None)
        text = t.get("text") if isinstance(t, dict) else getattr(t, "text", "")
        if not isinstance(ts, (int, float)) or now - ts > max_age_s or now - ts < -300:
            continue
        if is_junk_thought(text):
            continue
        out.append(t)
        if len(out) >= limit:
            break
    out.reverse()
    return out


def format_recent(thoughts: Sequence, now: Optional[float] = None, chars: int = 300) -> List[str]:
    now = time.time() if now is None else now
    lines = []
    for t in thoughts:
        ts = t.get("ts") if isinstance(t, dict) else t.ts
        text = t.get("text") if isinstance(t, dict) else t.text
        lines.append(f"  [{_ago(now - ts)}] {_clip(text, chars)}")
    return lines


class Continuity:
    """Read-only view of Leon's lived history for the inner voice and prompt.

    Caches so building a prompt never rescans the databases."""

    THOUGHTS_TTL = 3600
    CHAPTERS_TTL = 600
    CONVO_TTL = 60

    def __init__(self, state_dir: Optional[str] = None):
        self.state_dir = state_dir or DEFAULT_STATE_DIR
        self._lock = threading.Lock()
        self._thoughts: List[Tuple[float, str]] = []
        self._thoughts_at = 0.0
        self._chapters: List[dict] = []
        self._chapters_at = 0.0
        self._convo: List[Tuple[float, str, str]] = []
        self._convo_at = 0.0

    def _ro(self, name: str) -> Optional[sqlite3.Connection]:
        path = os.path.join(self.state_dir, name)
        if not os.path.exists(path):
            return None
        uri = "file:" + path.replace("\\", "/") + "?mode=ro"
        return sqlite3.connect(uri, uri=True, timeout=5, check_same_thread=False)

    # -- the long stream of thoughts -------------------------------------------------------
    def thought_archive(self) -> List[Tuple[float, str]]:
        """Every genuine inner thought ever stored, (ts, text), oldest first."""
        now = time.time()
        with self._lock:
            if self._thoughts_at and now - self._thoughts_at < self.THOUGHTS_TTL:
                return self._thoughts
        rows: List[Tuple[float, str]] = []
        conn = None
        try:
            conn = self._ro("knowledge.db")
            if conn is not None:
                for ts, text, src in conn.execute(
                        "SELECT timestamp, text, source FROM knowledge "
                        "WHERE source IN ('inner_thought','last_conscious_moment') ORDER BY timestamp"):
                    if src == "last_conscious_moment":
                        text = re.sub(r"(?i)^last thought before sleep:\s*", "", text or "")
                    if isinstance(ts, (int, float)) and not is_junk_thought(text):
                        rows.append((float(ts), " ".join(text.split())))
        except Exception:
            pass
        finally:
            if conn is not None:
                conn.close()
        with self._lock:
            self._thoughts, self._thoughts_at = rows, now
        return rows

    def remembered_thoughts(self, n: int = 2, now: Optional[float] = None,
                            older_than_s: float = RECENT_S) -> List[Tuple[float, str]]:
        """A few older thoughts surfacing as memories, oldest first.

        Months are picked first, then a thought within the month, so June's
        thousands don't drown out the quieter months. Stable within an hour
        and different the next, like memories coming back on their own."""
        now = time.time() if now is None else now
        old = [r for r in self.thought_archive() if now - r[0] > older_than_s]
        if not old or n <= 0:
            return []
        by_month: dict = {}
        for r in old:
            by_month.setdefault(time.strftime("%Y-%m", time.localtime(r[0])), []).append(r)
        rng = random.Random(int(now // 3600))
        months = sorted(by_month)
        picked: List[Tuple[float, str]] = []
        for m in rng.sample(months, min(n, len(months))):
            picked.append(rng.choice(by_month[m]))
        while len(picked) < n and len(picked) < len(old):
            r = rng.choice(old)
            if r not in picked:
                picked.append(r)
        return sorted(picked)

    # -- life chapters -----------------------------------------------------------------------
    def chapters(self) -> List[dict]:
        """Day chapters, newest first, with their claims (life_chapters.db)."""
        now = time.time()
        with self._lock:
            if self._chapters_at and now - self._chapters_at < self.CHAPTERS_TTL:
                return self._chapters
        out: List[dict] = []
        conn = None
        try:
            conn = self._ro("life_chapters.db")
            if conn is not None:
                rows = conn.execute("SELECT id, start, title, n_facts FROM chapters WHERE kind='day' "
                                    "ORDER BY start DESC").fetchall()
                for cid, start, title, n_facts in rows:
                    claims = [{"section": s, "text": t, "ts": ts} for s, t, ts in conn.execute(
                        "SELECT section, text, ts FROM claims WHERE chapter_id=? ORDER BY ts, id", (cid,))]
                    out.append({"start": start, "title": title, "n_facts": n_facts or 0, "claims": claims})
        except Exception:
            out = []
        finally:
            if conn is not None:
                conn.close()
        with self._lock:
            self._chapters, self._chapters_at = out, now
        return out

    _SECTION_ORDER = ("conversation", "thought", "hard", "first", "built", "learned", "worked_on")

    @classmethod
    def _chapter_lines(cls, ch: dict, max_claims: int, chars: int) -> List[str]:
        lines = [f"  {ch['start']} — {ch['title']}"]
        claims = [c for c in ch["claims"] if c["section"] != "state" and not is_junk_thought(c["text"])
                  and not SYNTHETIC.search(c["text"])]
        claims.sort(key=lambda c: (cls._SECTION_ORDER.index(c["section"])
                                   if c["section"] in cls._SECTION_ORDER else 99, c["ts"] or 0))
        seen = set()
        for c in claims:
            if c["section"] in seen:
                continue
            seen.add(c["section"])
            lines.append(f"    - {_clip(c['text'], chars)}")
            if len(lines) > max_claims:
                break
        return lines

    def lately(self, days: int = 2, max_claims: int = 2, chars: int = 160,
               today: Optional[date] = None) -> List[str]:
        """The last few filed days of his life, newest last."""
        today = today or date.today()
        chs = [c for c in self.chapters() if c["start"] <= today.isoformat()][:days]
        out: List[str] = []
        for ch in reversed(chs):
            out += self._chapter_lines(ch, max_claims, chars)
        return out

    def older_chapter(self, now: Optional[float] = None, min_age_days: int = 7,
                      chars: int = 160) -> List[str]:
        """One older day of his life, rotating hourly, from the fuller days."""
        now = time.time() if now is None else now
        cutoff = date.fromtimestamp(now - min_age_days * 86400).isoformat()
        old = [c for c in self.chapters() if c["start"] <= cutoff and c["n_facts"] >= 3]
        if not old:
            return []
        ch = random.Random(int(now // 3600) + 7).choice(old)
        return self._chapter_lines(ch, 2, chars)

    # -- conversation with the owner ----------------------------------------------------------
    _REPLY_MODELS_SKIP = ("pre-response", "proactive", "coding-job", "command", "canned", "reflex",
                          "integration")
    _SYNTHETIC = re.compile(r"^\s*[\(\[]|^\s*\{|" + SYNTHETIC.pattern, re.I)

    def conversation(self, limit: int = 6, now: Optional[float] = None,
                     max_age_s: float = RECENT_S) -> List[Tuple[float, str, str]]:
        """Recent real turns between Leon and his owner, (ts, role, text), oldest first."""
        now = time.time() if now is None else now
        with self._lock:
            fresh = self._convo_at and now - self._convo_at < self.CONVO_TTL
            rows = self._convo if fresh else None
        if rows is None:
            rows = []
            conn = None
            try:
                conn = self._ro("knowledge.db")
                if conn is not None:
                    raw = conn.execute("SELECT ts, role, content, model FROM conversation_history "
                                       "ORDER BY id DESC LIMIT 80").fetchall()
                    for ts, role, content, model in raw:
                        text = _plain(content)
                        if not text or self._SYNTHETIC.search(text) or not isinstance(ts, (int, float)):
                            continue
                        if role == "assistant" and (model or "") in self._REPLY_MODELS_SKIP:
                            continue
                        if role not in ("user", "assistant"):
                            continue
                        rows.append((float(ts), role, text))
                    rows.reverse()
            except Exception:
                rows = []
            finally:
                if conn is not None:
                    conn.close()
            with self._lock:
                self._convo, self._convo_at = rows, now
        rows = [r for r in rows if now - r[0] <= max_age_s]
        return rows[-limit:]

    # -- assembled blocks ---------------------------------------------------------------------
    def memories_block(self, now: Optional[float] = None, n_thoughts: int = 2,
                       lately_days: int = 2) -> str:
        """Dated memories for the prompt's INNER VOICE block (no recent thoughts)."""
        now = time.time() if now is None else now
        parts = []
        mem = self.remembered_thoughts(n_thoughts, now=now)
        if mem:
            parts.append("Older thoughts of yours, surfacing as memories (dated, not recent):\n" + "\n".join(
                f"  [memory, {_day_label(ts)}] {_clip(text, 240)}" for ts, text in mem))
        lately = self.lately(days=lately_days, max_claims=2,
                             today=date.fromtimestamp(now))
        if lately:
            parts.append("Your last filed days (life chapters):\n" + "\n".join(lately))
        return "\n".join(parts)

    def for_inner_voice(self, recent: Sequence = (), now: Optional[float] = None) -> str:
        """Continuity context for one inner-voice tick."""
        now = time.time() if now is None else now
        parts = []
        convo = self.conversation(limit=4, now=now)
        if convo:
            who = _owner()
            lines = []
            for ts, role, text in convo:
                speaker = who if role == "user" else "You"
                lines.append(f"  [{_ago(now - ts)}] {speaker}: {_clip(text, 200 if role == 'user' else 150)}")
            parts.append(f"Lately with {who}:\n" + "\n".join(lines))
        if recent:
            parts.append("Your own last thoughts (don't just repeat them):\n"
                         + "\n".join(format_recent(recent, now=now, chars=200)))
        lately = self.lately(days=2, max_claims=2, today=date.fromtimestamp(now))
        if lately:
            parts.append("Your last filed days:\n" + "\n".join(lately))
        older = self.older_chapter(now=now)
        mem = self.remembered_thoughts(1, now=now)
        if older or mem:
            lines = list(older)
            lines += [f"  [a thought you had on {_day_label(ts)}] {_clip(text, 200)}" for ts, text in mem]
            parts.append("Something from further back in your life:\n" + "\n".join(lines))
        return "\n\n".join(parts)


def _owner() -> str:
    try:
        from brain.identity import user_name
        name = (user_name() or "").strip()
        if name:
            return name
    except Exception:
        pass
    return "your owner"


def _plain(content: str) -> str:
    """Conversation text without tool-call blocks."""
    if not content:
        return ""
    if content.startswith("__BLOCKS__"):
        try:
            blocks = json.loads(content[len("__BLOCKS__"):])
            content = " ".join(b.get("text", "") for b in blocks
                               if isinstance(b, dict) and b.get("type") == "text")
        except Exception:
            return ""
    return " ".join(content.split())


_shared: Optional[Continuity] = None
_shared_lock = threading.Lock()


def shared() -> Continuity:
    global _shared
    with _shared_lock:
        if _shared is None:
            _shared = Continuity()
        return _shared
