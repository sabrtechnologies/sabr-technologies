#!/usr/bin/env python3
"""Crash / restart-loop detection for an INSTALLED SI on a customer machine.

WHY THIS EXISTS
---------------
sabr_installer.py's Installer.run() already refuses to print "ready" without
proof the SI answered (see the long comment at "DO NOT SAY 'READY' WITHOUT
LOOKING"). That check runs for ~90 seconds, once, at install time. It cannot
see the failure mode that actually costs us customers: an SI that comes up,
answers, and then dies — restarting forever behind a supervisor that hides it.

Every platform supervises the SI, and every one of them hides a crash loop:

  * Linux    `Restart=on-failure` / `RestartSec=5` (installer ~line 3445)
  * macOS    launchd `KeepAlive` + `ThrottleInterval: 10` (~line 3561)
  * Windows  the `:loop` in sabr_si_run.bat with 5→300s backoff (~line 3620)

Each of those restarts the SI silently. From the owner's side the product is
"slow" or "sometimes not there". From ours it is invisible: no ticket, no log,
no signal. The Windows runner in particular keeps its backoff counter in a
`set DELAY=` shell variable that dies with the batch process, so not even the
machine remembers how many times it looped.

WHAT THIS MODULE DOES
---------------------
Keeps a small, bounded, PII-free JSON watchdog file next to brain_state and
turns it into a one-word verdict:

    healthy | restart_loop | fatal_boot_error | unknown

Two independent sources, deliberately:

  1. The BOOT RING — the SI records its own boots and (separately) the moment
     it became healthy. This is the only source that works on all three
     platforms, and the only one that can tell "restarted 9 times" apart from
     "restarted 9 times and each one worked fine".
  2. The SERVICE MANAGER — systemd's NRestarts and launchd's LastExitStatus.
     Corroboration, and the one source that survives a brain_state wipe.

DESIGN RULES (all of these are load-bearing)
--------------------------------------------
* STDLIB ONLY, no imports from the rest of the brain. This runs at the very
  start of boot, before anything is known to work, and an import error here
  would itself become the crash it is supposed to report.
* EVERY PUBLIC FUNCTION SWALLOWS ITS OWN ERRORS. A watchdog that can raise is
  a watchdog that can kill the process it watches. Failure returns a verdict
  of "unknown", never an exception.
* NO PII, EVER. The file holds timestamps, counters, an exception CLASS name
  and a version string. No paths, no messages, no tracebacks, no SI name, no
  owner, no token. The installer phones this file's contents home verbatim
  (see sabr_installer._crash_signal), so anything added here goes to a server.
* BOUNDED. MAX_BOOTS entries, hard-capped. This file is written on a path that
  by definition may be executing thousands of times a day.

NOT WIRED. Nothing calls record_boot() yet — see INTEGRATION POINTS at the
bottom of this file for the exact three call sites.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import time
from typing import Any, Dict, List, Optional

# ── Tunables ──────────────────────────────────────────────────────────

#: Filename inside brain_state/. The installer reads this by NAME as pure
#: data (json.load) and never imports this module — the frozen installer
#: deliberately executes no code from the payload it downloads, which is the
#: same rule the live-install streamer states about the server. Renaming this
#: constant therefore breaks a cross-file contract; grep for it there too.
WATCHDOG_FILENAME = "boot-watchdog.json"

#: How far back a "restart loop" is measured. 10 minutes is chosen against
#: the supervisors above: Linux restarts every 5s (120 boots/window), macOS
#: throttles to 10s (60), and Windows backs off 5→300s, which still fits
#: 4 boots into 10 minutes before the cap. So the threshold below is
#: reachable on the SLOWEST platform, not just the fastest.
LOOP_WINDOW_S = 600

#: Boots inside LOOP_WINDOW_S that make it a loop. Four, not two: a customer
#: legitimately rebooting, then correcting a setting, then restarting the SI
#: is three boots in a few minutes and must not page anyone.
LOOP_THRESHOLD = 4

#: A boot that stayed up this long is evidence the install works. Used to
#: decide whether a boot ring full of restarts is a loop or just uptime.
#: Matches the spirit of the Windows runner's own `if !RAN! GEQ 60` backoff
#: reset, one notch more conservative.
HEALTHY_UPTIME_S = 120

#: Hard cap on ring size. A crash loop writes one entry per restart.
MAX_BOOTS = 40

#: Anything longer is a bug or an attack, not an exception class name.
_CLASS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]{0,63}$")

VERDICT_HEALTHY = "healthy"
VERDICT_LOOP = "restart_loop"
VERDICT_FATAL = "fatal_boot_error"
VERDICT_UNKNOWN = "unknown"

#: The only verdicts that ever leave this module. The telemetry client
#: validates against this exact tuple before sending, so a future verdict
#: added here without adding it there is dropped, not leaked.
VERDICTS = (VERDICT_HEALTHY, VERDICT_LOOP, VERDICT_FATAL, VERDICT_UNKNOWN)


# ── Paths ─────────────────────────────────────────────────────────────

def _default_root() -> str:
    """The install root: the parent of brain/, i.e. where run.py lives."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def watchdog_path(install_root: Optional[str] = None) -> str:
    """Absolute path of the watchdog file. Creates brain_state/ if needed.

    Lives INSIDE brain_state/ on purpose: a snapshot/restore round trip
    (brain/state_backup.py) then carries the crash history with the state it
    describes, and an uninstall --purge removes it along with everything else
    about the customer.
    """
    root = install_root or _default_root()
    state = os.path.join(root, "brain_state")
    try:
        os.makedirs(state, exist_ok=True)
    except OSError:
        pass
    return os.path.join(state, WATCHDOG_FILENAME)


# ── Read / write (never raise) ────────────────────────────────────────

def _blank() -> Dict[str, Any]:
    return {"schema": 1, "boots": [], "restarts": None, "version": ""}


def _load(path: str) -> Dict[str, Any]:
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return _blank()
    if not isinstance(data, dict):
        return _blank()
    boots = data.get("boots")
    if not isinstance(boots, list):
        data["boots"] = []
    else:
        # Trust nothing that came off disk: a truncated write (power cut mid
        # crash-loop is EXACTLY when that happens) can leave half an object.
        data["boots"] = [b for b in boots if isinstance(b, dict)][-MAX_BOOTS:]
    return data


def _save(path: str, data: Dict[str, Any]) -> bool:
    """Atomic-ish write. Returns success; never raises.

    Temp-then-replace because the writer here is, by construction, a process
    that is about to crash. A half-written watchdog file that json.load then
    rejects would erase the very history that proves the loop is happening.
    """
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, separators=(",", ":"))
        os.replace(tmp, path)
        return True
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        return False


def _safe_class(value: Any) -> str:
    """An exception class NAME, or "". Never a message.

    Accepts an exception instance or a string. `str(exc)` is deliberately
    unreachable from here — an exception message routinely contains the file
    path that failed, which is a customer's home directory and username.
    """
    if value is None:
        return ""
    name = type(value).__name__ if isinstance(value, BaseException) else str(value)
    name = name.strip()
    return name if _CLASS_RE.match(name) else ""


# ── Recording (called by the SI itself) ───────────────────────────────

def record_boot(install_root: Optional[str] = None,
                version: str = "",
                now: Optional[float] = None) -> Dict[str, Any]:
    """Append "a boot started". Call as early in startup as possible.

    Earlier is strictly better: the whole point is to catch a boot that dies
    before anything else in the process gets a chance to report.
    """
    try:
        path = watchdog_path(install_root)
        data = _load(path)
        data["boots"].append({"t": float(now if now is not None else time.time()),
                              "ok": False, "err": ""})
        data["boots"] = data["boots"][-MAX_BOOTS:]
        if version:
            data["version"] = str(version)[:40]
        _save(path, data)
        return data
    except Exception:
        return _blank()


def record_healthy(install_root: Optional[str] = None,
                   now: Optional[float] = None) -> Dict[str, Any]:
    """Mark the newest boot as one that actually came up.

    This is the flag that stops a busy-but-fine machine from reading as a
    crash loop. Without it, a customer who reboots their laptop four times in
    an afternoon is indistinguishable from an SI dying on import.
    """
    try:
        path = watchdog_path(install_root)
        data = _load(path)
        if data["boots"]:
            data["boots"][-1]["ok"] = True
            data["boots"][-1]["ok_t"] = float(now if now is not None else time.time())
            _save(path, data)
        return data
    except Exception:
        return _blank()


def record_fatal(error: Any,
                 install_root: Optional[str] = None) -> Dict[str, Any]:
    """Record that this boot died, and of what CLASS. No message is stored."""
    try:
        path = watchdog_path(install_root)
        data = _load(path)
        if not data["boots"]:
            data["boots"].append({"t": time.time(), "ok": False, "err": ""})
        data["boots"][-1]["err"] = _safe_class(error)
        _save(path, data)
        return data
    except Exception:
        return _blank()


# ── Service-manager counters (corroboration) ──────────────────────────

def _systemd_restarts() -> Optional[int]:
    """systemd's own count of how often it has restarted the unit."""
    try:
        r = subprocess.run(
            ["systemctl", "--user", "show", "sabr-si.service",
             "--property=NRestarts", "--value"],
            capture_output=True, text=True, timeout=10, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    out = (r.stdout or "").strip()
    return int(out) if out.isdigit() else None


def _launchd_signal() -> Optional[Dict[str, int]]:
    """launchd's view of com.sabr.si: last exit status.

    launchd exposes no restart counter, so this can prove "it died badly"
    but never "it died badly ten times" — which is precisely why the boot
    ring above is the primary source and this is only corroboration.
    """
    try:
        r = subprocess.run(["launchctl", "list", "com.sabr.si"],
                           capture_output=True, text=True, timeout=10,
                           check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    if r.returncode != 0:
        return None
    out = {}
    for key, field in (("LastExitStatus", "last_exit"), ("PID", "pid")):
        m = re.search(r'"%s"\s*=\s*(-?\d+)' % key, r.stdout or "")
        if m:
            out[field] = int(m.group(1))
    return out or None


def service_restarts(platform_name: str = "") -> Optional[int]:
    """Restart count from the OS supervisor, or None where it has none.

    platform_name is injectable so the test suite can exercise the Linux
    branch on any runner instead of only where it happens to be running.
    """
    name = (platform_name or os.name).lower()
    try:
        if "linux" in name or name == "posix":
            n = _systemd_restarts()
            if n is not None:
                return n
        if "darwin" in name or "mac" in name:
            sig = _launchd_signal()
            if sig and sig.get("last_exit"):
                return None  # died, but launchd cannot say how many times
    except Exception:
        return None
    return None


# ── The verdict ───────────────────────────────────────────────────────

def detect(install_root: Optional[str] = None,
           now: Optional[float] = None,
           restarts: Optional[int] = None) -> Dict[str, Any]:
    """Read the watchdog file and return a PII-free crash signal.

    Return shape (this IS the wire format — see sabr_installer._crash_signal):

        {"verdict": one of VERDICTS,
         "boots_in_window": int,
         "window_s": int,
         "failed_boots": int,
         "restarts": int|None,        # from the OS supervisor, when it has one
         "last_error_class": str,     # "" when unknown
         "version": str}

    Precedence, in order, and why:

      1. restart_loop beats everything. A machine looping right now is the
         emergency, and the class of whatever it died of last is noise next
         to the fact that it will die again in five seconds.
      2. fatal_boot_error — the newest boot has an error class and never
         reached healthy.
      3. healthy — the newest boot reached healthy.
      4. unknown — no file, no boots, or anything unreadable. Deliberately
         NOT "healthy": absence of evidence is not evidence of health, and a
         wiped brain_state must not report a green light it cannot see.
    """
    out: Dict[str, Any] = {
        "verdict": VERDICT_UNKNOWN, "boots_in_window": 0,
        "window_s": LOOP_WINDOW_S, "failed_boots": 0,
        "restarts": None, "last_error_class": "", "version": "",
    }
    try:
        now = float(now if now is not None else time.time())
        data = _load(watchdog_path(install_root))
        boots: List[Dict[str, Any]] = data.get("boots") or []
        out["version"] = str(data.get("version") or "")[:40]
        out["restarts"] = restarts if restarts is not None else data.get("restarts")
        if not isinstance(out["restarts"], int):
            out["restarts"] = None

        recent = [b for b in boots
                  if isinstance(b.get("t"), (int, float))
                  and now - float(b["t"]) <= LOOP_WINDOW_S]
        failed = [b for b in recent if not b.get("ok")]
        out["boots_in_window"] = len(recent)
        out["failed_boots"] = len(failed)

        last = boots[-1] if boots else None
        if last:
            out["last_error_class"] = _safe_class(last.get("err") or "") or ""

        # 1 — a loop. Two ways in: our own ring, or the supervisor's counter
        # (which survives a brain_state that was just wiped and refilled).
        looping = len(failed) >= LOOP_THRESHOLD
        if out["restarts"] is not None and out["restarts"] >= LOOP_THRESHOLD:
            looping = True
        if looping:
            out["verdict"] = VERDICT_LOOP
            return out

        if not last:
            return out                      # 4 — unknown

        # 2 — died, and stayed dead.
        if out["last_error_class"] and not last.get("ok"):
            out["verdict"] = VERDICT_FATAL
            return out

        # 3 — came up and stayed up.
        if last.get("ok"):
            out["verdict"] = VERDICT_HEALTHY
        return out
    except Exception:
        return out


def write_signal(install_root: Optional[str] = None,
                 now: Optional[float] = None,
                 platform_name: str = "") -> Dict[str, Any]:
    """Merge the supervisor counter into the file, then persist the verdict.

    THIS is what makes the installer's job pure data: after this runs, the
    watchdog JSON contains a ready-made `signal` object, so the installer
    reads and forwards it without needing systemctl, launchctl, or any
    knowledge of the rules above.
    """
    try:
        path = watchdog_path(install_root)
        data = _load(path)
        n = service_restarts(platform_name)
        if n is not None:
            data["restarts"] = n
        sig = detect(install_root, now=now, restarts=data.get("restarts"))
        data["signal"] = sig
        data["signal_t"] = float(now if now is not None else time.time())
        _save(path, data)
        return sig
    except Exception:
        return detect(install_root, now=now)


def read_signal(install_root: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """The signal as the INSTALLER sees it: parsed JSON, no code executed.

    Returns None when there is nothing to report (fresh box, no payload yet,
    unreadable file) so a caller can tell "no crash" apart from "no data".
    """
    try:
        data = _load(watchdog_path(install_root))
        sig = data.get("signal")
        if isinstance(sig, dict) and sig.get("verdict") in VERDICTS:
            return sig
        if data.get("boots"):
            return detect(install_root)
        return None
    except Exception:
        return None


# ── INTEGRATION POINTS (documented, deliberately NOT wired) ───────────
#
# Three call sites, none of which this branch touches. Each is one line and
# each is independently useful — wiring only #1 already gives restart-loop
# detection; #2 is what stops false positives; #3 sharpens the diagnosis.
#
#   1. BOOT.  run.py, immediately after the imports at the top of main(),
#      before any subsystem is constructed:
#
#          from brain import crash_watch
#          crash_watch.record_boot(version=os.environ.get("SABR_VERSION", ""))
#
#      Earliest possible is the point: a boot that dies during subsystem
#      construction must already be on the ring by then.
#
#   2. HEALTHY.  run.py, at the point the HTTP server is actually serving —
#      the same moment /api/version starts answering, which is what
#      sabr_installer._is_our_si() probes:
#
#          crash_watch.record_healthy()
#
#      Without this every boot looks failed and a laptop that suspends and
#      resumes four times reads as a crash loop.
#
#   3. FATAL.  run.py's top-level `except BaseException` (or the systemd/
#      launchd/bat supervisor's last gasp):
#
#          crash_watch.record_fatal(exc)
#
#   4. PUBLISH.  brain/license_heartbeat.py already runs on a timer and
#      already talks to sabrtechnologies.com, which makes it the natural
#      carrier for a live crash signal from an SI that is currently
#      looping — the installer can only report a crash the NEXT time
#      someone runs it. That file is owned by another agent, so nothing
#      here edits it. The integration is one line in its per-beat payload
#      builder:
#
#          payload["crash"] = crash_watch.write_signal()
#
#      write_signal(), not detect(): it refreshes the supervisor counter and
#      persists the verdict, which is also what leaves the file ready for
#      the installer. The return value is already PII-free and already
#      shaped like the telemetry `crash` object, so the heartbeat needs no
#      sanitising of its own.
