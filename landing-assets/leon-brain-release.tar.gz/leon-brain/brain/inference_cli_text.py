"""Verified Claude subscription text lane; stdlib, no history or action authority.

Only a caller-supplied identity/prompt is sent. No resume, persistent session,
tools, MCP, permission bypass, retries, alternate provider or API fallback exists.
POSIX process groups are required; unsupported platforms fail before spawning.
"""
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import selectors
import signal
import subprocess
import threading
import time
import uuid

from .inference_cancel import UnsupportedInferencePolicy

MINIMUM_VERSION = (2, 1, 280)
VERSION_PATTERN = r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)"
REQUIRED_FLAGS = ("--tools", "--safe-mode", "--strict-mcp-config", "--mcp-config",
                  "--no-session-persistence", "--permission-prompts", "--permission-mode",
                  "--disable-slash-commands", "--no-chrome", "--system-prompt", "--session-id",
                  "--model", "--effort", "--output-format", "--include-partial-messages", "--verbose")
TOOL_TYPES = frozenset({"tool_use", "tool_result", "server_tool_use", "server_tool_result",
                        "mcp_tool_use", "mcp_tool_result", "input_json_delta", "permission_request"})


class CliTextError(RuntimeError):
    """Sanitized transport failure: contains no provider stderr or prompt text."""


@dataclass(frozen=True)
class CliContract:
    executable: str
    stamp: tuple
    version: str
    help_sha256: str


@dataclass(frozen=True)
class TextRequest:
    prompt: str
    system_prompt: str
    model: str
    effort: str
    cwd: str
    env: dict
    subscription_auth_verified: bool = False
    conversation_id: str = ""
    session_id: str | None = None
    deadline_s: float = 60.0
    idle_s: float = 30.0
    max_output_bytes: int = 2 * 1024 * 1024


def _stamp(executable):
    p = Path(executable)
    if not p.is_absolute() or not p.is_file():
        raise UnsupportedInferencePolicy("explicit installed CLI executable required")
    st = p.stat()
    return (str(p.resolve()), st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)


def _subscription_env(source):
    env = dict(source)
    for key in ("ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_BASE_URL", "CLAUDE_CODE_USE_BEDROCK",
                "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY", "CLAUDE_CODE_USE_CCR",
                "CLAUDE_CODE_SIMPLE", "ANTHROPIC_CUSTOM_HEADERS"):
        if env.get(key) not in (None, "", "0", "false"):
            raise UnsupportedInferencePolicy("non-subscription provider configuration refused")
    # Match the existing CLI path: a stale API key must not override Max OAuth.
    env.pop("ANTHROPIC_API_KEY", None)
    env["CLAUDE_CODE_SAFE_MODE"] = "1"
    env.setdefault("LEON_BRIDGE_ROLE", "daemon")   # narration, never Dean's chat preference
    return env


def _number(value, maximum):
    return type(value) in (int, float) and math.isfinite(value) and 0 < value <= maximum


def _kill_group(proc):
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def _chunks(argv, payload, *, env, cwd, cancel_token=None, deadline_s=60, idle_s=30,
            output_cap=2 * 1024 * 1024, popen=subprocess.Popen, on_spawn=None, on_exit=None):
    """Own one process/session and bound I/O even while a consumer is paused."""
    if os.name != "posix":
        raise UnsupportedInferencePolicy("verified CLI process ownership requires POSIX")
    if cancel_token is not None and cancel_token.is_set():
        return
    if not _number(deadline_s, 600) or not _number(idle_s, 600):
        raise ValueError("invalid CLI deadline")
    proc = popen(argv, cwd=cwd, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                 stderr=subprocess.PIPE, start_new_session=True, bufsize=0)
    stop, mu = threading.Event(), threading.Lock()
    reason, active = [None], [True]
    started, last = time.monotonic(), [time.monotonic()]
    remove_callback = lambda: None
    selector, watchdog = None, None

    def interrupt(why):
        # Synchronous token callbacks only signal/kill; joining happens below.
        with mu:
            if active[0] and reason[0] is None:
                reason[0] = why
                _kill_group(proc)

    def watch():
        while not stop.wait(0.025):
            now = time.monotonic()
            if now - started >= deadline_s:
                interrupt("deadline")
                return
            if now - last[0] >= idle_s:
                interrupt("idle_timeout")
                return

    try:
        if cancel_token is not None:
            remove_callback = cancel_token.add_callback(lambda _: interrupt("cancelled"))
        watchdog = threading.Thread(target=watch, name="leon-cli-text-deadline", daemon=True)
        watchdog.start()
        if on_spawn is not None:
            on_spawn(proc)
        selector = selectors.DefaultSelector()
        for stream, tag in ((proc.stdout, "out"), (proc.stderr, "err")):
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, tag)
        position = 0
        if payload:
            os.set_blocking(proc.stdin.fileno(), False)
            selector.register(proc.stdin, selectors.EVENT_WRITE, "in")
        else:
            proc.stdin.close()
        out_size = err_size = 0
        while selector.get_map():
            if cancel_token is not None and cancel_token.is_set():
                interrupt("cancelled")
            if reason[0]:
                if reason[0] == "cancelled":
                    return
                raise CliTextError(reason[0])
            for key, _ in selector.select(0.05):
                if key.data == "in":
                    try:
                        position += os.write(key.fd, payload[position:position + 16384])
                    except BlockingIOError:
                        continue
                    except BrokenPipeError:
                        position = len(payload)
                    if position >= len(payload):
                        selector.unregister(key.fileobj)
                        key.fileobj.close()
                    continue
                try:
                    chunk = os.read(key.fd, 65536)
                except BlockingIOError:
                    continue
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                if key.data == "err":
                    err_size += len(chunk)
                    if err_size > 262144:
                        raise CliTextError("stderr_limit")
                    continue  # Never expose auth/prompt fragments from stderr.
                last[0] = time.monotonic()
                out_size += len(chunk)
                if out_size > output_cap:
                    raise CliTextError("stdout_limit")
                yield chunk
        while proc.poll() is None:
            if cancel_token is not None and cancel_token.is_set():
                interrupt("cancelled")
            if reason[0]:
                if reason[0] == "cancelled":
                    return
                raise CliTextError(reason[0])
            stop.wait(0.025)
        if reason[0] == "cancelled":
            return
        if reason[0]:
            raise CliTextError(reason[0])
        if proc.returncode != 0:
            raise CliTextError("cli_exit_%d" % proc.returncode)
    finally:
        remove_callback()
        stop.set()
        # Kill the entire owned group even after the direct child exited, so a
        # descendant retaining stdout cannot survive a consumer close/failure.
        with mu:
            if active[0]:
                _kill_group(proc)
                active[0] = False
        try:
            proc.wait(timeout=2)
        finally:
            if selector is not None:
                selector.close()
            for stream in (proc.stdin, proc.stdout, proc.stderr):
                stream.close()
            if watchdog is not None:
                watchdog.join(timeout=1)
            if on_exit is not None:
                on_exit(proc)


def supported_version(version):
    """Strict numeric release version; capabilities are checked separately."""
    match = re.fullmatch(VERSION_PATTERN, version) if isinstance(version, str) else None
    return bool(match and tuple(map(int, match.groups())) >= MINIMUM_VERSION)


def verify_cli(executable, *, env, cwd, popen=subprocess.Popen):
    """Read-only --help/--version probe. No model request, auth mutation or cache."""
    before = _stamp(executable)
    results = []
    for flag in ("--help", "--version"):
        output = b"".join(_chunks([str(executable), flag], b"", env=_subscription_env(env),
            cwd=cwd, deadline_s=10, idle_s=10, output_cap=262144, popen=popen))
        results.append(output.decode("utf-8", "strict"))
    help_text, version_text = results
    banner = re.fullmatch(r"(" + VERSION_PATTERN + r")(?: \(Claude Code\))?", version_text.strip())
    version = banner.group(1) if banner else ""
    if (not supported_version(version) or any(flag not in help_text for flag in REQUIRED_FLAGS)
            or 'Use "" to disable all' not in help_text or "Auth, model" not in help_text):
        raise UnsupportedInferencePolicy("installed CLI no-tools contract is unverified")
    if _stamp(executable) != before:
        raise UnsupportedInferencePolicy("CLI changed during verification")
    return CliContract(str(executable), before, version, hashlib.sha256(help_text.encode()).hexdigest())


def build_argv(request, contract):
    if request.subscription_auth_verified is not True:
        raise UnsupportedInferencePolicy("verified subscription auth is required")
    if not supported_version(contract.version) or _stamp(contract.executable) != contract.stamp:
        raise UnsupportedInferencePolicy("CLI changed; reverify its contract")
    if not isinstance(request.prompt, str) or not request.prompt or len(request.prompt.encode()) > 2 * 1024 * 1024:
        raise ValueError("prompt must be nonempty and at most 2 MiB")
    if not isinstance(request.system_prompt, str) or not request.system_prompt or len(request.system_prompt.encode()) > 65536:
        raise ValueError("explicit identity prompt required (64 KiB maximum)")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}", request.model):
        raise ValueError("invalid explicit model")
    if request.effort not in {"low", "medium", "high", "xhigh", "max"}:
        raise ValueError("invalid explicit effort")
    if not Path(request.cwd).is_absolute() or not Path(request.cwd).is_dir():
        raise ValueError("explicit working directory required")
    if type(request.max_output_bytes) is not int or not 1024 <= request.max_output_bytes <= 8 * 1024 * 1024:
        raise ValueError("invalid output cap")
    argv = [contract.executable, "--print", "--safe-mode", "--tools", "",
            "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}',
            "--disable-slash-commands", "--no-chrome", "--permission-mode", "dontAsk",
            "--permission-prompts", "none", "--no-session-persistence",
            "--system-prompt", request.system_prompt, "--model", request.model,
            "--effort", request.effort, "--output-format", "stream-json",
            "--include-partial-messages", "--verbose"]
    if request.session_id is not None:
        session_id = str(uuid.UUID(request.session_id))
        argv += ["--session-id", session_id]
    return argv


def _reject_tools(value):
    if isinstance(value, dict):
        kind = value.get("type")
        if kind is not None and not isinstance(kind, str):
            raise UnsupportedInferencePolicy("invalid CLI event discriminator")
        if kind in TOOL_TYPES or (isinstance(kind, str) and "tool" in kind):
            raise UnsupportedInferencePolicy("CLI emitted a tool or permission event")
        if value.get("stop_reason") == "tool_use":
            raise UnsupportedInferencePolicy("CLI requested a tool continuation")
        for item in value.values():
            _reject_tools(item)
    elif isinstance(value, list):
        for item in value:
            _reject_tools(item)


def stream_text(request, contract, *, cancel_token=None, popen=subprocess.Popen,
                on_spawn=None, on_exit=None):
    """Yield model/delta/done dictionaries. Caller alone owns history and recorder.

    Cancellation yields no done. Failures raise sanitized exceptions without a
    retry/fallback. done requires successful terminal JSON AND clean process exit.
    Always close the generator if consuming stops before exhaustion.
    """
    if cancel_token is not None and cancel_token.is_set():
        return
    argv = build_argv(request, contract)
    chunks = _chunks(argv, request.prompt.encode(), env=_subscription_env(request.env), cwd=request.cwd,
        cancel_token=cancel_token, deadline_s=request.deadline_s, idle_s=request.idle_s,
        output_cap=request.max_output_bytes, popen=popen, on_spawn=on_spawn, on_exit=on_exit)
    pending, pieces, terminal, initialized = b"", [], None, False
    try:
        for chunk in chunks:
            pending += chunk
            if len(pending) > 524288:
                raise CliTextError("record_limit")
            while b"\n" in pending:
                raw, pending = pending.split(b"\n", 1)
                if not raw.strip():
                    continue
                try:
                    obj = json.loads(raw)
                except (ValueError, UnicodeError, RecursionError):
                    raise CliTextError("malformed_cli_record") from None
                if not isinstance(obj, dict):
                    raise CliTextError("invalid_cli_record")
                _reject_tools(obj)
                kind = obj.get("type")
                if kind == "system" and obj.get("subtype") == "init":
                    if initialized or obj.get("tools") != [] or obj.get("mcp_servers") != []:
                        raise UnsupportedInferencePolicy("CLI init did not confirm empty tools and MCP")
                    if obj.get("permissionMode") != "dontAsk":
                        raise UnsupportedInferencePolicy("CLI did not preserve the denying permission mode")
                    if obj.get("plugins") or obj.get("skills"):
                        raise UnsupportedInferencePolicy("CLI customizations remain enabled")
                    initialized = True
                    yield {"type": "model", "model": request.model, "tier": "text-only-cli",
                           "conversation_id": request.conversation_id}
                    continue
                if not initialized:
                    raise UnsupportedInferencePolicy("CLI content arrived before verified init")
                if kind == "system" and obj.get("subtype") != "status":
                    raise UnsupportedInferencePolicy("unsupported CLI system event")
                if terminal is not None:
                    raise CliTextError("record_after_terminal")
                text = None
                if kind == "stream_event":
                    event = obj.get("event", {})
                    delta = event.get("delta", {})
                    if event.get("type") == "content_block_delta" and delta.get("type") == "text_delta":
                        text = delta.get("text")
                elif kind == "assistant" and not pieces:
                    content = obj.get("message", {}).get("content", [])
                    if not isinstance(content, list):
                        raise CliTextError("invalid_assistant_content")
                    text = "".join(c.get("text", "") for c in content if c.get("type") == "text")
                elif kind == "result":
                    if obj.get("subtype") != "success" or obj.get("is_error") is not False:
                        raise CliTextError("unsuccessful_cli_result")
                    if obj.get("permission_denials"):
                        raise UnsupportedInferencePolicy("CLI permission denial in text lane")
                    terminal = obj.get("result")
                    if not isinstance(terminal, str) or not terminal.strip():
                        raise CliTextError("empty_cli_result")
                elif kind not in {"assistant", "system", "rate_limit_event"}:
                    raise UnsupportedInferencePolicy("unsupported CLI stream event")
                if text:
                    if not isinstance(text, str):
                        raise CliTextError("invalid_text_delta")
                    pieces.append(text)
                    if cancel_token is not None and cancel_token.is_set():
                        return
                    yield {"type": "delta", "text": text}
        if cancel_token is not None and cancel_token.is_set():
            return
        if pending.strip() or terminal is None:
            raise CliTextError("incomplete_cli_result")
        streamed = "".join(pieces)
        if not terminal.startswith(streamed):
            raise CliTextError("inconsistent_cli_result")
        if terminal[len(streamed):]:
            yield {"type": "delta", "text": terminal[len(streamed):]}
        if cancel_token is not None and cancel_token.is_set():
            return
        yield {"type": "done", "full_text": terminal, "conversation_id": request.conversation_id}
    finally:
        chunks.close()
