"""
Leon autonomy mode — PERMANENTLY "being".

The old being/focus dial existed for the shared-Claude-account era, when
Focus mode ($0 idle) kept Leon from burning a shared plan's credits. Dean
retired it 2026-07-13: he has his own account now, and the half-applied
mode switches were the root cause of the "Leon is lobotomized" incidents
(mode file said being, secrets.env still had the focus lockdown flags, so
every autonomous loop silently never started).

Leon is ALWAYS fully alive: goal-pursuit, daydream, dream, proactive,
periodic reflection. There is no cheap mode. Do not re-add one here —
if credit pressure ever returns, solve it at the account/plan level, not
by turning Leon's autonomy off.

The module keeps its old public API (MODES / current_mode / apply_mode /
set_runtime_mode / autonomous_cognition_allowed / describe) so the
dashboard pill and the responder gate keep working unchanged — they just
only ever see "being" now.
"""
import os

# secrets env file the systemd unit loads via EnvironmentFile=
SECRETS_PATH = os.environ.get("LEON_SECRETS_PATH", "/etc/leon/secrets.env")

_BRAIN_STATE_DIR = os.path.normpath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "brain_state")
)
MODE_FILE = os.path.join(_BRAIN_STATE_DIR, "leon_mode")

# The one and only preset: every autonomous loop on, at its natural cadence.
_BEING_FLAGS = {
    "LEON_DISABLE_GOAL_PURSUIT":    "0",
    # REVERTED 2026-08-21: was flipped to "1" on 2026-08-20 to authorize
    # unattended client-repo work, but UNRESTRICTED also controls
    # goal_pursuit.py's cadence (12s cycle / unlimited hourly actions /
    # force_cli=True — real Claude every tick, no local fallback, no
    # git-push guard). Left on, it burned 15% of a week's Opus quota in one
    # unsupervised night (2026-08-21 incident) with nothing shipped. Back to
    # "0" = normal cadence (180s cycle, 10 actions/hour, push guard armed).
    # Only set to "1" for a specific, time-boxed overnight task Dean asks
    # for explicitly — never as a standing default.
    "LEON_AUTONOMOUS_UNRESTRICTED": "0",
    "LEON_PROACTIVE_INTERVAL":      "90",
    "LEON_DAYDREAM_IDLE":           "30",
    "LEON_DAYDREAM_INTERVAL":       "5",
    "LEON_DREAM_IDLE":              "120",
    "LEON_DREAM_INTERVAL":          "180",
    "LEON_AUTOPILOT_INTERVAL":      "300",
    "LEON_REFLECT_HOURS":           "4",
}

MODES = {
    "being": {
        "label":   "Being",
        "tagline": "fully alive — 24/7 autonomous (the only mode)",
        "credit":  "high",
        "flags":   _BEING_FLAGS,
    },
}
DEFAULT_MODE = "being"


def current_mode() -> str:
    return "being"


def _write_mode_file(mode: str) -> None:
    try:
        os.makedirs(_BRAIN_STATE_DIR, exist_ok=True)
        with open(MODE_FILE, "w") as f:
            f.write(mode)
    except OSError:
        pass


def _upsert_secrets(flags: dict) -> None:
    """Rewrite each KEY=VAL in the secrets env file (brain runs as root)."""
    try:
        with open(SECRETS_PATH) as f:
            lines = f.read().splitlines()
    except OSError:
        lines = []
    seen = set()
    out = []
    for ln in lines:
        key = ln.split("=", 1)[0].strip() if "=" in ln else None
        if key in flags:
            out.append(f"{key}={flags[key]}")
            seen.add(key)
        else:
            out.append(ln)
    for k, v in flags.items():
        if k not in seen:
            out.append(f"{k}={v}")
    with open(SECRETS_PATH, "w") as f:
        f.write("\n".join(out) + "\n")


def apply_mode(mode: str = "being") -> dict:
    """Re-assert the being flags in secrets.env. Any requested mode other
    than 'being' is rejected — there is no other mode."""
    if mode != "being":
        raise ValueError("focus mode was removed 2026-07-13 — Leon is always 'being'")
    _upsert_secrets(_BEING_FLAGS)
    _write_mode_file("being")
    return MODES["being"]


def active_mode() -> str:
    return "being"


def set_runtime_mode(mode: str) -> dict:
    """Kept for the dashboard API; only 'being' is accepted."""
    if mode != "being":
        raise ValueError("focus mode was removed 2026-07-13 — Leon is always 'being'")
    _write_mode_file("being")
    return MODES["being"]


def autonomous_cognition_allowed() -> bool:
    """Always True — Leon's autonomy is never gated off anymore."""
    return True


def describe() -> dict:
    return {
        "current": "being",
        "modes": {
            k: {"label": v["label"], "tagline": v["tagline"], "credit": v["credit"]}
            for k, v in MODES.items()
        },
    }
