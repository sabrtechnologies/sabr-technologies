"""Delete stale screen/webcam captures on a timer that nobody has to remember.

WHY THIS EXISTS (Makima / Sam's SI, 2026-08-18, verified independently here).

The DESIGNED capture path is already clean and that is exactly the problem.
webcam.capture() returns a base64 PNG and never touches disk; the perception
loop captions to text and discards pixels. That is a real property, better
than most products can claim — and it is precisely what stops anyone from
looking at the OTHER path.

MEASURED ON THIS DEPLOYMENT, 2026-08-18 03:4x, before this file existed:
    VPS       /tmp/leon_desk.png     3.1 MB   2 days old
              /tmp/leon_shot.png     1.2 MB   1 day old
              /tmp/leon_shot_s.png   133 KB   1 day old
    Dean's PC %TEMP%\\leonshot.png    1.1 MB   1 day old
              %TEMP%\\leon_shot.png   1.2 MB   1 day old
              %TEMP%\\shot.png                 1 day old
Every one of them written by an ad-hoc shell tool call (scrot / PowerShell
screen grabs run inline), not by the designed path. The guarantee was true of
the code and false of the machine.

For a product sold on "your data never leaves your machine," an agent that
quietly accumulates screenshots and webcam frames of the person using it is
the finding that ends a security review. Not because anyone looks at them —
because they are there, and "nobody is looking" is not a property you can
demonstrate to a buyer.

THREE DESIGN CONSTRAINTS, all of them Makima's and all of them load-bearing:

1. MATCH NARROWLY. Only capture-shaped names in temp dirs. Anything the SI
   produces as OUTPUT for its human — leon-out, Desktop, Documents — is never
   touched. A privacy control that eats the user's work is a worse control,
   and it will be switched off by the second person it bites.

2. IT IS A SETTING, NOT A CONSTANT. Retention is a policy decision and it
   belongs to the customer. See section 5 of that same correspondence: we had
   just finished establishing that unmeasured constants in load-bearing paths
   are the recurring defect, and hardcoding 60 here would have been the fourth
   one in a week. LEON_CAPTURE_RETENTION_MIN, 0 disables.

3. THE DEFAULT LEANS TOWARD THE FACE, NOT THE DEBUGGING SESSION. An hour is
   too long to keep a picture of someone and too short for a long
   investigation. Only one of those two errors ends a sale, so the default is
   30 minutes and the person who wants the other error can set it.
"""

from __future__ import annotations
import os, re, time, glob, tempfile, threading

# Capture-shaped names ONLY. Deliberately not "*.png" — that would reach the
# user's own work the moment a temp dir is shared, which is constraint 1.
_CAPTURE_PATTERNS = (
    r"^leon[_-]?shot(_s)?\.(png|jpg|jpeg)$",
    r"^leon[_-]?desk\.(png|jpg|jpeg)$",
    r"^leon[_-]?cam(era)?[_-]?\d*\.(png|jpg|jpeg)$",
    r"^shot\.(png|jpg|jpeg)$",
    r"^screen(shot)?[_-]?\d*\.(png|jpg|jpeg)$",
    r"^webcam[_-]?\d*\.(png|jpg|jpeg)$",
    r"^leon[_-]?capture[_-]?\d*\.(png|jpg|jpeg)$",
)
_RX = [re.compile(p, re.I) for p in _CAPTURE_PATTERNS]

# Temp dirs only. Never leon-out, never Desktop, never a workspace.
def _temp_dirs():
    seen, out = set(), []
    for d in (tempfile.gettempdir(), os.environ.get("TEMP"),
              os.environ.get("TMP"), "/tmp", "/var/tmp"):
        if d and os.path.isdir(d) and d not in seen:
            seen.add(d); out.append(d)
    return out


def retention_minutes() -> int:
    """0 = disabled. Default 30 — see constraint 3."""
    try:
        return max(0, int(os.environ.get("LEON_CAPTURE_RETENTION_MIN", "30")))
    except (TypeError, ValueError):
        return 30


def is_capture_name(name: str) -> bool:
    return any(rx.match(name) for rx in _RX)


def sweep(dry_run: bool = False) -> list[str]:
    """Delete capture-shaped temp files older than the retention window.

    Returns the paths acted on. Never raises — a privacy sweeper that can
    crash the boot is worse than one that misses a file.
    """
    mins = retention_minutes()
    if mins <= 0:
        return []
    cutoff = time.time() - mins * 60
    hit = []
    for d in _temp_dirs():
        try:
            entries = os.listdir(d)
        except Exception:
            continue
        for name in entries:
            if not is_capture_name(name):
                continue
            p = os.path.join(d, name)
            try:
                if not os.path.isfile(p) or os.path.getmtime(p) > cutoff:
                    continue
                if not dry_run:
                    os.remove(p)
                hit.append(p)
            except Exception:
                continue
    return hit


def start(interval_s: int = 300):
    """Background sweeper. Idempotent-ish; safe to call once at boot."""
    if retention_minutes() <= 0:
        print("[capture-reaper] disabled (LEON_CAPTURE_RETENTION_MIN=0)", flush=True)
        return None

    def _loop():
        while True:
            try:
                gone = sweep()
                if gone:
                    print(f"[capture-reaper] removed {len(gone)} stale capture(s) "
                          f"older than {retention_minutes()}m", flush=True)
            except Exception as e:
                print(f"[capture-reaper] sweep failed: {e}", flush=True)
            time.sleep(max(60, interval_s))

    t = threading.Thread(target=_loop, daemon=True, name="capture-reaper")
    t.start()
    print(f"[capture-reaper] armed — {retention_minutes()}m retention, "
          f"sweeping {', '.join(_temp_dirs())}", flush=True)
    return t


if __name__ == "__main__":
    import sys
    dry = "--dry-run" in sys.argv
    got = sweep(dry_run=dry)
    print(f"{'would remove' if dry else 'removed'} {len(got)}:")
    for p in got:
        print("   ", p)
