"""Read-only, reference-only SHADOW adapter over existing canonical owners.

No canonical constructors/writers, embeddings, identity edits or context text are
exposed. OFF returns before filesystem access. The sole worker owns optional
sidecar construction and retrieval; the caller only submits/polls metadata.
"""
from collections import OrderedDict, deque
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import threading
import time
import uuid

from .memory_service import (AutobiographyAdapter, GoalsAdapter, MemoryService,
                             SourcePolicy, SQLiteAdapter)


@dataclass(frozen=True)
class MemoryReference:
    store: str
    record_id: str
    text_sha256: str
    source: str
    memory_type: str
    created_ts: float
    scores: tuple
    unverified: bool | None


@dataclass(frozen=True)
class MemoryProposal:
    request_id: str
    trace_id: str
    scope_key: str
    references: tuple
    observed_mono: float
    expires_mono: float
    status: str = "shadow_proposal"

    @property
    def authorizes_action(self):
        return False


_OWNERS = (("knowledge", ("claude_bridge", "knowledge"), "db_path"),
           ("episodes", ("cognition", "episodes"), "path"),
           ("graph", ("cognition", "graph"), "path"),
           ("skills", ("cognition", "skills"), "path"),
           ("autobiography", ("autobiography",), "_path"),
           ("goals", ("goal_system",), "_path"))


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def _file_stamp(path):
    """Include WAL changes; references are still rehydrated before cache reuse."""
    out = []
    for p in (path, Path(str(path) + "-wal")):
        try:
            s = p.stat()
            out.append((s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns))
        except FileNotFoundError:
            out.append(None)
    return tuple(out)


def _bindings(state):
    bindings, absent = [], []
    for name, attrs, path_attr in _OWNERS:
        owner = state
        for attr in attrs:
            owner = getattr(owner, attr, None)
        raw = getattr(owner, path_attr, None)
        if raw is None:
            absent.append(name)
            continue
        path = Path(raw).resolve()
        if not path.is_file():
            absent.append(name)
            continue
        bindings.append((name, path, id(owner), _file_stamp(path)))
    return tuple(bindings), tuple(absent)


def _policy_snapshot(policy, revision):
    if not isinstance(policy, SourcePolicy) or not isinstance(revision, str) or not revision:
        raise ValueError("explicit source policy and revision required")
    # Explicit None preserves legacy unscoped read access without inventing an
    # authenticated owner. SourcePolicy still rejects principal/identity-bound
    # rows when the corresponding trusted binding is absent.
    for value in (policy.principal, policy.identity_id):
        if value is not None and (not isinstance(value, str) or not value):
            raise ValueError("principal/identity must be a trusted string or explicit None")
    snapshot = SourcePolicy(principal=policy.principal, identity_id=policy.identity_id,
        allowed_sources=policy.allowed_sources, denied_sources=policy.denied_sources,
        authority_by_source=policy.authority_by_source, authorize=policy.authorize)
    key = _digest({"principal": snapshot.principal, "identity": snapshot.identity_id,
        "revision": revision, "allowed": None if snapshot.allowed_sources is None else sorted(snapshot.allowed_sources),
        "denied": sorted(snapshot.denied_sources), "authority": snapshot.authority_by_source,
        "authorize_identity": id(snapshot.authorize)})
    return snapshot, key


def _adapters(bindings):
    output = []
    for name, path, _, _ in bindings:
        if name == "autobiography":
            output.append(AutobiographyAdapter(path))
        elif name == "goals":
            output.append(GoalsAdapter(path))
        else:
            output.append(SQLiteAdapter(name, path, query_timeout=0.05))
    return output


def _check_sidecar(sidecar, bindings):
    if sidecar is None:
        return
    for _, canonical, _, _ in bindings:
        if sidecar == canonical or (sidecar.exists() and os.path.samefile(sidecar, canonical)):
            raise ValueError("sidecar aliases canonical store")


class MemoryRuntime:
    """One owned background worker. Supported modes are OFF and SHADOW only.

    A proposal is dated metadata, never trusted canonical text or permission.
    Every submitted request (including a cached query) is revalidated on the
    worker. Poll also rejects changed source files/policies. A future context
    consumer must separately rehydrate and apply its source-specific formatter.
    """
    def __init__(self, state, *, mode="off", policy=None, policy_revision="",
                 sidecar_path=None, queue_limit=16, cache_limit=32, ttl_s=15.0,
                 reference_limit=8, clock=time.monotonic):
        if mode not in {"off", "shadow"}:
            raise ValueError("memory runtime supports off/shadow only")
        self.mode, self.state = mode, state
        self.policy, self.policy_revision = policy, policy_revision
        self._clock = clock
        self._queue_limit = max(1, min(64, int(queue_limit)))
        self._cache_limit = max(1, min(128, int(cache_limit)))
        if not math.isfinite(float(ttl_s)) or not 0 < float(ttl_s) <= 60:
            raise ValueError("invalid cache TTL")
        self._ttl = float(ttl_s)
        self._limit = max(1, min(16, int(reference_limit)))
        self._mu = threading.RLock()
        self._wake, self._stop = threading.Event(), threading.Event()
        self._queue, self._results, self._cache = deque(), OrderedDict(), OrderedDict()
        self._scope, self._generation = None, 0
        self._thread = None
        self._closed = False
        self._index = None
        self._index_paths = None
        self._install_spec = (mode, id(policy), policy_revision, str(sidecar_path),
                              queue_limit, cache_limit, ttl_s, reference_limit, id(clock))
        self._sidecar = None
        self._missing = ()
        self._counts = {"submitted": 0, "completed": 0, "dropped": 0, "errors": 0,
                        "stale": 0, "cache_revalidated": 0}
        if mode == "off":
            return
        _policy_snapshot(policy, policy_revision)
        self._sidecar = Path(sidecar_path).resolve() if sidecar_path is not None else None
        bindings, self._missing = _bindings(state)
        _check_sidecar(self._sidecar, bindings)
        self._thread = threading.Thread(target=self._run, name="leon-memory-proposals", daemon=True)
        self._thread.start()

    def _capture(self):
        policy, policy_key = _policy_snapshot(self.policy, self.policy_revision)
        bindings, absent = _bindings(self.state)
        _check_sidecar(self._sidecar, bindings)
        scope = _digest([policy_key, [(n, str(p), owner, stamp) for n, p, owner, stamp in bindings]])
        return policy, bindings, absent, scope

    def _refresh(self, scope, absent):
        with self._mu:
            self._missing = absent
            if scope != self._scope:
                self._generation += 1
                self._scope = scope
                self._counts["stale"] += len(self._results)
                self._results.clear()
                self._cache.clear()
                self._queue.clear()
            return self._generation

    def submit(self, query, *, principal, identity_id, policy_revision, trace_id=""):
        if self.mode == "off" or self._closed:
            return None
        if (principal != self.policy.principal or identity_id != self.policy.identity_id or
                policy_revision != self.policy_revision):
            raise PermissionError("memory request scope differs from the configured source policy")
        if not isinstance(query, str) or not query.strip() or len(query.encode()) > 4096:
            raise ValueError("query must be nonempty and at most 4096 bytes")
        if not isinstance(trace_id, str) or len(trace_id) > 128:
            raise ValueError("trace_id too long")
        policy, bindings, absent, scope = self._capture()
        generation = self._refresh(scope, absent)
        request_id = uuid.uuid4().hex
        key = (scope, hashlib.sha256(query.encode()).hexdigest())
        with self._mu:
            if self._closed:
                return None
            if len(self._queue) >= self._queue_limit:
                self._counts["dropped"] += 1
                return None
            self._queue.append((request_id, trace_id, query, key, generation, policy, bindings))
            self._counts["submitted"] += 1
            self._wake.set()
        return request_id

    def poll(self, request_id, *, principal, identity_id, policy_revision):
        if self.mode == "off" or self._closed:
            return None
        if (principal != self.policy.principal or identity_id != self.policy.identity_id or
                policy_revision != self.policy_revision):
            raise PermissionError("memory result scope differs from configured policy")
        _, _, absent, scope = self._capture()
        self._refresh(scope, absent)
        with self._mu:
            proposal = self._results.get(request_id)
            if proposal is not None and proposal.expires_mono <= self._clock():
                self._results.pop(request_id, None)
                self._counts["stale"] += 1
                return None
            return proposal

    def _service(self, bindings, policy):
        paths = tuple(str(p) for _, p, _, _ in bindings)
        if self._sidecar is not None and bindings and paths != self._index_paths:
            # This constructor writes V2 schema only. It runs on the worker,
            # after all existing canonical paths and hardlinks were rejected.
            from .semantic_index import SemanticIndex
            self._index = SemanticIndex(self._sidecar, enable_embeddings=False, canonical_paths=paths)
            self._index_paths = paths
        return MemoryService(_adapters(bindings), index=self._index, mode="shadow", policy=policy)

    def _references(self, service, query, key):
        now = self._clock()
        with self._mu:
            cached = self._cache.get(key)
        if cached is not None and cached[0] > now:
            valid = True
            for ref in cached[1]:
                if self._stop.is_set():
                    return ()
                record = service._get(ref.store, ref.record_id)
                if (record is None or hashlib.sha256(record.text.encode()).hexdigest() != ref.text_sha256 or
                        record.source != ref.source):
                    valid = False
                    break
            if valid:
                with self._mu:
                    self._counts["cache_revalidated"] += 1
        # Refresh the bounded candidate search even when all cached references
        # still exist. Metadata timestamps alone cannot prove no new matching
        # record was inserted; cached references are observation data, not truth.
        hits = service.retrieve(query, limit=self._limit)
        refs = []
        for hit in hits:
            if self._stop.is_set():
                return ()
            # Rehydrate once more: ranking may have crossed a store mutation.
            record = service._get(hit.store, hit.record_id)
            if record is None or record.text != hit.text:
                continue
            hit = service._hit(record, query)
            source = str(hit.metadata.get("source", "unknown"))
            if len(str(hit.record_id)) > 256 or len(source) > 128:
                continue  # Never truncate and thereby corrupt a canonical reference.
            refs.append(MemoryReference(hit.store, str(hit.record_id),
                hashlib.sha256(hit.text.encode()).hexdigest(), source,
                hit.memory_type.value, float(hit.metadata.get("created_ts", 0)),
                tuple((name, float(getattr(hit, name))) for name in ("semantic_score", "lexical_score",
                    "authority_score", "recency_score", "salience_score", "state_match_score", "final_score")),
                hit.metadata.get("unverified")))
        return tuple(refs)

    def _run(self):
        while not self._stop.is_set():
            self._wake.wait(0.05)
            with self._mu:
                if not self._queue:
                    self._wake.clear()
                    continue
                work = self._queue.popleft()
            request_id, trace_id, query, key, generation, policy, bindings = work
            try:
                if self._stop.is_set():
                    break
                current_policy, current_bindings, absent, current_scope = self._capture()
                current_generation = self._refresh(current_scope, absent)
                if generation != current_generation or key[0] != current_scope:
                    continue
                service = self._service(current_bindings, current_policy)
                refs = self._references(service, query, key)
                _, _, absent, after_scope = self._capture()
                if after_scope != key[0]:
                    self._refresh(after_scope, absent)
                    continue
                now = self._clock()
                proposal = MemoryProposal(request_id, trace_id, key[0], refs, now, now + self._ttl)
                with self._mu:
                    if self._closed or self._stop.is_set() or generation != self._generation:
                        continue
                    self._results[request_id] = proposal
                    self._cache[key] = (proposal.expires_mono, refs)
                    while len(self._results) > self._cache_limit:
                        self._results.popitem(last=False)
                    while len(self._cache) > self._cache_limit:
                        self._cache.popitem(last=False)
                    self._counts["completed"] += 1
            except Exception:
                with self._mu:
                    self._counts["errors"] += 1
            finally:
                # Do not retain canonical text/service objects in the worker's
                # waiting frame after a job. Only frozen references are cached.
                service = None
                work = None
                query = None

    def close(self, timeout=1.0):
        with self._mu:
            self._closed = True
            self._stop.set()
            self._queue.clear()
            self._results.clear()
            self._cache.clear()
            self._wake.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(max(0.0, min(5.0, float(timeout))))
        return thread is None or not thread.is_alive()

    def stats(self):
        with self._mu:
            return {"mode": self.mode, "closed": self._closed,
                    "worker_alive": self._thread is not None and self._thread.is_alive(),
                    "pending": len(self._queue), "results": len(self._results),
                    "cache_entries": len(self._cache), "missing_stores": self._missing,
                    "embeddings_enabled": False, "canonical_writes": False,
                    "metadata_only": True, **self._counts}


def install_from_state(state, *, existing=None, **kwargs):
    """Root owns assignment to state and calls close on its lifecycle boundary.

    Never replace a still-running instance implicitly. Late stores are discovered
    on submit; the runtime uses no early/default path snapshot.
    """
    if existing is not None:
        if existing.state is not state:
            raise ValueError("runtime belongs to another server state")
        spec = (kwargs.get("mode", "off"), id(kwargs.get("policy")), kwargs.get("policy_revision", ""),
                str(kwargs.get("sidecar_path")), kwargs.get("queue_limit", 16), kwargs.get("cache_limit", 32),
                kwargs.get("ttl_s", 15.0), kwargs.get("reference_limit", 8), id(kwargs.get("clock", time.monotonic)))
        if not existing._closed and spec != existing._install_spec:
            raise RuntimeError("close the existing memory runtime before reconfiguration")
        if not existing._closed:
            return existing
        if existing._thread is not None and existing._thread.is_alive():
            raise RuntimeError("previous memory worker is still stopping")
    return MemoryRuntime(state, **kwargs)
