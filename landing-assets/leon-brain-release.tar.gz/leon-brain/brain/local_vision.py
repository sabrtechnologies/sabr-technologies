"""
Local Vision tier — Moondream2 on CUDA for cheap "what do you see" queries.

The point: every webcam_capture / screen_capture round-trip to Sonnet
burns ~$0.005 per image (vision input is the most expensive part of any
Anthropic turn). For "is there a person in the frame?" or "what's on
screen?" type questions, a 4GB local VLM running on Dean's RTX 3070
answers in <1s with no API cost. Leon decides per-turn whether the
local answer is good enough or whether to escalate.

Design:
  - Lazy load — model and processor stay None until first describe().
  - Once loaded, kept warm in VRAM (~3.7GB on 3070, plenty of headroom).
  - Thread-safe: a single asyncio.Lock would be wrong here because
    the GPU itself serializes; we just lock so two concurrent requests
    don't trash each other's KV cache.
  - Falls back gracefully: if torch / model load fails, caller gets
    `{ok: False, error: ...}` and can choose to escalate to Sonnet.

Tunables via env:
  LEON_VISION_MODEL    HF model id (default vikhyatk/moondream2)
  LEON_VISION_REVISION model revision (default 2025-04-14)
  LEON_VISION_DEVICE   "cuda" | "cpu" (auto)
"""

from __future__ import annotations

import io
import os
import threading
import time
from typing import Any, Dict, Optional

# We import torch lazily so the brain server can boot without CUDA being
# present (e.g. on Dean's laptop or in CI). If LocalVision.start() fails,
# the wrapper just stays disabled and the tool returns ok=False.


_DEFAULT_MODEL = "vikhyatk/moondream2"
_DEFAULT_REV = "2025-04-14"


class LocalVision:
    """Wrapper around Moondream2 for local image Q&A."""

    def __init__(
        self,
        model_id: Optional[str] = None,
        revision: Optional[str] = None,
        device: Optional[str] = None,
    ):
        self.model_id = model_id or os.environ.get("LEON_VISION_MODEL", _DEFAULT_MODEL)
        self.revision = revision or os.environ.get("LEON_VISION_REVISION", _DEFAULT_REV)
        self.device = device or os.environ.get("LEON_VISION_DEVICE", "auto")
        self._model = None
        self._lock = threading.Lock()    # serialize GPU calls
        self._init_lock = threading.Lock()
        self._error: Optional[str] = None
        self._loaded_at: float = 0.0
        self._calls = 0
        self._total_inference_s = 0.0
        self._available = False
        self._last_use: float = 0.0
        self.last_latency_s: float = 0.0
        self._idle_unload_s = float(os.environ.get("LEON_VISION_IDLE_UNLOAD", "600"))  # 10 min
        # Transient-import retry state. A first-boot ImportError is NOT proof
        # the dependency is absent (see _deps_installed), so we back off and
        # retry instead of disabling vision for the life of the process.
        self._import_attempts = 0
        self._retry_not_before: float = 0.0

    @staticmethod
    def _deps_installed() -> bool:
        """True if torch AND transformers are actually installed on this host.

        This is the difference between "the package isn't here" (permanent,
        latch) and "the import blew up while the machine was thrashing during
        first boot" (transient, retry). importlib.find_spec only reads the
        module metadata — it does not execute the package — so it stays
        truthful even when a real import would fail under load.
        """
        try:
            import importlib.util as _ilu
            return all(_ilu.find_spec(m) is not None
                       for m in ("torch", "transformers"))
        except Exception:
            return False

    # ── State ────────────────────────────────────────────────────────────
    @property
    def available(self) -> bool:
        return self._available

    @property
    def last_error(self) -> Optional[str]:
        """Most recent load/inference error message, or None if healthy."""
        return self._error

    def get_state(self) -> Dict[str, Any]:
        return {
            "available": self._available,
            "model": self.model_id,
            "revision": self.revision,
            "device": self.device,
            "loaded_at": self._loaded_at,
            "loaded_age_s": (time.time() - self._loaded_at) if self._loaded_at else -1,
            "calls": self._calls,
            "avg_inference_s": (self._total_inference_s / self._calls) if self._calls else None,
            "error": self._error,
        }

    # ── Lazy init (called at first describe() or via prewarm()) ──────────
    def _resolve_device(self):
        import torch
        if self.device == "auto":
            return "cuda" if torch.cuda.is_available() else "cpu"
        return self.device

    def _ensure_loaded(self) -> bool:
        if self._model is not None:
            return True
        # Missing dependency (no transformers/torch on this host) can't fix
        # itself mid-process — without this flag every caller retried the
        # import forever, spamming "[VISION] load failed" hundreds of times
        # on the VPS and burning latency on the dead path.
        if getattr(self, "_permanent_fail", False):
            return False
        # Transient import failure: wait out the backoff rather than
        # hammering a machine that is already struggling.
        if self._retry_not_before and time.time() < self._retry_not_before:
            return False
        with self._init_lock:
            if self._model is not None:
                return True
            if getattr(self, "_permanent_fail", False):
                return False
            if self._retry_not_before and time.time() < self._retry_not_before:
                return False
            try:
                import torch
                from transformers import AutoModelForCausalLM
                dev = self._resolve_device()
                # Cap CPU threads to half cores when no GPU available
                if not torch.cuda.is_available():
                    _ncpu = int(os.environ.get('LEON_VISION_THREADS', '')) if os.environ.get('LEON_VISION_THREADS') else max(1, (os.cpu_count() or 2) // 2)
                    torch.set_num_threads(_ncpu)
                t0 = time.time()
                model = AutoModelForCausalLM.from_pretrained(
                    self.model_id,
                    revision=self.revision,
                    trust_remote_code=True,
                    torch_dtype=torch.float16 if dev == "cuda" else torch.float32,
                    device_map={"": dev},
                )
                self._model = model
                self._loaded_at = time.time()
                self.device = dev
                self._available = True
                self._error = None
                print(f"[VISION] Moondream2 loaded ({self.model_id}@{self.revision}) "
                      f"on {dev} in {time.time()-t0:.1f}s")
                return True
            except Exception as e:
                self._error = f"{type(e).__name__}: {e}"
                print(f"[VISION] load failed: {self._error}")
                if isinstance(e, ImportError):  # covers ModuleNotFoundError
                    if self._deps_installed():
                        # The packages ARE here. This import died for another
                        # reason — almost always first-boot contention, where
                        # torch's ~800MB of DLLs fail to map while pip, the
                        # model downloads and the brain all fight for the disk.
                        # Latching here left a fresh install permanently blind
                        # with nothing telling the user. Back off and retry.
                        self._import_attempts += 1
                        delay = min(300.0, 15.0 * (2 ** (self._import_attempts - 1)))
                        self._retry_not_before = time.time() + delay
                        print(f"[VISION] import failed but torch and transformers "
                              f"are installed — treating as transient "
                              f"(attempt {self._import_attempts}), retrying in "
                              f"{int(delay)}s")
                    else:
                        self._permanent_fail = True
                        print("[VISION] dependency missing on this host — "
                              "local vision disabled for this process "
                              "(captions come from the PC relay)")
                # On CUDA OOM, free whatever partial allocations the from_pretrained
                # left behind so the next attempt has a clean slate. Without this,
                # each failed load leaks VRAM and subsequent loads OOM sooner.
                try:
                    import torch
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                        torch.cuda.ipc_collect()
                except Exception:
                    pass
                # Don't keep a half-built model reference around.
                self._model = None
                self._available = False
                return False

    def prewarm(self) -> bool:
        """Eagerly load the model. Safe to call from a background thread
        at server boot so the first user-facing request is fast."""
        return self._ensure_loaded()

    def unload(self):
        """Free the model from GPU VRAM. Will reload on next use."""
        with self._init_lock:
            if self._model is not None:
                try:
                    del self._model
                    self._model = None
                    self._available = False
                    import torch
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    print("[VISION] Moondream2 unloaded — VRAM freed")
                except Exception:
                    pass

    def maybe_unload_if_idle(self):
        """Unload if not used for _idle_unload_s seconds. Call periodically."""
        if (self._model is not None and self._last_use > 0 and
                time.time() - self._last_use > self._idle_unload_s):
            self.unload()

    # ── Inference ───────────────────────────────────────────────────────
    def query(self, image_bytes: bytes, prompt: str) -> Dict[str, Any]:
        """Ask a question about the image. Returns {ok, answer, latency_s}.
        The image_bytes can be PNG or JPEG (Moondream's preprocessor handles
        both via PIL).
        """
        self._last_use = time.time()
        if not self._ensure_loaded():
            return {"ok": False, "error": self._error or "model not loaded"}
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        except Exception as e:
            return {"ok": False, "error": f"image decode failed: {e}"}
        with self._lock:
            t0 = time.time()
            try:
                out = self._model.query(img, prompt)
                ans = (out or {}).get("answer", "").strip()
                dt = time.time() - t0
                self._calls += 1
                self._total_inference_s += dt
                self.last_latency_s = dt
                return {"ok": True, "answer": ans, "latency_s": round(dt, 2)}
            except Exception as e:
                return {"ok": False, "error": f"inference failed: {e}"}

    def caption(self, image_bytes: bytes, length: str = "short") -> Dict[str, Any]:
        """Caption the image. `length` is 'short' or 'normal'."""
        if not self._ensure_loaded():
            return {"ok": False, "error": self._error or "model not loaded"}
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        except Exception as e:
            return {"ok": False, "error": f"image decode failed: {e}"}
        if length not in ("short", "normal"):
            length = "short"
        with self._lock:
            t0 = time.time()
            try:
                out = self._model.caption(img, length=length)
                cap = (out or {}).get("caption", "").strip()
                dt = time.time() - t0
                self._calls += 1
                self._total_inference_s += dt
                self.last_latency_s = dt
                return {"ok": True, "caption": cap, "latency_s": round(dt, 2)}
            except Exception as e:
                return {"ok": False, "error": f"inference failed: {e}"}

    def detect(self, image_bytes: bytes, target: str) -> Dict[str, Any]:
        """Object detection — `target` is the noun ('person', 'phone',
        'red car'). Returns bounding boxes (normalized 0-1)."""
        if not self._ensure_loaded():
            return {"ok": False, "error": self._error or "model not loaded"}
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        except Exception as e:
            return {"ok": False, "error": f"image decode failed: {e}"}
        with self._lock:
            t0 = time.time()
            try:
                out = self._model.detect(img, target)
                boxes = (out or {}).get("objects", [])
                dt = time.time() - t0
                self._calls += 1
                self._total_inference_s += dt
                return {"ok": True, "objects": boxes, "count": len(boxes),
                        "latency_s": round(dt, 2)}
            except Exception as e:
                return {"ok": False, "error": f"inference failed: {e}"}

    def point(self, image_bytes: bytes, target: str) -> Dict[str, Any]:
        """Point at the target in the image. `target` is a description with
        ANY language — Moondream2 understands positional descriptors like
        'the bottom right video', 'the Subscribe button', 'the third item
        in the list'. Returns NORMALIZED points (0-1 in both dims).

        Caller multiplies by image dimensions to get pixel coords.

        Returns {ok, points: [{x, y}], count, latency_s}.
        Empty points means Moondream didn't find a match.
        """
        if not self._ensure_loaded():
            return {"ok": False, "error": self._error or "model not loaded"}
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        except Exception as e:
            return {"ok": False, "error": f"image decode failed: {e}"}
        with self._lock:
            t0 = time.time()
            try:
                out = self._model.point(img, target)
                # Moondream returns {"points": [{x,y}], "count": N} OR a bare list.
                if isinstance(out, dict):
                    points = out.get("points", [])
                elif isinstance(out, list):
                    points = out
                else:
                    points = []
                # Normalize to list of {x: float, y: float}
                clean = []
                for p in points:
                    if isinstance(p, dict) and "x" in p and "y" in p:
                        clean.append({"x": float(p["x"]), "y": float(p["y"])})
                    elif isinstance(p, (list, tuple)) and len(p) >= 2:
                        clean.append({"x": float(p[0]), "y": float(p[1])})
                dt = time.time() - t0
                self._calls += 1
                self._total_inference_s += dt
                return {"ok": True, "points": clean, "count": len(clean),
                        "latency_s": round(dt, 2)}
            except Exception as e:
                return {"ok": False, "error": f"inference failed: {e}"}
