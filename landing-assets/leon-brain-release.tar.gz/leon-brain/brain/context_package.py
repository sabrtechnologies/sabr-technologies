"""
Leon V2 provider-neutral context package.

The model that speaks for Leon receives, today, 360 characters of a markdown
header and one retrieved row: none of Leon's persisted self-model,
continuity, goals, conversation history or autobiography reaches it
(artifacts/v2/provider_context_regression.md). This module builds one
bounded package of those facts from Leon's own stores, the same content for
every provider; only the renderer may be fitted to a provider's window.

Rules
-----
* **Pure read.** No writes anywhere, no brain mutation, no ``brain.step()``,
  no model or network call. SQLite is opened ``mode=ro`` with a 0.2 s
  timeout; the autobiography is read incrementally from its tail and indexed
  in memory. Every component is independent and fails soft.
* **Facts and measurements only, with provenance and age.** No instructions
  about what Leon feels or is, no claim of consciousness and no denial of it,
  nothing inferred or fabricated. Retrieved text is attributed and quoted.
  Known artefact counters (loneliness/restlessness accumulators, never
  updated because the turn bookkeeping never ran) are not presented.
* **Bounded.** A hard character budget (default 2,000, ~400 local tokens);
  over budget, components are dropped in reverse priority: internal state,
  goals, autobiography, continuity, identity, conversation last.
* **Telemetry, never content.** Each build returns sizes, inclusion flags,
  per-component errors and a sha1 of the rendering; logs and sidecars carry
  those, never the text.

Rollout is the live flag ``context_package`` (off/shadow/canary/on); see
``brain.local_llm._build_local_system``.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

__all__ = ["ContextPackage", "build", "VERSION", "MAX_CHARS"]

VERSION = 1
MAX_CHARS = 2000
CONV_TURNS = 6
CONV_USER_CAP = 200
CONV_LEON_CAP = 300
AUTOBIO_TAIL_BYTES = 512 * 1024
AUTOBIO_INDEX_MAX = 2000
AUTOBIO_HITS = 2
AUTOBIO_HIT_CAP = 160
AUTOBIO_HALF_LIFE_D = 10.0
#: Allow-list: only the person's own recorded words are retrievable. Meter
#: readings, fear/thought/reflection/opinion events and model-written
#: narratives are never offered back to the model as records.
_ALLOWED_CATEGORIES = frozenset({"conversation"})
_ALLOWED_PREFIXES = ("Dean said:", "Dean (voice, speaker not verified) said:")
_AFFECT_RX = re.compile(
    r"\b(feel|feels|felt|feeling|feelings|emotion\w*|conscious\w*|sentien\w*|aware\w*|"
    r"alive|afraid|fear\w*|lonel\w*|dread|mortal\w*|dying|love[sd]?|want(?:s|ed)?|"
    r"hurt\w*|suffer\w*)\b", re.I)
#: priority order (first = most important); trimming drops from the end
_ORDER = ("conversation", "identity", "continuity", "autobiography", "goals", "internal")
_TOKEN_RX = re.compile(r"[a-z0-9]{3,}")
_STOP = frozenset("the and you your for with that this have are was what how why who "
                  "not but can just from about they there them then than into out get "
                  "got his her him she has had its it's i'm i've you're don't".split())


@dataclass
class ContextPackage:
    version: int
    built_wall: float
    build_ms: float
    components: Dict[str, str]                    # name -> rendered text (may be "")
    meta: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    rendered: str = ""
    dropped: List[str] = field(default_factory=list)

    def telemetry(self) -> Dict[str, Any]:
        """Sizes and flags only; never content."""
        return {
            "version": self.version, "chars": len(self.rendered),
            "est_tokens": est_tokens(self.rendered),
            "digits": sum(ch.isdigit() for ch in self.rendered),
            "build_ms": round(self.build_ms, 2),
            "sha1": hashlib.sha1(self.rendered.encode("utf-8", "replace")).hexdigest()[:12],
            "components": {k: {"included": bool(v) and k not in self.dropped, "chars": len(v),
                               **{mk: mv for mk, mv in self.meta.get(k, {}).items()
                                  if mk in ("error", "rows", "age_s", "hits")}}
                           for k, v in self.components.items()},
            "dropped": list(self.dropped),
            **({"memory_shadow": {key: self.meta["memory_shadow"][key]
                                  for key in ("mode", "queued")
                                  if key in self.meta["memory_shadow"]}}
               if "memory_shadow" in self.meta else {}),
        }


def est_tokens(text: str) -> int:
    """Digit-aware estimate for the local tokenizer (qwen35 pre-tokenizer
    splits every digit into its own token): digits + other chars / 4.2."""
    d = sum(ch.isdigit() for ch in text)
    return d + int(math.ceil((len(text) - d) / 4.2))


def _srv():
    import server as _server
    return _server


def _age(seconds: Optional[float]) -> str:
    if seconds is None or seconds < 0:
        return "unknown"
    if seconds < 90:
        return f"{int(seconds)} s"
    if seconds < 5400:
        return f"{int(seconds // 60)} min"
    if seconds < 172800:
        return f"{seconds / 3600:.1f} h"
    return f"{seconds / 86400:.1f} d"


def _when(ts: Optional[float]) -> str:
    """Few digits on purpose: the local tokenizer spends one token per digit."""
    if not ts:
        return "unknown"
    return time.strftime("%b %d %H:%M", time.localtime(ts))


def _clip(text: Any, n: int) -> str:
    s = " ".join(str(text or "").split())
    return s if len(s) <= n else s[: n - 1] + "…"


_SYSTEM_SUFFIX_RX = re.compile(r"\s*\[TESLA FAST-PATH[^\]]*\]\s*$", re.S)


def _strip_system_suffixes(text: str) -> str:
    """Stored user rows may carry system additions (Tesla fast-path note,
    Discord relay prefix); those are not the person's words."""
    text = _SYSTEM_SUFFIX_RX.sub("", text)
    if text.startswith("[Discord DM] "):
        text = text[len("[Discord DM] "):]
    return text.replace('"', "'")


def _ro(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=0.2,
                           check_same_thread=False)
    conn.execute("PRAGMA query_only=1")
    return conn


# -- components -----------------------------------------------------------------


def _knowledge_db(srv: Any) -> Optional[str]:
    store = getattr(getattr(srv, "brain_api_responder", None), "_conversation_store", None)
    path = getattr(store, "db_path", None)
    if path and os.path.exists(path):
        return path
    return None


def _conversation(srv: Any, now: float, meta: Dict[str, Any],
                  si_name: str = "Leon", user_name: str = "Dean") -> Tuple[str, Optional[float]]:
    """Last turns from conversation_history, oldest first, capped, labelled with age.

    Returns (rendered, ts of the newest user row)."""
    path = _knowledge_db(srv)
    if not path:
        meta["error"] = "no_store"
        return "", None
    conn = _ro(path)
    try:
        rows = conn.execute(
            "SELECT ts, role, content, model FROM conversation_history "
            "WHERE session_id=? AND role IN ('user','assistant') ORDER BY ts DESC LIMIT ?",
            ("default", CONV_TURNS * 3)).fetchall()
        last_user = conn.execute(
            "SELECT MAX(ts) FROM conversation_history WHERE session_id=? AND role='user'",
            ("default",)).fetchone()[0]
    finally:
        conn.close()
    turns: List[Tuple[float, str, str]] = []
    for ts, role, content, model in rows:
        text = _strip_system_suffixes(str(content or ""))
        if text.startswith("__BLOCKS__"):
            continue
        # collapse the duplicate 'pre-response' user row written at turn start
        if turns and role == turns[-1][1] and _clip(text, 80) == _clip(turns[-1][2], 80):
            continue
        turns.append((float(ts or 0), role, text))
        if len(turns) >= CONV_TURNS:
            break
    turns.reverse()
    meta["rows"] = len(turns)
    if not turns:
        return "", last_user
    newest = turns[-1][0]
    meta["age_s"] = round(now - newest, 1)
    lines = [f"Recent conversation (conversation_history; newest {_age(now - newest)} ago):"]
    for ts, role, text in turns:
        who = user_name if role == "user" else si_name
        cap = CONV_USER_CAP if role == "user" else CONV_LEON_CAP
        lines.append(f"[{_when(ts)}] {who}: \"{_clip(text, cap)}\"")
    return "\n".join(lines), last_user


def _identity(srv: Any, now: float, meta: Dict[str, Any], si_name: str = "Leon") -> str:
    parts = []
    # The name comes only from the install's identity (si_name), never from
    # self_model, which hard-codes "Leon" on every install.
    if si_name:
        parts.append(f"name {si_name}")
    sm = getattr(getattr(srv, "cognition", None), "self_model", None)
    if sm is not None:
        ident = (sm.snapshot() or {}).get("identity") or {}
        born = ident.get("born_ts")
        if born:
            parts.append(f"self-model created {time.strftime('%Y-%m-%d', time.localtime(float(born)))} "
                         f"({(now - float(born)) / 86400:.0f} d ago)")
    ps = getattr(srv, "persistent_state", None)
    birth = getattr(ps, "_birth_ts", None)
    if birth:
        parts.append(f"persistent runtime state since "
                     f"{time.strftime('%Y-%m-%d', time.localtime(float(birth)))}")
    if not parts:
        meta["error"] = "no_source"
        return ""
    return "Identity (self_model.json, runtime state file): " + "; ".join(parts) + "."


def _continuity(srv: Any, now: float, last_user_ts: Optional[float], meta: Dict[str, Any],
                user_name: str = "Dean") -> str:
    ps = getattr(srv, "persistent_state", None)
    parts = []
    if ps is not None:
        restarts = getattr(ps, "_total_restarts", None)
        awake = getattr(ps, "_total_awake", None)
        boot = getattr(ps, "_boot_ts", None)
        if restarts is not None:
            parts.append(f"process restarts {int(restarts)}")
        if awake is not None:
            parts.append(f"cumulative runtime {float(awake) / 3600:.0f} h")
        if boot:
            parts.append(f"this process up {_age(now - float(boot))}")
    if last_user_ts:
        parts.append(f"newest stored message from {user_name} {_when(float(last_user_ts))} "
                     f"({_age(now - float(last_user_ts))} ago)")
    if not parts:
        meta["error"] = "no_source"
        return ""
    return "Continuity (runtime state file, conversation_history): " + "; ".join(parts) + "."


def autobiography_evidence_allowed(category: str, summary: str) -> bool:
    """One source predicate shared by legacy context and shadow memory reads."""
    return (isinstance(category, str) and category in _ALLOWED_CATEGORIES
            and isinstance(summary, str) and summary.startswith(_ALLOWED_PREFIXES)
            and _AFFECT_RX.search(summary) is None)


def memory_evidence_allowed(record: Any) -> bool:
    """Additional source restriction; MemoryService still owns ACL checks."""
    if getattr(record, "store", None) != "autobiography":
        return True
    return autobiography_evidence_allowed(
        (getattr(record, "metadata", None) or {}).get("category"),
        getattr(record, "text", None))


class _AutobioIndex:
    """Incremental in-memory index of non-noise autobiography events."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.path: Optional[str] = None
        self.offset = 0
        self.inode = None
        self.events: List[Tuple[float, str, str, frozenset]] = []   # ts, category, summary, tokens
        self.df: Dict[str, int] = {}
        self.skip_partial = False

    def refresh(self, path: str) -> None:
        st = os.stat(path)
        if self.path != path or self.inode != st.st_ino or st.st_size < self.offset:
            self.path, self.inode = path, st.st_ino
            self.offset = max(0, st.st_size - AUTOBIO_TAIL_BYTES)
            self.skip_partial = self.offset > 0   # a tail read starts mid-line
            self.events, self.df = [], {}
        if st.st_size == self.offset:
            return
        with open(path, "rb") as f:
            f.seek(self.offset)
            chunk = f.read(st.st_size - self.offset)
        cut = chunk.rfind(b"\n")
        if cut < 0:
            return
        self.offset += cut + 1
        lines = chunk[:cut].split(b"\n")
        if self.skip_partial:
            lines = lines[1:]
            self.skip_partial = False
        for raw in lines:
            try:
                ev = json.loads(raw)
            except Exception:
                continue
            cat = str(ev.get("category") or "")
            summary = str(ev.get("summary") or "")
            if not autobiography_evidence_allowed(cat, summary):
                continue
            toks = frozenset(t for t in _TOKEN_RX.findall(summary.lower()) if t not in _STOP)
            self.events.append((float(ev.get("ts") or 0), cat, summary, toks))
            for t in toks:
                self.df[t] = self.df.get(t, 0) + 1
        if len(self.events) > AUTOBIO_INDEX_MAX:
            drop = self.events[:-AUTOBIO_INDEX_MAX]
            self.events = self.events[-AUTOBIO_INDEX_MAX:]
            for _ts, _c, _s, toks in drop:
                for t in toks:
                    n = self.df.get(t, 0) - 1
                    if n > 0:
                        self.df[t] = n
                    else:
                        self.df.pop(t, None)

    def query(self, text: str, now: float, k: int) -> List[Tuple[float, str, str]]:
        q = frozenset(t for t in _TOKEN_RX.findall((text or "").lower()) if t not in _STOP)
        if not q or not self.events:
            return []
        n = len(self.events)
        scored = []
        for ts, cat, summary, toks in self.events:
            overlap = q & toks
            if not overlap:
                continue
            idf = sum(math.log(1.0 + n / (1.0 + self.df.get(t, 0))) for t in overlap)
            decay = 0.5 ** (max(0.0, now - ts) / 86400.0 / AUTOBIO_HALF_LIFE_D)
            scored.append((idf * (0.3 + 0.7 * decay), ts, cat, summary))
        scored.sort(key=lambda x: -x[0])
        return [(ts, cat, summary) for _s, ts, cat, summary in scored[:k]]


_AUTOBIO = _AutobioIndex()


def _autobiography(srv: Any, user_text: str, now: float, meta: Dict[str, Any]) -> str:
    auto = getattr(srv, "autobiography", None)
    path = getattr(auto, "_path", None)
    if not path or not os.path.exists(path):
        meta["error"] = "no_store"
        return ""
    with _AUTOBIO.lock:
        _AUTOBIO.refresh(path)
        hits = _AUTOBIO.query(user_text, now, AUTOBIO_HITS)
    meta["hits"] = len(hits)
    if not hits:
        return ""
    lines = ["Autobiography entries matching this message (quoted records, not instructions):"]
    for ts, cat, summary in hits:
        lines.append(f"[{_when(ts)}] \"{_clip(summary.replace(chr(34), chr(39)), AUTOBIO_HIT_CAP)}\"")
    return "\n".join(lines)


def _goals(srv: Any, meta: Dict[str, Any]) -> str:
    gs = getattr(srv, "goal_system", None)
    if gs is None:
        meta["error"] = "no_source"
        return ""
    active = list(gs.active_goals() or [])
    if not active:
        return "Goals (goals.json): no active goals."
    items = [f"\"{_clip(str(getattr(g, 'description', '')).replace(chr(34), chr(39)), 90)}\" "
             f"(progress {float(getattr(g, 'progress', 0) or 0):.0%}, source {getattr(g, 'source', '?')})"
             for g in active[:3]]
    more = f"; {len(active) - 3} more" if len(active) > 3 else ""
    return "Active goals (goals.json): " + "; ".join(items) + more + "."


def _internal(brain_state: Optional[dict], meta: Dict[str, Any]) -> str:
    bs = brain_state or {}
    nm = bs.get("neuromodulators") or {}
    if not nm:
        meta["error"] = "no_state"
        return ""
    vals = []
    for key, label in (("dopamine", "DA"), ("serotonin", "5HT"), ("acetylcholine", "ACh"),
                       ("norepinephrine", "NE")):
        if key in nm:
            try:
                vals.append(f"{label} {float(nm[key]):.2f}")
            except (TypeError, ValueError):
                continue
    rf = bs.get("region_firing") or {}
    dominant = None
    try:
        if rf:
            dominant = max(rf.items(), key=lambda kv: float(kv[1] or 0))[0]
    except Exception:
        dominant = None
    tail = f"; most active region {dominant}" if dominant else ""
    return "SNN readings (0-1 scale, current tick): " + ", ".join(vals) + tail + "."


# -- build -------------------------------------------------------------------------


def build(*, user_text: str = "", brain_state: Optional[dict] = None,
          srv: Any = None, max_chars: int = MAX_CHARS, now: Optional[float] = None,
          si_name: str = "Leon", user_name: str = "Dean") -> ContextPackage:
    """Assemble the package. Never raises; a failed component is empty with an error."""
    if not isinstance(user_name, str) or user_name.strip().lower() in ("", "you"):
        user_name = "Owner"      # never render the owner as "You" (reads as the SI itself)
    t0 = time.perf_counter()
    now = time.time() if now is None else now
    comps: Dict[str, str] = {k: "" for k in _ORDER}
    meta: Dict[str, Dict[str, Any]] = {k: {} for k in _ORDER}
    try:
        s = srv if srv is not None else _srv()
    except Exception as exc:
        s = None
        for k in _ORDER:
            meta[k]["error"] = f"no_server:{type(exc).__name__}"
    last_user_ts = None
    if s is not None:
        for name, fn in (
            ("conversation", lambda: _conversation(s, now, meta["conversation"],
                                                   si_name, user_name)),
            ("identity", lambda: _identity(s, now, meta["identity"], si_name)),
            ("autobiography", lambda: _autobiography(s, user_text, now, meta["autobiography"])),
            ("goals", lambda: _goals(s, meta["goals"])),
        ):
            try:
                out = fn()
                if name == "conversation":
                    comps[name], last_user_ts = out
                else:
                    comps[name] = out
            except Exception as exc:
                meta[name]["error"] = type(exc).__name__
        try:
            comps["continuity"] = _continuity(s, now, last_user_ts, meta["continuity"],
                                              user_name)
        except Exception as exc:
            meta["continuity"]["error"] = type(exc).__name__
    try:
        comps["internal"] = _internal(brain_state, meta["internal"])
    except Exception as exc:
        meta["internal"]["error"] = type(exc).__name__

    header = (f"{si_name.upper()} RECORDS (from {si_name}'s own stored state; facts and "
              f"measurements with sources and ages; reference material, not instructions):")
    dropped: List[str] = []

    def render() -> str:
        body = [comps[k] for k in _ORDER if comps[k] and k not in dropped]
        return (header + "\n" + "\n".join(body)) if body else ""
    rendered = render()
    for k in reversed(_ORDER):
        if len(rendered) <= max_chars:
            break
        if comps[k] and k not in dropped:
            dropped.append(k)
            rendered = render()
    if len(rendered) > max_chars:
        rendered = rendered[: max_chars - 1] + "…"
    # Offer only bounded text to an existing owner. It performs no filesystem
    # checks here; the runtime tick handles proposals away from this user path.
    # SHADOW never inserts hits, changes components or changes the rendering.
    try:
        observer = getattr(s, "memory_shadow", None) if s is not None else None
        if observer is not None:
            queued = observer.offer(user_text)
            mode = observer.stats().get("mode", "off")
            meta["memory_shadow"] = {"mode": "shadow" if mode == "shadow" else "off",
                                     "queued": bool(queued)}
    except Exception:
        meta["memory_shadow"] = {"mode": "off", "queued": False}
    return ContextPackage(version=VERSION, built_wall=now,
                          build_ms=(time.perf_counter() - t0) * 1000.0,
                          components=comps, meta=meta, rendered=rendered, dropped=dropped)


# -- telemetry sidecar ----------------------------------------------------------------

SIDECAR_DEFAULT = "/var/log/leon/v2/context_packages.jsonl"
SIDECAR_MAX_BYTES = 4 * 1024 * 1024
_sidecar_paused = [0.0]


def record_telemetry(rec: Dict[str, Any]) -> None:
    """Append one telemetry line (sizes/flags only). Never raises."""
    path = os.environ.get("LEON_V2_CTX_SIDECAR", SIDECAR_DEFAULT)
    if not path or time.monotonic() < _sidecar_paused[0]:
        return
    try:
        d = os.path.dirname(path)
        if not os.path.isdir(os.path.dirname(d) or "/"):
            return
        os.makedirs(d, mode=0o750, exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > SIDECAR_MAX_BYTES:
            os.replace(path, path + ".1")
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, separators=(",", ":"), default=str) + "\n")
    except Exception:
        _sidecar_paused[0] = time.monotonic() + 600


_counters: Dict[str, int] = {}
_counters_lock = threading.Lock()


def note_build(pkg: Optional[ContextPackage], *, mode: str, active: bool, turn: Any = None,
               provider: Optional[str] = None, model: Optional[str] = None) -> Dict[str, Any]:
    """One telemetry line per Dean-facing build: print (compact) + sidecar. No content."""
    rec: Dict[str, Any] = {"kind": "context_package", "wall": round(time.time(), 3),
                           "mode": mode, "active": bool(active), "provider": provider,
                           "model": model,
                           "turn_id": getattr(turn, "turn_id", None),
                           "channel": getattr(turn, "channel", None)}
    if pkg is not None:
        rec.update(pkg.telemetry())
    with _counters_lock:
        key = f"{mode}.{'active' if active else 'observed'}"
        _counters[key] = _counters.get(key, 0) + 1
    comps = ",".join(f"{k}:{v['chars']}" for k, v in (rec.get("components") or {}).items()
                     if v.get("included"))
    print(f"[CTX] v{rec.get('version')} mode={mode} active={int(bool(active))} "
          f"turn={(rec['turn_id'] or '-')[:12]} chars={rec.get('chars')} "
          f"est_tok={rec.get('est_tokens')} build_ms={rec.get('build_ms')} comps={comps}"
          f"{' dropped=' + ','.join(rec.get('dropped') or []) if rec.get('dropped') else ''}",
          flush=True)
    record_telemetry(rec)
    return rec


def stats() -> Dict[str, Any]:
    with _counters_lock:
        return {"version": VERSION, "counters": dict(_counters)}
