"""Tenant secret encryption with a dedicated, rotatable key.

WHY THIS MODULE EXISTS
----------------------
Tenant credentials (customer Anthropic keys, hosted keys, ElevenLabs keys, ...)
are stored encrypted in ``brain_state/registry.json`` under each tenant's
``metadata`` dict. Historically the encryption key was derived from
``LEON_API_KEY`` -- the server's *master API secret*::

    key = sha256(LEON_API_KEY + b"tenant-api-key-encryption")

That couples two things that have nothing to do with each other. ``LEON_API_KEY``
is an authentication secret: it is meant to be rotated whenever it leaks, is
shared, or simply ages out. But rotating it silently orphans *every* stored
customer credential, because the derived AES key changes and the old ciphertext
can never be read again. Worse, the old decrypt helper swallowed the resulting
exception and returned ``""``, so an orphaned credential looked exactly like
"this customer never supplied a key" -- and the provisioning path then
substituted the shared billing key without anyone noticing.

So this module introduces a *dedicated* encryption secret,
``TENANT_KEY_ENCRYPTION_KEY``, used for all new ciphertext::

    key = sha256(TENANT_KEY_ENCRYPTION_KEY + b"tenant-api-key-encryption-v2")

The API secret can now rotate freely without touching customer data, and the
encryption secret rotates on its own (deliberate) schedule via re-encryption.

THE V2 WIRE FORMAT
------------------
V2 is authenticated encryption. The primitive is AES-256-GCM (an AEAD), stored
as::

    "v2:" + base64(nonce || ciphertext_with_tag)

with a fresh 12-byte random nonce per encryption and GCM's 16-byte
authentication tag appended to the ciphertext by ``AESGCM``. The ``"v2:"``
prefix follows the convention already established by the legacy ``"xor:"``
prefix (the registry has no version field, so the prefix *is* the
discriminator).

Because GCM authenticates, any modification of a stored value -- a flipped
ciphertext byte, a flipped nonce byte, a truncated envelope -- is *detected*:
``cryptography`` raises ``InvalidTag`` and this module translates that into
``TenantDecryptionFailed``. It is never swallowed. Confidentiality and
integrity now come from the same primitive, so a registry.json an attacker can
write to can no longer be used to maul a customer credential undetected.

NONCE DISCIPLINE (the one rule GCM will not forgive)
----------------------------------------------------
A GCM nonce must NEVER be reused under the same key: two messages encrypted
with the same (key, nonce) pair leak their XOR and, worse, hand an attacker the
authentication subkey, which forgeries can then be minted from. This module
therefore draws every nonce from ``secrets.token_bytes(12)`` -- a fresh CSPRNG
draw per call, never a counter, never a value derived from the plaintext or the
tenant. Nothing here ever re-encrypts with a caller-supplied nonce, and there is
no API to supply one. Any future change that caches, derives or sequences
nonces must be treated as a break of this contract.

The legacy read paths (``xor:`` and bare-base64 legacy AES-CBC) exist purely for
transition: they let already-stored ciphertext be read once, so it can be
re-encrypted under the dedicated key as v2 GCM. Nothing here ever *writes* a
legacy format, and the legacy primitives are read-only by construction. Once
migration is complete the legacy branches can be deleted.

FAILURE SEMANTICS
-----------------
``decrypt_tenant_secret`` raises ``TenantDecryptionFailed`` when ciphertext is
present but unreadable. It never returns ``""`` to signal failure, because
"could not decrypt" and "customer stored nothing" must not look alike to a
caller that decides whose account pays for the API call. Callers that genuinely
cannot raise use ``try_decrypt_tenant_secret`` and MUST still distinguish its
``False`` from the separate case of no ciphertext being stored at all.

SECURITY NOTES
--------------
* No plaintext secret, and no key material, is ever logged, printed, or placed
  in an exception message by this module. Exceptions carry only the failure
  class, the detected format, and the exception type of the underlying error.
* New ciphertext is authenticated (AES-256-GCM). Tampering is detected and
  surfaced as ``TenantDecryptionFailed``, never as a plausible-looking
  plaintext.
* The *legacy* formats are not authenticated and cannot be made so
  retroactively: legacy AES-CBC without a MAC is malleable, and the legacy XOR
  stream is not encryption at all. They survive here strictly as read paths so
  already-stored credentials can be recovered and re-written as v2. A value
  that still reads as ``legacy-aes`` or ``legacy-xor`` should be treated as
  unmigrated, not as secure.
* AAD (additional authenticated data) is *supported* but deliberately unused in
  this migration -- see ``encrypt_tenant_secret``. Binding ciphertext to a
  tenant id is the right end state; doing it in the same change as the
  primitive swap would break the context-free compatibility shims and make the
  migration unverifiable.
* Env vars are read lazily, inside the functions that need them. The old code
  bound the master key at import time, which is precisely why it was hard to
  rotate (and impossible to test). Tests override the environment with
  ``os.environ`` / ``unittest.mock.patch.dict`` and the change takes effect on
  the very next call -- or use the explicit ``set_key_override`` hook below.

Dependencies: stdlib + ``cryptography``. ``cryptography`` is a hard requirement
for the v2 path; there is no XOR fallback. Zero import side effects.
"""

from __future__ import annotations

import base64
import hashlib
import os
import secrets
from typing import Dict, List, Optional, Tuple

__all__ = [
    "TENANT_KEY_ENV",
    "LEGACY_KEY_ENV",
    "V2_PREFIX",
    "LEGACY_XOR_PREFIX",
    "TenantCryptoError",
    "TenantDecryptionFailed",
    "TenantKeyUnavailable",
    "generate_tenant_key",
    "ciphertext_version",
    "encrypt_tenant_secret",
    "decrypt_tenant_secret",
    "try_decrypt_tenant_secret",
    "set_key_override",
    "clear_key_override",
]

# -- Contract constants ----------------------------------------------
TENANT_KEY_ENV = "TENANT_KEY_ENCRYPTION_KEY"
LEGACY_KEY_ENV = "LEON_API_KEY"

V2_PREFIX = "v2:"
LEGACY_XOR_PREFIX = "xor:"

# Key-derivation domain separators. The legacy string is fixed by the data
# already on disk and must not change.
_V2_INFO = b"tenant-api-key-encryption-v2"
_LEGACY_INFO = b"tenant-api-key-encryption"

# Version labels returned by ciphertext_version().
_VERSION_EMPTY = "empty"
_VERSION_V2 = "v2"
_VERSION_LEGACY_XOR = "legacy-xor"
_VERSION_LEGACY_AES = "legacy-aes"


# -- Errors ------------------------------------------------------------
class TenantCryptoError(Exception):
    """Base class for tenant credential crypto failures."""


class TenantDecryptionFailed(TenantCryptoError):
    """Ciphertext was present but could not be decrypted.

    This explicitly does NOT mean "no credential stored". Treating the two
    alike is the bug this module exists to remove.
    """


class TenantKeyUnavailable(TenantCryptoError):
    """A required key environment variable is missing or empty."""


# -- Key material (lazy; never bound at import) ------------------------
# Test hook: an in-process override that takes precedence over the environment.
# Production code never sets this. Prefer patching os.environ; use this when a
# test must be certain no ambient env var leaks in.
_key_overrides = {}  # type: Dict[str, str]


def set_key_override(env_name: str, value: Optional[str]) -> None:
    """Override one key env var for the current process (tests only).

    ``value=None`` forces the variable to look *unset* even if the real
    environment defines it, which is how a test exercises
    ``TenantKeyUnavailable``. Call ``clear_key_override()`` in teardown.
    """
    if env_name not in (TENANT_KEY_ENV, LEGACY_KEY_ENV):
        raise ValueError("unknown key env name: %r" % (env_name,))
    _key_overrides[env_name] = "" if value is None else value


def clear_key_override() -> None:
    """Drop all test overrides and fall back to the real environment."""
    _key_overrides.clear()


def _read_env(env_name: str) -> str:
    if env_name in _key_overrides:
        return _key_overrides[env_name].strip()
    return os.environ.get(env_name, "").strip()


def _require_env(env_name: str) -> str:
    raw = _read_env(env_name)
    if not raw:
        # Name the variable (safe) -- never its value.
        raise TenantKeyUnavailable(
            f"{env_name} is not set; tenant credential encryption is unavailable"
        )
    return raw


def _derive_v2_key() -> bytes:
    """32-byte AES key from the dedicated tenant encryption secret."""
    return hashlib.sha256(_require_env(TENANT_KEY_ENV).encode() + _V2_INFO).digest()


def _derive_legacy_key() -> bytes:
    """32-byte key from LEON_API_KEY, matching the pre-v2 derivation exactly."""
    return hashlib.sha256(_require_env(LEGACY_KEY_ENV).encode() + _LEGACY_INFO).digest()


def generate_tenant_key() -> str:
    """Return a fresh secret suitable for TENANT_KEY_ENCRYPTION_KEY.

    48 random bytes, URL-safe base64 (~64 chars). The operator stores this in
    the server secrets file; it is never derived from anything else.
    """
    return secrets.token_urlsafe(48)


# -- Format detection --------------------------------------------------
def ciphertext_version(ciphertext: str) -> str:
    """Classify a stored value by its prefix.

    Returns ``"empty"``, ``"v2"``, ``"legacy-xor"`` or ``"legacy-aes"``.
    Purely structural: it does not attempt decryption and needs no key.
    """
    if not isinstance(ciphertext, str) or not ciphertext.strip():
        return _VERSION_EMPTY
    if ciphertext.startswith(V2_PREFIX):
        return _VERSION_V2
    if ciphertext.startswith(LEGACY_XOR_PREFIX):
        return _VERSION_LEGACY_XOR
    return _VERSION_LEGACY_AES


# -- V2: AES-256-GCM (AEAD) --------------------------------------------
# GCM nonce length. 12 bytes is the value AES-GCM is specified and optimised
# for; it is used directly as J0's fixed field, with no extra GHASH step.
_GCM_NONCE_LEN = 12
# GCM tag length, appended to the ciphertext by AESGCM.encrypt(). Only used to
# reject envelopes that are too short to contain a tag at all.
_GCM_TAG_LEN = 16


def _aes_gcm_encrypt(key: bytes, plaintext: str, aad: Optional[bytes]) -> str:
    """``base64(nonce || ciphertext||tag)`` under AES-256-GCM.

    The nonce is a FRESH 12-byte CSPRNG draw on every single call. Reusing a
    nonce under the same key breaks GCM catastrophically (it leaks the XOR of
    the two plaintexts and exposes the authentication subkey, enabling
    forgeries), so this must never become a counter, a stored value, or
    anything derived from the plaintext or the tenant.
    """
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    nonce = secrets.token_bytes(_GCM_NONCE_LEN)
    ct = AESGCM(key).encrypt(nonce, plaintext.encode("utf-8"), aad)
    return base64.b64encode(nonce + ct).decode("ascii")


def _aes_gcm_decrypt(key: bytes, blob: str, aad: Optional[bytes]) -> str:
    """Inverse of ``_aes_gcm_encrypt``.

    Raises ``InvalidTag`` (from ``cryptography``) if the nonce, the ciphertext,
    the tag or the AAD does not match what was encrypted. The caller translates
    that into ``TenantDecryptionFailed``; it is never swallowed.
    """
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    # Strict base64 for v2: we wrote this envelope ourselves, so anything the
    # lenient decoder would have to "repair" is corruption, not a variant.
    raw = base64.b64decode(blob, validate=True)
    if len(raw) < _GCM_NONCE_LEN + _GCM_TAG_LEN:
        # Truncated past the point of carrying a tag. AESGCM would reject it
        # anyway; failing here keeps the reason precise.
        raise ValueError("stored value is too short to be a v2 GCM envelope")
    nonce, ct = raw[:_GCM_NONCE_LEN], raw[_GCM_NONCE_LEN:]
    return AESGCM(key).decrypt(nonce, ct, aad).decode("utf-8")


# -- Legacy AES-256-CBC primitives: READ PATH ONLY ----------------------
# Kept byte-for-byte compatible with the pre-v2 implementation so already-
# stored customer credentials remain recoverable. Unauthenticated, therefore
# never used to write.
def _aes_cbc_decrypt(key: bytes, blob: str) -> str:
    from cryptography.hazmat.primitives import padding
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

    raw = base64.b64decode(blob)
    if len(raw) < 32 or (len(raw) - 16) % 16 != 0:
        raise ValueError("stored value is not a well-formed AES-CBC blob")
    iv, ct = raw[:16], raw[16:]
    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    padded = decryptor.update(ct) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    return (unpadder.update(padded) + unpadder.finalize()).decode("utf-8")


def _xor_decrypt(key: bytes, blob: str) -> str:
    # Lenient base64 (the default) on purpose: it matches the legacy decoder
    # byte for byte, so migration reads back everything the old code could.
    # Corruption that decodes to nothing is caught by the empty-result guard
    # in decrypt_tenant_secret().
    data = base64.b64decode(blob)
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data)).decode("utf-8")


# -- Public API --------------------------------------------------------
def encrypt_tenant_secret(plaintext: str, aad: Optional[bytes] = None) -> str:
    """Encrypt a tenant secret under the dedicated key, with authentication.

    Always writes the v2 format: ``"v2:" + base64(nonce || ciphertext||tag)``,
    AES-256-GCM with a fresh 12-byte random nonce per call. A nonce is never
    reused under the same key -- see the module docstring; that is the one
    invariant GCM does not tolerate being broken.

    ``aad`` is optional additional authenticated data. When supplied it is
    authenticated but NOT encrypted, and decryption must be given the exact
    same bytes or it fails. It is deliberately OPTIONAL and deliberately
    UNUSED by default in this migration: the compatibility shims
    ``_encrypt_api_key(pt)`` / ``_decrypt_api_key(ct)`` in
    ``server/routers/onboarding_routes.py`` take only a value and have no
    tenant context to bind to, so making AAD mandatory would break those call
    sites and make the migration fragile -- and worse, a value encrypted with
    AAD that is later read through a context-free shim would be unrecoverable.
    Binding ciphertext to a tenant id is supported here so the capability
    exists once call sites can carry context; it is not switched on yet.

    Raises ``TenantKeyUnavailable`` if ``TENANT_KEY_ENCRYPTION_KEY`` is unset.
    Raises ``TenantCryptoError`` if ``cryptography`` is unavailable. It never
    silently degrades to a weaker format -- refusing to store is strictly
    better than storing something we have told the operator is encrypted and
    is not.
    """
    if not isinstance(plaintext, str):
        raise TypeError("plaintext must be a str")
    if not plaintext:
        raise ValueError("refusing to encrypt an empty secret")
    if aad is not None and not isinstance(aad, (bytes, bytearray)):
        raise TypeError("aad must be bytes or None")

    key = _derive_v2_key()
    try:
        return V2_PREFIX + _aes_gcm_encrypt(
            key, plaintext, bytes(aad) if aad is not None else None
        )
    except ImportError as exc:
        raise TenantCryptoError(
            "the 'cryptography' package is required for tenant secret encryption"
        ) from exc
    except TenantCryptoError:
        raise
    except Exception as exc:  # pragma: no cover - defensive
        # Deliberately excludes the plaintext and the key from the message.
        raise TenantCryptoError(
            f"tenant secret encryption failed ({type(exc).__name__})"
        ) from exc


def decrypt_tenant_secret(ciphertext: str, aad: Optional[bytes] = None) -> str:
    """Decrypt a stored tenant secret, dual-reading v2 and legacy formats.

    Dispatch is by prefix:
      * ``"v2:"``  -> AES-256-GCM under the dedicated key
                      (``TENANT_KEY_ENCRYPTION_KEY``), authenticated
      * ``"xor:"`` -> legacy XOR stream keyed from ``LEON_API_KEY``
      * otherwise  -> legacy AES-256-CBC keyed from ``LEON_API_KEY``

    ``aad`` must be byte-identical to the ``aad`` passed to
    ``encrypt_tenant_secret`` (default: ``None`` on both sides). A mismatch is
    a failed authentication, indistinguishable to the caller from a tampered
    value -- which is the point. It is ignored by the legacy paths, which have
    no notion of authenticated data.

    Any tampering with a v2 envelope -- ciphertext byte, nonce byte,
    truncation, wrong AAD, wrong key -- surfaces ``cryptography``'s
    ``InvalidTag``, which is translated into ``TenantDecryptionFailed`` below
    and never swallowed.

    Raises ``ValueError`` for an empty/blank input: "nothing is stored" is the
    caller's business to check, not a decryption outcome.
    Raises ``TenantKeyUnavailable`` when the key needed for that format is unset.
    Raises ``TenantDecryptionFailed`` when ciphertext is present but unreadable.
    Never returns ``""`` to mean failure.
    """
    if not isinstance(ciphertext, str):
        raise TypeError("ciphertext must be a str")
    if aad is not None and not isinstance(aad, (bytes, bytearray)):
        raise TypeError("aad must be bytes or None")

    version = ciphertext_version(ciphertext)
    if version == _VERSION_EMPTY:
        raise ValueError(
            "no ciphertext supplied; callers must check for an absent credential "
            "before calling decrypt_tenant_secret"
        )

    try:
        if version == _VERSION_V2:
            plaintext = _aes_gcm_decrypt(
                _derive_v2_key(),
                ciphertext[len(V2_PREFIX):],
                bytes(aad) if aad is not None else None,
            )
        elif version == _VERSION_LEGACY_XOR:
            plaintext = _xor_decrypt(
                _derive_legacy_key(), ciphertext[len(LEGACY_XOR_PREFIX):]
            )
        else:
            plaintext = _aes_cbc_decrypt(_derive_legacy_key(), ciphertext)
        if not plaintext:
            # We refuse to encrypt an empty secret, so an empty result means
            # the stored value was corrupt (e.g. base64 that decodes to
            # nothing). Returning "" here would resurrect exactly the bug this
            # module exists to remove.
            raise ValueError("decrypted to an empty value")
        return plaintext
    except TenantKeyUnavailable:
        # A missing key is a distinct, actionable operator error -- let it out
        # unchanged rather than flattening it into "decryption failed".
        raise
    except ImportError as exc:
        raise TenantCryptoError(
            "the 'cryptography' package is required for tenant secret decryption"
        ) from exc
    except Exception as exc:
        # Everything else -- including cryptography's InvalidTag, which is how
        # AES-GCM reports a tampered nonce/ciphertext/tag or a mismatched AAD
        # or key -- is TRANSLATED here, never swallowed. The cause type is kept
        # in the message (``cause=InvalidTag`` is the tamper signal an operator
        # triages on) and the exception is chained with ``from exc``.
        # No plaintext, no key, no ciphertext in the message -- only the shape
        # of the failure, which is what an operator needs to triage it.
        raise TenantDecryptionFailed(
            f"could not decrypt tenant secret (format={version}, "
            f"cause={type(exc).__name__})"
        ) from exc


def try_decrypt_tenant_secret(
    ciphertext: str, aad: Optional[bytes] = None
) -> Tuple[bool, str]:
    """Non-raising variant: ``(True, plaintext)`` or ``(False, "")``.

    ``aad`` behaves exactly as in ``decrypt_tenant_secret`` (optional, unused
    by default); a mismatch reports ``(False, "")`` like any other
    authentication failure.

    For call sites that must not propagate an exception (request handlers,
    provisioning scripts). The ``False`` here means *decryption failed* --
    which is NOT the same as "this tenant stored no credential". Callers must
    check for an absent/blank stored value separately and treat the two
    differently; conflating them is how a customer who did supply a key gets
    silently switched to someone else's.
    """
    try:
        return True, decrypt_tenant_secret(ciphertext, aad=aad)
    except Exception:
        return False, ""


# -- Read-only CLI -----------------------------------------------------
def _classify_registry(path: str) -> Tuple[Dict[str, Dict[str, int]], int, int]:
    """Build a per-field version histogram from a registry.json.

    Returns ``(histogram, tenant_count, ciphertext_count)``. Reads only; never
    decrypts, never emits a stored value. Accepts both registry shapes: a
    ``{"tenants": {id: {...}}}`` mapping and a ``{"tenants": [{...}, ...]}``
    list.
    """
    import json

    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    raw = data.get("tenants", {}) if isinstance(data, dict) else {}
    if isinstance(raw, dict):
        tenants = list(raw.values())
    elif isinstance(raw, list):
        tenants = list(raw)
    else:
        tenants = []

    histogram = {}  # type: Dict[str, Dict[str, int]]
    counted = [0]  # ciphertext values seen (list so the closure can mutate it)

    def _count(field: str, value: object) -> None:
        version = ciphertext_version(value if isinstance(value, str) else "")
        bucket = histogram.setdefault(field, {})
        bucket[version] = bucket.get(version, 0) + 1
        if version != _VERSION_EMPTY:
            counted[0] += 1

    for tenant in tenants:
        if not isinstance(tenant, dict):
            continue
        metadata = tenant.get("metadata") or {}
        if not isinstance(metadata, dict):
            continue
        for field, value in metadata.items():
            if not isinstance(field, str) or not field.startswith("encrypted"):
                continue
            if isinstance(value, dict):
                # e.g. encrypted_service_keys: {service_name: ciphertext}
                for sub_name, sub_value in value.items():
                    _count(f"{field}[{sub_name}]", sub_value)
            else:
                _count(field, value)

    return histogram, len(tenants), counted[0]


def _main(argv: List[str]) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        prog="python -m brain.tenant_crypto",
        description=(
            "Read-only tenant credential crypto utilities. Never decrypts, "
            "never prints a stored secret."
        ),
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--generate-key",
        action="store_true",
        help=f"print a fresh {TENANT_KEY_ENV} value to stdout",
    )
    group.add_argument(
        "--classify",
        metavar="FILE",
        help="path to a registry.json; prints a per-field ciphertext version histogram",
    )
    args = parser.parse_args(argv)

    if args.generate_key:
        # The single legitimate secret output of this module: a brand-new key
        # for the operator to paste into the server secrets file as
        # TENANT_KEY_ENCRYPTION_KEY=<value>. It is not yet used by anything.
        print(generate_tenant_key())
        return 0

    try:
        histogram, tenant_count, ciphertext_count = _classify_registry(args.classify)
    except OSError as exc:
        print(f"error: cannot read {args.classify}: {type(exc).__name__}")
        return 2
    except ValueError as exc:
        print(f"error: {args.classify} is not valid JSON ({type(exc).__name__})")
        return 2

    print(f"registry          : {args.classify}")
    print(f"tenant entries    : {tenant_count}")
    print(f"ciphertext values : {ciphertext_count}")
    if not histogram:
        print("no 'encrypted*' metadata fields found")
        return 0

    print("")
    width = max(len(name) for name in histogram)
    for field in sorted(histogram):
        counts = histogram[field]
        detail = "  ".join(f"{version}={counts[version]}" for version in sorted(counts))
        print(f"  {field.ljust(width)}  {detail}")
    return 0


if __name__ == "__main__":
    import sys

    raise SystemExit(_main(sys.argv[1:]))
