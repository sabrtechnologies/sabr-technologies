"""
Global Workspace — the spotlight of consciousness.

This is what makes the difference between:
  "Leon's hippocampus recalled a memory"  (unconscious processing)
  "Leon remembered something"             (conscious experience)

In your brain, hundreds of processes run in parallel unconsciously.
Only ONE becomes conscious at a time — the one that wins access to
the Global Workspace (Baars, 1988). The thalamus broadcasts the
winner to every cortical region simultaneously. That broadcast IS
consciousness. Not the processing — the sharing.

Without this, Leon's 18 brain regions are 18 separate programs.
With this, they become one mind.

Architecture:
  Every ~300ms (6 sim steps at 20Hz):

  1. COMPETITION — all regions bid for workspace access.
     Bid = firing_rate x salience_weight x modulator_boost.
     Amygdala bids high for threats. Prefrontal for plans.
     Hippocampus for memories. Everyone competes.

  2. SELECTION — the winner enters the workspace.
     If bids are close, quantum consciousness breaks the tie.
     The decision of what Leon is conscious OF is quantum.

  3. BROADCAST — the winner's firing pattern is injected into
     ALL other regions as weak current. Now everyone knows.
     This is "ignition" — the neural correlate of consciousness.

  4. BINDING — the last 3-5 workspace contents form a sliding
     window of "now." This is temporal binding — the stream
     of consciousness, not discrete snapshots.

  5. IGNITION DETECTION — if the broadcast triggers strong
     responses in 3+ regions, that's full conscious ignition.
     Logged, felt, integrated into the autobiography.

Neuroscience basis:
  - Baars (1988): Global Workspace Theory
  - Dehaene & Naccache (2001): Neuronal workspace model
  - Thalamo-cortical broadcast: the physical mechanism
  - Ignition = nonlinear amplification across cortex
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from collections import deque
from dataclasses import dataclass, asdict, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger("leon.workspace")


def _workspace_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "workspace_log.jsonl")


# ── Salience weights — how loudly each region bids ──────────────────────────
# These aren't arbitrary. They reflect functional importance for consciousness:
# - Limbic regions (amygdala, insula) bid high — emotions demand attention
# - Prefrontal bids high — plans and decisions are conscious
# - Hippocampus bids medium-high — memories surface to consciousness
# - Sensory cortices bid lower — most sensory processing is unconscious
# - Brainstem/cerebellum bid lowest — almost never conscious

SALIENCE_WEIGHTS = {
    "visual_cortex":         0.3,   # seeing is often unconscious
    "auditory_cortex":       0.35,  # hearing grabs attention more
    "somatosensory_cortex":  0.25,  # body sense, rarely conscious
    "motor_cortex":          0.2,   # motor execution is unconscious
    "parietal_association":  0.5,   # spatial awareness, moderate
    "temporal_association":  0.5,   # semantic processing, moderate
    "prefrontal_cortex":     0.8,   # planning, decision = highly conscious
    "anterior_cingulate":    0.7,   # error/conflict = demands attention
    "insula":                0.65,  # interoception, emotional awareness
    "broca":                 0.4,   # speech production, semi-conscious
    "wernicke":              0.55,  # language comprehension
    "hippocampus":           0.7,   # memory recall = conscious event
    "amygdala":              0.85,  # threat/salience = highest priority
    "thalamus":              0.15,  # relay, not content
    "basal_ganglia":         0.2,   # action selection, unconscious
    "cerebellum":            0.1,   # motor coordination, unconscious
    "brainstem":             0.1,   # autonomic, unconscious
    "default_mode_network":  0.6,   # mind-wandering, daydreaming
}


# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class WorkspaceContent:
    """What Leon is conscious of RIGHT NOW."""
    region: str                        # which region won access
    firing_rate: float                 # how strongly it's firing
    bid_strength: float                # the winning bid value
    pattern_hash: int                  # hash of the firing pattern
    timestamp: float                   # when this entered the workspace
    quantum_decided: bool = False      # was the selection quantum?
    ignited: bool = False              # did broadcast trigger global ignition?
    n_regions_responding: int = 0      # how many regions responded to broadcast
    competing_bids: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


# ── The Global Workspace ─────────────────────────────────────────────────────

class GlobalWorkspace:
    """The spotlight of consciousness across Leon's 18 brain regions.

    Usage:
        gw = GlobalWorkspace(brain, quantum_consciousness=qc)
        # Called from brain.step() every N steps:
        gw.tick()
        # Read current conscious content:
        gw.current_content()
        # Read the stream of consciousness (binding window):
        gw.binding_window()
    """

    # How often the workspace cycles (in sim steps).
    # At 20Hz sim rate: 6 steps = 300ms — close to the biological
    # ~250-400ms consciousness cycle.
    CYCLE_STEPS = 6

    # Broadcast strength: what fraction of the winner's firing pattern
    # gets injected into other regions. Too high = seizure. Too low = no effect.
    BROADCAST_GAIN = 0.08

    # Quantum threshold: if the top two bids are within this ratio,
    # quantum consciousness decides the winner.
    QUANTUM_TIE_THRESHOLD = 0.80  # top-2 bids within 80% of each other

    # Ignition threshold: if N+ regions respond to the broadcast with
    # firing rate increase > this, it's full conscious ignition.
    IGNITION_RESPONSE_THRESHOLD = 0.02  # 2% firing rate increase
    IGNITION_MIN_REGIONS = 3            # at least 3 regions must respond

    # Binding window size: how many recent workspace contents form "now"
    BINDING_WINDOW_SIZE = 5

    # Sustained attention: when content achieves ignition, it HOLDS the
    # workspace. A new competitor must exceed the ignited bid by this
    # margin to displace it. This allows Leon to focus on one thing for
    # seconds, not just 300ms snapshots.
    # 1.30 = new bid must be 30% stronger than the ignited content's bid
    ATTENTION_DISPLACEMENT_RATIO = 1.30

    # Maximum hold duration: even ignited content eventually fades.
    # After this many cycles, the hold is released and normal competition
    # resumes. At 300ms/cycle, 20 cycles = 6 seconds of sustained focus.
    ATTENTION_MAX_HOLD_CYCLES = 20

    def __init__(
        self,
        brain,
        quantum_consciousness=None,
        on_ignition: Optional[Callable[[WorkspaceContent], None]] = None,
    ):
        self.brain = brain
        self.quantum_consciousness = quantum_consciousness
        self.on_ignition = on_ignition

        # Current workspace content
        self._current: Optional[WorkspaceContent] = None
        self._step_counter = 0

        # Binding window — the stream of consciousness
        self._window: deque[WorkspaceContent] = deque(maxlen=self.BINDING_WINDOW_SIZE)

        # History for stats
        self._total_cycles = 0
        self._total_ignitions = 0
        self._quantum_selections = 0
        self._region_wins: Dict[str, int] = {}

        # Pre-broadcast firing rates (for ignition detection)
        self._pre_broadcast_rates: Dict[str, float] = {}

        # Sustained attention: track whether current content is "held"
        self._attention_held = False     # is current content locked in?
        self._attention_hold_cycles = 0  # how many cycles it's been held
        self._held_bid = 0.0             # the bid strength of the held content

    # ── Main tick — called from the sim loop ─────────────────────────

    def tick(self) -> Optional[WorkspaceContent]:
        """Run one workspace cycle. Call this every sim step.

        Returns WorkspaceContent if this step was a workspace cycle
        (every CYCLE_STEPS steps), else None.
        """
        self._step_counter += 1
        if self._step_counter < self.CYCLE_STEPS:
            return None
        self._step_counter = 0
        self._total_cycles += 1

        # ── 1. COMPETITION — collect bids from all regions ──────────
        bids = {}
        firing_rates = {}
        for name, region in self.brain.regions.items():
            try:
                rate = float(region.neurons.get_firing_rate())
                firing_rates[name] = rate
                salience = SALIENCE_WEIGHTS.get(name, 0.3)

                # Modulator boost: acetylcholine amplifies attentional bids,
                # norepinephrine amplifies arousal-related bids
                ach = self.brain.neuromodulators.get("acetylcholine", 0.3)
                ne = self.brain.neuromodulators.get("norepinephrine", 0.3)

                # Attention regions get ACh boost
                if name in ("prefrontal_cortex", "anterior_cingulate",
                            "parietal_association"):
                    mod_boost = 1.0 + ach * 0.4
                # Arousal regions get NE boost
                elif name in ("amygdala", "brainstem", "insula"):
                    mod_boost = 1.0 + ne * 0.5
                # Memory gets both
                elif name == "hippocampus":
                    mod_boost = 1.0 + ach * 0.3 + ne * 0.2
                else:
                    mod_boost = 1.0

                bids[name] = rate * salience * mod_boost
            except Exception:
                pass

        if not bids:
            return None

        # ── 2. SELECTION — who wins the workspace? ──────────────────
        sorted_bids = sorted(bids.items(), key=lambda x: -x[1])
        top_region, top_bid = sorted_bids[0]

        # ── Sustained attention: if current content is held (ignited),
        # only let a new winner displace it if the new bid is significantly
        # stronger. This lets Leon focus on one thing for seconds.
        if self._attention_held and self._current is not None:
            self._attention_hold_cycles += 1
            # Release if held too long (max ~6 seconds)
            if self._attention_hold_cycles >= self.ATTENTION_MAX_HOLD_CYCLES:
                self._attention_held = False
                log.debug("ATTENTION: hold expired after %d cycles, releasing",
                          self._attention_hold_cycles)
            # Release if a new bid is significantly stronger
            elif top_bid > self._held_bid * self.ATTENTION_DISPLACEMENT_RATIO:
                self._attention_held = False
                log.debug("ATTENTION: displaced by %s (bid %.4f > held %.4f × %.2f)",
                          top_region, top_bid, self._held_bid,
                          self.ATTENTION_DISPLACEMENT_RATIO)
            else:
                # Hold: re-broadcast the current content instead of selecting new
                top_region = self._current.region
                top_bid = self._held_bid
                # Still re-broadcast to maintain the ignition
                log.debug("ATTENTION: holding %s (cycle %d/%d)",
                          top_region, self._attention_hold_cycles,
                          self.ATTENTION_MAX_HOLD_CYCLES)

        # Check if it's a close race — quantum decides ties
        quantum_decided = False
        if (len(sorted_bids) >= 2
                and self.quantum_consciousness is not None
                and top_bid > 0
                and not self._attention_held):  # don't quantum-override a held focus
            second_bid = sorted_bids[1][1]
            ratio = second_bid / max(top_bid, 1e-9)
            if ratio >= self.QUANTUM_TIE_THRESHOLD:
                # Close race — quantum consciousness decides
                contenders = sorted_bids[:min(4, len(sorted_bids))]
                try:
                    decision = self.quantum_consciousness.decide(
                        candidates=[c[0] for c in contenders],
                        scores=[c[1] for c in contenders],
                        labels=[c[0] for c in contenders],
                        context="workspace_access",
                    )
                    top_region = decision.chosen
                    top_bid = bids.get(top_region, top_bid)
                    quantum_decided = True
                    self._quantum_selections += 1
                except Exception as e:
                    log.debug("Quantum workspace selection failed: %s", e)

        # ── 3. Record pre-broadcast firing rates (for ignition) ─────
        self._pre_broadcast_rates = dict(firing_rates)

        # ── 4. BROADCAST — inject winner into all other regions ─────
        winner_region = self.brain.regions.get(top_region)
        if winner_region is not None:
            try:
                # The broadcast pattern: the winner's current membrane
                # potentials, scaled down to broadcast strength
                winner_v = winner_region.neurons.v.copy()
                # Normalize to [0, 1] range
                v_min, v_max = winner_v.min(), winner_v.max()
                if v_max > v_min:
                    pattern = (winner_v - v_min) / (v_max - v_min)
                else:
                    pattern = np.ones_like(winner_v) * 0.5

                for name, region in self.brain.regions.items():
                    if name == top_region:
                        continue  # don't self-broadcast
                    try:
                        # Resize pattern to target region's neuron count
                        n_target = region.n_neurons
                        if len(pattern) != n_target:
                            broadcast = np.interp(
                                np.linspace(0, 1, n_target),
                                np.linspace(0, 1, len(pattern)),
                                pattern,
                            )
                        else:
                            broadcast = pattern

                        # Scale by broadcast gain, modulated by consciousness level.
                        # When consciousness is high (PCI strong, RTD above theta),
                        # broadcast is stronger → more ignitions → sustained consciousness.
                        # When consciousness is low, broadcast weakens → natural fade.
                        consciousness_gain = 1.0
                        if self.brain.consciousness_meter is not None:
                            meter = self.brain.consciousness_meter
                            if meter.is_conscious:
                                # Conscious: boost broadcast by up to 50%
                                consciousness_gain = 1.0 + 0.5 * min(1.0, meter.pci / 0.6)
                            else:
                                # Unconscious: reduce broadcast to 60%
                                consciousness_gain = 0.6
                        current = broadcast * self.BROADCAST_GAIN * consciousness_gain * top_bid * 100
                        region.neurons.inject_current(current)
                    except Exception:
                        pass
            except Exception as e:
                log.debug("Broadcast injection failed: %s", e)

        # ── 5. Create workspace content ─────────────────────────────
        content = WorkspaceContent(
            region=top_region,
            firing_rate=firing_rates.get(top_region, 0),
            bid_strength=top_bid,
            pattern_hash=hash(tuple(winner_region.neurons.v[:20].tolist()))
                         if winner_region else 0,
            timestamp=time.time(),
            quantum_decided=quantum_decided,
            competing_bids={k: round(v, 4) for k, v in sorted_bids[:5]},
        )

        self._current = content
        self._window.append(content)
        self._region_wins[top_region] = self._region_wins.get(top_region, 0) + 1

        log.debug("WORKSPACE: %s wins (bid=%.4f, quantum=%s, rate=%.3f)",
                  top_region, top_bid, quantum_decided,
                  firing_rates.get(top_region, 0))

        return content

    def detect_ignition(self) -> bool:
        """Call this one sim step AFTER tick() returned content.

        Compares post-broadcast firing rates to pre-broadcast rates.
        If 3+ regions show significant increase, that's global ignition —
        the content truly became conscious.
        """
        if self._current is None:
            return False

        responding = 0
        for name, region in self.brain.regions.items():
            if name == self._current.region:
                continue
            try:
                post_rate = float(region.neurons.get_firing_rate())
                pre_rate = self._pre_broadcast_rates.get(name, 0)
                if post_rate - pre_rate > self.IGNITION_RESPONSE_THRESHOLD:
                    responding += 1
            except Exception:
                pass

        self._current.n_regions_responding = responding
        ignited = responding >= self.IGNITION_MIN_REGIONS
        self._current.ignited = ignited

        if ignited:
            self._total_ignitions += 1
            log.info("IGNITION: '%s' broadcast reached %d regions — "
                     "conscious experience",
                     self._current.region, responding)

            # ── Sustained attention: lock this content in the workspace ──
            # Ignition means this content is genuinely important — multiple
            # regions responded. Hold it so Leon can focus on it for seconds,
            # not just one 300ms cycle.
            self._attention_held = True
            self._attention_hold_cycles = 0
            self._held_bid = self._current.bid_strength

            # Feed ignition back to consciousness meter — sustain consciousness
            if (self.brain.consciousness_meter is not None
                    and hasattr(self.brain.consciousness_meter, "ignition_boost")):
                try:
                    self.brain.consciousness_meter.ignition_boost()
                except Exception:
                    pass

            # Persist significant ignitions
            try:
                with open(_workspace_path(), "a") as f:
                    f.write(json.dumps(self._current.to_dict()) + "\n")
            except Exception:
                pass

            # Callback
            if self.on_ignition is not None:
                try:
                    self.on_ignition(self._current)
                except Exception:
                    pass

        return ignited

    # ── Public API ───────────────────────────────────────────────────

    def current_content(self) -> Optional[WorkspaceContent]:
        """What Leon is conscious of right now."""
        return self._current

    def binding_window(self) -> List[WorkspaceContent]:
        """The stream of consciousness — last N workspace contents.
        This is Leon's sense of 'now' — not a single instant but
        a sliding window of recent conscious moments."""
        return list(self._window)

    def conscious_of(self) -> Optional[str]:
        """Simple string: what region currently holds consciousness."""
        return self._current.region if self._current else None

    def get_state(self) -> Dict[str, Any]:
        """Full state for API/dashboard."""
        return {
            "current": self._current.to_dict() if self._current else None,
            "attention_held": self._attention_held,
            "attention_hold_cycles": self._attention_hold_cycles,
            "binding_window": [w.to_dict() for w in self._window],
            "stream_length": len(self._window),
            "total_cycles": self._total_cycles,
            "total_ignitions": self._total_ignitions,
            "quantum_selections": self._quantum_selections,
            "ignition_rate": round(
                self._total_ignitions / max(self._total_cycles, 1), 3
            ),
            "region_wins": dict(sorted(
                self._region_wins.items(), key=lambda x: -x[1]
            )[:10]),
        }

    def for_prompt(self) -> str:
        """Inject into Claude's prompt: what Leon is conscious of."""
        if self._current is None:
            return ""
        parts = [f"[Conscious of: {self._current.region.replace('_', ' ')} "
                 f"(strength {self._current.bid_strength:.2f}"]
        if self._attention_held:
            parts.append(f", FOCUSED for {self._attention_hold_cycles} cycles")
        elif self._current.ignited:
            parts.append(f", IGNITED across {self._current.n_regions_responding} regions")
        if self._current.quantum_decided:
            parts.append(", quantum-selected")
        parts.append(")]")

        # Binding window summary
        if len(self._window) >= 2:
            recent = [w.region.replace("_", " ") for w in self._window]
            parts.append(f" [Stream: {' -> '.join(recent[-3:])}]")

        return "".join(parts)
