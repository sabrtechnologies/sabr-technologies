"""
Leon persistent Claude session — one long-lived `claude -p` subprocess that
handles every text/voice turn, eliminating the 3-5s cold-start each turn used
to pay. After the first message, warm turns return in ~1-2s.

Wire:
    session = LeonClaudeSession(
        system_prompt=_LEON_SYSTEM_PROMPT_SHORT,
        mcp_config_json=_LEON_MCP_CONFIG_JSON,
        model="haiku",
    )
    for ev in session.ask(user_text):
        yield ev  # StreamEvent type=model/delta/sentence/tool_use/tool_result/done/error

Auto-restart on process death. Single-threaded turns (a lock serializes them).
Disable with LEON_PERSISTENT_CLAUDE=0 to fall back to the one-shot path.
"""
from __future__ import annotations

import json
import logging
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional

log = logging.getLogger("leon-session")

# Re-use the responder's sentence regex so per-sentence TTS lines up with the
# rest of the pipeline. Imported lazily to avoid circular import.
_SENTENCE_END_RE: Optional[re.Pattern] = None
_StreamEvent = None  # type imported lazily


def _lazy_imports():
    global _SENTENCE_END_RE, _StreamEvent
    if _SENTENCE_END_RE is None:
        from brain.claude_api_responder import _SENTENCE_END_RE as _RE, StreamEvent as _SE
        _SENTENCE_END_RE = _RE
        _StreamEvent = _SE


def _prune_stale_system_prompts(max_age_s: int = 3600) -> int:
    """Delete this user's orphaned leon-sysprompt-* temp files.

    Only files we own (POSIX /tmp is shared — this laptop literally has two
    people with two SIs on it) and only ones older than max_age_s, so a
    sibling process that just started is never robbed of its prompt file.
    """
    import glob as _glob
    tmp = tempfile.gettempdir()
    try:
        me = os.getuid()
    except AttributeError:
        me = None                      # Windows %TEMP% is already per-user
    now = time.time()
    n = 0
    for pattern in ("leon-sysprompt-*.txt", "leon-sysprompt-oneshot-*.txt"):
        for path in _glob.glob(os.path.join(tmp, pattern)):
            try:
                st = os.stat(path)
                if me is not None and st.st_uid != me:
                    continue
                if now - st.st_mtime < max_age_s:
                    continue
                os.remove(path)
                n += 1
            except OSError:
                pass
    if n:
        log.info("pruned %d stale system-prompt temp file(s)", n)
    return n


@dataclass
class _TurnState:
    """Per-turn accumulator. Reader thread fills it; producer drains via queue."""
    response_chunks: List[str] = field(default_factory=list)
    sentence_buf: str = ""
    sentence_idx: int = 0
    active_tool: Optional[Dict] = None
    done: bool = False
    error: Optional[str] = None
    queue: "queue.Queue" = field(default_factory=queue.Queue)
    #: monotonic time of the last line the child wrote for this turn. The
    #: reader thread touches it on EVERY line (thinking, tool json, text),
    #: not only on lines that become StreamEvents -- liveness is "the child
    #: is still talking", not "the owner got a token".
    last_activity: float = field(default_factory=time.monotonic)


#: How long one turn may hold the session before a waiter gives up. Generous
#: on purpose: a real tool-heavy turn can legitimately run for minutes, and a
#: false timeout would kill good work. This exists to break a WEDGE, not to
#: police slow turns — anything past this is a leak, not a long thought.
#: 2026-09-15: raised from 300 to sit above the turn hard ceiling below. A
#: legitimately long working turn can now run up to _TURN_HARD_CEILING_S; a
#: waiter that gave up before that would fail a good turn, not break a wedge.
#: A real wedge is now cleared by the IDLE deadline in ask() (silence for
#: `timeout` seconds), which releases this lock long before this fires.
_SESSION_LOCK_TIMEOUT_S = float(os.environ.get("LEON_SESSION_LOCK_TIMEOUT_S", "1300"))

#: Turn deadlines are IDLE-based, not wall-clock-from-send (2026-09-15).
#: The old rule was "90s after the prompt went in, kill the child" -- so any
#: turn where the SI actually WORKED (chained mcp tools, SSH, file edits) was
#: killed mid-job while tool_use/tool_result events were streaming the whole
#: time, reported to the owner as "my reasoning engine timed out", and the
#: killed child took its in-context work with it ("he forgets where we're
#: at"). 30+ such kills in one si.log. A stall is SILENCE, not duration.
#:   - `timeout` (per ask()) = how long the child may be silent.
#:   - while a tool call is in flight (tool_use emitted, no tool_result yet)
#:     the child is legitimately silent for as long as the tool runs, so the
#:     idle budget widens to at least _TOOL_IDLE_S.
#:   - _TURN_HARD_CEILING_S caps total turn time so a noisy-but-runaway child
#:     is still bounded. Mirrors the one-shot path's max(timeout*4, 900).
_TURN_HARD_CEILING_S = float(os.environ.get("LEON_TURN_HARD_CEILING_S", "900"))
_TOOL_IDLE_S = float(os.environ.get("LEON_TOOL_IDLE_S", "300"))


def _is_cli_control_limit(text: str) -> bool:
    """Recognize Claude Code's standalone limit notice.

    Claude Code can return a quota notice in a result envelope marked
    ``success``. It is control output, not an answer Leon should speak. Keep
    this stricter than the responder's broad quota detector: a real answer
    may discuss weekly or session limits.
    """
    low = " ".join(str(text or "").strip().casefold().replace("’", "'").split())
    if len(low) > 240:
        return False
    return low.startswith((
        "you've hit your session limit",
        "you've hit your weekly limit",
        "you've hit your opus limit",
        "you've hit your sonnet limit",
        "you've hit your limit",
        "claude usage limit reached",
        "weekly limit reached",
        "error: 429",
        "rate_limit_error",
    ))


class _BoundedLock:
    """A Lock whose `with` block refuses to wait forever.

    Drop-in for threading.Lock at the `with` sites, so the fix is one line at
    construction instead of a re-indent of every holder. On timeout it raises
    TimeoutError, which surfaces as a failed turn — recoverable — instead of a
    thread parked for the life of the process, which is not.
    """

    __slots__ = ("_l", "_t")

    def __init__(self, timeout: float):
        self._l = threading.Lock()
        self._t = timeout

    def __enter__(self):
        if not self._l.acquire(timeout=self._t):
            raise TimeoutError(
                f"claude session lock held >{self._t:.0f}s — treating as a "
                f"leaked turn and failing this one rather than blocking forever"
            )
        return self

    def __exit__(self, *_exc):
        try:
            self._l.release()
        except RuntimeError:
            pass  # already released; never mask the real exception
        return False

    # Some callers probe the lock directly.
    def locked(self) -> bool:
        return self._l.locked()


class LeonClaudeSession:
    """One persistent `claude -p` subprocess; serializes turns via a lock."""

    def __init__(
        self,
        system_prompt: str,
        mcp_config_json: Optional[str] = None,
        model: str = "haiku",
        effort: str = "low",
        tool_risk_map: Optional[Dict[str, str]] = None,
        bridge_role: str = "chat",
    ):
        _lazy_imports()
        self.system_prompt = system_prompt
        self.mcp_config_json = mcp_config_json
        self.model = model
        self.effort = effort
        # "chat" (Dean's conversation) or "daemon" (inner voice, dreaming...).
        # The laptop bridge applies the dashboard's chat preference only to chat.
        self.bridge_role = bridge_role
        self.tool_risk_map = tool_risk_map or {}

        self._proc: Optional[subprocess.Popen] = None
        from brain.bridge_lifecycle import track_session
        track_session(self)
        self._system_prompt_path: Optional[str] = None
        self._reader: Optional[threading.Thread] = None
        # BOUNDED, not infinite. ask() yields from inside `with self._lock:`,
        # so any consumer that abandons the generator mid-turn strands this
        # lock held. With a plain Lock that is terminal: every later turn
        # blocks here forever, the server-level responder lock is never
        # released either, and the owner gets "give me a second" on every
        # message for the life of the process (measured on a customer Windows
        # box 2026-08-11 — two threads parked here, zero conversations in two
        # hours). The generator close() calls added the same day remove the
        # known leaks; this is the backstop for the ones not found yet. A
        # leaked lock should cost ONE turn, never the whole mind.
        self._lock = _BoundedLock(_SESSION_LOCK_TIMEOUT_S)
        self._turn: Optional[_TurnState] = None
        self._turn_lock = threading.RLock()  # protects turn and reader ownership
        self._dead = False
        self._cold_start_done = threading.Event()
        # Turns served by the CURRENT child. The responder reads this to
        # recycle aged sessions before unbounded context growth pushes turn
        # latency past the 90s deadline. start() resets it with the child.
        self.turns_served = 0

    # ── Lifecycle ────────────────────────────────────────────────────────

    def start(self) -> None:
        """Spawn the subprocess. Idempotent — no-op if already running."""
        with self._lock:
            if self._proc is not None and self._proc.poll() is None:
                return
            # Absolute path, never the bare name: a frozen launch-time PATH
            # (a customer's box, 2026-08-29) or an npm claude.cmd on Windows
            # (CreateProcess only appends .exe) makes ["claude", ...] fail
            # while every which()-based health check passes.
            from brain import engine_health as _engine
            # System prompt goes through a FILE, never inline on argv.
            # Found on a customer's Windows box (2026-08-29): the npm
            # `claude` install there resolves to claude.CMD, a batch shim,
            # and Windows' cmd.exe caps a whole command line at 8,191 chars.
            # Leon's system prompt alone runs ~8,749 chars, so
            # `--system-prompt <text>` silently overflowed the shim on every
            # launch — the CLI never started, and the only symptom the owner
            # saw was the timeout handler's canned "still processing" reply,
            # for the SI's entire lifetime. A file path is a few dozen chars
            # regardless of prompt size, so this can't recur at any prompt
            # length, on any OS. One file per session start; stop() removes it.
            # Sweep orphans from previous lives BEFORE writing a new one.
            #
            # The comment above says "stop() removes it" — and stop() does.
            # But stop() only runs on a GRACEFUL shutdown, and a mind that
            # gets SIGKILLed, OOM-killed, or power-cut never reaches it. Each
            # such death orphans one 9KB file containing the SI's full system
            # prompt, which names its owner. Measured on the live VPS
            # 2026-09-04: 95 of them. Measured on a customer machine after a
            # SUCCESSFUL uninstall: 11 still on disk.
            #
            # One hour is the safety margin: anything younger could belong to
            # a sibling process starting up right now (the one-shot responder
            # writes the same shape), and deleting a live session's prompt
            # file would strip that mind of its identity mid-run.
            _prune_stale_system_prompts()

            try:
                _sp_fd, self._system_prompt_path = tempfile.mkstemp(
                    prefix="leon-sysprompt-", suffix=".txt",
                    dir=tempfile.gettempdir())
                with os.fdopen(_sp_fd, "w", encoding="utf-8") as _f:
                    _f.write(self.system_prompt)
            except OSError as e:
                # Can't write a temp file at all -- fall back to inline argv
                # rather than fail to start outright. Rare (disk full / no
                # write perms on tmp), and inline at least works on platforms
                # without the shim cap.
                log.error("could not write system-prompt temp file (%s: %s); "
                          "falling back to inline --system-prompt", type(e).__name__, e)
                self._system_prompt_path = None
            argv = [
                _engine.resolve(), "-p",
                "--input-format", "stream-json",
                "--output-format", "stream-json",
                "--include-partial-messages",
                "--verbose",
                "--model", self.model,
                "--effort", self.effort,
                "--no-session-persistence",
            ]
            if self._system_prompt_path:
                argv += ["--system-prompt-file", self._system_prompt_path]
            else:
                argv += ["--system-prompt", self.system_prompt]
            # --fallback-model only makes sense when distinct from main.
            # Fall back to haiku (always available, separate weekly quota) —
            # NOT sonnet. Sonnet's weekly cap (resets Jun 18) combined with
            # fable access lapsing made the old fable→sonnet fallback 429 on
            # EVERY fable turn (2026-06-14). haiku is the safe floor.
            if self.model != "haiku":
                argv += ["--fallback-model", "haiku"]
            if self.mcp_config_json:
                argv += [
                    "--mcp-config", self.mcp_config_json,
                    # --strict-mcp-config: use ONLY the leon MCP server, ignore
                    # every account-level / claude.ai connector. The VPS CLI is
                    # logged into a shared Anthropic account,
                    # whose claude.ai Gmail connector was leaking KYLE's inbox
                    # into Leon when Dean asked for email (2026-06-13). Leon's
                    # real email path is the browser (browser_gmail_inbox_state
                    # → the owner's signed-in browser account on CDP 9222). allowedTools
                    # alone didn't block the managed connector; this does.
                    "--strict-mcp-config",
                    "--allowedTools", "mcp__leon__*",
                    "--permission-mode", "bypassPermissions",
                ]
            env = os.environ.copy()
            env.pop("ANTHROPIC_API_KEY", None)
            env["LEON_BRIDGE_ROLE"] = self.bridge_role
            # Force claude's stdout to be LINE-buffered even when piped.
            # Node's claude binary detects TTY vs pipe and switches to block
            # buffering when piped — stdbuf overrides that via libstdbuf.so.
            # Without this, the system/init event sits in claude's stdout
            # buffer until enough output accumulates, and the reader thread
            # never sees it — `cold_start_done` never fires.
            # stdbuf is GNU coreutils — present on Linux, ABSENT on stock macOS.
            # Prepending it unconditionally made macOS clients FileNotFoundError
            # on `stdbuf` and mis-report it as "claude CLI not found in PATH"
            # (the brain never got a reasoning engine). Only wrap when it exists;
            # otherwise spawn claude directly (Mac loses line-buffering, not its
            # mind — the reader still drains, just in larger chunks).
            if shutil.which("stdbuf"):
                wrapped_argv = ["stdbuf", "-oL"] + argv
            else:
                wrapped_argv = argv
            # Windows: find_claude() often resolves to claude.cmd (npm's
            # global-install shim), which CreateProcess can't launch directly
            # under shell=False (WinError 193). No-op on Linux/Mac. See
            # engine_health.spawn_argv docstring — task 22, unverified until
            # exercised on real Windows.
            wrapped_argv = _engine.spawn_argv(wrapped_argv)
            try:
                self._proc = subprocess.Popen(
                    wrapped_argv,
                    # NOT "/tmp" — that is POSIX-only. On Windows it resolves
                    # to C:\tmp which does not exist, and Popen raises
                    # NotADirectoryError (WinError 267). That is a *sibling* of
                    # FileNotFoundError, not a subclass, so the handler below
                    # never caught it: the exception escaped unhandled, the
                    # session never marked itself dead, and every SI on Windows
                    # silently had no reasoning engine — response_start fired
                    # and no text ever came back. (Found on TEST1, 2026-08-10.)
                    cwd=tempfile.gettempdir(),
                    env=env,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                )
                self.turns_served = 0  # fresh child, fresh context budget
                # Drain stderr in a background thread so claude doesn't block on
                # a full pipe — but capture the last lines for diagnostics.
                self._stderr_tail: List[str] = []
                def _drain_stderr(p=self._proc, tail=self._stderr_tail):
                    try:
                        for line in p.stderr:
                            tail.append(line.rstrip())
                            if len(tail) > 50: tail.pop(0)
                    except Exception:
                        pass
                threading.Thread(target=_drain_stderr, daemon=True,
                                  name="leon-claude-stderr").start()
            except FileNotFoundError:
                self._dead = True
                log.error(
                    "claude CLI not found in PATH (looked for %r)",
                    wrapped_argv[0],
                )
                self._cleanup_system_prompt_file()
                return
            except OSError as e:
                # Catch-all for spawn failures that are NOT a missing binary:
                # bad cwd (NotADirectoryError / WinError 267), permission
                # denied, exec format error. These are siblings of
                # FileNotFoundError, so the clause above misses them. Before
                # this existed they escaped unhandled and the SI went mute with
                # no log line at all — the worst possible failure mode.
                self._dead = True
                log.error(
                    "failed to spawn claude CLI (%s: %s) argv=%r cwd=%r",
                    type(e).__name__, e, wrapped_argv, tempfile.gettempdir(),
                )
                self._cleanup_system_prompt_file()
                return
            self._dead = False
            self._cold_start_done.clear()
            self._reader = threading.Thread(target=self._read_loop, args=(self._proc,), daemon=True,
                                             name="leon-claude-reader")
            self._reader.start()
            log.info("session started — pid=%s model=%s mcp=%s",
                     self._proc.pid, self.model, bool(self.mcp_config_json))

    def stop(self) -> None:
        """Public stop. Takes the session lock. NEVER call this from a code
        path that already holds `self._lock` — use `_stop_locked()` instead.

        Why this split exists (found 2026-09-06, reproduced): ask() runs its
        whole body inside `with self._lock:`. Both its BrokenPipeError handler
        and its turn-timeout branch called `self.stop()`, which re-entered the
        SAME non-reentrant lock from the SAME thread. That is a self-deadlock,
        bounded only by _SESSION_LOCK_TIMEOUT_S — 300 seconds. So a broken
        pipe cost the owner five minutes of dead air, and then the TimeoutError
        got swallowed by the caller's `except Exception`, so the zombie
        `claude` subprocess was never actually killed. Symptom on a live
        machine: "sometimes it takes minutes to respond, sometimes it just
        breaks." Both halves came from this one re-entry.
        """
        with self._lock:
            self._stop_locked()

    def _stop_locked(self) -> None:
        """Teardown WITHOUT acquiring self._lock. Caller must already hold it."""
        self._dead = True
        if self._proc is not None:
            try:
                self._proc.stdin.close()
            except Exception:
                pass
            try:
                self._proc.terminate()
                self._proc.wait(timeout=2)
            except Exception:
                try: self._proc.kill()
                except Exception: pass
        self._proc = None
        self._cleanup_system_prompt_file()

    def _cleanup_system_prompt_file(self) -> None:
        if self._system_prompt_path:
            try:
                os.remove(self._system_prompt_path)
            except OSError:
                pass
            self._system_prompt_path = None

    def alive(self) -> bool:
        if self._dead or self._proc is None or self._proc.poll() is not None:
            return False
        # Also check reader thread — if it died, session is broken even if proc lives
        if self._reader is not None and not self._reader.is_alive():
            self._dead = True
            return False
        return True

    def interrupt(self) -> None:
        """Halt the in-flight turn NOW by killing the subprocess, so token
        generation (and Max-plan spend) stops the instant Dean hits Stop.
        The next ask() respawns a fresh subprocess.

        Safe to call from the consumer thread mid-turn: unlike stop() it does
        NOT take self._lock — the suspended ask() generator may still hold it,
        and acquiring it here would deadlock (same thread, non-reentrant lock).
        It just kills the process and flags the session dead so alive()→False.
        """
        self._dead = True
        proc = self._proc
        if proc is not None:
            try:
                proc.kill()
            except Exception:
                pass
        # Unblock a queue.get() the ask() generator may be parked on, so the
        # turn drains immediately instead of waiting out its timeout.
        turn = self._turn
        if turn is not None:
            try:
                turn.queue.put(None)
            except Exception:
                pass

    # ── Reader thread (one per subprocess) ───────────────────────────────

    def _read_loop(self, proc=None) -> None:
        # Bind the handle ONCE. stop() sets self._proc = None while this
        # thread is parked in readline(), so re-reading the attribute every
        # iteration raced it and blew up with
        #   reader loop died: 'NoneType' object has no attribute 'poll'
        # on every single shutdown (123 times on the Dell before this).
        # A local reference keeps the loop reading its OWN process to the end
        # of the pipe, and _dead is what tells it to leave.
        proc = proc if proc is not None else self._proc
        try:
            if proc is None:
                return
            # readline() instead of `for line in stdout` — the iterator does
            # read-ahead which can stall on a pipe that block-buffers, even
            # with bufsize=1. readline() returns as soon as a newline lands.
            while True:
                line = proc.stdout.readline()
                if not line:
                    if self._dead or proc.poll() is not None:
                        break
                    continue
                line = line.strip()
                if not line:
                    continue
                # Liveness: any line at all resets the idle clock -- including
                # thinking deltas and raw lines that never become StreamEvents.
                with self._turn_lock:
                    if self._proc is not proc:
                        return
                    if self._turn is not None:
                        self._turn.last_activity = time.monotonic()
                try:
                    evt = json.loads(line)
                except json.JSONDecodeError:
                    continue
                with self._turn_lock:
                    if self._proc is not proc:
                        return
                    self._handle_event(evt)
        except Exception as e:
            log.warning("reader loop died: %s", e)
        finally:
            with self._turn_lock:
                if self._proc is not proc:
                    return  # retired readers cannot affect a replacement
                if self._turn is not None and not self._turn.done:
                    # BUG (found alongside the not-logged-in preflight,
                    # 2026-08-25): this used to set `self._turn.error` and
                    # push only the bare `None` sentinel. `ask()`'s consumer
                    # loop treats `None` as "no more events, stop iterating"
                    # — it never looked at `.error`. So a subprocess that
                    # died mid-turn (not signed in, killed, crashed) ended
                    # the turn with ZERO events after the initial "model"
                    # event: no "error", no "done". The caller's for-loop
                    # ran zero iterations and the failure was invisible all
                    # the way up to the customer's chat window. Push an
                    # actual error event FIRST so every consumer of ask()
                    # gets a terminal event it can act on; the None sentinel
                    # still follows so the loop below still breaks.
                    tail = "; ".join(getattr(self, "_stderr_tail", [])[-3:])
                    reason = "claude subprocess exited mid-turn"
                    if tail:
                        reason += f" ({tail[:200]})"
                    self._turn.error = reason
                    self._turn.done = True
                    try:
                        self._turn.queue.put(
                            _StreamEvent(type="error", error=reason))
                    except Exception:
                        pass
                    self._turn.queue.put(None)
                self._dead = True

    def _emit(self, **kwargs) -> None:
        """Push a StreamEvent into the active turn's queue."""
        with self._turn_lock:
            if self._turn is None:
                return
            self._turn.queue.put(_StreamEvent(**kwargs))

    def _handle_event(self, evt: dict) -> None:
        t = evt.get("type")
        if t == "system" and evt.get("subtype") == "init":
            self._cold_start_done.set()
            return
        with self._turn_lock:
            turn = self._turn
        if turn is None:
            return

        if t == "stream_event":
            inner = evt.get("event", {})
            itype = inner.get("type")
            if itype == "content_block_start":
                cb = inner.get("content_block", {})
                if cb.get("type") == "tool_use":
                    turn.active_tool = {
                        "id": cb.get("id", ""),
                        "name": cb.get("name", "?"),
                        "input_json": "",
                        "emitted": False,
                    }
            elif itype == "content_block_delta":
                delta = inner.get("delta", {})
                dtype = delta.get("type")
                if dtype == "text_delta":
                    chunk = delta.get("text", "")
                    if chunk:
                        turn.response_chunks.append(chunk)
                        turn.sentence_buf += chunk
                        self._emit(type="delta", text=chunk)
                        # Emit any complete sentences in the buffer first.
                        while True:
                            m = _SENTENCE_END_RE.search(turn.sentence_buf)
                            if not m:
                                break
                            end = m.end()
                            sent = turn.sentence_buf[:end].strip()
                            if sent:
                                self._emit(type="sentence", text=sent, index=turn.sentence_idx)
                                turn.sentence_idx += 1
                            turn.sentence_buf = turn.sentence_buf[end:]
                        # EARLY-TTS: for the FIRST emission only, also split
                        # on a clause boundary (comma, em-dash, etc.) if the
                        # buffer is getting long. Lets the first 5-10 words
                        # speak while Claude finishes the rest. Subsequent
                        # chunks wait for full sentence boundaries so the
                        # cadence doesn't get choppy.
                        if turn.sentence_idx == 0 and len(turn.sentence_buf.split()) >= 6:
                            try:
                                from brain.claude_api_responder import _CLAUSE_BREAK_RE
                            except Exception:
                                _CLAUSE_BREAK_RE = None
                            if _CLAUSE_BREAK_RE:
                                m = _CLAUSE_BREAK_RE.search(turn.sentence_buf)
                                if m:
                                    end = m.end()
                                    sent = turn.sentence_buf[:end].strip()
                                    if sent and len(sent.split()) >= 4:
                                        self._emit(type="sentence", text=sent, index=turn.sentence_idx)
                                        turn.sentence_idx += 1
                                        turn.sentence_buf = turn.sentence_buf[end:]
                elif dtype == "input_json_delta" and turn.active_tool:
                    turn.active_tool["input_json"] += delta.get("partial_json", "")
            elif itype == "content_block_stop":
                at = turn.active_tool
                if at and not at.get("emitted"):
                    display = at["name"]
                    if display.startswith("mcp__leon__"):
                        display = display[len("mcp__leon__"):]
                    risk = self.tool_risk_map.get(display, "medium")
                    self._emit(
                        type="tool_use",
                        text=display,
                        tool_id=at["id"],
                        risk=risk,
                        full_text=at.get("input_json", ""),
                    )
                    at["emitted"] = True
        elif t == "user":
            msg = evt.get("message", {}) or {}
            for c in msg.get("content") or []:
                if isinstance(c, dict) and c.get("type") == "tool_result":
                    tid = c.get("tool_use_id", "")
                    from brain.tool_evidence import normalize_result
                    fallback = (turn.active_tool or {}).get("name", "tool")
                    display, summary = normalize_result(
                        c.get("content"), fallback_name=fallback,
                        is_error=bool(c.get("is_error")))

                    self._emit(
                        type="tool_result",
                        text=display,
                        tool_id=tid,
                        full_text=summary,
                    )
                    turn.active_tool = None
        elif t == "result":
            is_error = bool(evt.get("is_error"))
            # Final tail flush. A provider error is never an assistant
            # sentence, even if the CLI emitted a partial-looking prefix.
            tail = turn.sentence_buf.strip()
            if tail and not is_error:
                self._emit(type="sentence", text=tail, index=turn.sentence_idx)
                turn.sentence_idx += 1
                turn.sentence_buf = ""
            full = "".join(turn.response_chunks).strip()
            if not full:
                full = (evt.get("result") or "").strip()
            # A success envelope containing a standalone usage notice is a
            # provider failure. Without this, "You've hit your session limit"
            # became Leon's spoken answer and the fallback ladder never ran.
            control_limit = (not is_error and not turn.response_chunks
                             and _is_cli_control_limit(full))
            if control_limit:
                is_error = True
                evt = dict(evt)
                evt["is_error"] = True
            if full and not is_error and not turn.response_chunks:
                self._emit(type="delta", text=full)
            if is_error:
                # SAY WHAT WENT WRONG. "claude reported error" is a label,
                # not a cause -- an install can fail every turn of its life
                # and never tell its owner why. Measured on the Dell
                # 2026-09-05: the real reason was sitting right here in the
                # result text ("Failed to authenticate: OAuth session
                # expired and could not be refreshed") while the log said
                # only "claude reported error".
                detail = (evt.get("api_error_status")
                          or (full or "").strip()
                          or (evt.get("result") or "").strip()
                          or "; ".join(getattr(self, "_stderr_tail", [])[-2:]).strip()
                          or "claude reported error")
                turn.error = " ".join(str(detail).split())[:200]
                self._emit(type="error", error=turn.error)
            else:
                self._emit(type="done", full_text=full)
            with self._turn_lock:
                turn.done = True
                turn.queue.put(None)  # sentinel

    # ── Public turn API ──────────────────────────────────────────────────

    def ask(self, user_text: str, history_hint: str = "", timeout: float = 90.0,
            hard_timeout: Optional[float] = None) -> Iterator:
        """Yield a serialized turn; close() always releases its resources.

        `timeout` is an IDLE budget: the turn fails only if the child writes
        nothing for that long (widened to _TOOL_IDLE_S while a tool call is
        running). `hard_timeout` caps total wall-clock; defaults to
        max(timeout * 4, _TURN_HARD_CEILING_S). See the module constants.
        """
        _lazy_imports()
        if not self.alive():
            self.start()
        if not self.alive():
            yield _StreamEvent(type="error", error="claude session unavailable")
            return

        with self._lock:
            if not self.alive():
                yield _StreamEvent(type="error", error="claude session died before turn")
                return
            self.turns_served += 1
            turn = _TurnState()
            completed = False
            idle_budget = max(0.0, timeout)
            t_start = time.monotonic()
            hard_deadline = t_start + (
                hard_timeout if hard_timeout is not None
                else max(idle_budget * 4, _TURN_HARD_CEILING_S))

            def _deadline() -> tuple:
                """(deadline, idle_budget_in_force, last_activity)."""
                with self._turn_lock:
                    last = turn.last_activity
                    at = turn.active_tool
                    tool_pending = bool(at and at.get("emitted"))
                budget = max(idle_budget, _TOOL_IDLE_S) if tool_pending else idle_budget
                return (min(last + budget, hard_deadline), budget, last)

            with self._turn_lock:
                self._turn = turn
            try:
                yield _StreamEvent(type="model", model=f"claude-{self.model}", tier="cli")
                payload = json.dumps({
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": [{"type": "text", "text": user_text}],
                    },
                })
                try:
                    assert self._proc and self._proc.stdin
                    self._proc.stdin.write(payload + "\n")
                    self._proc.stdin.flush()
                except Exception as e:
                    # stop() takes the lock already held by this generator.
                    # _stop_locked() performs teardown without re-entering it.
                    self._stop_locked()
                    reason = "claude pipe broken — session died" if isinstance(e, BrokenPipeError) else f"send failed: {e}"
                    yield _StreamEvent(type="error", error=reason)
                    return

                while True:
                    deadline, budget, last = _deadline()
                    remaining = deadline - time.monotonic()
                    try:
                        if remaining <= 0:
                            raise queue.Empty
                        ev = turn.queue.get(timeout=remaining)
                    except queue.Empty:
                        # The child may have written lines that reset the
                        # idle clock without producing a StreamEvent
                        # (thinking, tool-input json). Re-check before
                        # declaring a stall.
                        now = time.monotonic()
                        deadline, budget, last = _deadline()
                        if now < deadline:
                            continue
                        idle_for = now - last
                        total_for = now - t_start
                        kind = "ceiling" if now >= hard_deadline else "idle"
                        # Clean up BEFORE yielding: callers break on error.
                        self._stop_locked()
                        # Keep the literal "turn timeout" -- _is_stall_error
                        # and the websocket owner-message branch key on it.
                        yield _StreamEvent(
                            type="error",
                            error=(f"turn timeout ({kind}: silent {idle_for:.0f}s "
                                   f"of {budget:g}s allowed, total {total_for:.0f}s)"))
                        return
                    if ev is None:
                        if turn.error:
                            yield _StreamEvent(type="error", error=str(turn.error))
                        return
                    completed = ev.type == "done"
                    yield ev
                    if ev.type in ("done", "error"):
                        return
            finally:
                if not completed:
                    self._stop_locked()
                with self._turn_lock:
                    if self._turn is turn:
                        self._turn = None

# ---------------------------------------------------------------------------
# Auth preflight
# ---------------------------------------------------------------------------
#
# WHY THIS EXISTS
# ---------------
# On Dean's Windows box (TEST1, 2026-08-10) the claude CLI was installed,
# on PATH, correct version -- and simply not signed in. Running it printed
# "Not logged in - Please run /login" and exited.
#
# Nothing in the brain checked for that. The SI accepted the user's message,
# emitted brain_response_start, and then produced NOTHING. Forever. No error,
# no log line, no hint. A customer types hello and watches a dead box.
#
# That is the single worst failure mode this product can have, because it is
# indistinguishable from "the AI is broken" when the actual fix is one click.
# Never let unauthenticated read as silence.

_NOT_LOGGED_IN_MARKERS = (
    "not logged in",
    "please run /login",
    "invalid api key",
    "authentication_error",
    "oauth token has expired",
)


def claude_auth_status(timeout: float = 45.0) -> dict:
    """Probe whether the claude CLI can actually answer.

    Returns {"ok": bool, "reason": str, "detail": str}. Never raises --
    a preflight that can throw is a preflight that gets wrapped in a bare
    except and silently ignored, which is how we got here.
    """
    # Same resolver the spawns use, so this probe can't pass on a binary
    # the runtime cannot launch (which() honours PATHEXT; CreateProcess
    # does not) or miss one that lives in a known install dir off PATH.
    try:
        from brain import engine_health as _engine
        exe = _engine.resolve(refresh=True)
        if exe == "claude":
            exe = None
    except Exception:
        exe = shutil.which("claude")
    if not exe:
        return {"ok": False, "reason": "cli_missing",
                "detail": "claude CLI not found on PATH or in any known install dir"}

    env = os.environ.copy()
    env.pop("ANTHROPIC_API_KEY", None)
    try:
        r = subprocess.run(
            [exe, "-p", "ping"],
            cwd=tempfile.gettempdir(),   # never "/tmp" -- see spawn note above
            env=env,
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "reason": "timeout",
                "detail": f"claude CLI did not respond within {int(timeout)}s"}
    except OSError as e:
        return {"ok": False, "reason": "spawn_failed",
                "detail": f"{type(e).__name__}: {e}"}

    blob = ((r.stdout or "") + "\n" + (r.stderr or "")).strip()
    low = blob.lower()
    if any(m in low for m in _NOT_LOGGED_IN_MARKERS):
        return {"ok": False, "reason": "not_logged_in",
                "detail": blob[:400] or "claude CLI reports it is not signed in"}
    if r.returncode != 0:
        return {"ok": False, "reason": "cli_error",
                "detail": f"exit {r.returncode}: {blob[:400]}"}
    if not blob:
        return {"ok": False, "reason": "empty_reply",
                "detail": "claude CLI exited 0 but produced no output"}
    return {"ok": True, "reason": "ok", "detail": blob[:200]}


def auth_status_message(status: dict, si_name: str = "Your SI") -> str:
    """Turn a failed preflight into something a NON-ENGINEER can act on.

    Deliberately plain language. The person reading this bought a product;
    they did not sign up to interpret "spawn_failed".
    """
    reason = (status or {}).get("reason", "")
    if reason == "not_logged_in":
        return (f"{si_name} is awake, but it can't reach Claude yet -- this "
                f"computer isn't signed in. Open a terminal, run: claude  "
                f"then use /login and sign in with your Claude account. "
                f"{si_name} will start thinking the moment that finishes.")
    if reason == "cli_missing":
        return (f"{si_name} is awake, but the Claude command isn't installed "
                f"on this computer, so it has nothing to think with.")
    if reason == "timeout":
        return (f"{si_name} is awake, but Claude isn't responding -- this is "
                f"usually no internet connection, or a firewall blocking it.")
    return (f"{si_name} is awake, but it can't reach Claude right now. "
            f"Details: {(status or {}).get('detail', 'unknown')}")
