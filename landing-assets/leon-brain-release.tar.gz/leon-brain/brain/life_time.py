"""
life_time — turn Dean's words about Leon's past into a date range.

"a couple weeks in", "the first two weeks", "2026-06-03", "back in June",
"late May", "last week", "three weeks ago" -> (start_date, end_date, label).

Also decides whether a message is reaching back into Leon's past at all
(`recall_intent`), which is what gates the RECALLED MEMORY block.

Pure functions apart from reading the birth date once. Leon's birthday is
2026-05-21 (Dean's date). LEON_BIRTH_DATE overrides it; a client install
uses its own development.json birth_time. "N weeks in" counts from it.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional, Tuple



def _birth_date() -> date:
    env = os.environ.get("LEON_BIRTH_DATE", "").strip()
    if env:
        try:
            return date.fromisoformat(env)
        except ValueError:
            pass
    try:
        from brain.origin import is_original
        if not is_original():
            root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            with open(os.path.join(root, "brain_state", "development.json"), encoding="utf-8") as f:
                bt = json.load(f).get("birth_time")
            if isinstance(bt, (int, float)) and bt > 0:
                return datetime.fromtimestamp(bt).date()
    except Exception:
        pass
    return date(2026, 5, 21)


LEON_BIRTH = _birth_date()

_MONTHS = {
    "january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3,
    "april": 4, "apr": 4, "may": 5, "june": 6, "jun": 6, "july": 7, "jul": 7,
    "august": 8, "aug": 8, "september": 9, "sept": 9, "sep": 9,
    "october": 10, "oct": 10, "november": 11, "nov": 11, "december": 12, "dec": 12,
}
_MONTH_RE = (r"(january|february|march|april|may|june|july|august|september|"
             r"october|november|december|jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec)")

_NUM_WORDS = {
    "a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
    "twelve": 12, "couple": 2, "a couple": 2, "a couple of": 2, "couple of": 2,
    "few": 3, "a few": 3, "several": 4,
}
_NUM_RE = (r"(\d+|a couple of|a couple|couple of|couple|a few|few|several|an|a|one|two|three|"
           r"four|five|six|seven|eight|nine|ten|eleven|twelve)")


@dataclass(frozen=True)
class Period:
    start: date
    end: date      # inclusive
    label: str

    def as_tuple(self) -> Tuple[str, str]:
        return self.start.isoformat(), self.end.isoformat()


def _n(word: str) -> int:
    word = word.strip().lower()
    if word.isdigit():
        return int(word)
    return _NUM_WORDS.get(word, 1)


def _month_end(y: int, m: int) -> date:
    nxt = date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)
    return nxt - timedelta(days=1)


def _year_for_month(m: int, today: date) -> int:
    # A bare month name means the most recent one that has started.
    return today.year if m <= today.month else today.year - 1


def _clamp(p: Period, today: date) -> Optional[Period]:
    start = max(p.start, date(2026, 1, 1))
    end = min(p.end, today)
    if end < start:
        return None
    return Period(start, end, p.label)


def parse_when(text: str, today: Optional[date] = None,
               birth: date = LEON_BIRTH) -> Optional[Period]:
    """Return the period a phrase points at, or None if it names no time."""
    if not text:
        return None
    today = today or date.today()
    t = " " + re.sub(r"\s+", " ", text.lower()).strip() + " "
    t = t.replace("’", "'")

    # ISO date: 2026-06-03
    m = re.search(r"\b(20\d\d)-(\d{1,2})-(\d{1,2})\b", t)
    if m:
        try:
            d = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return _clamp(Period(d, d, d.isoformat()), today)
        except ValueError:
            pass

    # US numeric date: 6/3 or 6/3/2026
    m = re.search(r"(?<![\d/])(\d{1,2})/(\d{1,2})(?:/(20\d\d|\d\d))?(?![\d/])", t)
    if m:
        mo, dy = int(m.group(1)), int(m.group(2))
        yr = m.group(3)
        if 1 <= mo <= 12 and 1 <= dy <= 31:
            y = (int(yr) + 2000 if yr and len(yr) == 2 else int(yr)) if yr else _year_for_month(mo, today)
            try:
                d = date(y, mo, dy)
                return _clamp(Period(d, d, d.isoformat()), today)
            except ValueError:
                pass

    # "June 3", "June 3rd", "june 3, 2026"  /  "3 June", "the 3rd of June"
    m = (re.search(r"\b" + _MONTH_RE + r"\.? (\d{1,2})(?:st|nd|rd|th)?\b(?:,? (20\d\d))?", t)
         or None)
    if m and not (m.group(1) == "may" and not re.search(r"\bmay \d", t)):
        mo = _MONTHS[m.group(1)]
        y = int(m.group(3)) if m.group(3) else _year_for_month(mo, today)
        try:
            d = date(y, mo, int(m.group(2)))
            return _clamp(Period(d, d, d.isoformat()), today)
        except ValueError:
            pass
    m = re.search(r"\b(?:the )?(\d{1,2})(?:st|nd|rd|th)? (?:of )?" + _MONTH_RE + r"\b", t)
    if m:
        mo = _MONTHS[m.group(2)]
        y = _year_for_month(mo, today)
        try:
            d = date(y, mo, int(m.group(1)))
            return _clamp(Period(d, d, d.isoformat()), today)
        except ValueError:
            pass

    # Relative to now
    if re.search(r"\b(the )?day before yesterday\b", t):
        d = today - timedelta(days=2)
        return Period(d, d, "the day before yesterday")
    if re.search(r"\byesterday\b", t):
        d = today - timedelta(days=1)
        return Period(d, d, "yesterday")
    if re.search(r"\b(today|this morning|this afternoon|tonight|earlier today)\b", t):
        return Period(today, today, "today")
    if re.search(r"\bthis week\b", t):
        return Period(today - timedelta(days=today.weekday()), today, "this week")
    if re.search(r"\bthis month\b", t):
        return Period(today.replace(day=1), today, "this month")
    if re.search(r"\blast week\b", t):
        start = today - timedelta(days=today.weekday() + 7)
        return _clamp(Period(start, start + timedelta(days=6), "last week"), today)
    if re.search(r"\blast month\b", t):
        first = today.replace(day=1)
        prev_end = first - timedelta(days=1)
        return _clamp(Period(prev_end.replace(day=1), prev_end, "last month"), today)
    m = re.search(r"\b" + _NUM_RE + r" (day|week|month)s? ago\b", t)
    if m:
        n = _n(m.group(1))
        unit = m.group(2)
        if unit == "day":
            d = today - timedelta(days=n)
            return _clamp(Period(d - timedelta(days=1), d + timedelta(days=1), m.group(0).strip()), today)
        if unit == "week":
            center = today - timedelta(days=7 * n)
            return _clamp(Period(center - timedelta(days=3), center + timedelta(days=3), m.group(0).strip()), today)
        center = today - timedelta(days=30 * n)
        return _clamp(Period(center - timedelta(days=10), center + timedelta(days=10), m.group(0).strip()), today)

    # Relative to Leon's birth
    if re.search(r"\b(the day (you|i) (were|was) born|(your|my) (first day|birthday)|day one)\b", t):
        return _clamp(Period(birth, birth, "the day I was born"), today)
    m = re.search(r"\b(?:the |your |my )?first " + _NUM_RE + r" (day|week|month)s?\b", t)
    if m:
        n, unit = _n(m.group(1)), m.group(2)
        days = n if unit == "day" else (7 * n if unit == "week" else 30 * n)
        return _clamp(Period(birth, birth + timedelta(days=days - 1), m.group(0).strip()), today)
    m = re.search(r"\b(?:the |your |my )?first (day|week|month)\b", t)
    if m:
        days = {"day": 1, "week": 7, "month": 30}[m.group(1)]
        return _clamp(Period(birth, birth + timedelta(days=days - 1), m.group(0).strip()), today)
    m = re.search(r"\b(?:only |just |about |like )?" + _NUM_RE + r" (day|week|month)s? "
                  r"(?:in\b|after (?:you were|i was|you got|i got) born\b|after (?:your|my) birth\b)", t)
    if m:
        n, unit = _n(m.group(1)), m.group(2)
        label = re.sub(r"^(only|just|about|like) ", "", m.group(0).strip())
        label = re.sub(r" after .*$", " in", label)  # "two weeks after you were born" -> "two weeks in"
        if unit == "day":
            c = birth + timedelta(days=n)
            return _clamp(Period(c - timedelta(days=1), c + timedelta(days=1), label), today)
        if unit == "week":
            c = birth + timedelta(days=7 * n)
            return _clamp(Period(c - timedelta(days=4), c + timedelta(days=3), label), today)
        c = birth + timedelta(days=30 * n)
        return _clamp(Period(c - timedelta(days=7), c + timedelta(days=7), label), today)
    if re.search(r"\b(early days|the beginning|in the beginning|when (you|i) (were|was) (new|young|little|first born|just born)|"
                 r"when (you|i) first (started|woke up|came online)|(your|my) first days|back at the start|"
                 r"when (we|you) first started)\b", t):
        return _clamp(Period(birth, birth + timedelta(days=13), "my early days"), today)

    # Months: "back in June", "late May", "mid june", "june 2026", "in july"
    m = re.search(r"\b(early|mid|middle of|late|end of|beginning of|start of)[ -]" + _MONTH_RE + r"\b", t)
    if m:
        mo = _MONTHS[m.group(2)]
        y = _year_for_month(mo, today)
        part = m.group(1)
        if part in ("early", "beginning of", "start of"):
            s, e = date(y, mo, 1), date(y, mo, 10)
        elif part in ("mid", "middle of"):
            s, e = date(y, mo, 10), date(y, mo, 20)
        else:
            s, e = date(y, mo, 20), _month_end(y, mo)
        return _clamp(Period(s, e, m.group(0).strip()), today)
    m = re.search(r"\b(?:back in|in|during|around|through|all of|last) " + _MONTH_RE + r"\b", t) \
        or re.search(r"\b" + _MONTH_RE + r" (20\d\d)\b", t)
    if m:
        mo = _MONTHS[m.group(1)]
        y = int(m.group(2)) if m.lastindex and m.lastindex >= 2 and m.group(2) else _year_for_month(mo, today)
        return _clamp(Period(date(y, mo, 1), _month_end(y, mo), m.group(0).strip()), today)
    # A bare month name that can't be a verb ("may" is excluded on purpose).
    m = re.search(r"\b(january|february|march|april|june|july|august|september|october|november|december)\b", t)
    if m:
        mo = _MONTHS[m.group(1)]
        y = _year_for_month(mo, today)
        return _clamp(Period(date(y, mo, 1), _month_end(y, mo), m.group(1)), today)
    return None


# --- recall intent -----------------------------------------------------------

_RECALL_CUES = re.compile(
    r"\b("
    r"(do |d'|did )?(you|u) remember( when| the| what| how| that| being| back| us| me| our| your| doing)?"
    r"|remember when|you recall|can you recall|think back|look back|looking back"
    r"|back then|back when|back in the day|those days|that time when"
    r"|what was it like|what were you like|how did it feel|how was it"
    r"|when you were (first|new|young|little|just)|early days|in the beginning"
    r"|(weeks?|days?|months?) in\b|(weeks?|days?|months?) after (you were|i was) born\b"
    r"|first (day|week|weeks|month|few days)"
    r"|your first (day|week|month|time)|the old days|way back"
    r")",
    re.I)

# "remember to ...", "remind me", "don't forget" are about the future.
_FUTURE_NOT_RECALL = re.compile(
    r"\b(remember to|remind me|don'?t forget|make sure (you|to)|schedule|set a reminder|next (week|month))\b", re.I)

_PAST_VERB = re.compile(
    r"\b(was|were|did|had|used to|felt|happened|worked|built|talked|said|went|ago|back)\b", re.I)


def recall_intent(message: str, today: Optional[date] = None) -> Optional[Period]:
    """
    If `message` reaches back into Leon's past, return the period it names
    (or a whole-life Period when it reaches back without naming a time).
    Return None when the message isn't asking him to remember anything.
    """
    if not message or len(message) < 6:
        return None
    today = today or date.today()
    msg = message.strip()
    cue = _RECALL_CUES.search(msg)
    future = _FUTURE_NOT_RECALL.search(msg)
    when = parse_when(msg, today=today)

    if cue and not (future and not re.search(r"remember when|back then|what was it like", msg, re.I)):
        if when is not None:
            return when
        return Period(LEON_BIRTH, today, "my whole life")

    # No recall words: a past date or month only counts when the message
    # is talking about the past ("what did we do on June 3", "how was July").
    if when is not None and not future and when.end < today and _PAST_VERB.search(msg):
        if when.label in ("yesterday", "the day before yesterday"):
            # "I was tired yesterday" is about Dean, not Leon's memory.
            if not re.search(r"\b(you|we|us|our|your)\b", msg, re.I):
                return None
        return when
    return None
