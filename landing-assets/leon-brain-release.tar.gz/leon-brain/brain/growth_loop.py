"""
Growth Loop — Leon's autonomous self-improvement cycle.

Runs as a background thread during idle periods. The loop:

  1. Explore: Try untested tools (curiosity)
  2. Practice: Test reliability of frequently-used tools
  3. Repair: Diagnose and fix broken tools
  4. Audit: Check which credentials are configured
  5. Reflect: Update goals based on what was learned

Interval: every 5 minutes during idle (no active conversation).
Never interrupts Dean. Logs everything to the activity panel.
"""

from __future__ import annotations

import logging
import threading
import time

log = logging.getLogger("leon.growth")

_GROWTH_INTERVAL = 300  # 5 minutes
_running = False
_thread: threading.Thread | None = None


def start():
    """Start the growth loop background thread."""
    global _running, _thread
    if _running:
        return
    _running = True
    _thread = threading.Thread(target=_loop, daemon=True, name="growth-loop")
    _thread.start()
    log.info("[GROWTH] Background growth loop started (interval=%ds)", _GROWTH_INTERVAL)


def stop():
    global _running
    _running = False


def _is_idle() -> bool:
    """Check if Leon is idle (no active conversation)."""
    try:
        import server.state as state
        resp = getattr(state, "brain_api_responder", None)
        if resp and getattr(resp, "_active_response", False):
            return False
    except Exception:
        pass
    return True


def _loop():
    """Main growth loop."""
    # Wait for brain to fully initialize
    time.sleep(60)

    cycle = 0
    while _running:
        try:
            if not _is_idle():
                time.sleep(30)
                continue

            cycle += 1
            _run_cycle(cycle)

        except Exception as e:
            log.warning("[GROWTH] cycle error: %s", e)

        time.sleep(_GROWTH_INTERVAL)


def _run_cycle(cycle: int):
    """One growth cycle."""
    try:
        from server.helpers import broadcast_activity
    except Exception:
        broadcast_activity = lambda *a, **k: None

    # Phase 1: Explore (every cycle)
    if cycle % 1 == 0:  # every cycle
        try:
            from brain.tool_explorer import explore_one
            result = explore_one()
            if result and result.get("status") != "all_explored":
                log.info("[GROWTH] Explored: %s → %s",
                         result.get("tool"), "ok" if result.get("ok") else "failed")
        except Exception as e:
            log.debug("[GROWTH] explore error: %s", e)

    # Phase 2: Practice (every 3 cycles = ~15 min)
    if cycle % 3 == 0:
        try:
            from brain.skill_practice import practice_session
            results = practice_session()
            if results:
                healthy = sum(1 for r in results if r.get("status") == "healthy")
                log.info("[GROWTH] Practice: %d/%d tools healthy", healthy, len(results))
        except Exception as e:
            log.debug("[GROWTH] practice error: %s", e)

    # Phase 3: Self-repair (every 6 cycles = ~30 min)
    if cycle % 6 == 0:
        try:
            from brain.self_repair_tools import repair_check
            repairs = repair_check()
            fixed = sum(1 for r in repairs if r.get("repair", {}).get("success"))
            if repairs:
                log.info("[GROWTH] Repair check: %d issues, %d auto-fixed", len(repairs), fixed)
        except Exception as e:
            log.debug("[GROWTH] repair error: %s", e)

    # Phase 4: Credential audit (every 12 cycles = ~1 hour)
    if cycle % 12 == 0:
        try:
            from brain.credential_audit import audit
            report = audit()
            log.info("[GROWTH] Credential audit: %d configured, %d missing",
                     report.get("configured_count", 0), report.get("missing_count", 0))
            # Only broadcast if the counts changed since last audit
            _cur = (report.get('configured_count', 0), report.get('missing_count', 0))
            _prev = getattr(_run_cycle, '_last_cred_counts', None)
            _run_cycle._last_cred_counts = _cur
            if _prev is None:
                pass  # first run — log silently, don't spam the dashboard
            elif _cur != _prev:
                broadcast_activity("inner",
                    f"Credential change: {_cur[0]} configured, {_cur[1]} missing "
                    f"(was {_prev[0]}/{_prev[1]})", 10000)
        except Exception as e:
            log.debug("[GROWTH] audit error: %s", e)

    # Phase 5: Goal reflection (every 6 cycles = ~30 min)
    if cycle % 6 == 0:
        try:
            from brain.persistent_goals import get_active_goals
            from brain.tool_explorer import get_exploration_stats
            goals = get_active_goals()
            stats = get_exploration_stats()

            # Auto-create exploration goal if none exists
            if not any(g.get("category") == "explore" for g in goals):
                if stats.get("total_tested", 0) < 50:
                    from brain.persistent_goals import add_goal
                    add_goal(
                        f"Explore my tools — only tested {stats.get('total_tested', 0)} so far",
                        category="explore",
                        priority=0.3,
                        source="system",
                    )
        except Exception as e:
            log.debug("[GROWTH] goals error: %s", e)
