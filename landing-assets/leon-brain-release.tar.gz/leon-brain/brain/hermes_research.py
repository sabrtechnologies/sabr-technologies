"""Conversation entry point for the existing durable native Hermes research queue."""
import hashlib
import re
import subprocess


TOOL = {
    "name": "hermes_research",
    "description": (
        "Genuine NousResearch Hermes research on the VPS, with durable memory keyed by "
        "the absolute project folder across fresh sessions. Read-only project files and "
        "public web research; no coding worker or memoryless fallback. action=start returns "
        "a tracked job_id; use action=status with that ID for the report, or action=list "
        "for the jobs board. Start needs folder, task, model and effort (use the selected "
        "Codex coding settings), and a stable request_id. Retry interrupted starts with "
        "the SAME request_id and arguments. Laptop rollout is separate."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["start", "status", "list"]},
            "folder": {"type": "string", "description": "Absolute VPS project folder; stable memory identity."},
            "task": {"type": "string", "minLength": 10},
            "project": {"type": "string", "description": "Display label; folder determines memory identity."},
            "request_id": {"type": "string", "pattern": "^[A-Za-z0-9-]{8,100}$"},
            "model": {"type": "string", "description": "Selected Codex coding model, passed unchanged."},
            "effort": {"type": "string", "description": "Selected reasoning effort, passed unchanged."},
            "timeout_min": {"type": "integer", "minimum": 1, "maximum": 720},
            "job_id": {"type": "string", "pattern": "^vps-[a-f0-9]{24}$"},
        },
        "additionalProperties": False,
    },
}


def research(args):
    """Fail closed on unavailable host/runtime/memory; never dispatch to old helpers."""
    from server import native_jobs

    if not native_jobs.enabled():
        return {"ok": False, "error": "Native Hermes research is unavailable on this host; no helper launched."}
    if not isinstance(args, dict) or set(args) - set(TOOL["input_schema"]["properties"]):
        return {"ok": False, "error": "Invalid Hermes research arguments."}
    action = args.get("action", "start")
    if action == "start":
        for key in ("folder", "task", "request_id", "model", "effort"):
            if not isinstance(args.get(key), str) or not args[key].strip():
                return {"ok": False, "error": f"Hermes research start requires {key}."}
        if not re.fullmatch(r"[A-Za-z0-9-]{8,100}", args["request_id"]):
            return {"ok": False, "error": "request_id must be 8-100 ASCII letters, digits or hyphens."}
        payload = {k: v for k, v in args.items() if k not in ("action", "job_id")}
        payload.update(provider="codex", execution_location="vps", job_kind="research")
    elif action == "status":
        if not isinstance(args.get("job_id"), str) or not re.fullmatch(r"vps-[a-f0-9]{24}", args["job_id"]):
            return {"ok": False, "error": "A native job_id is required."}
        payload = {"job_id": args["job_id"]}
    elif action == "list":
        payload = {}
    else:
        return {"ok": False, "error": "action must be start, status or list."}
    try:
        return native_jobs.call(action, payload)
    except (OSError, subprocess.TimeoutExpired):
        # A timed-out admission may already have launched; preserve its lookup identity.
        job_id = ("vps-" + hashlib.sha256(args["request_id"].encode()).hexdigest()[:24]
                  if action == "start" else args.get("job_id"))
        return {"ok": False, "job_id": job_id,
                "error": "Native queue outcome unknown. Inspect status or retry the SAME request_id and arguments; no fallback launched."}


EXTRA_TOOLS = {"hermes.research": research}
