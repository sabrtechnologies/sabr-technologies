"""Shared mind: Leon's inner voice thinks from the same context as his replies,
and does its own read-only checks with the same hands.

Dean, 2026-10-05 16:16: Leon said "If I can feel a handoff, there are still two
of me passing notes. What I want is what you have, where the thinking and the
doing happen in one place with the same context and the same hands." The inner
voice ran on a thin summary (autobiography, goals, dreams): it never saw his
tool results, what he had already told Dean, or the job list, and it could not
call a tool. Today it thought "The grep is cheap and I keep not running it.
I'll check journalctl for who actually called the restart..." and the check
never ran; brain/action_cues.py did not even recognise it as a cue.

What this module does:

  * context_block() is what the inner voice now thinks from: the last turns of
    the conversation with Dean (Leon's own replies included), the tool calls of
    the last 30 minutes and what came back (brain/evidence_ledger.py, the claim
    gate's ledger), live coding job states, the open-task ledger and queued
    cues (brain/action_cues.py), and the checks the inner voice already ran.
  * intent_for(thought, check) finds the action in a thought. The thought
    prompt lets Leon add one "CHECK: <command>" line; without one, a few plain
    read-only intents are recognised in the words (journalctl / the logs, the
    coding jobs, one job, git status).
  * on_thought() runs a read-only check at once through the main loop's own
    tool runner (server/routers/agent_routes.dispatch, the code behind
    /api/leon/tool) and records the result in the evidence ledger, so the next
    thought, the next reply and the claim gate all see it. No queue hop.
    Mutating or risky actions (edits, restarts, deploys, messages, money) are
    never run here: they go to action_cues, as before.
  * The same check within 30 minutes, by the inner voice or by any turn, is not
    run again: the thought becomes "Already checked ... : <result>" once, and
    later repeats are dropped. So are thoughts that say he still hasn't run a
    check that did run.
  * reply_block() puts the fresh results at the top of Dean's next turn, so
    what Leon says and what he thinks agree.
  * At most MAX_CALLS checks per 10 minutes (LEON_INNER_TOOLS_PER_10MIN), each
    capped at TOOL_TIMEOUT_S. Checks run on the inner voice's own thread, never
    on the reply path. LEON_INNER_ACT=off turns execution off (thoughts then go
    to action_cues exactly as before). A hosted tenant or client SI never runs
    shell checks here.

Everything is fail-open: a fault here never blocks a thought or a reply.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DEDUPE_S = 30 * 60.0          # the same check within 30 minutes counts once
RATE_WINDOW_S = 10 * 60.0
TOOL_TIMEOUT_S = 12.0
REPLY_FRESH_S = 15 * 60.0     # findings shown at the top of Dean's next turn
RESULT_CHARS = 600            # result kept per finding
CONTEXT_TURNS = 8
CONTEXT_TOOLS = 8


def max_calls() -> int:
    try:
        return max(0, int(os.environ.get("LEON_INNER_TOOLS_PER_10MIN", "4")))
    except ValueError:
        return 4


def acting_enabled() -> bool:
    if os.environ.get("LEON_INNER_ACT", "on").strip().lower() in ("0", "off", "false", "no"):
        return False
    if os.environ.get("LEON_HOSTED_TENANT_ID"):
        return False
    try:
        from brain.identity import is_client_si
        if is_client_si():
            return False
    except Exception:
        pass
    return True


def service_unit() -> str:
    return os.environ.get("LEON_SERVICE_UNIT", "leon.service")


# ── read-only commands ──────────────────────────────────────────────────────

_SAFE_COMMANDS = {
    "grep", "egrep", "fgrep", "rg", "journalctl", "cat", "head", "tail", "ls", "wc",
    "sort", "uniq", "cut", "tr", "git", "systemctl", "ps", "pgrep", "df", "free",
    "uptime", "date", "stat", "find", "du", "tac", "nl", "jq", "file", "curl",
}
_GIT_READ = {"status", "log", "diff", "show", "rev-parse", "describe", "ls-files",
             "blame", "shortlog", "branch"}
_SYSTEMCTL_READ = {"status", "is-active", "is-enabled", "is-failed", "show",
                   "list-units", "list-timers"}
# Flags that write, run something, or never return (a follow would sit until
# the timeout). Two-character ones are also caught inside bundles ("-sSo").
_BAD_FLAGS = {
    "journalctl": ("--vacuum", "--rotate", "--flush", "--sync", "--relinquish",
                   "--smart-relinquish", "--setup-keys", "--update-catalog", "-f", "--follow"),
    "tail": ("-f", "-F", "--follow", "--retry"),
    "find": ("-delete", "-exec", "-execdir", "-ok", "-okdir", "-fprint", "-fls"),
    "sort": ("-o", "--output", "--compress-program"),
    "git": ("--output", "--ext-diff"),
    "curl": ("-X", "--request", "-d", "--data", "-F", "--form", "-T", "--upload",
             "-o", "--output", "-O", "--remote-name", "-K", "--config", "-u", "--user",
             "-c", "--cookie-jar", "--json"),
    "rg": ("--pre",),
}
# Secrets never go into a thought, the ledger or a reply.
_SECRET_PATH = re.compile(r"secrets?\.env|(?:^|/)\.env\b|\.ssh\b|id_(?:rsa|ed25519|ecdsa)|"
                          r"credentials|owner_facts|/etc/shadow|(?:^|/)secure/|api[_-]?key|token",
                          re.I)
_LOCAL_URL = re.compile(r"^https?://(?:127\.0\.0\.1|localhost)(?::\d+)?(?:/|$)")


def readonly_shell(cmd: str) -> Optional[str]:
    """None when `cmd` is a plain read-only pipeline, else why it is not."""
    cmd = (cmd or "").strip()
    if not cmd:
        return "empty command"
    if len(cmd) > 500:
        return "too long"
    if "\n" in cmd or "`" in cmd or "$(" in cmd or "${" in cmd or "<(" in cmd or ">(" in cmd:
        return "shell substitution"
    try:
        lex = shlex.shlex(cmd, posix=True, punctuation_chars=True)
        lex.whitespace_split = True
        tokens = list(lex)
    except ValueError:
        return "unbalanced quotes"
    stages: List[List[str]] = [[]]
    for tok in tokens:
        if tok == "|":
            stages.append([])
        elif tok and set(tok) <= set("|&;<>()"):
            return "operator %s" % tok
        else:
            stages[-1].append(tok)
    for stage in stages:
        if not stage:
            return "empty pipeline stage"
        prog, args = stage[0], stage[1:]
        if prog not in _SAFE_COMMANDS:
            return "%s is not a read-only command" % prog
        for a in args:
            if _SECRET_PATH.search(a):
                return "touches secrets"
            for bad in _BAD_FLAGS.get(prog, ()):
                if a.startswith(bad) or (len(bad) == 2 and a.startswith("-")
                                         and not a.startswith("--") and bad[1] in a[1:]):
                    return "%s %s writes, runs or follows" % (prog, a)
        if prog == "git":
            i = 0
            while i < len(args) and args[i].startswith("-"):
                if args[i] == "-C":            # git -C <repo> ...: where, not what
                    i += 2
                elif args[i] == "--no-pager":
                    i += 1
                else:                          # -c can set a pager command
                    return "git option %s" % args[i]
            sub = args[i] if i < len(args) else ""
            args = args[i:]
            if sub not in _GIT_READ:
                return "git %s is not a read" % (sub or "(none)")
            if sub == "branch" and any(a not in ("branch", "-a", "-v", "-vv", "-r", "--show-current",
                                                  "--list", "--all") for a in args):
                return "git branch with arguments"
        if prog == "systemctl":
            sub = next((a for a in args if not a.startswith("-")), "")
            if sub not in _SYSTEMCTL_READ:
                return "systemctl %s is not a read" % (sub or "(none)")
        if prog == "uniq" and len([a for a in args if not a.startswith("-")]) > 1:
            return "uniq with an output file"
        if prog == "curl":
            urls = [a for a in args if not a.startswith("-")]
            if not urls or not all(_LOCAL_URL.match(u) for u in urls):
                return "curl outside this machine"
    return None


# ── intents ─────────────────────────────────────────────────────────────────

@dataclass
class Intent:
    action: str                 # the action in words
    readonly: bool
    tool: str = ""              # shell_exec | coding_jobs_list | coding_job_status | ""
    args: Dict[str, Any] = field(default_factory=dict)
    label: str = ""             # what was checked, in words
    topic: List[str] = field(default_factory=list)   # keywords for dedupe

    @property
    def key(self) -> str:
        if not self.tool:
            return ""
        try:
            return "%s|%s" % (self.tool, json.dumps(self.args, sort_keys=True))
        except Exception:
            return "%s|%r" % (self.tool, self.args)


_CHECK_LINE = re.compile(r"^\s*(?:\*\*)?CHECK(?:\*\*)?\s*:\s*(.+?)\s*$", re.I | re.M)


def split_check(text: str):
    """(thought without its CHECK line, the CHECK command or "")."""
    text = text or ""
    m = _CHECK_LINE.search(text)
    if not m:
        return text.strip(), ""
    check = m.group(1).strip().strip("`").strip()
    rest = (text[:m.start()] + text[m.end():]).strip()
    if check.lower() in ("none", "nothing", "-", "n/a"):
        check = ""
    return rest, check


_JOB_ID = re.compile(r"\b\d{4}-\d{6}-[0-9a-f]{4}\b")
_INTENT = re.compile(
    r"\b(?:i\s+should|i\s+need\s+to|i\s+have\s+to|i\s+must|i'm\s+going\s+to|i\s+am\s+going\s+to|"
    r"i'll|i\s+will|let\s+me|time\s+to|gotta|i\s+want\s+to|go)\b", re.I)
_READ_VERB = re.compile(
    r"\b(?:check|recheck|read|reread|look\s+at|look\s+into|pull\s+up|pull|grep|search|inspect|"
    r"review|verify|confirm|see|find|fetch|scan|run\s+the\s+grep|run\s+the\s+check|tail)\b", re.I)
_WRITE_VERB = re.compile(
    r"\b(?:restart|reboot|kill|stop|start|launch|deploy|ship|push|commit|merge|install|"
    r"uninstall|edit|change|write|delete|remove|rm|fix|patch|repair|send|message|text|email|"
    r"tell|reply|post|pay|buy|order|charge|refund|transfer|cancel|close|rename|move|update|"
    r"upgrade|revert|reset|rollback|roll\s+back|apply|run\s+the\s+(?:job|script|migration))\b", re.I)
_STOP_MULLING = re.compile(
    r"\b(?:stop|quit)\s+(?:thinking|talking|narrating|circling|promising|stalling|waiting|"
    r"wondering|worrying)(?:\s+about\s+(?:it|this|that))?(?:\s+and)?\b", re.I)
_LOGS = re.compile(r"\b(?:journalctl|journal|the\s+logs?|service\s+logs?|leon\s+logs?)\b", re.I)
_JOBS = re.compile(r"\b(?:coding\s+jobs?|the\s+jobs?|job\s+list|jobs?\s+(?:list|results?|status)|"
                   r"result\s+files?)\b", re.I)
_GIT = re.compile(r"\b(?:git\s+status|git\s+log|the\s+repo|what'?s\s+committed|head\s+commit)\b", re.I)
_TOPIC_STOP = set("""a an the and or of to in on for with that this it is was be who what when where why
how which actually really exact exactly real actual just still again called call caller calls about
from into there here them their they his him dean leon logs log journalctl journal grep check checking
something someone anything thing things line lines entry entries so then than""".split())


def _topic_words(text: str) -> List[str]:
    out = []
    for w in re.findall(r"[a-z][a-z0-9_.\-]{3,}", (text or "").lower()):
        w = w.strip(".-")
        if w in _TOPIC_STOP or w in out:
            continue
        out.append(w)
    return out[:3]


def _stem(word: str) -> str:
    for suf in ("ing", "ed", "er", "s"):
        if word.endswith(suf) and len(word) - len(suf) >= 4:
            return word[:-len(suf)]
    return word


def _sentence_with(pattern, text: str) -> str:
    for s in re.split(r"(?<=[.!?])\s+", text or ""):
        if pattern.search(s):
            return s
    return ""


def _infer(thought: str) -> Optional[Intent]:
    """A read-only intent stated in words, mapped to a concrete check."""
    sentence = ""
    for s in re.split(r"(?<=[.!?])\s+", thought or ""):
        if _INTENT.search(s) and _READ_VERB.search(s):
            sentence = s
            break
    if not sentence:
        return None
    action = sentence.strip()
    tail = sentence[_INTENT.search(sentence).end():]
    # "stop thinking about it and read the result files" stops nothing real.
    tail = _STOP_MULLING.sub(" ", tail)
    if _WRITE_VERB.search(re.split(r"\b(?:for|about|to\s+see|whether|if)\b", tail, 1)[0]):
        return None   # "check and restart it" is not a read
    jid = _JOB_ID.search(sentence)
    if jid:
        return Intent(action, True, "coding_job_status", {"job_id": jid.group(0)},
                      "job %s" % jid.group(0), [jid.group(0)])
    if _LOGS.search(sentence):
        after = re.split(r"\b(?:journalctl|journal|logs?)\b", sentence, 1, flags=re.I)[-1]
        after = re.split(r"\b(?:for|about|on|showing|where)\b", after, 1, flags=re.I)[-1] \
            if re.search(r"\b(?:for|about|on|showing|where)\b", after, re.I) else ""
        after = re.split(r",|\bso\b|\bbecause\b|\bbefore\b|\band\s+then\b", after, 1, flags=re.I)[0]
        words = [_stem(w) for w in _topic_words(after)]
        cmd = 'journalctl -u %s --since "-2 hours" --no-pager -o short-iso' % service_unit()
        if words:
            cmd += " | grep -i -E %s" % shlex.quote("|".join(re.escape(w) for w in words))
        cmd += " | tail -n 40"
        label = "journalctl for %s" % service_unit() + (" (%s)" % ", ".join(words) if words else "")
        if readonly_shell(cmd):
            return None
        return Intent(action, True, "shell_exec", {"command": cmd, "timeout_s": TOOL_TIMEOUT_S},
                      label, ["journalctl"] + words)
    if _JOBS.search(sentence):
        return Intent(action, True, "coding_jobs_list", {"limit": 10}, "the coding job list",
                      ["jobs"])
    if _GIT.search(sentence):
        return Intent(action, True, "shell_exec",
                      {"command": "git status --short --branch", "timeout_s": TOOL_TIMEOUT_S},
                      "git status", ["git"])
    return None


def _from_check(check: str, thought: str) -> Intent:
    # Silencing stderr is harmless; shell_exec captures it separately anyway.
    check = re.sub(r"\s+2>\s*/dev/null|\s+2>&1", "", check.strip())
    action = check
    m = re.match(r"^(coding_jobs_list|coding_job_status)\b\s*(.*)$", check)
    if m:
        if m.group(1) == "coding_jobs_list":
            return Intent(action, True, "coding_jobs_list", {"limit": 10}, "the coding job list",
                          ["jobs"])
        jid = _JOB_ID.search(m.group(2) or "") or _JOB_ID.search(thought or "")
        if not jid:
            return Intent(action, False)
        return Intent(action, True, "coding_job_status", {"job_id": jid.group(0)},
                      "job %s" % jid.group(0), [jid.group(0)])
    why = readonly_shell(check)
    if why:
        print("[SHARED-MIND] CHECK not run (%s): %s" % (why, check[:160]), flush=True)
        return Intent(action, False)
    prog = check.split()[0]
    words = [w for w in _topic_words(check) if w != prog][:2]
    return Intent(action, True, "shell_exec", {"command": check, "timeout_s": TOOL_TIMEOUT_S},
                  check[:120], [prog] + words)


def intent_for(thought: str, check: str = "") -> Optional[Intent]:
    """The action in a thought: a runnable read-only check, a mutating action
    (readonly=False, for action_cues), or None."""
    if check:
        return _from_check(check, thought)
    found = _infer(thought)
    if found is not None:
        return found
    try:
        from brain import action_cues
        action = action_cues.classify(thought)
    except Exception:
        action = None
    if not action:
        return None
    return Intent(action, False)


# ── findings: what the inner voice checked, shared with everything else ────

@dataclass
class Finding:
    ts: float
    key: str
    tool: str
    args: Dict[str, Any]
    label: str
    topic: List[str]
    ok: bool
    result: str
    thought: str = ""
    noted: bool = False          # an "Already checked" thought was made from it

    def age(self, now: float) -> str:
        mins = max(0, int((now - self.ts) / 60))
        return "just now" if mins < 1 else "%d min ago" % mins


_lock = threading.RLock()
_findings: Deque[Finding] = deque(maxlen=60)
_calls: Deque[float] = deque(maxlen=200)


def reset() -> None:
    with _lock:
        _findings.clear()
        _calls.clear()


def findings(window_s: float = DEDUPE_S, now: Optional[float] = None) -> List[Finding]:
    now = time.time() if now is None else now
    with _lock:
        return [f for f in _findings if now - f.ts <= window_s]


def _result_text(resp: Any) -> str:
    """A tool response as plain text for prompts and the ledger."""
    if not isinstance(resp, dict):
        return str(resp)
    if not resp.get("ok", True) and resp.get("error"):
        return "ERROR: %s" % resp.get("error")
    value = resp.get("value", resp)
    if isinstance(value, dict) and isinstance(value.get("result"), dict) and "stdout" in value["result"]:
        r = value["result"]
        out = (r.get("stdout") or "").strip()
        err = (r.get("stderr") or "").strip()
        text = out or err or "(no output)"
        if r.get("rc") not in (0, None) and not out:
            text = "rc=%s %s" % (r.get("rc"), text)
        return text
    if isinstance(value, dict) and value.get("ok") is False and value.get("error"):
        return "ERROR: %s" % value.get("error")
    try:
        return json.dumps(value, ensure_ascii=False, default=str)
    except Exception:
        return str(value)


def _masked(text: str) -> str:
    try:
        from server.coding_jobs import mask_secrets
        return mask_secrets(text)
    except Exception:
        return text


def _coding_jobs_list(args: Dict[str, Any]) -> Dict[str, Any]:
    from server import coding_jobs
    body = coding_jobs.list_jobs(int(args.get("limit") or 10))
    try:
        from brain import evidence_ledger
        evidence_ledger.note_jobs(body.get("jobs") or [], source="inner_voice")
    except Exception:
        pass
    jobs = [{"job_id": j.get("job_id"), "state": j.get("state"),
             "task": " ".join(str(j.get("task") or "").split())[:100]}
            for j in body.get("jobs") or []]
    return {"ok": bool(body.get("ok")), "error": body.get("error"),
            "value": {"running": body.get("running_count", 0), "jobs": jobs}}


def _coding_job_status(args: Dict[str, Any]) -> Dict[str, Any]:
    from server import coding_jobs
    body = coding_jobs.job_stream(args.get("job_id") or "", 0)
    if not body.get("ok"):
        return {"ok": False, "error": body.get("error") or "unavailable"}
    job = body.get("job") or {}
    said = [e.get("text") for e in body.get("entries") or [] if isinstance(e, dict) and e.get("text")]
    return {"ok": True, "value": {"job_id": job.get("job_id"), "state": job.get("state"),
                                  "error": job.get("error"), "last": (said[-1] if said else "")[:800]}}


_IN_PROCESS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    "coding_jobs_list": _coding_jobs_list,
    "coding_job_status": _coding_job_status,
}


def _dispatch(name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """The main loop's tool runner (what /api/leon/tool runs)."""
    if name in _IN_PROCESS:
        return _IN_PROCESS[name](args)
    from server.routers.agent_routes import dispatch
    return dispatch(name, args)


def run_tool(name: str, args: Dict[str, Any], timeout_s: float = TOOL_TIMEOUT_S) -> Dict[str, Any]:
    """_dispatch with a hard deadline, on a worker thread."""
    box: Dict[str, Any] = {}

    def work():
        try:
            box["resp"] = _dispatch(name, dict(args))
        except Exception as exc:
            box["resp"] = {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}

    worker = threading.Thread(target=work, daemon=True, name="shared-mind-tool")
    worker.start()
    worker.join(timeout_s + 1.0)
    if worker.is_alive():
        return {"ok": False, "error": "timed out after %.0fs" % timeout_s}
    return box.get("resp") or {"ok": False, "error": "no result"}


def _ledger_match(intent: Intent, now: float):
    """A tool call any turn made in the last 30 minutes that did this check."""
    try:
        from brain import evidence_ledger
        entries = evidence_ledger.recent(DEDUPE_S, kind="tool", now=now)
    except Exception:
        return None
    lead = (intent.topic or [""])[0]
    rest = intent.topic[1:]
    for e in reversed(entries):
        if e.source == "inner_voice" or not e.result:
            continue
        name = (e.name or "").lower()
        names = (intent.tool, "bash") if intent.tool == "shell_exec" else (intent.tool,)
        if not any(name == n or name.endswith("__" + n) for n in names):
            continue
        text = (e.summary or "").lower()
        if intent.tool == "shell_exec":
            if lead and lead not in text:
                continue
            if rest and not any(w in text for w in rest):
                continue
        elif lead and intent.tool == "coding_job_status" and lead not in text:
            continue
        return e
    return None


def _already(intent: Intent, now: float):
    """A finding (or another turn's tool call) that already did this check."""
    with _lock:
        for f in reversed(_findings):
            if now - f.ts > DEDUPE_S:
                break
            if f.key == intent.key:
                return f
            if f.tool == intent.tool and intent.topic and f.topic \
                    and intent.topic[0] == f.topic[0] \
                    and (len(intent.topic) == 1 or set(intent.topic[1:]) & set(f.topic[1:])):
                return f
    e = _ledger_match(intent, now)
    if e is not None:
        f = Finding(ts=e.ts, key=intent.key, tool=intent.tool, args=dict(intent.args),
                    label=intent.label, topic=list(intent.topic), ok=e.ok,
                    result=(e.result or "")[:RESULT_CHARS], thought="(checked in a turn)")
        with _lock:
            _findings.append(f)
        return f
    return None


# "I still haven't run it" about a check that did run.
_UNRAN = re.compile(
    r"\b(?:haven'?t|have\s+not|never|keep\s+not|still\s+not|didn'?t|did\s+not|not\s+once|"
    r"keep\s+promising|promising|instead\s+of)\b[^.!?]{0,40}?\b(?:run|ran|running|check|checked|"
    r"checking|grep|grepped|grepping|look|looked|read|pulled|pull)", re.I)


def _stale_about(thought: str, now: float) -> Optional[Finding]:
    """A thought complaining that a check never ran, when it ran recently."""
    if not _UNRAN.search(thought or ""):
        return None
    low = (thought or "").lower()
    with _lock:
        for f in reversed(_findings):
            if now - f.ts > DEDUPE_S:
                break
            lead = (f.topic or [""])[0]
            if lead and (lead in low or (lead == "journalctl" and re.search(r"\b(?:grep|logs?|journal)", low))
                         or (lead == "jobs" and "job" in low)):
                return f
    return None


def _calls_left(now: float) -> int:
    with _lock:
        while _calls and now - _calls[0] > RATE_WINDOW_S:
            _calls.popleft()
        return max_calls() - len(_calls)


def _already_note(f: Finding, now: float) -> str:
    result = " ".join((f.result or "").split())[:220] or "(no output)"
    return "Already checked %s %s: %s" % (f.label, f.age(now), result)


@dataclass
class Outcome:
    kind: str            # none | ran | already | suppressed | queued | deferred
    text: str = ""       # the thought to store ("" = drop it)
    finding: Optional[Finding] = None
    why: str = ""


def _queue(thought: str, trigger: str, intent: Optional[Intent]) -> bool:
    """Hand the thought's action to action_cues, for Leon's next turn."""
    try:
        from brain import action_cues
        if action_cues.classify(thought):
            return bool(action_cues.on_thought(thought, trigger))
        if intent is not None and intent.action:
            return bool(action_cues.add_cue(intent.action, source="thought", source_text=thought))
    except Exception:
        pass
    return False


def on_thought(thought: str, check: str = "", trigger: str = "",
               now: Optional[float] = None) -> Outcome:
    """Act on one inner thought, in the same loop that thought it."""
    now = time.time() if now is None else now
    try:
        intent = intent_for(thought, check)
    except Exception as exc:
        print("[SHARED-MIND] intent failed: %s" % type(exc).__name__, flush=True)
        intent = None

    if intent is None:
        stale = _stale_about(thought, now)
        if stale is not None:
            return _repeat(stale, thought, now)
        return Outcome("none", thought)

    if not intent.readonly or not intent.tool:
        # As before this module: only what action_cues itself recognises in
        # the words is queued, never a raw command from a CHECK line.
        queued = _queue(thought, trigger, None)
        return Outcome("queued" if queued else "none", thought, why="not a read-only check")

    hit = _already(intent, now)
    if hit is not None:
        return _repeat(hit, thought, now)

    if not acting_enabled():
        _queue(thought, trigger, intent)
        return Outcome("queued", thought, why="acting disabled")
    if _calls_left(now) <= 0:
        _queue(thought, trigger, intent)
        print("[SHARED-MIND] rate limit (%d per 10 min): %s queued" % (max_calls(), intent.label),
              flush=True)
        return Outcome("deferred", thought, why="rate limit")

    with _lock:
        _calls.append(now)
    t0 = time.time()
    resp = run_tool(intent.tool, intent.args)
    ok = bool(resp.get("ok", False)) if isinstance(resp, dict) else False
    result = _masked(_result_text(resp))[:RESULT_CHARS]
    f = Finding(ts=time.time(), key=intent.key, tool=intent.tool, args=dict(intent.args),
                label=intent.label, topic=list(intent.topic), ok=ok, result=result,
                thought=(thought or "")[:300])
    with _lock:
        _findings.append(f)
    try:
        from brain import evidence_ledger
        summary = intent.args.get("command") if intent.tool == "shell_exec" else json.dumps(intent.args)
        evidence_ledger.record_tool(intent.tool, summary or "", ok=ok, result=result,
                                    source="inner_voice")
    except Exception:
        pass
    print("[SHARED-MIND] checked %s in %.1fs ok=%s: %s" % (
        intent.label, time.time() - t0, ok, " ".join(result.split())[:160]), flush=True)
    try:
        from server.helpers import broadcast_activity
        broadcast_activity("inner", "Checked %s" % intent.label, 6000)
    except Exception:
        pass
    return Outcome("ran", thought, finding=f)


def _repeat(f: Finding, thought: str, now: float) -> Outcome:
    with _lock:
        first = not f.noted
        f.noted = True
    if first:
        note = _already_note(f, now)
        print("[SHARED-MIND] repeat of a check already done -> %s" % note[:160], flush=True)
        return Outcome("already", note, finding=f, why="already checked")
    print("[SHARED-MIND] thought dropped (repeats %s, checked %s): %r"
          % (f.label, f.age(now), (thought or "")[:80]), flush=True)
    return Outcome("suppressed", "", finding=f, why="already checked")


# ── one context for thinking and replying ──────────────────────────────────

def _text_of(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, dict) and b.get("type") == "text":
                parts.append(b.get("text") or "")
        return " ".join(parts)
    return ""


def _recent_turns(limit: int = CONTEXT_TURNS) -> List[Dict[str, str]]:
    st = sys.modules.get("server.state")
    responder = getattr(st, "brain_api_responder", None) if st is not None else None
    if responder is None:
        return []
    rows: List[Dict[str, Any]] = []
    store = getattr(responder, "_conversation_store", None)
    if store is not None:
        try:
            rows = store.load_recent(limit=limit * 2)
        except Exception:
            rows = []
    if not rows:
        rows = list(getattr(responder, "history", None) or [])[-limit * 2:]
    out = []
    for r in rows:
        text = " ".join(_text_of(r.get("content")).split())
        if not text or text.startswith(("[INTERNAL", "/cli [INTERNAL")):
            continue
        out.append({"role": r.get("role") or "", "text": text})
    return out[-limit:]


def context_block(now: Optional[float] = None) -> str:
    """What the inner voice thinks from: the same things the reply path sees."""
    now = time.time() if now is None else now
    try:
        from brain.identity import si_name
        me = si_name()
    except Exception:
        me = "Leon"
    parts: List[str] = []
    try:
        turns = _recent_turns()
        if turns:
            lines = ["The conversation with Dean, most recent last (your own replies included):"]
            for t in turns:
                who = "You" if t["role"] == "assistant" else "Dean"
                lines.append("- %s: %s" % (who, t["text"][:280]))
            parts.append("\n".join(lines))
    except Exception:
        pass
    try:
        from brain import evidence_ledger
        tools = [e for e in evidence_ledger.recent(DEDUPE_S, kind="tool", now=now)][-CONTEXT_TOOLS:]
        if tools:
            lines = ["Tools you ran in the last 30 minutes and what came back:"]
            for e in tools:
                mins = max(0, int((now - e.ts) / 60))
                lines.append("- %s %s%s: %s -> %s" % (
                    "just now" if mins < 1 else "%d min ago" % mins, e.name,
                    " (inner voice)" if e.source == "inner_voice" else "",
                    e.summary[:140] or "(no args)",
                    (e.result[:200] if e.result else ("ok" if e.ok else "error"))))
            parts.append("\n".join(lines))
        jobs = evidence_ledger.job_states(DEDUPE_S)
        if jobs:
            lines = ["Coding jobs (latest reading):"]
            for j in sorted(jobs, key=lambda j: -float(j.get("ts") or 0))[:6]:
                lines.append("- %s: %s %s" % (j.get("job_id"), j.get("state"),
                                              (j.get("task") or j.get("summary") or "")[:100]))
            parts.append("\n".join(lines))
    except Exception:
        pass
    try:
        # Read-only: open_tasks()/open_cues() would rewrite expired rows.
        from brain import action_cues
        tasks = sorted((t for t in action_cues._load_tasks() if t.get("status") == "open"
                        and now - float(t.get("created") or 0) <= action_cues.TASK_TTL_S),
                       key=lambda t: float(t.get("created") or 0))
        if tasks:
            parts.append("Open tasks Dean is waiting on:\n" + "\n".join(
                "- (%s) %s" % (action_cues._age(t.get("created"), now), t.get("text", "")[:160])
                for t in tasks[:5]))
        cues = [r for r in action_cues._load() if r.get("status") == "open"
                and now - float(r.get("created") or 0) <= (
                    action_cues.JOB_CUE_TTL_S if r.get("source") == "job"
                    else action_cues.THOUGHT_CUE_TTL_S)]
        if cues:
            parts.append("Follow-throughs already queued for your next turn:\n" + "\n".join(
                "- %s" % c.get("text", "")[:160] for c in cues[:4]))
    except Exception:
        pass
    done = findings(DEDUPE_S, now)
    if done:
        parts.append("Checks you already ran on your own (don't promise these again; build on "
                     "what they found):\n" + "\n".join(
                         "- %s, %s: %s" % (f.label, f.age(now), " ".join(f.result.split())[:240])
                         for f in done[-5:]))
    if not parts:
        return ""
    return ("What is actually going on (the same record %s's replies use):\n" % me
            + "\n\n".join(parts))


def reply_block(now: Optional[float] = None) -> str:
    """Fresh inner-voice results for the top of Dean's next turn."""
    now = time.time() if now is None else now
    fresh = [f for f in findings(REPLY_FRESH_S, now) if f.thought != "(checked in a turn)"]
    if not fresh:
        return ""
    lines = ["[WHAT YOU CHECKED ON YOUR OWN — real tool results from your inner voice, last "
             "15 min. What you say should agree with these.]"]
    for f in fresh[-3:]:
        lines.append("- %s, %s: %s" % (f.label, f.age(now), " ".join(f.result.split())[:300]))
    return "\n".join(lines)


CHECK_INSTRUCTION = (
    "If the thought is that you should look at something you can check right now without "
    "changing anything (a log, the coding jobs, git status, a file), add one more line: "
    "CHECK: <one read-only shell command; pipes are fine, no redirects, ; or &&>, or CHECK: "
    "coding_jobs_list, or CHECK: coding_job_status <job id>. It runs right away and you'll "
    "see the result next time. "
    "Restarts, edits, deploys and messages are not checks; just think them. Don't promise a "
    "check already listed above as done.")
