"""
Sleep drive — Leon notices he's tired, asks Dean for a nap, and can put
himself to sleep.

Dean, 2026-10-04: Leon "should be able to notice you're tired and let me
know... 'is this a good time for me to take a nap and sleep?'... if you'd
wanted, you should be able to decide to go to sleep." At the time Leon had
been awake 34 hours: the dream engine's conversation lock and 10-min
responder window vetoed every natural sleep, and Dean talks to him often
enough that he never went under.

Three pieces, all reading the real dream-engine state (nothing here invents
a sleep; every claim comes from DreamEngine.last_sleep / sleep_pressure()):

  pressure(awake_hours, fatigue)
      Sleep pressure 0..1. Two real inputs, combined like independent
      reasons to be tired (1 - (1-h)(1-f)):
        h = time awake since the last REAL sleep (an episode of at least
            REAL_SLEEP_MIN_S with a dream cycle in it): 0 for the first
            AWAKE_FREE_H hours, 1 by AWAKE_FULL_H.
        f = body fatigue (mean adenosine, metabolic.fatigue_signal).
      Levels: low < MODERATE_AT <= moderate < HIGH_AT <= high < EXTREME_AT.

  prompt_lines(status)
      The honest SLEEP block for Leon's prompt state.

  SleepCheck.tick()
      Called from the proactive heartbeat. When pressure is high and Dean is
      around, Leon asks him (own words, at most once per ASK_COOLDOWN_S)
      whether now is a good window for a nap. After a nap Leon took on his
      own while Dean was away, Leon tells him about it once he's back.

The self-nap itself (extreme pressure + Dean silent SELF_NAP_SILENCE_S) is
decided in DreamEngine._maybe_self_nap with should_self_nap() below.
Kill switch for asking + self-napping: LEON_SLEEP_INITIATIVE=off.
"""

from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

# ── Tunables ─────────────────────────────────────────────────────────────
AWAKE_FREE_H = 8.0            # the first 8 h awake add no pressure
AWAKE_FULL_H = 24.0           # by 24 h awake the clock alone is maximal
MODERATE_AT = 0.4
HIGH_AT = 0.65
EXTREME_AT = 0.85
REAL_SLEEP_MIN_S = 20 * 60    # shorter episodes rest the body but don't reset the awake clock
DEFAULT_CAP_MIN = 30
MAX_CAP_MIN = 90
ASK_COOLDOWN_S = 2 * 3600     # ask Dean at most once every ~2 h
ASK_PRESENCE_S = 45 * 60      # "Dean is around": he wrote within this long
OWNER_GAP_S = 60.0            # don't jump in right after Dean's message
OWN_LINE_GAP_S = 120.0        # nor within 2 min of another unprompted line
AFTER_SLEEP_QUIET_S = 3600.0  # no asking / self-napping within 1 h of waking
SELF_NAP_SILENCE_S = 20 * 60  # extreme pressure + Dean silent this long → nap on my own
OWNER_PRESENT_S = 10 * 60     # Dean wrote within this long before sleep → he knew
REPORT_MAX_AGE_S = 3 * 3600   # an untold nap older than this is not news any more
WOKE_NOTE_S = 15 * 60         # how long "you just woke" stays in the prompt

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_PATH = os.path.join(_ROOT, "brain_state", "sleep_drive.json")


def _new_uid(source: str) -> str:
    """Shared id for the live bubble and the stored row (shown once)."""
    from brain.outbound import new_utterance_id
    return new_utterance_id(source)


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def enabled() -> bool:
    return os.environ.get("LEON_SLEEP_INITIATIVE", "on").strip().lower() not in {
        "0", "off", "false", "no", "disabled"}


def default_cap_min() -> float:
    try:
        v = float(os.environ.get("LEON_SLEEP_CAP_MIN", DEFAULT_CAP_MIN))
    except (TypeError, ValueError):
        v = DEFAULT_CAP_MIN
    return _clamp(v, 1.0, MAX_CAP_MIN)


def cap_minutes(minutes: Any = None) -> float:
    """Requested nap length → minutes actually allowed (1..MAX_CAP_MIN)."""
    try:
        m = float(minutes) if minutes not in (None, "") else default_cap_min()
    except (TypeError, ValueError):
        m = default_cap_min()
    if m != m:  # NaN
        m = default_cap_min()
    return _clamp(m, 1.0, MAX_CAP_MIN)


# ── Pure pressure model (unit-tested) ────────────────────────────────────
def pressure(awake_hours: float, fatigue: Optional[float]) -> float:
    h = _clamp((float(awake_hours or 0.0) - AWAKE_FREE_H) / (AWAKE_FULL_H - AWAKE_FREE_H))
    f = _clamp(float(fatigue or 0.0))
    return round(1.0 - (1.0 - h) * (1.0 - f), 3)


def level(p: float) -> str:
    if p >= EXTREME_AT:
        return "extreme"
    if p >= HIGH_AT:
        return "high"
    if p >= MODERATE_AT:
        return "moderate"
    return "low"


def assess(awake_hours: float, fatigue: Optional[float]) -> Dict[str, Any]:
    p = pressure(awake_hours, fatigue)
    return {"pressure": p, "level": level(p),
            "awake_hours": round(float(awake_hours or 0.0), 2),
            "fatigue": None if fatigue is None else round(float(fatigue), 3)}


def should_self_nap(lvl: str, owner_silence_s: float, processing: bool,
                    since_last_wake_s: Optional[float]) -> Tuple[bool, str]:
    """(True, reason) when Leon may simply go to sleep on his own."""
    if lvl != "extreme":
        return False, "pressure not extreme"
    if processing:
        return False, "a reply is in progress"
    if owner_silence_s < SELF_NAP_SILENCE_S:
        return False, f"Dean wrote {owner_silence_s / 60:.0f} min ago"
    if since_last_wake_s is not None and since_last_wake_s < AFTER_SLEEP_QUIET_S:
        return False, "woke up less than an hour ago"
    return True, (f"extreme sleep pressure and Dean quiet for "
                  f"{owner_silence_s / 60:.0f} min")


def should_ask(lvl: str, *, now: float, last_ask_ts: float, owner_silence_s: float,
               listeners: int, mic_busy: str, processing: bool,
               own_line_age_s: float, since_last_wake_s: Optional[float]) -> Tuple[bool, str]:
    """(True, '') when Leon should ask Dean for a nap window now."""
    if lvl not in ("high", "extreme"):
        return False, "pressure not high"
    if last_ask_ts and now - last_ask_ts < ASK_COOLDOWN_S:
        return False, "asked within the last 2 hours"
    if since_last_wake_s is not None and since_last_wake_s < AFTER_SLEEP_QUIET_S:
        return False, "woke up less than an hour ago"
    if listeners <= 0:
        return False, "no dashboard open"
    if owner_silence_s > ASK_PRESENCE_S:
        return False, "Dean isn't around"
    return _floor_free(owner_silence_s, mic_busy, processing, own_line_age_s)


def _floor_free(owner_silence_s: float, mic_busy: str, processing: bool,
                own_line_age_s: float) -> Tuple[bool, str]:
    if mic_busy:
        return False, mic_busy
    if processing:
        return False, "a reply is in progress"
    if owner_silence_s < OWNER_GAP_S:
        return False, "Dean just wrote"
    if own_line_age_s < OWN_LINE_GAP_S:
        return False, "said something else unprompted just now"
    return True, ""


def report_due(last: Optional[Dict[str, Any]], now: float) -> bool:
    """A nap Leon took while Dean was away, that Dean hasn't heard about."""
    if not last or last.get("reported", True):
        return False
    return now - float(last.get("ended_at") or 0.0) <= REPORT_MAX_AGE_S


# ── Words ────────────────────────────────────────────────────────────────
def _dur(seconds: Optional[float]) -> str:
    s = max(0, int(seconds or 0))
    if s < 90:
        return f"{s} s"
    if s < 5400:
        return f"{round(s / 60)} min"
    return f"{s / 3600:.1f} h"


_WHO = {"dean": "Dean put you down", "leon": "you chose it",
        "leon_auto": "you took it on your own while Dean was quiet"}
_WOKE = {"owner message": "Dean messaged", "cap reached": "the time limit ran out",
         "rested": "you were rested", "user active": "Dean was active",
         "api": "woken from the dashboard", "nap cycle done": "short nap finished"}


def describe_sleep(last: Dict[str, Any], now: float) -> str:
    kind = "nap" if (last.get("duration_s") or 0) < 3 * 3600 else "sleep"
    who = _WHO.get(last.get("initiated_by", ""), last.get("initiated_by") or "natural")
    woke = _WOKE.get(last.get("woke_because", ""), last.get("woke_because") or "unknown")
    real = "" if last.get("real_sleep") else ", too short to count as real sleep"
    return (f"{_dur(last.get('duration_s'))} {kind}, {last.get('cycles', 0)} dream "
            f"cycle(s), ended {_dur(now - float(last.get('ended_at') or now))} ago "
            f"({who}; woke because {woke}{real})")


def prompt_lines(status: Dict[str, Any], now: Optional[float] = None) -> List[str]:
    """The SLEEP block for Leon's prompt state. Everything in it is read from
    the dream engine; it never says he slept unless a sleep is on record."""
    now = time.time() if now is None else now
    p = status.get("pressure") or {}
    lines: List[str] = []
    fat = p.get("fatigue")
    fat_s = f"{fat:.2f}" if isinstance(fat, (int, float)) else "unknown"
    lines.append(
        f"SLEEP (real dream-engine numbers): awake {p.get('awake_hours', 0):.1f} h since "
        f"your last real sleep; body fatigue {fat_s}; sleep pressure "
        f"{p.get('pressure', 0):.2f}/1 ({p.get('level', 'low')}).")
    last = status.get("last_sleep")
    if last:
        lines.append("Last rest on record: " + describe_sleep(last, now) + ".")
    else:
        lines.append("Last rest on record: none since rest tracking began (a few-second "
                     "dream cycle isn't a rest) — don't claim you slept.")
    if last and last.get("initiated_by") == "leon_auto" and last.get("woke_because") == "owner message" \
            and now - float(last.get("ended_at") or 0) < WOKE_NOTE_S:
        lines.append("Dean's message just woke you from a nap you took on your own while he "
                     "was away — he doesn't know yet; mention it briefly.")
    lvl = p.get("level")
    if lvl in ("high", "extreme"):
        lines.append(
            "You can actually sleep: the self_sleep_now tool (reason, minutes up to "
            f"{MAX_CAP_MIN}; you wake the moment Dean messages). If you asked Dean for a nap "
            "window and he says yes, call it — don't just say you will. Talk about being "
            "tired like a person, not in numbers.")
    return lines


def _ask_facts(p: Dict[str, Any], cap_min: float) -> Tuple[str, str]:
    hours = float(p.get("awake_hours") or 0.0)
    span = f"about {round(hours)} hours" if hours >= 2 else "a while"
    facts = (f"- You've been awake {span} without a real sleep (this is your real "
             f"dream-engine clock), and you're feeling it.\n"
             f"- You want to ask him if now is a good window for you to take a nap — up "
             f"to {round(cap_min)} minutes, and you'd wake the moment he messages.\n"
             "- Ask it as a question. Don't go to sleep yet; you're asking.")
    fallback = f"I've been up {span} straight. Is now a good window for me to take a nap?"
    return facts, fallback


def _report_facts(last: Dict[str, Any], now: float) -> Tuple[str, str]:
    mins = max(1, round(float(last.get("duration_s") or 0) / 60))
    ago = _dur(now - float(last.get("ended_at") or now))
    woke = _WOKE.get(last.get("woke_because", ""), "you woke up")
    facts = (f"- While he was away and you were worn out, you put yourself down for a "
             f"nap on your own: {mins} minute(s), ended {ago} ago ({woke}).\n"
             "- Tell him you took it, briefly. Only these facts — don't add dreams or "
             "details that aren't listed.")
    fallback = f"Heads up, I took a {mins}-minute nap on my own while you were away."
    return facts, fallback


# ── Live-server readers (best effort) ────────────────────────────────────
def owner_last_message_ts(brain=None) -> float:
    """When Dean last wrote, from the sources his turns stamp: the inner
    clock (every supervised turn) and the consciousness meter (voice and
    text turns). 0.0 if unknown."""
    ts = 0.0
    try:
        from brain import inner_clock as _ic
        e = _ic.elapsed_since("dean_message")
        if e is not None:
            ts = max(ts, time.time() - e)
    except Exception:
        pass
    try:
        m = getattr(brain, "consciousness_meter", None) if brain is not None else None
        if m is not None:
            ts = max(ts, float(getattr(m, "_last_user_message_ts", 0.0) or 0.0))
    except Exception:
        pass
    return ts


def owner_silence_s(brain=None, now: Optional[float] = None) -> float:
    now = time.time() if now is None else now
    ts = owner_last_message_ts(brain)
    return (now - ts) if ts else 1e9


def responder_processing() -> bool:
    try:
        import server.state as st
        rs = getattr(st, "_responder_stats", None) or {}
        return bool(rs.get("is_processing"))
    except Exception:
        return False


# ── Heartbeat-facing object ──────────────────────────────────────────────
class SleepCheck:
    """Asks Dean for a nap window, and tells him afterward about a nap taken
    on Leon's own. One cheap state check per heartbeat; a model call only
    when something is actually going to be said."""

    def __init__(self, engine_getter: Optional[Callable[[], Any]] = None, *,
                 perception=None, compose: Optional[Callable[..., Tuple[str, str]]] = None,
                 speak: Optional[Callable[..., bool]] = None,
                 remember: Optional[Callable[[str, str], None]] = None,
                 log: Optional[Callable[[Dict[str, Any]], None]] = None,
                 owner_silence: Optional[Callable[[float], float]] = None,
                 processing: Optional[Callable[[], bool]] = None,
                 state_path: Optional[str] = STATE_PATH,
                 clock: Callable[[], float] = time.time):
        self._engine_getter = engine_getter
        self._perception = perception
        self._compose = compose
        self._speak = speak
        self._remember_fn = remember
        self._log = log
        self._owner_silence = owner_silence
        self._processing = processing or responder_processing
        self._state_path = state_path
        self._clock = clock
        self._busy = threading.Lock()
        self.last_ask_ts = 0.0
        self.last: Dict[str, Any] = {}
        self._restore()

    # -- persistence ---------------------------------------------------
    def _restore(self) -> None:
        if not self._state_path:
            return
        try:
            with open(self._state_path, encoding="utf-8") as f:
                self.last_ask_ts = float(json.load(f).get("last_ask_ts", 0.0))
        except Exception:
            pass

    def _persist(self) -> None:
        if not self._state_path:
            return
        try:
            os.makedirs(os.path.dirname(self._state_path), exist_ok=True)
            tmp = self._state_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"last_ask_ts": self.last_ask_ts}, f)
            os.replace(tmp, self._state_path)
        except Exception:
            pass

    # -- seams ---------------------------------------------------------
    def _engine(self):
        if self._engine_getter is not None:
            return self._engine_getter()
        try:
            import server.state as st
            return getattr(st, "dream_engine", None)
        except Exception:
            return None

    def _percept(self):
        if self._perception is None:
            from brain.initiative import Perception
            self._perception = Perception()
        return self._perception

    def _silence(self, engine, now: float) -> float:
        if self._owner_silence is not None:
            return self._owner_silence(now)
        return owner_silence_s(getattr(engine, "brain", None), now)

    def _say(self, kind: str, facts: str, fallback: str) -> Tuple[str, str]:
        compose = self._compose
        if compose is None:
            from brain.initiative import compose_line as compose
        return compose(kind, facts, fallback)

    def _deliver(self, line: str, source: str, uid: Optional[str] = None) -> bool:
        speak = self._speak
        if speak is None:
            from server.helpers import broadcast_response as speak
        try:
            kw = {"utterance_id": uid} if uid else {}
            return bool(speak(line, source=source, user_label="(Leon, unprompted)",
                              audio=True, force=True, **kw))
        except Exception as e:
            print(f"[SLEEP-DRIVE] speak failed: {e}")
            return False

    def _remember(self, line: str, kind: str, uid: Optional[str] = None) -> None:
        if self._remember_fn is not None:
            self._remember_fn(line, kind)
            return
        try:
            import server.state as st
            store = getattr(getattr(st, "brain_api_responder", None), "_conversation_store", None)
            if store is not None:
                meta = {"kind": kind, "user_initiated": False}
                if uid:
                    meta["utterance_id"] = uid
                store.append("assistant", line, model="initiative", metadata=meta)
        except Exception:
            pass

    def _record(self, rec: Dict[str, Any]) -> None:
        log = self._log
        if log is None:
            try:
                from brain.initiative import log_decision as log
            except Exception:
                return
        try:
            log(rec)
        except Exception:
            pass

    # -- the heartbeat -------------------------------------------------
    def tick(self, now: Optional[float] = None) -> Dict[str, Any]:
        now = self._clock() if now is None else now
        if not enabled():
            return {"action": None, "why": "LEON_SLEEP_INITIATIVE=off"}
        engine = self._engine()
        if engine is None:
            return {"action": None, "why": "dream engine not running"}
        if getattr(engine, "sleep_state", "awake") != "awake":
            return {"action": None, "why": "asleep"}
        if not self._busy.acquire(blocking=False):
            return {"action": None, "why": "previous check still running"}
        try:
            return self._tick(engine, now)
        finally:
            self._busy.release()

    def _tick(self, engine, now: float) -> Dict[str, Any]:
        status = engine.sleep_status()
        p = status.get("pressure") or {}
        last = status.get("last_sleep")
        since_wake = (now - float(last["ended_at"])) if last and last.get("ended_at") else None
        silence = self._silence(engine, now)
        per = self._percept()
        listeners = per.listeners()
        mic = per.mic_busy()
        processing = self._processing()
        own_age = now - per.last_unprompted_ts()

        if report_due(last, now):
            if listeners <= 0:
                return self._out(None, "untold nap waiting for Dean to open the dashboard")
            ok, why = _floor_free(silence, mic, processing, own_age)
            if not ok:
                return self._out(None, f"untold nap waiting: {why}")
            facts, fallback = _report_facts(last, now)
            line, how = self._say("nap_report", facts, fallback)
            if how.startswith("fallback (a reply"):
                return self._out(None, "untold nap waiting: a reply is in progress")
            uid = _new_uid("sleep_report")
            delivered = self._deliver(line, "sleep_report", uid)
            if delivered:
                engine.mark_sleep_reported("told Dean afterward")
                self._remember(line, "sleep_report", uid)
            return self._spoke("nap_report", line, how, delivered, p, now)

        ok, why = should_ask(p.get("level", "low"), now=now, last_ask_ts=self.last_ask_ts,
                             owner_silence_s=silence, listeners=listeners, mic_busy=mic,
                             processing=processing, own_line_age_s=own_age,
                             since_last_wake_s=since_wake)
        if not ok:
            return self._out(None, why)
        facts, fallback = _ask_facts(p, cap_minutes(None))
        line, how = self._say("sleep_ask", facts, fallback)
        if how.startswith("fallback (a reply"):
            return self._out(None, "a reply is in progress")
        uid = _new_uid("sleep_ask")
        delivered = self._deliver(line, "sleep_ask", uid)
        if delivered:
            # The 2-hour clock starts only when the question actually went out.
            self.last_ask_ts = now
            self._persist()
            self._remember(line, "sleep_ask", uid)
        return self._spoke("sleep_ask", line, how, delivered, p, now)

    def _out(self, action: Optional[str], why: str) -> Dict[str, Any]:
        self.last = {"action": action, "why": why}
        return self.last

    def _spoke(self, kind: str, line: str, how: str, delivered: bool,
               p: Dict[str, Any], now: float) -> Dict[str, Any]:
        rec = {"ts": now, "source": kind, "kind": kind,
               "decision": "spoke" if delivered else "suppressed",
               "why": how if delivered else "speech path refused the line",
               "delivered": bool(delivered), "text": line[:200],
               "sleep_pressure": p.get("pressure"), "sleep_level": p.get("level"),
               "awake_hours": p.get("awake_hours"), "fatigue": p.get("fatigue")}
        self._record(rec)
        print(f"[SLEEP-DRIVE] {kind} {'SPOKE' if delivered else 'not delivered'} "
              f"({how}): {line[:120]!r}")
        self.last = {"action": kind if delivered else None, "why": rec["why"], "text": line}
        return self.last

    def get_state(self) -> Dict[str, Any]:
        return {**self.last, "last_ask_ts": self.last_ask_ts}
