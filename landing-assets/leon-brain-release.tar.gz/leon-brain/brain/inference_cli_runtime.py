"""Explicit lifecycle installation of the verified, subscription-only text CLI.

No discovery, login, auth ping, model call or installation runs at import. The
integrator supplies reviewed authentication/policy evidence; capability probes
alone are never evidence of subscription billing. This adapter owns only its
transport receipts, not scheduling, history or tools.
"""
from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import re
import threading
import time

from .inference_cancel import CancelToken, UnsupportedInferencePolicy
from . import inference_cli_text as transport


@dataclass(frozen=True)
class SubscriptionEvidence:
    """Explicit integrator attestation, not an automatically inferred auth result.

    policy_paths must include every reviewed effective user/project/managed
    settings source (including currently absent candidates) and applicable auth
    provenance files/directories. Directory receipts cover up to 128 immediate
    regular files; nested directories require a separate reviewed strategy.
    No file content or credential is loaded by the installed adapter.
    The integrator chooses validity from actual evidence, not this code.
    """
    evidence_ref: str = ""
    authenticated_subscription: bool = False
    api_key_helper_disabled: bool = False
    managed_policy_compatible: bool = False
    policy_review_complete: bool = False
    valid_until_wall: float = 0.0
    policy_paths: tuple = ()


def _policy_stamp(path):
    value = os.fspath(path)
    if not os.path.isabs(value):
        raise UnsupportedInferencePolicy("absolute reviewed policy paths required")
    resolved = os.path.realpath(value)
    try:
        stat = os.stat(value)
    except FileNotFoundError:
        return (resolved, None)
    stamp = (resolved, stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
    if os.path.isdir(value):
        entries = []
        with os.scandir(value) as children:
            for child in children:
                if len(entries) >= 128 or not child.is_file():
                    raise UnsupportedInferencePolicy("policy directory exceeds reviewed flat-file bounds")
                entries.append((child.name, _policy_stamp(child.path)))
        return stamp + (tuple(sorted(entries)),)
    if not os.path.isfile(value):
        raise UnsupportedInferencePolicy("reviewed policy path must be regular, flat directory or absent")
    return stamp


def _reviewed_env(source):
    """Reject additional credential selection paths before the transport probe.

    File-based profiles, helpers and managed env still require effective-policy
    review. An empty ambient API key is never proof of subscription auth.
    """
    env = transport._subscription_env(source)
    for key in ("ANTHROPIC_PROFILE", "ANTHROPIC_FEDERATION_RULE_ID",
                "ANTHROPIC_ORGANIZATION_ID", "ANTHROPIC_IDENTITY_TOKEN_FILE"):
        if env.get(key):
            raise UnsupportedInferencePolicy("alternate Anthropic credential selection refused")
    return env


@dataclass(frozen=True)
class AuthStatusObservation:
    """Sanitized diagnostic metadata. This is never SubscriptionEvidence.

    Only the observed logged-out enum values are recognized. A positive auth
    schema must be reviewed before it can become an automatic evidence source.
    No raw JSON, stderr, account identity or credential is retained here.
    """
    cli_version: str
    exit_code: int
    logged_in: bool | None
    auth_method: str
    api_provider: str
    subscription_type: str
    schema: tuple


def collect_auth_status(*, executable, cwd, env):
    """Explicit lifecycle diagnostic: help/version, auth help, status JSON only.

    Uses the exact child environment/cwd and bounded existing process owner.
    Never a model/login request; the CLI's internal network behavior is not
    asserted. Does not install a runtime or grant subscription authority.
    """
    frozen_env = _reviewed_env(env)
    if not Path(cwd).is_absolute() or not Path(cwd).is_dir():
        raise UnsupportedInferencePolicy("explicit CLI working directory required")
    contract = transport.verify_cli(executable, env=frozen_env, cwd=cwd)

    def output(args, *, allow_logged_out=False):
        chunks, code = [], 0
        try:
            for chunk in transport._chunks([contract.executable] + args, b"",
                    env=frozen_env, cwd=cwd, deadline_s=10, idle_s=10, output_cap=262144):
                chunks.append(chunk)
        except transport.CliTextError as exc:
            if not allow_logged_out or str(exc) != "cli_exit_1":
                raise UnsupportedInferencePolicy("CLI auth metadata probe failed") from None
            code = 1
        try:
            return b"".join(chunks).decode("utf-8", "strict"), code
        except UnicodeError:
            raise UnsupportedInferencePolicy("invalid CLI auth metadata encoding") from None

    auth_help, _ = output(["auth", "--help"])
    if not re.search(r"\bstatus\b", auth_help):
        raise UnsupportedInferencePolicy("CLI auth status capability unavailable")
    status_help, _ = output(["auth", "status", "--help"])
    if "--json" not in status_help:
        raise UnsupportedInferencePolicy("CLI auth JSON capability unavailable")
    raw, code = output(["auth", "status", "--json"], allow_logged_out=True)
    if transport._stamp(contract.executable) != contract.stamp:
        raise UnsupportedInferencePolicy("CLI changed during auth metadata collection")
    try:
        data = json.loads(raw)
    except (ValueError, RecursionError):
        raise UnsupportedInferencePolicy("invalid CLI auth metadata JSON") from None
    if not isinstance(data, dict) or len(data) > 128:
        raise UnsupportedInferencePolicy("invalid CLI auth metadata object")
    # Schema field names/types only; even unrecognized enum contents stay private.
    schema = tuple(sorted((key, type(value).__name__) for key, value in data.items()
                          if isinstance(key, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,63}", key)))
    logged = data.get("loggedIn")
    logged = logged if type(logged) is bool else None
    if code == 1 and logged is not False:
        raise UnsupportedInferencePolicy("inconsistent CLI auth metadata exit status")
    def observed(key, allowed):
        value = data.get(key)
        return value if isinstance(value, str) and value in allowed else ("absent" if key not in data else "unrecognized")
    return AuthStatusObservation(contract.version, code, logged,
        observed("authMethod", {"none"}), observed("apiProvider", {"firstParty"}),
        observed("subscriptionType", set()), schema)


def _validate_evidence(evidence):
    if not isinstance(evidence, SubscriptionEvidence) or any(value is not True for value in (
            evidence.authenticated_subscription, evidence.api_key_helper_disabled,
            evidence.managed_policy_compatible, evidence.policy_review_complete)):
        raise UnsupportedInferencePolicy("subscription auth and effective policy require explicit review")
    if not isinstance(evidence.evidence_ref, str) or not 1 <= len(evidence.evidence_ref) <= 160:
        raise UnsupportedInferencePolicy("opaque subscription evidence reference required")
    if (type(evidence.valid_until_wall) not in (int, float)
            or not math.isfinite(evidence.valid_until_wall)
            or evidence.valid_until_wall <= time.time()):
        raise UnsupportedInferencePolicy("subscription evidence expired or has no validity bound")
    if (not isinstance(evidence.policy_paths, tuple) or not evidence.policy_paths
            or len(evidence.policy_paths) > 32):
        raise UnsupportedInferencePolicy("bounded complete policy provenance paths required")


class VerifiedCliRuntime:
    def __init__(self, *, contract, cwd, env, evidence, policy_stamps):
        self._contract, self._cwd = contract, cwd
        self._env = dict(env)
        self._evidence, self._policy_stamps = evidence, tuple(policy_stamps)
        self._lock = threading.RLock()
        self._stopping = False
        self._calls = {}
        self._processes = {}

    def _check(self):
        if self._stopping:
            raise UnsupportedInferencePolicy("CLI text runtime is retiring")
        _validate_evidence(self._evidence)
        if tuple(_policy_stamp(p) for p in self._evidence.policy_paths) != self._policy_stamps:
            raise UnsupportedInferencePolicy("CLI auth/policy provenance changed; explicit review required")

    def stream(self, *, prompt, system_prompt, model, effort, conversation_id="",
               cancel_token=None, deadline_s=60.0, idle_s=30.0):
        """Wrap one existing transport; requests never probe or reverify the CLI."""
        token = cancel_token if cancel_token is not None else CancelToken()
        if token.is_set():
            return
        receipt = object()
        with self._lock:
            self._check()
            if len(self._calls) >= 32:
                raise UnsupportedInferencePolicy("CLI transport registry capacity reached")
            self._calls[receipt] = token

        def spawned(proc):
            with self._lock:
                self._processes[proc.pid] = (receipt, proc)
                if self._stopping:
                    token.cancel("cli_runtime_retired")

        def exited(proc):
            with self._lock:
                if self._processes.get(proc.pid) == (receipt, proc):
                    self._processes.pop(proc.pid, None)

        stream = None
        try:
            request = transport.TextRequest(
                prompt=prompt, system_prompt=system_prompt, model=model, effort=effort,
                cwd=self._cwd, env=dict(self._env), subscription_auth_verified=True,
                conversation_id=str(conversation_id or ""), deadline_s=deadline_s, idle_s=idle_s)
            stream = transport.stream_text(request, self._contract, cancel_token=token,
                                           on_spawn=spawned, on_exit=exited)
            for event in stream:
                if token.is_set():
                    return
                yield event
        finally:
            try:
                if stream is not None:
                    stream.close()
            finally:
                with self._lock:
                    self._calls.pop(receipt, None)

    def stop(self):
        """Stop admission and cancel owned calls; consumers retain cleanup ownership."""
        with self._lock:
            self._stopping = True
            tokens = list(self._calls.values())
        for token in tokens:
            token.cancel("cli_runtime_retired")
        return self.retired

    @property
    def retired(self):
        with self._lock:
            return self._stopping and not self._calls and not self._processes

    def stats(self):
        with self._lock:
            return {"stopping": self._stopping, "active_calls": len(self._calls),
                    "active_processes": len(self._processes), "retired": self.retired}


_installed = None
_install_lock = threading.RLock()


def install(*, executable, cwd, env, evidence):
    """Explicit lifecycle only: bounded --help/--version, never auth/model probes.

    Evidence attests the exact supplied environment/cwd and complete effective
    settings. collect_auth_status provides diagnostics, never positive evidence.
    Failure leaves the previous owner retained, or the lane unavailable.
    """
    global _installed
    _validate_evidence(evidence)
    if not Path(cwd).is_absolute() or not Path(cwd).is_dir():
        raise UnsupportedInferencePolicy("explicit CLI working directory required")
    frozen_env = _reviewed_env(env)
    with _install_lock:
        if _installed is not None and not _installed.retired:
            raise UnsupportedInferencePolicy("retire previous CLI text runtime before installation")
        stamps = tuple(_policy_stamp(p) for p in evidence.policy_paths)
        contract = transport.verify_cli(executable, env=frozen_env, cwd=cwd)
        if tuple(_policy_stamp(p) for p in evidence.policy_paths) != stamps:
            raise UnsupportedInferencePolicy("CLI auth/policy provenance changed during verification")
        _validate_evidence(evidence)
        candidate = VerifiedCliRuntime(contract=contract, cwd=str(cwd), env=frozen_env,
                                       evidence=evidence, policy_stamps=stamps)
        _installed = candidate
        return candidate


def get_runtime():
    return _installed


def require_runtime():
    runtime = _installed
    if runtime is None:
        raise UnsupportedInferencePolicy("no verified subscription CLI text runtime installed")
    return runtime


def uninstall():
    global _installed
    with _install_lock:
        if _installed is not None and not _installed.stop():
            return False
        _installed = None
        return True
