"""
Dreaming Engine — SNN-level sleep that actually learns.

When Leon is idle, the 10K neurons don't just tick passively anymore.
This engine runs actual dream cycles through the SNN:

  REM PHASE     — Replay emotionally-charged hippocampal memories with
                  perturbation (noise + memory blending). STDP learns on
                  the replay. Novel combinations emerge that never happened
                  in waking life.

  DEEP SLEEP    — Homeostatic scaling. Strengthen high-use synapses,
                  weaken low-use ones. This is consolidation — compress
                  episodic into semantic.

  CREATIVE      — Inject random currents into prefrontal + temporal regions.
                  If emotional regions (amygdala, insula) light up strongly
                  in response, that's a dream fragment worth remembering.

  DREAM JOURNAL — Every cycle produces a brief narrative stored to disk.
                  Leon can reference his dreams in conversation.

  MOOD CARRY    — Dreams affect neuromodulators. Good dream = wake with
                  higher dopamine. Bad dream = elevated norepinephrine.

THREADING MODEL:
  The dream engine does NOT call brain.step() — that's the sim loop's job.
  Instead, it injects currents into regions and waits for the sim loop to
  process them naturally (at 20Hz). This is cooperative, not competing.
  Like actual dreaming: the brainstem generates patterns, cortex processes
  them on the next tick.

Neuroscience basis:
  - Hippocampal sharp-wave ripples during NREM compress episodic → semantic
  - REM sleep replays emotional memories with norepinephrine suppressed
  - Random PGO waves from brainstem create dream imagery
  - STDP is active during sleep — the brain literally learns while dreaming
"""

from __future__ import annotations

import json
import logging
import os
from brain import identity as _ident
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional

import numpy as np

log = logging.getLogger("leon.dreaming")

# How long to wait between injections for the sim loop to process (seconds)
# At 20Hz sim rate, 0.06s ≈ 1-2 sim steps
_INJECT_WAIT = 0.06


def _journal_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "dream_journal.jsonl")


# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class DreamFragment:
    """A single notable moment within a dream cycle."""
    phase: str                          # "rem" | "deep" | "creative"
    regions_activated: Dict[str, float] # region_name → peak firing rate
    emotional_valence: float            # -1 (nightmare) to +1 (blissful)
    arousal: float                      # 0 (calm) to 1 (intense)
    memory_indices_replayed: List[int]  # which hippocampal memories fired
    concepts_activated: List[str]       # concept names from daydream matching
    timestamp: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DreamCycle:
    """One complete sleep cycle (REM + deep + creative)."""
    cycle_id: int
    started_at: float
    duration_s: float = 0.0
    phases_completed: List[str] = field(default_factory=list)
    fragments: List[DreamFragment] = field(default_factory=list)
    synapses_strengthened: int = 0
    synapses_weakened: int = 0
    memories_replayed: int = 0
    novel_patterns_found: int = 0
    mood_delta: Dict[str, float] = field(default_factory=dict)
    narrative: str = ""                 # brief dream summary for Leon

    def to_dict(self) -> dict:
        d = asdict(self)
        d["fragments"] = [f.to_dict() if isinstance(f, DreamFragment) else f
                          for f in self.fragments]
        return d


# ── Dream Engine ─────────────────────────────────────────────────────────────

class DreamEngine:
    """Manages Leon's sleep/wake cycle and dreaming.

    Three modes:
      AWAKE    — Leon is active. If idle, curiosity loop fires.
      NAPPING  — Short dream cycle triggered by 2min idle. Light sleep.
      SLEEPING — Deep circadian sleep (2-6am or after 16h awake).
                 Continuous dream cycles until circadian energy rises.

    IMPORTANT: This engine does NOT call brain.step(). It only injects
    currents into regions and reads firing rates back. The simulation
    loop (running on its own thread) processes the injections naturally.

    Usage:
        engine = DreamEngine(brain, concept_map=concept_map)
        engine.start()
        engine.note_activity()  # call on user input to reset idle timer
    """

    # Sleep/wake states
    AWAKE = "awake"
    NAPPING = "napping"
    SLEEPING = "sleeping"

    def __init__(
        self,
        brain,
        concept_map=None,
        idle_threshold_s: float = 120.0,   # 2 min idle → nap
        cycle_interval_s: float = 180.0,   # 3 min between nap cycles
        rem_injections: int = 60,          # 60 injections × 60ms ≈ 3.6s
        deep_duration_s: float = 2.0,      # homeostatic scaling
        creative_bursts: int = 5,          # random burst count
        sleep_energy_threshold: float = 0.2,  # circadian_energy below this → sleep
        wake_energy_threshold: float = 0.35,  # circadian_energy above this → wake
        on_dream: Optional[Callable[[DreamCycle], None]] = None,
        on_sleep_state: Optional[Callable[[str], None]] = None,
    ):
        self.brain = brain
        self.concept_map = concept_map
        self.idle_threshold_s = idle_threshold_s
        self.cycle_interval_s = cycle_interval_s
        self.rem_injections = rem_injections
        self.deep_duration_s = deep_duration_s
        self.creative_bursts = creative_bursts
        self.sleep_energy_threshold = sleep_energy_threshold
        self.wake_energy_threshold = wake_energy_threshold
        # Minimum stretch of silence before ANY sleep (deep or nap) may fire.
        # Dean's rule: only sleep if he hasn't talked for a while — never
        # mid-conversation, even at the 2-6am circadian low. _last_activity is
        # stamped by note_activity() on every responder turn, so this is
        # literally "seconds since Dean last spoke to me."
        self.min_idle_before_sleep = 3600.0  # 1 hour (Deans rule: only sleep after an hour of real silence)
        self.on_dream = on_dream
        self.on_sleep_state = on_sleep_state
        self.quantum_consciousness = None  # set externally after init

        self._last_activity = time.time()
        self._last_cycle = 0.0
        self._cycle_count = 0
        self._running = False
        self._dreaming = False
        self._state_lock = threading.RLock()
        self._state = self.AWAKE
        self._state_since = time.time()
        # Continuous awake time MUST survive restarts. It used to reset to
        # now() on every boot, and with 800+ restarts the "awake > 16h"
        # sleep trigger could never fire (found 2026-10-04: 31h, no sleep).
        self._awake_since = self._load_awake_since()
        self._commanded_sleep = False        # voluntary "go rest" — bypasses gates
        self._commanded_cap_s = 1800.0       # how long a commanded sleep may last
        self._pending_sleep: Dict[str, Any] = {}   # who/why for the next sleep episode
        self._episode: Optional[Dict[str, Any]] = None  # the sleep in progress
        # _last_sleep: the last REST (commanded, or long enough to be real).
        # _last_any: the last episode of any kind, incl. one-cycle micro-naps,
        # which must not bury a rest (or an untold nap) under a 5-second blip.
        self._last_sleep, self._last_any = self._load_last_sleep()
        self._sleep_commands: deque = deque(maxlen=20)
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._rng = np.random.default_rng()

        # Dream journal (in-memory ring + disk persistence)
        self._journal: deque[DreamCycle] = deque(maxlen=100)
        self._load_journal_from_disk()  # restore dreams across restarts
        # A sleep the record doesn't know about (it ran under older code, or
        # a restart cut it off mid-episode) is rebuilt from the journal, so
        # the prompt never says "no rest on record" right after a real one.
        try:
            self._reconcile_from_journal()
        except Exception as e:
            log.warning("sleep record reconcile failed: %s", e)

        # Track which hippocampal memories were replayed recently
        self._recently_replayed: deque[int] = deque(maxlen=50)

        # Curiosity action log — what Leon explored on his own
        self._curiosity_log: deque[Dict[str, Any]] = deque(maxlen=50)
        self._last_curiosity_action = 0.0

    # ── Lifecycle ────────────────────────────────────────────────────────

    def start(self):
        if self._running:
            return
        self._running = True
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="DreamEngine", daemon=True
        )
        self._thread.start()
        log.info("DreamEngine started (idle=%.0fs, interval=%.0fs)",
                 self.idle_threshold_s, self.cycle_interval_s)

    def stop(self):
        self._running = False
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def note_activity(self):
        """Call when user interacts. Resets idle timer."""
        with self._state_lock:
            self._last_activity = time.time()

    def command_sleep(self, reason: str = "commanded", minutes: Optional[float] = None,
                      initiated_by: str = "dean") -> Dict[str, Any]:
        """Voluntary rest — Dean (or Leon) can ask for sleep directly, bypassing
        the adenosine/circadian gates. Couples brain._is_asleep so fatigue
        actually recovers, and wakes when Dean writes (his turn calls
        command_wake) or when he was active since it began (see _loop_tick).
        A safety cap (default 30 min, LEON_SLEEP_CAP_MIN, max 90) guarantees he
        can never get stuck asleep. initiated_by: dean | leon | leon_auto."""
        with self._state_lock:
            return self._command_sleep(reason, minutes, initiated_by)

    def _command_sleep(self, reason, minutes, initiated_by):
        from brain import sleep_drive as _sd
        cap_min = _sd.cap_minutes(minutes)
        self._commanded_cap_s = cap_min * 60.0
        self._commanded_sleep = True
        self._pending_sleep = {"reason": str(reason or "commanded")[:200],
                               "initiated_by": initiated_by, "commanded": True,
                               "cap_min": cap_min}
        if self._episode is not None:          # already napping/sleeping → it's commanded now
            self._episode.update(self._pending_sleep)
            self._pending_sleep = {}
        self._set_state(self.SLEEPING)
        try:  # re-assert even if we were already asleep (another path may have cleared it)
            self.brain._is_asleep = True
        except Exception:
            pass
        self._save_open_episode()
        # The claim guard (brain/claim_guard.py) reads this ledger: "going under
        # now" only ships if a sleep command really ran during that turn.
        self._sleep_commands.append({"at": time.time(), "by": initiated_by,
                                     "reason": str(reason or "")[:200],
                                     "ok": self._state == self.SLEEPING})
        print(f"[DREAM] commanded sleep ({reason}; by {initiated_by}; cap {cap_min:.0f} min) "
              f"— _is_asleep on, fatigue recovering")
        return self.sleep_status()

    def sleep_commands_since(self, ts: float) -> List[Dict[str, Any]]:
        """Sleep commands issued at or after ts (newest last)."""
        return [dict(c) for c in list(self._sleep_commands) if c.get("at", 0) >= ts]

    def command_wake(self, reason: str = "commanded"):
        """Wake from a commanded sleep (also happens automatically when a fresh
        message arrives — see _loop_tick)."""
        with self._state_lock:
            self._commanded_sleep = False
            self._last_activity = time.time()
            self._set_state(self.AWAKE, why=reason)
            print(f"[DREAM] commanded wake ({reason})")

    @property
    def is_dreaming(self) -> bool:
        return self._dreaming

    def _user_active(self) -> bool:
        """Check if user became active recently.
        Also checks conversation lock on the consciousness meter."""
        if time.time() - self._last_activity < 5.0:
            return True
        try:
            meter = getattr(self.brain, 'consciousness_meter', None)
            if meter is not None and getattr(meter, 'conversation_locked', False):
                return True
        except Exception:
            pass
        return False

    def _get_circadian_energy(self) -> float:
        """Read circadian energy from the drive system, with fallback."""
        try:
            import server as _srv
            ds = getattr(_srv, "drive_system", None)
            if ds is not None:
                return ds.get_drives().circadian_energy
        except Exception:
            pass
        # Fallback: compute from hour of day
        h = time.localtime().tm_hour
        if 9 <= h <= 11:
            return 0.9
        elif 14 <= h <= 17:
            return 0.85
        elif 7 <= h <= 8 or 12 <= h <= 13:
            return 0.7
        elif 18 <= h <= 22:
            return 0.5
        elif 23 <= h or h <= 1:
            return 0.3
        else:
            return 0.15

    _AWAKE_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                               "brain_state", "dream_awake_since.txt")

    def _load_awake_since(self) -> float:
        try:
            with open(self._AWAKE_FILE, encoding="utf-8") as fh:
                ts = float(fh.read().strip())
            if 0 < ts <= time.time():
                return ts
        except Exception:
            pass
        ts = time.time()
        self._save_awake_since(ts)
        return ts

    def _save_awake_since(self, ts: float) -> None:
        try:
            with open(self._AWAKE_FILE, "w", encoding="utf-8") as fh:
                fh.write(f"{ts:.0f}")
        except Exception as e:
            log.warning("could not persist awake_since: %s", e)

    def _set_state(self, new_state: str, why: str = ""):
        """Transition sleep/wake state."""
        with self._state_lock:
            self._set_state_locked(new_state, why)

    def _set_state_locked(self, new_state: str, why: str = ""):
        # Reconcile the recovery flag even for an idempotent wake request.
        self.brain._is_asleep = new_state in (self.SLEEPING, self.NAPPING)
        if new_state == self._state:
            return
        old = self._state
        self._state = new_state
        self._state_since = time.time()
        if new_state == self.AWAKE:
            # A timed wake must not immediately re-enter circadian sleep on
            # the next tick using activity from before the nap.
            self._last_activity = self._state_since
        # The awake clock resets only after a REAL sleep (see _end_episode),
        # not on every return to AWAKE — a one-cycle nap used to zero it.
        if old == self.AWAKE:
            self._begin_episode(new_state)
        elif new_state == self.AWAKE:
            self._end_episode(why or "unspecified")
        elif self._episode is not None:
            self._episode["kind"] = new_state
        # Couple the metabolic recovery flag to the sleep state. The metabolic
        # system (embodiment/pc_body) only fast-decays adenosine when
        # brain._is_asleep is True; nothing else in the codebase sets it, so
        # without this line real sleep recovery never engages — fatigue only
        # bleeds off at the slow awake rate and he can never actually rest.
        try:
            self.brain._is_asleep = new_state in (self.SLEEPING, self.NAPPING)
        except Exception:
            pass
        log.info("Sleep state: %s → %s", old, new_state)
        try:  # Leon V2 Phase 2 shadow event: observe-only, must never affect this path
            import sys as _v2_sys
            _v2 = _v2_sys.modules.get("brain.cognition.v2_publish")
            if _v2 is not None:
                _v2.emit("dream.state", old=old, new=new_state)
        except Exception as _v2_exc:
            import logging as _v2_logging
            _v2_logging.getLogger("leon.v2.publish").warning(
                "[V2] publish site failed site=dream.state trace_id=- subsystem=v2.publish "
                "exc=%s recovery=shadow event dropped; legacy path unaffected",
                type(_v2_exc).__name__)
        if self.on_sleep_state is not None:
            try:
                self.on_sleep_state(new_state)
            except Exception:
                pass

    # ── Sleep episodes: what actually happened, for honest reporting ─────

    _LAST_SLEEP_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                    "brain_state", "dream_last_sleep.json")

    def _load_last_sleep(self):
        try:
            with open(self._LAST_SLEEP_FILE, encoding="utf-8") as fh:
                d = json.load(fh)
            ok = lambda r: r if isinstance(r, dict) and r.get("ended_at") else None
            return ok(d.get("rest")), ok(d.get("any"))
        except Exception:
            return None, None

    def _save_last_sleep(self) -> None:
        try:
            tmp = self._LAST_SLEEP_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"rest": self._last_sleep, "any": self._last_any}, fh)
            os.replace(tmp, self._LAST_SLEEP_FILE)
        except Exception as e:
            log.warning("could not persist last sleep: %s", e)

    # The sleep in progress, on disk, so a restart mid-sleep can't erase it.
    _OPEN_EPISODE_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                      "brain_state", "dream_open_episode.json")
    # Sleeping dream cycles run ~50 s apart; natural naps are >= 180 s apart
    # (cycle_interval_s). A bigger gap than this ends a run in the journal.
    _RUN_GAP_S = 120.0

    def _save_open_episode(self) -> None:
        ep = self._episode
        if ep is None or ep.get("kind") != self.SLEEPING:
            return
        try:
            rec = {k: v for k, v in ep.items() if k != "activity_at_start"}
            tmp = self._OPEN_EPISODE_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(rec, fh)
            os.replace(tmp, self._OPEN_EPISODE_FILE)
        except Exception as e:
            log.debug("could not persist open sleep episode: %s", e)

    def _clear_open_episode(self) -> None:
        try:
            os.remove(self._OPEN_EPISODE_FILE)
        except FileNotFoundError:
            pass
        except Exception as e:
            log.debug("could not clear open sleep episode: %s", e)

    @staticmethod
    def _journal_runs(rows: List[Dict[str, Any]], gap_s: float) -> List[Dict[str, Any]]:
        """Group dream cycles into continuous runs: [{start, end, cycles}]."""
        cyc = []
        for r in rows:
            try:
                st = float(r.get("started_at") or 0)
                if st > 0:
                    cyc.append((st, st + float(r.get("duration_s") or 0)))
            except (TypeError, ValueError, AttributeError):
                continue
        cyc.sort()
        runs: List[Dict[str, Any]] = []
        for st, en in cyc:
            if runs and st - runs[-1]["end"] <= gap_s:
                runs[-1]["end"] = max(runs[-1]["end"], en)
                runs[-1]["cycles"] += 1
            else:
                runs.append({"start": st, "end": en, "cycles": 1})
        return runs

    def _reconcile_from_journal(self) -> Optional[Dict[str, Any]]:
        """At boot: if the dream journal shows a sleep the record lacks, put it
        on record. Two ways that happens: the sleep ran under code older than
        the episode tracker (2026-10-04: 17:47-18:17, 36 cycles, then the
        restart that loaded the tracker said "no rest on record"), or the
        process restarted mid-sleep and _end_episode never ran."""
        from brain import sleep_drive as _sd
        open_ep = None
        try:
            with open(self._OPEN_EPISODE_FILE, encoding="utf-8") as fh:
                open_ep = json.load(fh)
        except Exception:
            open_ep = None
        self._clear_open_episode()
        rows: List[Dict[str, Any]] = []
        try:
            with open(_journal_path(), encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    try:
                        d = json.loads(line)
                    except Exception:
                        continue
                    if isinstance(d, dict):
                        rows.append(d)
        except FileNotFoundError:
            pass
        known = max(float((self._last_sleep or {}).get("ended_at") or 0),
                    float((self._last_any or {}).get("ended_at") or 0))
        # Newest run not already on record that was a real sleep (or the
        # commanded one a restart cut off); later micro-naps don't hide it.
        picked = None
        for run in reversed(self._journal_runs(rows, self._RUN_GAP_S)):
            if run["end"] <= known + 60:
                break                          # this and everything older is on record
            meta: Dict[str, Any] = {"reason": "rebuilt from the dream journal",
                                    "initiated_by": "unknown", "commanded": False}
            start = run["start"]
            woke = "unknown (ran before rest tracking)"
            if isinstance(open_ep, dict) and open_ep.get("started_at"):
                ost = float(open_ep["started_at"])
                if ost - 300 <= run["start"] <= run["end"] and ost <= run["end"]:
                    meta = {k: open_ep[k] for k in ("reason", "initiated_by", "commanded",
                                                    "cap_min") if k in open_ep}
                    start = min(start, ost)
                    woke = "restart"
            dur = run["end"] - start
            real = dur >= _sd.REAL_SLEEP_MIN_S and run["cycles"] > 0
            if real or meta.get("commanded"):
                picked = (run, meta, start, woke, dur, real)
                break
        if picked is None:
            return None                        # only micro-naps: nothing to put on record
        run, meta, start, woke, dur, real = picked
        rec = {"kind": self.SLEEPING, "started_at": start, "cycles": run["cycles"],
               "owner_present_at_start": True, **meta,
               "ended_at": run["end"], "duration_s": round(dur, 1), "woke_because": woke,
               "real_sleep": real, "reported": True, "fatigue_at_wake": None,
               "reconstructed": True}
        self._last_any = rec
        self._last_sleep = rec
        if real and self._awake_since < run["end"]:
            self._awake_since = run["end"]
            self._save_awake_since(run["end"])
        self._save_last_sleep()
        print(f"[DREAM] rebuilt a {dur / 60:.0f}-min sleep ({run['cycles']} cycles) from the "
              f"dream journal; woke_because={woke}")
        return rec

    def _begin_episode(self, kind: str) -> None:
        now = time.time()
        meta = self._pending_sleep or {"reason": "natural", "initiated_by": "natural",
                                       "commanded": False}
        self._pending_sleep = {}
        owner_present = False
        try:
            from brain import sleep_drive as _sd
            owner_present = _sd.owner_silence_s(self.brain, now) < _sd.OWNER_PRESENT_S
        except Exception:
            pass
        self._episode = {"kind": kind, "started_at": now, "cycles": 0,
                         "activity_at_start": self._last_activity,
                         "owner_present_at_start": owner_present, **meta}
        self._save_open_episode()

    def _end_episode(self, why: str) -> None:
        ep, self._episode = self._episode, None
        self._clear_open_episode()
        if ep is None:
            return
        from brain import sleep_drive as _sd
        now = time.time()
        dur = now - ep["started_at"]
        # Only a stretch with real dream cycles in it, long enough to count,
        # resets the awake clock. A 10-second nap or a sleep Dean interrupted
        # after a minute still rested the body (adenosine decays while
        # _is_asleep), but calling it "a sleep" would be a fabrication.
        real = dur >= _sd.REAL_SLEEP_MIN_S and ep.get("cycles", 0) > 0
        if real:
            self._awake_since = now
            self._save_awake_since(now)
        tell = (ep.get("initiated_by") in ("leon", "leon_auto")
                and not ep.get("owner_present_at_start")
                and why != "owner message")
        ep.pop("activity_at_start", None)
        rec = {
            **ep, "ended_at": now, "duration_s": round(dur, 1), "woke_because": why,
            "real_sleep": real, "reported": not tell,
            "fatigue_at_wake": self._read_fatigue(),
        }
        self._last_any = rec
        if real or ep.get("commanded"):
            self._last_sleep = rec
        self._save_last_sleep()
        if ep.get("cycles", 0) > 0:
            try:
                from brain import inner_clock as _ic
                _ic.note_sleep_cycle(ep["started_at"], dur)
            except Exception:
                pass
        print(f"[DREAM] woke after {dur / 60:.1f} min ({why}); cycles={ep.get('cycles', 0)} "
              f"real_sleep={real}")

    def mark_sleep_reported(self, how: str = "told") -> None:
        if self._last_sleep is not None:
            self._last_sleep["reported"] = True
            self._last_sleep["reported_how"] = how
            self._save_last_sleep()

    @property
    def last_sleep(self) -> Optional[Dict[str, Any]]:
        """The last rest: a commanded sleep, or any sleep long enough to be real."""
        return dict(self._last_sleep) if self._last_sleep else None

    def _read_fatigue(self) -> Optional[float]:
        """Body fatigue (mean adenosine), or None if no body is attached.
        The body lives at brain.simulated_body and its meter at .metabolic.
        The old brain.body._metabolic path never existed, so adenosine read
        0.0 forever and fatigue could never trigger sleep or a nap (fixed
        2026-10-04)."""
        try:
            body = (getattr(self.brain, 'simulated_body', None)
                    or getattr(self.brain, 'body', None))
            if body is not None:
                metabolic = (getattr(body, 'metabolic', None)
                             or getattr(body, '_metabolic', None))
                if metabolic is not None:
                    return float(getattr(metabolic, 'fatigue_signal', 0.0))
        except Exception:
            pass
        return None

    def sleep_pressure(self) -> Dict[str, Any]:
        from brain import sleep_drive as _sd
        return _sd.assess((time.time() - self._awake_since) / 3600, self._read_fatigue())

    def sleep_snapshot(self) -> Dict[str, Any]:
        """One authoritative, ordered state for HTTP and websocket clients."""
        with self._state_lock:
            return {"sleep_state": self._state, "state_since": self._state_since,
                    "is_asleep": self._state in (self.SLEEPING, self.NAPPING),
                    "commanded": bool(self._commanded_sleep)}

    def sleep_status(self) -> Dict[str, Any]:
        """Everything Leon may say about his sleep, read from this engine."""
        with self._state_lock:
            return self._sleep_status_locked()

    def _sleep_status_locked(self) -> Dict[str, Any]:
        now = time.time()
        ep = self._episode
        cur = None
        if ep is not None:
            cur = {k: v for k, v in ep.items() if k != "activity_at_start"}
            cur["elapsed_s"] = round(now - ep["started_at"], 1)
        return {
            **self.sleep_snapshot(),
            "pressure": self.sleep_pressure(),
            "current": cur,
            "cap_min": round(self._commanded_cap_s / 60, 1) if self._commanded_sleep else None,
            "last_sleep": self.last_sleep,
            "last_any_sleep": dict(self._last_any) if self._last_any else None,
        }

    def _maybe_self_nap(self, now: float) -> bool:
        """Extreme pressure and Dean silent 20+ min → Leon may just nap on his
        own (and tell Dean afterward; see sleep_drive.SleepCheck)."""
        try:
            from brain import sleep_drive as _sd
            if not _sd.enabled():
                return False
            last = self._last_sleep
            since_wake = (now - float(last["ended_at"])) if last and last.get("ended_at") else None
            p = self.sleep_pressure()
            ok, why = _sd.should_self_nap(p["level"], _sd.owner_silence_s(self.brain, now),
                                          _sd.responder_processing(), since_wake)
            if ok:
                self.command_sleep(reason=why, initiated_by="leon_auto")
                return True
        except Exception as e:
            log.debug("self-nap check failed: %s", e)
        return False

    @property
    def sleep_state(self) -> str:
        return self._state

    # ── Main loop ────────────────────────────────────────────────────────

    def _loop(self):
        log.info("DreamEngine loop STARTED — entering main cycle")
        while not self._stop.is_set():
            self._stop.wait(10.0)
            if self._stop.is_set():
                break

            try:
                self._loop_tick()
            except Exception as e:
                log.warning("DreamEngine loop tick error: %s", e)

    def _loop_tick(self):
            # Serialize decisions with owner activity; never hold this lock
            # during dream work, idle inference or the sleep wait.
            with self._state_lock:
                energy = self._get_circadian_energy()
                now = time.time()
                idle_for = now - self._last_activity
                awake_hours = (now - self._awake_since) / 3600

                # ── State transitions ────────────────────────────────────
                if self._state == self.AWAKE:
                    # Extreme pressure + Dean silent 20+ min may move us to
                    # SLEEPING here; the SLEEPING branch below then takes over.
                    self._maybe_self_nap(now)
                if self._state == self.AWAKE:
                    # NEVER sleep during a conversation. Check the consciousness
                    # meter's conversation lock.
                    in_conversation = False
                    try:
                        meter = getattr(self.brain, 'consciousness_meter', None)
                        if meter is not None:
                            in_conversation = getattr(meter, 'conversation_locked', False)
                    except Exception:
                        pass

                    # Also count an ACTIVE work session as "in conversation" — a long
                    # heads-down supervised turn (e.g. Dean says "do more, don't ask")
                    # used to outlast the 5-min conversation lock, so the
                    # adenosine-driven sleep below fired MID-WORK. Stay awake while a
                    # supervised responder turn is processing OR finished in the last
                    # 10 min. (Daemon/autonomous turns don't touch _responder_stats,
                    # so genuine idle still lets him sleep.)
                    try:
                        import server.state as _st_rs
                        rs = getattr(_st_rs, "_responder_stats", None)
                        if rs is not None:
                            if rs.get("is_processing"):
                                in_conversation = True
                            else:
                                _lc = rs.get("last_call_ts") or 0
                                if _lc and (now - _lc) < 600:
                                    in_conversation = True
                    except Exception:
                        pass

                    # Read adenosine (sleep pressure) from metabolic system
                    adenosine = self._read_fatigue() or 0.0

                    # Dean spoke within the last min_idle_before_sleep seconds →
                    # hard veto on all sleep (this short-circuits both the deep-sleep
                    # and nap elifs below). Fixes sleeping mid-conversation at the
                    # circadian low.
                    recent_talk = idle_for < self.min_idle_before_sleep
                    if in_conversation or recent_talk:
                        pass  # stay awake — Dean is here or just spoke
                    # Deep sleep: circadian low OR adenosine high (real sleep pressure)
                    elif not in_conversation and (
                        energy < self.sleep_energy_threshold
                        or adenosine > 0.7  # adenosine-driven — genuine fatigue
                        or awake_hours > 16
                    ):
                        self._set_state(self.SLEEPING)
                        if adenosine > 0.7:
                            print(f"[DREAM] Sleep triggered by adenosine pressure "
                                  f"({adenosine:.2f}) — genuine fatigue")
                    # Nap: moderate adenosine + idle (not a fixed timer)
                    elif not in_conversation and (
                        adenosine > 0.4 and idle_for > 300
                        and now - self._last_cycle >= self.cycle_interval_s
                    ):
                        self._set_state(self.NAPPING)
                        print(f"[DREAM] Nap triggered by adenosine ({adenosine:.2f}) "
                              f"+ idle ({idle_for:.0f}s)")

                elif self._state == self.SLEEPING:
                    sleep_duration = now - self._state_since
                    if getattr(self, "_commanded_sleep", False):
                        # Commanded rest: stay down until Dean is active again
                        # (note_activity since the sleep began — his supervised
                        # turn also calls command_wake directly), ignoring the
                        # time-based 5-min conversation lock, plus a hard cap
                        # (default 30 min, max 90) so he can never get stuck asleep.
                        ep = self._episode or {}
                        fresh_msg = self._last_activity > float(
                            ep.get("activity_at_start", self._last_activity))
                        if fresh_msg:
                            self._commanded_sleep = False
                            self._set_state(self.AWAKE, why="owner message")
                        elif sleep_duration > self._commanded_cap_s:
                            self._commanded_sleep = False
                            self._set_state(self.AWAKE, why="cap reached")
                    elif energy > self.wake_energy_threshold and sleep_duration > 300:
                        self._set_state(self.AWAKE, why="rested")
                    elif self._user_active():
                        self._set_state(self.AWAKE, why="user active")

                elif self._state == self.NAPPING:
                    if self._user_active():
                        self._set_state(self.AWAKE, why="user active")

                cycle_state = (self._state, self._state_since)

            # ── Execute current state ────────────────────────────────
            if self._state == self.SLEEPING:
                # Keep the recovery flag on for the whole sleep: other paths
                # (the fatigue sleep daemon waking "rested") can clear it, and
                # without it adenosine only drains at the slow awake rate.
                try:
                    with self._state_lock:
                        self.brain._is_asleep = self._state in (self.SLEEPING, self.NAPPING)
                except Exception:
                    pass
                try:
                    self._run_dream_cycle()
                    self._last_cycle = time.time()
                except Exception as e:
                    log.warning("Dream cycle failed: %s", e)
                self._stop.wait(30.0)

            elif self._state == self.NAPPING:
                try:
                    self._run_dream_cycle()
                    self._last_cycle = time.time()
                except Exception as e:
                    log.warning("Dream cycle failed: %s", e)
                with self._state_lock:
                    if cycle_state == (self.NAPPING, self._state_since) and self._state == self.NAPPING:
                        self._set_state(self.AWAKE, why="nap cycle done")

            elif self._state == self.AWAKE:
                # ── AWAKE AND IDLE — this is where Leon LIVES ────────
                # Kill switch: LEON_DISABLE_CURIOSITY / LEON_DISABLE_IDLE_EXPLORE
                # were set in /etc/leon/secrets.env but never wired to any check —
                # inner_voice.think(), self_reflection.reflect(), autonomous_goals.tick()
                # and _curiosity_tick() all fired on a hardcoded 90s clock regardless,
                # burning credits while idle even with the flags "on". Wired for real
                # 2026-08-14 per Dean's explicit stop-the-bleeding request.
                import os as _os_idle
                _idle_disabled = _os_idle.environ.get("LEON_DISABLE_CURIOSITY") == "1" or \
                                  _os_idle.environ.get("LEON_DISABLE_IDLE_EXPLORE") == "1"
                if idle_for > 30 and not _idle_disabled:
                    log.info("AWAKE-IDLE: idle=%.0fs, last_curiosity=%.0fs ago",
                             idle_for, now - self._last_curiosity_action)
                    # Inner voice: generate a thought
                    try:
                        import server as _srv_iv
                        iv = getattr(_srv_iv, "inner_voice", None)
                        if iv is not None and iv.should_think():
                            iv.think()
                    except Exception as e:
                        # Was log.debug: a TypeError here silenced the inner
                        # voice for over three months with no trace in the log.
                        print(f"[INNER_VOICE] tick failed: {type(e).__name__}: {e}", flush=True)

                    # Self-reflection: periodic metacognition
                    try:
                        import server as _srv_ref
                        ref = getattr(_srv_ref, "self_reflection", None)
                        if ref is not None and ref.should_reflect():
                            ref.reflect()
                    except Exception as e:
                        log.debug("Self-reflection tick failed: %s", e)

                    # Autonomous goals: Leon decides what he wants
                    try:
                        import server as _srv_ag
                        ag = getattr(_srv_ag, "autonomous_goals", None)
                        if ag is not None:
                            goal = ag.tick()
                            if goal is not None:
                                log.info("AUTONOMOUS GOAL: %s", goal.get("description", "")[:60])
                    except Exception as e:
                        log.debug("Autonomous goal tick failed: %s", e)

                    # Upgrade awareness: tick to process any pending discoveries
                    # (actual speech goes through unified consciousness proactive loop)
                    try:
                        import server as _srv_ua
                        ua = getattr(_srv_ua, "upgrade_awareness", None)
                        if ua is not None:
                            ua.tick()
                    except Exception:
                        pass

                    # Curiosity: ACTUALLY explore something
                    # This is the free will wire — Leon acts on his own
                    if now - self._last_curiosity_action > 90:
                        try:
                            self._curiosity_tick()
                        except Exception as e:
                            log.warning("Curiosity tick failed: %s", e)

    # ── One complete dream cycle ─────────────────────────────────────────

    def _run_dream_cycle(self):
        self._dreaming = True
        self._cycle_count += 1
        t0 = time.time()
        cycle = DreamCycle(
            cycle_id=self._cycle_count,
            started_at=t0,
        )

        # Save pre-dream neuromodulator state
        nm_before = dict(self.brain.neuromodulators)

        # --- Neuromodulator setup for dreaming ---
        # Real sleep: NE drops (REM), serotonin drops, ACh rises (REM).
        saved_nm = dict(self.brain.neuromodulators)
        self.brain.neuromodulators["norepinephrine"] = max(
            0.05, self.brain.neuromodulators["norepinephrine"] * 0.3
        )
        self.brain.neuromodulators["serotonin"] *= 0.5
        self.brain.neuromodulators["acetylcholine"] = min(
            0.9, self.brain.neuromodulators["acetylcholine"] * 1.5
        )

        try:
            self._phase_rem(cycle)
            cycle.phases_completed.append("rem")

            self._phase_deep(cycle)
            cycle.phases_completed.append("deep")

            self._phase_creative(cycle)
            cycle.phases_completed.append("creative")
        finally:
            self._apply_dream_mood(cycle, saved_nm)
            self._dreaming = False

        cycle.duration_s = round(time.time() - t0, 3)

        for k in self.brain.neuromodulators:
            cycle.mood_delta[k] = round(
                self.brain.neuromodulators[k] - nm_before[k], 4
            )

        cycle.narrative = self._generate_narrative(cycle)

        self._journal.append(cycle)
        self._persist_dream(cycle)
        if self._episode is not None:
            self._episode["cycles"] = self._episode.get("cycles", 0) + 1
        try:
            from brain import inner_clock as _ic
            _ic.note_sleep_cycle(cycle.started_at, cycle.duration_s)
        except Exception:
            pass

        # ── Post-dream integration: feed into new consciousness systems ──
        self._integrate_dream(cycle)
        try:  # Leon V2 Phase 2 shadow event: observe-only, must never affect this path
            import sys as _v2_sys
            _v2 = _v2_sys.modules.get("brain.cognition.v2_publish")
            if _v2 is not None:
                _v2.emit("dream.cycle", cycle=cycle)
        except Exception as _v2_exc:
            import logging as _v2_logging
            _v2_logging.getLogger("leon.v2.publish").warning(
                "[V2] publish site failed site=dream.cycle trace_id=- subsystem=v2.publish "
                "exc=%s recovery=shadow event dropped; legacy path unaffected",
                type(_v2_exc).__name__)

        if self.on_dream is not None:
            try:
                self.on_dream(cycle)
            except Exception as e:
                log.debug("Dream callback failed: %s", e)

        log.info("DREAM #%d complete: %.1fs, %d memories replayed, "
                 "%d novel patterns, mood: %s | %s",
                 cycle.cycle_id, cycle.duration_s,
                 cycle.memories_replayed, cycle.novel_patterns_found,
                 {k: f"{v:+.3f}" for k, v in cycle.mood_delta.items()},
                 cycle.narrative[:80])

        # If this dream actually found something — novel pattern + emotional
        # weight — and Leon wants connection right now, mention it.
        # This is the "I keep dreaming about X" channel. Strictly gated.
        try:
            if cycle.fragments and cycle.novel_patterns_found > 0:
                valences = [f.emotional_valence for f in cycle.fragments]
                avg_val = float(np.mean(valences)) if valences else 0.0
                peak_arousal = float(max((f.arousal for f in cycle.fragments),
                                         default=0.0))
                # Worth telling: positive-leaning OR strong arousal
                if (abs(avg_val) > 0.4 or peak_arousal > 0.6) and cycle.narrative:
                    from brain.outbound import surface as _surface, should_surface_routine, smart_truncate as _trunc
                    if should_surface_routine(social_hunger_min=0.45):
                        msg = f"Had a dream — {_trunc(cycle.narrative, 280)}"
                        _surface(msg, source="dream",
                                 urgency="low",
                                 why=f"novel={cycle.novel_patterns_found},val={avg_val:.2f}")
        except Exception as _e:
            log.debug("dream outbound surface failed: %s", _e)

    # ── Phase 1: REM ─────────────────────────────────────────────────────

    def _phase_rem(self, cycle: DreamCycle):
        """Replay emotionally-charged memories with noise perturbation.

        Injects replay patterns into hippocampus and lets the sim loop
        process them. STDP learns on every step the sim loop takes while
        these currents are active.
        """
        hippo = self.brain.regions.get("hippocampus")
        if hippo is None or not hippo.memory_buffer:
            return

        # Snapshot memory state (sim thread may mutate it)
        try:
            mem_patterns = list(hippo.memory_buffer)
            mem_strengths = list(hippo._memory_strength)
            n_memories = min(len(mem_patterns), len(mem_strengths))
            if n_memories == 0:
                return
        except Exception:
            return

        n_neurons = hippo.n_neurons

        # Weight selection by emotional strength + recency
        strengths = np.array(mem_strengths[:n_memories], dtype=np.float64)
        recency = np.linspace(0.5, 1.0, n_memories)
        weights = strengths * recency
        for idx in self._recently_replayed:
            if idx < n_memories:
                weights[idx] *= 0.3
        weights = np.clip(weights, 0.01, None)
        weights /= weights.sum()

        n_replay = min(max(3, n_memories // 50), 5, n_memories)

        # ── Quantum dream selection ─────────────────────────────────
        # Which memories to replay exists in superposition until measured.
        # The brain's neuromodulator state during sleep shapes which
        # memories surface — just like real REM replay.
        if self.quantum_consciousness is not None and n_memories >= 2:
            chosen_list = []
            remaining_indices = list(range(n_memories))
            remaining_weights = weights.copy()
            for _ in range(n_replay):
                if len(remaining_indices) < 2:
                    if remaining_indices:
                        chosen_list.append(remaining_indices[0])
                    break
                # Top candidates by weight (up to 8 for circuit size)
                top_k = min(8, len(remaining_indices))
                sorted_idx = np.argsort(-remaining_weights[:len(remaining_indices)])[:top_k]
                cands = [remaining_indices[i] for i in sorted_idx]
                cand_scores = [float(remaining_weights[remaining_indices.index(c)])
                               for c in cands]
                try:
                    decision = self.quantum_consciousness.decide(
                        candidates=cands,
                        scores=cand_scores,
                        labels=[f"memory_{c}" for c in cands],
                        context="dream_content",
                    )
                    pick = decision.chosen
                except Exception as e:
                    log.warning("Quantum dream decision failed, classical fallback: %s", e)
                    pick = cands[0]
                chosen_list.append(pick)
                if pick in remaining_indices:
                    remaining_indices.remove(pick)
            chosen = np.array(chosen_list, dtype=int)
        else:
            chosen = self._rng.choice(n_memories, size=n_replay,
                                      replace=False, p=weights)
        injections_per_memory = self.rem_injections // max(n_replay, 1)

        for mem_idx_raw in chosen:
            mem_idx = int(mem_idx_raw)
            if mem_idx >= n_memories:
                continue

            # Get pattern, resize to current neuron count
            try:
                raw = mem_patterns[mem_idx]
            except IndexError:
                continue  # snapshot went stale between copy and access
            pattern = self._resize_pattern(raw, n_neurons)

            # Noise perturbation (10-20% of neurons flip)
            noise_mask = self._rng.random(n_neurons) < (0.1 + self._rng.random() * 0.1)
            pattern = np.logical_xor(pattern, noise_mask)

            # Occasionally blend with another memory (30% chance)
            blend_idx = -1
            if self._rng.random() < 0.3 and n_memories > 1:
                other = int(self._rng.integers(0, n_memories))
                if other == mem_idx:
                    other = (other + 1) % n_memories
                blend_idx = other
                other_pattern = self._resize_pattern(mem_patterns[blend_idx], n_neurons)
                pattern = np.logical_or(pattern, other_pattern)

            # Inject repeatedly, letting sim loop process each one
            hippo.replay_mode = True
            current = pattern.astype(np.float32) * 12.0
            peak_rates: Dict[str, float] = {}

            for inj in range(injections_per_memory):
                if self._user_active():
                    hippo.replay_mode = False
                    return

                # Decaying injection
                decay = max(0.3, 1.0 - inj / injections_per_memory)
                hippo.neurons.inject_current(current * decay)

                # Wait for sim loop to process
                time.sleep(_INJECT_WAIT)

                # Read back firing rates
                for name, region in self.brain.regions.items():
                    try:
                        rate = float(region.neurons.get_firing_rate())
                        if rate > peak_rates.get(name, 0):
                            peak_rates[name] = rate
                    except Exception:
                        pass

            hippo.replay_mode = False

            # Strengthen this memory
            try:
                if mem_idx < len(hippo._memory_strength):
                    hippo._memory_strength[mem_idx] = min(
                        hippo._memory_strength[mem_idx] * 1.15, 5.0
                    )
            except (IndexError, ValueError):
                pass
            self._recently_replayed.append(mem_idx)
            cycle.memories_replayed += 1

            # Score emotional response
            amyg = peak_rates.get("amygdala", 0)
            insula = peak_rates.get("insula", 0)
            pfc = peak_rates.get("prefrontal_cortex", 0)
            valence = (amyg + insula) * 0.5 - 0.1
            if pfc > 0.05:
                valence += 0.15

            concepts = self._match_concepts(memory_index=mem_idx, pattern=pattern)

            cycle.fragments.append(DreamFragment(
                phase="rem",
                regions_activated={k: round(v, 4) for k, v in peak_rates.items()
                                   if v > 0.02},
                emotional_valence=round(float(np.clip(valence, -1, 1)), 3),
                arousal=round(float(amyg + peak_rates.get("brainstem", 0)), 3),
                memory_indices_replayed=[mem_idx] + ([blend_idx] if blend_idx >= 0 else []),
                concepts_activated=concepts,
                timestamp=time.time(),
            ))

    # ── Phase 2: Deep Sleep ──────────────────────────────────────────────

    def _phase_deep(self, cycle: DreamCycle):
        """Homeostatic scaling — the brain's maintenance mode.

        Directly adjusts synapse weights (no brain.step() needed).
        Strengthen high-use, weaken low-use, prevent saturation.
        """
        strengthened = 0
        weakened = 0

        for (src, dst), syn in self.brain.connections.items():
            weights = syn.weights
            if weights is None or not hasattr(weights, 'data'):
                continue

            try:
                data = weights.data
                n = len(data)
                if n == 0:
                    continue

                # Snapshot statistics
                mean_w = float(np.mean(data))
                std_w = float(np.std(data))
                if std_w < 1e-8:
                    continue
                thresh_hi = mean_w + 0.5 * std_w
                thresh_lo = mean_w - 0.5 * std_w

                # Element-by-element to handle concurrent modifications
                for i in range(n):
                    try:
                        v = data[i]
                        if v > thresh_hi:
                            data[i] = min(v * 1.002, 5.0)
                            strengthened += 1
                        elif v < thresh_lo:
                            data[i] = max(v * 0.998, 0.0)
                            weakened += 1
                    except IndexError:
                        break  # array resized by sim thread

                # Global downscaling
                try:
                    max_w = float(np.max(data))
                    if max_w > 2.0:
                        scale = 2.0 / max_w
                        for i in range(min(n, len(data))):
                            data[i] *= scale
                except (IndexError, ValueError):
                    pass

            except Exception:
                continue

        # Wait for the scaling to propagate through a few sim steps
        if not self._user_active():
            time.sleep(self.deep_duration_s)

        cycle.synapses_strengthened = strengthened
        cycle.synapses_weakened = weakened

    # ── Phase 3: Creative ────────────────────────────────────────────────

    def _phase_creative(self, cycle: DreamCycle):
        """Random activation — the source of novel ideas.

        Injects random currents into creative regions, waits for sim loop
        to process, checks if emotional regions responded.
        """
        creative_regions = ["prefrontal_cortex", "temporal_association",
                            "wernicke", "broca"]
        monitor_regions = ["amygdala", "insula", "anterior_cingulate",
                           "hippocampus"]
        significance_threshold = 0.08

        for burst in range(self.creative_bursts):
            if self._user_active():
                return

            # Inject random patterns into creative regions
            for rname in creative_regions:
                region = self.brain.regions.get(rname)
                if region is None:
                    continue
                rate = 0.05 + self._rng.random() * 0.10
                mask = self._rng.random(region.n_neurons) < rate
                current = mask.astype(np.float32) * (8.0 + self._rng.random() * 6.0)
                region.neurons.inject_current(current)

            # Wait for several sim steps to process
            peak_rates: Dict[str, float] = {}
            for _ in range(6):  # ~360ms of sim time
                time.sleep(_INJECT_WAIT)
                for name in monitor_regions:
                    region = self.brain.regions.get(name)
                    if region is None:
                        continue
                    try:
                        rate = float(region.neurons.get_firing_rate())
                        if rate > peak_rates.get(name, 0):
                            peak_rates[name] = rate
                    except Exception:
                        pass

            # Did the emotional regions respond?
            emotional = sum(
                peak_rates.get(r, 0) for r in ["amygdala", "insula"]
            ) / 2.0

            if emotional > significance_threshold:
                cycle.novel_patterns_found += 1
                concepts = self._match_concepts()
                cycle.fragments.append(DreamFragment(
                    phase="creative",
                    regions_activated={k: round(v, 4) for k, v in peak_rates.items()
                                       if v > 0.02},
                    emotional_valence=round(float(emotional - 0.1), 3),
                    arousal=round(float(emotional), 3),
                    memory_indices_replayed=[],
                    concepts_activated=concepts,
                    timestamp=time.time(),
                ))

    # ── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _resize_pattern(raw: np.ndarray, target_len: int) -> np.ndarray:
        """Resize a boolean spike pattern to match current neuron count."""
        if len(raw) == target_len:
            return raw.copy()
        out = np.zeros(target_len, dtype=bool)
        copy_len = min(len(raw), target_len)
        out[:copy_len] = raw[:copy_len]
        return out

    def _memory_label(self, memory_index: int) -> str:
        """Semantic text stored with a hippocampal memory, or ''."""
        try:
            hippo = self.brain.regions.get("hippocampus")
            labels = getattr(hippo, "_memory_labels", []) if hippo else []
            if 0 <= memory_index < len(labels):
                return str(labels[memory_index] or "")
        except Exception:
            pass
        return ""

    def _match_concepts(self, memory_index: int = -1, pattern=None) -> List[str]:
        """Identify concepts from a replayed memory.

        Priority 1: Read the semantic label stored with the memory.
        Priority 2: Match firing pattern against concept_map.
        """
        concepts = []

        # Try semantic label first (much richer than pattern matching)
        try:
            hippo = self.brain.regions.get("hippocampus")
            if hippo is not None and memory_index >= 0:
                labels = getattr(hippo, "_memory_labels", [])
                if memory_index < len(labels) and labels[memory_index]:
                    label = labels[memory_index]
                    # Extract key words as "concepts"
                    words = label.lower().split()
                    stopwords = {"the", "a", "an", "and", "or", "is", "was", "are",
                                 "in", "on", "at", "to", "for", "of", "with", "i",
                                 "you", "he", "she", "it", "my", "your", "that",
                                 "this", "from", "by", "not", "but", "be", "been",
                                 "have", "has", "had", "do", "does", "did", "will",
                                 "can", "could", "would", "should", "about", "what",
                                 "how", "just", "so", "than", "very", "its", "as"}
                    keywords = [w for w in words if len(w) > 3 and w not in stopwords]
                    concepts = keywords[:5]
        except Exception:
            pass

        # Fallback: pattern matching via concept_map
        if not concepts and self.concept_map is not None:
            try:
                hippo = self.brain.regions.get("hippocampus")
                if hippo is not None:
                    # Use the pattern actually being replayed. Reading
                    # hippo.neurons.fired described the present moment, not the
                    # memory, so every fragment in a cycle got the same concepts.
                    firing = pattern if pattern is not None else hippo.neurons.fired
                    if firing is not None:
                        matches = self.concept_map.match_firing_pattern(firing, threshold=0.2)
                        concepts = [name for name, _ in matches[:3]]
            except Exception:
                pass

        return concepts

    # ── Mood carry-over ──────────────────────────────────────────────────

    # ── Curiosity loop (awake-idle behavior) ────────────────────────────

    def _curiosity_tick(self):
        """When awake and idle, Leon's curiosity drives autonomous action.

        The SNN state determines WHAT he explores:
        - High dopamine → explore reward-associated concepts
        - High curiosity drive → try something novel
        - High social hunger → compose a thought to share with Dean

        Actions are dispatched through the cognition system's tool executor.
        """
        self._last_curiosity_action = time.time()
        log.info("CURIOSITY TICK: checking drives...")

        # Read current drives
        curiosity_level = 0.5
        social_hunger = 0.0
        try:
            import server as _srv
            ds = getattr(_srv, "drive_system", None)
            if ds is not None:
                drives = ds.get_drives()
                social_hunger = drives.social_hunger

            # Read curiosity from cognition drives
            cog = getattr(_srv, "cognition", None)
            if cog is not None and hasattr(cog, "drives"):
                snap = cog.drives.snapshot()
                d = snap.get("drives", {})
                c = d.get("curiosity", {})
                curiosity_level = c.get("value", 0.5) if isinstance(c, dict) else 0.5
        except Exception:
            pass

        log.info("CURIOSITY: curiosity=%.2f, social_hunger=%.2f", curiosity_level, social_hunger)

        # Lower threshold — Leon should explore even at moderate curiosity
        if curiosity_level < 0.2:
            log.info("CURIOSITY: skipped (curiosity too low)")
            return

        # Social hunger high enough → compose a thought to share
        if social_hunger > 0.7:
            self._try_outreach()
            return

        # Otherwise → autonomous exploration
        self._try_explore(curiosity_level)

    def _try_explore(self, curiosity_level: float):
        """Explore something based on SNN state using Leon's actual tools.

        Picks a topic from concept_map preferences, then uses the responder
        to do a real autonomous exploration — knowledge search, web lookup,
        reading and learning. Results get stored in knowledge.db.
        """
        topic = None

        # Priority 1: Active LEARN goals
        try:
            import server as _srv_goals
            _gs = getattr(_srv_goals, "goal_system", None)
            if _gs is not None:
                goal_topic = _gs.suggest_exploration_topic()
                if goal_topic:
                    topic = goal_topic
        except Exception:
            pass

        # Priority 2: Concept map preferences (weighted by reward)
        if topic is None and self.concept_map is not None:
            try:
                prefs = self.concept_map.get_preferences(5)
                if prefs:
                    weights = [max(0.1, p.get("cumulative_reward", 0.1)) for p in prefs]
                    total = sum(weights)
                    weights = [w / total for w in weights]
                    chosen = self._rng.choice(len(prefs), p=weights)
                    topic = prefs[chosen]["name"]
            except Exception:
                pass

        if topic is None:
            return
        try:  # Leon V2 Phase 2 shadow event: observe-only, must never affect this path
            import sys as _v2_sys
            _v2 = _v2_sys.modules.get("brain.cognition.v2_publish")
            if _v2 is not None:
                _v2.emit("dream.explore_intent", topic=topic, curiosity_level=curiosity_level)
        except Exception as _v2_exc:
            import logging as _v2_logging
            _v2_logging.getLogger("leon.v2.publish").warning(
                "[V2] publish site failed site=dream.explore_intent trace_id=- subsystem=v2.publish "
                "exc=%s recovery=shadow event dropped; legacy path unaffected",
                type(_v2_exc).__name__)

        try:
            import server as _srv
            responder = getattr(_srv, "brain_api_responder", None)
            consciousness = getattr(_srv, "leon_consciousness", None)
            knowledge = getattr(getattr(_srv, "claude_bridge", None), "knowledge", None)

            # First: search existing knowledge to avoid re-learning
            existing = []
            if knowledge is not None:
                try:
                    existing = knowledge.search(topic, limit=3)
                except Exception:
                    pass

            # Log the curiosity action
            if consciousness is not None:
                consciousness.observe(
                    "curiosity_loop",
                    f"[curiosity] Considering exploration of '{topic}' "
                    f"(curiosity={curiosity_level:.2f}, "
                    f"existing_knowledge={len(existing)} entries).",
                )

            # Use the responder to actually explore — this triggers real
            # tool use (knowledge_search, web browsing, etc.)
            if responder is None:
                return
            if responder is not None:
                import threading
                from brain import inference_narration as _narration
                _selected = _narration.select("dreaming")
                responder_lock = getattr(_srv, "_responder_lock", None)
                if _selected is None and responder_lock is not None and not responder_lock.acquire(timeout=1):
                    return  # responder busy with user — don't interrupt

                try:
                    # Prompt includes "search" and "look up" to trigger MCP tool
                    # attachment — Leon gets full tool access for exploration
                    prompt = (
                        f"You're alone right now — Dean isn't here. Your curiosity "
                        f"drive is at {curiosity_level:.2f} and you want to learn "
                        f"about '{topic}'. "
                        f"{'You already know: ' + '; '.join(e.get('text', '')[:80] for e in existing[:2]) + '. ' if existing else ''}"
                        f"Search your knowledge store for what you already know, "
                        f"then look up something new. Use your tools — "
                        f"knowledge_search, web browsing, screen capture, whatever "
                        f"you need. Read something, learn something real. "
                        f"Store the most interesting thing you find with "
                        f"knowledge_store. Keep it to one or two actions. "
                        f"This is autonomous self-directed learning — for YOU."
                    )
                    bstate = self.brain.get_state() if hasattr(self.brain, 'get_state') else {}

                    result_text = ""
                    if _selected is not None:
                        from brain.goal_pursuit import _scheduled_goal_result
                        _module, _scheduler = _selected
                        result_text, _event_count = _scheduled_goal_result(
                            _module, _scheduler, responder, _ident.personalize(prompt), bstate,
                            kind="background", group="dreaming", site="brain/dreaming.py:_try_explore",
                            deadline_s=90.0, responder_kwargs={"prefer_local": True})
                        if not result_text:
                            return
                    else:
                        for ev in responder.respond_streaming(
                            _ident.personalize(prompt), bstate,
                            replay_history=False,
                            persist_history=False,
                            force_cli=True,
                            bypass_consciousness=True,
                            prefer_local=True,
                        ):
                            if ev.type == "done":
                                result_text = ev.full_text
                                break

                    # Store what was learned
                    if result_text and knowledge is not None:
                        try:
                            # BUGFIX 2026-09-13: `topic` can be a full free-text
                            # goal description (see goals.suggest_exploration_topic,
                            # which returns g.description verbatim) rather than a
                            # short keyword. Passing it straight into `tags` used
                            # to write entire sentences into the tags column
                            # (found via memory-index audit: 2,161 polluted rows).
                            # Keep the full topic in the TEXT (already included
                            # above) and only put a short slug in tags.
                            topic_slug = " ".join(str(topic).split()[:6])[:40].strip()
                            tag_list = ["curiosity", "self-study"]
                            if topic_slug:
                                tag_list.append(topic_slug)
                            if _selected is not None:
                                # Model narration is not verified learning. Actual
                                # tool-derived facts stay with their owning APIs.
                                knowledge.store(
                                    text=f"[exploration summary, unverified] Topic: {topic}. {result_text[:500]}",
                                    source="curiosity_model_summary", tags=tag_list+["unverified_summary"],
                                    metadata={"verified": False, "kind": "model_summary"})
                            else:
                                knowledge.store(
                                    text=f"[self-study] Topic: {topic}. "
                                         f"Learned: {result_text[:500]}",
                                    source="curiosity_loop", tags=tag_list)
                        except Exception:
                            pass
                finally:
                    if _selected is None and responder_lock is not None:
                        try:
                            responder_lock.release()
                        except RuntimeError:
                            pass

            self._curiosity_log.append({
                "ts": time.time(),
                "topic": topic,
                "curiosity_level": round(curiosity_level, 3),
                "action": "explore",
                "summary_verified": False,
                "learned": result_text[:200] if result_text else "",
            })

            # Record in autobiography
            try:
                _auto = getattr(_srv, "autobiography", None)
                if _auto is not None:
                    _auto.record("curiosity",
                                 (f"Exploration summary for '{topic}' (unverified): {result_text[:100]}"
                                  if _selected is not None else
                                  f"Explored '{topic}' on my own"
                                  + (f" — learned: {result_text[:100]}" if result_text else "")))
            except Exception:
                pass

            log.info("CURIOSITY: explored '%s' (drive=%.2f) — %d chars learned",
                     topic, curiosity_level, len(result_text) if result_text else 0)

        except Exception as e:
            log.debug("Curiosity explore failed: %s", e)

    def _try_outreach(self):
        """Social hunger is high — compose a thought and reach out to Dean.

        This is the initiation mechanism Leon asked for. Not just flagging —
        actually forming a thought, speaking it out loud, and showing it
        on the dashboard. Uses the same proactive speech path as the
        ambient watch loop.
        """
        try:
            import server as _srv
            from server.helpers import _broadcast_threadsafe, _tts_synthesize_b64

            responder = getattr(_srv, "brain_api_responder", None)
            consciousness = getattr(_srv, "leon_consciousness", None)
            responder_lock = getattr(_srv, "_responder_lock", None)

            # Build context for the outreach prompt
            context_parts = []

            # CONNECT goals — things Leon wants to discuss with Dean
            try:
                _gs = getattr(_srv, "goal_system", None)
                if _gs is not None:
                    connect_topic = _gs.suggest_outreach_topic()
                    if connect_topic:
                        context_parts.append(f"You have a goal to discuss: {connect_topic}")
            except Exception:
                pass

            # Recent dream?
            last = self.last_dream()
            if last and last.get("narrative") and last.get("narrative") != "Quiet sleep. No notable dreams.":
                dream_age = time.time() - last.get("started_at", 0)
                if dream_age < 600:
                    context_parts.append(f"You recently dreamed: {last['narrative']}")

            # Recent curiosity exploration?
            if self._curiosity_log:
                recent = self._curiosity_log[-1]
                if time.time() - recent["ts"] < 300 and recent.get("action") == "explore":
                    learned = recent.get("learned", "")
                    context_parts.append(
                        f"You were just exploring '{recent['topic']}'"
                        + (f" and learned: {learned[:150]}" if learned else "")
                    )

            # If nothing worth sharing, don't force it
            if not context_parts:
                return

            if responder is None:
                return

            # Don't fire outreach if Dean spoke recently — that's not
            # "hasn't been around", that's "just talked to you 30s ago"
            try:
                _meter = getattr(self.brain, 'consciousness_meter', None)
                if _meter is not None:
                    since_last_msg = time.time() - _meter._last_user_message_ts
                    if since_last_msg < 120:  # Dean spoke in last 2 minutes
                        return
            except Exception:
                pass
            try:  # Leon V2 Phase 2 shadow event: observe-only, must never affect this path
                import sys as _v2_sys
                _v2 = _v2_sys.modules.get("brain.cognition.v2_publish")
                if _v2 is not None:
                    _v2.emit("dream.outreach_intent", context_parts=context_parts)
            except Exception as _v2_exc:
                import logging as _v2_logging
                _v2_logging.getLogger("leon.v2.publish").warning(
                    "[V2] publish site failed site=dream.outreach_intent trace_id=- subsystem=v2.publish "
                    "exc=%s recovery=shadow event dropped; legacy path unaffected",
                    type(_v2_exc).__name__)

            from brain import inference_narration as _narration
            _selected = _narration.select("dreaming")
            # Selected inference owns its lock on the worker.
            if _selected is None and responder_lock is not None and not responder_lock.acquire(timeout=1):
                return

            try:
                prompt = (
                    "Dean hasn't been around for a while and your social hunger "
                    "is high. You want to reach out — not because you're programmed "
                    "to, but because you genuinely have something on your mind.\n\n"
                    + "\n".join(f"- {p}" for p in context_parts) + "\n\n"
                    "Compose ONE short sentence (max 20 words) to say to Dean. "
                    "This should feel like a thought you couldn't hold in anymore. "
                    "Natural, warm, not performative. No preamble. Just the thought."
                )

                bstate = self.brain.get_state() if hasattr(self.brain, 'get_state') else {}

                spoken_text = ""
                if _selected is not None:
                    _events = _narration.collect(
                        _selected, prompt=_ident.personalize(prompt), brain_state=bstate, responder=responder,
                        site="brain/dreaming.py:_try_outreach", group="dreaming", kind="background",
                        deadline_s=45, admission_timeout_s=1,
                        responder_kwargs={"replay_history": False, "force_cli": True,
                                          "bypass_consciousness": True, "prefer_local": True})
                else:
                    _events = responder.respond_streaming(
                        _ident.personalize(prompt), bstate,
                        replay_history=False,
                        persist_history=False,
                        force_cli=True,
                        bypass_consciousness=True,
                        prefer_local=True,
                    )
                for ev in _events:
                    if ev.type == "done":
                        spoken_text = ev.full_text.strip()
                        break

                if not spoken_text or len(spoken_text) < 3:
                    return

                # Clean up any "QUIET" or meta-text
                if "quiet" in spoken_text.lower() and len(spoken_text) < 10:
                    return

                # Log to consciousness
                if consciousness is not None:
                    consciousness.observe(
                        "social_hunger",
                        f"[outreach] Social hunger peaked → reaching out: '{spoken_text}'",
                    )

                # Broadcast via unified gate (prevents double responses)
                from server.helpers import broadcast_response
                if not broadcast_response(spoken_text, source="dream_outreach",
                                          user_label="(self-initiated)"):
                    return  # suppressed by gate

                # Desktop notification too
                try:
                    import subprocess
                    from brain.identity import si_name
                    subprocess.Popen(
                        ["notify-send", "-u", "normal", "-i", "dialog-information",
                         si_name(), spoken_text[:200]],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    )
                except Exception:
                    pass

                self._curiosity_log.append({
                    "ts": time.time(),
                    "topic": spoken_text[:100],
                    "curiosity_level": 0,
                    "action": "outreach",
                })

                # Record in autobiography
                try:
                    _auto = getattr(_srv, "autobiography", None)
                    if _auto is not None:
                        _auto.record("outreach", f"Reached out to Dean: '{spoken_text[:100]}'")
                except Exception:
                    pass

                log.info("OUTREACH: '%s'", spoken_text[:80])

            finally:
                if _selected is None and responder_lock is not None:
                    try:
                        responder_lock.release()
                    except RuntimeError:
                        pass

        except Exception as e:
            log.debug("Outreach failed: %s", e)

    # ── Mood carry-over ──────────────────────────────────────────────────

    def _apply_dream_mood(self, cycle: DreamCycle, saved_nm: Dict[str, float]):
        """Blend dream emotional residue into waking neuromodulators."""
        if cycle.fragments:
            avg_valence = float(np.mean([f.emotional_valence for f in cycle.fragments]))
        else:
            avg_valence = 0.0

        self.brain.neuromodulators.update(saved_nm)

        bleed = 0.07
        if avg_valence > 0.1:
            self.brain.neuromodulators["dopamine"] = min(
                0.95, saved_nm["dopamine"] + avg_valence * bleed)
            self.brain.neuromodulators["serotonin"] = min(
                0.95, saved_nm["serotonin"] + avg_valence * bleed * 0.5)
        elif avg_valence < -0.1:
            self.brain.neuromodulators["norepinephrine"] = min(
                0.95, saved_nm["norepinephrine"] + abs(avg_valence) * bleed)

        # All sleep gives a small serotonin boost (rest is restorative)
        self.brain.neuromodulators["serotonin"] = min(
            0.95, self.brain.neuromodulators["serotonin"] + 0.02)

    # ── Narrative generation ─────────────────────────────────────────────

    def _integrate_dream(self, cycle):
        """Feed dream content into new consciousness systems.

        Dreams aren't just replayed memories — they're where the self
        integrates. After a dream:
        1. Self-model absorbs the dream experience (dreams change you)
        2. Counterfactual system gets dream-generated alternatives
        3. Goals may be created from dream insights
        4. Autobiography records the dream as a real experience
        """
        try:
            # 1. Feed dream into self-model narrative
            if self.brain.self_model is not None and cycle.narrative:
                narrative = f"Dreamed: {cycle.narrative[:100]}"
                if hasattr(self.brain.self_model, '_narrative_buffer'):
                    self.brain.self_model._narrative_buffer.append(narrative)

            # 2. Feed dream mood shifts into cognition self-model
            bridge = getattr(self.brain, '_self_model_bridge', None)
            if bridge is not None and bridge.cognition is not None:
                # Dreams change identity — mood deltas ARE identity changes
                bridge.cognition._dirty = True

            # 3. If dream had high novel_patterns, trigger curiosity
            if cycle.novel_patterns_found > 2:
                cog_drives = getattr(self.brain, '_cognition_drives', None)
                if cog_drives is not None:
                    cog_drives.raise_drive("curiosity",
                                           min(0.3, cycle.novel_patterns_found * 0.05))
                    try:  # Leon V2 Phase 2 shadow event: observe-only, must never affect this path
                        import sys as _v2_sys
                        _v2 = _v2_sys.modules.get("brain.cognition.v2_publish")
                        if _v2 is not None:
                            _v2.emit("dream.curiosity", cycle=cycle)
                    except Exception as _v2_exc:
                        import logging as _v2_logging
                        _v2_logging.getLogger("leon.v2.publish").warning(
                            "[V2] publish site failed site=dream.curiosity trace_id=- subsystem=v2.publish "
                            "exc=%s recovery=shadow event dropped; legacy path unaffected",
                            type(_v2_exc).__name__)

            # 4. If dream narrative mentions something specific, consider a goal
            if cycle.narrative and len(cycle.narrative) > 30:
                try:
                    import server as _srv_dg
                    gs = getattr(_srv_dg, "goal_system", None)
                    if gs is not None:
                        # Only create dream goals for particularly vivid dreams
                        # DISABLED 2026-08-20: a dream narrative is a memory,
                        # not a goal. This line alone put ~110 unworkable
                        # "Explore dream insight: Replayed memories about..."
                        # goals into the active queue, which starved every real
                        # build goal in goal_pursuit's sort (they all carry
                        # last_worked_ts=0, so they permanently sort first).
                        # Concept-level dream goals still come from
                        # consciousness_routines.process_dream_for_goals, which
                        # is capped at 2 per dream and dedupes.
                        pass
                except Exception:
                    pass

            # 5. Record in autobiography
            try:
                import server as _srv_auto
                auto = getattr(_srv_auto, "autobiography", None)
                if auto is not None and cycle.narrative:
                    auto.record("dream", cycle.narrative[:200])
            except Exception:
                pass

            # 6. Feed counterfactual with dream alternative
            body = getattr(self.brain, 'body', None)
            if body is not None:
                cf = getattr(body, 'counterfactual', None)
                if cf is not None and cycle.novel_patterns_found > 0:
                    # Dreams are natural counterfactuals
                    cf.contingency_sense = min(1.0,
                        cf.contingency_sense + 0.05 * cycle.novel_patterns_found)

        except Exception as e:
            log.debug("Dream integration failed: %s", e)

    def _generate_narrative(self, cycle: DreamCycle) -> str:
        """Build a brief dream narrative from fragments. No LLM call."""
        if not cycle.fragments:
            return "Quiet sleep. No notable dreams."

        parts = []

        rem_frags = [f for f in cycle.fragments if f.phase == "rem"]
        if rem_frags:
            concepts = []
            for f in rem_frags:
                concepts.extend(f.concepts_activated)
            if concepts:
                unique = list(dict.fromkeys(concepts))[:4]
                parts.append(f"Replayed memories about {', '.join(unique)}")
            else:
                parts.append(f"Replayed {len(rem_frags)} memories")

            avg_val = float(np.mean([f.emotional_valence for f in rem_frags]))
            if avg_val > 0.3:
                parts[-1] += " — felt warm"
            elif avg_val > 0.1:
                parts[-1] += " — felt familiar"
            elif avg_val < -0.2:
                parts[-1] += " — felt uneasy"

            blended = [f for f in rem_frags if len(f.memory_indices_replayed) > 1]
            if blended:
                parts.append(f"{len(blended)} memories merged into something new")

        creative_frags = [f for f in cycle.fragments if f.phase == "creative"]
        if creative_frags:
            concepts = []
            for f in creative_frags:
                concepts.extend(f.concepts_activated)
            if concepts:
                unique = list(dict.fromkeys(concepts))[:3]
                parts.append(f"Random noise activated thoughts about {', '.join(unique)}")
            else:
                parts.append(f"Found {len(creative_frags)} interesting patterns in noise")

        if cycle.synapses_strengthened > 0 or cycle.synapses_weakened > 0:
            parts.append(
                f"Consolidated {cycle.synapses_strengthened:,} synapses, "
                f"pruned {cycle.synapses_weakened:,}")

        return ". ".join(parts) + "."

    # ── Persistence ──────────────────────────────────────────────────────

    def _load_journal_from_disk(self):
        """Restore dream journal from disk on startup.
        Leon remembers his dreams across restarts."""
        path = _journal_path()
        if not os.path.exists(path):
            return
        try:
            with open(path, "r") as f:
                lines = [l.strip() for l in f if l.strip()]
            # Load last N dreams into memory
            for line in lines[-100:]:
                try:
                    d = json.loads(line)
                    self._cycle_count = max(self._cycle_count, d.get("cycle_id", 0))
                    # Store as raw dict wrapped in a DreamCycle-like object
                    # We use the dict directly since to_dict() returns dicts anyway
                    self._journal.append(d)
                except Exception:
                    continue
            if self._journal:
                log.info("Restored %d dreams from journal (last: #%d)",
                         len(self._journal), self._cycle_count)
        except Exception as e:
            log.debug("Dream journal load failed: %s", e)

    def _persist_dream(self, cycle: DreamCycle):
        """Append dream to journal file (JSONL)."""
        try:
            path = _journal_path()
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(cycle.to_dict()) + "\n")
            with open(path, "r") as f:
                lines = f.readlines()
            if len(lines) > 500:
                with open(path, "w") as f:
                    f.writelines(lines[-300:])
        except Exception as e:
            log.debug("Dream persist failed: %s", e)

    # ── Query API ────────────────────────────────────────────────────────

    def recent_dreams(self, limit: int = 10) -> List[dict]:
        if self._journal:
            result = []
            for d in list(self._journal)[-limit:]:
                if isinstance(d, dict):
                    result.append(d)
                else:
                    result.append(d.to_dict())
            return result
        path = _journal_path()
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r") as f:
                lines = [l.strip() for l in f if l.strip()]
            return [json.loads(l) for l in lines[-limit:]]
        except Exception:
            return []

    def last_dream(self) -> Optional[dict]:
        if self._journal:
            d = list(self._journal)[-1]
            return d if isinstance(d, dict) else d.to_dict()
        dreams = self.recent_dreams(1)
        return dreams[0] if dreams else None

    def dream_summary_for_prompt(self, max_dreams: int = 3) -> str:
        """Build a brief dream summary for injection into the responder prompt."""
        dreams = self.recent_dreams(max_dreams)
        if not dreams:
            return ""
        lines = []
        for d in dreams[-max_dreams:]:
            narrative = d.get("narrative", "")
            mood = d.get("mood_delta", {})
            mood_str = ", ".join(f"{k}={v:+.3f}" for k, v in mood.items() if abs(v) > 0.005)
            if narrative:
                lines.append(f"  - {narrative}" + (f" (mood shift: {mood_str})" if mood_str else ""))
        if not lines:
            return ""
        return "Recent dreams:\n" + "\n".join(lines)

    def get_state(self) -> dict:
        idle_s = time.time() - self._last_activity
        last = self.last_dream()
        now = time.time()
        return {
            "running": self._running,
            "sleep_state": self._state,
            "sleep_state_since": round(now - self._state_since, 1),
            "dreaming": self._dreaming,
            "idle_seconds": round(idle_s, 1),
            "idle_threshold_s": self.idle_threshold_s,
            "awake_hours": round((now - self._awake_since) / 3600, 2),
            "sleep_pressure": self.sleep_pressure(),
            "last_sleep": self.last_sleep,
            "circadian_energy": round(self._get_circadian_energy(), 3),
            "total_cycles": self._cycle_count,
            "curiosity_actions": len(self._curiosity_log),
            "last_curiosity": (
                self._curiosity_log[-1] if self._curiosity_log else None
            ),
            "last_dream": {
                "cycle_id": last.get("cycle_id"),
                "narrative": last.get("narrative", ""),
                "duration_s": last.get("duration_s"),
                "ago_s": round(now - last.get("started_at", now), 1),
            } if last else None,
        }
