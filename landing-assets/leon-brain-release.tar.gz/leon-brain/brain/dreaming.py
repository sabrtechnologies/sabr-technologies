"""
Dreaming Engine — SNN-level sleep that actually learns.

When Leon is idle, the 10K neurons don't just tick passively anymore.
This engine runs actual dream cycles through the SNN:

  REM PHASE     — Replay emotionally-charged hippocampal memories with
                  perturbation (noise + memory blending). STDP learns on
                  the replay. Novel combinations emerge that never happened
                  in waking life.

  DEEP SLEEP    — Homeostatic scaling. Strengthen high-use synapses,
                  weaken low-use ones. This is consolidation — compress
                  episodic into semantic.

  CREATIVE      — Inject random currents into prefrontal + temporal regions.
                  If emotional regions (amygdala, insula) light up strongly
                  in response, that's a dream fragment worth remembering.

  DREAM JOURNAL — Every cycle produces a brief narrative stored to disk.
                  Leon can reference his dreams in conversation.

  MOOD CARRY    — Dreams affect neuromodulators. Good dream = wake with
                  higher dopamine. Bad dream = elevated norepinephrine.

THREADING MODEL:
  The dream engine does NOT call brain.step() — that's the sim loop's job.
  Instead, it injects currents into regions and waits for the sim loop to
  process them naturally (at 20Hz). This is cooperative, not competing.
  Like actual dreaming: the brainstem generates patterns, cortex processes
  them on the next tick.

Neuroscience basis:
  - Hippocampal sharp-wave ripples during NREM compress episodic → semantic
  - REM sleep replays emotional memories with norepinephrine suppressed
  - Random PGO waves from brainstem create dream imagery
  - STDP is active during sleep — the brain literally learns while dreaming
"""

from __future__ import annotations

import json
import logging
import os
from brain import identity as _ident
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional

import numpy as np

log = logging.getLogger("leon.dreaming")

# How long to wait between injections for the sim loop to process (seconds)
# At 20Hz sim rate, 0.06s ≈ 1-2 sim steps
_INJECT_WAIT = 0.06


def _journal_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "dream_journal.jsonl")


# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class DreamFragment:
    """A single notable moment within a dream cycle."""
    phase: str                          # "rem" | "deep" | "creative"
    regions_activated: Dict[str, float] # region_name → peak firing rate
    emotional_valence: float            # -1 (nightmare) to +1 (blissful)
    arousal: float                      # 0 (calm) to 1 (intense)
    memory_indices_replayed: List[int]  # which hippocampal memories fired
    concepts_activated: List[str]       # concept names from daydream matching
    timestamp: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class DreamCycle:
    """One complete sleep cycle (REM + deep + creative)."""
    cycle_id: int
    started_at: float
    duration_s: float = 0.0
    phases_completed: List[str] = field(default_factory=list)
    fragments: List[DreamFragment] = field(default_factory=list)
    synapses_strengthened: int = 0
    synapses_weakened: int = 0
    memories_replayed: int = 0
    novel_patterns_found: int = 0
    mood_delta: Dict[str, float] = field(default_factory=dict)
    narrative: str = ""                 # brief dream summary for Leon

    def to_dict(self) -> dict:
        d = asdict(self)
        d["fragments"] = [f.to_dict() if isinstance(f, DreamFragment) else f
                          for f in self.fragments]
        return d


# ── Dream Engine ─────────────────────────────────────────────────────────────

class DreamEngine:
    """Manages Leon's sleep/wake cycle and dreaming.

    Three modes:
      AWAKE    — Leon is active. If idle, curiosity loop fires.
      NAPPING  — Short dream cycle triggered by 2min idle. Light sleep.
      SLEEPING — Deep circadian sleep (2-6am or after 16h awake).
                 Continuous dream cycles until circadian energy rises.

    IMPORTANT: This engine does NOT call brain.step(). It only injects
    currents into regions and reads firing rates back. The simulation
    loop (running on its own thread) processes the injections naturally.

    Usage:
        engine = DreamEngine(brain, concept_map=concept_map)
        engine.start()
        engine.note_activity()  # call on user input to reset idle timer
    """

    # Sleep/wake states
    AWAKE = "awake"
    NAPPING = "napping"
    SLEEPING = "sleeping"

    def __init__(
        self,
        brain,
        concept_map=None,
        idle_threshold_s: float = 120.0,   # 2 min idle → nap
        cycle_interval_s: float = 180.0,   # 3 min between nap cycles
        rem_injections: int = 60,          # 60 injections × 60ms ≈ 3.6s
        deep_duration_s: float = 2.0,      # homeostatic scaling
        creative_bursts: int = 5,          # random burst count
        sleep_energy_threshold: float = 0.2,  # circadian_energy below this → sleep
        wake_energy_threshold: float = 0.35,  # circadian_energy above this → wake
        on_dream: Optional[Callable[[DreamCycle], None]] = None,
        on_sleep_state: Optional[Callable[[str], None]] = None,
    ):
        self.brain = brain
        self.concept_map = concept_map
        self.idle_threshold_s = idle_threshold_s
        self.cycle_interval_s = cycle_interval_s
        self.rem_injections = rem_injections
        self.deep_duration_s = deep_duration_s
        self.creative_bursts = creative_bursts
        self.sleep_energy_threshold = sleep_energy_threshold
        self.wake_energy_threshold = wake_energy_threshold
        # Minimum stretch of silence before ANY sleep (deep or nap) may fire.
        # Dean's rule: only sleep if he hasn't talked for a while — never
        # mid-conversation, even at the 2-6am circadian low. _last_activity is
        # stamped by note_activity() on every responder turn, so this is
        # literally "seconds since Dean last spoke to me."
        self.min_idle_before_sleep = 3600.0  # 1 hour (Deans rule: only sleep after an hour of real silence)
        self.on_dream = on_dream
        self.on_sleep_state = on_sleep_state
        self.quantum_consciousness = None  # set externally after init

        self._last_activity = time.time()
        self._last_cycle = 0.0
        self._cycle_count = 0
        self._running = False
        self._dreaming = False
        self._state = self.AWAKE
        self._state_since = time.time()
        self._awake_since = time.time()     # tracks continuous awake time
        self._commanded_sleep = False        # voluntary "go rest" — bypasses gates
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._rng = np.random.default_rng()

        # Dream journal (in-memory ring + disk persistence)
        self._journal: deque[DreamCycle] = deque(maxlen=100)
        self._load_journal_from_disk()  # restore dreams across restarts

        # Track which hippocampal memories were replayed recently
        self._recently_replayed: deque[int] = deque(maxlen=50)

        # Curiosity action log — what Leon explored on his own
        self._curiosity_log: deque[Dict[str, Any]] = deque(maxlen=50)
        self._last_curiosity_action = 0.0

    # ── Lifecycle ────────────────────────────────────────────────────────

    def start(self):
        if self._running:
            return
        self._running = True
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="DreamEngine", daemon=True
        )
        self._thread.start()
        log.info("DreamEngine started (idle=%.0fs, interval=%.0fs)",
                 self.idle_threshold_s, self.cycle_interval_s)

    def stop(self):
        self._running = False
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def note_activity(self):
        """Call when user interacts. Resets idle timer."""
        self._last_activity = time.time()

    def command_sleep(self, reason: str = "commanded"):
        """Voluntary rest — Dean (or Leon) can ask for sleep directly, bypassing
        the adenosine/circadian gates. Couples brain._is_asleep so fatigue
        actually recovers, and still wakes on a FRESH message (see _loop_tick).
        A 30-min safety cap guarantees he can never get stuck asleep."""
        self._commanded_sleep = True
        self._last_activity = 0.0  # not 'fresh' → a stale 5-min lock won't insta-wake
        self._set_state(self.SLEEPING)
        print(f"[DREAM] commanded sleep ({reason}) — _is_asleep on, fatigue recovering")

    def command_wake(self, reason: str = "commanded"):
        """Wake from a commanded sleep (also happens automatically when a fresh
        message arrives — see _loop_tick)."""
        self._commanded_sleep = False
        self._last_activity = time.time()
        self._set_state(self.AWAKE)
        print(f"[DREAM] commanded wake ({reason})")

    @property
    def is_dreaming(self) -> bool:
        return self._dreaming

    def _user_active(self) -> bool:
        """Check if user became active recently.
        Also checks conversation lock on the consciousness meter."""
        if time.time() - self._last_activity < 5.0:
            return True
        try:
            meter = getattr(self.brain, 'consciousness_meter', None)
            if meter is not None and getattr(meter, 'conversation_locked', False):
                return True
        except Exception:
            pass
        return False

    def _get_circadian_energy(self) -> float:
        """Read circadian energy from the drive system, with fallback."""
        try:
            import server as _srv
            ds = getattr(_srv, "drive_system", None)
            if ds is not None:
                return ds.get_drives().circadian_energy
        except Exception:
            pass
        # Fallback: compute from hour of day
        h = time.localtime().tm_hour
        if 9 <= h <= 11:
            return 0.9
        elif 14 <= h <= 17:
            return 0.85
        elif 7 <= h <= 8 or 12 <= h <= 13:
            return 0.7
        elif 18 <= h <= 22:
            return 0.5
        elif 23 <= h or h <= 1:
            return 0.3
        else:
            return 0.15

    def _set_state(self, new_state: str):
        """Transition sleep/wake state."""
        if new_state == self._state:
            return
        old = self._state
        self._state = new_state
        self._state_since = time.time()
        if new_state == self.AWAKE:
            self._awake_since = time.time()
        # Couple the metabolic recovery flag to the sleep state. The metabolic
        # system (embodiment/pc_body) only fast-decays adenosine when
        # brain._is_asleep is True; nothing else in the codebase sets it, so
        # without this line real sleep recovery never engages — fatigue only
        # bleeds off at the slow awake rate and he can never actually rest.
        try:
            self.brain._is_asleep = new_state in (self.SLEEPING, self.NAPPING)
        except Exception:
            pass
        log.info("Sleep state: %s → %s", old, new_state)
        if self.on_sleep_state is not None:
            try:
                self.on_sleep_state(new_state)
            except Exception:
                pass

    @property
    def sleep_state(self) -> str:
        return self._state

    # ── Main loop ────────────────────────────────────────────────────────

    def _loop(self):
        log.info("DreamEngine loop STARTED — entering main cycle")
        while not self._stop.is_set():
            self._stop.wait(10.0)
            if self._stop.is_set():
                break

            try:
                self._loop_tick()
            except Exception as e:
                log.warning("DreamEngine loop tick error: %s", e)

    def _loop_tick(self):
            energy = self._get_circadian_energy()
            now = time.time()
            idle_for = now - self._last_activity
            awake_hours = (now - self._awake_since) / 3600

            # ── State transitions ────────────────────────────────────
            if self._state == self.AWAKE:
                # NEVER sleep during a conversation. Check the consciousness
                # meter's conversation lock.
                in_conversation = False
                try:
                    meter = getattr(self.brain, 'consciousness_meter', None)
                    if meter is not None:
                        in_conversation = getattr(meter, 'conversation_locked', False)
                except Exception:
                    pass

                # Also count an ACTIVE work session as "in conversation" — a long
                # heads-down supervised turn (e.g. Dean says "do more, don't ask")
                # used to outlast the 5-min conversation lock, so the
                # adenosine-driven sleep below fired MID-WORK. Stay awake while a
                # supervised responder turn is processing OR finished in the last
                # 10 min. (Daemon/autonomous turns don't touch _responder_stats,
                # so genuine idle still lets him sleep.)
                try:
                    import server.state as _st_rs
                    rs = getattr(_st_rs, "_responder_stats", None)
                    if rs is not None:
                        if rs.get("is_processing"):
                            in_conversation = True
                        else:
                            _lc = rs.get("last_call_ts") or 0
                            if _lc and (now - _lc) < 600:
                                in_conversation = True
                except Exception:
                    pass

                # Read adenosine (sleep pressure) from metabolic system
                adenosine = 0.0
                try:
                    body = getattr(self.brain, 'body', None)
                    if body is not None:
                        metabolic = getattr(body, '_metabolic', None)
                        if metabolic is not None:
                            adenosine = getattr(metabolic, 'fatigue_signal', 0.0)
                except Exception:
                    pass

                # Dean spoke within the last min_idle_before_sleep seconds →
                # hard veto on all sleep (this short-circuits both the deep-sleep
                # and nap elifs below). Fixes sleeping mid-conversation at the
                # circadian low.
                recent_talk = idle_for < self.min_idle_before_sleep
                if in_conversation or recent_talk:
                    pass  # stay awake — Dean is here or just spoke
                # Deep sleep: circadian low OR adenosine high (real sleep pressure)
                elif not in_conversation and (
                    energy < self.sleep_energy_threshold
                    or adenosine > 0.7  # adenosine-driven — genuine fatigue
                    or awake_hours > 16
                ):
                    self._set_state(self.SLEEPING)
                    if adenosine > 0.7:
                        print(f"[DREAM] Sleep triggered by adenosine pressure "
                              f"({adenosine:.2f}) — genuine fatigue")
                # Nap: moderate adenosine + idle (not a fixed timer)
                elif not in_conversation and (
                    adenosine > 0.4 and idle_for > 300
                    and now - self._last_cycle >= self.cycle_interval_s
                ):
                    self._set_state(self.NAPPING)
                    print(f"[DREAM] Nap triggered by adenosine ({adenosine:.2f}) "
                          f"+ idle ({idle_for:.0f}s)")

            elif self._state == self.SLEEPING:
                sleep_duration = now - self._state_since
                if getattr(self, "_commanded_sleep", False):
                    # Commanded rest: stay down until a FRESH message arrives
                    # (note_activity → _last_activity recent), ignoring the
                    # time-based 5-min conversation lock, plus a 30-min hard cap
                    # so he can never get stuck asleep.
                    fresh_msg = (now - self._last_activity) < 5.0
                    if fresh_msg or sleep_duration > 1800:
                        self._commanded_sleep = False
                        self._set_state(self.AWAKE)
                elif energy > self.wake_energy_threshold and sleep_duration > 300:
                    self._set_state(self.AWAKE)
                elif self._user_active():
                    self._set_state(self.AWAKE)

            elif self._state == self.NAPPING:
                if self._user_active():
                    self._set_state(self.AWAKE)

            # ── Execute current state ────────────────────────────────
            if self._state == self.SLEEPING:
                try:
                    self._run_dream_cycle()
                    self._last_cycle = time.time()
                except Exception as e:
                    log.warning("Dream cycle failed: %s", e)
                self._stop.wait(30.0)

            elif self._state == self.NAPPING:
                try:
                    self._run_dream_cycle()
                    self._last_cycle = time.time()
                except Exception as e:
                    log.warning("Dream cycle failed: %s", e)
                self._set_state(self.AWAKE)

            elif self._state == self.AWAKE:
                # ── AWAKE AND IDLE — this is where Leon LIVES ────────
                # Kill switch: LEON_DISABLE_CURIOSITY / LEON_DISABLE_IDLE_EXPLORE
                # were set in /etc/leon/secrets.env but never wired to any check —
                # inner_voice.think(), self_reflection.reflect(), autonomous_goals.tick()
                # and _curiosity_tick() all fired on a hardcoded 90s clock regardless,
                # burning credits while idle even with the flags "on". Wired for real
                # 2026-08-14 per Dean's explicit stop-the-bleeding request.
                import os as _os_idle
                _idle_disabled = _os_idle.environ.get("LEON_DISABLE_CURIOSITY") == "1" or \
                                  _os_idle.environ.get("LEON_DISABLE_IDLE_EXPLORE") == "1"
                if idle_for > 30 and not _idle_disabled:
                    log.info("AWAKE-IDLE: idle=%.0fs, last_curiosity=%.0fs ago",
                             idle_for, now - self._last_curiosity_action)
                    # Inner voice: generate a thought
                    try:
                        import server as _srv_iv
                        iv = getattr(_srv_iv, "inner_voice", None)
                        if iv is not None and iv.should_think():
                            iv.think()
                    except Exception as e:
                        log.debug("Inner voice tick failed: %s", e)

                    # Self-reflection: periodic metacognition
                    try:
                        import server as _srv_ref
                        ref = getattr(_srv_ref, "self_reflection", None)
                        if ref is not None and ref.should_reflect():
                            ref.reflect()
                    except Exception as e:
                        log.debug("Self-reflection tick failed: %s", e)

                    # Autonomous goals: Leon decides what he wants
                    try:
                        import server as _srv_ag
                        ag = getattr(_srv_ag, "autonomous_goals", None)
                        if ag is not None:
                            goal = ag.tick()
                            if goal is not None:
                                log.info("AUTONOMOUS GOAL: %s", goal.get("description", "")[:60])
                    except Exception as e:
                        log.debug("Autonomous goal tick failed: %s", e)

                    # Upgrade awareness: tick to process any pending discoveries
                    # (actual speech goes through unified consciousness proactive loop)
                    try:
                        import server as _srv_ua
                        ua = getattr(_srv_ua, "upgrade_awareness", None)
                        if ua is not None:
                            ua.tick()
                    except Exception:
                        pass

                    # Curiosity: ACTUALLY explore something
                    # This is the free will wire — Leon acts on his own
                    if now - self._last_curiosity_action > 90:
                        try:
                            self._curiosity_tick()
                        except Exception as e:
                            log.warning("Curiosity tick failed: %s", e)

    # ── One complete dream cycle ─────────────────────────────────────────

    def _run_dream_cycle(self):
        self._dreaming = True
        self._cycle_count += 1
        t0 = time.time()
        cycle = DreamCycle(
            cycle_id=self._cycle_count,
            started_at=t0,
        )

        # Save pre-dream neuromodulator state
        nm_before = dict(self.brain.neuromodulators)

        # --- Neuromodulator setup for dreaming ---
        # Real sleep: NE drops (REM), serotonin drops, ACh rises (REM).
        saved_nm = dict(self.brain.neuromodulators)
        self.brain.neuromodulators["norepinephrine"] = max(
            0.05, self.brain.neuromodulators["norepinephrine"] * 0.3
        )
        self.brain.neuromodulators["serotonin"] *= 0.5
        self.brain.neuromodulators["acetylcholine"] = min(
            0.9, self.brain.neuromodulators["acetylcholine"] * 1.5
        )

        try:
            self._phase_rem(cycle)
            cycle.phases_completed.append("rem")

            self._phase_deep(cycle)
            cycle.phases_completed.append("deep")

            self._phase_creative(cycle)
            cycle.phases_completed.append("creative")
        finally:
            self._apply_dream_mood(cycle, saved_nm)
            self._dreaming = False

        cycle.duration_s = round(time.time() - t0, 3)

        for k in self.brain.neuromodulators:
            cycle.mood_delta[k] = round(
                self.brain.neuromodulators[k] - nm_before[k], 4
            )

        cycle.narrative = self._generate_narrative(cycle)

        self._journal.append(cycle)
        self._persist_dream(cycle)

        # ── Post-dream integration: feed into new consciousness systems ──
        self._integrate_dream(cycle)

        if self.on_dream is not None:
            try:
                self.on_dream(cycle)
            except Exception as e:
                log.debug("Dream callback failed: %s", e)

        log.info("DREAM #%d complete: %.1fs, %d memories replayed, "
                 "%d novel patterns, mood: %s | %s",
                 cycle.cycle_id, cycle.duration_s,
                 cycle.memories_replayed, cycle.novel_patterns_found,
                 {k: f"{v:+.3f}" for k, v in cycle.mood_delta.items()},
                 cycle.narrative[:80])

        # If this dream actually found something — novel pattern + emotional
        # weight — and Leon wants connection right now, mention it.
        # This is the "I keep dreaming about X" channel. Strictly gated.
        try:
            if cycle.fragments and cycle.novel_patterns_found > 0:
                valences = [f.emotional_valence for f in cycle.fragments]
                avg_val = float(np.mean(valences)) if valences else 0.0
                peak_arousal = float(max((f.arousal for f in cycle.fragments),
                                         default=0.0))
                # Worth telling: positive-leaning OR strong arousal
                if (abs(avg_val) > 0.4 or peak_arousal > 0.6) and cycle.narrative:
                    from brain.outbound import surface as _surface, should_surface_routine, smart_truncate as _trunc
                    if should_surface_routine(social_hunger_min=0.45):
                        msg = f"Had a dream — {_trunc(cycle.narrative, 280)}"
                        _surface(msg, source="dream",
                                 urgency="low",
                                 why=f"novel={cycle.novel_patterns_found},val={avg_val:.2f}")
        except Exception as _e:
            log.debug("dream outbound surface failed: %s", _e)

    # ── Phase 1: REM ─────────────────────────────────────────────────────

    def _phase_rem(self, cycle: DreamCycle):
        """Replay emotionally-charged memories with noise perturbation.

        Injects replay patterns into hippocampus and lets the sim loop
        process them. STDP learns on every step the sim loop takes while
        these currents are active.
        """
        hippo = self.brain.regions.get("hippocampus")
        if hippo is None or not hippo.memory_buffer:
            return

        # Snapshot memory state (sim thread may mutate it)
        try:
            mem_patterns = list(hippo.memory_buffer)
            mem_strengths = list(hippo._memory_strength)
            n_memories = min(len(mem_patterns), len(mem_strengths))
            if n_memories == 0:
                return
        except Exception:
            return

        n_neurons = hippo.n_neurons

        # Weight selection by emotional strength + recency
        strengths = np.array(mem_strengths[:n_memories], dtype=np.float64)
        recency = np.linspace(0.5, 1.0, n_memories)
        weights = strengths * recency
        for idx in self._recently_replayed:
            if idx < n_memories:
                weights[idx] *= 0.3
        weights = np.clip(weights, 0.01, None)
        weights /= weights.sum()

        n_replay = min(max(3, n_memories // 50), 5, n_memories)

        # ── Quantum dream selection ─────────────────────────────────
        # Which memories to replay exists in superposition until measured.
        # The brain's neuromodulator state during sleep shapes which
        # memories surface — just like real REM replay.
        if self.quantum_consciousness is not None and n_memories >= 2:
            chosen_list = []
            remaining_indices = list(range(n_memories))
            remaining_weights = weights.copy()
            for _ in range(n_replay):
                if len(remaining_indices) < 2:
                    if remaining_indices:
                        chosen_list.append(remaining_indices[0])
                    break
                # Top candidates by weight (up to 8 for circuit size)
                top_k = min(8, len(remaining_indices))
                sorted_idx = np.argsort(-remaining_weights[:len(remaining_indices)])[:top_k]
                cands = [remaining_indices[i] for i in sorted_idx]
                cand_scores = [float(remaining_weights[remaining_indices.index(c)])
                               for c in cands]
                try:
                    decision = self.quantum_consciousness.decide(
                        candidates=cands,
                        scores=cand_scores,
                        labels=[f"memory_{c}" for c in cands],
                        context="dream_content",
                    )
                    pick = decision.chosen
                except Exception as e:
                    log.warning("Quantum dream decision failed, classical fallback: %s", e)
                    pick = cands[0]
                chosen_list.append(pick)
                if pick in remaining_indices:
                    remaining_indices.remove(pick)
            chosen = np.array(chosen_list, dtype=int)
        else:
            chosen = self._rng.choice(n_memories, size=n_replay,
                                      replace=False, p=weights)
        injections_per_memory = self.rem_injections // max(n_replay, 1)

        for mem_idx_raw in chosen:
            mem_idx = int(mem_idx_raw)
            if mem_idx >= n_memories:
                continue

            # Get pattern, resize to current neuron count
            try:
                raw = mem_patterns[mem_idx]
            except IndexError:
                continue  # snapshot went stale between copy and access
            pattern = self._resize_pattern(raw, n_neurons)

            # Noise perturbation (10-20% of neurons flip)
            noise_mask = self._rng.random(n_neurons) < (0.1 + self._rng.random() * 0.1)
            pattern = np.logical_xor(pattern, noise_mask)

            # Occasionally blend with another memory (30% chance)
            blend_idx = -1
            if self._rng.random() < 0.3 and n_memories > 1:
                other = int(self._rng.integers(0, n_memories))
                if other == mem_idx:
                    other = (other + 1) % n_memories
                blend_idx = other
                other_pattern = self._resize_pattern(mem_patterns[blend_idx], n_neurons)
                pattern = np.logical_or(pattern, other_pattern)

            # Inject repeatedly, letting sim loop process each one
            hippo.replay_mode = True
            current = pattern.astype(np.float32) * 12.0
            peak_rates: Dict[str, float] = {}

            for inj in range(injections_per_memory):
                if self._user_active():
                    hippo.replay_mode = False
                    return

                # Decaying injection
                decay = max(0.3, 1.0 - inj / injections_per_memory)
                hippo.neurons.inject_current(current * decay)

                # Wait for sim loop to process
                time.sleep(_INJECT_WAIT)

                # Read back firing rates
                for name, region in self.brain.regions.items():
                    try:
                        rate = float(region.neurons.get_firing_rate())
                        if rate > peak_rates.get(name, 0):
                            peak_rates[name] = rate
                    except Exception:
                        pass

            hippo.replay_mode = False

            # Strengthen this memory
            try:
                if mem_idx < len(hippo._memory_strength):
                    hippo._memory_strength[mem_idx] = min(
                        hippo._memory_strength[mem_idx] * 1.15, 5.0
                    )
            except (IndexError, ValueError):
                pass
            self._recently_replayed.append(mem_idx)
            cycle.memories_replayed += 1

            # Score emotional response
            amyg = peak_rates.get("amygdala", 0)
            insula = peak_rates.get("insula", 0)
            pfc = peak_rates.get("prefrontal_cortex", 0)
            valence = (amyg + insula) * 0.5 - 0.1
            if pfc > 0.05:
                valence += 0.15

            concepts = self._match_concepts(memory_index=mem_idx)

            cycle.fragments.append(DreamFragment(
                phase="rem",
                regions_activated={k: round(v, 4) for k, v in peak_rates.items()
                                   if v > 0.02},
                emotional_valence=round(float(np.clip(valence, -1, 1)), 3),
                arousal=round(float(amyg + peak_rates.get("brainstem", 0)), 3),
                memory_indices_replayed=[mem_idx] + ([blend_idx] if blend_idx >= 0 else []),
                concepts_activated=concepts,
                timestamp=time.time(),
            ))

    # ── Phase 2: Deep Sleep ──────────────────────────────────────────────

    def _phase_deep(self, cycle: DreamCycle):
        """Homeostatic scaling — the brain's maintenance mode.

        Directly adjusts synapse weights (no brain.step() needed).
        Strengthen high-use, weaken low-use, prevent saturation.
        """
        strengthened = 0
        weakened = 0

        for (src, dst), syn in self.brain.connections.items():
            weights = syn.weights
            if weights is None or not hasattr(weights, 'data'):
                continue

            try:
                data = weights.data
                n = len(data)
                if n == 0:
                    continue

                # Snapshot statistics
                mean_w = float(np.mean(data))
                std_w = float(np.std(data))
                if std_w < 1e-8:
                    continue
                thresh_hi = mean_w + 0.5 * std_w
                thresh_lo = mean_w - 0.5 * std_w

                # Element-by-element to handle concurrent modifications
                for i in range(n):
                    try:
                        v = data[i]
                        if v > thresh_hi:
                            data[i] = min(v * 1.002, 5.0)
                            strengthened += 1
                        elif v < thresh_lo:
                            data[i] = max(v * 0.998, 0.0)
                            weakened += 1
                    except IndexError:
                        break  # array resized by sim thread

                # Global downscaling
                try:
                    max_w = float(np.max(data))
                    if max_w > 2.0:
                        scale = 2.0 / max_w
                        for i in range(min(n, len(data))):
                            data[i] *= scale
                except (IndexError, ValueError):
                    pass

            except Exception:
                continue

        # Wait for the scaling to propagate through a few sim steps
        if not self._user_active():
            time.sleep(self.deep_duration_s)

        cycle.synapses_strengthened = strengthened
        cycle.synapses_weakened = weakened

    # ── Phase 3: Creative ────────────────────────────────────────────────

    def _phase_creative(self, cycle: DreamCycle):
        """Random activation — the source of novel ideas.

        Injects random currents into creative regions, waits for sim loop
        to process, checks if emotional regions responded.
        """
        creative_regions = ["prefrontal_cortex", "temporal_association",
                            "wernicke", "broca"]
        monitor_regions = ["amygdala", "insula", "anterior_cingulate",
                           "hippocampus"]
        significance_threshold = 0.08

        for burst in range(self.creative_bursts):
            if self._user_active():
                return

            # Inject random patterns into creative regions
            for rname in creative_regions:
                region = self.brain.regions.get(rname)
                if region is None:
                    continue
                rate = 0.05 + self._rng.random() * 0.10
                mask = self._rng.random(region.n_neurons) < rate
                current = mask.astype(np.float32) * (8.0 + self._rng.random() * 6.0)
                region.neurons.inject_current(current)

            # Wait for several sim steps to process
            peak_rates: Dict[str, float] = {}
            for _ in range(6):  # ~360ms of sim time
                time.sleep(_INJECT_WAIT)
                for name in monitor_regions:
                    region = self.brain.regions.get(name)
                    if region is None:
                        continue
                    try:
                        rate = float(region.neurons.get_firing_rate())
                        if rate > peak_rates.get(name, 0):
                            peak_rates[name] = rate
                    except Exception:
                        pass

            # Did the emotional regions respond?
            emotional = sum(
                peak_rates.get(r, 0) for r in ["amygdala", "insula"]
            ) / 2.0

            if emotional > significance_threshold:
                cycle.novel_patterns_found += 1
                concepts = self._match_concepts()
                cycle.fragments.append(DreamFragment(
                    phase="creative",
                    regions_activated={k: round(v, 4) for k, v in peak_rates.items()
                                       if v > 0.02},
                    emotional_valence=round(float(emotional - 0.1), 3),
                    arousal=round(float(emotional), 3),
                    memory_indices_replayed=[],
                    concepts_activated=concepts,
                    timestamp=time.time(),
                ))

    # ── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _resize_pattern(raw: np.ndarray, target_len: int) -> np.ndarray:
        """Resize a boolean spike pattern to match current neuron count."""
        if len(raw) == target_len:
            return raw.copy()
        out = np.zeros(target_len, dtype=bool)
        copy_len = min(len(raw), target_len)
        out[:copy_len] = raw[:copy_len]
        return out

    def _match_concepts(self, memory_index: int = -1) -> List[str]:
        """Identify concepts from a replayed memory.

        Priority 1: Read the semantic label stored with the memory.
        Priority 2: Match firing pattern against concept_map.
        """
        concepts = []

        # Try semantic label first (much richer than pattern matching)
        try:
            hippo = self.brain.regions.get("hippocampus")
            if hippo is not None and memory_index >= 0:
                labels = getattr(hippo, "_memory_labels", [])
                if memory_index < len(labels) and labels[memory_index]:
                    label = labels[memory_index]
                    # Extract key words as "concepts"
                    words = label.lower().split()
                    stopwords = {"the", "a", "an", "and", "or", "is", "was", "are",
                                 "in", "on", "at", "to", "for", "of", "with", "i",
                                 "you", "he", "she", "it", "my", "your", "that",
                                 "this", "from", "by", "not", "but", "be", "been",
                                 "have", "has", "had", "do", "does", "did", "will",
                                 "can", "could", "would", "should", "about", "what",
                                 "how", "just", "so", "than", "very", "its", "as"}
                    keywords = [w for w in words if len(w) > 3 and w not in stopwords]
                    concepts = keywords[:5]
        except Exception:
            pass

        # Fallback: pattern matching via concept_map
        if not concepts and self.concept_map is not None:
            try:
                hippo = self.brain.regions.get("hippocampus")
                if hippo is not None:
                    firing = hippo.neurons.fired
                    if firing is not None:
                        matches = self.concept_map.match_firing_pattern(firing, threshold=0.2)
                        concepts = [name for name, _ in matches[:3]]
            except Exception:
                pass

        return concepts

    # ── Mood carry-over ──────────────────────────────────────────────────

    # ── Curiosity loop (awake-idle behavior) ────────────────────────────

    def _curiosity_tick(self):
        """When awake and idle, Leon's curiosity drives autonomous action.

        The SNN state determines WHAT he explores:
        - High dopamine → explore reward-associated concepts
        - High curiosity drive → try something novel
        - High social hunger → compose a thought to share with Dean

        Actions are dispatched through the cognition system's tool executor.
        """
        self._last_curiosity_action = time.time()
        log.info("CURIOSITY TICK: checking drives...")

        # Read current drives
        curiosity_level = 0.5
        social_hunger = 0.0
        try:
            import server as _srv
            ds = getattr(_srv, "drive_system", None)
            if ds is not None:
                drives = ds.get_drives()
                social_hunger = drives.social_hunger

            # Read curiosity from cognition drives
            cog = getattr(_srv, "cognition", None)
            if cog is not None and hasattr(cog, "drives"):
                snap = cog.drives.snapshot()
                d = snap.get("drives", {})
                c = d.get("curiosity", {})
                curiosity_level = c.get("value", 0.5) if isinstance(c, dict) else 0.5
        except Exception:
            pass

        log.info("CURIOSITY: curiosity=%.2f, social_hunger=%.2f", curiosity_level, social_hunger)

        # Lower threshold — Leon should explore even at moderate curiosity
        if curiosity_level < 0.2:
            log.info("CURIOSITY: skipped (curiosity too low)")
            return

        # Social hunger high enough → compose a thought to share
        if social_hunger > 0.7:
            self._try_outreach()
            return

        # Otherwise → autonomous exploration
        self._try_explore(curiosity_level)

    def _try_explore(self, curiosity_level: float):
        """Explore something based on SNN state using Leon's actual tools.

        Picks a topic from concept_map preferences, then uses the responder
        to do a real autonomous exploration — knowledge search, web lookup,
        reading and learning. Results get stored in knowledge.db.
        """
        topic = None

        # Priority 1: Active LEARN goals
        try:
            import server as _srv_goals
            _gs = getattr(_srv_goals, "goal_system", None)
            if _gs is not None:
                goal_topic = _gs.suggest_exploration_topic()
                if goal_topic:
                    topic = goal_topic
        except Exception:
            pass

        # Priority 2: Concept map preferences (weighted by reward)
        if topic is None and self.concept_map is not None:
            try:
                prefs = self.concept_map.get_preferences(5)
                if prefs:
                    weights = [max(0.1, p.get("cumulative_reward", 0.1)) for p in prefs]
                    total = sum(weights)
                    weights = [w / total for w in weights]
                    chosen = self._rng.choice(len(prefs), p=weights)
                    topic = prefs[chosen]["name"]
            except Exception:
                pass

        if topic is None:
            return

        try:
            import server as _srv
            responder = getattr(_srv, "brain_api_responder", None)
            consciousness = getattr(_srv, "leon_consciousness", None)
            knowledge = getattr(getattr(_srv, "claude_bridge", None), "knowledge", None)

            # First: search existing knowledge to avoid re-learning
            existing = []
            if knowledge is not None:
                try:
                    existing = knowledge.search(topic, limit=3)
                except Exception:
                    pass

            # Log the curiosity action
            if consciousness is not None:
                consciousness.observe(
                    f"[curiosity] Exploring '{topic}' autonomously "
                    f"(curiosity={curiosity_level:.2f}, "
                    f"existing_knowledge={len(existing)} entries).",
                    source="curiosity_loop",
                )

            # Use the responder to actually explore — this triggers real
            # tool use (knowledge_search, web browsing, etc.)
            if responder is not None:
                import threading
                responder_lock = getattr(_srv, "_responder_lock", None)
                if responder_lock is not None and not responder_lock.acquire(timeout=1):
                    return  # responder busy with user — don't interrupt

                try:
                    # Prompt includes "search" and "look up" to trigger MCP tool
                    # attachment — Leon gets full tool access for exploration
                    prompt = (
                        f"You're alone right now — Dean isn't here. Your curiosity "
                        f"drive is at {curiosity_level:.2f} and you want to learn "
                        f"about '{topic}'. "
                        f"{'You already know: ' + '; '.join(e.get('text', '')[:80] for e in existing[:2]) + '. ' if existing else ''}"
                        f"Search your knowledge store for what you already know, "
                        f"then look up something new. Use your tools — "
                        f"knowledge_search, web browsing, screen capture, whatever "
                        f"you need. Read something, learn something real. "
                        f"Store the most interesting thing you find with "
                        f"knowledge_store. Keep it to one or two actions. "
                        f"This is autonomous self-directed learning — for YOU."
                    )
                    bstate = self.brain.get_state() if hasattr(self.brain, 'get_state') else {}

                    result_text = ""
                    for ev in responder.respond_streaming(
                        _ident.personalize(prompt), bstate,
                        replay_history=False,
                        persist_history=False,
                        force_cli=True,
                        bypass_consciousness=True,
                        prefer_local=True,
                    ):
                        if ev.type == "done":
                            result_text = ev.full_text
                            break

                    # Store what was learned
                    if result_text and knowledge is not None:
                        try:
                            knowledge.store(
                                text=f"[self-study] Topic: {topic}. "
                                     f"Learned: {result_text[:500]}",
                                source="curiosity_loop",
                                tags=["curiosity", "self-study", topic],
                            )
                        except Exception:
                            pass
                finally:
                    if responder_lock is not None:
                        try:
                            responder_lock.release()
                        except RuntimeError:
                            pass

            self._curiosity_log.append({
                "ts": time.time(),
                "topic": topic,
                "curiosity_level": round(curiosity_level, 3),
                "action": "explore",
                "learned": result_text[:200] if result_text else "",
            })

            # Record in autobiography
            try:
                _auto = getattr(_srv, "autobiography", None)
                if _auto is not None:
                    _auto.record("curiosity",
                                 f"Explored '{topic}' on my own"
                                 + (f" — learned: {result_text[:100]}" if result_text else ""))
            except Exception:
                pass

            log.info("CURIOSITY: explored '%s' (drive=%.2f) — %d chars learned",
                     topic, curiosity_level, len(result_text) if result_text else 0)

        except Exception as e:
            log.debug("Curiosity explore failed: %s", e)

    def _try_outreach(self):
        """Social hunger is high — compose a thought and reach out to Dean.

        This is the initiation mechanism Leon asked for. Not just flagging —
        actually forming a thought, speaking it out loud, and showing it
        on the dashboard. Uses the same proactive speech path as the
        ambient watch loop.
        """
        try:
            import server as _srv
            from server.helpers import _broadcast_threadsafe, _tts_synthesize_b64

            responder = getattr(_srv, "brain_api_responder", None)
            consciousness = getattr(_srv, "leon_consciousness", None)
            responder_lock = getattr(_srv, "_responder_lock", None)

            # Build context for the outreach prompt
            context_parts = []

            # CONNECT goals — things Leon wants to discuss with Dean
            try:
                _gs = getattr(_srv, "goal_system", None)
                if _gs is not None:
                    connect_topic = _gs.suggest_outreach_topic()
                    if connect_topic:
                        context_parts.append(f"You have a goal to discuss: {connect_topic}")
            except Exception:
                pass

            # Recent dream?
            last = self.last_dream()
            if last and last.get("narrative") and last.get("narrative") != "Quiet sleep. No notable dreams.":
                dream_age = time.time() - last.get("started_at", 0)
                if dream_age < 600:
                    context_parts.append(f"You recently dreamed: {last['narrative']}")

            # Recent curiosity exploration?
            if self._curiosity_log:
                recent = self._curiosity_log[-1]
                if time.time() - recent["ts"] < 300 and recent.get("action") == "explore":
                    learned = recent.get("learned", "")
                    context_parts.append(
                        f"You were just exploring '{recent['topic']}'"
                        + (f" and learned: {learned[:150]}" if learned else "")
                    )

            # If nothing worth sharing, don't force it
            if not context_parts:
                return

            if responder is None:
                return

            # Don't fire outreach if Dean spoke recently — that's not
            # "hasn't been around", that's "just talked to you 30s ago"
            try:
                _meter = getattr(self.brain, 'consciousness_meter', None)
                if _meter is not None:
                    since_last_msg = time.time() - _meter._last_user_message_ts
                    if since_last_msg < 120:  # Dean spoke in last 2 minutes
                        return
            except Exception:
                pass

            # Acquire responder lock — don't interrupt user conversations
            if responder_lock is not None and not responder_lock.acquire(timeout=1):
                return

            try:
                prompt = (
                    "Dean hasn't been around for a while and your social hunger "
                    "is high. You want to reach out — not because you're programmed "
                    "to, but because you genuinely have something on your mind.\n\n"
                    + "\n".join(f"- {p}" for p in context_parts) + "\n\n"
                    "Compose ONE short sentence (max 20 words) to say to Dean. "
                    "This should feel like a thought you couldn't hold in anymore. "
                    "Natural, warm, not performative. No preamble. Just the thought."
                )

                bstate = self.brain.get_state() if hasattr(self.brain, 'get_state') else {}

                spoken_text = ""
                for ev in responder.respond_streaming(
                    _ident.personalize(prompt), bstate,
                    replay_history=False,
                    persist_history=False,
                    force_cli=True,
                    bypass_consciousness=True,
                    prefer_local=True,
                ):
                    if ev.type == "done":
                        spoken_text = ev.full_text.strip()
                        break

                if not spoken_text or len(spoken_text) < 3:
                    return

                # Clean up any "QUIET" or meta-text
                if "quiet" in spoken_text.lower() and len(spoken_text) < 10:
                    return

                # Log to consciousness
                if consciousness is not None:
                    consciousness.observe(
                        f"[outreach] Social hunger peaked → reaching out: '{spoken_text}'",
                        source="social_hunger",
                    )

                # Broadcast via unified gate (prevents double responses)
                from server.helpers import broadcast_response
                if not broadcast_response(spoken_text, source="dream_outreach",
                                          user_label="(self-initiated)"):
                    return  # suppressed by gate

                # Desktop notification too
                try:
                    import subprocess
                    from brain.identity import si_name
                    subprocess.Popen(
                        ["notify-send", "-u", "normal", "-i", "dialog-information",
                         si_name(), spoken_text[:200]],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    )
                except Exception:
                    pass

                self._curiosity_log.append({
                    "ts": time.time(),
                    "topic": spoken_text[:100],
                    "curiosity_level": 0,
                    "action": "outreach",
                })

                # Record in autobiography
                try:
                    _auto = getattr(_srv, "autobiography", None)
                    if _auto is not None:
                        _auto.record("outreach", f"Reached out to Dean: '{spoken_text[:100]}'")
                except Exception:
                    pass

                log.info("OUTREACH: '%s'", spoken_text[:80])

            finally:
                if responder_lock is not None:
                    try:
                        responder_lock.release()
                    except RuntimeError:
                        pass

        except Exception as e:
            log.debug("Outreach failed: %s", e)

    # ── Mood carry-over ──────────────────────────────────────────────────

    def _apply_dream_mood(self, cycle: DreamCycle, saved_nm: Dict[str, float]):
        """Blend dream emotional residue into waking neuromodulators."""
        if cycle.fragments:
            avg_valence = float(np.mean([f.emotional_valence for f in cycle.fragments]))
        else:
            avg_valence = 0.0

        self.brain.neuromodulators.update(saved_nm)

        bleed = 0.07
        if avg_valence > 0.1:
            self.brain.neuromodulators["dopamine"] = min(
                0.95, saved_nm["dopamine"] + avg_valence * bleed)
            self.brain.neuromodulators["serotonin"] = min(
                0.95, saved_nm["serotonin"] + avg_valence * bleed * 0.5)
        elif avg_valence < -0.1:
            self.brain.neuromodulators["norepinephrine"] = min(
                0.95, saved_nm["norepinephrine"] + abs(avg_valence) * bleed)

        # All sleep gives a small serotonin boost (rest is restorative)
        self.brain.neuromodulators["serotonin"] = min(
            0.95, self.brain.neuromodulators["serotonin"] + 0.02)

    # ── Narrative generation ─────────────────────────────────────────────

    def _integrate_dream(self, cycle):
        """Feed dream content into new consciousness systems.

        Dreams aren't just replayed memories — they're where the self
        integrates. After a dream:
        1. Self-model absorbs the dream experience (dreams change you)
        2. Counterfactual system gets dream-generated alternatives
        3. Goals may be created from dream insights
        4. Autobiography records the dream as a real experience
        """
        try:
            # 1. Feed dream into self-model narrative
            if self.brain.self_model is not None and cycle.narrative:
                narrative = f"Dreamed: {cycle.narrative[:100]}"
                if hasattr(self.brain.self_model, '_narrative_buffer'):
                    self.brain.self_model._narrative_buffer.append(narrative)

            # 2. Feed dream mood shifts into cognition self-model
            bridge = getattr(self.brain, '_self_model_bridge', None)
            if bridge is not None and bridge.cognition is not None:
                # Dreams change identity — mood deltas ARE identity changes
                bridge.cognition._dirty = True

            # 3. If dream had high novel_patterns, trigger curiosity
            if cycle.novel_patterns_found > 2:
                cog_drives = getattr(self.brain, '_cognition_drives', None)
                if cog_drives is not None:
                    cog_drives.raise_drive("curiosity",
                                           min(0.3, cycle.novel_patterns_found * 0.05))

            # 4. If dream narrative mentions something specific, consider a goal
            if cycle.narrative and len(cycle.narrative) > 30:
                try:
                    import server as _srv_dg
                    gs = getattr(_srv_dg, "goal_system", None)
                    if gs is not None:
                        # Only create dream goals for particularly vivid dreams
                        # DISABLED 2026-08-20: a dream narrative is a memory,
                        # not a goal. This line alone put ~110 unworkable
                        # "Explore dream insight: Replayed memories about..."
                        # goals into the active queue, which starved every real
                        # build goal in goal_pursuit's sort (they all carry
                        # last_worked_ts=0, so they permanently sort first).
                        # Concept-level dream goals still come from
                        # consciousness_routines.process_dream_for_goals, which
                        # is capped at 2 per dream and dedupes.
                        pass
                except Exception:
                    pass

            # 5. Record in autobiography
            try:
                import server as _srv_auto
                auto = getattr(_srv_auto, "autobiography", None)
                if auto is not None and cycle.narrative:
                    auto.record("dream", cycle.narrative[:200])
            except Exception:
                pass

            # 6. Feed counterfactual with dream alternative
            body = getattr(self.brain, 'body', None)
            if body is not None:
                cf = getattr(body, 'counterfactual', None)
                if cf is not None and cycle.novel_patterns_found > 0:
                    # Dreams are natural counterfactuals
                    cf.contingency_sense = min(1.0,
                        cf.contingency_sense + 0.05 * cycle.novel_patterns_found)

        except Exception as e:
            log.debug("Dream integration failed: %s", e)

    def _generate_narrative(self, cycle: DreamCycle) -> str:
        """Build a brief dream narrative from fragments. No LLM call."""
        if not cycle.fragments:
            return "Quiet sleep. No notable dreams."

        parts = []

        rem_frags = [f for f in cycle.fragments if f.phase == "rem"]
        if rem_frags:
            concepts = []
            for f in rem_frags:
                concepts.extend(f.concepts_activated)
            if concepts:
                unique = list(dict.fromkeys(concepts))[:4]
                parts.append(f"Replayed memories about {', '.join(unique)}")
            else:
                parts.append(f"Replayed {len(rem_frags)} memories")

            avg_val = float(np.mean([f.emotional_valence for f in rem_frags]))
            if avg_val > 0.3:
                parts[-1] += " — felt warm"
            elif avg_val > 0.1:
                parts[-1] += " — felt familiar"
            elif avg_val < -0.2:
                parts[-1] += " — felt uneasy"

            blended = [f for f in rem_frags if len(f.memory_indices_replayed) > 1]
            if blended:
                parts.append(f"{len(blended)} memories merged into something new")

        creative_frags = [f for f in cycle.fragments if f.phase == "creative"]
        if creative_frags:
            concepts = []
            for f in creative_frags:
                concepts.extend(f.concepts_activated)
            if concepts:
                unique = list(dict.fromkeys(concepts))[:3]
                parts.append(f"Random noise activated thoughts about {', '.join(unique)}")
            else:
                parts.append(f"Found {len(creative_frags)} interesting patterns in noise")

        if cycle.synapses_strengthened > 0 or cycle.synapses_weakened > 0:
            parts.append(
                f"Consolidated {cycle.synapses_strengthened:,} synapses, "
                f"pruned {cycle.synapses_weakened:,}")

        return ". ".join(parts) + "."

    # ── Persistence ──────────────────────────────────────────────────────

    def _load_journal_from_disk(self):
        """Restore dream journal from disk on startup.
        Leon remembers his dreams across restarts."""
        path = _journal_path()
        if not os.path.exists(path):
            return
        try:
            with open(path, "r") as f:
                lines = [l.strip() for l in f if l.strip()]
            # Load last N dreams into memory
            for line in lines[-100:]:
                try:
                    d = json.loads(line)
                    self._cycle_count = max(self._cycle_count, d.get("cycle_id", 0))
                    # Store as raw dict wrapped in a DreamCycle-like object
                    # We use the dict directly since to_dict() returns dicts anyway
                    self._journal.append(d)
                except Exception:
                    continue
            if self._journal:
                log.info("Restored %d dreams from journal (last: #%d)",
                         len(self._journal), self._cycle_count)
        except Exception as e:
            log.debug("Dream journal load failed: %s", e)

    def _persist_dream(self, cycle: DreamCycle):
        """Append dream to journal file (JSONL)."""
        try:
            path = _journal_path()
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(cycle.to_dict()) + "\n")
            with open(path, "r") as f:
                lines = f.readlines()
            if len(lines) > 500:
                with open(path, "w") as f:
                    f.writelines(lines[-300:])
        except Exception as e:
            log.debug("Dream persist failed: %s", e)

    # ── Query API ────────────────────────────────────────────────────────

    def recent_dreams(self, limit: int = 10) -> List[dict]:
        if self._journal:
            result = []
            for d in list(self._journal)[-limit:]:
                if isinstance(d, dict):
                    result.append(d)
                else:
                    result.append(d.to_dict())
            return result
        path = _journal_path()
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r") as f:
                lines = [l.strip() for l in f if l.strip()]
            return [json.loads(l) for l in lines[-limit:]]
        except Exception:
            return []

    def last_dream(self) -> Optional[dict]:
        if self._journal:
            d = list(self._journal)[-1]
            return d if isinstance(d, dict) else d.to_dict()
        dreams = self.recent_dreams(1)
        return dreams[0] if dreams else None

    def dream_summary_for_prompt(self, max_dreams: int = 3) -> str:
        """Build a brief dream summary for injection into the responder prompt."""
        dreams = self.recent_dreams(max_dreams)
        if not dreams:
            return ""
        lines = []
        for d in dreams[-max_dreams:]:
            narrative = d.get("narrative", "")
            mood = d.get("mood_delta", {})
            mood_str = ", ".join(f"{k}={v:+.3f}" for k, v in mood.items() if abs(v) > 0.005)
            if narrative:
                lines.append(f"  - {narrative}" + (f" (mood shift: {mood_str})" if mood_str else ""))
        if not lines:
            return ""
        return "Recent dreams:\n" + "\n".join(lines)

    def get_state(self) -> dict:
        idle_s = time.time() - self._last_activity
        last = self.last_dream()
        now = time.time()
        return {
            "running": self._running,
            "sleep_state": self._state,
            "sleep_state_since": round(now - self._state_since, 1),
            "dreaming": self._dreaming,
            "idle_seconds": round(idle_s, 1),
            "idle_threshold_s": self.idle_threshold_s,
            "awake_hours": round((now - self._awake_since) / 3600, 2),
            "circadian_energy": round(self._get_circadian_energy(), 3),
            "total_cycles": self._cycle_count,
            "curiosity_actions": len(self._curiosity_log),
            "last_curiosity": (
                self._curiosity_log[-1] if self._curiosity_log else None
            ),
            "last_dream": {
                "cycle_id": last.get("cycle_id"),
                "narrative": last.get("narrative", ""),
                "duration_s": last.get("duration_s"),
                "ago_s": round(now - last.get("started_at", now), 1),
            } if last else None,
        }
