"""Persistent Kokoro synthesis worker.

Runs inside the isolated kokoro venv (kokoro-onnx pins its own onnxruntime,
which is why it can't share the main venv with piper-tts). Loading the model
costs ~2.4s, so a fresh subprocess per utterance — what the original VPS
implementation did — put that on every single sentence Leon speaks. This
loads once and stays resident.

Protocol: one JSON request per line on stdin, one JSON reply per line on
stdout. Anything the library prints goes to stderr so stdout stays parseable.

  in : {"text": "...", "voice": "bm_daniel", "speed": 1.05, "lang": "en-gb"}
  out: {"ok": true, "path": "/tmp/kokoro_ab12.wav", "sr": 24000}
       {"ok": false, "error": "..."}
"""

import json
import os
import sys
import tempfile


def main() -> None:
    model = sys.argv[1]
    voices = sys.argv[2]

    # Kokoro/phonemizer chatter on stdout would corrupt the protocol —
    # including C-level writes (onnxruntime, espeak-ng) that bypass
    # sys.stdout entirely. Keep a private dup of the real fd for the
    # protocol, then point fd 1 at stderr so native code can't touch it.
    real_stdout = os.fdopen(os.dup(1), "w")
    os.dup2(2, 1)
    sys.stdout = sys.stderr

    import soundfile as sf
    from kokoro_onnx import Kokoro

    kokoro = Kokoro(model, voices)
    print(json.dumps({"ok": True, "ready": True}), file=real_stdout, flush=True)

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            samples, sr = kokoro.create(
                req["text"],
                voice=req.get("voice", "bm_daniel"),
                speed=float(req.get("speed", 1.0)),
                lang=req.get("lang", "en-us"),
            )
            fd, out = tempfile.mkstemp(suffix=".wav", prefix="kokoro_")
            os.close(fd)
            sf.write(out, samples, sr)
            reply = {"ok": True, "path": out, "sr": int(sr)}
        except Exception as e:
            reply = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        print(json.dumps(reply), file=real_stdout, flush=True)


if __name__ == "__main__":
    main()
