"""Streaming filler audio — Leon's instant "got it / one sec" the moment
Dean finishes speaking, before the real response starts arriving.

Why: voice latency = STT (~0.5s) + responder cold-path (~1-3s) + first
sentence TTS (~0.3s). Dean perceives all of that as dead silence. A
sub-100ms filler completely changes the feel.

How: pre-synthesize a small library of context-appropriate fillers on
first use and cache as WAV bytes in memory. On utterance receipt, pick
one based on a cheap text heuristic and emit it instantly as the
"sentence_index=-1" audio event (renders ahead of the real response).

The filler isn't part of the response transcript — it's purely audio.
The dashboard audio queue plays it first because sentence_index=-1 sorts
before 0.

Public API:
  - prewarm(tts)         — synthesize all fillers into the cache. Call once at boot.
  - get_filler(text)     — returns (b64_wav, sample_rate, mime, text) for a user utterance, or None.
  - reset_cache()        — drop cached audio (e.g. on voice change).
"""

from __future__ import annotations

import base64
import io
import random
import re
import wave
from typing import Any, Dict, Optional, Tuple


# Filler bank — each phrase is one short utterance Leon speaks while thinking.
# Categories let us pick context-appropriate ones (questions get different
# fillers than commands).
# A filler must never PROMISE work ("Let me check." / "One sec." /
# "Thinking.") — if the engine then dies, the owner hears a promise and
# then silence. Neutral acknowledgements only (customer report, 2026-08-29).
_FILLERS: Dict[str, list] = {
    "question":   ["Okay.", "One moment.", "Looking.", "Hmm.", "Checking."],
    "command":    ["On it.", "Got it.", "Doing that now.", "Right away.", "Will do."],
    # "Sir" here is Dean's own choice for his own install (leon_persona.py).
    # It is rewritten per-install by _personalized_fillers() below so a
    # client SI never guesses its owner's gender.
    "greeting":   ["Hey Sir.", "Hi Sir.", "Yes Sir.", "Right here."],
    "thinking":   ["Hmm.", "One moment.", "Okay.", "Working on it.", "Stand by."],
    "ack":        ["Mhm.", "Yeah.", "Okay.", "Got it.", "Sure thing."],
}

# In-memory cache: text → (wav_bytes, sample_rate)
_CACHE: Dict[str, Tuple[bytes, int]] = {}

_PERSONALIZED_FILLERS: Optional[Dict[str, list]] = None


def _personalized_fillers() -> Dict[str, list]:
    """_FILLERS rewritten for this install (drops "Sir" for a client SI).

    Computed once and cached — is_client_si()/personalize() are stable for
    the life of the process, and prewarm() and get_filler() both need the
    SAME text for a phrase so the cache key lines up between them.
    """
    global _PERSONALIZED_FILLERS
    if _PERSONALIZED_FILLERS is None:
        from brain.identity import personalize
        _PERSONALIZED_FILLERS = {
            cat: [personalize(p) for p in phrases]
            for cat, phrases in _FILLERS.items()
        }
    return _PERSONALIZED_FILLERS


def _classify(text: str) -> str:
    """Heuristic: which filler category fits this user utterance?"""
    t = (text or "").strip().lower()
    if not t:
        return "thinking"
    # Greetings
    if re.search(r"\b(hi|hey|hello|hey leon|leon|sir|good (morning|evening|afternoon))\b", t):
        if len(t.split()) <= 4:
            return "greeting"
    # Questions
    if t.endswith("?") or re.match(r"^(what|who|where|when|why|how|is|are|do|does|can|could|will|would|should|did)\b", t):
        return "question"
    # Commands / requests
    if re.match(r"^(open|close|click|launch|run|kill|stop|start|play|pause|set|create|make|send|email|text|call|find|search|delete|save|write|read|tell|show|give|fetch|get|update|fix|build|install|remove|add)\b", t):
        return "command"
    # Default
    return "ack" if len(t.split()) <= 5 else "thinking"


def get_filler(text: str) -> Optional[Dict[str, Any]]:
    """Return a filler audio packet matched to the user's utterance, or None
    if no filler is cached. Output shape matches the rest of the audio
    pipeline so the dashboard can render it directly:

        {"audio_b64": "...", "sample_rate": 22050, "mime": "audio/wav",
         "filler_text": "Got it."}

    Cache miss returns None — caller continues without a filler.
    """
    category = _classify(text)
    fillers = _personalized_fillers()
    candidates = fillers.get(category, fillers["thinking"])
    # Try a random one; if its WAV isn't cached, walk siblings.
    random.shuffle(candidates)
    for phrase in candidates:
        if phrase in _CACHE:
            wav_bytes, sr = _CACHE[phrase]
            return {
                "audio_b64": base64.b64encode(wav_bytes).decode("ascii"),
                "sample_rate": sr,
                "mime": "audio/wav",
                "filler_text": phrase,
                "filler_category": category,
            }
    # Try ANY cached phrase as last resort
    for phrase, (wav_bytes, sr) in _CACHE.items():
        return {
            "audio_b64": base64.b64encode(wav_bytes).decode("ascii"),
            "sample_rate": sr,
            "mime": "audio/wav",
            "filler_text": phrase,
            "filler_category": "fallback",
        }
    return None


def reset_cache() -> None:
    _CACHE.clear()


def prewarm(tts) -> Dict[str, Any]:
    """Synthesize every phrase once and cache the result.

    `tts` must have a `.speak(text) -> TTSResult` method where TTSResult
    has `.wav_bytes` and `.sample_rate`.

    Returns {"ok": True, "cached": N, "failed": [phrases…]}.
    """
    failed = []
    cached = 0
    fillers = _personalized_fillers()
    for category, phrases in fillers.items():
        for phrase in phrases:
            if phrase in _CACHE:
                continue
            try:
                result = tts.speak(phrase)
                if not result or not getattr(result, "wav_bytes", None):
                    failed.append(phrase)
                    continue
                _CACHE[phrase] = (result.wav_bytes, result.sample_rate)
                cached += 1
            except Exception as e:
                failed.append(f"{phrase}: {type(e).__name__}")
    return {"ok": True, "cached": cached, "failed": failed, "total_phrases": sum(len(v) for v in fillers.values())}


def cached_phrases() -> list:
    """List phrases currently in the cache."""
    return list(_CACHE.keys())
