"""Scale PCM16 samples without corrupting the WAV container header."""
import array
import io
import math
import struct
import sys
import wave


def apply_wav_gain(data: bytes, gain: float) -> bytes:
    if not math.isfinite(gain) or gain == 1.0:
        return data
    gain = max(0.0, min(4.0, gain))
    try:
        with wave.open(io.BytesIO(data), "rb") as source:
            params = source.getparams()
            if params.sampwidth != 2 or params.comptype != "NONE":
                return data
            frames = source.readframes(params.nframes)
        samples = array.array("h")
        samples.frombytes(frames)
        if sys.byteorder != "little":
            samples.byteswap()
        samples = array.array("h", (max(-32768, min(32767, round(x * gain))) for x in samples))
        if sys.byteorder != "little":
            samples.byteswap()
        output = io.BytesIO()
        with wave.open(output, "wb") as target:
            # ffmpeg writing WAV to a pipe stamps 0xFFFFFFFF placeholder
            # sizes; trusting params.nframes then overflows the output
            # header. Count frames from the data actually read instead.
            target.setparams(params)
            target.setnframes(len(frames) // (params.sampwidth * params.nchannels))
            target.writeframes(samples.tobytes())
        return output.getvalue()
    except (wave.Error, EOFError, ValueError, struct.error):
        return data
