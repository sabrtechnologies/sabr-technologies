"""One bounded speech worker; model/tool streams never wait for synthesis."""
from collections import deque
import logging
import threading
import time

log = logging.getLogger(__name__)


class SpeechTurn:
    def __init__(self, dispatcher, response_id, send):
        self.dispatcher = dispatcher
        self.response_id = response_id
        self.send = send
        self.cancelled = threading.Event()
        self.had_audio = False

    def submit(self, text, index):
        return self.dispatcher.enqueue(self, (text, index))

    def finish(self):
        if not getattr(self, "_finished", False):
            self._finished = True
            self.dispatcher.enqueue(self, None)


class SpeechDispatcher:
    def __init__(self, synthesize, capacity=32):
        self.synthesize = synthesize
        self.capacity = capacity
        self.pending = deque()
        self.condition = threading.Condition()
        self.current = None
        self.closed = False
        self.worker = threading.Thread(target=self._run, daemon=True, name="response-speech")
        self.worker.start()

    def begin(self, response_id, send):
        with self.condition:
            self.cancel()
            self.current = SpeechTurn(self, response_id, send)
            return self.current

    def cancel(self):
        with self.condition:
            if self.current:
                self.current.cancelled.set()
            self.pending.clear()
            self.condition.notify_all()

    def enqueue(self, turn, item):
        with self.condition:
            if self.closed or turn.cancelled.is_set():
                return False
            # Completion is always allowed so a full queue cannot leave
            # the UI permanently waiting for audio. Text remains complete.
            if item is not None and len(self.pending) >= self.capacity:
                log.warning("speech queue full for %s; retaining text output", turn.response_id)
                return False
            self.pending.append((turn, item))
            self.condition.notify()
            return True

    def close(self):
        with self.condition:
            self.closed = True
            self.cancel()
        self.worker.join(timeout=1)

    def _run(self):
        while True:
            with self.condition:
                self.condition.wait_for(lambda: self.pending or self.closed)
                if self.closed:
                    return
                turn, item = self.pending.popleft()
            if turn.cancelled.is_set():
                continue
            try:
                if item is None:
                    turn.send({"type": "brain_audio_complete", "response_id": turn.response_id,
                               "had_audio": turn.had_audio})
                    continue
                text, index = item
                started = time.monotonic()
                audio = self.synthesize(text, cancelled=turn.cancelled.is_set)
                if audio and not turn.cancelled.is_set():
                    turn.had_audio = True
                    turn.send({"type": "brain_audio", "response_id": turn.response_id,
                               "sentence_index": index, **audio})
                    log.info("speech %s sentence=%s ready_ms=%.0f", turn.response_id,
                             index, (time.monotonic() - started) * 1000)
            except Exception:
                log.exception("speech failed for %s; text stream continues", turn.response_id)


_dispatcher = None
_lock = threading.Lock()


def start_response(synthesize, response_id, send):
    global _dispatcher
    with _lock:
        if _dispatcher is None:
            _dispatcher = SpeechDispatcher(synthesize)
        return _dispatcher.begin(response_id, send)


def cancel_response():
    with _lock:
        if _dispatcher is not None:
            _dispatcher.cancel()
