"""One bounded speech worker; model/tool streams never wait for synthesis."""
from collections import deque
import json
import logging
import math
import tempfile
import threading
import time
import uuid

log = logging.getLogger(__name__)


class SpeechBusy(RuntimeError):
    """A lower-priority utterance cannot replace an active foreground turn."""


class _SpeechBacklog:
    """Private, temporary FIFO for text that outpaces synthesis.

    All access is under the dispatcher's condition. Audio stays bounded to
    one synthesized chunk; overflow text never waits for that synthesis.
    """

    def __init__(self):
        self.file = tempfile.TemporaryFile(mode="w+b")
        self.read_at = 0
        self.count = 0

    def append(self, item):
        data = (json.dumps(item, ensure_ascii=True) + "\n").encode("ascii")
        self.file.seek(0, 2)
        start = self.file.tell()
        try:
            self.file.write(data)
            self.file.flush()
        except Exception:
            self.file.seek(start)
            self.file.truncate()
            raise
        self.count += 1

    def pop(self):
        self.file.seek(self.read_at)
        item = json.loads(self.file.readline())
        self.read_at = self.file.tell()
        self.count -= 1
        return item

    def close(self):
        self.file.close()


class SpeechTurn:
    def __init__(self, dispatcher, response_id, send, priority=100, synthesize=None,
                 *, arbitration=False, generation=0, stop_audio=None):
        self.dispatcher = dispatcher
        self.response_id = response_id
        self.send = send
        self.cancelled = threading.Event()
        self.had_audio = False
        self.priority = int(priority)
        self.synthesize = synthesize or dispatcher.synthesize
        self.completed = threading.Event()
        self._finished = False
        self.arbitration = arbitration
        self.generation = generation
        self.stop_audio = stop_audio
        self._interrupt = None
        self._cancel_notified = False
        self.playback_until = 0.0
        self._backlog = None
        self.failed_chunks = 0

    def event(self, payload):
        if self.arbitration:
            return {**payload, "speech_session": _session,
                    "speech_generation": self.generation}
        return payload

    def bind_interrupt(self, callback):
        """Bind this turn's inference handle, never a task worker/global abort."""
        if not callable(callback):
            raise TypeError("speech interruption callback must be callable")
        with self.dispatcher.condition:
            if self._interrupt is not None:
                raise RuntimeError("speech turn already has an interruption owner")
            self._interrupt = callback
            cancelled = self.cancelled.is_set()
        if cancelled and self.arbitration:
            callback()

    def submit(self, text, index):
        return self.dispatcher.enqueue(self, (text, index))

    def finish(self):
        with _admission_lock, self.dispatcher.condition:
            if self._finished:
                return
            self._finished = True
            self.dispatcher.enqueue(self, None)

    def cancel(self):
        return self.dispatcher.cancel(self.response_id, owner=self)


class SpeechDispatcher:
    def __init__(self, synthesize, capacity=32):
        self.synthesize = synthesize
        if not isinstance(capacity, int) or isinstance(capacity, bool) or capacity < 1:
            raise ValueError("speech capacity must be a positive integer")
        self.capacity = capacity
        self.pending = deque()
        self.condition = threading.Condition()
        # Serialize sink-stop effects with ownership replacement. Synthesis and
        # enqueue never hold this fence; there is still one synthesis worker.
        self.transition = _ownership_transition
        self.current = None
        self.closed = False
        self.dropped = 0
        self.cancelled = 0
        self.errors = 0
        self.worker = threading.Thread(target=self._run, daemon=True, name="response-speech")
        self.worker.start()

    def begin(self, response_id, send, *, priority=100, synthesize=None,
              arbitration=False, stop_audio=None):
        with _admission_lock:
            if _admissions_frozen.is_set():
                raise RuntimeError("speech owner is retiring")
        with self.transition:
            with self.condition:
                if self.closed:
                    raise RuntimeError("speech worker is closed")
                current = self.current
                active = current is not None and (not current.completed.is_set() or (
                    current.arbitration and not current.cancelled.is_set()
                    and time.monotonic() < current.playback_until))
                if active and priority < current.priority:
                    raise SpeechBusy("foreground speech is still active")
            self.cancel(reason="superseded")
            with _admission_lock, self.condition:
                if _admissions_frozen.is_set():
                    raise RuntimeError("speech owner is retiring")
                turn = SpeechTurn(self, response_id, send, priority, synthesize,
                                  arbitration=arbitration, generation=_next_generation(),
                                  stop_audio=stop_audio)
                self.current = turn
            if turn.arbitration:
                self._send(turn, {"type": "brain_audio_owner", "response_id": response_id})
            return turn

    def cancel(self, response_id=None, *, owner=None, reason="cancelled"):
        with self.transition:
            with self.condition:
                if owner is not None and self.current is not owner:
                    return False
                if response_id is not None and (self.current is None or self.current.response_id != response_id):
                    return False
                turn = self.current
                if turn:
                    if not turn.cancelled.is_set():
                        self.cancelled += 1
                    turn.cancelled.set()
                    turn.completed.set()
                    if turn._backlog is not None:
                        turn._backlog.close()
                        turn._backlog = None
                self.pending.clear()
                self.condition.notify_all()
                notify = turn is not None and turn.arbitration and not turn._cancel_notified
                if notify:
                    turn._cancel_notified = True
                    callback = turn._interrupt
            if notify:
                # No condition/global inference lock across callbacks. The
                # transition fence prevents a delayed global sink stop from
                # stopping a successor admitted by this speech owner.
                if callback is not None:
                    try:
                        callback()
                    except Exception:
                        self.errors += 1
                payload = turn.event({"type": "brain_audio_cancel", "response_id": turn.response_id,
                                      "reason": reason})
                self._send(turn, payload)
                if turn.stop_audio is not None:
                    try:
                        turn.stop_audio(payload)
                    except Exception:
                        self.errors += 1
                        log.warning("speech sink stop failed; cancellation frame still emitted")
            return True

    def _send(self, turn, payload):
        if _admissions_frozen.is_set() and payload.get("type") != "brain_audio_cancel":
            return
        try:
            turn.send(turn.event(payload))
        except Exception:
            self.errors += 1
            if payload.get("type") == "brain_audio":
                turn.failed_chunks += 1
            log.warning("speech delivery failed for response %s", turn.response_id)

    def enqueue(self, turn, item):
        with _admission_lock, self.condition:
            if _admissions_frozen.is_set() or self.closed or turn.cancelled.is_set():
                return False
            if item is not None and turn._finished:
                return False
            # Never discard the tail of a reply when tokens outrun Piper.
            # Once overflow starts, append behind it until it drains, even
            # when there is space in the in-memory prefix again.
            if item is not None and (turn._backlog is not None or len(self.pending) >= self.capacity):
                try:
                    if turn._backlog is None:
                        turn._backlog = _SpeechBacklog()
                        self.pending.append((turn, turn._backlog))
                    turn._backlog.append(item)
                except Exception:
                    self.errors += 1
                    self.dropped += 1
                    turn.failed_chunks += 1
                    log.exception("speech backlog write failed for %s", turn.response_id)
                    return False
            else:
                # Completion sits AFTER the backlog, and finish is idempotent.
                self.pending.append((turn, item))
            self.condition.notify()
            return True

    def close(self, timeout=1):
        with self.transition:
            with self.condition:
                self.closed = True
            self.cancel(reason="shutdown")
        if threading.current_thread() is not self.worker:
            self.worker.join(timeout=timeout)
        return not self.worker.is_alive()

    def stats(self):
        with self.condition:
            return {"alive": self.worker.is_alive(), "closed": self.closed,
                    "queued": len(self.pending), "capacity": self.capacity,
                    "dropped": self.dropped, "cancelled": self.cancelled,
                    "errors": self.errors,
                    "spooled": self.current._backlog.count if self.current and self.current._backlog else 0,
                    "active_response_id": self.current.response_id if self.current else None}

    def _run(self):
        while True:
            with self.condition:
                self.condition.wait_for(lambda: self.pending or self.closed)
                if self.closed:
                    return
                turn, item = self.pending[0]
                if isinstance(item, _SpeechBacklog):
                    backlog = item
                    try:
                        item = backlog.pop() if backlog.count else None
                    except Exception:
                        self.errors += 1
                        turn.failed_chunks += backlog.count
                        self.dropped += backlog.count
                        backlog.count = 0
                        item = None
                        log.exception("speech backlog read failed for %s", turn.response_id)
                    if not backlog.count:
                        self.pending.popleft()
                        backlog.close()
                        turn._backlog = None
                    if item is None:
                        continue
                else:
                    self.pending.popleft()
            if turn.cancelled.is_set() or _admissions_frozen.is_set():
                continue
            try:
                if item is None:
                    if not turn.cancelled.is_set():
                        self._send(turn, {"type": "brain_audio_complete", "response_id": turn.response_id,
                                          "had_audio": turn.had_audio,
                                          **({"audio_errors": turn.failed_chunks} if turn.failed_chunks else {})})
                    turn.completed.set()
                    continue
                text, index = item
                started = time.monotonic()
                audio = turn.synthesize(text, cancelled=turn.cancelled.is_set)
                # A slow UI callback must not hold the enqueue/cancel lock.
                # Every frame retains its response ID for receiver-side ownership.
                if audio and not turn.cancelled.is_set():
                    turn.had_audio = True
                    duration = audio.get("duration_sec", 0)
                    if (type(duration) in (int, float)
                            and math.isfinite(duration) and duration > 0):
                        # Synthesis completion is not playback completion. Keep
                        # foreground priority for the entire expected backlog;
                        # this estimate is not a physical playback receipt.
                        # Tracked for every turn so busy() can hold unsolicited
                        # lines; begin() still only honours it under arbitration.
                        with self.condition:
                            now = time.monotonic()
                            turn.playback_until = max(now, turn.playback_until) + duration
                    self._send(turn, {"type": "brain_audio", "response_id": turn.response_id,
                                      "sentence_index": index, **audio})
                    log.info("speech %s sentence=%s ready_ms=%.0f", turn.response_id,
                             index, (time.monotonic() - started) * 1000)
                elif not audio and not turn.cancelled.is_set():
                    turn.failed_chunks += 1
                    # A line that ends up text-only must say so (2026-10-04:
                    # text with no audio was read by the dashboard's browser
                    # voice, and nothing on the server showed it).
                    log.warning("[TTS] speech %s sentence=%s: synthesis gave no audio for %d chars; "
                                "text only", turn.response_id, index, len(text or ""))
            except Exception:
                self.errors += 1
                turn.failed_chunks += 1
                if item is None:
                    turn.completed.set()
                log.exception("speech failed for %s; text stream continues", turn.response_id)


_dispatcher = None
_lock = threading.RLock()
_session = uuid.uuid4().hex
_generation = 0
_generation_lock = threading.Lock()
_ownership_transition = threading.RLock()
_admission_lock = threading.RLock()
_admissions_frozen = threading.Event()
_arbitration = None


def _next_generation():
    global _generation
    with _generation_lock:
        _generation += 1
        return _generation


def install_arbitration(*, enabled, stop_audio=None):
    """Cold wiring only; starts no worker and performs no audio/model action.

    enabled returns literal True only for active configured selection. The
    bounded synchronous stop_audio callback receives a tagged snapshot event;
    it must never call this queue recursively or cancel any TaskWorker action.
    """
    global _arbitration
    if not callable(enabled) or (stop_audio is not None and not callable(stop_audio)):
        raise TypeError("arbitration wiring requires callables")
    with _lock, _admission_lock:
        if _arbitration is not None:
            raise RuntimeError("previous arbitration binding is still owned")
        if _dispatcher is not None:
            if ((_dispatcher.closed and _dispatcher.worker.is_alive()) or
                    (_admissions_frozen.is_set() and
                     (not _dispatcher.closed or _dispatcher.worker.is_alive()))):
                raise RuntimeError("previous speech worker has not drained")
        _arbitration = (enabled, stop_audio)
        _admissions_frozen.clear()


def quiesce_arbitration():
    """Effect-free admission fence; never wait on synthesis/sink callbacks.

    The root lifecycle owns the one-shot cleanup caller for stop(). The freeze
    outlives clear_arbitration so late consumers cannot resurrect a worker.
    """
    with _admission_lock:
        _admissions_frozen.set()
    return True


def admissions_frozen():
    """Pure lifecycle metadata; inspecting it admits no work or side effects."""
    return _admissions_frozen.is_set()


def clear_arbitration():
    global _arbitration
    with _lock, _admission_lock:
        if _dispatcher is not None and (not _dispatcher.closed or _dispatcher.worker.is_alive()):
            raise RuntimeError("speech worker must drain before binding is cleared")
        _arbitration = None
        _admissions_frozen.set()
    return True


def resume_legacy_after_retirement():
    """Explicit installer-only transition when the V2 runtime is disabled.

    Normal stop/clear stay frozen. The root installer calls this only after
    its previous speech owner fully retired; stale consumers never call it.
    It creates no worker or arbitration binding and invokes no sink callback.
    """
    with _lock, _admission_lock:
        if _arbitration is not None:
            raise RuntimeError("speech arbitration is still owned")
        if _admissions_frozen.is_set():
            if _dispatcher is not None and (not _dispatcher.closed or _dispatcher.worker.is_alive()):
                raise RuntimeError("speech worker has not drained")
            _admissions_frozen.clear()
    return True


def arbitration_active():
    with _lock:
        configuration = _arbitration
    try:
        return configuration is not None and configuration[0]() is True
    except Exception:
        return False


def interrupt(reason="barge_in", *, after_stop=None):
    """Invalidate this generation; optionally close its speaker-ledger window.

    after_stop is a bounded ledger-only callback under the ownership fence, so
    its old interval closure cannot truncate a successor's playback interval.
    """
    if not arbitration_active():
        return False
    with _ownership_transition:
        with _lock:
            dispatcher = _dispatcher
        result = False
        if dispatcher is not None:
            with dispatcher.condition:
                turn = dispatcher.current
            if turn is not None:
                result = dispatcher.cancel(owner=turn, reason=reason)
        if after_stop is not None:
            after_stop()
            return True
        return result


def delivery_allowed(payload):
    """Recheck tagged output at the actual network delivery boundary."""
    if "speech_generation" not in payload:
        return True
    if payload.get("type") == "brain_audio_cancel":
        return payload.get("speech_session") == _session
    if _admissions_frozen.is_set():
        return False
    with _lock:
        dispatcher = _dispatcher
    if dispatcher is None:
        return False
    with dispatcher.condition:
        turn = dispatcher.current
        return bool(turn is not None and turn.arbitration and not turn.cancelled.is_set()
                    and payload.get("speech_session") == _session
                    and payload.get("speech_generation") == turn.generation
                    and payload.get("response_id") == turn.response_id)


def start_response(synthesize, response_id, send, *, priority=100):
    global _dispatcher
    with _admission_lock:
        if _admissions_frozen.is_set():
            raise RuntimeError("speech owner is retiring")
    with _lock:
        with _admission_lock:
            if _admissions_frozen.is_set():
                raise RuntimeError("speech owner is retiring")
        if _dispatcher is not None and _dispatcher.closed and _dispatcher.worker.is_alive():
            raise RuntimeError("previous speech worker is still draining")
        if _dispatcher is None or _dispatcher.closed:
            _dispatcher = SpeechDispatcher(synthesize)
        dispatcher, configuration = _dispatcher, _arbitration
    try:
        selected = configuration is not None and configuration[0]() is True
    except Exception:
        selected = False
    return dispatcher.begin(response_id, send, priority=priority, synthesize=synthesize,
                            arbitration=selected,
                            stop_audio=configuration[1] if selected else None)


def busy(now=None):
    """True while a turn is still synthesizing or its audio is expected to be
    playing. Read-only; announcements wait on this instead of talking over a
    reply whose synthesis finished long before its playback does."""
    with _lock:
        dispatcher = _dispatcher
    if dispatcher is None:
        return False
    now = time.monotonic() if now is None else now
    with dispatcher.condition:
        turn = dispatcher.current
        if turn is None or turn.cancelled.is_set():
            return False
        return not turn.completed.is_set() or now < turn.playback_until


def cancel_response(response_id=None):
    with _lock:
        dispatcher = _dispatcher
    return dispatcher.cancel(response_id) if dispatcher is not None else False


def stop(timeout=1):
    """Cleanup caller only: timeout bounds join, not sink/transition callbacks.

    Lifecycle code must quiesce first and retain one background cleanup caller
    until this returns True. Never call this on a tick/ASGI consumer thread.
    """
    with _lock:
        dispatcher = _dispatcher
    return dispatcher.close(timeout) if dispatcher is not None else True


def stats():
    with _lock:
        dispatcher = _dispatcher
    return dispatcher.stats() if dispatcher is not None else {"alive": False, "queued": 0}
