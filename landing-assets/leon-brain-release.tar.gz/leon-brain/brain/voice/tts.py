"""
Text-to-Speech.

Backends (preference order):
  1. Piper         — local, fast, open-source, decent quality
  2. pyttsx3       — system TTS (SAPI on Windows, NSSpeech on macOS, espeak on Linux)
  3. Mock          — silent WAV for testing

Every backend exposes .speak(text) → bytes of WAV audio plus an optional
streaming generator synthesize_stream(text) for barge-in support.
"""

from __future__ import annotations

import io
import os
import threading
import wave
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class TTSResult:
    wav_bytes: bytes
    sample_rate: int
    backend: str
    duration_sec: float


class _MockTTS:
    name = "mock"

    def speak(self, text: str) -> TTSResult:
        # Generate 0.5s of silence per 20 characters as a stand-in
        sr = 16000
        seconds = max(0.3, len(text) / 40.0)
        n_samples = int(sr * seconds)
        pcm = b"\x00\x00" * n_samples
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(pcm)
        return TTSResult(
            wav_bytes=buf.getvalue(),
            sample_rate=sr,
            backend=self.name,
            duration_sec=seconds,
        )


class _Pyttsx3TTS:
    name = "pyttsx3"

    def __init__(self):
        try:
            import pyttsx3  # type: ignore
        except ImportError as e:
            raise RuntimeError("pyttsx3 not installed") from e
        self._engine = pyttsx3.init()

    def speak(self, text: str) -> TTSResult:
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            path = tmp.name
        try:
            self._engine.save_to_file(text, path)
            self._engine.runAndWait()
            with open(path, "rb") as f:
                wav = f.read()
            with wave.open(io.BytesIO(wav), "rb") as w:
                sr = w.getframerate()
                duration = w.getnframes() / sr
            return TTSResult(wav_bytes=wav, sample_rate=sr, backend=self.name, duration_sec=duration)
        finally:
            try:
                os.remove(path)
            except Exception:
                pass


def speakable(text: str) -> str:
    """Turn written text into text meant to be HEARD.

    Piper's phonemizer reads punctuation literally, which is why periods kept
    coming out as the word "dot" — an ellipsis becomes "dot dot dot", a domain
    like sabr.co becomes "sabr dot co", and a bullet or asterisk gets spoken
    outright. None of that is Piper being broken; nothing was ever cleaning
    the string. This does.

    Applied to every backend, not just Piper, so the fix can't drift again
    the way the Kokoro wiring did.
    """
    import re

    t = text

    # Markdown scaffolding — asterisks and backticks get read aloud.
    t = re.sub(r"[*_`#>]+", " ", t)
    # Bullets and list glyphs.
    t = re.sub(r"^[\s\-•·–]+", "", t, flags=re.MULTILINE)
    # Ellipsis -> a real pause, not three spoken dots.
    t = re.sub(r"\.{2,}", ",", t)
    # Dashes used as pauses -> comma. Keeps the rhythm, loses the word.
    t = re.sub(r"\s*[—–]\s*", ", ", t)
    # Bare URLs read as an unbroken stream of symbols. This MUST run before
    # the domain rule below — otherwise the domain rule splits the host, the
    # URL pattern then only matches the front half, and you get the literal
    # nonsense "a link com/dashboard". Caught by the test, not by reading it.
    t = re.sub(r"https?://\S+", "a link", t)
    # Domains and file extensions: say the name, not the punctuation.
    t = re.sub(r"\b([A-Za-z0-9-]+)\.(com|org|net|io|co|ai|dev|py|js|sh|md|json)\b",
               r"\1 \2", t)
    # Stray symbols with no spoken form.
    t = re.sub(r"[\[\]{}|\\<>~^]+", " ", t)
    t = t.replace("&", " and ").replace("%", " percent").replace("+", " plus ")
    # Collapse the whitespace all that substitution just created.
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\s*\n\s*", ". ", t.strip())
    # Substitution can leave doubled punctuation, which reads as a stumble.
    t = re.sub(r"([,.])\s*[,.]+", r"\1", t)
    return t.strip()


# ── Piper voice model auto-download ──────────────────────────────────
#
# The ears already solve this: brain/voice/wake_word_vosk.py fetches its
# own Vosk model on first use. The mouth did not, so every fresh install
# fell through Piper to the OS narrator and nobody noticed, because the
# fallback was silent. Same pattern, same honesty about what it's doing.
#
# URLs verified against huggingface.co/rhasspy/piper-voices (HEAD → 200).
# BOTH files are mandatory: PiperVoice.load() reads <model>.onnx.json for
# the phoneme map and sample rate and will not start without it.

_PIPER_DIR_REL = "brain_state/voice/piper"
_PIPER_BASE_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/main"

# voice name → (relative path within the piper-voices repo)
_PIPER_VOICES = {
    # Default: this is the voice the product already ships and logs as
    # "voice=en_GB-alan-medium", so a fresh install now sounds like the
    # demo box instead of like a different product.
    "en_GB-alan-medium": "en/en_GB/alan/medium/en_GB-alan-medium.onnx",
    "en_US-lessac-medium": "en/en_US/lessac/medium/en_US-lessac-medium.onnx",
}
_DEFAULT_PIPER_VOICE = "en_GB-alan-medium"
# Real size of a medium model, measured via Content-Length: 63,201,294 B.
_PIPER_MODEL_MB = 60


def default_piper_voice() -> str:
    v = (os.environ.get("LEON_PIPER_VOICE") or "").strip()
    return v if v in _PIPER_VOICES else _DEFAULT_PIPER_VOICE


def default_piper_model_path(voice: Optional[str] = None) -> str:
    """Absolute path where the default Piper model lives (may not exist)."""
    voice = voice or default_piper_voice()
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(root, _PIPER_DIR_REL, f"{voice}.onnx")


def _download_to(url: str, dest_tmp: str, deadline: float) -> None:
    """Stream `url` into `dest_tmp`, aborting if we blow past `deadline`.

    urlopen(timeout=...) only bounds a single socket operation, so a slow
    trickle can hang a constructor effectively forever. The wall-clock
    check in the read loop is what actually bounds this.
    """
    import time
    import urllib.request

    req = urllib.request.Request(url, headers={"User-Agent": "leon-brain/1.0"})
    remaining = max(1.0, deadline - time.time())
    with urllib.request.urlopen(req, timeout=min(60.0, remaining)) as r, \
            open(dest_tmp, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            if time.time() > deadline:
                raise TimeoutError(
                    f"download exceeded {_piper_timeout():.0f}s budget")


def _piper_timeout() -> float:
    try:
        return max(10.0, float(os.environ.get("LEON_TTS_DOWNLOAD_TIMEOUT", "300")))
    except ValueError:
        return 300.0


def _ensure_piper_model(model_path: str, voice: Optional[str] = None) -> bool:
    """Fetch the Piper .onnx + .onnx.json to `model_path` if missing.

    Returns True if both files are present afterward. Never raises — the
    caller decides what a False means (here: raise so the TTS ladder keeps
    falling through to pyttsx3, exactly as it does today).
    """
    import time

    cfg_path = model_path + ".json"
    if os.path.exists(model_path) and os.path.exists(cfg_path):
        return True

    # Derive the voice from the filename so a custom --piper-model path
    # pointing at a known voice still self-heals.
    base = os.path.basename(model_path)
    voice = voice or (base[: -len(".onnx")] if base.endswith(".onnx") else base)
    rel = _PIPER_VOICES.get(voice)
    if rel is None:
        print(f"[TTS] Piper voice {voice!r} unknown — no download URL", flush=True)
        return False

    if os.environ.get("LEON_TTS_NO_DOWNLOAD", "").strip() not in ("", "0", "false", "False"):
        print(f"[TTS] Piper voice missing and LEON_TTS_NO_DOWNLOAD is set — "
              f"skipping download, falling back to the system voice", flush=True)
        return False

    parent = os.path.dirname(os.path.abspath(model_path))
    try:
        os.makedirs(parent, exist_ok=True)
    except OSError as e:
        print(f"[TTS] cannot create Piper model dir {parent}: {e}", flush=True)
        return False

    onnx_url = f"{_PIPER_BASE_URL}/{rel}"
    json_url = onnx_url + ".json"
    print(f"[TTS] Piper voice missing — downloading {voice} "
          f"(~{_PIPER_MODEL_MB}MB) from {onnx_url}", flush=True)

    import tempfile
    deadline = time.time() + _piper_timeout()
    tmps = []
    try:
        wanted = [(json_url, cfg_path), (onnx_url, model_path)]
        for url, dest in [(u, d) for u, d in wanted if not os.path.exists(d)]:
            fd, tmp = tempfile.mkstemp(suffix=".part", dir=parent)
            os.close(fd)
            tmps.append((tmp, dest))
            _download_to(url, tmp, deadline)
        # Sanity-check before publishing: a captive-portal HTML page or a
        # truncated body would otherwise be renamed into place and then
        # fail forever, since the "does it exist" check would pass.
        for tmp, dest in tmps:
            if dest.endswith(".json"):
                import json as _json
                with open(tmp, "r", encoding="utf-8") as f:
                    _json.load(f)
            elif os.path.getsize(tmp) < 1_000_000:
                raise RuntimeError(
                    f"downloaded model is only {os.path.getsize(tmp)} bytes")
        for tmp, dest in tmps:
            os.replace(tmp, dest)
        tmps = []
        if not (os.path.exists(model_path) and os.path.exists(cfg_path)):
            print(f"[TTS] Piper download finished but {model_path} is still "
                  f"incomplete", flush=True)
            return False
        print(f"[TTS] Piper voice ready — {model_path}", flush=True)
        return True
    except Exception as e:
        print(f"[TTS] Piper voice download failed: {type(e).__name__}: {e} — "
              f"falling back to the system voice", flush=True)
        return False
    finally:
        for tmp, _dest in tmps:
            try:
                os.remove(tmp)
            except OSError:
                pass


class _PiperTTS:
    name = "piper"

    def __init__(self, model_path: Optional[str] = None):
        try:
            from piper import PiperVoice  # type: ignore
        except ImportError as e:
            raise RuntimeError("piper-tts not installed") from e
        if model_path is None:
            # No path configured → use the standard location under
            # brain_state/voice/piper/ and fetch the model if it isn't
            # there. Nobody was ever going to drop an .onnx in by hand.
            model_path = default_piper_model_path()
        if not os.path.exists(model_path) or not os.path.exists(model_path + ".json"):
            if not _ensure_piper_model(model_path):
                raise RuntimeError(f"Piper model not available: {model_path}")
        self._voice = PiperVoice.load(model_path)

    def speak(self, text: str) -> TTSResult:
        # Piper also clips last word without trailing punctuation
        tts_text = speakable(text).rstrip()
        if tts_text and tts_text[-1] not in ".!?;:—":
            tts_text += "."
        # piper-tts >=1.4 split the API: `synthesize` returns audio chunks,
        # `synthesize_wav` writes a fully-formed WAV (header + frames) to
        # the given wave.Wave_write. Let it set its own WAV format so we
        # don't double-write the header.
        # length_scale < 1.0 = faster speech. Env-tunable.
        from piper.config import SynthesisConfig
        _speed = float(os.environ.get("PIPER_LENGTH_SCALE", "0.75"))
        _syn = SynthesisConfig(length_scale=_speed)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            self._voice.synthesize_wav(tts_text, w, syn_config=_syn,
                                       set_wav_format=True)
        wav = buf.getvalue()
        with wave.open(io.BytesIO(wav), "rb") as w:
            sr = w.getframerate()
            duration = w.getnframes() / sr if sr > 0 else 0.0
        return TTSResult(wav_bytes=wav, sample_rate=sr, backend=self.name, duration_sec=duration)


class _KokoroTTS:
    """Kokoro-82M via isolated venv. Local, free, no API key, no quota."""
    name = "kokoro"
    VENV = "/opt/kokoro-venv/bin/python"
    DIR = "/opt/leon-brain/brain_state/voice/kokoro"

    def __init__(self, voice: Optional[str] = None):
        import os as _os
        if not _os.path.exists(self.VENV):
            raise RuntimeError("kokoro venv missing")
        if not _os.path.exists(_os.path.join(self.DIR, "kokoro-v1.0.onnx")):
            raise RuntimeError("kokoro model missing")
        self.voice = voice or _os.environ.get("LEON_KOKORO_VOICE", "am_michael")
        self.speed = float(_os.environ.get("LEON_KOKORO_SPEED", "1.05"))
        self._worker = None
        self._rbuf = bytearray()
        self._lock = threading.Lock()

    # Loading the 325MB model costs ~2.4s. The old implementation spawned a
    # fresh interpreter per utterance and paid that on every sentence — most
    # of a short reply's latency. kokoro_worker.py loads once and stays
    # resident; JSON-per-line over stdin/stdout (library chatter goes to
    # stderr so stdout stays parseable — keep it that way if you touch it).
    WORKER = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "kokoro_worker.py")

    # Matches the old per-utterance subprocess ceiling. A worker that blows
    # past it is killed and respawned rather than wedging the speak lock.
    TIMEOUT_SEC = 120

    def _read_line(self, timeout: float) -> str:
        """One protocol line from the worker, or RuntimeError on deadline.

        The pipe is binary and buffered here, not in a TextIO wrapper —
        select() on a wrapped stream can report idle while a complete line
        sits in the wrapper's buffer.
        """
        import select, time
        deadline = time.monotonic() + timeout
        while b"\n" not in self._rbuf:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                # Kill the wedged child now — the old subprocess.run
                # timeout did, and a live one would keep chewing CPU and
                # wedge the next request too.
                self._kill_worker()
                raise RuntimeError("kokoro worker timed out")
            ready, _, _ = select.select(
                [self._worker.stdout], [], [], min(remaining, 1.0))
            if ready:
                chunk = os.read(self._worker.stdout.fileno(), 65536)
                if not chunk:
                    raise RuntimeError("kokoro worker died mid-request")
                self._rbuf += chunk
        line, _, rest = bytes(self._rbuf).partition(b"\n")
        self._rbuf = bytearray(rest)
        return line.decode("utf-8", "replace")

    def _kill_worker(self):
        worker, self._worker = self._worker, None
        if worker is not None and worker.poll() is None:
            try:
                worker.kill()
                worker.wait(timeout=5)
            except Exception:
                pass

    def __del__(self):
        self._kill_worker()

    def _spawn_worker(self):
        import subprocess, json
        proc = subprocess.Popen(
            [self.VENV, self.WORKER,
             os.path.join(self.DIR, "kokoro-v1.0.onnx"),
             os.path.join(self.DIR, "voices-v1.0.bin")],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL)
        self._worker = proc
        self._rbuf = bytearray()
        # First line is the ready handshake, sent after the model loads.
        try:
            ready = self._read_line(self.TIMEOUT_SEC)
            if not json.loads(ready).get("ready"):
                raise RuntimeError("kokoro worker refused to start")
        except Exception:
            self._kill_worker()
            raise
        return proc

    def _request(self, text: str) -> dict:
        import json
        req = json.dumps({
            "text": text, "voice": self.voice, "speed": self.speed,
            "lang": "en-gb" if self.voice.startswith(("bm_", "bf_"))
                    else "en-us",
        })
        if self._worker is None or self._worker.poll() is not None:
            self._spawn_worker()
        self._worker.stdin.write(req.encode() + b"\n")
        self._worker.stdin.flush()
        try:
            return json.loads(self._read_line(self.TIMEOUT_SEC))
        except json.JSONDecodeError as e:
            raise RuntimeError("kokoro worker spoke garbage: %s" % e)

    def speak(self, text: str) -> TTSResult:
        with self._lock:
            try:
                reply = self._request(text)
            except (RuntimeError, BrokenPipeError, OSError, ValueError):
                # Worker died or spoke garbage (OOM kill, venv upgrade
                # underneath it, native library writing to fd 1). One
                # respawn; a second failure is real and goes to the caller
                # so the backend chain can move on.
                self._kill_worker()
                reply = self._request(text)
        if not reply.get("ok"):
            raise RuntimeError("kokoro synth failed: %s"
                               % str(reply.get("error", ""))[-300:])
        out = reply["path"]
        try:
            wav_bytes = open(out, "rb").read()
        finally:
            try:
                os.unlink(out)
            except OSError:
                pass
        with wave.open(io.BytesIO(wav_bytes)) as w:
            sr = w.getframerate()
            dur = w.getnframes() / float(sr)
        return TTSResult(wav_bytes=wav_bytes, sample_rate=sr,
                         backend=self.name, duration_sec=dur)


class TTS:
    def __init__(
        self,
        prefer: Optional[str] = None,
        piper_model: Optional[str] = None,
    ):
        self.backend: Any = None
        self.backend_name: str = ""
        # Remembered so a SPEAK-time failure can construct the next backend.
        self._piper_model = piper_model
        order = [prefer] if prefer else []
        order += ["piper", "pyttsx3", "mock"]
        errors = []
        for name in order:
            if name is None:
                continue
            try:
                if name == "kokoro":
                    self.backend = _KokoroTTS()
                elif name == "piper":
                    self.backend = _PiperTTS(piper_model)
                elif name == "pyttsx3":
                    self.backend = _Pyttsx3TTS()
                elif name == "mock":
                    self.backend = _MockTTS()
                else:
                    continue
                self.backend_name = self.backend.name
                break
            except Exception as e:
                errors.append(f"{name}: {e}")
                continue
        if self.backend is None:
            raise RuntimeError(f"No TTS backend available. Tried: {errors}")

    def _next_backend(self, after: str):
        """First constructible backend other than `after`, or None.

        The order above only ran at CONSTRUCTION. A backend that dies at speak
        time (missing runtime, model deleted) therefore ended the
        sentence in silence with the exception swallowed one frame up. This is
        the same list, re-walked, minus the one that just failed.
        """
        for name in ("piper", "pyttsx3", "mock"):
            if name == after:
                continue
            try:
                if name == "piper":
                    return _PiperTTS(self._piper_model)
                if name == "pyttsx3":
                    return _Pyttsx3TTS()
                if name == "mock":
                    return _MockTTS()
            except Exception:
                continue
        return None

    def speak(self, text: str) -> TTSResult:
        # Ensure text ends with punctuation so TTS renders the final word/sentence.
        # Applied here once, universally, regardless of backend.
        text = text.rstrip()
        if text and text[-1] not in ".!?;:—":
            text += "."
        try:
            return self.backend.speak(text)
        except Exception as e:
            failed = self.backend_name
            nxt = self._next_backend(failed)
            if nxt is None:
                raise
            print(f"[TTS] {failed} failed at speak ({e}) — switching to "
                  f"{nxt.name} for the rest of this process.", flush=True)
            self.backend = nxt
            self.backend_name = nxt.name
            return self.backend.speak(text)
