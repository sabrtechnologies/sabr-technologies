"""V2 queue API over the existing single speech worker; no second audio owner.

The compatibility module remains speech_queue. Actuator audio.stop is owned
by the responder's existing Stop path; targeted cancellation here only cancels
the matching response's queued/in-flight synthesis output.
"""
from .speech_queue import (SpeechBusy, SpeechDispatcher, SpeechTurn,
                           cancel_response, start_response, stats, stop,
                           install_arbitration, clear_arbitration, quiesce_arbitration,
                           admissions_frozen, arbitration_active, interrupt, delivery_allowed)


def enqueue(turn, text, index):
    return turn.submit(text, index)
