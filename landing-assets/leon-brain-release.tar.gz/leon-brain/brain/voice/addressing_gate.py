"""
addressing_gate.py — "was this actually said TO me, or merely ABOUT me?"

Why this module exists
----------------------
audio_gate.py already solves a different problem: it stops Leon from
hearing HIMSELF (speaker bleed, echo, barge-in drain). That machinery is
sound and this module does not touch it.

The hole it does NOT cover, reported by Dean 2026-08-09:

    Dean was in the room talking to Wesley ABOUT Leon. He never pressed
    push-to-talk. The Vosk listener heard "...hey Leon..." inside a
    sentence aimed at another human, fired a wake, transcribed the
    surrounding speech, and Leon ANSWERED a conversation he was not part
    of — burning a turn and interrupting a real one.

Nothing in the pipeline asked the only question that matters:
*was this utterance addressed to me?* The wake word proves the SOUND
occurred. It does not prove the INTENT. Those are different claims and
the old code conflated them.

The check
---------
After STT and after the self-echo check, the transcript is handed to a
CHEAP model (OpenAI gpt-4o-mini, or the local Qwen when offline — never
Claude, never Opus). One boolean question: is this addressed to Leon?

Cost note: this is deliberately on the cheap lane. Spending a fraction of
a cent to avoid burning an Opus turn on a conversation that wasn't ours
is strictly profitable, and it is the whole point of having a second
architecture wired in at all.

Fail-open, on purpose
---------------------
If the classifier errors, times out, or no provider is reachable, we
ANSWER. A false drop means Leon goes silent when Dean actually wanted
him — that is the failure mode that cost a full day already. A false
answer is merely annoying. Silence is worse than noise, so the
uncertainty is spent on the side of responding.

Push-to-talk always wins
------------------------
If Dean physically pressed the button, intent is proven by the button
and this gate is skipped entirely. It only ever judges hands-free wakes.
"""

from __future__ import annotations

import os
import re
from typing import Tuple

# Utterances shorter than this are ambiguous by nature ("Leon?") and are
# almost always genuine summons. Don't spend a call to second-guess them.
_MIN_WORDS_TO_JUDGE = 4

# Env kill switch, so this can be disabled without a code edit if it ever
# misbehaves in front of a client.
_ENV_FLAG = "LEON_ADDRESSING_GATE"


def is_enabled() -> bool:
    return (os.environ.get(_ENV_FLAG, "on").strip().lower()
            not in ("0", "off", "false", "no"))


_PROMPT = """You are a strict binary classifier. You are NOT a chat assistant.

Someone spoke near a voice assistant named Leon. Decide whether the speech
was ADDRESSED TO Leon (a request, question, or command for him), or merely
MENTIONED Leon while speaking to another person / thinking aloud.

Examples addressed to Leon -> YES:
  "hey Leon can you check the server"
  "Leon what time is it"
  "Leon, stop"

  "Leon pull up the build logs"
  "Leon, send that to Wesley"

Examples merely about Leon -> NO:
  "so Leon runs on a hundred thousand neurons, it's wild"
  "I was telling him how Leon fixed that bug earlier"
  "yeah Leon's been having trouble with the microphone thing"

Decision rules, in order:
  1. If the sentence contains an IMPERATIVE aimed at Leon (pull up, check,
     open, send, stop, tell me, show me, run, find) -> YES, even if it
     also describes something.
  2. If it is a QUESTION and Leon is the one being asked ("Leon what is
     the status", "Leon how long will that take") -> YES. A question
     naming Leon is a question FOR Leon unless it is clearly about him
     in the third person ("is Leon still broken?" asked of a human).
  3. If Leon is the GRAMMATICAL SUBJECT being described in third person
     ("Leon is...", "Leon has been...", "Leon runs...") and there is no
     imperative or question for him -> NO.
  4. If you are not confident -> YES. Wrongly ignoring a real request is
     far worse than wrongly answering.

Answer with exactly one word: YES or NO.

Speech: {transcript}"""


def _ask_cheap_model(transcript: str) -> str:
    from brain.integrations import ai_providers as ap
    r = ap.cheapest_chat({"prompt": _PROMPT.format(transcript=transcript)})
    if not r.get("ok"):
        raise RuntimeError(r.get("error") or "no provider")
    return (r.get("text") or "").strip()


def is_addressed_to_leon(transcript: str,
                         push_to_talk: bool = False) -> Tuple[bool, str]:
    """Return (addressed, reason).

    Fail-open: any error/uncertainty returns True.
    """
    if push_to_talk:
        return True, "push-to-talk (intent proven by button)"
    if not is_enabled():
        return True, "gate disabled via %s" % _ENV_FLAG

    text = (transcript or "").strip()
    if not text:
        return True, "empty transcript (upstream will drop)"
    if len(text.split()) < _MIN_WORDS_TO_JUDGE:
        return True, "too short to judge — treated as a summons"

    try:
        answer = _ask_cheap_model(text)
    except Exception as e:
        return True, f"classifier unavailable ({e}) — failing open"

    # Be permissive in parsing: anything that isn't a clean NO answers.
    if re.match(r"^\W*no\b", answer, re.IGNORECASE):
        return False, f"classifier says not addressed to Leon ({answer[:20]!r})"
    return True, f"classifier says addressed ({answer[:20]!r})"
