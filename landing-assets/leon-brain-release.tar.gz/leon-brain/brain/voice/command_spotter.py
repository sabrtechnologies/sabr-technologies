"""Local finite-grammar command lane, independent of full STT and cloud models.

The owner fans post-wake PCM to this lane AND normal STT. An utterance retains
its trace/id through partials and full STT, which publishes VOICE_FINAL here.
Recognizer confidence must be supplied; absent Vosk word confidence means wait.
"""
from __future__ import annotations

import json
import math
import threading

from brain.cognition.procedural import normalize


class VoskCommandRecognizer:
    """Reuse an already loaded local Vosk model; never download a model."""
    def __init__(self, model, grammar, sample_rate=16000, recognizer_factory=None):
        if sample_rate != 16000:
            raise ValueError("command PCM must be mono 16-bit 16000 Hz")
        if recognizer_factory is None:
            from vosk import KaldiRecognizer
            recognizer_factory = KaldiRecognizer
        self._factory, self._model, self._rate = recognizer_factory, model, sample_rate
        self.reset(grammar)

    def reset(self, grammar):
        # Vosk lexicons contain spoken number words. The router also accepts
        # digit transcripts, but those aliases need not enter its acoustic grammar.
        phrases = sorted(p for p in grammar["phrases"] if not any(w.isdigit() for w in p.split())) + ["[unk]"]
        self.version = grammar["version"]
        self._recognizer = self._factory(self._model, self._rate, json.dumps(phrases))
        self._recognizer.SetWords(True)
        # Old Vosk versions without partial words remain final-only, safely.
        if hasattr(self._recognizer, "SetPartialWords"):
            self._recognizer.SetPartialWords(True)

    def accept_pcm(self, pcm16):
        if not isinstance(pcm16, bytes) or len(pcm16) % 2 or len(pcm16) > 32000:
            raise ValueError("expected at most one second of PCM16 bytes")
        final = self._recognizer.AcceptWaveform(pcm16)
        raw = json.loads(self._recognizer.Result() if final else self._recognizer.PartialResult())
        words = raw.get("result" if final else "partial_result") or []
        confidences = [w.get("conf") for w in words]
        confidence = 0.0
        if confidences and all(isinstance(c, (int, float)) and math.isfinite(c) and 0 <= c <= 1 for c in confidences):
            confidence = min(confidences)
        return raw.get("text" if final else "partial", ""), confidence, not bool(final)


class CommandSpotter:
    def __init__(self, router, *, recognizer=None, capacity=4096):
        self.router, self.recognizer = router, recognizer
        self.capacity = capacity
        self._lock = threading.RLock()
        self._utterances = {}
        self._active = None

    def begin(self, *, trace_id, utterance_id, wake_context=False, always_on_authorized=False):
        if not trace_id or not utterance_id:
            raise ValueError("stable trace_id and utterance_id are required")
        key = (trace_id, utterance_id)
        with self._lock:
            if key not in self._utterances:
                if len(self._utterances) >= self.capacity:
                    raise RuntimeError("command utterance capacity reached")
                self._utterances[key] = {"hypothesis": None, "count": 0, "final": None,
                    "context": {"wake_context": bool(wake_context),
                                "always_on_authorized": bool(always_on_authorized)},
                    "grammar": self.router.safe_grammar()["version"], "predicted": None}
            self._active = key
            if self.recognizer is not None:
                self.recognizer.reset(self.router.safe_grammar())

    def feed_pcm(self, pcm16):
        with self._lock:
            if self._active is None:
                raise RuntimeError("begin an utterance before feeding PCM")
            if self.recognizer is None:
                raise RuntimeError("local recognizer unavailable; continue full STT")
            key = self._active
            grammar = self.router.safe_grammar()
            if self.recognizer.version != grammar["version"]:
                self.recognizer.reset(grammar)
                self._utterances[key]["hypothesis"] = None
                self._utterances[key]["count"] = 0
            text, confidence, partial = self.recognizer.accept_pcm(pcm16)
            # A grammar recognizer endpoint is not the full-STT final transcript.
            # It cannot substitute for the two required partial observations.
            return self.partial(text, confidence=confidence, trace_id=key[0],
                                utterance_id=key[1], is_partial=partial)

    def partial(self, text, *, confidence, trace_id, utterance_id, is_partial=True):
        key = (trace_id, utterance_id)
        with self._lock:
            state = self._utterances.get(key)
            if state is None:
                raise RuntimeError("utterance has not begun")
            if state["final"] is not None or self.router.ledger.get_final(*key) is not None:
                return None
            prior = self.router.ledger.get(*key)
            if prior is not None:
                return {**prior, "duplicate": True}
            grammar = self.router.safe_grammar()
            if state["grammar"] != grammar["version"]:
                state.update(grammar=grammar["version"], hypothesis=None, count=0, predicted=None)
            match = self.router.match(text, partial=True, confidence=confidence) if is_partial else None
            if match is None or match.confidence < (0.99 if match.procedure.risk == "R0" else 0.995):
                state.update(hypothesis=None, count=0)
                return None
            fingerprint = (match.procedure.procedure_id, normalize(text))
            state["count"] = state["count"] + 1 if state["hypothesis"] == fingerprint else 1
            state["hypothesis"] = fingerprint
            if state["count"] < 2 or state["predicted"] == fingerprint:
                return None
            result = self.router.execute(match, trace_id=trace_id, utterance_id=utterance_id,
                                         partial=True, context=state["context"])
            if result["status"] == "shadow":
                state["predicted"] = fingerprint
            return result

    def final_text(self, text, *, trace_id, utterance_id):
        """Publish full STT with the existing action receipt, never execute again.

        If suppress_procedural is true, the caller records/deliberates about this
        final text but MUST NOT pass it to another legacy motor command path.
        Otherwise the normal final transcript/action-gate pipeline continues.
        """
        key = (trace_id, utterance_id)
        with self._lock:
            state = self._utterances.get(key)
            if state is None:
                raise RuntimeError("utterance has not begun")
            prior = self.router.ledger.get_final(*key)
            if prior is not None:
                return {**self.retry_final_feedback(trace_id=trace_id, utterance_id=utterance_id),
                        "duplicate": True}
            result = self.router.ledger.get(*key)
            payload = {"trace_id": trace_id, "utterance_id": utterance_id, "text": text,
                       "already_executed": result,
                       "suppress_procedural": bool(result and result.get("executed")),
                       "feedback_delivered": False}
            if result:
                final_match = self.router.match(text)
                payload["final_differs"] = (final_match is None or
                    final_match.procedure.procedure_id != result.get("procedure_id") or
                    [{"tool": s.tool, "args": s.args} for s in final_match.steps] != result.get("parameters"))
            # Separate durable namespace: a final with no early action must not
            # claim the action latch and block the normal final command route.
            claimed, _ = self.router.ledger.claim_final(*key, payload)
            result = self.retry_final_feedback(trace_id=trace_id, utterance_id=utterance_id)
            return result if claimed else {**result, "duplicate": True}

    def retry_final_feedback(self, *, trace_id, utterance_id):
        """Recover an outbox entry after restart, without begin or any dispatch.

        Sink acknowledgment follows emission, so a crash between them may
        redeliver the same stable event_id. The sink must deduplicate it.
        """
        key = (trace_id, utterance_id)
        with self._lock:
            payload = self.router.ledger.get_final(*key)
            if payload is None:
                return None
            if not payload.get("feedback_delivered"):
                payload["feedback_delivered"] = self.router._emit("VOICE_FINAL", payload)
                self.router.ledger.finish_final(*key, payload)
            state = self._utterances.get(key)
            if state is not None:
                state["final"] = payload
            return dict(payload)

    def retire(self, *, trace_id, utterance_id):
        """Only after all producers acknowledge final handling; never on a timer."""
        key = (trace_id, utterance_id)
        with self._lock:
            final = self.router.ledger.get_final(*key)
            if final is None or not final.get("feedback_delivered"):
                return False
            receipt = self.router.ledger.get(*key)
            if receipt and (receipt.get("status") == "running" or receipt.get("feedback_pending")):
                return False
            if not self.router.ledger.retire(*key):
                return False
            self._utterances.pop(key, None)
            if self._active == key:
                self._active = None
            return True
