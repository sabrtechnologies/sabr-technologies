"""Wake phrase resolution shared by detection and transcript confirmation."""
import os
import re


def configured_phrases(phrases=None):
    override = os.environ.get("LEON_WAKE_PHRASES", "").strip()
    if override:
        candidates = override.split("|")
    elif phrases:
        candidates = phrases
    else:
        from brain.identity import si_name
        candidates = [f"hey {(si_name() or 'si').strip()}"]
    words = {" ".join(re.findall(r"\w+", p.casefold())) for p in candidates}
    result = sorted(filter(None, words), key=len, reverse=True)
    if not result:
        raise ValueError("A nonempty wake phrase is required")
    return result


def phrase_pattern(phrases):
    alternatives = [r"\W+".join(re.escape(w) for w in p.split()) for p in phrases]
    return re.compile(r"(?<!\w)(?:" + "|".join(alternatives) + r")(?!\w)", re.I)


def confirmed_command(transcript, phrases=None):
    """Confirm the full phrase in the retained lead-in, then remove it.

    Two seconds of pre-roll can contain a few preceding words. A bare name
    or substring never confirms a wake unless explicitly configured.
    """
    text = transcript.strip()
    match = phrase_pattern(configured_phrases(phrases)).search(text[:100])
    if match is None or len(text[:match.start()].split()) > 6:
        return text, False
    return text[match.end():].lstrip(" ,.!?:;—-"), True
