"""
Speech-to-Text.

Backends (preference order):
  1. Faster-Whisper (local, fast, accurate)
  2. openai-whisper (local, slower)
  3. OpenAI Whisper API (cloud, requires key)
  4. Mock (for tests / no-audio environments)

Returns incremental transcription — feed() takes audio chunks and
returns a partial (volatile) transcript until an endpointing flush.
"""

from __future__ import annotations

import os
import tempfile
import threading
import time
import wave
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class STTResult:
    text: str
    is_final: bool
    confidence: float
    backend: str


# ── Whisper initial_prompt ────────────────────────────────────────────────
# Neutral words only. NOTHING owner-specific, and nothing that names a thing
# in the world (a car, a company, a project).
#
# WHY THIS MATTERS MORE THAN A PROMPT USUALLY DOES (2026-08-30): the shipped
# default listed the owner's name, his company, his car's make AND model,
# and his browser — nine tokens, five of them naming things in his life.
# initial_prompt is decoder conditioning, not a filter — on silence or noise
# Whisper's most likely continuation IS the prompt vocabulary, so it emits
# those words as a transcript. Those transcripts are then stored as memories
# (continuous_hearing) and replayed by the dream/consolidation loop. That is
# the literal mechanism behind customers reporting their SI "dreaming about"
# a car nobody in the house owns: nobody ever said the word, the decoder did.
# (The word itself is deliberately not repeated here — a comment ships too.)
#
# Every token here should be a word the SI genuinely needs biased (its own
# name, which Whisper otherwise mangles) or a generic UI noun.
_NEUTRAL_STT_VOCAB = ("dashboard", "browser", "screen", "notes", "reminder")


def default_initial_prompt() -> str:
    """Build the Whisper initial_prompt from THIS install's identity.

    The SI's own name is repeated deliberately: "Leon" is transcribed as
    "Liam"/"Lyam" without the bias (acoustically near-identical, far more
    common in training data), and the same applies to any short given name a
    customer picks. The owner's name is included only when one is actually
    configured — user_name() returns the turn label "You" when it is not, and
    seeding the decoder with "You" would make it hallucinate the word.
    """
    si = owner = ""
    try:
        from brain import identity as _ident
        si = (_ident.si_name() or "").strip()
        owner = (_ident.user_name() or "").strip()
    except Exception:
        pass
    # "SI" and "You" are identity.py's neutral placeholders for "not
    # configured", not names. Biasing toward them is worse than nothing.
    def _usable(w, placeholder):
        return w if (w and w != placeholder) else ""

    si = _usable(si, "SI")
    owner = _usable(owner, "You")
    words = [w for w in (si, owner, si) if w]
    if owner and owner == si:
        words = [si, si]
    words += list(_NEUTRAL_STT_VOCAB)
    return ", ".join(words) + "."


class _MockSTT:
    name = "mock"

    def transcribe(self, pcm16: bytes, sample_rate: int = 16000) -> STTResult:
        n = len(pcm16) // 2
        seconds = n / sample_rate
        return STTResult(
            text=f"[mock transcription of {seconds:.2f}s audio]",
            is_final=True,
            confidence=1.0,
            backend=self.name,
        )


class _FasterWhisperSTT:
    name = "faster-whisper"

    def __init__(self, model_size: str = "base"):
        try:
            from faster_whisper import WhisperModel  # type: ignore
        except ImportError as e:
            raise RuntimeError("faster-whisper not installed") from e
        # int8 quantized for CPU — fast and small. Users can pass "small"/"medium"/"large-v3" for better quality.
        self._model = WhisperModel(model_size, device="cpu", compute_type="int8")

    def transcribe(self, pcm16: bytes, sample_rate: int = 16000) -> STTResult:
        # Write to a temp WAV and hand path to faster-whisper
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            wav_path = tmp.name
        try:
            with wave.open(wav_path, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(sample_rate)
                w.writeframes(pcm16)
            # beam_size=1 keeps short-utterance latency under ~1.5s on the
            # "small" model. Bumping to 5 gave only marginally better text
            # at 5x the wall-clock — way too slow for "hey leon, how are
            # you" style turns. Users wanting accuracy over speed can set
            # LEON_STT_BEAM_SIZE in .env. language="en" skips ~200ms of
            # language detection. condition_on_previous_text=False stops
            # the model from inventing context that wasn't there.
            import os as _os
            beam = int(_os.environ.get("LEON_STT_BEAM_SIZE", "1"))
            # initial_prompt biases the decoder toward Dean-specific vocab —
            # most importantly "Leon" (which Whisper otherwise transcribes as
            # "Lyam" / "Liam" — they're acoustically near-identical and "Liam"
            # is much more common in training data). Set via LEON_STT_INITIAL_PROMPT
            # in .env. Falls back to a sensible default if unset.
            # Default is built from THIS install's identity plus neutral
            # words — never from the owner's vocabulary. The original keeps
            # its richer list in .env via the override, which still wins.
            init_prompt = (_os.environ.get("LEON_STT_INITIAL_PROMPT", "").strip()
                           or default_initial_prompt())
            segments, info = self._model.transcribe(
                wav_path,
                beam_size=beam,
                language="en",
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 500},
                condition_on_previous_text=False,
                temperature=0.0,
                initial_prompt=init_prompt,
            )
            text = " ".join(s.text.strip() for s in segments).strip()
            conf = float(info.duration_after_vad > 0)
            return STTResult(text=text, is_final=True, confidence=conf, backend=self.name)
        finally:
            try:
                os.remove(wav_path)
            except Exception:
                pass


class _WhisperLocalSTT:
    name = "openai-whisper"

    def __init__(self, model_size: str = "base"):
        try:
            import whisper  # type: ignore
        except ImportError as e:
            raise RuntimeError("openai-whisper not installed") from e
        self._model = whisper.load_model(model_size)

    def transcribe(self, pcm16: bytes, sample_rate: int = 16000) -> STTResult:
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            wav_path = tmp.name
        try:
            with wave.open(wav_path, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(sample_rate)
                w.writeframes(pcm16)
            result = self._model.transcribe(wav_path)
            return STTResult(
                text=result["text"].strip(),
                is_final=True,
                confidence=1.0,
                backend=self.name,
            )
        finally:
            try:
                os.remove(wav_path)
            except Exception:
                pass


class _OpenAIAPISTT:
    name = "openai-api"

    def __init__(self):
        self.api_key = os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            raise RuntimeError("OPENAI_API_KEY not set")

    def transcribe(self, pcm16: bytes, sample_rate: int = 16000) -> STTResult:
        import urllib.request
        import urllib.error

        # Write temp wav, upload via multipart/form-data
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            wav_path = tmp.name
        try:
            with wave.open(wav_path, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(sample_rate)
                w.writeframes(pcm16)

            boundary = "----nlkd-boundary-XYZ"
            with open(wav_path, "rb") as f:
                audio = f.read()
            body = (
                f"--{boundary}\r\n"
                'Content-Disposition: form-data; name="model"\r\n\r\n'
                "whisper-1\r\n"
                f"--{boundary}\r\n"
                'Content-Disposition: form-data; name="file"; filename="audio.wav"\r\n'
                "Content-Type: audio/wav\r\n\r\n"
            ).encode() + audio + f"\r\n--{boundary}--\r\n".encode()

            req = urllib.request.Request(
                "https://api.openai.com/v1/audio/transcriptions",
                data=body,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": f"multipart/form-data; boundary={boundary}",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                import json
                data = json.loads(resp.read().decode("utf-8"))
                return STTResult(
                    text=data.get("text", "").strip(),
                    is_final=True,
                    confidence=1.0,
                    backend=self.name,
                )
        finally:
            try:
                os.remove(wav_path)
            except Exception:
                pass


# The fallback has to be about as good as the cloud model it stands in for.
# "base" (the old default) turned Dean's speech into "Cybertruck" and "Steve
# from Sardin" on 2026-10-06. large-v3-turbo, int8 on the VPS CPU with the
# brain running: 25.6s clip in 4.2s at the default 4 threads (8 threads was
# slower, 7.4s, contending with the sim), ~1 GB RAM, ~16s to load.
_FALLBACK_MODEL = os.environ.get("LEON_STT_FALLBACK_MODEL", "large-v3-turbo")
_local_cache: dict = {}
_local_lock = threading.Lock()


def _shared_local_backend(model_size: str = "base"):
    """One local fallback per process, shared by every STT instance (the
    voice pipeline, the push-to-talk route and the audio daemon each build
    their own STT). The preferred model first, then the caller's size, so a
    box that can't fetch turbo still gets the model it already has. A failed
    build is cached as None so a missing install isn't retried per clip."""
    with _local_lock:
        key = (_FALLBACK_MODEL, model_size)
        if key in _local_cache:
            return _local_cache[key]
        backend = None
        for size in dict.fromkeys((_FALLBACK_MODEL, model_size)):
            for cls in (_FasterWhisperSTT, _WhisperLocalSTT):
                try:
                    t0 = time.time()
                    backend = cls(size)
                    print(f"[STT] local fallback ready: {backend.name} {size} "
                          f"({time.time() - t0:.1f}s)", flush=True)
                    break
                except Exception:
                    continue
            if backend is not None:
                break
        _local_cache[key] = backend
        return backend


class STT:
    def __init__(self, prefer: Optional[str] = None, model_size: str = "base"):
        self.backend: Any = None
        self.backend_name: str = ""
        # Allow forcing a backend from .env (e.g. LEON_STT_PREFER=openai-api
        # for cloud Whisper accuracy). Falls back to local backends if the
        # preferred one can't init (missing key, etc).
        prefer = prefer or os.environ.get("LEON_STT_PREFER") or None
        order = [prefer] if prefer else []
        # "mock" is NOT in the automatic chain. _MockSTT returns the literal
        # string "[mock transcription of N.NNs audio]" and STT.transcribe
        # passes it straight through to the responder as if the owner had
        # SPOKEN it. On a stock client install none of faster-whisper,
        # openai-whisper or an OPENAI_API_KEY is present, so mock was the
        # guaranteed landing spot: a hallucinated input channel that invents
        # sentences the human never said. Silence is a bug; fabricated input
        # is a lie. It stays reachable only via an explicit
        # LEON_STT_PREFER=mock for tests.
        order += ["faster-whisper", "openai-whisper", "openai-api"]
        errors = []
        for name in order:
            if name is None:
                continue
            try:
                if name == "faster-whisper":
                    self.backend = _FasterWhisperSTT(model_size)
                elif name == "openai-whisper":
                    self.backend = _WhisperLocalSTT(model_size)
                elif name == "openai-api":
                    self.backend = _OpenAIAPISTT()
                elif name == "mock":
                    self.backend = _MockSTT()
                else:
                    continue
                self.backend_name = self.backend.name
                break
            except Exception as e:
                errors.append(f"{name}: {e}")
                continue
        if self.backend is None:
            raise RuntimeError(f"No STT backend available. Tried: {errors}")
        self._model_size = model_size
        self._cloud_down_until = 0.0
        self.last_error = ""            # why the cloud backend last failed
        if (self.backend_name in self._CLOUD_BACKENDS
                and os.environ.get("LEON_STT_PREWARM_FALLBACK", "1") != "0"):
            # Load the fallback now, off-thread: the turbo model takes ~16s
            # to load on the VPS, and the first clip after the cloud fails
            # should not wait for that.
            threading.Thread(target=self._local_fallback, daemon=True,
                             name="stt-fallback-prewarm").start()

    # A cloud backend can init fine and still fail on every call. 2026-10-06:
    # the OpenAI account ran out of credits, whisper-1 answered every clip
    # with 429 insufficient_quota, /api/voice/transcribe returned 500, and
    # push-to-talk went dead while the faster-whisper model sat cached on the
    # same box. Fall back to the local model instead, and stop paying a
    # doomed round trip on every clip until the cooldown passes.
    _CLOUD_BACKENDS = ("openai-api",)
    _CLOUD_COOLDOWN_S = 600

    def _local_fallback(self):
        return _shared_local_backend(self._model_size)

    def transcribe(self, pcm16: bytes, sample_rate: int = 16000) -> STTResult:
        if self.backend_name not in self._CLOUD_BACKENDS:
            return self.backend.transcribe(pcm16, sample_rate)
        if time.time() < self._cloud_down_until:
            local = self._local_fallback()
            if local is not None:
                return local.transcribe(pcm16, sample_rate)
        try:
            result = self.backend.transcribe(pcm16, sample_rate)
            self.last_error = ""
            return result
        except Exception as e:
            reason = describe_stt_error(e)
            self.last_error = reason
            local = self._local_fallback()
            if local is None:
                raise STTError(reason) from e
            self._cloud_down_until = time.time() + self._CLOUD_COOLDOWN_S
            print(f"[STT] {self.backend_name} failed ({reason}); using "
                  f"{local.name} for the next {self._CLOUD_COOLDOWN_S // 60} min",
                  flush=True)
            return local.transcribe(pcm16, sample_rate)


class STTError(RuntimeError):
    """Transcription failed; str() is one short sentence safe to show Dean."""


def describe_stt_error(e: Exception) -> str:
    """Turn a backend exception into a short human reason."""
    import json
    import urllib.error
    if isinstance(e, STTError):
        return str(e)
    if isinstance(e, urllib.error.HTTPError):
        code, msg = "", ""
        try:
            err = json.loads(e.read().decode("utf-8", "replace")).get("error") or {}
            code = str(err.get("code") or err.get("type") or "")
            msg = str(err.get("message") or "")
        except Exception:
            pass
        if e.code == 429 and ("quota" in code or "credit" in code):
            return "OpenAI speech-to-text is out of credits"
        if e.code == 401:
            return "OpenAI speech-to-text key was rejected"
        if e.code == 429:
            return "OpenAI speech-to-text is rate-limiting"
        return f"OpenAI speech-to-text error {e.code}" + (f": {msg[:80]}" if msg else "")
    if isinstance(e, urllib.error.URLError):
        return f"couldn't reach the speech-to-text service ({e.reason})"
    return f"speech-to-text failed: {type(e).__name__}: {str(e)[:100]}"
