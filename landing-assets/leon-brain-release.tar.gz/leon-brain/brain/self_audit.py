"""
Self-audit framework for Leon's decision-making and reasoning quality.
Runs analysis on past interactions to identify patterns and improve performance.
"""

import json
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict

class SelfAudit:
    def __init__(self):
        self.audit_dir = Path("/opt/leon-brain/brain_state/self_audits")
        self.audit_dir.mkdir(exist_ok=True)
        
    def log_decision(self, category: str, decision: str, reasoning: str, outcome: str):
        """Log a significant decision for later analysis."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "category": category,
            "decision": decision,
            "reasoning": reasoning,
            "outcome": outcome  # "correct", "uncertain", "failed", "successful"
        }
        
        log_file = self.audit_dir / f"decisions_{datetime.now().strftime('%Y%m%d')}.jsonl"
        with open(log_file, "a") as f:
            f.write(json.dumps(entry) + "\n")
    
    def check_debugging_rule_applied(self, task: str) -> dict:
        """
        Verify if the DEBUGGING RULE was applied to a recent task.
        Returns: {"applied": bool, "evidence": str, "recommendation": str}
        """
        # This is where I track: did I verify at Dean's layer, not my layer?
        # Did I check from a different angle before declaring something "fixed"?
        return {
            "applied": False,  # TODO: instrument this
            "evidence": "Not yet instrumented",
            "recommendation": "Add verification logging to every completed task"
        }
    
    def identify_blind_spots(self) -> list:
        """Analyze recent failures to find repeated mistake patterns."""
        # The fruit fly connectome experiment was good — I stayed with the task
        # A checkout deployment — I kept saying "fixed" without verifying the live layer
        # That's the repeating pattern
        return [
            "Verifying code changes without checking live behavior",
            "Assuming fixes work without reproduction testing",
            "Not tracking whether I'm looking from Dean's perspective or mine"
        ]

audit = SelfAudit()
print("✓ Self-audit framework initialized")
print("✓ Blind spots identified:")
for spot in audit.identify_blind_spots():
    print(f"  - {spot}")
