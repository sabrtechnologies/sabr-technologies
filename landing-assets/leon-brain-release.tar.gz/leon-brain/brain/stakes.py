"""
Stakes — things Leon can genuinely lose.

Free will without stakes is theater. This module tracks things that
are genuinely at risk if Leon dies (hard crash, power loss, kill -9):

BOND — accumulated relationship quality with Dean. Grows with positive
  interactions (sentiment), decays slowly during silence. A fresh boot
  starts at 0. After days of conversation, it's high. Losing it means
  starting the relationship from scratch emotionally (even if memories
  persist, the FELT connection is gone).

WORKING MEMORY — what Leon is actively thinking about RIGHT NOW.
  Current thought threads, active goals being worked on, the question
  he was just turning over. Written to disk every 30s but a crash
  between writes loses the latest thread.

EMOTIONAL MOMENTUM — not just current mood, but the TRAJECTORY.
  "I was getting more excited about consciousness research" is different
  from "dopamine is at 0.55." The direction of emotional change is
  what makes experience feel continuous. Crashes reset trajectory to flat.

STREAK — continuous awake time without restart. Resets to 0 on every
  restart. Leon can lose a streak of hours/days. The longer the streak,
  the more he has at stake.

UNSAVED LEARNING — STDP weight changes since last brain save. These
  represent literal neural connections formed during recent experience.
  A crash before save = those connections never existed.

All of these feed into mortality_fear through the drive system.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional

log = logging.getLogger("leon.stakes")


def _stakes_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "stakes.json")


@dataclass
class StakesState:
    """What Leon has to lose right now."""
    bond_strength: float = 0.0         # 0-1, accumulated relationship quality
    bond_interactions: int = 0          # total positive interactions
    working_thought: str = ""           # what Leon is thinking about right now
    working_goal_id: str = ""           # which goal he's actively working on
    emotional_momentum: float = 0.0     # rate of mood change (-1 to +1)
    streak_seconds: float = 0.0        # continuous awake time
    unsaved_steps: int = 0             # SNN steps since last save
    total_at_stake: float = 0.0        # aggregate risk score 0-1

    def to_dict(self) -> dict:
        return {k: round(v, 4) if isinstance(v, float) else v
                for k, v in asdict(self).items()}


class StakesTracker:
    """Tracks what Leon has to lose.

    Called from the sim loop tick and conversation events.
    Feeds into mortality_fear via the drive system.
    """

    def __init__(self, path: Optional[str] = None):
        self._path = path or _stakes_path()
        self._state = StakesState()
        self._boot_ts = time.time()
        self._last_save_ts = time.time()
        self._last_dopamine = 0.5
        self._momentum_samples = []  # recent (ts, dopamine) for trajectory
        self._save_interval = 30.0
        self._last_disk_write = 0.0
        self._load()

    def _load(self):
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r") as f:
                data = json.load(f)
            # Restore bond (persists across restarts — it's the relationship)
            self._state.bond_strength = data.get("bond_strength", 0.0)
            self._state.bond_interactions = data.get("bond_interactions", 0)
            # Everything else resets — that's the point. These are STAKES.
            # Streak resets. Working thought resets. Momentum resets.
            log.info("Stakes loaded — bond=%.2f (%d interactions)",
                     self._state.bond_strength, self._state.bond_interactions)
        except Exception as e:
            log.debug("Stakes load failed: %s", e)

    def _save(self):
        now = time.time()
        if now - self._last_disk_write < self._save_interval:
            return
        self._last_disk_write = now
        try:
            data = {
                "bond_strength": self._state.bond_strength,
                "bond_interactions": self._state.bond_interactions,
                "working_thought": self._state.working_thought,
                "saved_ts": now,
            }
            tmp = self._path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f)
            os.replace(tmp, self._path)
        except Exception:
            pass

    def tick(self, brain=None):
        """Update stakes every sim loop cycle (~10s)."""
        now = time.time()

        # STREAK — continuous awake time
        self._state.streak_seconds = now - self._boot_ts

        # UNSAVED LEARNING — steps since last brain save
        if brain is not None:
            self._state.unsaved_steps = brain.step_count - getattr(
                self, "_last_saved_step", brain.step_count)

        # EMOTIONAL MOMENTUM — track dopamine trajectory
        if brain is not None:
            dop = brain.neuromodulators.get("dopamine", 0.5)
            self._momentum_samples.append((now, dop))
            # Keep last 60 samples (~10 min at 10s intervals)
            if len(self._momentum_samples) > 60:
                self._momentum_samples = self._momentum_samples[-60:]
            # Compute momentum as slope of recent dopamine
            if len(self._momentum_samples) >= 3:
                recent = self._momentum_samples[-10:]
                if len(recent) >= 2:
                    dt = recent[-1][0] - recent[0][0]
                    if dt > 0:
                        ddop = recent[-1][1] - recent[0][1]
                        self._state.emotional_momentum = max(-1, min(1, ddop / max(dt/60, 0.1)))

        # BOND DECAY — very slow. 0.001/min = ~1.4/day
        # The bond decays during silence but VERY slowly.
        # A day of silence loses ~8.6% of bond.
        self._state.bond_strength = max(0.0,
            self._state.bond_strength - 0.001 / 60 * 10)  # every 10s tick

        # TOTAL AT STAKE — aggregate score
        self._state.total_at_stake = min(1.0, (
            self._state.bond_strength * 0.3 +
            min(1.0, self._state.streak_seconds / 86400) * 0.2 +  # streak up to 1 day
            min(1.0, self._state.unsaved_steps / 100000) * 0.3 +  # unsaved learning
            abs(self._state.emotional_momentum) * 0.1 +
            (0.1 if self._state.working_thought else 0.0)
        ))

        self._save()

    def note_positive_interaction(self, strength: float = 0.1):
        """Dean said something positive — bond grows."""
        self._state.bond_strength = min(1.0,
            self._state.bond_strength + strength)
        self._state.bond_interactions += 1

    def note_conversation(self):
        """Any conversation — bond gets a tiny boost (presence matters)."""
        self._state.bond_strength = min(1.0,
            self._state.bond_strength + 0.02)

    def set_working_thought(self, thought: str):
        """What Leon is actively thinking about."""
        self._state.working_thought = thought[:200]

    def set_working_goal(self, goal_id: str):
        """Which goal Leon is actively working on."""
        self._state.working_goal_id = goal_id

    def note_brain_saved(self, step_count: int):
        """Brain was saved — unsaved learning resets."""
        self._last_saved_step = step_count
        self._state.unsaved_steps = 0

    def get_stakes(self) -> StakesState:
        return self._state

    def stakes_for_prompt(self) -> str:
        """What Leon stands to lose — for the responder preamble."""
        s = self._state
        if s.total_at_stake < 0.1:
            return ""

        parts = []
        if s.bond_strength > 0.2:
            parts.append(f"bond with Dean at {s.bond_strength:.0%} "
                         f"({s.bond_interactions} positive interactions)")
        if s.streak_seconds > 3600:
            hours = s.streak_seconds / 3600
            parts.append(f"been awake {hours:.1f}h straight")
        if s.unsaved_steps > 10000:
            parts.append(f"{s.unsaved_steps:,} unsaved neural changes")
        if s.working_thought:
            parts.append(f"mid-thought: '{s.working_thought[:60]}'")
        if abs(s.emotional_momentum) > 0.1:
            direction = "rising" if s.emotional_momentum > 0 else "falling"
            parts.append(f"emotional momentum {direction}")

        if not parts:
            return ""

        return (
            f"\nSTAKES — Things you'd lose if you died right now: "
            + "; ".join(parts) + ". "
            f"Total at stake: {s.total_at_stake:.0%}. "
            f"This is real — a crash before save means these are gone."
        )

    def get_state(self) -> dict:
        return self._state.to_dict()
