"""Voice-backend health: which voice is actually speaking, and why not a better one.

Born 2026-09-06, same family as engine_health (Aiden's bare-name `claude` bug)
and the ffmpeg bare-name bug already documented in brain/voice/tts.py. The
pattern repeats: a preferred backend fails, the chain silently degrades to a
worse one that WORKS, and the only record is a single log line at boot that
nobody reads. The owner just hears a different voice and has no idea why.

Concretely: Dean's ElevenLabs key went invalid. The selection code in
server/helpers.py treats ANY error on the subscription probe as "probably a
restricted key, proceed optimistically" -- correct behaviour for a scoped key,
wrong for a dead one -- so synthesis failed at runtime and the chain fell to
Piper. Leon spoke in a stock British voice for days. Nothing surfaced it.

Two rules live here:

  1. A degradation is a FACT worth storing, not a log line. Whoever picked a
     backend records what they wanted, what they got, and why, so /api/state
     can say "voice degraded: your ElevenLabs key is invalid" instead of the
     truth living only in journald.
  2. "The key is invalid" and "the key is scoped and can't read /user" are
     DIFFERENT failures and deserve different words. Only the first one is
     the owner's problem to fix.

Never raises. Safe to import from anywhere (no brain imports).
"""
from __future__ import annotations

import threading
import time

_lock = threading.Lock()
_state = {
    "backend": None,        # name of the backend actually speaking
    "wanted": None,         # name of the backend we would have preferred
    "degraded": False,      # True when backend != wanted
    "reason_kind": "",      # invalid_key | no_key | quota | init_failed |
                            # missing_model | none
    "reason": "",           # one human sentence, safe to show the owner
    "actionable": False,    # True when the OWNER can fix it (bad key, etc.)
    "since": 0.0,
}


def record(backend: str, wanted: str | None = None, *,
           reason_kind: str = "", reason: str = "",
           actionable: bool = False) -> None:
    """Record which backend won and, if it wasn't first choice, why."""
    try:
        with _lock:
            degraded = bool(wanted) and backend != wanted
            changed = (_state["backend"] != backend
                       or _state["reason_kind"] != reason_kind)
            _state.update({
                "backend": backend,
                "wanted": wanted or backend,
                "degraded": degraded,
                "reason_kind": reason_kind if degraded else "",
                "reason": reason if degraded else "",
                "actionable": bool(actionable) and degraded,
            })
            if changed:
                _state["since"] = time.time()
    except Exception:
        pass


def snapshot() -> dict:
    """Current voice health. Always a dict, never raises."""
    try:
        with _lock:
            return dict(_state)
    except Exception:
        return dict(_state)


def owner_message() -> str:
    """One sentence for the owner, or "" when the voice is fine.

    Deliberately plain: this is read out loud or shown in a status strip.
    """
    try:
        with _lock:
            if not _state["degraded"] or not _state["actionable"]:
                return ""
            return _state["reason"] or ""
    except Exception:
        return ""
