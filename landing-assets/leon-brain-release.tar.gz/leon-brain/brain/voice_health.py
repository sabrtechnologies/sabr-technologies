"""Voice-backend health: actual local voice and any fallback reason.

Backend selection records degradation so it is visible in /api/state.
Only problems the owner can fix should produce an actionable notice.
Never raises. Safe to import without constructing a brain.
"""
from __future__ import annotations

import threading
import time

_lock = threading.Lock()
_state = {
    "backend": None,        # name of the backend actually speaking
    "wanted": None,         # name of the backend we would have preferred
    "degraded": False,      # True when backend != wanted
    "reason_kind": "",      # invalid_key | no_key | quota | init_failed |
                            # missing_model | none
    "reason": "",           # one human sentence, safe to show the owner
    "actionable": False,    # True when the OWNER can fix it (bad key, etc.)
    "since": 0.0,
}


def record(backend: str, wanted: str | None = None, *,
           reason_kind: str = "", reason: str = "",
           actionable: bool = False) -> None:
    """Record which backend won and, if it wasn't first choice, why."""
    try:
        with _lock:
            degraded = bool(wanted) and backend != wanted
            changed = (_state["backend"] != backend
                       or _state["reason_kind"] != reason_kind)
            _state.update({
                "backend": backend,
                "wanted": wanted or backend,
                "degraded": degraded,
                "reason_kind": reason_kind if degraded else "",
                "reason": reason if degraded else "",
                "actionable": bool(actionable) and degraded,
            })
            if changed:
                _state["since"] = time.time()
    except Exception:
        pass


def snapshot() -> dict:
    """Current voice health. Always a dict, never raises."""
    try:
        with _lock:
            return dict(_state)
    except Exception:
        return dict(_state)


def owner_message() -> str:
    """One sentence for the owner, or "" when the voice is fine.

    Deliberately plain: this is read out loud or shown in a status strip.
    """
    try:
        with _lock:
            if not _state["degraded"] or not _state["actionable"]:
                return ""
            return _state["reason"] or ""
    except Exception:
        return ""
