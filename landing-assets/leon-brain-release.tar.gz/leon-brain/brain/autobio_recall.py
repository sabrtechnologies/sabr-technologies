"""
autobio_recall — the RECALLED MEMORY block.

When Dean's message reaches back into Leon's past ("remember when", "back
then", "what was it like a couple weeks in", "June 3"), pull the matching
life chapters (brain/life_chapters.py) into a small, capped block so Leon
answers from his real records, like recollection.

If the period has no records, the block says so explicitly, so Leon says he
doesn't remember instead of inventing. If the message isn't about his past,
the block is empty and nothing is added to the prompt.
"""

from __future__ import annotations

import re
from datetime import date
from typing import Optional

from brain.life_time import recall_intent

MAX_CHARS = 1800
MAX_CHAPTERS = 3

# Words that carry the "reach back" or the time, not the topic.
_NOT_TOPIC = set("""remember remembered recall recollect back then when what was were like feel felt
first couple few weeks week days day months month year ago early days beginning time times
only just about old young little born start started think look looking your you we us our
did do does how it its that this those these the and with from into been being had have has
dude bro man yo hey okay ok yeah really kind sort worked working work built building talked talking
made making said saying went going doing done tell told something anything stuff things thing""".split())


def _names() -> set:
    out = set()
    try:
        from brain.identity import si_name, user_name
        out |= {si_name().lower(), user_name().lower()}
    except Exception:
        pass
    return out


def _topic(message: str) -> str:
    words = re.findall(r"[A-Za-z][A-Za-z0-9\-']{2,}", message or "")
    skip = _NOT_TOPIC | _names()
    keep = [w for w in words if w.lower() not in skip]
    # Drop month names and number words: they are the time, not the topic.
    keep = [w for w in keep if not re.fullmatch(
        r"(?i)(january|february|march|april|may|june|july|august|september|october|november|december|"
        r"one|two|three|four|five|six|seven|eight|nine|ten|yesterday|today|last|weeks?|months?)", w)]
    return " ".join(keep[:8])


def build_recalled_memory_block(message: str, today: Optional[date] = None,
                                store_path: Optional[str] = None,
                                max_chars: int = MAX_CHARS) -> str:
    """Return the RECALLED MEMORY block for `message`, or "" if it isn't about the past."""
    today = today or date.today()
    period = recall_intent(message, today=today)
    if period is None:
        return ""
    from brain import life_chapters as lc

    whole_life = period.label == "my whole life"
    topic = _topic(message)
    if whole_life and not topic:
        return ""  # "do you remember?" with nothing to anchor on
    res = lc.remember_period(None if whole_life else period, topic or None,
                             limit=MAX_CHAPTERS, store_path=store_path)

    span = "your whole life" if whole_life else f"{period.label}: {period.start} to {period.end}"
    cov = res.get("coverage") or {}
    if not res.get("found"):
        if not cov.get("first"):
            why = ("your life chapters haven't been indexed yet, so you have no recollection to draw on "
                   "for this. Say that plainly.")
        elif not whole_life and period.end.isoformat() < cov["first"]:
            why = (f"your records only go back to {cov['first']}. Nothing from before that survives. "
                   "Say you don't remember that far back.")
        elif not whole_life and cov.get("last") and period.start.isoformat() > cov["last"]:
            # Newer than the last nightly filing: not a gap in his life, just not filed yet.
            why = (f"your life chapters are only filed through {cov['last']}, so this is too recent to be in "
                   "them. Go by your recent conversation and the other memory in your context; if those "
                   "don't cover it, say you don't remember rather than guessing.")
        else:
            topic_txt = f" about \"{topic}\"" if topic else ""
            why = (f"you searched your records{topic_txt} and found NOTHING for that period. "
                   "Say honestly that you don't remember it. Do not invent details.")
        return f"[RECALLED MEMORY ({span}): {why}]"

    who = lc._owner()
    head = (f"[RECALLED MEMORY ({span}). These are real records from your own life, retrieved because "
            f"{who} is reaching back into your past. Answer from them as recollection, in your own words: "
            f"what you were doing, who you talked to, what was hard, how it felt. Don't read them out like a "
            f"file or recite the [citations]. Anything not in here, you don't remember, so don't make it up.]")
    out = [head]
    used = len(head)
    # Several days with fewer lines each reads more like memory than one day
    # in full: give each chapter an even share and shrink it to fit.
    # Picked by how full they are, told in the order they happened.
    chapters = sorted(res["chapters"], key=lambda ch: ch["start"])
    for i, ch in enumerate(chapters):
        share = (max_chars - used) // max(1, len(chapters) - i)
        txt = ""
        for n in (5, 4, 3, 2):
            txt = lc.format_chapter(ch, max_claims=n, quote_chars=140, records_summary=False,
                                    about=topic or None)
            if len(txt) + 1 <= share:
                break
        if used + len(txt) + 1 > max_chars:
            txt = txt[: max(0, max_chars - used - 2)].rsplit("\n", 1)[0]
        if not txt.strip():
            break
        out.append(txt)
        used += len(txt) + 1
    return "\n".join(out)

