"""Inert compatibility hook for installed, explicitly selected narration routes."""
import sys


def select(group):
    module = sys.modules.get("brain.cognition.inference_scheduler")
    if module is None:
        return None
    scheduler = module.route(group)
    return (module, scheduler) if scheduler is not None else None


def collect(selection, **kwargs):
    module, scheduler = selection
    return module.collect_narration(scheduler, **kwargs)
