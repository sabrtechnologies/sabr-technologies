"""Bounded memory updates for persistent CLI sessions (no model calls)."""
from __future__ import annotations

import hashlib
import sqlite3


def memory_delta(session, blocks: dict[str, str]) -> tuple[str, dict]:
    """Send changed sections once per child; a new child gets a fresh seed.

    The caller commits the returned fingerprint map only after a successful
    response. Failed delivery must not make the next turn forget its context.
    """
    old = getattr(session, "_memory_fingerprints", {}) if session else {}
    current, parts = {}, []
    for name, value in blocks.items():
        digest = hashlib.sha256(value.encode()).hexdigest()
        current[name] = digest
        if old.get(name) != digest and (value or name in old):
            parts.append(f"[{name} — current snapshot, replaces earlier snapshot:]\n"
                         + (value or "(empty)"))
    return "\n\n".join(parts), current


def conversation_delta(store, after_id: int = 0, limit: int = 12):
    """Read only unseen turns, bounded for cold starts and cross-lane handoff."""
    if store is None:
        return "", after_id
    with sqlite3.connect(store.db_path, timeout=5) as conn:
        rows = conn.execute(
            "SELECT id, role, content FROM conversation_history "
            "WHERE session_id=? AND id>? ORDER BY id DESC LIMIT ?",
            (store.session_id, after_id, limit),
        ).fetchall()
    lines = []
    for _, role, content in reversed(rows):
        if isinstance(content, str) and not content.startswith("__BLOCKS__"):
            lines.append(f"{role}: {content[:800]}")
    return "\n".join(lines), max([after_id] + [r[0] for r in rows])
