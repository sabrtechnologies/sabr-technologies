"""Cancellable urllib HTTP/HTTPS transport for inference calls.

Cancellation shuts down only this request's socket. It never closes a response
from a second thread (buffered response.close can wait for the blocked reader).
DNS and connection setup still depend on their configured network timeout.
"""
import functools
import http.client
import socket
import threading
import urllib.request

URLOPEN_AT_IMPORT = urllib.request.urlopen


def shutdown(sock):
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except Exception:
        pass


class SocketHolder:
    def __init__(self):
        self.sock = None
        self.cancelled = False
        self.mu = threading.Lock()

    def set(self, sock):
        with self.mu:
            self.sock = sock
            cancelled = self.cancelled
        if cancelled:
            shutdown(sock)

    def kill(self, _reason=None):
        with self.mu:
            self.cancelled = True
            sock = self.sock
        if sock is not None:
            shutdown(sock)


class _TrackedConnection:
    def __init__(self, *args, v2_holder=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._v2_holder = v2_holder
        create = self._create_connection

        def tracked_create(*args, **kwargs):
            sock = create(*args, **kwargs)
            if self._v2_holder is not None:
                # Track before proxy/TLS setup can block, then track the wrapped
                # socket again once connect finishes.
                self._v2_holder.set(sock)
            return sock
        self._create_connection = tracked_create

    def connect(self):
        if self._v2_holder is not None and self._v2_holder.cancelled:
            raise OSError("inference request cancelled before connect")
        super().connect()
        if self._v2_holder is not None:
            self._v2_holder.set(self.sock)


class TrackedHTTPConnection(_TrackedConnection, http.client.HTTPConnection):
    pass


class TrackedHTTPSConnection(_TrackedConnection, http.client.HTTPSConnection):
    def connect(self):
        if self._v2_holder is not None and self._v2_holder.cancelled:
            raise OSError("inference request cancelled before connect")
        # Match HTTPSConnection's proxy and hostname behavior, but register the
        # wrapped socket before its handshake. wrap_socket detaches the raw
        # socket, so holding only the raw socket cannot interrupt TLS setup.
        http.client.HTTPConnection.connect(self)
        hostname = self._tunnel_host or self.host
        self.sock = self._context.wrap_socket(self.sock, server_hostname=hostname,
                                              do_handshake_on_connect=False)
        if self._v2_holder is not None:
            self._v2_holder.set(self.sock)
        self.sock.do_handshake()


class TrackedHTTPHandler(urllib.request.HTTPHandler):
    def __init__(self, holder):
        super().__init__()
        self._v2_holder = holder

    def http_open(self, req):
        return self.do_open(functools.partial(TrackedHTTPConnection,
                                             v2_holder=self._v2_holder), req)


class TrackedHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, holder):
        super().__init__()
        self._v2_holder = holder

    def https_open(self, req):
        return self.do_open(functools.partial(TrackedHTTPSConnection,
                                             v2_holder=self._v2_holder), req,
                            context=self._context)


def open_cancellable(req, timeout, cancel_token=None):
    """Return (response, unregister_callback), preserving urlopen when inert.

    Replaced urlopen functions are honored for compatibility/test transports.
    All callbacks must be unregistered in the caller's finally block.
    """
    if cancel_token is not None and cancel_token.is_set():
        raise OSError("inference request cancelled before open")
    url = str(getattr(req, "full_url", req))
    if (cancel_token is None or urllib.request.urlopen is not URLOPEN_AT_IMPORT
            or not url.startswith(("http://", "https://"))):
        return urllib.request.urlopen(req, timeout=timeout), None
    holder = SocketHolder()
    opener = urllib.request.build_opener(TrackedHTTPHandler(holder), TrackedHTTPSHandler(holder))
    unhook = cancel_token.add_callback(holder.kill)
    try:
        return opener.open(req, timeout=timeout), unhook
    except BaseException:
        unhook()
        raise
