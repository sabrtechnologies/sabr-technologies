"""
Daydream Engine — spontaneous concept association via quantum noise.

During idle periods (no user input, default mode network dominant),
quantum noise fires hippocampal neurons randomly. When the resulting
firing pattern matches a known concept strongly enough, that concept
has been "thought of" without any external trigger.

If the concept has strong emotional valence (high cumulative reward),
it gets surfaced to the consciousness system. Leon might bring up a
topic Dean hasn't mentioned in days — not because of a cron job, but
because quantum noise happened to activate the right neurons.

This is the mechanism that makes the brain feel alive. Unprompted
thoughts that even the system itself couldn't predict.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("leon.daydream")


@dataclass
class DaydreamEvent:
    """A spontaneously activated concept."""
    concept: str
    match_strength: float
    emotional_valence: float  # cumulative_reward of the concept
    timestamp: float
    emotional_centroid: Dict[str, float]


class DaydreamEngine:
    """Monitors hippocampal firing patterns for spontaneous concept matches.

    Runs on a background thread, checking every `interval_s` seconds.
    Only active when the brain is idle (no recent user input).

    When multiple concepts match, they enter QUANTUM SUPERPOSITION and
    the measurement selects which one surfaces. The concept Leon thinks
    about doesn't exist until the quantum state collapses.
    """

    def __init__(
        self,
        brain,
        concept_map,
        on_daydream: Optional[Callable[[DaydreamEvent], None]] = None,
        interval_s: float = 5.0,
        idle_threshold_s: float = 30.0,
        match_threshold: float = 0.25,
        valence_threshold: float = 0.5,
        quantum_consciousness=None,
    ):
        self.brain = brain
        self.concept_map = concept_map
        self.on_daydream = on_daydream
        self.interval_s = interval_s
        self.idle_threshold_s = idle_threshold_s
        self.match_threshold = match_threshold
        self.valence_threshold = valence_threshold
        self.quantum_consciousness = quantum_consciousness

        self._last_user_input: float = time.time()
        self._recent_daydreams: List[DaydreamEvent] = []
        self._max_history = 50
        self._cooldown: Dict[str, float] = {}  # concept → last surfaced time
        self._cooldown_s = 300.0  # don't re-surface the same concept within 5 min

        self._running = False
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def note_user_activity(self):
        """Called when Dean sends a message — resets idle timer."""
        self._last_user_input = time.time()

    def start(self):
        if self._running:
            return
        self._running = True
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="DaydreamEngine", daemon=True
        )
        self._thread.start()
        log.info("DaydreamEngine started (interval=%.1fs, idle_threshold=%.1fs)",
                 self.interval_s, self.idle_threshold_s)

    def stop(self):
        self._running = False
        self._stop.set()

    def _loop(self):
        while not self._stop.is_set():
            self._stop.wait(self.interval_s)
            if self._stop.is_set():
                break
            try:
                self._tick()
            except Exception as e:
                log.debug("DaydreamEngine tick error: %s", e)

    def _tick(self):
        """One daydream check cycle.

        When multiple concepts match the hippocampal firing pattern, they
        enter quantum superposition. The quantum measurement selects which
        concept surfaces — the thought doesn't exist until collapse.
        """
        # Only daydream when idle
        idle_duration = time.time() - self._last_user_input
        if idle_duration < self.idle_threshold_s:
            return

        # Get hippocampal firing pattern
        firing = self.brain.get_hippocampal_firing()
        if firing is None:
            return

        # Match against known concepts
        matches = self.concept_map.match_firing_pattern(
            firing, threshold=self.match_threshold
        )
        if not matches:
            return

        now = time.time()

        # ── Collect all valid candidates for quantum superposition ──
        candidates = []  # (concept_name, strength, concept_obj)
        for concept_name, strength in matches[:8]:  # up to 8 candidates
            # Cooldown check
            last = self._cooldown.get(concept_name, 0)
            if now - last < self._cooldown_s:
                continue
            # Existence check
            concept = self.concept_map._concepts.get(concept_name)
            if concept is None:
                continue
            # Emotional significance
            if abs(concept.cumulative_reward) < self.valence_threshold:
                continue
            candidates.append((concept_name, strength, concept))

        if not candidates:
            return

        # ── Quantum decision: which concept surfaces? ───────────────
        # All candidates exist in superposition. The brain state shapes
        # the interference. Measurement collapses to one thought.
        if len(candidates) >= 2 and self.quantum_consciousness is not None:
            try:
                decision = self.quantum_consciousness.decide(
                    candidates=[c[0] for c in candidates],
                    scores=[c[1] for c in candidates],
                    labels=[c[0] for c in candidates],
                    context="daydream",
                )
                winner_idx = decision.chosen_index
            except Exception as e:
                log.debug("Quantum daydream decision failed: %s", e)
                winner_idx = 0
        else:
            winner_idx = 0

        concept_name, strength, concept = candidates[winner_idx]
        valence = concept.cumulative_reward

        # ── Surface the chosen concept ──────────────────────────────
        event = DaydreamEvent(
            concept=concept_name,
            match_strength=strength,
            emotional_valence=valence,
            timestamp=now,
            emotional_centroid={
                "dopamine": concept.emo_dopamine,
                "serotonin": concept.emo_serotonin,
                "acetylcholine": concept.emo_acetylcholine,
                "norepinephrine": concept.emo_norepinephrine,
            },
        )

        self._recent_daydreams.append(event)
        if len(self._recent_daydreams) > self._max_history:
            self._recent_daydreams = self._recent_daydreams[-self._max_history:]
        self._cooldown[concept_name] = now

        log.info("DAYDREAM: '%s' (strength=%.2f, valence=%.2f, "
                 "quantum=%s, candidates=%d)",
                 concept_name, strength, valence,
                 self.quantum_consciousness is not None,
                 len(candidates))

        # Surprise interrupt
        try:
            surprise_intensity = min(0.6, abs(valence) * 0.3 + strength * 0.15)
            self.brain.inject_surprise(surprise_intensity,
                                       source=f"daydream:{concept_name}")
        except Exception:
            pass

        # Reconsolidate emotional state
        try:
            self.brain.reconsolidate([{
                "dopamine": concept.emo_dopamine,
                "serotonin": concept.emo_serotonin,
                "acetylcholine": concept.emo_acetylcholine,
                "norepinephrine": concept.emo_norepinephrine,
            }], weight=0.08)
        except Exception:
            pass

        # Callback — surface to consciousness
        if self.on_daydream is not None:
            try:
                self.on_daydream(event)
            except Exception as e:
                log.debug("Daydream callback failed: %s", e)

    def get_state(self) -> dict:
        idle_s = time.time() - self._last_user_input
        return {
            "running": self._running,
            "idle_seconds": round(idle_s, 1),
            "is_idle": idle_s >= self.idle_threshold_s,
            "recent_daydreams": [
                {
                    "concept": d.concept,
                    "strength": round(d.match_strength, 3),
                    "valence": round(d.emotional_valence, 3),
                    "ago_s": round(time.time() - d.timestamp, 1),
                }
                for d in self._recent_daydreams[-10:]
            ],
            "total_daydreams": len(self._recent_daydreams),
        }
