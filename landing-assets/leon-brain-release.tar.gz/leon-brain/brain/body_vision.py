"""On-demand visual reasoning on Leon's Dell body.

The VPS holds the primary 35B reasoning model.  Its remaining RAM is not
enough to keep a second vision model warm, while the Dell has an idle Quadro
and ample system memory.  This client sends one user-requested screen/webcam
frame to the authenticated Dell body relay and returns its concise answer.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any, Dict


def _vision_url() -> str:
    relay = os.environ.get("LEON_PC_RELAY_URL", "").rstrip("/")
    if relay.endswith("/actuator"):
        return relay[:-len("/actuator")] + "/vision"
    return relay + "/vision" if relay else ""


def describe(image_b64: str, prompt: str, timeout: float = 100.0) -> Dict[str, Any]:
    """Analyze one supplied image through the Dell's local vision model."""
    url = _vision_url()
    if not url:
        return {"ok": False, "error": "Dell body relay is not configured"}
    if not image_b64:
        return {"ok": False, "error": "empty image"}
    headers = {"Content-Type": "application/json"}
    api_key = os.environ.get("LEON_API_KEY", "")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    payload = json.dumps({"image_b64": image_b64, "prompt": prompt or ""}).encode("utf-8")
    request = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        return {"ok": False, "error": f"Dell vision relay rejected the frame ({exc.code})"}
    except Exception as exc:
        return {"ok": False, "error": f"Dell vision relay unavailable: {type(exc).__name__}"}
    if not data.get("ok"):
        return {"ok": False, "error": data.get("error", "Dell vision failed")}
    result = data.get("result") or {}
    answer = str(result.get("answer") or "").strip()
    if not answer:
        return {"ok": False, "error": "Dell vision returned no answer"}
    return {"ok": True, "result": {
        "answer": answer,
        "via": "dell_local_vision",
        "model": result.get("model", ""),
        "face_count": result.get("face_count"),
        "image_adjustment": result.get("image_adjustment"),
    }}
