"""
Seed core facts into Leon's neural knowledge store at HIGH strength.

These aren't prompt injections — they're real memories stored in the same
knowledge.db that conversations and experiences go into, but with strength=1.0
so they always surface during recall. The neural encoder gives them real
fingerprints (which brain regions fire when processing each fact).

Run once, or re-run to update. Idempotent — checks for existing entries
by source tag and replaces them.

Usage:
    python3 -m brain.seed_core_facts          # from Leon root
    python3 brain/seed_core_facts.py          # direct
"""

import os
import sqlite3
import time

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DB = os.path.join(_ROOT, "brain_state", "knowledge.db")

# Owner facts live in a separate LEON-ONLY file that is not shipped to
# clients. If it is absent (client build), CORE_FACTS is empty so nothing
# personal can be seeded or leaked.
_IMPORT_ERROR = None
try:
    from brain.owner_facts import OWNER_FACTS as CORE_FACTS
except ModuleNotFoundError as e:
    # Only a genuinely ABSENT file means "client build". Anything else
    # (SyntaxError, bad quote, ImportError inside the module) is a broken
    # owner file and must NOT be treated as "no facts".
    if getattr(e, "name", "") == "brain.owner_facts":
        CORE_FACTS = []
    else:
        CORE_FACTS, _IMPORT_ERROR = [], e
except Exception as e:
    CORE_FACTS, _IMPORT_ERROR = [], e

SOURCE_TAG = "core_fact_seed"


def seed():
    # ── FAIL CLOSED (added 2026-08-30) ─────────────────────────────────
    # On 2026-08-30 a stray double quote made owner_facts.py a SyntaxError;
    # the bare `except: CORE_FACTS = []` above swallowed it and this
    # function then DELETED all 59 permanent facts and rendered an empty
    # core_facts.md. A memory wipe must never be the failure mode of a typo.
    if _IMPORT_ERROR is not None:
        print(f"[CORE_FACTS] ABORT — brain/owner_facts.py failed to import "
              f"({type(_IMPORT_ERROR).__name__}: {_IMPORT_ERROR}). "
              f"Nothing deleted, nothing rendered. Fix the file and re-run.")
        raise SystemExit(2)
    conn = sqlite3.connect(_DB, timeout=30)
    c = conn.cursor()
    existing = c.execute("SELECT COUNT(*) FROM knowledge WHERE source = ?",
                         (SOURCE_TAG,)).fetchone()[0]
    if not CORE_FACTS and existing:
        print(f"[CORE_FACTS] ABORT — owner facts list is EMPTY but the DB holds "
              f"{existing} seeded facts. Refusing to wipe permanent memory.")
        conn.close()
        raise SystemExit(3)

    # Remove old seeds so re-running updates cleanly
    c.execute("DELETE FROM knowledge WHERE source = ?", (SOURCE_TAG,))
    removed = c.rowcount

    now = time.time()
    inserted = 0
    for text, tags in CORE_FACTS:
        c.execute(
            """INSERT INTO knowledge
               (text, source, tags, timestamp, neural_fingerprint, metadata,
                access_count, last_access, strength,
                emo_dopamine, emo_serotonin, emo_acetylcholine, emo_norepinephrine)
               VALUES (?, ?, ?, ?, '', '{"core_fact": true}',
                       100, ?, 1.0,
                       0.7, 0.5, 0.4, 0.2)""",
            (text, SOURCE_TAG, tags, now, now),
        )
        inserted += 1

    conn.commit()
    conn.close()

    # ── Encode fingerprints so background recall (spontaneous association
    # via brain-state similarity) can surface these facts. Without this
    # step the rows are FTS-searchable but invisible to the proactive
    # loop's `recall_by_fingerprint` path — i.e. Leon's foreground
    # `knowledge_search` tool finds them, but his idle-loop "intrusive
    # thought" path doesn't. The projection encoder is deterministic
    # (PROJECTION_SEED=47) so backfilled fingerprints match what the live
    # in-process encoder would produce for the same text.
    encoded = 0
    try:
        from brain.neural_encoder import NeuralEncoder
        from brain.knowledge_store import (
            KnowledgeStore, backfill_neural_fingerprints,
        )
        encoder = NeuralEncoder()
        store = KnowledgeStore(_DB)
        encoded = backfill_neural_fingerprints(store, encoder,
                                                only_missing=True)
    except Exception as e:
        print(f"[CORE_FACTS] fingerprint backfill skipped: {e}")

    print(f"[CORE_FACTS] Seeded {inserted} facts (removed {removed} old, "
          f"backfilled {encoded} fingerprints). Strength=1.0, "
          f"access_count=100.")

    # ── Render core_facts.md from the SAME tuple ─────────────────────
    # The [CORE FACTS] block injected into every prompt reads
    # brain_state/core_facts.md directly. Before 2026-06-11 that file
    # was hand-maintained and drifted badly stale (still said Spark 8
    # was a "label/sticker business" weeks after this seed was corrected
    # to SMOKE SHOP; missing several clients, projects, and the 47 founders).
    # Leon found the symptom himself during self-debugging. Generating
    # the md from CORE_FACTS makes drift impossible — edit CORE_FACTS
    # above, re-run this module, both stores update together.
    md_path = os.path.join(os.path.dirname(_DB), "core_facts.md")
    try:
        lines = [
            "# Core Facts — PERMANENT MEMORY (never forget these)",
            "",
            "<!-- AUTO-GENERATED by brain/seed_core_facts.py. Do NOT hand-edit:",
            "     edit CORE_FACTS in that file, then run",
            "     python3 -m brain.seed_core_facts -->",
            "",
        ]
        lines += [f"- {text}" for text, _tags in CORE_FACTS]
        tmp = md_path + ".tmp"
        with open(tmp, "w") as f:
            f.write("\n".join(lines) + "\n")
        os.replace(tmp, md_path)
        print(f"[CORE_FACTS] Rendered {md_path} ({len(CORE_FACTS)} facts).")
    except Exception as e:
        print(f"[CORE_FACTS] md render FAILED ({e}) — the [CORE FACTS] "
              f"prompt block stays stale until this is fixed.")


if __name__ == "__main__":
    seed()
