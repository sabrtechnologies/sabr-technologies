"""
calendar_power.py — Leon's deep calendar tool surface.

Gives Leon real control over Dean's calendar: Google Calendar (full CRUD,
quick-add, free/busy), generic CalDAV, smart scheduling (free-slot finding,
meeting-time suggestions, focus-time blocking, day-load), and a local SQLite
event store that always works with no credentials.

Credential sources (read lazily, never logged):
  - Google Calendar: OAuth token store at
    `~/.openclaw/google-oauth/tokens.json` (flat JSON: access_token,
    refresh_token, expiry_date, token_type). Auto-refreshes against
    `~/.openclaw/google-oauth/credentials.json` when expired. Override the
    access token outright with env `GCAL_ACCESS_TOKEN`.
  - CalDAV: env `CALDAV_URL`, `CALDAV_USER`, `CALDAV_PASSWORD`.
  - Local store: SQLite `brain_state/calendar_local.db` (auto-created).

Every tool takes a single `args` dict and returns the standard `{ok, ...}`
contract used by the rest of the brain. Nothing here raises — every
exception is wrapped into `{"ok": False, "error": "<type>: <msg>"}`.

`EXTRA_TOOLS` at the bottom maps dotted names (e.g. `cal.events_today`)
to callables. Import that dict from the responder / MCP server.

Style matches `brain/integrations/comms.py` (credential handling, `_err`)
and `brain/integrations/productivity.py` (SQLite local store).
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import threading
import time
import xml.etree.ElementTree as ET
from datetime import datetime, date, time as dtime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests


# ──────────────────────────────────────────────────────────────────────────
# CONSTANTS & PATHS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 12.0
_GCAL_BASE = "https://www.googleapis.com/calendar/v3"
_GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"

_GOOGLE_DIR = Path.home() / ".openclaw" / "google-oauth"
_TOKENS_PATH = _GOOGLE_DIR / "tokens.json"
_CREDS_PATH = _GOOGLE_DIR / "credentials.json"


def _project_root() -> str:
    """Project directory (parent of brain/). This file is two levels deep."""
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "calendar_local.db")


def _err(e: Exception) -> Dict[str, Any]:
    """Standard error wrapper — type + message, never a traceback."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# DATETIME HELPERS  (stdlib only)
# ──────────────────────────────────────────────────────────────────────────


def _now() -> datetime:
    """Timezone-aware local now."""
    return datetime.now().astimezone()


def _parse_iso(s: str) -> datetime:
    """Parse an ISO-8601 string into an aware datetime.

    Accepts trailing 'Z', date-only strings, and naive strings (assumed
    local). Always returns an aware datetime.
    """
    if not s:
        raise ValueError("empty datetime string")
    txt = str(s).strip()
    if txt.endswith("Z"):
        txt = txt[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(txt)
    except ValueError:
        # date-only
        dt = datetime.fromisoformat(txt + "T00:00:00")
    if dt.tzinfo is None:
        dt = dt.astimezone()
    return dt


def _to_iso(dt: datetime) -> str:
    """Aware datetime -> ISO-8601 string with offset."""
    if dt.tzinfo is None:
        dt = dt.astimezone()
    return dt.isoformat()


def _to_rfc3339(dt: datetime) -> str:
    """Google wants RFC3339; isoformat() on an aware dt already is."""
    return _to_iso(dt)


def _day_bounds(d: date) -> Tuple[datetime, datetime]:
    """Start (00:00) and end (23:59:59.999999) of a local calendar day."""
    tz = _now().tzinfo
    start = datetime.combine(d, dtime(0, 0, 0), tzinfo=tz)
    end = datetime.combine(d, dtime(23, 59, 59, 999999), tzinfo=tz)
    return start, end


def _parse_date_arg(s: Optional[str]) -> date:
    """Parse a date-ish arg ('2026-05-14', ISO datetime, None=today)."""
    if not s:
        return _now().date()
    return _parse_iso(s).date()


def _parse_hhmm(s: str, on_day: date) -> datetime:
    """Combine 'HH:MM' with a date into an aware local datetime."""
    h, m = s.split(":")
    tz = _now().tzinfo
    return datetime.combine(on_day, dtime(int(h), int(m)), tzinfo=tz)


def _fmt_event_dt(node: Optional[dict]) -> Optional[str]:
    """Pull the human string from a Google event start/end node."""
    if not node:
        return None
    return node.get("dateTime") or node.get("date")


def _event_dt(node: Optional[dict]) -> Optional[datetime]:
    """Pull an aware datetime from a Google event start/end node."""
    if not node:
        return None
    raw = node.get("dateTime") or node.get("date")
    if not raw:
        return None
    try:
        return _parse_iso(raw)
    except Exception:
        return None


# ──────────────────────────────────────────────────────────────────────────
# GOOGLE CALENDAR — AUTH
# ──────────────────────────────────────────────────────────────────────────

_TOKEN_LOCK = threading.Lock()
_TOKEN_CACHE: Optional[Dict[str, Any]] = None
_TOKEN_MTIME: float = 0.0


def _load_tokens() -> Dict[str, Any]:
    """Load (and cache, mtime-checked) the OAuth token store. {} on error."""
    global _TOKEN_CACHE, _TOKEN_MTIME
    try:
        if not _TOKENS_PATH.exists():
            return {}
        mtime = _TOKENS_PATH.stat().st_mtime
        if _TOKEN_CACHE is not None and mtime == _TOKEN_MTIME:
            return dict(_TOKEN_CACHE)
        with open(_TOKENS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _TOKEN_CACHE = data
        _TOKEN_MTIME = mtime
        return dict(data)
    except Exception:
        return {}


def _save_tokens(data: Dict[str, Any]) -> None:
    """Persist a refreshed token store; failure is non-fatal."""
    global _TOKEN_CACHE, _TOKEN_MTIME
    try:
        _GOOGLE_DIR.mkdir(parents=True, exist_ok=True)
        with open(_TOKENS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        _TOKEN_CACHE = data
        _TOKEN_MTIME = _TOKENS_PATH.stat().st_mtime
    except Exception:
        pass


def _load_client_creds() -> Dict[str, str]:
    """Load the OAuth client_id/client_secret. Handles google's wrapper
    shapes ({"installed": {...}} / {"web": {...}}) and flat objects."""
    try:
        if not _CREDS_PATH.exists():
            return {}
        with open(_CREDS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        for wrapper in ("installed", "web"):
            if isinstance(data.get(wrapper), dict):
                data = data[wrapper]
                break
        return {
            "client_id": data.get("client_id", ""),
            "client_secret": data.get("client_secret", ""),
        }
    except Exception:
        return {}


def _refresh_access_token() -> Optional[str]:
    """Use the stored refresh_token to mint a new access token. Persists
    the new token. Returns the access token or None."""
    tokens = _load_tokens()
    refresh = tokens.get("refresh_token")
    creds = _load_client_creds()
    if not (refresh and creds.get("client_id") and creds.get("client_secret")):
        return None
    try:
        resp = requests.post(
            _GOOGLE_TOKEN_URL,
            data={
                "client_id": creds["client_id"],
                "client_secret": creds["client_secret"],
                "refresh_token": refresh,
                "grant_type": "refresh_token",
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code != 200:
            return None
        body = resp.json()
        access = body.get("access_token")
        if not access:
            return None
        tokens["access_token"] = access
        if body.get("expires_in"):
            tokens["expiry_date"] = int(
                time.time() * 1000 + int(body["expires_in"]) * 1000
            )
        _save_tokens(tokens)
        return access
    except Exception:
        return None


def _gcal_access_token(force_refresh: bool = False) -> Optional[str]:
    """Resolve a usable Google access token.

    Priority: env GCAL_ACCESS_TOKEN > stored token (if unexpired) >
    refreshed token. Returns None when nothing is available.
    """
    env = os.environ.get("GCAL_ACCESS_TOKEN", "").strip()
    if env and not force_refresh:
        return env
    with _TOKEN_LOCK:
        if force_refresh:
            return _refresh_access_token()
        tokens = _load_tokens()
        access = tokens.get("access_token")
        expiry = tokens.get("expiry_date")
        if access and expiry:
            # expiry_date is epoch ms; refresh 60s early
            if time.time() * 1000 < (int(expiry) - 60_000):
                return access
            return _refresh_access_token() or access
        if access:
            return access
        return _refresh_access_token()


def _gcal_request(
    method: str,
    path: str,
    params: Optional[dict] = None,
    body: Optional[dict] = None,
) -> Dict[str, Any]:
    """Make an authenticated Google Calendar API call.

    Retries once with a forced token refresh on a 401. Returns either the
    decoded JSON (a dict) or a `{"ok": False, "error": ...}` dict — callers
    must check for an "ok" key.
    """
    token = _gcal_access_token()
    if not token:
        return {
            "ok": False,
            "error": "No Google Calendar credentials. Run "
            "`openclaw-mcp auth:google` or set GCAL_ACCESS_TOKEN.",
        }
    url = _GCAL_BASE + path
    for attempt in (1, 2):
        try:
            resp = requests.request(
                method,
                url,
                headers={"Authorization": f"Bearer {token}"},
                params=params,
                json=body,
                timeout=_DEFAULT_TIMEOUT,
            )
        except Exception as e:
            return _err(e)
        if resp.status_code == 401 and attempt == 1:
            token = _gcal_access_token(force_refresh=True)
            if not token:
                return {"ok": False, "error": "Google auth failed (401)."}
            continue
        if resp.status_code == 204:
            return {"_raw": True}
        if resp.status_code >= 400:
            detail = resp.text[:300]
            try:
                detail = resp.json().get("error", {}).get("message", detail)
            except Exception:
                pass
            return {
                "ok": False,
                "error": f"Google API {resp.status_code}: {detail}",
            }
        try:
            return resp.json()
        except Exception:
            return {"_raw": True}
    return {"ok": False, "error": "Google API call failed."}


def _slim_event(ev: dict) -> Dict[str, Any]:
    """Reduce a verbose Google event object to the fields Leon cares about."""
    return {
        "id": ev.get("id"),
        "summary": ev.get("summary", "(no title)"),
        "start": _fmt_event_dt(ev.get("start")),
        "end": _fmt_event_dt(ev.get("end")),
        "location": ev.get("location"),
        "description": ev.get("description"),
        "status": ev.get("status"),
        "html_link": ev.get("htmlLink"),
        "attendees": [
            {
                "email": a.get("email"),
                "name": a.get("displayName"),
                "response": a.get("responseStatus"),
            }
            for a in ev.get("attendees", [])
        ]
        or None,
        "recurring": bool(ev.get("recurringEventId") or ev.get("recurrence")),
        "recurring_event_id": ev.get("recurringEventId"),
        "organizer": (ev.get("organizer") or {}).get("email"),
        "all_day": "date" in (ev.get("start") or {}),
    }


def _list_events_raw(
    calendar_id: str,
    time_min: datetime,
    time_max: datetime,
    single_events: bool = True,
    max_results: int = 250,
) -> Any:
    """Shared event-list call. Returns a list of raw events or an error dict."""
    params = {
        "timeMin": _to_rfc3339(time_min),
        "timeMax": _to_rfc3339(time_max),
        "maxResults": max_results,
        "orderBy": "startTime" if single_events else None,
        "singleEvents": "true" if single_events else "false",
    }
    params = {k: v for k, v in params.items() if v is not None}
    data = _gcal_request(
        "GET", f"/calendars/{requests.utils.quote(calendar_id, safe='')}/events",
        params=params,
    )
    if isinstance(data, dict) and data.get("ok") is False:
        return data
    return data.get("items", []) if isinstance(data, dict) else []


# ──────────────────────────────────────────────────────────────────────────
# GOOGLE CALENDAR — TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _cal_list_calendars(args: dict) -> dict:
    try:
        data = _gcal_request("GET", "/users/me/calendarList")
        if isinstance(data, dict) and data.get("ok") is False:
            return data
        cals = [
            {
                "id": c.get("id"),
                "summary": c.get("summary"),
                "primary": bool(c.get("primary")),
                "access_role": c.get("accessRole"),
                "timezone": c.get("timeZone"),
            }
            for c in data.get("items", [])
        ]
        return {"ok": True, "calendars": cals, "count": len(cals)}
    except Exception as e:
        return _err(e)


def _cal_events_today(args: dict) -> dict:
    try:
        cal = args.get("calendar_id", "primary")
        start, end = _day_bounds(_now().date())
        evs = _list_events_raw(cal, start, end)
        if isinstance(evs, dict):
            return evs
        slim = [_slim_event(e) for e in evs]
        return {"ok": True, "date": _now().date().isoformat(),
                "events": slim, "count": len(slim)}
    except Exception as e:
        return _err(e)


def _cal_events_upcoming(args: dict) -> dict:
    try:
        cal = args.get("calendar_id", "primary")
        days = int(args.get("days", 7))
        start = _now()
        end = start + timedelta(days=days)
        evs = _list_events_raw(cal, start, end)
        if isinstance(evs, dict):
            return evs
        slim = [_slim_event(e) for e in evs]
        return {"ok": True, "days": days, "events": slim, "count": len(slim)}
    except Exception as e:
        return _err(e)


def _cal_events_range(args: dict) -> dict:
    try:
        cal = args.get("calendar_id", "primary")
        start_iso = args.get("start_iso")
        end_iso = args.get("end_iso")
        if not (start_iso and end_iso):
            return {"ok": False, "error": "start_iso and end_iso required."}
        evs = _list_events_raw(cal, _parse_iso(start_iso), _parse_iso(end_iso))
        if isinstance(evs, dict):
            return evs
        slim = [_slim_event(e) for e in evs]
        return {"ok": True, "events": slim, "count": len(slim)}
    except Exception as e:
        return _err(e)


def _cal_event_get(args: dict) -> dict:
    try:
        event_id = args.get("event_id")
        if not event_id:
            return {"ok": False, "error": "event_id required."}
        cal = args.get("calendar_id", "primary")
        data = _gcal_request(
            "GET",
            f"/calendars/{requests.utils.quote(cal, safe='')}/events/"
            f"{requests.utils.quote(event_id, safe='')}",
        )
        if isinstance(data, dict) and data.get("ok") is False:
            return data
        return {"ok": True, "event": _slim_event(data), "raw": data}
    except Exception as e:
        return _err(e)


def _cal_event_create(args: dict) -> dict:
    try:
        summary = args.get("summary")
        start_iso = args.get("start_iso")
        end_iso = args.get("end_iso")
        if not (summary and start_iso and end_iso):
            return {"ok": False,
                    "error": "summary, start_iso, end_iso required."}
        cal = args.get("calendar_id", "primary")
        body: Dict[str, Any] = {
            "summary": summary,
            "start": {"dateTime": _to_rfc3339(_parse_iso(start_iso))},
            "end": {"dateTime": _to_rfc3339(_parse_iso(end_iso))},
        }
        if args.get("description"):
            body["description"] = args["description"]
        if args.get("location"):
            body["location"] = args["location"]
        attendees = args.get("attendees")
        if attendees:
            if isinstance(attendees, str):
                attendees = [a.strip() for a in attendees.split(",")
                             if a.strip()]
            body["attendees"] = [{"email": a} for a in attendees]
        data = _gcal_request(
            "POST", f"/calendars/{requests.utils.quote(cal, safe='')}/events",
            body=body,
        )
        if isinstance(data, dict) and data.get("ok") is False:
            return data
        return {"ok": True, "created": _slim_event(data)}
    except Exception as e:
        return _err(e)


def _cal_event_update(args: dict) -> dict:
    try:
        event_id = args.get("event_id")
        if not event_id:
            return {"ok": False, "error": "event_id required."}
        cal = args.get("calendar_id", "primary")
        body: Dict[str, Any] = {}
        if "summary" in args:
            body["summary"] = args["summary"]
        if "description" in args:
            body["description"] = args["description"]
        if "location" in args:
            body["location"] = args["location"]
        if args.get("start_iso"):
            body["start"] = {
                "dateTime": _to_rfc3339(_parse_iso(args["start_iso"]))}
        if args.get("end_iso"):
            body["end"] = {
                "dateTime": _to_rfc3339(_parse_iso(args["end_iso"]))}
        if "attendees" in args and args["attendees"]:
            att = args["attendees"]
            if isinstance(att, str):
                att = [a.strip() for a in att.split(",") if a.strip()]
            body["attendees"] = [{"email": a} for a in att]
        if not body:
            return {"ok": False, "error": "No fields to update."}
        data = _gcal_request(
            "PATCH",
            f"/calendars/{requests.utils.quote(cal, safe='')}/events/"
            f"{requests.utils.quote(event_id, safe='')}",
            body=body,
        )
        if isinstance(data, dict) and data.get("ok") is False:
            return data
        return {"ok": True, "updated": _slim_event(data)}
    except Exception as e:
        return _err(e)


def _cal_event_delete(args: dict) -> dict:
    try:
        event_id = args.get("event_id")
        if not event_id:
            return {"ok": False, "error": "event_id required."}
        cal = args.get("calendar_id", "primary")
        data = _gcal_request(
            "DELETE",
            f"/calendars/{requests.utils.quote(cal, safe='')}/events/"
            f"{requests.utils.quote(event_id, safe='')}",
        )
        if isinstance(data, dict) and data.get("ok") is False:
            return data
        return {"ok": True, "deleted": event_id}
    except Exception as e:
        return _err(e)


def _cal_event_quick_add(args: dict) -> dict:
    try:
        text = args.get("text")
        if not text:
            return {"ok": False, "error": "text required."}
        cal = args.get("calendar_id", "primary")
        data = _gcal_request(
            "POST",
            f"/calendars/{requests.utils.quote(cal, safe='')}/events/quickAdd",
            params={"text": text},
        )
        if isinstance(data, dict) and data.get("ok") is False:
            return data
        return {"ok": True, "created": _slim_event(data)}
    except Exception as e:
        return _err(e)


def _cal_event_respond(args: dict) -> dict:
    try:
        event_id = args.get("event_id")
        response = (args.get("response") or "").lower()
        if not event_id:
            return {"ok": False, "error": "event_id required."}
        valid = {"accepted", "declined", "tentative", "needsaction"}
        if response not in valid:
            return {"ok": False,
                    "error": f"response must be one of {sorted(valid)}."}
        cal = args.get("calendar_id", "primary")
        # find which attendee entry is "self"
        get = _gcal_request(
            "GET",
            f"/calendars/{requests.utils.quote(cal, safe='')}/events/"
            f"{requests.utils.quote(event_id, safe='')}",
        )
        if isinstance(get, dict) and get.get("ok") is False:
            return get
        attendees = get.get("attendees", []) or []
        changed = False
        for a in attendees:
            if a.get("self"):
                a["responseStatus"] = response
                changed = True
        if not changed:
            return {"ok": False,
                    "error": "You are not an attendee of this event."}
        data = _gcal_request(
            "PATCH",
            f"/calendars/{requests.utils.quote(cal, safe='')}/events/"
            f"{requests.utils.quote(event_id, safe='')}",
            body={"attendees": attendees},
        )
        if isinstance(data, dict) and data.get("ok") is False:
            return data
        return {"ok": True, "response": response, "event_id": event_id}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# AVAILABILITY & SCHEDULING
# ──────────────────────────────────────────────────────────────────────────


def _busy_blocks(
    time_min: datetime, time_max: datetime,
    calendar_ids: Optional[List[str]] = None,
) -> Any:
    """Return a sorted list of (start, end) busy datetime tuples via the
    Google free/busy endpoint. Returns an error dict on failure."""
    ids = calendar_ids or ["primary"]
    if isinstance(ids, str):
        ids = [ids]
    body = {
        "timeMin": _to_rfc3339(time_min),
        "timeMax": _to_rfc3339(time_max),
        "items": [{"id": i} for i in ids],
    }
    data = _gcal_request("POST", "/freeBusy", body=body)
    if isinstance(data, dict) and data.get("ok") is False:
        return data
    blocks: List[Tuple[datetime, datetime]] = []
    cals = data.get("calendars", {}) if isinstance(data, dict) else {}
    for _cid, info in cals.items():
        for b in info.get("busy", []):
            try:
                blocks.append((_parse_iso(b["start"]), _parse_iso(b["end"])))
            except Exception:
                continue
    blocks.sort(key=lambda x: x[0])
    return blocks


def _merge_blocks(
    blocks: List[Tuple[datetime, datetime]],
) -> List[Tuple[datetime, datetime]]:
    """Merge overlapping/adjacent busy blocks."""
    if not blocks:
        return []
    merged = [blocks[0]]
    for s, e in blocks[1:]:
        ls, le = merged[-1]
        if s <= le:
            merged[-1] = (ls, max(le, e))
        else:
            merged.append((s, e))
    return merged


def _free_windows(
    win_start: datetime, win_end: datetime,
    busy: List[Tuple[datetime, datetime]],
) -> List[Tuple[datetime, datetime]]:
    """Given a window and busy blocks, return the free gaps inside it."""
    free: List[Tuple[datetime, datetime]] = []
    cursor = win_start
    for s, e in _merge_blocks(busy):
        if e <= win_start or s >= win_end:
            continue
        s = max(s, win_start)
        e = min(e, win_end)
        if s > cursor:
            free.append((cursor, s))
        cursor = max(cursor, e)
    if cursor < win_end:
        free.append((cursor, win_end))
    return free


def _cal_free_busy(args: dict) -> dict:
    try:
        start_iso = args.get("start_iso")
        end_iso = args.get("end_iso")
        if not (start_iso and end_iso):
            return {"ok": False, "error": "start_iso and end_iso required."}
        blocks = _busy_blocks(
            _parse_iso(start_iso), _parse_iso(end_iso),
            args.get("calendar_ids"),
        )
        if isinstance(blocks, dict):
            return blocks
        return {
            "ok": True,
            "busy": [{"start": _to_iso(s), "end": _to_iso(e)}
                     for s, e in blocks],
            "count": len(blocks),
        }
    except Exception as e:
        return _err(e)


def _cal_find_free_slots(args: dict) -> dict:
    try:
        d = _parse_date_arg(args.get("date_iso"))
        duration = int(args.get("duration_min", 30))
        work_start = args.get("work_start", "09:00")
        work_end = args.get("work_end", "18:00")
        win_start = _parse_hhmm(work_start, d)
        win_end = _parse_hhmm(work_end, d)
        # don't suggest slots in the past
        now = _now()
        if win_start < now < win_end:
            win_start = now
        busy = _busy_blocks(win_start, win_end)
        if isinstance(busy, dict):
            return busy
        slots = []
        for fs, fe in _free_windows(win_start, win_end, busy):
            if (fe - fs).total_seconds() >= duration * 60:
                slots.append({
                    "start": _to_iso(fs),
                    "end": _to_iso(fe),
                    "minutes": int((fe - fs).total_seconds() // 60),
                })
        return {"ok": True, "date": d.isoformat(),
                "duration_min": duration, "free_slots": slots,
                "count": len(slots)}
    except Exception as e:
        return _err(e)


def _cal_next_free_slot(args: dict) -> dict:
    try:
        duration = int(args.get("duration_min", 30))
        work_start = args.get("work_start", "09:00")
        work_end = args.get("work_end", "18:00")
        for offset in range(0, 14):
            d = (_now() + timedelta(days=offset)).date()
            win_start = _parse_hhmm(work_start, d)
            win_end = _parse_hhmm(work_end, d)
            now = _now()
            if win_end < now:
                continue
            if win_start < now < win_end:
                win_start = now
            busy = _busy_blocks(win_start, win_end)
            if isinstance(busy, dict):
                return busy
            for fs, fe in _free_windows(win_start, win_end, busy):
                if (fe - fs).total_seconds() >= duration * 60:
                    return {
                        "ok": True,
                        "start": _to_iso(fs),
                        "end": _to_iso(fs + timedelta(minutes=duration)),
                        "window_minutes": int((fe - fs).total_seconds() // 60),
                        "days_out": offset,
                    }
        return {"ok": True, "start": None,
                "note": "No free slot found in the next 14 days."}
    except Exception as e:
        return _err(e)


def _cal_suggest_meeting_times(args: dict) -> dict:
    try:
        duration = int(args.get("duration_min", 30))
        days_ahead = int(args.get("days_ahead", 5))
        count = int(args.get("count", 5))
        work_start = args.get("work_start", "09:00")
        work_end = args.get("work_end", "18:00")
        suggestions: List[Dict[str, Any]] = []
        for offset in range(0, days_ahead + 1):
            if len(suggestions) >= count:
                break
            d = (_now() + timedelta(days=offset)).date()
            if d.weekday() >= 5:  # skip weekends
                continue
            win_start = _parse_hhmm(work_start, d)
            win_end = _parse_hhmm(work_end, d)
            now = _now()
            if win_end < now:
                continue
            if win_start < now < win_end:
                win_start = now
            busy = _busy_blocks(win_start, win_end)
            if isinstance(busy, dict):
                return busy
            for fs, fe in _free_windows(win_start, win_end, busy):
                cursor = fs
                while (fe - cursor).total_seconds() >= duration * 60:
                    suggestions.append({
                        "start": _to_iso(cursor),
                        "end": _to_iso(cursor + timedelta(minutes=duration)),
                        "weekday": d.strftime("%A"),
                    })
                    if len(suggestions) >= count:
                        break
                    cursor += timedelta(minutes=max(duration, 30))
                if len(suggestions) >= count:
                    break
        return {"ok": True, "duration_min": duration,
                "suggestions": suggestions[:count], "count":
                len(suggestions[:count])}
    except Exception as e:
        return _err(e)


def _cal_is_free_now(args: dict) -> dict:
    try:
        now = _now()
        blocks = _busy_blocks(now - timedelta(minutes=1),
                              now + timedelta(minutes=1))
        if isinstance(blocks, dict):
            return blocks
        for s, e in blocks:
            if s <= now <= e:
                return {"ok": True, "free": False,
                        "busy_until": _to_iso(e),
                        "minutes_remaining": int((e - now).total_seconds()
                                                 // 60)}
        return {"ok": True, "free": True}
    except Exception as e:
        return _err(e)


def _cal_block_focus_time(args: dict) -> dict:
    try:
        d = _parse_date_arg(args.get("date_iso"))
        duration = int(args.get("duration_min", 120))
        label = args.get("label", "Focus")
        # find the first free slot of the day for the block
        win_start = _parse_hhmm(args.get("work_start", "09:00"), d)
        win_end = _parse_hhmm(args.get("work_end", "18:00"), d)
        now = _now()
        if win_start < now < win_end:
            win_start = now
        busy = _busy_blocks(win_start, win_end)
        if isinstance(busy, dict):
            return busy
        chosen = None
        for fs, fe in _free_windows(win_start, win_end, busy):
            if (fe - fs).total_seconds() >= duration * 60:
                chosen = fs
                break
        if chosen is None:
            return {"ok": False,
                    "error": f"No {duration}-min free window on "
                             f"{d.isoformat()}."}
        return _cal_event_create({
            "summary": f"\U0001f9e0 {label}",
            "start_iso": _to_iso(chosen),
            "end_iso": _to_iso(chosen + timedelta(minutes=duration)),
            "description": "Focus block reserved by Leon. Do not schedule "
                           "over this.",
        })
    except Exception as e:
        return _err(e)


def _cal_day_load(args: dict) -> dict:
    try:
        d = _parse_date_arg(args.get("date_iso"))
        work_start = _parse_hhmm(args.get("work_start", "09:00"), d)
        work_end = _parse_hhmm(args.get("work_end", "18:00"), d)
        total = (work_end - work_start).total_seconds()
        busy = _busy_blocks(work_start, work_end)
        if isinstance(busy, dict):
            return busy
        booked = 0.0
        for s, e in _merge_blocks(busy):
            s = max(s, work_start)
            e = min(e, work_end)
            if e > s:
                booked += (e - s).total_seconds()
        pct = round(100.0 * booked / total, 1) if total > 0 else 0.0
        if pct >= 80:
            verdict = "packed"
        elif pct >= 50:
            verdict = "busy"
        elif pct >= 20:
            verdict = "moderate"
        else:
            verdict = "open"
        return {
            "ok": True,
            "date": d.isoformat(),
            "booked_minutes": int(booked // 60),
            "work_minutes": int(total // 60),
            "load_pct": pct,
            "verdict": verdict,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# SMART
# ──────────────────────────────────────────────────────────────────────────


def _cal_next_event(args: dict) -> dict:
    try:
        cal = args.get("calendar_id", "primary")
        now = _now()
        evs = _list_events_raw(cal, now, now + timedelta(days=30),
                               max_results=10)
        if isinstance(evs, dict):
            return evs
        for e in evs:
            start = _event_dt(e.get("start"))
            if start and start > now:
                mins = int((start - now).total_seconds() // 60)
                return {"ok": True, "event": _slim_event(e),
                        "minutes_until": mins,
                        "starts_in": _humanize_minutes(mins)}
        return {"ok": True, "event": None,
                "note": "No upcoming events in the next 30 days."}
    except Exception as e:
        return _err(e)


def _humanize_minutes(mins: int) -> str:
    if mins < 1:
        return "now"
    if mins < 60:
        return f"{mins} min"
    h, m = divmod(mins, 60)
    if h < 24:
        return f"{h}h {m}m" if m else f"{h}h"
    days, h = divmod(h, 24)
    return f"{days}d {h}h" if h else f"{days}d"


def _cal_minutes_until_next_meeting(args: dict) -> dict:
    try:
        nxt = _cal_next_event(args)
        if not nxt.get("ok"):
            return nxt
        if not nxt.get("event"):
            return {"ok": True, "minutes": None,
                    "note": "No upcoming meetings."}
        return {"ok": True, "minutes": nxt["minutes_until"],
                "starts_in": nxt["starts_in"],
                "event": nxt["event"]["summary"]}
    except Exception as e:
        return _err(e)


def _cal_meeting_prep(args: dict) -> dict:
    """Best-effort meeting prep brief. Pulls attendee list from the event;
    last email thread / related docs are attempted if comms or research
    tooling is importable, otherwise reported as unavailable."""
    try:
        event_id = args.get("event_id")
        if not event_id:
            return {"ok": False, "error": "event_id required."}
        cal = args.get("calendar_id", "primary")
        got = _cal_event_get({"event_id": event_id, "calendar_id": cal})
        if not got.get("ok"):
            return got
        ev = got["event"]
        attendees = ev.get("attendees") or []
        prep: Dict[str, Any] = {
            "summary": ev.get("summary"),
            "start": ev.get("start"),
            "end": ev.get("end"),
            "location": ev.get("location"),
            "attendees": attendees,
            "description": ev.get("description"),
        }
        # best-effort: last email thread with the first external attendee
        email_thread = None
        try:
            from brain.integrations import comms as _comms  # type: ignore
            # comms has no direct gmail search; skip gracefully
            _ = _comms
        except Exception:
            pass
        prep["last_email_thread"] = email_thread or "unavailable"
        prep["related_docs"] = "unavailable"
        # compose a markdown brief
        lines = [f"# Meeting Prep — {ev.get('summary')}", ""]
        lines.append(f"**When:** {ev.get('start')} → {ev.get('end')}")
        if ev.get("location"):
            lines.append(f"**Where:** {ev.get('location')}")
        if attendees:
            lines.append("**Attendees:**")
            for a in attendees:
                nm = a.get("name") or a.get("email")
                lines.append(f"  - {nm} ({a.get('response')})")
        if ev.get("description"):
            lines.append("")
            lines.append("**Notes:**")
            lines.append(ev["description"])
        prep["brief_markdown"] = "\n".join(lines)
        return {"ok": True, "prep": prep}
    except Exception as e:
        return _err(e)


def _cal_week_overview(args: dict) -> dict:
    try:
        cal = args.get("calendar_id", "primary")
        now = _now()
        # Monday of this week
        monday = now - timedelta(days=now.weekday())
        monday = datetime.combine(monday.date(), dtime(0, 0),
                                  tzinfo=now.tzinfo)
        sunday = monday + timedelta(days=7)
        evs = _list_events_raw(cal, monday, sunday)
        if isinstance(evs, dict):
            return evs
        by_day: Dict[str, List[dict]] = {}
        for e in evs:
            start = _event_dt(e.get("start"))
            if not start:
                continue
            key = start.date().isoformat()
            by_day.setdefault(key, []).append(e)
        lines = [f"# Week of {monday.date().isoformat()}", ""]
        for i in range(7):
            day = (monday + timedelta(days=i)).date()
            label = day.strftime("%A %b %d")
            day_evs = by_day.get(day.isoformat(), [])
            if not day_evs:
                lines.append(f"**{label}** — clear")
                continue
            lines.append(f"**{label}**")
            for e in day_evs:
                st = _event_dt(e.get("start"))
                tstr = (st.strftime("%H:%M") if st and "dateTime" in
                        (e.get("start") or {}) else "all-day")
                lines.append(f"  - {tstr}  {e.get('summary', '(no title)')}")
            lines.append("")
        return {"ok": True, "week_start": monday.date().isoformat(),
                "event_count": len(evs),
                "markdown": "\n".join(lines).strip()}
    except Exception as e:
        return _err(e)


def _cal_detect_conflicts(args: dict) -> dict:
    try:
        cal = args.get("calendar_id", "primary")
        days = int(args.get("days", 7))
        now = _now()
        evs = _list_events_raw(cal, now, now + timedelta(days=days))
        if isinstance(evs, dict):
            return evs
        timed = []
        for e in evs:
            s = _event_dt(e.get("start"))
            en = _event_dt(e.get("end"))
            if s and en and "dateTime" in (e.get("start") or {}):
                timed.append((s, en, e))
        timed.sort(key=lambda x: x[0])
        conflicts = []
        for i in range(len(timed)):
            s1, e1, ev1 = timed[i]
            for j in range(i + 1, len(timed)):
                s2, e2, ev2 = timed[j]
                if s2 >= e1:
                    break
                conflicts.append({
                    "event_a": _slim_event(ev1),
                    "event_b": _slim_event(ev2),
                    "overlap_minutes": int(
                        (min(e1, e2) - max(s1, s2)).total_seconds() // 60),
                })
        return {"ok": True, "days": days, "conflicts": conflicts,
                "count": len(conflicts)}
    except Exception as e:
        return _err(e)


def _cal_recurring_events_list(args: dict) -> dict:
    try:
        cal = args.get("calendar_id", "primary")
        now = _now()
        # use singleEvents=false to see recurring series masters
        evs = _list_events_raw(cal, now - timedelta(days=30),
                               now + timedelta(days=365),
                               single_events=False, max_results=2500)
        if isinstance(evs, dict):
            return evs
        series = []
        for e in evs:
            if e.get("recurrence"):
                series.append({
                    "id": e.get("id"),
                    "summary": e.get("summary", "(no title)"),
                    "recurrence": e.get("recurrence"),
                    "start": _fmt_event_dt(e.get("start")),
                })
        return {"ok": True, "recurring": series, "count": len(series)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CALDAV (generic)
# ──────────────────────────────────────────────────────────────────────────


def _caldav_creds() -> Optional[Tuple[str, str, str]]:
    url = os.environ.get("CALDAV_URL", "").strip()
    user = os.environ.get("CALDAV_USER", "").strip()
    pw = os.environ.get("CALDAV_PASSWORD", "").strip()
    if url and user and pw:
        return url, user, pw
    return None


def _ics_escape(text: str) -> str:
    return (text.replace("\\", "\\\\").replace(";", "\\;")
            .replace(",", "\\,").replace("\n", "\\n"))


def _ics_dt(dt: datetime) -> str:
    """Format a datetime as a UTC iCalendar timestamp."""
    return dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _caldav_report(url: str, user: str, pw: str,
                   start: datetime, end: datetime) -> Any:
    """Issue a CalDAV calendar-query REPORT for events in a window.
    Returns a list of {summary,start,end} or an error dict."""
    body = (
        '<?xml version="1.0" encoding="utf-8" ?>'
        '<C:calendar-query xmlns:D="DAV:" '
        'xmlns:C="urn:ietf:params:xml:ns:caldav">'
        '<D:prop><D:getetag/><C:calendar-data/></D:prop>'
        '<C:filter><C:comp-filter name="VCALENDAR">'
        '<C:comp-filter name="VEVENT">'
        f'<C:time-range start="{_ics_dt(start)}" end="{_ics_dt(end)}"/>'
        '</C:comp-filter></C:comp-filter></C:filter>'
        '</C:calendar-query>'
    )
    try:
        resp = requests.request(
            "REPORT", url,
            data=body,
            headers={"Depth": "1", "Content-Type": "application/xml"},
            auth=(user, pw),
            timeout=_DEFAULT_TIMEOUT,
        )
    except Exception as e:
        return _err(e)
    if resp.status_code >= 400:
        return {"ok": False,
                "error": f"CalDAV {resp.status_code}: {resp.text[:200]}"}
    events: List[Dict[str, Any]] = []
    try:
        root = ET.fromstring(resp.text)
        for cdata in root.iter():
            tag = cdata.tag.split("}")[-1]
            if tag == "calendar-data" and cdata.text:
                events.extend(_parse_ics(cdata.text))
    except Exception:
        # fall back to crude text scan
        events.extend(_parse_ics(resp.text))
    return events


def _parse_ics(text: str) -> List[Dict[str, Any]]:
    """Very small VEVENT extractor — summary + start + end."""
    out: List[Dict[str, Any]] = []
    for block in re.findall(r"BEGIN:VEVENT(.*?)END:VEVENT", text, re.S):
        ev: Dict[str, Any] = {}
        for line in block.splitlines():
            line = line.strip()
            if line.startswith("SUMMARY"):
                ev["summary"] = line.split(":", 1)[-1]
            elif line.startswith("DTSTART"):
                ev["start"] = line.split(":", 1)[-1]
            elif line.startswith("DTEND"):
                ev["end"] = line.split(":", 1)[-1]
        if ev:
            out.append(ev)
    return out


def _cal_caldav_events_today(args: dict) -> dict:
    try:
        creds = _caldav_creds()
        if not creds:
            return {"ok": False,
                    "error": "Set CALDAV_URL, CALDAV_USER, CALDAV_PASSWORD."}
        url, user, pw = creds
        start, end = _day_bounds(_now().date())
        evs = _caldav_report(url, user, pw, start, end)
        if isinstance(evs, dict):
            return evs
        return {"ok": True, "date": _now().date().isoformat(),
                "events": evs, "count": len(evs)}
    except Exception as e:
        return _err(e)


def _cal_caldav_event_create(args: dict) -> dict:
    try:
        creds = _caldav_creds()
        if not creds:
            return {"ok": False,
                    "error": "Set CALDAV_URL, CALDAV_USER, CALDAV_PASSWORD."}
        url, user, pw = creds
        summary = args.get("summary")
        start_iso = args.get("start_iso")
        end_iso = args.get("end_iso")
        if not (summary and start_iso and end_iso):
            return {"ok": False,
                    "error": "summary, start_iso, end_iso required."}
        uid = f"leon-{int(time.time())}@47industries"
        ics = (
            "BEGIN:VCALENDAR\r\n"
            "VERSION:2.0\r\n"
            "PRODID:-//Sabr//Leon//EN\r\n"
            "BEGIN:VEVENT\r\n"
            f"UID:{uid}\r\n"
            f"DTSTAMP:{_ics_dt(_now())}\r\n"
            f"DTSTART:{_ics_dt(_parse_iso(start_iso))}\r\n"
            f"DTEND:{_ics_dt(_parse_iso(end_iso))}\r\n"
            f"SUMMARY:{_ics_escape(summary)}\r\n"
            "END:VEVENT\r\n"
            "END:VCALENDAR\r\n"
        )
        put_url = url.rstrip("/") + f"/{uid}.ics"
        resp = requests.put(
            put_url, data=ics,
            headers={"Content-Type": "text/calendar"},
            auth=(user, pw), timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code >= 400:
            return {"ok": False,
                    "error": f"CalDAV {resp.status_code}: {resp.text[:200]}"}
        return {"ok": True, "uid": uid, "url": put_url}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# LOCAL EVENT STORE  (SQLite — always works, no creds)
# ──────────────────────────────────────────────────────────────────────────

_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS local_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    summary     TEXT NOT NULL,
    start_iso   TEXT NOT NULL,
    end_iso     TEXT NOT NULL,
    notes       TEXT,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_local_events_start
    ON local_events(start_iso);
"""


def _conn() -> sqlite3.Connection:
    """Lazily open the local-event-store SQLite connection (thread-safe)."""
    global _DB_CONN
    with _DB_LOCK:
        if _DB_CONN is None:
            conn = sqlite3.connect(_db_path(), check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
            _DB_CONN = conn
        return _DB_CONN


def _row_to_event(row: sqlite3.Row) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "summary": row["summary"],
        "start": row["start_iso"],
        "end": row["end_iso"],
        "notes": row["notes"],
        "created_at": row["created_at"],
        "source": "local",
    }


def _cal_local_event_add(args: dict) -> dict:
    try:
        summary = args.get("summary")
        start_iso = args.get("start_iso")
        end_iso = args.get("end_iso")
        if not (summary and start_iso and end_iso):
            return {"ok": False,
                    "error": "summary, start_iso, end_iso required."}
        # normalize via the parser so bad input fails here cleanly
        start_norm = _to_iso(_parse_iso(start_iso))
        end_norm = _to_iso(_parse_iso(end_iso))
        conn = _conn()
        with _DB_LOCK:
            cur = conn.execute(
                "INSERT INTO local_events "
                "(summary, start_iso, end_iso, notes, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (summary, start_norm, end_norm, args.get("notes"),
                 _to_iso(_now())),
            )
            conn.commit()
            event_id = cur.lastrowid
        return {"ok": True, "id": event_id, "summary": summary,
                "start": start_norm, "end": end_norm}
    except Exception as e:
        return _err(e)


def _cal_local_events_today(args: dict) -> dict:
    try:
        start, end = _day_bounds(_now().date())
        conn = _conn()
        with _DB_LOCK:
            rows = conn.execute(
                "SELECT * FROM local_events "
                "WHERE start_iso >= ? AND start_iso <= ? "
                "ORDER BY start_iso",
                (_to_iso(start), _to_iso(end)),
            ).fetchall()
        evs = [_row_to_event(r) for r in rows]
        return {"ok": True, "date": _now().date().isoformat(),
                "events": evs, "count": len(evs)}
    except Exception as e:
        return _err(e)


def _cal_local_events_upcoming(args: dict) -> dict:
    try:
        days = int(args.get("days", 7))
        now = _now()
        end = now + timedelta(days=days)
        conn = _conn()
        with _DB_LOCK:
            rows = conn.execute(
                "SELECT * FROM local_events "
                "WHERE start_iso >= ? AND start_iso <= ? "
                "ORDER BY start_iso",
                (_to_iso(now), _to_iso(end)),
            ).fetchall()
        evs = [_row_to_event(r) for r in rows]
        return {"ok": True, "days": days, "events": evs, "count": len(evs)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Google Calendar
    "cal.list_calendars": _cal_list_calendars,
    "cal.events_today": _cal_events_today,
    "cal.events_upcoming": _cal_events_upcoming,
    "cal.events_range": _cal_events_range,
    "cal.event_get": _cal_event_get,
    "cal.event_create": _cal_event_create,
    "cal.event_update": _cal_event_update,
    "cal.event_delete": _cal_event_delete,
    "cal.event_quick_add": _cal_event_quick_add,
    "cal.event_respond": _cal_event_respond,
    # Availability & scheduling
    "cal.free_busy": _cal_free_busy,
    "cal.find_free_slots": _cal_find_free_slots,
    "cal.next_free_slot": _cal_next_free_slot,
    "cal.suggest_meeting_times": _cal_suggest_meeting_times,
    "cal.is_free_now": _cal_is_free_now,
    "cal.block_focus_time": _cal_block_focus_time,
    "cal.day_load": _cal_day_load,
    # Smart
    "cal.next_event": _cal_next_event,
    "cal.minutes_until_next_meeting": _cal_minutes_until_next_meeting,
    "cal.meeting_prep": _cal_meeting_prep,
    "cal.week_overview": _cal_week_overview,
    "cal.detect_conflicts": _cal_detect_conflicts,
    "cal.recurring_events_list": _cal_recurring_events_list,
    # CalDAV
    "cal.caldav_events_today": _cal_caldav_events_today,
    "cal.caldav_event_create": _cal_caldav_event_create,
    # Local event store
    "cal.local_event_add": _cal_local_event_add,
    "cal.local_events_today": _cal_local_events_today,
    "cal.local_events_upcoming": _cal_local_events_upcoming,
}
