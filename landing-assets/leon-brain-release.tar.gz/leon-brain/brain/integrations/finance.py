"""
finance.py — Leon's personal finance tool surface.

Gives Leon the ability to track Dean's money end-to-end: a manual
transaction ledger, accounts, budgets, recurring bills, investment
portfolio (manual entry, prices resolved on demand), net worth, and
roll-ups (monthly/yearly/category breakdowns + cash-flow chart data).

All persistence is local SQLite at `brain_state/finance.db` (auto-
created on first call). Each tool takes a single `args` dict and
returns `{"ok": True, "result": ...}` or `{"ok": False, "error": "..."}`.
The `EXTRA_TOOLS` dict at the bottom maps dotted tool names (e.g.
`finance.txn_add`, `finance.budget_status`) to the implementing
function.

Style matches `brain/integrations/productivity.py`.
"""

from __future__ import annotations

import csv
import os
import re
import sqlite3
import threading
from datetime import datetime, date, timedelta
from typing import Any, Callable, Dict, List, Optional, Tuple


# ──────────────────────────────────────────────────────────────────────────
# PATHS & CONNECTION
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/)."""
    # this file lives at brain/integrations/finance.py — two levels up
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "finance.db")


_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'USD',
    category TEXT,
    account TEXT,
    description TEXT,
    type TEXT DEFAULT 'expense',
    tags TEXT,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    type TEXT NOT NULL,
    balance REAL DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    opened_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT UNIQUE NOT NULL,
    monthly_limit REAL NOT NULL,
    currency TEXT DEFAULT 'USD',
    alert_threshold_pct REAL DEFAULT 80,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS recurring (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    amount REAL NOT NULL,
    frequency TEXT NOT NULL,
    next_due TEXT NOT NULL,
    category TEXT,
    account TEXT,
    autopay INTEGER DEFAULT 0,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS investments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    asset_type TEXT NOT NULL,
    quantity REAL NOT NULL,
    cost_basis REAL NOT NULL,
    account TEXT,
    notes TEXT,
    opened_at REAL DEFAULT (strftime('%s','now'))
);
"""


def _conn() -> sqlite3.Connection:
    """Lazy SQLite connection. Creates schema on first call."""
    global _DB_CONN
    if _DB_CONN is not None:
        return _DB_CONN
    with _DB_LOCK:
        if _DB_CONN is not None:
            return _DB_CONN
        conn = sqlite3.connect(
            _db_path(),
            timeout=30,
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
        _DB_CONN = conn
    return _DB_CONN


# ──────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _row(r: sqlite3.Row) -> Optional[Dict[str, Any]]:
    if r is None:
        return None
    return {k: r[k] for k in r.keys()}


def _rows(rs) -> List[Dict[str, Any]]:
    return [_row(r) for r in rs]


def _today_str() -> str:
    return date.today().isoformat()


def _parse_date(s: Any) -> Optional[str]:
    """Normalize a date input to ISO YYYY-MM-DD. Returns None if invalid."""
    if s is None:
        return None
    if isinstance(s, (date, datetime)):
        return s.isoformat()[:10]
    s = str(s).strip()
    if not s:
        return None
    # Try common formats first
    fmts = (
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%m-%d-%Y",
        "%d-%m-%Y",
        "%b %d %Y",
        "%B %d %Y",
        "%Y-%m-%dT%H:%M:%S",
    )
    for f in fmts:
        try:
            return datetime.strptime(s, f).date().isoformat()
        except Exception:
            continue
    # Last resort — take leading 10 chars if they look ISO-ish
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return m.group(0)
    return None


def _normalize_tags(tags: Any) -> Optional[str]:
    if tags is None:
        return None
    if isinstance(tags, list):
        return ",".join(str(t).strip() for t in tags if str(t).strip())
    return str(tags).strip() or None


def _month_bounds(month: Optional[str] = None) -> Tuple[str, str, str]:
    """Return (start_iso, end_iso_exclusive, month_str 'YYYY-MM') for the
    given YYYY-MM string or current month if None."""
    if month:
        try:
            y, m = month.split("-")
            y, m = int(y), int(m)
        except Exception:
            y, m = date.today().year, date.today().month
    else:
        y, m = date.today().year, date.today().month
    start = date(y, m, 1)
    if m == 12:
        end = date(y + 1, 1, 1)
    else:
        end = date(y, m + 1, 1)
    return start.isoformat(), end.isoformat(), f"{y:04d}-{m:02d}"


def _year_bounds(year: Optional[int] = None) -> Tuple[str, str, int]:
    y = int(year) if year else date.today().year
    return date(y, 1, 1).isoformat(), date(y + 1, 1, 1).isoformat(), y


def _days_left_in_month() -> int:
    today = date.today()
    if today.month == 12:
        end = date(today.year + 1, 1, 1)
    else:
        end = date(today.year, today.month + 1, 1)
    return (end - today).days


_VALID_TXN_TYPE = {"income", "expense", "transfer"}
_VALID_ACCOUNT_TYPE = {
    "checking",
    "savings",
    "credit",
    "cash",
    "investment",
    "crypto",
}
_VALID_FREQUENCY = {"weekly", "monthly", "yearly"}
_VALID_ASSET_TYPE = {"stock", "crypto", "real_estate"}


# Heuristic categorization keywords
_CATEGORY_KEYWORDS: List[Tuple[str, Tuple[str, ...]]] = [
    ("groceries", (
        "grocery", "groceries", "whole foods", "wholefoods", "trader joe",
        "safeway", "kroger", "publix", "aldi", "costco", "wegmans",
        "supermarket", "market basket", "sprouts", "heb",
    )),
    ("dining", (
        "restaurant", "cafe", "coffee", "starbucks", "dunkin", "mcdonald",
        "chipotle", "doordash", "uber eats", "ubereats", "grubhub",
        "postmates", "pizza", "sushi", "diner", "bistro", "brewery",
        "bar ", "tavern", "panera", "wendy", "kfc", "burger",
    )),
    ("transport", (
        "uber", "lyft", "taxi", "metro", "transit", "subway pass", "amtrak",
        "shell", "chevron", "exxon", "mobil", "bp ", "gas station", "fuel",
        "parking", "toll", "dmv", "car wash",
    )),
    ("utilities", (
        "electric", "comcast", "xfinity", "spectrum", "verizon", "att ",
        "t-mobile", "tmobile", "internet", "water bill", "gas bill",
        "utility", "power co", "pg&e", "con ed", "sewer",
    )),
    ("entertainment", (
        "netflix", "hulu", "spotify", "disney", "hbo", "prime video",
        "youtube premium", "apple music", "steam", "playstation", "xbox",
        "cinema", "movie", "concert", "ticketmaster", "stubhub",
    )),
    ("shopping", (
        "amazon", "amzn", "ebay", "etsy", "walmart", "target", "best buy",
        "ikea", "home depot", "lowe's", "lowes", "macy", "nordstrom",
        "uniqlo", "zara", "h&m",
    )),
    ("rent", ("rent", "landlord", "property mgmt", "lease payment")),
    ("mortgage", ("mortgage", "principal payment", "escrow")),
    ("health", (
        "pharmacy", "cvs", "walgreens", "doctor", "dental", "dentist",
        "clinic", "hospital", "medical", "vision", "optometr", "therapist",
    )),
    ("fitness", (
        "gym", "fitness", "peloton", "yoga", "crossfit", "planet fitness",
        "equinox", "blink fitness",
    )),
    ("subscriptions", (
        "subscription", "patreon", "substack", "github", "openai",
        "anthropic", "chatgpt", "claude", "icloud", "dropbox", "notion",
        "1password", "linear", "vercel", "cloudflare",
    )),
    ("travel", (
        "airline", "delta", "united", "southwest", "jetblue", "american air",
        "airbnb", "hotel", "marriott", "hilton", "expedia", "booking.com",
        "rental car", "hertz", "enterprise rent", "avis",
    )),
    ("income", (
        "payroll", "salary", "direct dep", "interest paid", "dividend",
        "refund", "reimbursement", "stripe payout", "venmo cash in",
    )),
    ("transfer", ("transfer", "zelle", "venmo to", "wire ", "ach transfer")),
    ("fees", ("fee", "overdraft", "service charge", "atm fee")),
    ("taxes", ("irs", "tax payment", "tax refund", "franchise tax")),
    ("education", (
        "tuition", "university", "college", "coursera", "udemy", "edx",
        "khan academy",
    )),
]


def _heuristic_category(description: str) -> str:
    """Match a description against keyword bundles. Returns 'uncategorized'
    if nothing hits."""
    if not description:
        return "uncategorized"
    d = description.lower()
    for cat, kws in _CATEGORY_KEYWORDS:
        for kw in kws:
            if kw in d:
                return cat
    return "uncategorized"


def _resolve_recurring(name_or_id: Any) -> Optional[Dict[str, Any]]:
    if name_or_id is None:
        return None
    c = _conn()
    if isinstance(name_or_id, int) or (
        isinstance(name_or_id, str) and str(name_or_id).isdigit()
    ):
        r = c.execute(
            "SELECT * FROM recurring WHERE id = ?", (int(name_or_id),)
        ).fetchone()
    else:
        r = c.execute(
            "SELECT * FROM recurring WHERE name = ?", (str(name_or_id),)
        ).fetchone()
    return _row(r)


def _advance_due(current_iso: str, frequency: str) -> str:
    """Advance a YYYY-MM-DD date by one frequency step."""
    try:
        cur = datetime.strptime(current_iso, "%Y-%m-%d").date()
    except Exception:
        cur = date.today()
    if frequency == "weekly":
        nxt = cur + timedelta(days=7)
    elif frequency == "yearly":
        try:
            nxt = cur.replace(year=cur.year + 1)
        except ValueError:
            # Feb 29 → Feb 28 next year
            nxt = cur.replace(year=cur.year + 1, day=28)
    else:  # monthly (default)
        m = cur.month + 1
        y = cur.year
        if m > 12:
            m = 1
            y += 1
        # clamp day to last valid day of target month
        for day in (cur.day, 28, 29, 30, 31):
            try:
                nxt = date(y, m, min(day, 31))
                # validate
                _ = date(y, m, nxt.day)
                break
            except ValueError:
                continue
        else:
            nxt = date(y, m, 28)
    return nxt.isoformat()


def _live_price(symbol: str, asset_type: str) -> Optional[float]:
    """Best-effort live price via life/crypto integrations. Returns None on
    any failure — investment_current_value must not raise."""
    sym = (symbol or "").strip().upper()
    if not sym:
        return None
    try:
        if asset_type == "crypto":
            from brain.integrations import crypto as _crypto  # type: ignore
            fn = getattr(_crypto, "binance_price", None)
            if callable(fn):
                pair = sym if "USD" in sym else f"{sym}USDT"
                r = fn({"symbol": pair})
                if isinstance(r, dict) and r.get("ok"):
                    res = r.get("result") or {}
                    p = res.get("price") if isinstance(res, dict) else None
                    if p is not None:
                        return float(p)
        elif asset_type == "stock":
            from brain.integrations import life as _life  # type: ignore
            fn = getattr(_life, "stock_price", None)
            if callable(fn):
                r = fn({"symbol": sym})
                if isinstance(r, dict) and r.get("ok"):
                    res = r.get("result") or {}
                    p = (
                        res.get("price")
                        if isinstance(res, dict)
                        else None
                    )
                    if p is not None:
                        return float(p)
    except Exception:
        return None
    return None


# ──────────────────────────────────────────────────────────────────────────
# TRANSACTIONS
# ──────────────────────────────────────────────────────────────────────────


def txn_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Insert a transaction. Required: date, amount, category, description."""
    d = _parse_date(args.get("date")) or _today_str()
    try:
        amount = float(args.get("amount"))
    except Exception:
        return _err("amount is required and must be numeric")
    category = (args.get("category") or "").strip() or None
    description = (args.get("description") or "").strip()
    if not description and not category:
        return _err("description or category is required")
    type_ = (args.get("type") or "expense").lower()
    if type_ not in _VALID_TXN_TYPE:
        return _err(f"type must be one of {sorted(_VALID_TXN_TYPE)}")
    account = (args.get("account") or "").strip() or None
    currency = (args.get("currency") or "USD").upper()
    tags = _normalize_tags(args.get("tags"))
    if not category:
        category = _heuristic_category(description)
    c = _conn()
    with _DB_LOCK:
        cur = c.execute(
            """INSERT INTO transactions
               (date, amount, currency, category, account, description,
                type, tags)
               VALUES (?,?,?,?,?,?,?,?)""",
            (d, amount, currency, category, account, description, type_,
             tags),
        )
        txn_id = cur.lastrowid
        # Mirror to account balance if the account is known
        if account:
            acct = c.execute(
                "SELECT * FROM accounts WHERE name = ?", (account,)
            ).fetchone()
            if acct:
                delta = amount if type_ == "income" else -amount
                if type_ == "transfer":
                    delta = -amount
                c.execute(
                    "UPDATE accounts SET balance = balance + ? WHERE id = ?",
                    (delta, acct["id"]),
                )
        c.commit()
        r = c.execute(
            "SELECT * FROM transactions WHERE id = ?", (txn_id,)
        ).fetchone()
    return _ok(_row(r))


def txn_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent transactions with optional filters."""
    try:
        limit = int(args.get("limit") or 50)
    except Exception:
        limit = 50
    limit = max(1, min(1000, limit))
    where = []
    params: List[Any] = []
    if args.get("category"):
        where.append("category = ?")
        params.append(str(args["category"]))
    if args.get("account"):
        where.append("account = ?")
        params.append(str(args["account"]))
    if args.get("type"):
        where.append("type = ?")
        params.append(str(args["type"]).lower())
    if args.get("since"):
        sd = _parse_date(args.get("since"))
        if sd:
            where.append("date >= ?")
            params.append(sd)
    q = "SELECT * FROM transactions"
    if where:
        q += " WHERE " + " AND ".join(where)
    q += " ORDER BY date DESC, id DESC LIMIT ?"
    params.append(limit)
    rs = _conn().execute(q, params).fetchall()
    return _ok(_rows(rs))


def txn_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Substring search across description / category / account / tags."""
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query is required")
    try:
        limit = int(args.get("limit") or 50)
    except Exception:
        limit = 50
    limit = max(1, min(1000, limit))
    like = f"%{query}%"
    rs = _conn().execute(
        """SELECT * FROM transactions
           WHERE description LIKE ? OR category LIKE ?
              OR account LIKE ? OR tags LIKE ?
           ORDER BY date DESC, id DESC LIMIT ?""",
        (like, like, like, like, limit),
    ).fetchall()
    return _ok(_rows(rs))


def txn_update(args: Dict[str, Any]) -> Dict[str, Any]:
    """Update fields on a transaction. txn_id required."""
    txn_id = args.get("txn_id")
    if txn_id is None:
        return _err("txn_id is required")
    try:
        txn_id = int(txn_id)
    except Exception:
        return _err("txn_id must be an integer")
    allowed = {
        "date", "amount", "currency", "category", "account",
        "description", "type", "tags",
    }
    sets: List[str] = []
    params: List[Any] = []
    for k, v in args.items():
        if k == "txn_id" or k not in allowed:
            continue
        if k == "date":
            v = _parse_date(v) or v
        if k == "tags":
            v = _normalize_tags(v)
        if k == "type" and v is not None:
            v = str(v).lower()
            if v not in _VALID_TXN_TYPE:
                return _err(f"type must be one of {sorted(_VALID_TXN_TYPE)}")
        sets.append(f"{k} = ?")
        params.append(v)
    if not sets:
        return _err("no updatable fields supplied")
    params.append(txn_id)
    c = _conn()
    with _DB_LOCK:
        c.execute(
            f"UPDATE transactions SET {', '.join(sets)} WHERE id = ?",
            params,
        )
        c.commit()
        r = c.execute(
            "SELECT * FROM transactions WHERE id = ?", (txn_id,)
        ).fetchone()
    if r is None:
        return _err(f"transaction {txn_id} not found")
    return _ok(_row(r))


def txn_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a transaction by id."""
    txn_id = args.get("txn_id")
    if txn_id is None:
        return _err("txn_id is required")
    try:
        txn_id = int(txn_id)
    except Exception:
        return _err("txn_id must be an integer")
    c = _conn()
    with _DB_LOCK:
        cur = c.execute(
            "DELETE FROM transactions WHERE id = ?", (txn_id,)
        )
        c.commit()
    if cur.rowcount == 0:
        return _err(f"transaction {txn_id} not found")
    return _ok({"deleted": txn_id})


def txn_today(args: Dict[str, Any]) -> Dict[str, Any]:
    """Today's transactions, newest first."""
    rs = _conn().execute(
        "SELECT * FROM transactions WHERE date = ? "
        "ORDER BY id DESC",
        (_today_str(),),
    ).fetchall()
    return _ok(_rows(rs))


def txn_this_month(args: Dict[str, Any]) -> Dict[str, Any]:
    """This calendar month's transactions."""
    start, end, _ = _month_bounds(None)
    rs = _conn().execute(
        "SELECT * FROM transactions WHERE date >= ? AND date < ? "
        "ORDER BY date DESC, id DESC",
        (start, end),
    ).fetchall()
    return _ok(_rows(rs))


def txn_categorize(args: Dict[str, Any]) -> Dict[str, Any]:
    """Heuristic categorization of a free-form description."""
    desc = (args.get("description") or "").strip()
    if not desc:
        return _err("description is required")
    return _ok({"description": desc, "category": _heuristic_category(desc)})


# ──────────────────────────────────────────────────────────────────────────
# ACCOUNTS
# ──────────────────────────────────────────────────────────────────────────


def account_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add an account. type must be one of the valid set."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    type_ = (args.get("type") or "").lower().strip()
    if type_ not in _VALID_ACCOUNT_TYPE:
        return _err(f"type must be one of {sorted(_VALID_ACCOUNT_TYPE)}")
    try:
        balance = float(args.get("balance") or 0)
    except Exception:
        return _err("balance must be numeric")
    currency = (args.get("currency") or "USD").upper()
    c = _conn()
    with _DB_LOCK:
        try:
            cur = c.execute(
                "INSERT INTO accounts (name, type, balance, currency) "
                "VALUES (?,?,?,?)",
                (name, type_, balance, currency),
            )
            c.commit()
            acct_id = cur.lastrowid
        except sqlite3.IntegrityError:
            return _err(f"account '{name}' already exists")
        r = c.execute(
            "SELECT * FROM accounts WHERE id = ?", (acct_id,)
        ).fetchone()
    return _ok(_row(r))


def account_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """All accounts."""
    rs = _conn().execute(
        "SELECT * FROM accounts ORDER BY type, name"
    ).fetchall()
    return _ok(_rows(rs))


def account_balance(args: Dict[str, Any]) -> Dict[str, Any]:
    """Balance for a single account by name."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    r = _conn().execute(
        "SELECT * FROM accounts WHERE name = ?", (name,)
    ).fetchone()
    if r is None:
        return _err(f"account '{name}' not found")
    row = _row(r) or {}
    return _ok({
        "name": row.get("name"),
        "type": row.get("type"),
        "balance": row.get("balance"),
        "currency": row.get("currency"),
    })


def account_update_balance(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set an account's balance to a new explicit value."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    try:
        new_balance = float(args.get("new_balance"))
    except Exception:
        return _err("new_balance is required and must be numeric")
    c = _conn()
    with _DB_LOCK:
        cur = c.execute(
            "UPDATE accounts SET balance = ? WHERE name = ?",
            (new_balance, name),
        )
        c.commit()
    if cur.rowcount == 0:
        return _err(f"account '{name}' not found")
    return _ok({"name": name, "balance": new_balance})


def account_transfer(args: Dict[str, Any]) -> Dict[str, Any]:
    """Move funds between two accounts. Logs two transactions for audit."""
    src = (args.get("from_account") or "").strip()
    dst = (args.get("to_account") or "").strip()
    if not src or not dst:
        return _err("from_account and to_account are required")
    if src == dst:
        return _err("from_account and to_account must differ")
    try:
        amount = float(args.get("amount"))
    except Exception:
        return _err("amount is required and must be numeric")
    if amount <= 0:
        return _err("amount must be positive")
    note = (args.get("note") or "").strip() or f"Transfer {src}→{dst}"
    c = _conn()
    with _DB_LOCK:
        s = c.execute(
            "SELECT * FROM accounts WHERE name = ?", (src,)
        ).fetchone()
        d_ = c.execute(
            "SELECT * FROM accounts WHERE name = ?", (dst,)
        ).fetchone()
        if s is None:
            return _err(f"from_account '{src}' not found")
        if d_ is None:
            return _err(f"to_account '{dst}' not found")
        today = _today_str()
        c.execute(
            "UPDATE accounts SET balance = balance - ? WHERE id = ?",
            (amount, s["id"]),
        )
        c.execute(
            "UPDATE accounts SET balance = balance + ? WHERE id = ?",
            (amount, d_["id"]),
        )
        c.execute(
            """INSERT INTO transactions
               (date, amount, currency, category, account, description,
                type, tags)
               VALUES (?,?,?,?,?,?,?,?)""",
            (today, amount, s["currency"], "transfer", src, note,
             "transfer", None),
        )
        c.execute(
            """INSERT INTO transactions
               (date, amount, currency, category, account, description,
                type, tags)
               VALUES (?,?,?,?,?,?,?,?)""",
            (today, amount, d_["currency"], "transfer", dst, note,
             "transfer", None),
        )
        c.commit()
    return _ok({
        "from": src,
        "to": dst,
        "amount": amount,
        "note": note,
    })


# ──────────────────────────────────────────────────────────────────────────
# BUDGETS
# ──────────────────────────────────────────────────────────────────────────


def budget_set(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set (or update) a monthly budget for a category."""
    category = (args.get("category") or "").strip().lower()
    if not category:
        return _err("category is required")
    try:
        monthly_limit = float(args.get("monthly_limit"))
    except Exception:
        return _err("monthly_limit is required and must be numeric")
    if monthly_limit <= 0:
        return _err("monthly_limit must be positive")
    try:
        threshold = float(args.get("alert_threshold_pct") or 80)
    except Exception:
        threshold = 80.0
    threshold = max(0.0, min(100.0, threshold))
    c = _conn()
    with _DB_LOCK:
        existing = c.execute(
            "SELECT id FROM budgets WHERE category = ?", (category,)
        ).fetchone()
        if existing:
            c.execute(
                "UPDATE budgets SET monthly_limit = ?, "
                "alert_threshold_pct = ? WHERE id = ?",
                (monthly_limit, threshold, existing["id"]),
            )
        else:
            c.execute(
                "INSERT INTO budgets (category, monthly_limit, "
                "alert_threshold_pct) VALUES (?,?,?)",
                (category, monthly_limit, threshold),
            )
        c.commit()
        r = c.execute(
            "SELECT * FROM budgets WHERE category = ?", (category,)
        ).fetchone()
    return _ok(_row(r))


def budget_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """All budgets."""
    rs = _conn().execute(
        "SELECT * FROM budgets ORDER BY category"
    ).fetchall()
    return _ok(_rows(rs))


def budget_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """For one or all budgets, return spent/limit/% used/days left."""
    month = args.get("month")
    start, end, month_str = _month_bounds(month)
    c = _conn()
    cat = args.get("category")
    if cat:
        rs = c.execute(
            "SELECT * FROM budgets WHERE category = ?",
            (str(cat).lower(),),
        ).fetchall()
    else:
        rs = c.execute("SELECT * FROM budgets ORDER BY category").fetchall()
    out = []
    days_left = _days_left_in_month() if month_str == _today_str()[:7] else 0
    for r in rs:
        row = _row(r) or {}
        spent_row = c.execute(
            """SELECT COALESCE(SUM(amount),0) AS s FROM transactions
               WHERE category = ? AND type = 'expense'
                 AND date >= ? AND date < ?""",
            (row["category"], start, end),
        ).fetchone()
        spent = float(spent_row["s"] or 0)
        limit = float(row.get("monthly_limit") or 0)
        pct = (spent / limit * 100.0) if limit > 0 else 0.0
        out.append({
            "category": row.get("category"),
            "limit": limit,
            "spent": round(spent, 2),
            "remaining": round(limit - spent, 2),
            "pct_used": round(pct, 1),
            "alert_threshold_pct": row.get("alert_threshold_pct"),
            "month": month_str,
            "days_left_in_month": days_left,
        })
    if cat and not out:
        return _err(f"no budget set for category '{cat}'")
    return _ok(out if not cat else out[0])


def budget_alerts(args: Dict[str, Any]) -> Dict[str, Any]:
    """Budgets where spent% >= alert_threshold_pct for the current month."""
    res = budget_status({})
    if not res.get("ok"):
        return res
    items = res.get("result") or []
    if isinstance(items, dict):
        items = [items]
    alerts = [
        b for b in items
        if (b.get("alert_threshold_pct") or 80) <= (b.get("pct_used") or 0)
    ]
    return _ok(alerts)


# ──────────────────────────────────────────────────────────────────────────
# RECURRING BILLS
# ──────────────────────────────────────────────────────────────────────────


def recurring_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add a recurring bill / subscription."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    try:
        amount = float(args.get("amount"))
    except Exception:
        return _err("amount is required and must be numeric")
    freq = (args.get("frequency") or "").lower().strip()
    if freq not in _VALID_FREQUENCY:
        return _err(f"frequency must be one of {sorted(_VALID_FREQUENCY)}")
    next_due = _parse_date(args.get("next_due"))
    if not next_due:
        return _err("next_due is required (YYYY-MM-DD)")
    category = (args.get("category") or "").strip().lower() or None
    account = (args.get("account") or "").strip() or None
    autopay = 1 if args.get("autopay") else 0
    c = _conn()
    with _DB_LOCK:
        try:
            cur = c.execute(
                """INSERT INTO recurring
                   (name, amount, frequency, next_due, category, account,
                    autopay)
                   VALUES (?,?,?,?,?,?,?)""",
                (name, amount, freq, next_due, category, account, autopay),
            )
            c.commit()
            rid = cur.lastrowid
        except sqlite3.IntegrityError:
            return _err(f"recurring '{name}' already exists")
        r = c.execute(
            "SELECT * FROM recurring WHERE id = ?", (rid,)
        ).fetchone()
    return _ok(_row(r))


def recurring_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """Recurring bills due within `upcoming_days` (default 30)."""
    try:
        days = int(args.get("upcoming_days") or 30)
    except Exception:
        days = 30
    days = max(1, min(365, days))
    cutoff = (date.today() + timedelta(days=days)).isoformat()
    rs = _conn().execute(
        "SELECT * FROM recurring WHERE next_due <= ? "
        "ORDER BY next_due ASC, name ASC",
        (cutoff,),
    ).fetchall()
    out = []
    today = _today_str()
    for r in rs:
        row = _row(r) or {}
        try:
            d = datetime.strptime(row["next_due"], "%Y-%m-%d").date()
            days_until = (d - date.today()).days
        except Exception:
            days_until = None
        row["days_until_due"] = days_until
        row["overdue"] = bool(
            row.get("next_due") and row["next_due"] < today
        )
        out.append(row)
    return _ok(out)


def recurring_mark_paid(args: Dict[str, Any]) -> Dict[str, Any]:
    """Mark a recurring bill paid: logs a transaction, advances next_due,
    and (if account known) debits it."""
    key = args.get("name_or_id")
    if key is None:
        return _err("name_or_id is required")
    row = _resolve_recurring(key)
    if row is None:
        return _err(f"recurring '{key}' not found")
    c = _conn()
    with _DB_LOCK:
        # Insert payment transaction
        d = row.get("next_due") or _today_str()
        c.execute(
            """INSERT INTO transactions
               (date, amount, currency, category, account, description,
                type, tags)
               VALUES (?,?,?,?,?,?,?,?)""",
            (
                d,
                float(row.get("amount") or 0),
                "USD",
                row.get("category") or "subscriptions",
                row.get("account"),
                f"Recurring: {row.get('name')}",
                "expense",
                "recurring",
            ),
        )
        # Debit account
        if row.get("account"):
            c.execute(
                "UPDATE accounts SET balance = balance - ? WHERE name = ?",
                (float(row.get("amount") or 0), row["account"]),
            )
        # Advance due date
        new_due = _advance_due(d, row.get("frequency") or "monthly")
        c.execute(
            "UPDATE recurring SET next_due = ? WHERE id = ?",
            (new_due, row["id"]),
        )
        c.commit()
        fresh = c.execute(
            "SELECT * FROM recurring WHERE id = ?", (row["id"],)
        ).fetchone()
    return _ok(_row(fresh))


def recurring_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a recurring bill by name or id."""
    key = args.get("name_or_id")
    if key is None:
        return _err("name_or_id is required")
    row = _resolve_recurring(key)
    if row is None:
        return _err(f"recurring '{key}' not found")
    c = _conn()
    with _DB_LOCK:
        c.execute("DELETE FROM recurring WHERE id = ?", (row["id"],))
        c.commit()
    return _ok({"deleted": row["name"]})


# ──────────────────────────────────────────────────────────────────────────
# INVESTMENTS
# ──────────────────────────────────────────────────────────────────────────


def investment_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add a holding. cost_basis is total cost paid (not per-share)."""
    symbol = (args.get("symbol") or "").strip().upper()
    if not symbol:
        return _err("symbol is required")
    asset_type = (args.get("asset_type") or "").lower().strip()
    if asset_type not in _VALID_ASSET_TYPE:
        return _err(f"asset_type must be one of {sorted(_VALID_ASSET_TYPE)}")
    try:
        quantity = float(args.get("quantity"))
    except Exception:
        return _err("quantity is required and must be numeric")
    try:
        cost_basis = float(args.get("cost_basis"))
    except Exception:
        return _err("cost_basis is required and must be numeric")
    account = (args.get("account") or "").strip() or None
    notes = (args.get("notes") or "").strip() or None
    c = _conn()
    with _DB_LOCK:
        cur = c.execute(
            """INSERT INTO investments
               (symbol, asset_type, quantity, cost_basis, account, notes)
               VALUES (?,?,?,?,?,?)""",
            (symbol, asset_type, quantity, cost_basis, account, notes),
        )
        c.commit()
        r = c.execute(
            "SELECT * FROM investments WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
    return _ok(_row(r))


def investment_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """All holdings."""
    rs = _conn().execute(
        "SELECT * FROM investments ORDER BY asset_type, symbol"
    ).fetchall()
    return _ok(_rows(rs))


def investment_current_value(args: Dict[str, Any]) -> Dict[str, Any]:
    """Look up current price per holding, compute market value, sum total.
    Real-estate holdings (no live price) fall back to cost_basis."""
    rs = _conn().execute("SELECT * FROM investments").fetchall()
    out = []
    total = 0.0
    for r in rs:
        row = _row(r) or {}
        sym = row.get("symbol") or ""
        atype = row.get("asset_type") or ""
        qty = float(row.get("quantity") or 0)
        cb = float(row.get("cost_basis") or 0)
        price = _live_price(sym, atype)
        if price is not None:
            value = price * qty
            source = "live"
        else:
            value = cb  # fallback
            price = (cb / qty) if qty else 0.0
            source = "cost_basis_fallback"
        total += value
        out.append({
            "symbol": sym,
            "asset_type": atype,
            "quantity": qty,
            "cost_basis": cb,
            "price": round(price, 6),
            "value": round(value, 2),
            "price_source": source,
        })
    return _ok({
        "holdings": out,
        "total_value": round(total, 2),
    })


def investment_pnl(args: Dict[str, Any]) -> Dict[str, Any]:
    """Profit / loss vs cost basis across all holdings."""
    cv = investment_current_value({})
    if not cv.get("ok"):
        return cv
    holdings = (cv.get("result") or {}).get("holdings") or []
    total_value = (cv.get("result") or {}).get("total_value") or 0.0
    total_cb = sum(float(h.get("cost_basis") or 0) for h in holdings)
    pnl = total_value - total_cb
    pct = (pnl / total_cb * 100.0) if total_cb > 0 else 0.0
    per_holding = []
    for h in holdings:
        cb = float(h.get("cost_basis") or 0)
        val = float(h.get("value") or 0)
        h_pnl = val - cb
        h_pct = (h_pnl / cb * 100.0) if cb > 0 else 0.0
        per_holding.append({
            "symbol": h.get("symbol"),
            "asset_type": h.get("asset_type"),
            "cost_basis": round(cb, 2),
            "value": round(val, 2),
            "pnl": round(h_pnl, 2),
            "pnl_pct": round(h_pct, 2),
        })
    return _ok({
        "total_cost_basis": round(total_cb, 2),
        "total_value": round(total_value, 2),
        "total_pnl": round(pnl, 2),
        "total_pnl_pct": round(pct, 2),
        "per_holding": per_holding,
    })


# ──────────────────────────────────────────────────────────────────────────
# NET WORTH & SUMMARIES
# ──────────────────────────────────────────────────────────────────────────


def net_worth(args: Dict[str, Any]) -> Dict[str, Any]:
    """Sum of account balances + current investment value. Credit accounts
    contribute negatively (their balance is treated as a liability)."""
    c = _conn()
    accts = c.execute("SELECT * FROM accounts").fetchall()
    assets = 0.0
    liabilities = 0.0
    by_type: Dict[str, float] = {}
    for r in accts:
        row = _row(r) or {}
        bal = float(row.get("balance") or 0)
        t = row.get("type") or "other"
        by_type[t] = by_type.get(t, 0.0) + bal
        if t == "credit":
            liabilities += abs(bal)
        else:
            assets += bal
    inv = investment_current_value({})
    inv_value = 0.0
    if inv.get("ok"):
        inv_value = float(
            (inv.get("result") or {}).get("total_value") or 0
        )
    net = assets + inv_value - liabilities
    return _ok({
        "accounts_total": round(assets, 2),
        "liabilities_total": round(liabilities, 2),
        "investments_value": round(inv_value, 2),
        "net_worth": round(net, 2),
        "by_account_type": {k: round(v, 2) for k, v in by_type.items()},
    })


def monthly_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """Income / expense / savings rate for a YYYY-MM (default current)."""
    start, end, month_str = _month_bounds(args.get("month"))
    c = _conn()
    r = c.execute(
        """SELECT
             COALESCE(SUM(CASE WHEN type='income'  THEN amount END),0) AS inc,
             COALESCE(SUM(CASE WHEN type='expense' THEN amount END),0) AS exp,
             COUNT(*) AS n
           FROM transactions
           WHERE date >= ? AND date < ?""",
        (start, end),
    ).fetchone()
    inc = float(r["inc"] or 0)
    exp = float(r["exp"] or 0)
    net = inc - exp
    rate = (net / inc * 100.0) if inc > 0 else 0.0
    return _ok({
        "month": month_str,
        "income": round(inc, 2),
        "expense": round(exp, 2),
        "net": round(net, 2),
        "savings_rate_pct": round(rate, 1),
        "transaction_count": int(r["n"] or 0),
    })


def yearly_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """Income / expense / net for a calendar year."""
    start, end, y = _year_bounds(args.get("year"))
    c = _conn()
    r = c.execute(
        """SELECT
             COALESCE(SUM(CASE WHEN type='income'  THEN amount END),0) AS inc,
             COALESCE(SUM(CASE WHEN type='expense' THEN amount END),0) AS exp,
             COUNT(*) AS n
           FROM transactions
           WHERE date >= ? AND date < ?""",
        (start, end),
    ).fetchone()
    inc = float(r["inc"] or 0)
    exp = float(r["exp"] or 0)
    net = inc - exp
    rate = (net / inc * 100.0) if inc > 0 else 0.0
    # Per-month breakdown
    months = []
    for m in range(1, 13):
        ms = f"{y:04d}-{m:02d}"
        s, e, _ = _month_bounds(ms)
        mr = c.execute(
            """SELECT
                 COALESCE(SUM(CASE WHEN type='income'  THEN amount END),0) AS inc,
                 COALESCE(SUM(CASE WHEN type='expense' THEN amount END),0) AS exp
               FROM transactions
               WHERE date >= ? AND date < ?""",
            (s, e),
        ).fetchone()
        months.append({
            "month": ms,
            "income": round(float(mr["inc"] or 0), 2),
            "expense": round(float(mr["exp"] or 0), 2),
        })
    return _ok({
        "year": y,
        "income": round(inc, 2),
        "expense": round(exp, 2),
        "net": round(net, 2),
        "savings_rate_pct": round(rate, 1),
        "transaction_count": int(r["n"] or 0),
        "months": months,
    })


def category_breakdown(args: Dict[str, Any]) -> Dict[str, Any]:
    """Top spending categories for a month (default current)."""
    start, end, month_str = _month_bounds(args.get("month"))
    rs = _conn().execute(
        """SELECT category, COALESCE(SUM(amount),0) AS total, COUNT(*) AS n
           FROM transactions
           WHERE date >= ? AND date < ? AND type='expense'
           GROUP BY category
           ORDER BY total DESC""",
        (start, end),
    ).fetchall()
    items = []
    grand = 0.0
    for r in rs:
        total = float(r["total"] or 0)
        grand += total
        items.append({
            "category": r["category"] or "uncategorized",
            "total": round(total, 2),
            "count": int(r["n"] or 0),
        })
    for it in items:
        it["pct"] = round(
            (it["total"] / grand * 100.0) if grand > 0 else 0.0, 1
        )
    return _ok({
        "month": month_str,
        "total_expense": round(grand, 2),
        "categories": items,
    })


def cash_flow_chart_data(args: Dict[str, Any]) -> Dict[str, Any]:
    """Per-month income/expense/net for the last N months. Suitable for
    a dashboard line/bar chart."""
    try:
        months = int(args.get("months") or 6)
    except Exception:
        months = 6
    months = max(1, min(36, months))
    today = date.today()
    y, m = today.year, today.month
    points = []
    # walk backwards then reverse
    for i in range(months):
        mm = m - i
        yy = y
        while mm <= 0:
            mm += 12
            yy -= 1
        ms = f"{yy:04d}-{mm:02d}"
        s, e, _ = _month_bounds(ms)
        r = _conn().execute(
            """SELECT
                 COALESCE(SUM(CASE WHEN type='income'  THEN amount END),0) AS inc,
                 COALESCE(SUM(CASE WHEN type='expense' THEN amount END),0) AS exp
               FROM transactions
               WHERE date >= ? AND date < ?""",
            (s, e),
        ).fetchone()
        inc = round(float(r["inc"] or 0), 2)
        exp = round(float(r["exp"] or 0), 2)
        points.append({
            "month": ms,
            "income": inc,
            "expense": exp,
            "net": round(inc - exp, 2),
        })
    points.reverse()
    return _ok({"months": months, "series": points})


def spending_trend(args: Dict[str, Any]) -> Dict[str, Any]:
    """Monthly spend in one category over the last N months."""
    category = (args.get("category") or "").strip().lower()
    if not category:
        return _err("category is required")
    try:
        months = int(args.get("months") or 6)
    except Exception:
        months = 6
    months = max(1, min(36, months))
    today = date.today()
    y, m = today.year, today.month
    points = []
    for i in range(months):
        mm = m - i
        yy = y
        while mm <= 0:
            mm += 12
            yy -= 1
        ms = f"{yy:04d}-{mm:02d}"
        s, e, _ = _month_bounds(ms)
        r = _conn().execute(
            """SELECT COALESCE(SUM(amount),0) AS t, COUNT(*) AS n
               FROM transactions
               WHERE date >= ? AND date < ?
                 AND type='expense' AND category=?""",
            (s, e, category),
        ).fetchone()
        points.append({
            "month": ms,
            "total": round(float(r["t"] or 0), 2),
            "count": int(r["n"] or 0),
        })
    points.reverse()
    totals = [p["total"] for p in points]
    avg = sum(totals) / len(totals) if totals else 0.0
    return _ok({
        "category": category,
        "months": months,
        "series": points,
        "average_monthly": round(avg, 2),
    })


# ──────────────────────────────────────────────────────────────────────────
# CSV IMPORT / EXPORT
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_CSV_MAPPING: Dict[str, Tuple[str, ...]] = {
    "date": ("date", "transaction date", "posted date", "post date"),
    "amount": ("amount", "value", "debit", "credit"),
    "description": ("description", "details", "memo", "name", "payee"),
    "category": ("category", "type"),
    "account": ("account", "account name"),
}


def _csv_pick(header_map: Dict[str, str], candidates: Tuple[str, ...]) -> Optional[str]:
    for c in candidates:
        if c in header_map:
            return header_map[c]
    return None


def import_csv(args: Dict[str, Any]) -> Dict[str, Any]:
    """Import a bank-style CSV. `mapping` overrides the default header→field
    mapping if your bank uses unusual column names. Returns a count + first
    few rows imported."""
    path = (args.get("path") or "").strip()
    if not path:
        return _err("path is required")
    if not os.path.isfile(path):
        return _err(f"file not found: {path}")
    mapping = args.get("mapping") or {}
    # Build effective mapping (user mapping wins)
    eff = {
        k: ((mapping.get(k),) if mapping.get(k) else _DEFAULT_CSV_MAPPING[k])
        for k in _DEFAULT_CSV_MAPPING
    }
    inserted = 0
    samples: List[Dict[str, Any]] = []
    errors: List[str] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                return _err("CSV has no header row")
            header_map = {h.lower().strip(): h for h in reader.fieldnames}
            col_date = _csv_pick(header_map, eff["date"])
            col_amt = _csv_pick(header_map, eff["amount"])
            col_desc = _csv_pick(header_map, eff["description"])
            col_cat = _csv_pick(header_map, eff["category"])
            col_acct = _csv_pick(header_map, eff["account"])
            if not col_date or not col_amt:
                return _err(
                    "CSV must have at least date + amount columns "
                    "(or supply a mapping)"
                )
            c = _conn()
            with _DB_LOCK:
                for i, raw in enumerate(reader):
                    try:
                        d = _parse_date(raw.get(col_date)) or _today_str()
                        amt_raw = (raw.get(col_amt) or "").replace(",", "")
                        amt_raw = amt_raw.replace("$", "").strip()
                        if not amt_raw:
                            continue
                        amt = float(amt_raw)
                        type_ = "income" if amt > 0 else "expense"
                        amt = abs(amt)
                        desc = (raw.get(col_desc) if col_desc else "") or ""
                        desc = desc.strip()
                        cat = (
                            (raw.get(col_cat) if col_cat else "") or ""
                        ).strip().lower() or _heuristic_category(desc)
                        acct = (
                            (raw.get(col_acct) if col_acct else "") or ""
                        ).strip() or None
                        c.execute(
                            """INSERT INTO transactions
                               (date, amount, currency, category, account,
                                description, type, tags)
                               VALUES (?,?,?,?,?,?,?,?)""",
                            (d, amt, "USD", cat, acct, desc, type_, "imported"),
                        )
                        inserted += 1
                        if len(samples) < 5:
                            samples.append({
                                "date": d, "amount": amt,
                                "category": cat, "description": desc,
                                "type": type_,
                            })
                    except Exception as e:  # per-row errors are non-fatal
                        if len(errors) < 5:
                            errors.append(f"row {i}: {e}")
                        continue
                c.commit()
    except Exception as e:
        return _err(f"failed to read CSV: {e}")
    return _ok({
        "imported": inserted,
        "samples": samples,
        "row_errors": errors,
    })


def export_csv(args: Dict[str, Any]) -> Dict[str, Any]:
    """Export all transactions (optionally since YYYY-MM-DD) to a CSV file."""
    save_to = (args.get("save_to") or "").strip()
    if not save_to:
        return _err("save_to is required")
    where = ""
    params: List[Any] = []
    since = args.get("since")
    if since:
        sd = _parse_date(since)
        if sd:
            where = " WHERE date >= ?"
            params.append(sd)
    rs = _conn().execute(
        "SELECT id, date, amount, currency, category, account, description, "
        "type, tags, created_at FROM transactions" + where +
        " ORDER BY date ASC, id ASC",
        params,
    ).fetchall()
    try:
        os.makedirs(os.path.dirname(os.path.abspath(save_to)) or ".",
                    exist_ok=True)
        with open(save_to, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow([
                "id", "date", "amount", "currency", "category", "account",
                "description", "type", "tags", "created_at",
            ])
            for r in rs:
                w.writerow([r[k] for k in (
                    "id", "date", "amount", "currency", "category",
                    "account", "description", "type", "tags", "created_at",
                )])
    except Exception as e:
        return _err(f"failed to write CSV: {e}")
    return _ok({"path": save_to, "rows": len(rs)})


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS EXPORT
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # transactions
    "finance.txn_add": txn_add,
    "finance.txn_list": txn_list,
    "finance.txn_search": txn_search,
    "finance.txn_update": txn_update,
    "finance.txn_delete": txn_delete,
    "finance.txn_today": txn_today,
    "finance.txn_this_month": txn_this_month,
    "finance.txn_categorize": txn_categorize,
    # accounts
    "finance.account_add": account_add,
    "finance.account_list": account_list,
    "finance.account_balance": account_balance,
    "finance.account_update_balance": account_update_balance,
    "finance.account_transfer": account_transfer,
    # budgets
    "finance.budget_set": budget_set,
    "finance.budget_list": budget_list,
    "finance.budget_status": budget_status,
    "finance.budget_alerts": budget_alerts,
    # recurring
    "finance.recurring_add": recurring_add,
    "finance.recurring_list": recurring_list,
    "finance.recurring_mark_paid": recurring_mark_paid,
    "finance.recurring_delete": recurring_delete,
    # investments
    "finance.investment_add": investment_add,
    "finance.investment_list": investment_list,
    "finance.investment_current_value": investment_current_value,
    "finance.investment_pnl": investment_pnl,
    # net worth & summaries
    "finance.net_worth": net_worth,
    "finance.monthly_summary": monthly_summary,
    "finance.yearly_summary": yearly_summary,
    "finance.category_breakdown": category_breakdown,
    "finance.cash_flow_chart_data": cash_flow_chart_data,
    "finance.spending_trend": spending_trend,
    # csv
    "finance.import_csv": import_csv,
    "finance.export_csv": export_csv,
}
