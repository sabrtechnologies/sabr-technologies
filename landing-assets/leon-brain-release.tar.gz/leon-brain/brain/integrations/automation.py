"""OS-level automation — record + replay mouse/keyboard macros, screen
record, hotkey listener, key remapping.

Tools (~15 total):

  - automation.macro_record_start(label?)     start recording keystrokes/clicks
  - automation.macro_record_stop()            finish, save to file
  - automation.macro_list()                   list saved macros
  - automation.macro_play(name, speed=1.0)    replay a recorded macro
  - automation.macro_delete(name)
  - automation.screen_record_start(...)       full screen capture to mp4
  - automation.screen_record_stop()
  - automation.screen_record_list()
  - automation.keystroke_sequence(keys, delay_ms=50)
  - automation.mouse_path(points, speed=500)  draw mouse along path
  - automation.click_at_relative(x_pct, y_pct, monitor=0)
  - automation.hotkey_register(combo, action_tool, action_args)  registers global hotkey
  - automation.hotkey_list()
  - automation.hotkey_unregister(combo)
  - automation.idle_monitor_start(threshold_min=15, on_idle_tool=None)
"""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


_BASE = Path(__file__).resolve().parent.parent.parent / "brain_state"
_MACRO_DIR = _BASE / "macros_recorded"
_REC_DIR = _BASE / "screen_recordings"
_MACRO_DIR.mkdir(parents=True, exist_ok=True)
_REC_DIR.mkdir(parents=True, exist_ok=True)
_HOTKEYS_FILE = _BASE / "hotkeys.json"

# In-memory state
_RECORDER_PROC: Optional[Dict[str, Any]] = None  # current macro recording
_SCREEN_PROC: Optional[Dict[str, Any]] = None    # current screen recording
_LOCK = threading.RLock()


def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _safe_id(label: str) -> str:
    base = "".join(c if c.isalnum() else "_" for c in (label or "macro"))
    return f"{base}_{int(time.time())}_{uuid.uuid4().hex[:4]}"


# ── Macro record/play (xdotool-based for X11) ──────────────────────────
def _macro_record_start(args: Dict[str, Any]) -> Dict[str, Any]:
    """Start recording a keystroke/mouse macro using xinput.

    Args:
      label: short name (default 'macro')
    """
    global _RECORDER_PROC
    with _LOCK:
        if _RECORDER_PROC:
            return {"ok": False, "error": "a recording is already active — stop it first"}
    if not _have("xdotool") or not _have("xinput"):
        return {"ok": False, "error": "xdotool and xinput required"}
    label = args.get("label", "macro")
    macro_id = _safe_id(label)
    out_file = _MACRO_DIR / f"{macro_id}.jsonl"

    # We record using a simple polling loop in a thread:
    # capture mouse position every 100ms + watch xinput events for keys.
    # Stop file signals the thread to halt.
    stop_flag = {"stop": False}
    events: List[Dict[str, Any]] = []
    started_at = time.time()

    def _recorder():
        last_mouse = None
        last_event_t = started_at
        while not stop_flag["stop"]:
            try:
                r = subprocess.run(["xdotool", "getmouselocation", "--shell"],
                                    capture_output=True, text=True, timeout=1)
                if r.returncode == 0:
                    pos = {}
                    for line in r.stdout.split("\n"):
                        if "=" in line:
                            k, v = line.split("=", 1)
                            pos[k.strip()] = v.strip()
                    cur = (int(pos.get("X", 0)), int(pos.get("Y", 0)))
                    if cur != last_mouse:
                        events.append({"t": time.time() - started_at,
                                         "type": "mouse_move",
                                         "x": cur[0], "y": cur[1]})
                        last_mouse = cur
            except Exception:
                pass
            time.sleep(0.1)
        out_file.write_text("\n".join(json.dumps(e) for e in events))

    t = threading.Thread(target=_recorder, daemon=True, name=f"macro-rec-{macro_id}")
    t.start()
    with _LOCK:
        _RECORDER_PROC = {"macro_id": macro_id, "out_file": str(out_file),
                          "stop_flag": stop_flag, "thread": t,
                          "started_at": started_at, "label": label,
                          "events": events}
    return {"ok": True, "macro_id": macro_id, "label": label,
            "note": "Records mouse moves at 10Hz. xdotool key-recording is limited; "
                    "use `automation.keystroke_sequence` for deterministic playback."}


def _macro_record_stop(args: Dict[str, Any]) -> Dict[str, Any]:
    global _RECORDER_PROC
    with _LOCK:
        if not _RECORDER_PROC:
            return {"ok": False, "error": "no active recording"}
        rec = _RECORDER_PROC
        _RECORDER_PROC = None
    rec["stop_flag"]["stop"] = True
    rec["thread"].join(timeout=2)
    return {"ok": True, "macro_id": rec["macro_id"], "events_recorded": len(rec["events"]),
            "duration_s": round(time.time() - rec["started_at"], 2),
            "out_file": rec["out_file"]}


def _macro_list(args: Dict[str, Any]) -> Dict[str, Any]:
    files = sorted(_MACRO_DIR.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
    return {"ok": True, "macros": [
        {"name": p.stem, "path": str(p), "size": p.stat().st_size,
         "modified": p.stat().st_mtime} for p in files
    ], "count": len(files)}


def _macro_play(args: Dict[str, Any]) -> Dict[str, Any]:
    """Replay a recorded macro.

    Args:
      name: macro id (without .jsonl)
      speed: playback speed multiplier (default 1.0)
    """
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name required"}
    speed = float(args.get("speed", 1.0))
    p = _MACRO_DIR / f"{name}.jsonl"
    if not p.exists():
        return {"ok": False, "error": f"not found: {p}"}
    if not _have("xdotool"):
        return {"ok": False, "error": "xdotool not installed"}

    events = []
    for line in p.read_text().split("\n"):
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except Exception:
            pass
    last_t = 0
    for ev in events:
        wait = (ev["t"] - last_t) / max(0.01, speed)
        if wait > 0:
            time.sleep(min(wait, 5.0))
        last_t = ev["t"]
        try:
            if ev["type"] == "mouse_move":
                subprocess.run(["xdotool", "mousemove", str(ev["x"]), str(ev["y"])],
                                capture_output=True, timeout=2)
            elif ev["type"] == "mouse_click":
                subprocess.run(["xdotool", "click", str(ev.get("button", 1))],
                                capture_output=True, timeout=2)
            elif ev["type"] == "keystroke":
                subprocess.run(["xdotool", "key", ev["key"]], capture_output=True, timeout=2)
        except Exception:
            continue
    return {"ok": True, "macro": name, "events_played": len(events), "speed": speed}


def _macro_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name required"}
    p = _MACRO_DIR / f"{name}.jsonl"
    if p.exists():
        p.unlink()
        return {"ok": True, "deleted": str(p)}
    return {"ok": False, "error": "not found"}


# ── Screen recording ──────────────────────────────────────────────────
def _screen_record_start(args: Dict[str, Any]) -> Dict[str, Any]:
    """Start screen recording via ffmpeg → mp4.

    Args:
      label: filename hint
      fps: default 30
      with_audio: capture system audio too (default True)
    """
    global _SCREEN_PROC
    with _LOCK:
        if _SCREEN_PROC:
            return {"ok": False, "error": "a screen recording is already active"}
    if not _have("ffmpeg"):
        return {"ok": False, "error": "ffmpeg not installed"}
    label = args.get("label", "screen")
    fps = int(args.get("fps", 30))
    with_audio = bool(args.get("with_audio", True))
    rec_id = _safe_id(label)
    out = _REC_DIR / f"{rec_id}.mp4"
    # Determine display dimensions
    try:
        r = subprocess.run(["xdpyinfo"], capture_output=True, text=True, timeout=3)
        dim = "1920x1080"
        for line in r.stdout.split("\n"):
            if "dimensions:" in line:
                dim = line.strip().split()[1]
                break
    except Exception:
        dim = "1920x1080"
    display = os.environ.get("DISPLAY", ":0")
    cmd = ["ffmpeg", "-hide_banner", "-y",
            "-f", "x11grab", "-r", str(fps), "-s", dim, "-i", display]
    if with_audio and _have("parec"):
        cmd += ["-f", "pulse", "-i", "default"]
    cmd += ["-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p", str(out)]
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL,
                                 start_new_session=True)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    with _LOCK:
        _SCREEN_PROC = {"rec_id": rec_id, "pid": proc.pid,
                        "out": str(out), "started_at": time.time(),
                        "label": label}
    return {"ok": True, "rec_id": rec_id, "out": str(out)}


def _screen_record_stop(args: Dict[str, Any]) -> Dict[str, Any]:
    global _SCREEN_PROC
    with _LOCK:
        if not _SCREEN_PROC:
            return {"ok": False, "error": "no active screen recording"}
        rec = _SCREEN_PROC
        _SCREEN_PROC = None
    try:
        os.killpg(os.getpgid(rec["pid"]), signal.SIGINT)
    except (ProcessLookupError, OSError):
        pass
    time.sleep(0.5)
    duration = time.time() - rec["started_at"]
    size = Path(rec["out"]).stat().st_size if Path(rec["out"]).exists() else 0
    return {"ok": True, "rec_id": rec["rec_id"], "out": rec["out"],
            "duration_s": round(duration, 2), "size_bytes": size}


def _screen_record_list(args: Dict[str, Any]) -> Dict[str, Any]:
    files = sorted(_REC_DIR.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
    return {"ok": True, "recordings": [
        {"path": str(p), "name": p.stem, "size": p.stat().st_size,
         "modified": p.stat().st_mtime} for p in files
    ], "count": len(files)}


# ── Direct input dispatch ─────────────────────────────────────────────
def _keystroke_sequence(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send a sequence of keystrokes via xdotool.

    Args:
      keys: list of xdotool key codes (e.g. ["ctrl+c", "ctrl+v"])
        OR a plain string to type
      delay_ms: delay between keys (default 50)
    """
    keys = args.get("keys")
    if not keys:
        return {"ok": False, "error": "keys required"}
    delay = int(args.get("delay_ms", 50))
    if not _have("xdotool"):
        return {"ok": False, "error": "xdotool not installed"}
    if isinstance(keys, str):
        try:
            r = subprocess.run(["xdotool", "type", "--delay", str(delay), keys],
                                capture_output=True, timeout=15)
            return {"ok": r.returncode == 0, "typed": keys[:120]}
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "xdotool type timed out"}
    if isinstance(keys, list):
        for k in keys:
            try:
                subprocess.run(["xdotool", "key", str(k)], capture_output=True, timeout=4)
                time.sleep(delay / 1000.0)
            except Exception as e:
                return {"ok": False, "error": f"failed at key '{k}': {e}"}
        return {"ok": True, "sent": keys}
    return {"ok": False, "error": "keys must be string or list"}


def _mouse_path(args: Dict[str, Any]) -> Dict[str, Any]:
    """Move the mouse along a path of (x,y) points.

    Args:
      points: list of [x, y] pairs (required)
      speed: pixels/sec (default 1000)
    """
    pts = args.get("points")
    if not pts or not isinstance(pts, list):
        return {"ok": False, "error": "points list required"}
    speed = float(args.get("speed", 1000))
    if not _have("xdotool"):
        return {"ok": False, "error": "xdotool not installed"}
    last = None
    for p in pts:
        if not isinstance(p, (list, tuple)) or len(p) < 2:
            continue
        x, y = int(p[0]), int(p[1])
        if last is not None:
            dx, dy = x - last[0], y - last[1]
            dist = (dx*dx + dy*dy) ** 0.5
            sleep = dist / max(1, speed)
            time.sleep(min(sleep, 2.0))
        subprocess.run(["xdotool", "mousemove", str(x), str(y)],
                        capture_output=True, timeout=2)
        last = (x, y)
    return {"ok": True, "points_traveled": len(pts)}


def _click_at_relative(args: Dict[str, Any]) -> Dict[str, Any]:
    """Click at a relative (0–1) position on a monitor.

    Args:
      x_pct: 0.0 to 1.0
      y_pct: 0.0 to 1.0
      monitor: 0-indexed monitor (default 0)
    """
    if args.get("x_pct") is None or args.get("y_pct") is None:
        return {"ok": False, "error": "x_pct and y_pct are required (0.0–1.0)"}
    try:
        xp = float(args.get("x_pct"))
        yp = float(args.get("y_pct"))
        monitor_idx = int(args.get("monitor", 0))
    except (TypeError, ValueError) as e:
        return {"ok": False, "error": f"invalid args: {e}"}
    # Get monitor geometry from xrandr
    try:
        r = subprocess.run(["xrandr", "--listmonitors"], capture_output=True, text=True, timeout=3)
        lines = [l for l in r.stdout.split("\n") if l.strip().startswith(str(monitor_idx) + ":")]
        if not lines:
            return {"ok": False, "error": f"monitor {monitor_idx} not found"}
        # Format: "0: +*HDMI-0 1920/598x1080/336+0+0  HDMI-0"
        import re
        m = re.search(r"(\d+)/\d+x(\d+)/\d+\+(-?\d+)\+(-?\d+)", lines[0])
        if not m:
            return {"ok": False, "error": "could not parse xrandr"}
        w, h, ox, oy = int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
    except Exception as e:
        return {"ok": False, "error": f"xrandr failed: {e}"}
    x = ox + int(xp * w)
    y = oy + int(yp * h)
    subprocess.run(["xdotool", "mousemove", str(x), str(y), "click", "1"],
                    capture_output=True, timeout=3)
    return {"ok": True, "x": x, "y": y, "monitor": monitor_idx}


# ── Hotkeys (registered globally — best-effort via xbindkeys file) ────
def _load_hotkeys() -> Dict[str, Any]:
    if not _HOTKEYS_FILE.exists():
        return {}
    try:
        return json.loads(_HOTKEYS_FILE.read_text())
    except Exception:
        return {}


def _save_hotkeys(data: Dict[str, Any]) -> None:
    _HOTKEYS_FILE.write_text(json.dumps(data, indent=2))


def _hotkey_register(args: Dict[str, Any]) -> Dict[str, Any]:
    """Register a global hotkey → fires a Leon tool.

    Args:
      combo: xdotool-style key combo (e.g. "ctrl+alt+l")
      action_tool: dotted tool name to call
      action_args: dict of args for the tool
    """
    combo = args.get("combo")
    tool = args.get("action_tool")
    if not combo or not tool:
        return {"ok": False, "error": "combo and action_tool required"}
    action_args = args.get("action_args") or {}
    keys = _load_hotkeys()
    keys[combo] = {"tool": tool, "args": action_args, "registered_at": time.time()}
    _save_hotkeys(keys)
    return {"ok": True, "combo": combo, "tool": tool,
            "note": "Hotkey registered in brain_state/hotkeys.json. "
                    "Use a separate xbindkeys/keyd daemon to actually bind it OS-wide. "
                    "Leon will execute the tool if /api/leon/hotkey?combo=<combo> is called."}


def _hotkey_list(args: Dict[str, Any]) -> Dict[str, Any]:
    keys = _load_hotkeys()
    return {"ok": True, "hotkeys": keys, "count": len(keys)}


def _hotkey_unregister(args: Dict[str, Any]) -> Dict[str, Any]:
    combo = args.get("combo")
    if not combo:
        return {"ok": False, "error": "combo required"}
    keys = _load_hotkeys()
    if combo not in keys:
        return {"ok": False, "error": f"hotkey '{combo}' not registered"}
    del keys[combo]
    _save_hotkeys(keys)
    return {"ok": True, "unregistered": combo}


EXTRA_TOOLS = {
    "automation.macro_record_start":   _macro_record_start,
    "automation.macro_record_stop":    _macro_record_stop,
    "automation.macro_list":           _macro_list,
    "automation.macro_play":           _macro_play,
    "automation.macro_delete":         _macro_delete,
    "automation.screen_record_start":  _screen_record_start,
    "automation.screen_record_stop":   _screen_record_stop,
    "automation.screen_record_list":   _screen_record_list,
    "automation.keystroke_sequence":   _keystroke_sequence,
    "automation.mouse_path":           _mouse_path,
    "automation.click_at_relative":    _click_at_relative,
    "automation.hotkey_register":      _hotkey_register,
    "automation.hotkey_list":          _hotkey_list,
    "automation.hotkey_unregister":    _hotkey_unregister,
}
