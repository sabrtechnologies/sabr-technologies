"""
travel.py — Leon's travel planning & destination-intelligence tool surface.

This module gives Leon everything it needs to plan a trip end to end:
flight & hotel search, live flight status, airport lookup, a local
SQLite-backed itinerary builder with budgets and packing lists, plus a
big stack of destination intelligence — country facts, currency, visa
guidance, travel advisories, timezones, power plugs, best time to visit,
trip countdowns, great-circle distance estimates and jet-lag plans.

Design philosophy mirrors `brain/integrations/life.py` and
`brain/integrations/productivity.py`:

  - One function per tool, taking a single `args` dict.
  - Every function returns `{"ok": True, ...}` or `{"ok": False, "error": ...}`
    — never raises out.
  - Credentials are read lazily from env on each call, so Leon picks up a
    new key the moment Dean sets it without a restart.
  - Network calls go through `_get` / `_post` helpers with a 12s timeout.
  - We prefer FREE, no-key public APIs (RestCountries, OpenSky,
    open.er-api currency rates) and only require API keys for the things
    that truly need them (Amadeus / Tequila for flights & hotels,
    AviationStack for live status).
  - All itinerary persistence is local SQLite at `brain_state/trips.db`
    (auto-created).

EXTRA_TOOLS at the bottom maps dotted names like `travel.country_info` to
the implementing function — import that dict from the responder / MCP
server to register everything in one shot.
"""

from __future__ import annotations

import math
import os
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from zoneinfo import ZoneInfo, available_timezones

import requests


# ──────────────────────────────────────────────────────────────────────────
# HTTP HELPERS
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_TIMEOUT = 12
_USER_AGENT = os.environ.get(
    "LEON_HTTP_CONTACT",
    "Leon/1.0 (Leon; Sabr; contact: support@sabrtechnologies.com)")


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    h = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
    if extra:
        h.update(extra)
    return h


def _get(url: str, params: Optional[dict] = None, headers: Optional[dict] = None,
         timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    """GET with uniform error envelope. Returns {ok, status, json|text} or {ok:False, error}."""
    try:
        r = requests.get(url, params=params, headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        try:
            out["json"] = r.json()
        except ValueError:
            out["text"] = r.text
    else:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


def _post(url: str, json_body: Optional[dict] = None, data: Optional[dict] = None,
          headers: Optional[dict] = None, timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    try:
        r = requests.post(url, json=json_body, data=data,
                           headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        try:
            out["json"] = r.json()
        except ValueError:
            out["text"] = r.text
    else:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


def _env(name: str) -> Optional[str]:
    v = os.environ.get(name)
    return v.strip() if v and v.strip() else None


def _require_arg(args: dict, key: str) -> Any:
    """Return args[key] or raise KeyError — caller wraps in try/except."""
    if key not in args or args[key] in (None, ""):
        raise KeyError(key)
    return args[key]


def _ok(**kw: Any) -> Dict[str, Any]:
    out = {"ok": True}
    out.update(kw)
    return out


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


# ──────────────────────────────────────────────────────────────────────────
# SQLITE — itinerary / trips persistence
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/)."""
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "trips.db")


_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS trips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    destination TEXT,
    start_date TEXT,
    end_date TEXT,
    budget REAL,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS trip_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id INTEGER NOT NULL,
    type TEXT DEFAULT 'activity',
    title TEXT NOT NULL,
    date TEXT,
    time TEXT,
    cost REAL,
    notes TEXT,
    created_at REAL DEFAULT (strftime('%s','now')),
    FOREIGN KEY (trip_id) REFERENCES trips(id)
);
CREATE TABLE IF NOT EXISTS packing_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id INTEGER NOT NULL,
    item TEXT NOT NULL,
    category TEXT,
    packed INTEGER DEFAULT 0,
    created_at REAL DEFAULT (strftime('%s','now')),
    FOREIGN KEY (trip_id) REFERENCES trips(id)
);
"""


def _conn() -> sqlite3.Connection:
    """Lazy SQLite connection. Creates schema on first call."""
    global _DB_CONN
    if _DB_CONN is not None:
        return _DB_CONN
    with _DB_LOCK:
        if _DB_CONN is not None:
            return _DB_CONN
        conn = sqlite3.connect(_db_path(), timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
        _DB_CONN = conn
    return _DB_CONN


def _row(r: Optional[sqlite3.Row]) -> Optional[Dict[str, Any]]:
    return dict(r) if r is not None else None


def _rows(rs) -> List[Dict[str, Any]]:
    return [dict(r) for r in rs]


# ──────────────────────────────────────────────────────────────────────────
# MISC HELPERS
# ──────────────────────────────────────────────────────────────────────────


_VALID_ITEM_TYPES = {"flight", "hotel", "activity", "meal", "transport"}

_ITEM_TYPE_ORDER = {"transport": 0, "flight": 1, "hotel": 2, "meal": 3, "activity": 4}


def _parse_date(s: Any) -> Optional[datetime]:
    """Best-effort parse of YYYY-MM-DD (or with time)."""
    if not s:
        return None
    txt = str(s).strip()
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M",
                "%Y-%m-%dT%H:%M:%S", "%Y/%m/%d", "%m/%d/%Y"):
        try:
            return datetime.strptime(txt, fmt)
        except ValueError:
            continue
    return None


def _restcountries(country: str) -> Dict[str, Any]:
    """Look up a single country on RestCountries (free, no key). Returns {ok, data} or {ok:False}."""
    q = str(country).strip()
    resp = _get(f"https://restcountries.com/v3.1/name/{requests.utils.quote(q)}",
                params={"fields": "name,capital,currencies,languages,timezones,"
                                  "idd,latlng,region,subregion,population,flags,cca2,cca3"})
    if not resp.get("ok"):
        # try as a code (cca2/cca3)
        resp = _get(f"https://restcountries.com/v3.1/alpha/{requests.utils.quote(q)}",
                    params={"fields": "name,capital,currencies,languages,timezones,"
                                      "idd,latlng,region,subregion,population,flags,cca2,cca3"})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", f"country not found: {country}")}
    data = resp.get("json")
    if isinstance(data, list):
        if not data:
            return {"ok": False, "error": f"country not found: {country}"}
        # prefer an exact-ish common-name match
        best = data[0]
        for c in data:
            cn = (c.get("name") or {}).get("common", "")
            if cn.lower() == q.lower():
                best = c
                break
        data = best
    if not isinstance(data, dict):
        return {"ok": False, "error": f"country not found: {country}"}
    return {"ok": True, "data": data}


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return r * 2 * math.asin(math.sqrt(a))


def _geocode_city(city: str) -> Optional[Dict[str, Any]]:
    """Free geocode via Open-Meteo geocoding API. Returns {name,lat,lon,country,timezone} or None."""
    resp = _get("https://geocoding-api.open-meteo.com/v1/search",
                params={"name": str(city).strip(), "count": 1, "language": "en"})
    if not resp.get("ok"):
        return None
    results = (resp.get("json") or {}).get("results") or []
    if not results:
        return None
    r = results[0]
    return {
        "name": r.get("name"),
        "lat": r.get("latitude"),
        "lon": r.get("longitude"),
        "country": r.get("country"),
        "timezone": r.get("timezone"),
        "admin": r.get("admin1"),
    }


# ── Amadeus OAuth ──────────────────────────────────────────────────────────

_AMADEUS_TOKEN: Dict[str, Any] = {"value": None, "expires": 0.0}


def _amadeus_token() -> Dict[str, Any]:
    """Fetch (and cache) an Amadeus OAuth token. Returns {ok, token} or {ok:False, error}."""
    cid = _env("AMADEUS_CLIENT_ID")
    secret = _env("AMADEUS_CLIENT_SECRET")
    if not cid or not secret:
        return {"ok": False, "error": "AMADEUS_CLIENT_ID + AMADEUS_CLIENT_SECRET not set"}
    if _AMADEUS_TOKEN["value"] and _AMADEUS_TOKEN["expires"] > time.time() + 30:
        return {"ok": True, "token": _AMADEUS_TOKEN["value"]}
    resp = _post(
        "https://test.api.amadeus.com/v1/security/oauth2/token",
        data={"grant_type": "client_credentials",
              "client_id": cid, "client_secret": secret},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "amadeus auth failed")}
    j = resp.get("json") or {}
    tok = j.get("access_token")
    if not tok:
        return {"ok": False, "error": "amadeus returned no access_token"}
    _AMADEUS_TOKEN["value"] = tok
    _AMADEUS_TOKEN["expires"] = time.time() + float(j.get("expires_in", 1799))
    return {"ok": True, "token": tok}


def _amadeus_get(path: str, params: dict) -> Dict[str, Any]:
    tok = _amadeus_token()
    if not tok.get("ok"):
        return tok
    return _get(f"https://test.api.amadeus.com{path}", params=params,
                headers={"Authorization": f"Bearer {tok['token']}"})


# ──────────────────────────────────────────────────────────────────────────
# FLIGHTS
# ──────────────────────────────────────────────────────────────────────────


def flight_search(args: dict) -> dict:
    """Search flights. Amadeus (AMADEUS_CLIENT_ID/SECRET) or Tequila/Kiwi (TEQUILA_API_KEY)."""
    try:
        origin = str(_require_arg(args, "origin")).upper().strip()
        dest = str(_require_arg(args, "destination")).upper().strip()
        depart = str(_require_arg(args, "depart_date")).strip()
    except KeyError as e:
        return _err(f"{e.args[0]} is required")
    return_date = args.get("return_date")
    adults = int(args.get("adults", 1) or 1)

    have_amadeus = _env("AMADEUS_CLIENT_ID") and _env("AMADEUS_CLIENT_SECRET")
    have_tequila = _env("TEQUILA_API_KEY")
    if not have_amadeus and not have_tequila:
        return _err("flight search needs API keys — set AMADEUS_CLIENT_ID + "
                    "AMADEUS_CLIENT_SECRET (amadeus.com, free tier) or "
                    "TEQUILA_API_KEY (tequila.kiwi.com)")

    if have_amadeus:
        params = {
            "originLocationCode": origin,
            "destinationLocationCode": dest,
            "departureDate": depart,
            "adults": adults,
            "max": 10,
            "currencyCode": "USD",
        }
        if return_date:
            params["returnDate"] = str(return_date).strip()
        resp = _amadeus_get("/v2/shopping/flight-offers", params)
        if not resp.get("ok"):
            return _err(resp.get("error", "amadeus flight search failed"))
        offers = (resp.get("json") or {}).get("data") or []
        flights = []
        for o in offers[:10]:
            price = (o.get("price") or {}).get("grandTotal")
            segs = []
            for itin in o.get("itineraries", []):
                for s in itin.get("segments", []):
                    segs.append({
                        "from": (s.get("departure") or {}).get("iataCode"),
                        "to": (s.get("arrival") or {}).get("iataCode"),
                        "depart": (s.get("departure") or {}).get("at"),
                        "arrive": (s.get("arrival") or {}).get("at"),
                        "carrier": s.get("carrierCode"),
                        "flight": s.get("number"),
                    })
            flights.append({"price_usd": price, "stops": max(0, len(segs) - 1),
                            "segments": segs})
        flights.sort(key=lambda f: float(f["price_usd"] or 1e9))
        return _ok(provider="amadeus", origin=origin, destination=dest,
                   depart_date=depart, return_date=return_date,
                   count=len(flights), flights=flights)

    # Tequila / Kiwi
    dfmt = lambda d: _parse_date(d).strftime("%d/%m/%Y") if _parse_date(d) else d
    params = {
        "fly_from": origin, "fly_to": dest,
        "date_from": dfmt(depart), "date_to": dfmt(depart),
        "adults": adults, "curr": "USD", "limit": 10, "sort": "price",
    }
    if return_date:
        params["return_from"] = dfmt(return_date)
        params["return_to"] = dfmt(return_date)
    resp = _get("https://api.tequila.kiwi.com/v2/search", params=params,
                headers={"apikey": _env("TEQUILA_API_KEY")})
    if not resp.get("ok"):
        return _err(resp.get("error", "tequila flight search failed"))
    data = (resp.get("json") or {}).get("data") or []
    flights = []
    for o in data[:10]:
        flights.append({
            "price_usd": o.get("price"),
            "airlines": o.get("airlines"),
            "from": o.get("cityFrom"),
            "to": o.get("cityTo"),
            "depart": o.get("local_departure"),
            "arrive": o.get("local_arrival"),
            "duration": (o.get("duration") or {}).get("total"),
            "deep_link": o.get("deep_link"),
        })
    return _ok(provider="tequila", origin=origin, destination=dest,
               depart_date=depart, return_date=return_date,
               count=len(flights), flights=flights)


def flight_cheapest_dates(args: dict) -> dict:
    """Cheapest day to fly within a month. Amadeus flight-dates or Tequila scan."""
    try:
        origin = str(_require_arg(args, "origin")).upper().strip()
        dest = str(_require_arg(args, "destination")).upper().strip()
        month = str(_require_arg(args, "month")).strip()  # YYYY-MM
    except KeyError as e:
        return _err(f"{e.args[0]} is required")

    have_amadeus = _env("AMADEUS_CLIENT_ID") and _env("AMADEUS_CLIENT_SECRET")
    have_tequila = _env("TEQUILA_API_KEY")
    if not have_amadeus and not have_tequila:
        return _err("flight pricing needs API keys — set Amadeus or TEQUILA_API_KEY")

    # normalise month → first/last day
    try:
        y, m = month.split("-")[:2]
        first = datetime(int(y), int(m), 1)
        nxt = datetime(int(y) + (int(m) == 12), (int(m) % 12) + 1, 1)
        last = nxt - timedelta(days=1)
    except Exception:
        return _err("month must be YYYY-MM")

    if have_amadeus:
        resp = _amadeus_get("/v1/shopping/flight-dates",
                            {"origin": origin, "destination": dest,
                             "departureDate": f"{first:%Y-%m-%d},{last:%Y-%m-%d}"})
        if resp.get("ok"):
            data = (resp.get("json") or {}).get("data") or []
            options = sorted(
                ({"depart_date": d.get("departureDate"),
                  "return_date": d.get("returnDate"),
                  "price_usd": (d.get("price") or {}).get("total")} for d in data),
                key=lambda x: float(x["price_usd"] or 1e9))
            if options:
                return _ok(provider="amadeus", origin=origin, destination=dest,
                           month=month, cheapest=options[0], all_options=options[:30])
        # fall through to tequila if amadeus had no inventory

    if have_tequila:
        resp = _get("https://api.tequila.kiwi.com/v2/search",
                    params={"fly_from": origin, "fly_to": dest,
                            "date_from": f"{first:%d/%m/%Y}",
                            "date_to": f"{last:%d/%m/%Y}",
                            "curr": "USD", "limit": 200, "sort": "price",
                            "one_for_city": 0},
                    headers={"apikey": _env("TEQUILA_API_KEY")})
        if not resp.get("ok"):
            return _err(resp.get("error", "tequila scan failed"))
        data = (resp.get("json") or {}).get("data") or []
        by_day: Dict[str, float] = {}
        for o in data:
            day = (o.get("local_departure") or "")[:10]
            price = o.get("price")
            if day and price is not None and (day not in by_day or price < by_day[day]):
                by_day[day] = price
        options = sorted(({"depart_date": d, "price_usd": p} for d, p in by_day.items()),
                         key=lambda x: x["price_usd"])
        if not options:
            return _err("no fares found for that month")
        return _ok(provider="tequila", origin=origin, destination=dest,
                   month=month, cheapest=options[0], all_options=options)

    return _err("no fares found for that month")


def flight_status(args: dict) -> dict:
    """Live status of a flight by number/IATA code. AviationStack if key set, else OpenSky."""
    try:
        code = str(_require_arg(args, "flight_number")).upper().replace(" ", "").strip()
    except KeyError:
        return _err("flight_number is required")

    key = _env("AVIATIONSTACK_API_KEY")
    if key:
        resp = _get("http://api.aviationstack.com/v1/flights",
                    params={"access_key": key, "flight_iata": code, "limit": 1})
        if not resp.get("ok"):
            return _err(resp.get("error", "aviationstack failed"))
        data = (resp.get("json") or {}).get("data") or []
        if not data:
            return _err(f"no flight found for {code}")
        f = data[0]
        dep, arr = f.get("departure") or {}, f.get("arrival") or {}
        return _ok(provider="aviationstack", result={
            "flight": code,
            "status": f.get("flight_status"),
            "airline": (f.get("airline") or {}).get("name"),
            "departure_airport": dep.get("airport"),
            "departure_scheduled": dep.get("scheduled"),
            "departure_estimated": dep.get("estimated"),
            "departure_gate": dep.get("gate"),
            "arrival_airport": arr.get("airport"),
            "arrival_scheduled": arr.get("scheduled"),
            "arrival_estimated": arr.get("estimated"),
            "arrival_gate": arr.get("gate"),
            "delay_min": dep.get("delay"),
        })

    # OpenSky fallback — by callsign (best effort, free, no key)
    resp = _get("https://opensky-network.org/api/states/all")
    if not resp.get("ok"):
        return _err("no AVIATIONSTACK_API_KEY set and OpenSky fallback failed")
    states = (resp.get("json") or {}).get("states") or []
    for s in states:
        callsign = (s[1] or "").strip().upper()
        if callsign and callsign == code:
            return _ok(provider="opensky", result={
                "flight": code,
                "callsign": callsign,
                "origin_country": s[2],
                "longitude": s[5],
                "latitude": s[6],
                "altitude_m": s[7],
                "velocity_ms": s[9],
                "on_ground": s[8],
                "note": "live position from OpenSky — set AVIATIONSTACK_API_KEY "
                        "for scheduled/gate/delay detail",
            })
    return _err(f"flight {code} not currently airborne (OpenSky) — set "
                f"AVIATIONSTACK_API_KEY for scheduled-flight lookups")


# minimal airport DB for offline lookups; network lookup augments it
_AIRPORTS: Dict[str, Dict[str, Any]] = {
    "LAX": {"name": "Los Angeles International", "city": "Los Angeles",
            "country": "US", "lat": 33.9416, "lon": -118.4085, "tz": "America/Los_Angeles"},
    "JFK": {"name": "John F. Kennedy International", "city": "New York",
            "country": "US", "lat": 40.6413, "lon": -73.7781, "tz": "America/New_York"},
    "SFO": {"name": "San Francisco International", "city": "San Francisco",
            "country": "US", "lat": 37.6213, "lon": -122.3790, "tz": "America/Los_Angeles"},
    "ORD": {"name": "O'Hare International", "city": "Chicago",
            "country": "US", "lat": 41.9742, "lon": -87.9073, "tz": "America/Chicago"},
    "ATL": {"name": "Hartsfield-Jackson Atlanta International", "city": "Atlanta",
            "country": "US", "lat": 33.6407, "lon": -84.4277, "tz": "America/New_York"},
    "DFW": {"name": "Dallas/Fort Worth International", "city": "Dallas",
            "country": "US", "lat": 32.8998, "lon": -97.0403, "tz": "America/Chicago"},
    "MIA": {"name": "Miami International", "city": "Miami",
            "country": "US", "lat": 25.7959, "lon": -80.2870, "tz": "America/New_York"},
    "SEA": {"name": "Seattle-Tacoma International", "city": "Seattle",
            "country": "US", "lat": 47.4502, "lon": -122.3088, "tz": "America/Los_Angeles"},
    "LHR": {"name": "London Heathrow", "city": "London",
            "country": "GB", "lat": 51.4700, "lon": -0.4543, "tz": "Europe/London"},
    "CDG": {"name": "Paris Charles de Gaulle", "city": "Paris",
            "country": "FR", "lat": 49.0097, "lon": 2.5479, "tz": "Europe/Paris"},
    "AMS": {"name": "Amsterdam Schiphol", "city": "Amsterdam",
            "country": "NL", "lat": 52.3105, "lon": 4.7683, "tz": "Europe/Amsterdam"},
    "FRA": {"name": "Frankfurt", "city": "Frankfurt",
            "country": "DE", "lat": 50.0379, "lon": 8.5622, "tz": "Europe/Berlin"},
    "DXB": {"name": "Dubai International", "city": "Dubai",
            "country": "AE", "lat": 25.2532, "lon": 55.3657, "tz": "Asia/Dubai"},
    "HND": {"name": "Tokyo Haneda", "city": "Tokyo",
            "country": "JP", "lat": 35.5494, "lon": 139.7798, "tz": "Asia/Tokyo"},
    "NRT": {"name": "Tokyo Narita", "city": "Tokyo",
            "country": "JP", "lat": 35.7720, "lon": 140.3929, "tz": "Asia/Tokyo"},
    "SIN": {"name": "Singapore Changi", "city": "Singapore",
            "country": "SG", "lat": 1.3644, "lon": 103.9915, "tz": "Asia/Singapore"},
    "SYD": {"name": "Sydney Kingsford Smith", "city": "Sydney",
            "country": "AU", "lat": -33.9399, "lon": 151.1753, "tz": "Australia/Sydney"},
    "HKG": {"name": "Hong Kong International", "city": "Hong Kong",
            "country": "HK", "lat": 22.3080, "lon": 113.9185, "tz": "Asia/Hong_Kong"},
    "YYZ": {"name": "Toronto Pearson", "city": "Toronto",
            "country": "CA", "lat": 43.6777, "lon": -79.6248, "tz": "America/Toronto"},
    "MEX": {"name": "Mexico City International", "city": "Mexico City",
            "country": "MX", "lat": 19.4363, "lon": -99.0721, "tz": "America/Mexico_City"},
}


def airport_info(args: dict) -> dict:
    """Look up an airport by IATA code. Uses local DB, augments with a free network lookup."""
    try:
        code = str(_require_arg(args, "iata_code")).upper().strip()
    except KeyError:
        return _err("iata_code is required")
    if len(code) != 3:
        return _err("iata_code must be a 3-letter IATA code (e.g. LAX)")

    info = dict(_AIRPORTS.get(code, {}))
    # try free network DB to fill / verify
    resp = _get(f"https://airport-data.com/api/ap_info.json", params={"iata": code})
    if resp.get("ok"):
        j = resp.get("json") or {}
        if j.get("name"):
            info.setdefault("name", j.get("name"))
            info["city"] = j.get("location") or info.get("city")
            info["country"] = j.get("country") or info.get("country")
            try:
                if j.get("latitude"):
                    info["lat"] = float(j["latitude"])
                if j.get("longitude"):
                    info["lon"] = float(j["longitude"])
            except (TypeError, ValueError):
                pass
            info["icao"] = j.get("icao")
    if not info:
        return _err(f"unknown airport code: {code}")
    info["iata"] = code
    return _ok(airport=info)


# ──────────────────────────────────────────────────────────────────────────
# HOTELS
# ──────────────────────────────────────────────────────────────────────────


def hotel_search(args: dict) -> dict:
    """Search hotels in a city. Amadeus hotel search (needs AMADEUS_CLIENT_ID/SECRET)."""
    try:
        city = str(_require_arg(args, "city")).strip()
        checkin = str(_require_arg(args, "checkin")).strip()
        checkout = str(_require_arg(args, "checkout")).strip()
    except KeyError as e:
        return _err(f"{e.args[0]} is required")
    adults = int(args.get("adults", 2) or 2)

    if not (_env("AMADEUS_CLIENT_ID") and _env("AMADEUS_CLIENT_SECRET")) \
            and not _env("BOOKING_API_KEY"):
        return _err("hotel search needs API keys — set AMADEUS_CLIENT_ID + "
                    "AMADEUS_CLIENT_SECRET (amadeus.com) or BOOKING_API_KEY")

    if _env("AMADEUS_CLIENT_ID") and _env("AMADEUS_CLIENT_SECRET"):
        # step 1: resolve a city → cityCode (IATA city code)
        loc = _amadeus_get("/v1/reference-data/locations",
                           {"keyword": city, "subType": "CITY", "page[limit]": 1})
        if not loc.get("ok"):
            return _err(loc.get("error", "amadeus city lookup failed"))
        cdata = (loc.get("json") or {}).get("data") or []
        if not cdata:
            return _err(f"could not resolve city: {city}")
        city_code = cdata[0].get("iataCode")
        # step 2: hotels by city
        hl = _amadeus_get("/v1/reference-data/locations/hotels/by-city",
                          {"cityCode": city_code})
        if not hl.get("ok"):
            return _err(hl.get("error", "amadeus hotel list failed"))
        hotels = [(h.get("hotelId"), h.get("name"))
                  for h in ((hl.get("json") or {}).get("data") or [])][:20]
        if not hotels:
            return _err(f"no hotels listed for {city}")
        # step 3: offers/pricing for the first batch
        ids = ",".join(h[0] for h in hotels if h[0])
        off = _amadeus_get("/v3/shopping/hotel-offers",
                           {"hotelIds": ids, "checkInDate": checkin,
                            "checkOutDate": checkout, "adults": adults,
                            "currency": "USD", "bestRateOnly": "true"})
        results = []
        if off.get("ok"):
            for h in ((off.get("json") or {}).get("data") or []):
                hotel = h.get("hotel") or {}
                offers = h.get("offers") or []
                price = (offers[0].get("price") or {}).get("total") if offers else None
                results.append({
                    "hotel_id": hotel.get("hotelId"),
                    "name": hotel.get("name"),
                    "price_total_usd": price,
                    "checkin": checkin, "checkout": checkout,
                })
        if not results:
            results = [{"hotel_id": hid, "name": name,
                        "price_total_usd": None,
                        "note": "no live offer — call hotel_details for pricing"}
                       for hid, name in hotels]
        results.sort(key=lambda x: float(x.get("price_total_usd") or 1e9))
        return _ok(provider="amadeus", city=city, city_code=city_code,
                   checkin=checkin, checkout=checkout,
                   count=len(results), hotels=results)

    return _err("BOOKING_API_KEY set but Booking integration not configured — "
                "use Amadeus keys for hotel search")


def hotel_details(args: dict) -> dict:
    """Get offers/details for a specific hotel id (Amadeus)."""
    try:
        hotel_id = str(_require_arg(args, "hotel_id")).strip()
    except KeyError:
        return _err("hotel_id is required")
    if not (_env("AMADEUS_CLIENT_ID") and _env("AMADEUS_CLIENT_SECRET")):
        return _err("hotel details needs AMADEUS_CLIENT_ID + AMADEUS_CLIENT_SECRET")
    params = {"hotelIds": hotel_id, "currency": "USD"}
    if args.get("checkin"):
        params["checkInDate"] = str(args["checkin"]).strip()
    if args.get("checkout"):
        params["checkOutDate"] = str(args["checkout"]).strip()
    if args.get("adults"):
        params["adults"] = int(args["adults"])
    resp = _amadeus_get("/v3/shopping/hotel-offers", params)
    if not resp.get("ok"):
        return _err(resp.get("error", "amadeus hotel details failed"))
    data = (resp.get("json") or {}).get("data") or []
    if not data:
        return _err(f"no offers found for hotel {hotel_id}")
    h = data[0]
    hotel = h.get("hotel") or {}
    offers = []
    for o in h.get("offers", []):
        offers.append({
            "room": ((o.get("room") or {}).get("typeEstimated") or {}).get("category"),
            "description": ((o.get("room") or {}).get("description") or {}).get("text"),
            "board": o.get("boardType"),
            "price_total_usd": (o.get("price") or {}).get("total"),
            "checkin": o.get("checkInDate"),
            "checkout": o.get("checkOutDate"),
            "cancellable": bool((o.get("policies") or {}).get("cancellations")),
        })
    return _ok(provider="amadeus", hotel={
        "hotel_id": hotel.get("hotelId"),
        "name": hotel.get("name"),
        "latitude": hotel.get("latitude"),
        "longitude": hotel.get("longitude"),
        "available": h.get("available"),
        "offers": offers,
    })


# ──────────────────────────────────────────────────────────────────────────
# ITINERARY — local SQLite trips
# ──────────────────────────────────────────────────────────────────────────


def trip_create(args: dict) -> dict:
    """Create a trip. {name, destination, start_date, end_date, budget?}."""
    try:
        name = str(_require_arg(args, "name")).strip()
    except KeyError:
        return _err("name is required")
    dest = args.get("destination")
    start = args.get("start_date")
    end = args.get("end_date")
    budget = args.get("budget")
    try:
        budget = float(budget) if budget not in (None, "") else None
    except (TypeError, ValueError):
        return _err("budget must be a number")
    try:
        c = _conn()
        cur = c.execute(
            "INSERT INTO trips (name, destination, start_date, end_date, budget) "
            "VALUES (?,?,?,?,?)",
            (name, dest, start, end, budget))
        c.commit()
        trip_id = cur.lastrowid
        row = c.execute("SELECT * FROM trips WHERE id=?", (trip_id,)).fetchone()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    return _ok(trip=_row(row))


def trip_list(args: dict) -> dict:
    """List all trips, soonest start first."""
    try:
        rows = _conn().execute(
            "SELECT * FROM trips ORDER BY "
            "CASE WHEN start_date IS NULL THEN 1 ELSE 0 END, start_date ASC"
        ).fetchall()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    return _ok(count=len(rows), trips=_rows(rows))


def trip_get(args: dict) -> dict:
    """Get a single trip with a summary of its items and budget."""
    try:
        trip_id = int(_require_arg(args, "trip_id"))
    except KeyError:
        return _err("trip_id is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    try:
        c = _conn()
        trip = c.execute("SELECT * FROM trips WHERE id=?", (trip_id,)).fetchone()
        if trip is None:
            return _err(f"trip {trip_id} not found")
        items = c.execute("SELECT * FROM trip_items WHERE trip_id=?", (trip_id,)).fetchall()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    t = _row(trip)
    planned = sum(float(i["cost"] or 0) for i in items)
    t["item_count"] = len(items)
    t["planned_cost"] = round(planned, 2)
    return _ok(trip=t)


def trip_add_item(args: dict) -> dict:
    """Add an itinerary item. type: flight/hotel/activity/meal/transport."""
    try:
        trip_id = int(_require_arg(args, "trip_id"))
        itype = str(_require_arg(args, "type")).strip().lower()
        title = str(_require_arg(args, "title")).strip()
    except KeyError as e:
        return _err(f"{e.args[0]} is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    if itype not in _VALID_ITEM_TYPES:
        return _err(f"type must be one of {sorted(_VALID_ITEM_TYPES)}")
    cost = args.get("cost")
    try:
        cost = float(cost) if cost not in (None, "") else None
    except (TypeError, ValueError):
        return _err("cost must be a number")
    try:
        c = _conn()
        if c.execute("SELECT 1 FROM trips WHERE id=?", (trip_id,)).fetchone() is None:
            return _err(f"trip {trip_id} not found")
        cur = c.execute(
            "INSERT INTO trip_items (trip_id, type, title, date, time, cost, notes) "
            "VALUES (?,?,?,?,?,?,?)",
            (trip_id, itype, title, args.get("date"), args.get("time"),
             cost, args.get("notes")))
        c.commit()
        row = c.execute("SELECT * FROM trip_items WHERE id=?",
                        (cur.lastrowid,)).fetchone()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    return _ok(item=_row(row))


def trip_items(args: dict) -> dict:
    """Ordered itinerary for a trip — sorted by date, then time, then type."""
    try:
        trip_id = int(_require_arg(args, "trip_id"))
    except KeyError:
        return _err("trip_id is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    try:
        rows = _conn().execute(
            "SELECT * FROM trip_items WHERE trip_id=?", (trip_id,)).fetchall()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    items = _rows(rows)
    items.sort(key=lambda i: (
        i.get("date") or "9999-12-31",
        i.get("time") or "99:99",
        _ITEM_TYPE_ORDER.get(i.get("type"), 9),
    ))
    return _ok(trip_id=trip_id, count=len(items), items=items)


def trip_budget_status(args: dict) -> dict:
    """Compare planned itinerary cost against the trip budget."""
    try:
        trip_id = int(_require_arg(args, "trip_id"))
    except KeyError:
        return _err("trip_id is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    try:
        c = _conn()
        trip = c.execute("SELECT * FROM trips WHERE id=?", (trip_id,)).fetchone()
        if trip is None:
            return _err(f"trip {trip_id} not found")
        items = c.execute("SELECT type, cost FROM trip_items WHERE trip_id=?",
                          (trip_id,)).fetchall()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    planned = sum(float(i["cost"] or 0) for i in items)
    by_type: Dict[str, float] = {}
    for i in items:
        by_type[i["type"]] = round(by_type.get(i["type"], 0) + float(i["cost"] or 0), 2)
    budget = trip["budget"]
    out = {
        "trip_id": trip_id,
        "trip_name": trip["name"],
        "budget": budget,
        "planned_cost": round(planned, 2),
        "by_type": by_type,
    }
    if budget is not None:
        out["remaining"] = round(budget - planned, 2)
        out["pct_used"] = round(planned / budget * 100, 1) if budget else None
        out["over_budget"] = planned > budget
    else:
        out["note"] = "no budget set on this trip"
    return _ok(**out)


def trip_delete(args: dict) -> dict:
    """Delete a trip and all of its items / packing list. HIGH — irreversible."""
    try:
        trip_id = int(_require_arg(args, "trip_id"))
    except KeyError:
        return _err("trip_id is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    try:
        c = _conn()
        if c.execute("SELECT 1 FROM trips WHERE id=?", (trip_id,)).fetchone() is None:
            return _err(f"trip {trip_id} not found")
        items = c.execute("DELETE FROM trip_items WHERE trip_id=?", (trip_id,)).rowcount
        packing = c.execute("DELETE FROM packing_items WHERE trip_id=?", (trip_id,)).rowcount
        c.execute("DELETE FROM trips WHERE id=?", (trip_id,))
        c.commit()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    return _ok(deleted_trip=trip_id, deleted_items=items, deleted_packing=packing)


# ──────────────────────────────────────────────────────────────────────────
# PACKING LISTS
# ──────────────────────────────────────────────────────────────────────────


_PACKING_BASE = {
    "Essentials": ["Passport / ID", "Wallet & cards", "Phone", "Phone charger",
                   "Travel documents / boarding passes", "House keys", "Medications"],
    "Clothing": ["Underwear", "Socks", "T-shirts / tops", "Pants / shorts",
                 "Sleepwear", "Comfortable walking shoes"],
    "Toiletries": ["Toothbrush & toothpaste", "Deodorant", "Shampoo / soap",
                   "Skincare", "Razor"],
    "Tech": ["Power bank", "Headphones", "Universal travel adapter"],
}

_PACKING_CLIMATE = {
    "hot": ["Sunscreen", "Sunglasses", "Hat / cap", "Light breathable clothing",
            "Sandals", "Reusable water bottle", "Insect repellent"],
    "cold": ["Warm jacket / coat", "Thermal layers", "Gloves", "Beanie / warm hat",
             "Scarf", "Warm socks", "Lip balm", "Boots"],
    "rainy": ["Rain jacket / poncho", "Umbrella", "Waterproof shoes",
              "Quick-dry clothing"],
    "tropical": ["Sunscreen", "Insect repellent", "Light rain jacket",
                 "Swimwear", "Quick-dry towel", "Sandals"],
    "temperate": ["Light jacket", "Layerable clothing"],
}

_PACKING_TRIP_TYPE = {
    "leisure": ["Swimwear", "Camera", "Book / e-reader", "Day bag / backpack"],
    "business": ["Business attire", "Laptop & charger", "Notebook & pen",
                 "Business cards", "Dress shoes"],
    "beach": ["Swimwear", "Beach towel", "Flip-flops", "Snorkel gear",
              "Waterproof phone pouch", "After-sun lotion"],
    "hiking": ["Hiking boots", "Daypack", "Trail snacks", "Water bottle / hydration",
               "First-aid kit", "Map / GPS", "Trekking poles", "Quick-dry layers"],
    "city": ["Comfortable walking shoes", "Day bag", "Portable charger",
             "City map / offline maps"],
    "ski": ["Ski jacket & pants", "Goggles", "Gloves", "Thermal base layers",
            "Helmet", "Hand warmers"],
    "backpacking": ["Backpack rain cover", "Quick-dry towel", "Padlock",
                    "Laundry detergent sheets", "Travel sheet liner", "Headlamp"],
}

_HOT_REGIONS = {"africa", "south america", "central america", "caribbean",
                "southeast asia", "south asia", "middle east", "oceania"}


def _infer_climate(destination: str) -> str:
    """Best-effort climate guess from a country/region name (used when climate omitted)."""
    info = _restcountries(destination)
    if info.get("ok"):
        region = (info["data"].get("region") or "").lower()
        subregion = (info["data"].get("subregion") or "").lower()
        latlng = info["data"].get("latlng") or []
        if latlng:
            abslat = abs(latlng[0])
            if abslat < 23.5:
                return "tropical"
            if abslat > 55:
                return "cold"
        if subregion in _HOT_REGIONS or region == "africa":
            return "hot"
    return "temperate"


def packing_list_generate(args: dict) -> dict:
    """Generate a smart packing list from destination + days + trip_type + climate."""
    try:
        destination = str(_require_arg(args, "destination")).strip()
        days = int(_require_arg(args, "days"))
    except KeyError as e:
        return _err(f"{e.args[0]} is required")
    except (TypeError, ValueError):
        return _err("days must be an integer")
    if days < 1:
        return _err("days must be >= 1")
    trip_type = str(args.get("trip_type", "leisure")).strip().lower()
    climate = args.get("climate")
    climate = str(climate).strip().lower() if climate else _infer_climate(destination)

    categories: Dict[str, List[str]] = {k: list(v) for k, v in _PACKING_BASE.items()}
    # scale clothing counts by trip length
    clothing_units = min(days, 10)
    categories["Clothing"] = [
        f"Underwear x{clothing_units}",
        f"Socks x{clothing_units}",
        f"Tops / t-shirts x{min(days, 8)}",
        f"Pants / shorts x{max(2, min(days // 2, 5))}",
        "Sleepwear", "Comfortable walking shoes",
    ]
    if days > 7:
        categories["Essentials"].append("Plan for laundry mid-trip")

    cl = _PACKING_CLIMATE.get(climate, _PACKING_CLIMATE["temperate"])
    categories[f"Climate ({climate})"] = list(cl)

    tt = _PACKING_TRIP_TYPE.get(trip_type)
    if tt:
        categories[f"Trip type ({trip_type})"] = list(tt)

    flat = [it for items in categories.values() for it in items]
    return _ok(destination=destination, days=days, trip_type=trip_type,
               climate=climate, total_items=len(flat),
               categories=categories, items=flat)


def packing_list_save(args: dict) -> dict:
    """Save a packing list against a trip. items: list of strings or {item, category}."""
    try:
        trip_id = int(_require_arg(args, "trip_id"))
        items = _require_arg(args, "items")
    except KeyError as e:
        return _err(f"{e.args[0]} is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    if not isinstance(items, (list, tuple)):
        return _err("items must be a list")
    try:
        c = _conn()
        if c.execute("SELECT 1 FROM trips WHERE id=?", (trip_id,)).fetchone() is None:
            return _err(f"trip {trip_id} not found")
        # replace existing list for this trip
        c.execute("DELETE FROM packing_items WHERE trip_id=?", (trip_id,))
        rows = []
        for it in items:
            if isinstance(it, dict):
                name = str(it.get("item", "")).strip()
                cat = it.get("category")
                packed = 1 if it.get("packed") else 0
            else:
                name, cat, packed = str(it).strip(), None, 0
            if name:
                rows.append((trip_id, name, cat, packed))
        c.executemany(
            "INSERT INTO packing_items (trip_id, item, category, packed) "
            "VALUES (?,?,?,?)", rows)
        c.commit()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    return _ok(trip_id=trip_id, saved=len(rows))


def packing_checklist(args: dict) -> dict:
    """Get a trip's packing checklist with packed/unpacked state.

    Optional: mark={item_id|item_name: bool} to toggle packed state.
    """
    try:
        trip_id = int(_require_arg(args, "trip_id"))
    except KeyError:
        return _err("trip_id is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    try:
        c = _conn()
        if c.execute("SELECT 1 FROM trips WHERE id=?", (trip_id,)).fetchone() is None:
            return _err(f"trip {trip_id} not found")
        mark = args.get("mark")
        if isinstance(mark, dict):
            for key, val in mark.items():
                packed = 1 if val else 0
                if str(key).isdigit():
                    c.execute("UPDATE packing_items SET packed=? WHERE id=? AND trip_id=?",
                              (packed, int(key), trip_id))
                else:
                    c.execute("UPDATE packing_items SET packed=? "
                              "WHERE item=? AND trip_id=?",
                              (packed, str(key), trip_id))
            c.commit()
        rows = c.execute("SELECT id, item, category, packed FROM packing_items "
                         "WHERE trip_id=? ORDER BY category, id", (trip_id,)).fetchall()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    items = _rows(rows)
    for it in items:
        it["packed"] = bool(it["packed"])
    packed_n = sum(1 for it in items if it["packed"])
    return _ok(trip_id=trip_id, total=len(items), packed=packed_n,
               remaining=len(items) - packed_n, items=items)


# ──────────────────────────────────────────────────────────────────────────
# COUNTRY / DESTINATION INFO
# ──────────────────────────────────────────────────────────────────────────


def country_info(args: dict) -> dict:
    """Country facts via RestCountries (free, no key): capital, currency, languages, etc."""
    try:
        country = _require_arg(args, "country")
    except KeyError:
        return _err("country is required")
    info = _restcountries(country)
    if not info.get("ok"):
        return _err(info.get("error", f"country not found: {country}"))
    d = info["data"]
    currencies = d.get("currencies") or {}
    cur_code = next(iter(currencies), None)
    idd = d.get("idd") or {}
    calling = ""
    if idd.get("root"):
        suffixes = idd.get("suffixes") or [""]
        calling = idd["root"] + (suffixes[0] if len(suffixes) == 1 else "")
    return _ok(country={
        "name": (d.get("name") or {}).get("common"),
        "official_name": (d.get("name") or {}).get("official"),
        "capital": (d.get("capital") or [None])[0],
        "region": d.get("region"),
        "subregion": d.get("subregion"),
        "population": d.get("population"),
        "currency": cur_code,
        "currency_name": (currencies.get(cur_code) or {}).get("name") if cur_code else None,
        "currency_symbol": (currencies.get(cur_code) or {}).get("symbol") if cur_code else None,
        "languages": list((d.get("languages") or {}).values()),
        "timezones": d.get("timezones"),
        "calling_code": calling,
        "iso2": d.get("cca2"),
        "iso3": d.get("cca3"),
        "flag": (d.get("flags") or {}).get("png"),
    })


def visa_requirements(args: dict) -> dict:
    """Visa requirements between passport country and destination. Free API + guidance."""
    try:
        passport = str(_require_arg(args, "passport_country")).strip()
        destination = str(_require_arg(args, "destination_country")).strip()
    except KeyError as e:
        return _err(f"{e.args[0]} is required")

    # resolve to ISO2 codes for the free passport-index style API
    p_info = _restcountries(passport)
    d_info = _restcountries(destination)
    p_iso = p_info["data"].get("cca2") if p_info.get("ok") else None
    d_iso = d_info["data"].get("cca2") if d_info.get("ok") else None

    if p_iso and d_iso:
        resp = _get(f"https://rough-sun-2niceanddandy.herokuapp.com/api/{p_iso}/{d_iso}")
        if resp.get("ok") and isinstance(resp.get("json"), dict):
            j = resp["json"]
            return _ok(source="passport-index API",
                       passport_country=passport, destination_country=destination,
                       requirement=j.get("data") or j,
                       note="best-effort — always confirm with the destination's "
                            "embassy / official immigration site before travel")
    return _ok(source="guidance",
               passport_country=passport, destination_country=destination,
               requirement="unknown",
               guidance=f"No live visa data available. Check the official "
                        f"immigration / embassy website of {destination} for "
                        f"{passport} passport holders. Many countries offer "
                        f"visa-on-arrival or eVisa; requirements change often.",
               note="this tool never guarantees entry — confirm officially")


_ADVISORY_GRADE = {
    1: "Exercise normal precautions",
    2: "Exercise increased caution",
    3: "Reconsider travel",
    4: "Do not travel",
}


def travel_advisory(args: dict) -> dict:
    """Best-effort travel safety / advisory info for a country."""
    try:
        country = str(_require_arg(args, "country")).strip()
    except KeyError:
        return _err("country is required")
    info = _restcountries(country)
    iso2 = info["data"].get("cca2") if info.get("ok") else None
    if iso2:
        resp = _get(f"https://www.travel-advisory.info/api",
                    params={"countrycode": iso2})
        if resp.get("ok"):
            data = ((resp.get("json") or {}).get("data") or {}).get(iso2)
            if data:
                adv = data.get("advisory") or {}
                score = adv.get("score")
                return _ok(source="travel-advisory.info",
                           country=data.get("name") or country,
                           advisory_score=score,
                           risk_level=("low" if score and score < 2.5 else
                                       "moderate" if score and score < 4 else "high"),
                           message=adv.get("message"),
                           updated=adv.get("updated"),
                           note="aggregated third-party data — for authoritative "
                                "guidance check your government's official travel "
                                "advisory (e.g. US State Dept, UK FCDO)")
    return _ok(source="guidance", country=country, advisory_score=None,
               note=f"No live advisory data for {country}. Check your "
                    f"government's official travel advisory before booking.")


def timezone_for(args: dict) -> dict:
    """Timezone + current local time for a city."""
    try:
        city = str(_require_arg(args, "city")).strip()
    except KeyError:
        return _err("city is required")
    geo = _geocode_city(city)
    if not geo or not geo.get("timezone"):
        return _err(f"could not resolve a timezone for: {city}")
    tzname = geo["timezone"]
    try:
        now = datetime.now(ZoneInfo(tzname))
    except Exception:
        return _err(f"unknown timezone {tzname} for {city}")
    return _ok(city=geo.get("name") or city, country=geo.get("country"),
               timezone=tzname,
               utc_offset=now.strftime("%z"),
               local_time=now.strftime("%Y-%m-%d %H:%M:%S"),
               local_time_iso=now.isoformat())


def currency_for_country(args: dict) -> dict:
    """Currency code for a country + current USD exchange rate (free open.er-api)."""
    try:
        country = _require_arg(args, "country")
    except KeyError:
        return _err("country is required")
    info = _restcountries(country)
    if not info.get("ok"):
        return _err(info.get("error", f"country not found: {country}"))
    currencies = info["data"].get("currencies") or {}
    code = next(iter(currencies), None)
    if not code:
        return _err(f"no currency listed for {country}")
    cur = currencies[code] or {}
    resp = _get("https://open.er-api.com/v6/latest/USD")
    rate = None
    updated = None
    if resp.get("ok"):
        j = resp.get("json") or {}
        rate = (j.get("rates") or {}).get(code)
        updated = j.get("time_last_update_utc")
    return _ok(country=(info["data"].get("name") or {}).get("common"),
               currency_code=code,
               currency_name=cur.get("name"),
               currency_symbol=cur.get("symbol"),
               usd_to_local=rate,
               local_to_usd=round(1 / rate, 6) if rate else None,
               rate_updated=updated,
               example=f"$100 USD = {round(100 * rate, 2)} {code}" if rate else None)


# plug type / voltage by ISO2 country code (compact, common destinations)
_PLUG_TABLE = {
    "US": {"plugs": ["A", "B"], "voltage": "120V", "frequency": "60Hz"},
    "CA": {"plugs": ["A", "B"], "voltage": "120V", "frequency": "60Hz"},
    "MX": {"plugs": ["A", "B"], "voltage": "127V", "frequency": "60Hz"},
    "GB": {"plugs": ["G"], "voltage": "230V", "frequency": "50Hz"},
    "IE": {"plugs": ["G"], "voltage": "230V", "frequency": "50Hz"},
    "FR": {"plugs": ["C", "E"], "voltage": "230V", "frequency": "50Hz"},
    "DE": {"plugs": ["C", "F"], "voltage": "230V", "frequency": "50Hz"},
    "ES": {"plugs": ["C", "F"], "voltage": "230V", "frequency": "50Hz"},
    "IT": {"plugs": ["C", "F", "L"], "voltage": "230V", "frequency": "50Hz"},
    "NL": {"plugs": ["C", "F"], "voltage": "230V", "frequency": "50Hz"},
    "CH": {"plugs": ["C", "J"], "voltage": "230V", "frequency": "50Hz"},
    "JP": {"plugs": ["A", "B"], "voltage": "100V", "frequency": "50/60Hz"},
    "CN": {"plugs": ["A", "C", "I"], "voltage": "220V", "frequency": "50Hz"},
    "AU": {"plugs": ["I"], "voltage": "230V", "frequency": "50Hz"},
    "NZ": {"plugs": ["I"], "voltage": "230V", "frequency": "50Hz"},
    "IN": {"plugs": ["C", "D", "M"], "voltage": "230V", "frequency": "50Hz"},
    "AE": {"plugs": ["C", "D", "G"], "voltage": "230V", "frequency": "50Hz"},
    "SG": {"plugs": ["G"], "voltage": "230V", "frequency": "50Hz"},
    "TH": {"plugs": ["A", "B", "C", "O"], "voltage": "230V", "frequency": "50Hz"},
    "BR": {"plugs": ["C", "N"], "voltage": "127/220V", "frequency": "60Hz"},
    "ZA": {"plugs": ["C", "D", "M", "N"], "voltage": "230V", "frequency": "50Hz"},
    "KR": {"plugs": ["C", "F"], "voltage": "220V", "frequency": "60Hz"},
}


def power_plug_type(args: dict) -> dict:
    """Electrical plug type(s) and voltage for a country (hardcoded lookup)."""
    try:
        country = str(_require_arg(args, "country")).strip()
    except KeyError:
        return _err("country is required")
    info = _restcountries(country)
    iso2 = info["data"].get("cca2") if info.get("ok") else country.upper()[:2]
    entry = _PLUG_TABLE.get(iso2)
    if not entry:
        return _ok(country=country, iso2=iso2, plugs=None,
                   note=f"no plug data on file for {country} — bring a universal "
                        f"travel adapter (covers types A-N) to be safe")
    return _ok(country=(info["data"].get("name") or {}).get("common")
               if info.get("ok") else country,
               iso2=iso2, plug_types=entry["plugs"],
               voltage=entry["voltage"], frequency=entry["frequency"],
               note="if your devices are 120V-only and the country is 230V, you "
                    "need a voltage converter — most modern chargers are 100-240V")


# best time to visit — hardcoded heuristic by country/region
_BEST_TIME = {
    "japan": "Mar-May (cherry blossom) and Oct-Nov (autumn colours); avoid Jun rainy season",
    "thailand": "Nov-Feb — cool & dry; avoid Apr heat and Jun-Oct monsoon",
    "italy": "Apr-Jun and Sep-Oct — mild, fewer crowds; avoid Aug heat & tourists",
    "france": "Apr-Jun and Sep-Oct — pleasant weather, lighter crowds",
    "spain": "Apr-Jun and Sep-Oct — warm but not extreme",
    "united kingdom": "May-Sep for the warmest, driest weather",
    "united states": "Varies hugely by region — spring/fall generally best nationwide",
    "iceland": "Jun-Aug for midnight sun & hiking; Sep-Mar for northern lights",
    "australia": "Sep-Nov and Mar-May; seasons are reversed (Dec-Feb is summer)",
    "new zealand": "Dec-Feb (summer) for outdoors; Jun-Aug for skiing",
    "mexico": "Nov-Apr — dry season; avoid Jun-Oct hurricane season on coasts",
    "india": "Oct-Mar — cool & dry; avoid Apr-Jun heat and Jul-Sep monsoon",
    "greece": "May-Jun and Sep-Oct — warm seas, fewer crowds than Jul-Aug",
    "egypt": "Oct-Apr — comfortable; avoid the extreme summer heat",
    "brazil": "May-Sep (dry season); Feb for Carnival",
    "germany": "May-Sep — warm; Dec for Christmas markets",
    "canada": "Jun-Sep for most regions; Dec-Mar for winter sports",
    "united arab emirates": "Nov-Mar — pleasant; avoid brutal Jun-Sep heat",
}


def best_time_to_visit(args: dict) -> dict:
    """Climate-based best-time-to-visit recommendation (hardcoded heuristic)."""
    try:
        country = str(_require_arg(args, "country")).strip()
    except KeyError:
        return _err("country is required")
    key = country.lower()
    if key in _BEST_TIME:
        return _ok(country=country, recommendation=_BEST_TIME[key],
                   source="curated heuristic")
    # fall back to latitude-based generic guidance
    info = _restcountries(country)
    if info.get("ok"):
        latlng = info["data"].get("latlng") or []
        cname = (info["data"].get("name") or {}).get("common", country)
        if latlng:
            lat = latlng[0]
            if abs(lat) < 23.5:
                rec = ("Tropical climate — pick the dry season (often Nov-Apr in the "
                       "northern tropics, May-Oct in the southern). Avoid monsoon months.")
            elif lat > 23.5:
                rec = "Northern temperate — spring (Apr-Jun) and autumn (Sep-Oct) are usually best."
            else:
                rec = ("Southern hemisphere — seasons reversed; their summer is "
                       "Dec-Feb, their spring/autumn (Sep-Nov / Mar-May) are mild.")
            return _ok(country=cname, recommendation=rec,
                       source="latitude heuristic", latitude=lat)
    return _ok(country=country,
               recommendation="No specific data — spring and autumn are a safe "
                               "default for most temperate destinations.",
               source="generic")


# ──────────────────────────────────────────────────────────────────────────
# TRIP UTILITIES
# ──────────────────────────────────────────────────────────────────────────


def trip_countdown(args: dict) -> dict:
    """Days until a trip starts (and trip length / status)."""
    try:
        trip_id = int(_require_arg(args, "trip_id"))
    except KeyError:
        return _err("trip_id is required")
    except (TypeError, ValueError):
        return _err("trip_id must be an integer")
    try:
        trip = _conn().execute("SELECT * FROM trips WHERE id=?", (trip_id,)).fetchone()
    except sqlite3.Error as e:
        return _err(f"db error: {e}")
    if trip is None:
        return _err(f"trip {trip_id} not found")
    start = _parse_date(trip["start_date"])
    end = _parse_date(trip["end_date"])
    if start is None:
        return _err(f"trip {trip_id} has no valid start_date")
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    days_until = (start - today).days
    out = {
        "trip_id": trip_id,
        "trip_name": trip["name"],
        "start_date": trip["start_date"],
        "end_date": trip["end_date"],
        "days_until_start": days_until,
    }
    if end:
        out["trip_length_days"] = (end - start).days + 1
    if days_until > 0:
        out["status"] = "upcoming"
        out["message"] = f"{days_until} day(s) until {trip['name']}"
    elif days_until == 0:
        out["status"] = "today"
        out["message"] = f"{trip['name']} starts today!"
    elif end and today <= end:
        out["status"] = "in_progress"
        out["message"] = f"{trip['name']} is happening now"
    else:
        out["status"] = "past"
        out["message"] = f"{trip['name']} ended {abs((end or start) - today).days} day(s) ago"
    return _ok(**out)


def distance_estimate(args: dict) -> dict:
    """Great-circle distance + rough flight time between two cities."""
    try:
        origin = str(_require_arg(args, "origin_city")).strip()
        dest = str(_require_arg(args, "dest_city")).strip()
    except KeyError as e:
        return _err(f"{e.args[0]} is required")
    o = _geocode_city(origin)
    d = _geocode_city(dest)
    if not o:
        return _err(f"could not geocode origin city: {origin}")
    if not d:
        return _err(f"could not geocode dest city: {dest}")
    km = _haversine_km(o["lat"], o["lon"], d["lat"], d["lon"])
    miles = km * 0.621371
    # cruising ~800 km/h + ~45 min taxi/climb/descent overhead
    flight_hours = km / 800.0 + 0.75
    h = int(flight_hours)
    m = int(round((flight_hours - h) * 60))
    return _ok(origin=o.get("name") or origin, destination=d.get("name") or dest,
               distance_km=round(km, 1), distance_miles=round(miles, 1),
               est_flight_time_hours=round(flight_hours, 1),
               est_flight_time=f"{h}h {m}m",
               note="great-circle estimate — actual routing & layovers add time")


def jet_lag_plan(args: dict) -> dict:
    """Jet-lag adjustment tips based on hours of timezone difference."""
    try:
        from_tz = str(_require_arg(args, "from_tz")).strip()
        to_tz = str(_require_arg(args, "to_tz")).strip()
    except KeyError as e:
        return _err(f"{e.args[0]} is required")
    try:
        now = datetime.now(timezone.utc)
        off_from = ZoneInfo(from_tz).utcoffset(now)
        off_to = ZoneInfo(to_tz).utcoffset(now)
    except Exception:
        return _err(f"invalid timezone — use IANA names like 'America/Los_Angeles'. "
                    f"got from_tz={from_tz}, to_tz={to_tz}")
    if off_from is None or off_to is None:
        return _err("could not compute timezone offsets")
    diff_hours = (off_to - off_from).total_seconds() / 3600.0
    direction = "east" if diff_hours > 0 else "west" if diff_hours < 0 else "none"
    abs_h = abs(diff_hours)
    # rule of thumb: ~1 day of adjustment per timezone crossed
    recovery_days = max(1, round(abs_h / 1.5)) if abs_h >= 3 else 0

    tips: List[str] = []
    if abs_h < 3:
        tips.append("Time difference is small — minimal jet lag expected.")
    else:
        tips.append(f"Crossing ~{abs_h:.0f} hours {direction}ward — expect "
                    f"~{recovery_days} day(s) to fully adjust.")
        if direction == "east":
            tips += [
                "Eastward travel is harder — shift your sleep EARLIER for a few "
                "days before departure.",
                "Seek bright morning light at the destination; avoid bright light "
                "late evening.",
                "Consider melatonin a few hours before the new local bedtime.",
            ]
        else:
            tips += [
                "Westward travel is easier — shift your sleep LATER before departure.",
                "Seek evening light at the destination to stay up; get morning "
                "light only after you've adjusted.",
                "Avoid napping too long on arrival day; push through to local bedtime.",
            ]
        tips += [
            "Set your watch/phone to destination time as soon as you board.",
            "Stay hydrated; limit alcohol and caffeine on the flight.",
            "Adopt the destination's meal schedule immediately on arrival.",
        ]
    return _ok(from_tz=from_tz, to_tz=to_tz,
               hours_difference=round(diff_hours, 1),
               direction=direction,
               estimated_recovery_days=recovery_days,
               tips=tips)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Any] = {
    # flights
    "travel.flight_search": flight_search,
    "travel.flight_cheapest_dates": flight_cheapest_dates,
    "travel.flight_status": flight_status,
    "travel.airport_info": airport_info,
    # hotels
    "travel.hotel_search": hotel_search,
    "travel.hotel_details": hotel_details,
    # itinerary (local SQLite)
    "travel.trip_create": trip_create,
    "travel.trip_list": trip_list,
    "travel.trip_get": trip_get,
    "travel.trip_add_item": trip_add_item,
    "travel.trip_items": trip_items,
    "travel.trip_budget_status": trip_budget_status,
    "travel.trip_delete": trip_delete,
    # packing
    "travel.packing_list_generate": packing_list_generate,
    "travel.packing_list_save": packing_list_save,
    "travel.packing_checklist": packing_checklist,
    # country / destination info
    "travel.country_info": country_info,
    "travel.visa_requirements": visa_requirements,
    "travel.travel_advisory": travel_advisory,
    "travel.timezone_for": timezone_for,
    "travel.currency_for_country": currency_for_country,
    "travel.power_plug_type": power_plug_type,
    "travel.best_time_to_visit": best_time_to_visit,
    # trip utilities
    "travel.trip_countdown": trip_countdown,
    "travel.distance_estimate": distance_estimate,
    "travel.jet_lag_plan": jet_lag_plan,
}
