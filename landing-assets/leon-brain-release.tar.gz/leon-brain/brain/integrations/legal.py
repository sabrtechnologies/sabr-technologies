"""Legal & e-signature integration for Leon.

Covers e-signature platforms (DocuSign, Dropbox Sign / HelloSign, PandaDoc),
local contract-template generation (NDA, consulting / service agreements,
privacy policy, ToS, cease-and-desist, demand letter), a curated legal
reference library (entity types, filing calendars, clause library, term
glossary, trademark tips) and a local SQLite contract tracker.

`EXTRA_TOOLS` at the bottom maps dotted tool names (e.g. ``legal.nda``)
to callables. Every callable takes a single ``args`` dict and returns
``{"ok": bool, ...}`` — they never raise.

Credentials are read lazily from the environment:
  - DocuSign:     DOCUSIGN_ACCESS_TOKEN, DOCUSIGN_ACCOUNT_ID, DOCUSIGN_BASE_URI
  - Dropbox Sign: DROPBOXSIGN_API_KEY
  - PandaDoc:     PANDADOC_API_KEY

Nothing here is legal advice. Reference tools always carry a disclaimer.
"""

from __future__ import annotations

import base64
import os
import sqlite3
import threading
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

try:
    import requests
except Exception:  # pragma: no cover - requests should be present
    requests = None  # type: ignore

_TIMEOUT = 15
_DISCLAIMER = "Not legal advice — consult an attorney."

# Document output directory — auto-created on import.
_LEGAL_DIR = Path.home() / "Documents" / "leon-legal"
try:
    _LEGAL_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass


# ──────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _ok(**kw: Any) -> Dict[str, Any]:
    d: Dict[str, Any] = {"ok": True}
    d.update(kw)
    return d


def _err(msg: str, **kw: Any) -> Dict[str, Any]:
    d: Dict[str, Any] = {"ok": False, "error": msg}
    d.update(kw)
    return d


def _need_requests() -> Optional[Dict[str, Any]]:
    if requests is None:
        return _err("requests library not available")
    return None


def _project_root() -> str:
    # brain/integrations/legal.py -> project root is two dirs up.
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ── credentials (lazy) ────────────────────────────────────────────────────


def _docusign_creds() -> Optional[Dict[str, str]]:
    tok = os.environ.get("DOCUSIGN_ACCESS_TOKEN")
    acct = os.environ.get("DOCUSIGN_ACCOUNT_ID")
    base = os.environ.get("DOCUSIGN_BASE_URI")
    if not (tok and acct and base):
        return None
    return {"token": tok, "account_id": acct, "base_uri": base.rstrip("/")}


def _dropboxsign_key() -> Optional[str]:
    return os.environ.get("DROPBOXSIGN_API_KEY")


def _pandadoc_key() -> Optional[str]:
    return os.environ.get("PANDADOC_API_KEY")


# ── HTTP wrapper ──────────────────────────────────────────────────────────


def _request(method: str, url: str, **kw: Any) -> Dict[str, Any]:
    """Perform an HTTP request, return {"ok", "status", "data"/"text"}."""
    miss = _need_requests()
    if miss:
        return miss
    kw.setdefault("timeout", _TIMEOUT)
    try:
        resp = requests.request(method, url, **kw)
    except requests.exceptions.Timeout:
        return _err(f"request timed out after {_TIMEOUT}s")
    except Exception as e:  # network / DNS / SSL
        return _err(f"request failed: {e}")
    try:
        data = resp.json()
        payload = {"data": data}
    except Exception:
        payload = {"text": resp.text}
    if resp.status_code >= 400:
        return _err(
            f"HTTP {resp.status_code}",
            status=resp.status_code,
            **payload,
        )
    return _ok(status=resp.status_code, **payload)


def _read_doc(path: str) -> Optional[bytes]:
    try:
        p = Path(path).expanduser()
        if not p.is_file():
            return None
        return p.read_bytes()
    except Exception:
        return None


def _slug(text: str) -> str:
    keep = "".join(c if c.isalnum() or c in " -_" else "" for c in str(text))
    return "_".join(keep.lower().split())[:60] or "document"


def _today() -> str:
    return date.today().isoformat()


# ── markdown -> file output ───────────────────────────────────────────────


def _save_document(title: str, markdown: str, save_pdf: bool) -> Dict[str, Any]:
    """Render markdown to PDF via the docgen module, or return raw markdown.

    Returns a dict fragment merged into the tool result.
    """
    if not save_pdf:
        return {"format": "markdown", "markdown": markdown}

    fname = f"{_slug(title)}_{int(time.time())}"
    # Try the existing docgen pipeline first.
    try:
        from brain.integrations import docgen  # type: ignore

        fn = docgen.EXTRA_TOOLS.get("docgen.markdown_to_pdf")
        if fn is not None:
            res = fn({
                "markdown": markdown,
                "title": title,
                "save_to": str(_LEGAL_DIR / f"{fname}.pdf"),
            })
            if isinstance(res, dict) and res.get("ok"):
                path = res.get("path") or res.get("file") or str(
                    _LEGAL_DIR / f"{fname}.pdf"
                )
                return {"format": "pdf", "path": path, "markdown": markdown}
    except Exception:
        pass

    # Fallback: write the markdown to disk so nothing is lost.
    try:
        out = _LEGAL_DIR / f"{fname}.md"
        out.write_text(markdown, encoding="utf-8")
        return {
            "format": "markdown_file",
            "path": str(out),
            "markdown": markdown,
            "note": "docgen PDF unavailable — saved as markdown",
        }
    except Exception as e:
        return {"format": "markdown", "markdown": markdown,
                "note": f"could not save file: {e}"}


# ── SQLite tracker ────────────────────────────────────────────────────────

_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT,
    status TEXT DEFAULT 'draft',
    counterparty TEXT,
    value REAL,
    expiry_date TEXT,
    created_at REAL DEFAULT (strftime('%s','now'))
);
"""


def _db_path() -> str:
    brain_state = os.path.join(_project_root(), "brain_state")
    try:
        os.makedirs(brain_state, exist_ok=True)
    except Exception:
        pass
    return os.path.join(brain_state, "legal_docs.db")


def _conn() -> sqlite3.Connection:
    """Lazy SQLite connection. Creates schema on first call."""
    global _DB_CONN
    if _DB_CONN is not None:
        return _DB_CONN
    with _DB_LOCK:
        if _DB_CONN is not None:
            return _DB_CONN
        conn = sqlite3.connect(_db_path(), timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
        _DB_CONN = conn
    return _DB_CONN


def _row(r: Optional[sqlite3.Row]) -> Optional[Dict[str, Any]]:
    if r is None:
        return None
    return {k: r[k] for k in r.keys()}


def _rows(rs: Any) -> List[Dict[str, Any]]:
    return [d for d in (_row(r) for r in rs) if d is not None]


# ══════════════════════════════════════════════════════════════════════════
# DOCUSIGN
# ══════════════════════════════════════════════════════════════════════════


def _docusign_headers(creds: Dict[str, str]) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {creds['token']}",
        "Content-Type": "application/json",
    }


def _docusign_url(creds: Dict[str, str], path: str) -> str:
    return (
        f"{creds['base_uri']}/restapi/v2.1/accounts/"
        f"{creds['account_id']}/{path.lstrip('/')}"
    )


def docusign_envelopes(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent DocuSign envelopes filtered by status."""
    creds = _docusign_creds()
    if not creds:
        return _err("DocuSign not configured — set DOCUSIGN_ACCESS_TOKEN, "
                    "DOCUSIGN_ACCOUNT_ID, DOCUSIGN_BASE_URI")
    status = args.get("status", "sent")
    limit = int(args.get("limit", 20))
    # DocuSign requires from_date for envelope listing; use 1 year back.
    from_date = (date.today() - timedelta(days=365)).isoformat()
    res = _request(
        "GET",
        _docusign_url(creds, "envelopes"),
        headers=_docusign_headers(creds),
        params={"from_date": from_date, "status": status, "count": limit},
    )
    if not res["ok"]:
        return res
    data = res.get("data", {})
    envs = (data.get("envelopes") or [])[:limit]
    return _ok(
        envelopes=[
            {
                "envelope_id": e.get("envelopeId"),
                "status": e.get("status"),
                "subject": e.get("emailSubject"),
                "created": e.get("createdDateTime"),
                "sent": e.get("sentDateTime"),
            }
            for e in envs
        ],
        count=len(envs),
        status_filter=status,
    )


def docusign_envelope_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Get the status of a single DocuSign envelope."""
    creds = _docusign_creds()
    if not creds:
        return _err("DocuSign not configured")
    env_id = args.get("envelope_id")
    if not env_id:
        return _err("envelope_id required")
    res = _request(
        "GET",
        _docusign_url(creds, f"envelopes/{env_id}"),
        headers=_docusign_headers(creds),
    )
    if not res["ok"]:
        return res
    d = res.get("data", {})
    return _ok(
        envelope_id=d.get("envelopeId"),
        status=d.get("status"),
        subject=d.get("emailSubject"),
        created=d.get("createdDateTime"),
        sent=d.get("sentDateTime"),
        completed=d.get("completedDateTime"),
        voided_reason=d.get("voidedReason"),
    )


def docusign_send(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send a document for signature via DocuSign (HIGH risk — sends a real
    legally-binding request to a signer)."""
    creds = _docusign_creds()
    if not creds:
        return _err("DocuSign not configured")
    doc_path = args.get("document_path")
    signer_email = args.get("signer_email")
    signer_name = args.get("signer_name")
    if not (doc_path and signer_email and signer_name):
        return _err("document_path, signer_email, signer_name required")
    raw = _read_doc(doc_path)
    if raw is None:
        return _err(f"could not read document: {doc_path}")
    p = Path(doc_path).expanduser()
    ext = (p.suffix.lstrip(".") or "pdf").lower()
    subject = args.get("subject") or f"Please sign: {p.stem}"
    envelope = {
        "emailSubject": subject,
        "status": "sent",
        "documents": [{
            "documentBase64": base64.b64encode(raw).decode("ascii"),
            "name": p.name,
            "fileExtension": ext,
            "documentId": "1",
        }],
        "recipients": {
            "signers": [{
                "email": signer_email,
                "name": signer_name,
                "recipientId": "1",
                "routingOrder": "1",
                "tabs": {
                    "signHereTabs": [{
                        "anchorString": "/sig/",
                        "anchorUnits": "pixels",
                        "anchorXOffset": "0",
                        "anchorYOffset": "0",
                    }]
                },
            }]
        },
    }
    res = _request(
        "POST",
        _docusign_url(creds, "envelopes"),
        headers=_docusign_headers(creds),
        json=envelope,
    )
    if not res["ok"]:
        return res
    d = res.get("data", {})
    return _ok(
        envelope_id=d.get("envelopeId"),
        status=d.get("status"),
        signer=signer_email,
        subject=subject,
        message=f"Envelope sent to {signer_name} <{signer_email}>",
    )


def docusign_void(args: Dict[str, Any]) -> Dict[str, Any]:
    """Void an in-progress DocuSign envelope (MEDIUM risk)."""
    creds = _docusign_creds()
    if not creds:
        return _err("DocuSign not configured")
    env_id = args.get("envelope_id")
    reason = args.get("reason")
    if not env_id:
        return _err("envelope_id required")
    if not reason:
        return _err("reason required (DocuSign mandates a void reason)")
    res = _request(
        "PUT",
        _docusign_url(creds, f"envelopes/{env_id}"),
        headers=_docusign_headers(creds),
        json={"status": "voided", "voidedReason": reason},
    )
    if not res["ok"]:
        return res
    return _ok(envelope_id=env_id, status="voided", reason=reason,
               message="Envelope voided")


# ══════════════════════════════════════════════════════════════════════════
# DROPBOX SIGN / HELLOSIGN
# ══════════════════════════════════════════════════════════════════════════

_DROPBOXSIGN_BASE = "https://api.hellosign.com/v3"


def _dropboxsign_auth(key: str) -> Any:
    # Dropbox Sign uses HTTP basic auth: API key as username, blank password.
    return (key, "")


def dropboxsign_send(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send a document for signature via Dropbox Sign / HelloSign (HIGH risk)."""
    key = _dropboxsign_key()
    if not key:
        return _err("Dropbox Sign not configured — set DROPBOXSIGN_API_KEY")
    doc_path = args.get("document_path")
    signer_email = args.get("signer_email")
    signer_name = args.get("signer_name")
    if not (doc_path and signer_email and signer_name):
        return _err("document_path, signer_email, signer_name required")
    p = Path(doc_path).expanduser()
    if not p.is_file():
        return _err(f"could not read document: {doc_path}")
    title = args.get("title") or p.stem
    miss = _need_requests()
    if miss:
        return miss
    try:
        with open(p, "rb") as fh:
            files = {"file[0]": (p.name, fh)}
            data = {
                "title": title,
                "subject": f"Signature requested: {title}",
                "signers[0][email_address]": signer_email,
                "signers[0][name]": signer_name,
                "test_mode": "0",
            }
            resp = requests.post(
                f"{_DROPBOXSIGN_BASE}/signature_request/send",
                auth=_dropboxsign_auth(key),
                data=data,
                files=files,
                timeout=_TIMEOUT,
            )
    except requests.exceptions.Timeout:
        return _err(f"request timed out after {_TIMEOUT}s")
    except Exception as e:
        return _err(f"request failed: {e}")
    try:
        body = resp.json()
    except Exception:
        body = {}
    if resp.status_code >= 400:
        return _err(f"HTTP {resp.status_code}", status=resp.status_code,
                    data=body)
    sr = body.get("signature_request", {})
    return _ok(
        signature_request_id=sr.get("signature_request_id"),
        title=sr.get("title"),
        signer=signer_email,
        is_complete=sr.get("is_complete"),
        message=f"Signature request sent to {signer_name} <{signer_email}>",
    )


def dropboxsign_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent Dropbox Sign signature requests."""
    key = _dropboxsign_key()
    if not key:
        return _err("Dropbox Sign not configured — set DROPBOXSIGN_API_KEY")
    limit = int(args.get("limit", 20))
    res = _request(
        "GET",
        f"{_DROPBOXSIGN_BASE}/signature_request/list",
        auth=_dropboxsign_auth(key),
        params={"page_size": min(limit, 100)},
    )
    if not res["ok"]:
        return res
    reqs = (res.get("data", {}).get("signature_requests") or [])[:limit]
    return _ok(
        signature_requests=[
            {
                "signature_request_id": r.get("signature_request_id"),
                "title": r.get("title"),
                "is_complete": r.get("is_complete"),
                "created_at": r.get("created_at"),
                "signers": [s.get("email_address")
                            for s in (r.get("signatures") or [])],
            }
            for r in reqs
        ],
        count=len(reqs),
    )


def dropboxsign_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Get the status of a single Dropbox Sign signature request."""
    key = _dropboxsign_key()
    if not key:
        return _err("Dropbox Sign not configured — set DROPBOXSIGN_API_KEY")
    sr_id = args.get("signature_request_id")
    if not sr_id:
        return _err("signature_request_id required")
    res = _request(
        "GET",
        f"{_DROPBOXSIGN_BASE}/signature_request/{sr_id}",
        auth=_dropboxsign_auth(key),
    )
    if not res["ok"]:
        return res
    r = res.get("data", {}).get("signature_request", {})
    return _ok(
        signature_request_id=r.get("signature_request_id"),
        title=r.get("title"),
        is_complete=r.get("is_complete"),
        is_declined=r.get("is_declined"),
        created_at=r.get("created_at"),
        signers=[
            {
                "email": s.get("email_address"),
                "name": s.get("signer_name"),
                "status": s.get("status_code"),
                "signed_at": s.get("signed_at"),
            }
            for s in (r.get("signatures") or [])
        ],
    )


# ══════════════════════════════════════════════════════════════════════════
# PANDADOC
# ══════════════════════════════════════════════════════════════════════════

_PANDADOC_BASE = "https://api.pandadoc.com/public/v1"


def _pandadoc_headers(key: str) -> Dict[str, str]:
    return {
        "Authorization": f"API-Key {key}",
        "Content-Type": "application/json",
    }


def pandadoc_documents(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent PandaDoc documents."""
    key = _pandadoc_key()
    if not key:
        return _err("PandaDoc not configured — set PANDADOC_API_KEY")
    limit = int(args.get("limit", 20))
    res = _request(
        "GET",
        f"{_PANDADOC_BASE}/documents",
        headers=_pandadoc_headers(key),
        params={"count": min(limit, 100)},
    )
    if not res["ok"]:
        return res
    docs = (res.get("data", {}).get("results") or [])[:limit]
    return _ok(
        documents=[
            {
                "id": d.get("id"),
                "name": d.get("name"),
                "status": d.get("status"),
                "date_created": d.get("date_created"),
                "date_modified": d.get("date_modified"),
            }
            for d in docs
        ],
        count=len(docs),
    )


def pandadoc_document_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Get the status / details of a single PandaDoc document."""
    key = _pandadoc_key()
    if not key:
        return _err("PandaDoc not configured — set PANDADOC_API_KEY")
    doc_id = args.get("document_id")
    if not doc_id:
        return _err("document_id required")
    res = _request(
        "GET",
        f"{_PANDADOC_BASE}/documents/{doc_id}/details",
        headers=_pandadoc_headers(key),
    )
    if not res["ok"]:
        return res
    d = res.get("data", {})
    return _ok(
        id=d.get("id"),
        name=d.get("name"),
        status=d.get("status"),
        date_created=d.get("date_created"),
        date_completed=d.get("date_completed"),
        recipients=[
            {
                "email": r.get("email"),
                "first_name": r.get("first_name"),
                "last_name": r.get("last_name"),
                "has_completed": r.get("has_completed"),
            }
            for r in (d.get("recipients") or [])
        ],
    )


def pandadoc_create_from_template(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a PandaDoc document from a template (MEDIUM risk)."""
    key = _pandadoc_key()
    if not key:
        return _err("PandaDoc not configured — set PANDADOC_API_KEY")
    template_id = args.get("template_id")
    recipient_email = args.get("recipient_email")
    recipient_name = args.get("recipient_name")
    if not (template_id and recipient_email and recipient_name):
        return _err("template_id, recipient_email, recipient_name required")
    parts = str(recipient_name).split(None, 1)
    first = parts[0]
    last = parts[1] if len(parts) > 1 else ""
    payload = {
        "name": f"{recipient_name} — {_today()}",
        "template_uuid": template_id,
        "recipients": [{
            "email": recipient_email,
            "first_name": first,
            "last_name": last,
            "role": "Client",
        }],
    }
    res = _request(
        "POST",
        f"{_PANDADOC_BASE}/documents",
        headers=_pandadoc_headers(key),
        json=payload,
    )
    if not res["ok"]:
        return res
    d = res.get("data", {})
    return _ok(
        id=d.get("id"),
        name=d.get("name"),
        status=d.get("status"),
        message=f"Document created from template for {recipient_email}",
    )


# ══════════════════════════════════════════════════════════════════════════
# CONTRACT TEMPLATES (local — no creds)
# ══════════════════════════════════════════════════════════════════════════

_TEMPLATE_TYPES = {
    "nda": "Mutual non-disclosure agreement",
    "consulting_agreement": "Independent consulting agreement",
    "service_agreement": "Service / master services agreement",
    "invoice_terms": "Standard invoice payment terms",
    "privacy_policy": "Website privacy policy",
    "terms_of_service": "Website terms of service",
    "cease_and_desist": "Cease-and-desist letter",
    "demand_letter": "Payment demand letter",
}

_TEMPLATE_FOOTER = (
    "\n# Disclaimer\n"
    "This document was auto-generated as a starting draft. It is not "
    "legal advice and has not been reviewed by an attorney. Have a "
    "qualified lawyer review and adapt it before use.\n"
)


def template_nda(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a mutual non-disclosure agreement."""
    a = args.get("party_a")
    b = args.get("party_b")
    if not (a and b):
        return _err("party_a and party_b required")
    eff = args.get("effective_date") or _today()
    save_pdf = bool(args.get("save_pdf", True))
    md = f"""# Mutual Non-Disclosure Agreement

This Mutual Non-Disclosure Agreement (the "Agreement") is entered into as of {eff} by and between {a} ("Party A") and {b} ("Party B"), each a "Party" and collectively the "Parties".

# 1. Purpose
The Parties wish to explore a potential business relationship and, in connection therewith, may disclose to each other certain confidential and proprietary information.

# 2. Definition of Confidential Information
"Confidential Information" means any non-public information disclosed by one Party (the "Discloser") to the other (the "Recipient"), whether oral, written, or electronic, including business plans, financials, customer lists, trade secrets, and technical data. It excludes information that is public, already known to the Recipient, independently developed, or rightfully received from a third party.

# 3. Obligations
The Recipient shall: (a) use the Confidential Information solely to evaluate the potential relationship; (b) protect it with at least the same care it uses for its own confidential information, and no less than reasonable care; and (c) not disclose it to third parties without the Discloser's prior written consent.

# 4. Term
This Agreement remains in effect for two (2) years from the Effective Date. Confidentiality obligations survive for three (3) years after disclosure.

# 5. Return of Materials
Upon written request, the Recipient shall return or destroy all Confidential Information and copies thereof.

# 6. No License
Nothing in this Agreement grants any license or ownership rights in the Confidential Information.

# 7. Governing Law
This Agreement is governed by the laws of the State of Delaware, without regard to its conflict-of-laws principles.

# 8. Signatures

Party A: {a}

Signature: /sig/    Date: ____________

Party B: {b}

Signature: /sig/    Date: ____________
{_TEMPLATE_FOOTER}"""
    out = _save_document(f"NDA {a} {b}", md, save_pdf)
    return _ok(template="nda", party_a=a, party_b=b, effective_date=eff,
               disclaimer=_DISCLAIMER, **out)


def template_consulting_agreement(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate an independent consulting agreement."""
    client = args.get("client")
    contractor = args.get("contractor")
    rate = args.get("rate")
    scope = args.get("scope")
    if not (client and contractor and rate and scope):
        return _err("client, contractor, rate, scope required")
    save_pdf = bool(args.get("save_pdf", True))
    eff = _today()
    md = f"""# Consulting Agreement

This Consulting Agreement (the "Agreement") is made as of {eff} between {client} ("Client") and {contractor} ("Consultant").

# 1. Services
The Consultant shall perform the following services (the "Services"): {scope}

# 2. Compensation
The Client shall pay the Consultant at a rate of {rate}. Invoices are due within thirty (30) days of receipt. Reasonable pre-approved expenses are reimbursable.

# 3. Independent Contractor
The Consultant is an independent contractor, not an employee, partner, or agent of the Client. The Consultant is responsible for all taxes on amounts received and is not entitled to employee benefits.

# 4. Intellectual Property
All work product created by the Consultant specifically for the Client under this Agreement is a "work made for hire" and is assigned to the Client upon full payment. The Consultant retains rights in its pre-existing tools and methodologies.

# 5. Confidentiality
The Consultant shall keep confidential all non-public Client information and use it only to perform the Services.

# 6. Term and Termination
This Agreement begins on the Effective Date and continues until the Services are complete. Either Party may terminate on fourteen (14) days' written notice. The Client shall pay for Services rendered through the termination date.

# 7. Limitation of Liability
Neither Party is liable for indirect or consequential damages. The Consultant's total liability is limited to the fees paid under this Agreement.

# 8. Governing Law
This Agreement is governed by the laws of the State of Delaware.

# 9. Signatures

Client: {client}

Signature: /sig/    Date: ____________

Consultant: {contractor}

Signature: /sig/    Date: ____________
{_TEMPLATE_FOOTER}"""
    out = _save_document(f"Consulting Agreement {client} {contractor}",
                         md, save_pdf)
    return _ok(template="consulting_agreement", client=client,
               contractor=contractor, rate=rate, scope=scope,
               disclaimer=_DISCLAIMER, **out)


def template_service_agreement(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a service / master services agreement."""
    provider = args.get("provider")
    client = args.get("client")
    services = args.get("services")
    fee = args.get("fee")
    if not (provider and client and services and fee):
        return _err("provider, client, services, fee required")
    save_pdf = bool(args.get("save_pdf", True))
    eff = _today()
    md = f"""# Service Agreement

This Service Agreement (the "Agreement") is entered into as of {eff} between {provider} ("Provider") and {client} ("Client").

# 1. Scope of Services
The Provider shall provide the following services (the "Services"): {services}

# 2. Fees and Payment
The Client shall pay the Provider {fee} for the Services. Payment terms are net thirty (30) days from the invoice date. Late payments accrue interest at 1.5% per month or the maximum rate permitted by law, whichever is lower.

# 3. Performance Standards
The Provider shall perform the Services in a professional and workmanlike manner consistent with industry standards.

# 4. Warranties
The Provider warrants it has the authority and capability to provide the Services. EXCEPT AS EXPRESSLY STATED, THE SERVICES ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.

# 5. Intellectual Property
Deliverables created for the Client are assigned to the Client upon full payment, excluding the Provider's pre-existing materials and tools.

# 6. Confidentiality
Each Party shall protect the other's confidential information and use it only as needed to perform under this Agreement.

# 7. Term and Termination
This Agreement begins on the Effective Date and continues until terminated. Either Party may terminate for convenience on thirty (30) days' written notice, or immediately for uncured material breach after a fifteen (15) day cure period.

# 8. Limitation of Liability
NEITHER PARTY IS LIABLE FOR INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES. THE PROVIDER'S AGGREGATE LIABILITY IS LIMITED TO THE FEES PAID IN THE TWELVE (12) MONTHS PRECEDING THE CLAIM.

# 9. Indemnification
Each Party shall indemnify the other against third-party claims arising from its own negligence or breach of this Agreement.

# 10. Governing Law
This Agreement is governed by the laws of the State of Delaware.

# 11. Signatures

Provider: {provider}

Signature: /sig/    Date: ____________

Client: {client}

Signature: /sig/    Date: ____________
{_TEMPLATE_FOOTER}"""
    out = _save_document(f"Service Agreement {provider} {client}",
                         md, save_pdf)
    return _ok(template="service_agreement", provider=provider,
               client=client, services=services, fee=fee,
               disclaimer=_DISCLAIMER, **out)


def template_invoice_terms(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate standard invoice payment terms text."""
    company = args.get("company")
    if not company:
        return _err("company required")
    days = int(args.get("terms_days", 30))
    md = f"""# Invoice Payment Terms — {company}

# Payment Due
All invoices issued by {company} are due and payable within {days} days of the invoice date ("Net {days}").

# Accepted Payment Methods
Payment may be made by bank transfer, ACH, credit card, or other methods agreed in writing.

# Late Payment
Invoices not paid within {days} days accrue a late fee of 1.5% per month (or the maximum rate permitted by law, whichever is lower) on the outstanding balance. {company} reserves the right to suspend services on accounts more than fifteen (15) days overdue.

# Disputes
Any disputed invoice item must be raised in writing within ten (10) days of the invoice date. Undisputed amounts remain due on the original schedule.

# Taxes
Stated amounts exclude applicable sales, use, or value-added taxes, which are the responsibility of the client.
{_TEMPLATE_FOOTER}"""
    # Invoice terms are short; always return markdown (no save_pdf arg in spec).
    return _ok(template="invoice_terms", company=company, terms_days=days,
               format="markdown", markdown=md, disclaimer=_DISCLAIMER)


def template_privacy_policy(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a website privacy policy."""
    company = args.get("company")
    website = args.get("website")
    if not (company and website):
        return _err("company and website required")
    save_pdf = bool(args.get("save_pdf", True))
    eff = _today()
    md = f"""# Privacy Policy

Effective date: {eff}

This Privacy Policy describes how {company} ("we", "us") collects, uses, and protects information in connection with {website} (the "Site").

# 1. Information We Collect
We collect: (a) information you provide directly, such as your name, email, and account details; (b) usage data automatically collected via cookies and analytics, such as IP address, browser type, and pages visited; and (c) information from third-party services you connect to the Site.

# 2. How We Use Information
We use information to operate and improve the Site, provide and personalize services, communicate with you, process transactions, ensure security, and comply with legal obligations.

# 3. Sharing of Information
We do not sell personal information. We share information with service providers acting on our behalf, when required by law, and in connection with a merger or acquisition. Service providers are bound by confidentiality obligations.

# 4. Cookies
The Site uses cookies and similar technologies. You can control cookies through your browser settings; disabling them may affect Site functionality.

# 5. Data Retention
We retain personal information only as long as necessary for the purposes described or as required by law.

# 6. Your Rights
Depending on your location, you may have rights to access, correct, delete, or restrict the use of your personal information, and to object to certain processing. To exercise these rights, contact us using the details below.

# 7. Security
We use reasonable administrative, technical, and physical safeguards to protect personal information. No method of transmission or storage is fully secure.

# 8. Children
The Site is not directed to children under 13, and we do not knowingly collect their personal information.

# 9. Changes
We may update this Policy from time to time. Material changes will be posted on the Site with a revised effective date.

# 10. Contact
Questions about this Policy may be directed to {company} via {website}.
{_TEMPLATE_FOOTER}"""
    out = _save_document(f"Privacy Policy {company}", md, save_pdf)
    return _ok(template="privacy_policy", company=company, website=website,
               disclaimer=_DISCLAIMER, **out)


def template_terms_of_service(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate website terms of service."""
    company = args.get("company")
    website = args.get("website")
    if not (company and website):
        return _err("company and website required")
    save_pdf = bool(args.get("save_pdf", True))
    eff = _today()
    md = f"""# Terms of Service

Effective date: {eff}

These Terms of Service (the "Terms") govern your use of {website} (the "Site"), operated by {company} ("we", "us"). By accessing or using the Site, you agree to these Terms.

# 1. Use of the Site
You agree to use the Site only for lawful purposes and not to violate any law, infringe others' rights, or interfere with the Site's operation or security.

# 2. Accounts
If you create an account, you are responsible for maintaining the confidentiality of your credentials and for all activity under your account. Provide accurate and current information.

# 3. Intellectual Property
All content on the Site, including text, graphics, logos, and software, is owned by {company} or its licensors and is protected by intellectual property laws. You may not copy, modify, or distribute it without permission.

# 4. User Content
You retain ownership of content you submit but grant {company} a non-exclusive, worldwide, royalty-free license to use it as needed to operate the Site. You are responsible for your content and warrant that you have the rights to it.

# 5. Disclaimers
THE SITE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED. WE DO NOT WARRANT THAT THE SITE WILL BE UNINTERRUPTED OR ERROR-FREE.

# 6. Limitation of Liability
TO THE MAXIMUM EXTENT PERMITTED BY LAW, {company} IS NOT LIABLE FOR INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING FROM YOUR USE OF THE SITE.

# 7. Indemnification
You agree to indemnify and hold {company} harmless from claims arising out of your use of the Site or violation of these Terms.

# 8. Termination
We may suspend or terminate your access to the Site at any time, with or without notice, for any reason.

# 9. Changes to the Terms
We may revise these Terms at any time. Continued use of the Site after changes constitutes acceptance of the revised Terms.

# 10. Governing Law
These Terms are governed by the laws of the State of Delaware, without regard to conflict-of-laws principles.

# 11. Contact
Questions about these Terms may be directed to {company} via {website}.
{_TEMPLATE_FOOTER}"""
    out = _save_document(f"Terms of Service {company}", md, save_pdf)
    return _ok(template="terms_of_service", company=company, website=website,
               disclaimer=_DISCLAIMER, **out)


def template_cease_and_desist(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a cease-and-desist letter."""
    sender = args.get("sender")
    recipient = args.get("recipient")
    complaint = args.get("complaint")
    if not (sender and recipient and complaint):
        return _err("sender, recipient, complaint required")
    save_pdf = bool(args.get("save_pdf", True))
    eff = _today()
    md = f"""# Cease and Desist Letter

Date: {eff}

To: {recipient}

From: {sender}

# Re: Demand to Cease and Desist

Dear {recipient},

This letter serves as formal notice and demand that you immediately CEASE AND DESIST from the following conduct:

{complaint}

The above conduct is unlawful and is causing harm to {sender}. This letter constitutes a formal demand that you:

# Demands
- Immediately and permanently stop the conduct described above.
- Refrain from any similar conduct in the future.
- Confirm in writing within ten (10) days of the date of this letter that you have complied with these demands.

# Consequences of Non-Compliance
If you fail to comply, {sender} is prepared to pursue all available legal remedies, which may include injunctive relief and a claim for monetary damages, costs, and attorneys' fees. {sender} reserves all rights and remedies, and nothing in this letter waives any of them.

This letter is sent without prejudice to {sender}'s rights, all of which are expressly reserved.

Sincerely,

{sender}

Signature: /sig/    Date: ____________
{_TEMPLATE_FOOTER}"""
    out = _save_document(f"Cease and Desist {recipient}", md, save_pdf)
    return _ok(template="cease_and_desist", sender=sender,
               recipient=recipient, complaint=complaint,
               disclaimer=_DISCLAIMER, **out)


def template_demand_letter(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a payment demand letter."""
    sender = args.get("sender")
    recipient = args.get("recipient")
    amount = args.get("amount")
    reason = args.get("reason")
    if not (sender and recipient and amount and reason):
        return _err("sender, recipient, amount, reason required")
    save_pdf = bool(args.get("save_pdf", True))
    eff = _today()
    deadline = (date.today() + timedelta(days=14)).isoformat()
    md = f"""# Demand for Payment

Date: {eff}

To: {recipient}

From: {sender}

# Re: Demand for Payment of {amount}

Dear {recipient},

This letter is a formal demand for payment of {amount} owed to {sender}.

# Basis of the Debt
The amount is owed for the following reason: {reason}

Despite prior communications, this amount remains unpaid.

# Demand
{sender} demands payment in full of {amount} no later than {deadline} (fourteen days from the date of this letter). Payment should be made by an agreed method and confirmed in writing.

# Consequences of Non-Payment
If payment is not received by the deadline above, {sender} reserves the right to pursue all available legal remedies, including filing a lawsuit to recover the amount owed, plus interest, court costs, and attorneys' fees where permitted by law.

This letter is an attempt to resolve this matter without litigation. {sender} reserves all rights and remedies.

Sincerely,

{sender}

Signature: /sig/    Date: ____________
{_TEMPLATE_FOOTER}"""
    out = _save_document(f"Demand Letter {recipient}", md, save_pdf)
    return _ok(template="demand_letter", sender=sender, recipient=recipient,
               amount=amount, reason=reason, payment_deadline=deadline,
               disclaimer=_DISCLAIMER, **out)


def list_templates(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all available contract / legal-document template types."""
    return _ok(
        templates=[{"type": k, "description": v}
                   for k, v in _TEMPLATE_TYPES.items()],
        count=len(_TEMPLATE_TYPES),
        output_dir=str(_LEGAL_DIR),
        disclaimer=_DISCLAIMER,
    )


# ══════════════════════════════════════════════════════════════════════════
# LEGAL REFERENCE (local — informational, NOT legal advice)
# ══════════════════════════════════════════════════════════════════════════


def entity_type_compare(args: Dict[str, Any]) -> Dict[str, Any]:
    """Compare common US business entity types."""
    comparison = [
        {
            "entity": "Sole Proprietorship",
            "liability": "Unlimited personal liability",
            "taxation": "Pass-through; reported on owner's Schedule C",
            "formation": "No filing required; default for solo owners",
            "ongoing": "Minimal — no annual report in most states",
            "best_for": "Low-risk solo side projects, testing an idea",
        },
        {
            "entity": "LLC",
            "liability": "Limited — personal assets generally protected",
            "taxation": "Pass-through by default; can elect S-Corp or C-Corp",
            "formation": "File articles of organization; operating agreement advised",
            "ongoing": "Annual report / franchise tax in most states",
            "best_for": "Most small businesses; flexibility + liability shield",
        },
        {
            "entity": "S-Corporation",
            "liability": "Limited — personal assets generally protected",
            "taxation": "Pass-through; owner-employees split salary + distributions, "
                        "saving self-employment tax",
            "formation": "Form a corporation or LLC, then file IRS Form 2553",
            "ongoing": "Payroll, reasonable salary requirement, annual filings, "
                       "<=100 US-person shareholders",
            "best_for": "Profitable businesses where SE-tax savings exceed payroll cost",
        },
        {
            "entity": "C-Corporation",
            "liability": "Limited — personal assets generally protected",
            "taxation": "Entity taxed at corporate rate; dividends taxed again "
                        "(double taxation)",
            "formation": "File articles of incorporation; issue stock; bylaws",
            "ongoing": "Board, bylaws, minutes, annual filings; most formal",
            "best_for": "Raising VC, issuing stock options, going public",
        },
    ]
    return _ok(
        comparison=comparison,
        note="Tax treatment depends on elections and state law. Costs and "
             "self-employment tax math vary widely.",
        disclaimer=_DISCLAIMER,
    )


_FILING_CALENDARS: Dict[str, Dict[str, Any]] = {
    "DE": {
        "LLC": [
            {"item": "Delaware LLC annual franchise tax",
             "due": "June 1 each year",
             "amount": "$300 flat",
             "notes": "No annual report for LLCs; tax only."},
            {"item": "Registered agent renewal",
             "due": "Per agent's billing cycle",
             "amount": "Varies (~$50-300/yr)",
             "notes": "Required to maintain good standing."},
        ],
        "CORP": [
            {"item": "Delaware annual report + franchise tax",
             "due": "March 1 each year",
             "amount": "Min $175 (authorized shares) or assumed-par-value method",
             "notes": "Report and tax filed together online."},
        ],
    },
    "CA": {
        "LLC": [
            {"item": "California $800 annual franchise tax",
             "due": "15th day of 4th month of tax year (Apr 15 for calendar year)",
             "amount": "$800 minimum",
             "notes": "First-year exemption rules have changed over time."},
            {"item": "Statement of Information (Form LLC-12)",
             "due": "Within 90 days of formation, then every 2 years",
             "amount": "$20",
             "notes": "Filed with the Secretary of State."},
            {"item": "LLC fee (gross-receipts based)",
             "due": "With the tax return if applicable",
             "amount": "$0-$11,790 depending on CA gross receipts",
             "notes": "Applies above $250k CA receipts."},
        ],
        "CORP": [
            {"item": "California $800 minimum franchise tax",
             "due": "15th day of 4th month of tax year",
             "amount": "$800 minimum",
             "notes": "Owed even at a loss."},
            {"item": "Statement of Information (Form SI-550)",
             "due": "Within 90 days of registration, then annually",
             "amount": "$25",
             "notes": "Filed with the Secretary of State."},
        ],
    },
    "WY": {
        "LLC": [
            {"item": "Wyoming annual report license tax",
             "due": "First day of the anniversary month of formation",
             "amount": "$60 minimum (or $0.0002 per $ of WY assets)",
             "notes": "No state income tax."},
        ],
        "CORP": [
            {"item": "Wyoming annual report license tax",
             "due": "First day of the anniversary month of formation",
             "amount": "$60 minimum",
             "notes": "No state corporate income tax."},
        ],
    },
}

_FEDERAL_FILINGS = [
    {"item": "Federal income tax return",
     "due": "LLC/S-Corp: March 15 (1065/1120-S); C-Corp: April 15 (1120)",
     "notes": "Calendar-year filers; extensions available."},
    {"item": "Estimated quarterly taxes",
     "due": "Apr 15, Jun 15, Sep 15, Jan 15",
     "notes": "For pass-through owners and C-Corps with tax liability."},
    {"item": "Beneficial Ownership Information (BOI) report",
     "due": "Per current FinCEN rules — verify, requirements have changed",
     "notes": "Check FinCEN for the latest applicability and deadlines."},
]


def business_filing_calendar(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return annual filing deadlines for a business entity by state."""
    state = str(args.get("state", "DE")).upper()
    entity = str(args.get("entity_type", "LLC")).upper()
    entity_key = "CORP" if entity in ("CORP", "C-CORP", "S-CORP",
                                      "CCORP", "SCORP", "CORPORATION") else "LLC"
    state_data = _FILING_CALENDARS.get(state)
    if not state_data:
        return _ok(
            state=state,
            entity_type=entity,
            state_filings=[],
            federal_filings=_FEDERAL_FILINGS,
            note=f"No curated state calendar for {state}. Known states: "
                 f"{', '.join(sorted(_FILING_CALENDARS))}. "
                 "Check your Secretary of State website.",
            disclaimer=_DISCLAIMER,
        )
    return _ok(
        state=state,
        entity_type=entity,
        state_filings=state_data.get(entity_key, []),
        federal_filings=_FEDERAL_FILINGS,
        note="Deadlines and amounts change — always verify with the state "
             "Secretary of State and the IRS.",
        disclaimer=_DISCLAIMER,
    )


_CLAUSE_LIBRARY: Dict[str, str] = {
    "indemnification": (
        "Indemnification. Each Party (the \"Indemnifying Party\") shall "
        "indemnify, defend, and hold harmless the other Party and its "
        "officers, directors, employees, and agents (the \"Indemnified "
        "Parties\") from and against any and all third-party claims, "
        "losses, liabilities, damages, costs, and expenses (including "
        "reasonable attorneys' fees) arising out of or related to the "
        "Indemnifying Party's negligence, willful misconduct, or breach "
        "of this Agreement. The Indemnified Party shall promptly notify "
        "the Indemnifying Party of any claim and provide reasonable "
        "cooperation in the defense."
    ),
    "limitation_of_liability": (
        "Limitation of Liability. EXCEPT FOR BREACHES OF CONFIDENTIALITY, "
        "INDEMNIFICATION OBLIGATIONS, OR A PARTY'S GROSS NEGLIGENCE OR "
        "WILLFUL MISCONDUCT, IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR "
        "ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE "
        "DAMAGES, OR FOR LOST PROFITS OR REVENUE. EACH PARTY'S TOTAL "
        "AGGREGATE LIABILITY UNDER THIS AGREEMENT SHALL NOT EXCEED THE "
        "TOTAL FEES PAID OR PAYABLE IN THE TWELVE (12) MONTHS PRECEDING "
        "THE EVENT GIVING RISE TO THE CLAIM."
    ),
    "termination": (
        "Termination. Either Party may terminate this Agreement: (a) for "
        "convenience upon thirty (30) days' prior written notice; or "
        "(b) immediately upon written notice if the other Party "
        "materially breaches this Agreement and fails to cure such breach "
        "within fifteen (15) days after receiving written notice of it. "
        "Upon termination, the Client shall pay for all Services properly "
        "rendered through the effective date of termination. Sections "
        "addressing confidentiality, indemnification, limitation of "
        "liability, and governing law survive termination."
    ),
    "confidentiality": (
        "Confidentiality. Each Party may receive non-public information "
        "of the other (\"Confidential Information\"). The receiving Party "
        "shall: (a) use Confidential Information solely to perform under "
        "this Agreement; (b) protect it with at least reasonable care; "
        "and (c) not disclose it to any third party without prior written "
        "consent, except to employees or contractors with a need to know "
        "who are bound by similar obligations. These obligations survive "
        "for three (3) years after termination, and indefinitely for "
        "trade secrets."
    ),
    "ip_assignment": (
        "Intellectual Property Assignment. All deliverables, work product, "
        "inventions, and materials created by the Contractor specifically "
        "for the Client under this Agreement (the \"Work Product\") are "
        "deemed \"works made for hire.\" To the extent any Work Product is "
        "not a work made for hire, the Contractor hereby irrevocably "
        "assigns to the Client all right, title, and interest in and to "
        "such Work Product, effective upon full payment. The Contractor "
        "retains ownership of its pre-existing tools, libraries, and "
        "know-how and grants the Client a non-exclusive license to use "
        "them as embedded in the Work Product."
    ),
    "non_compete": (
        "Non-Compete. During the term of this Agreement and for twelve "
        "(12) months thereafter, the Contractor shall not, within the "
        "geographic area where the Client operates, directly engage in a "
        "business that competes with the Client's business as conducted "
        "during the engagement. NOTE: Non-compete enforceability varies "
        "dramatically by jurisdiction and is restricted or banned in many "
        "states; narrow scope, duration, and geography to what is "
        "reasonably necessary to protect legitimate interests."
    ),
    "force_majeure": (
        "Force Majeure. Neither Party is liable for any failure or delay "
        "in performance (other than payment obligations) caused by events "
        "beyond its reasonable control, including acts of God, natural "
        "disasters, war, terrorism, civil unrest, government action, "
        "epidemics, labor disputes, or failures of utilities or the "
        "internet. The affected Party shall promptly notify the other and "
        "use commercially reasonable efforts to resume performance. If a "
        "force majeure event continues for more than sixty (60) days, "
        "either Party may terminate this Agreement on written notice."
    ),
    "governing_law": (
        "Governing Law and Venue. This Agreement is governed by and "
        "construed in accordance with the laws of the State of Delaware, "
        "without regard to its conflict-of-laws principles. The Parties "
        "consent to the exclusive jurisdiction and venue of the state and "
        "federal courts located in Delaware for any dispute arising out "
        "of or relating to this Agreement."
    ),
}


def contract_clause_library(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return standard text for a common contract clause."""
    clause = str(args.get("clause_type", "")).strip().lower().replace("-", "_")
    clause = clause.replace(" ", "_")
    if not clause:
        return _err("clause_type required",
                    available=sorted(_CLAUSE_LIBRARY),
                    disclaimer=_DISCLAIMER)
    text = _CLAUSE_LIBRARY.get(clause)
    if text is None:
        return _err(f"unknown clause_type '{clause}'",
                    available=sorted(_CLAUSE_LIBRARY),
                    disclaimer=_DISCLAIMER)
    return _ok(clause_type=clause, text=text, disclaimer=_DISCLAIMER)


_LEGAL_TERMS: Dict[str, str] = {
    "indemnification": "A promise by one party to cover the losses or legal "
                       "costs of another party if a specified bad thing happens.",
    "force majeure": "A contract clause excusing performance when extraordinary "
                      "events beyond a party's control (war, disaster) make it "
                      "impossible.",
    "consideration": "Something of value (money, services, a promise) that each "
                     "side gives — required to make a contract legally binding.",
    "breach": "Failure to perform any term of a contract without a legitimate "
              "legal excuse.",
    "liquidated damages": "A pre-agreed dollar amount the breaching party must "
                          "pay, set in the contract instead of proving actual "
                          "damages later.",
    "arbitration": "A private dispute-resolution process where a neutral "
                    "arbitrator (not a court) decides the outcome, usually "
                    "binding.",
    "tort": "A civil wrong (e.g., negligence) that causes harm and can lead to "
            "liability, separate from contract law.",
    "fiduciary duty": "A legal obligation to act in another party's best "
                       "interest, e.g., a director toward shareholders.",
    "due diligence": "The investigation a reasonable party performs before "
                      "entering a deal, e.g., reviewing finances before an "
                      "acquisition.",
    "non-disclosure agreement": "A contract (NDA) in which parties agree to keep "
                                "shared information confidential.",
    "intellectual property": "Intangible creations — patents, trademarks, "
                             "copyrights, trade secrets — that can be owned and "
                             "licensed.",
    "warranty": "A promise or assurance about a fact or the quality of goods or "
                "services; breaching it can create liability.",
    "boilerplate": "Standard, reusable contract clauses (governing law, notices, "
                    "severability) usually placed near the end.",
    "severability": "A clause stating that if one provision is found invalid, "
                     "the rest of the contract still stands.",
    "jurisdiction": "A court's authority to hear a case, and the location whose "
                     "courts and laws apply to a dispute.",
    "injunction": "A court order requiring a party to do, or stop doing, a "
                   "specific act.",
    "estoppel": "A legal principle preventing someone from asserting something "
                "contrary to what they previously stated or implied.",
    "novation": "Replacing a party or obligation in a contract with a new one, "
                "with all parties' consent, extinguishing the old obligation.",
    "indemnitee": "The party that is protected and reimbursed under an "
                  "indemnification clause.",
    "good standing": "Status confirming a business has met state filing and tax "
                      "requirements and is legally allowed to operate.",
}


def legal_term_define(args: Dict[str, Any]) -> Dict[str, Any]:
    """Provide a plain-English definition of a common legal term."""
    term = str(args.get("term", "")).strip().lower()
    if not term:
        return _err("term required", available=sorted(_LEGAL_TERMS),
                    disclaimer=_DISCLAIMER)
    definition = _LEGAL_TERMS.get(term)
    if definition is None:
        # Loose match: substring against known keys.
        for k, v in _LEGAL_TERMS.items():
            if term in k or k in term:
                return _ok(term=k, definition=v, matched="fuzzy",
                           disclaimer=_DISCLAIMER)
        return _err(f"no definition for '{term}'",
                    available=sorted(_LEGAL_TERMS),
                    disclaimer=_DISCLAIMER)
    return _ok(term=term, definition=definition, disclaimer=_DISCLAIMER)


def trademark_search_tips(args: Dict[str, Any]) -> Dict[str, Any]:
    """Give guidance on searching for trademark conflicts."""
    mark = args.get("mark")
    if not mark:
        return _err("mark required")
    return _ok(
        mark=mark,
        steps=[
            f"Search the USPTO Trademark Search system for '{mark}' and close "
            "variations (plurals, misspellings, phonetic equivalents).",
            "Check across the relevant goods/services classes — a conflict "
            "only matters within related classes.",
            "Run a broad web and domain search: a name used in commerce can "
            "have common-law rights even without a federal registration.",
            "Search your state's business-entity registry for similar names.",
            "Check social media handles and app stores for the same name.",
            "Consider a professional clearance search by a trademark attorney "
            "before investing in branding or filing.",
        ],
        uspto_search_url="https://tmsearch.uspto.gov/",
        uspto_filing_url="https://www.uspto.gov/trademarks",
        note="A clear search reduces risk but does not guarantee "
             "registrability — examiners and existing owners can still object.",
        disclaimer=_DISCLAIMER,
    )


# ══════════════════════════════════════════════════════════════════════════
# DOCUMENT TRACKING (local SQLite)
# ══════════════════════════════════════════════════════════════════════════


def document_track(args: Dict[str, Any]) -> Dict[str, Any]:
    """Log a contract / legal document into the local tracker."""
    name = args.get("name")
    dtype = args.get("type")
    status = args.get("status")
    if not (name and dtype and status):
        return _err("name, type, status required")
    value = args.get("value")
    try:
        value = float(value) if value is not None else None
    except (TypeError, ValueError):
        return _err("value must be numeric")
    expiry = args.get("expiry_date")
    if expiry:
        try:
            datetime.fromisoformat(str(expiry))
        except ValueError:
            return _err("expiry_date must be ISO format (YYYY-MM-DD)")
    try:
        c = _conn()
        cur = c.execute(
            "INSERT INTO documents (name, type, status, counterparty, "
            "value, expiry_date) VALUES (?, ?, ?, ?, ?, ?)",
            (name, dtype, status, args.get("counterparty"), value, expiry),
        )
        c.commit()
    except Exception as e:
        return _err(f"database error: {e}")
    return _ok(
        id=cur.lastrowid,
        name=name,
        type=dtype,
        status=status,
        counterparty=args.get("counterparty"),
        value=value,
        expiry_date=expiry,
        message=f"Tracked document #{cur.lastrowid}: {name}",
    )


def documents_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List tracked documents, optionally filtered by status."""
    status = args.get("status")
    try:
        c = _conn()
        if status:
            rs = c.execute(
                "SELECT * FROM documents WHERE status = ? "
                "ORDER BY created_at DESC",
                (status,),
            ).fetchall()
        else:
            rs = c.execute(
                "SELECT * FROM documents ORDER BY created_at DESC"
            ).fetchall()
    except Exception as e:
        return _err(f"database error: {e}")
    docs = _rows(rs)
    return _ok(documents=docs, count=len(docs),
               status_filter=status or "all")


def documents_expiring(args: Dict[str, Any]) -> Dict[str, Any]:
    """List tracked documents expiring within N days (default 60)."""
    try:
        days = int(args.get("days", 60))
    except (TypeError, ValueError):
        return _err("days must be an integer")
    cutoff = (date.today() + timedelta(days=days)).isoformat()
    today = _today()
    try:
        c = _conn()
        rs = c.execute(
            "SELECT * FROM documents WHERE expiry_date IS NOT NULL "
            "AND expiry_date != '' AND expiry_date <= ? "
            "ORDER BY expiry_date ASC",
            (cutoff,),
        ).fetchall()
    except Exception as e:
        return _err(f"database error: {e}")
    docs = []
    for d in _rows(rs):
        exp = d.get("expiry_date")
        try:
            days_left = (datetime.fromisoformat(str(exp)).date()
                         - date.today()).days
        except Exception:
            days_left = None
        d["days_until_expiry"] = days_left
        d["expired"] = bool(exp and str(exp) < today)
        docs.append(d)
    return _ok(documents=docs, count=len(docs), within_days=days,
               cutoff_date=cutoff)


# ══════════════════════════════════════════════════════════════════════════
# EXTRA_TOOLS EXPORT
# ══════════════════════════════════════════════════════════════════════════

EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # DocuSign
    "legal.docusign_envelopes": docusign_envelopes,
    "legal.docusign_envelope_status": docusign_envelope_status,
    "legal.docusign_send": docusign_send,
    "legal.docusign_void": docusign_void,
    # Dropbox Sign / HelloSign
    "legal.dropboxsign_send": dropboxsign_send,
    "legal.dropboxsign_list": dropboxsign_list,
    "legal.dropboxsign_status": dropboxsign_status,
    # PandaDoc
    "legal.pandadoc_documents": pandadoc_documents,
    "legal.pandadoc_document_status": pandadoc_document_status,
    "legal.pandadoc_create_from_template": pandadoc_create_from_template,
    # Contract templates
    "legal.template_nda": template_nda,
    "legal.template_consulting_agreement": template_consulting_agreement,
    "legal.template_service_agreement": template_service_agreement,
    "legal.template_invoice_terms": template_invoice_terms,
    "legal.template_privacy_policy": template_privacy_policy,
    "legal.template_terms_of_service": template_terms_of_service,
    "legal.template_cease_and_desist": template_cease_and_desist,
    "legal.template_demand_letter": template_demand_letter,
    "legal.list_templates": list_templates,
    # Legal reference
    "legal.entity_type_compare": entity_type_compare,
    "legal.business_filing_calendar": business_filing_calendar,
    "legal.contract_clause_library": contract_clause_library,
    "legal.legal_term_define": legal_term_define,
    "legal.trademark_search_tips": trademark_search_tips,
    # Tracking
    "legal.document_track": document_track,
    "legal.documents_list": documents_list,
    "legal.documents_expiring": documents_expiring,
}
