"""project_mgmt.py — Leon's project-management integration hub.

Backends: Linear, Jira, Trello, Asana, ClickUp, GitHub Projects v2.

Each tool reads credentials lazily (env first, then `~/.openclaw/secrets.json`),
makes `requests` calls with a 12s default timeout, and returns the standard
`{ok, ...}` contract used by the rest of the brain. Nothing in this module
raises — every exception is wrapped into
`{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `pm.linear_issues`) to
callables that take a single `dict` argument. Import that dict from the
responder / MCP server to register everything in one shot.

Credentials read:
  - LINEAR_API_KEY
  - JIRA_DOMAIN  (e.g. "yourco.atlassian.net")
  - JIRA_EMAIL
  - JIRA_API_TOKEN
  - TRELLO_API_KEY
  - TRELLO_TOKEN
  - ASANA_ACCESS_TOKEN
  - CLICKUP_API_TOKEN
  - GITHUB_TOKEN  (falls back to `gh auth token`)

Secrets file fallback: `~/.openclaw/secrets.json` — a flat JSON object,
e.g. `{"LINEAR_API_KEY": "...", "JIRA_API_TOKEN": "...", ...}`.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 12.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file.

    Returns `{}` on any error — caller will fall through to a missing
    credential message. Never raises, never logs values.
    """
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _missing(keys: Any, platform: str) -> Dict[str, Any]:
    """Standard missing-credentials envelope. `keys` may be str or list."""
    if isinstance(keys, (list, tuple)):
        key_str = " + ".join(keys)
    else:
        key_str = str(keys)
    return {
        "ok": False,
        "error": f"credentials missing — needs {key_str} env var(s) "
                 f"(or entries in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _http_error(resp: requests.Response, platform: str) -> Dict[str, Any]:
    """Build an error envelope from a non-2xx HTTP response."""
    detail: Any
    try:
        detail = resp.json()
    except Exception:
        detail = resp.text[:1000]
    return {
        "ok": False,
        "error": f"{platform} HTTP {resp.status_code}",
        "detail": detail,
    }


def _gh_token() -> Optional[str]:
    """GitHub token from env/secrets, falling back to `gh auth token`."""
    tok = _get_secret("GITHUB_TOKEN")
    if tok:
        return tok
    try:
        out = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True, text=True, timeout=8,
        )
        if out.returncode == 0 and out.stdout.strip():
            return out.stdout.strip()
    except Exception:
        pass
    return None


# ──────────────────────────────────────────────────────────────────────────
# LINEAR  (GraphQL — https://api.linear.app/graphql)
# ──────────────────────────────────────────────────────────────────────────

_LINEAR_API = "https://api.linear.app/graphql"


def _linear_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("LINEAR_API_KEY")
    if not tok:
        return None
    return {"Authorization": tok, "Content-Type": "application/json"}


def _linear_query(query: str, variables: Optional[dict] = None) -> Dict[str, Any]:
    """Run a GraphQL request against Linear, return {ok, data} or error."""
    headers = _linear_headers()
    if headers is None:
        return _missing("LINEAR_API_KEY", "Linear")
    try:
        resp = requests.post(
            _LINEAR_API,
            headers=headers,
            json={"query": query, "variables": variables or {}},
            timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code >= 300:
            return _http_error(resp, "Linear")
        body = resp.json()
        if body.get("errors"):
            return {"ok": False, "error": "Linear GraphQL error",
                    "detail": body["errors"]}
        return {"ok": True, "data": body.get("data", {})}
    except Exception as e:
        return _err(e)


def _linear_issues(args: dict) -> dict:
    """List Linear issues, optionally filtered by team key/name and state."""
    team = args.get("team")
    state = args.get("state")
    try:
        limit = int(args.get("limit", 30))
    except Exception:
        limit = 30
    filt: Dict[str, Any] = {}
    if team:
        filt["team"] = {"or": [
            {"key": {"eq": str(team)}},
            {"name": {"eqIgnoreCase": str(team)}},
        ]}
    if state:
        filt["state"] = {"name": {"eqIgnoreCase": str(state)}}
    query = """
    query Issues($filter: IssueFilter, $first: Int) {
      issues(filter: $filter, first: $first,
             orderBy: updatedAt) {
        nodes {
          id identifier title priority url
          state { name type }
          team { key name }
          assignee { name }
          updatedAt
        }
      }
    }"""
    res = _linear_query(query, {"filter": filt, "first": limit})
    if not res.get("ok"):
        return res
    nodes = res["data"].get("issues", {}).get("nodes", [])
    return {"ok": True, "count": len(nodes), "issues": nodes}


def _linear_issue_get(args: dict) -> dict:
    """Fetch a single Linear issue by id or identifier (e.g. ENG-123)."""
    issue_id = str(args.get("issue_id", "")).strip()
    if not issue_id:
        return {"ok": False, "error": "issue_id required"}
    query = """
    query Issue($id: String!) {
      issue(id: $id) {
        id identifier title description priority url
        state { name type }
        team { key name }
        assignee { name }
        creator { name }
        comments { nodes { body user { name } createdAt } }
        createdAt updatedAt
      }
    }"""
    res = _linear_query(query, {"id": issue_id})
    if not res.get("ok"):
        return res
    issue = res["data"].get("issue")
    if not issue:
        return {"ok": False, "error": f"Linear issue not found: {issue_id}"}
    return {"ok": True, "issue": issue}


def _linear_issue_create(args: dict) -> dict:
    """Create a Linear issue.  MEDIUM — mutates remote state."""
    title = str(args.get("title", "")).strip()
    team_id = str(args.get("team_id", "")).strip()
    if not title or not team_id:
        return {"ok": False, "error": "title and team_id required"}
    inp: Dict[str, Any] = {"title": title, "teamId": team_id}
    if args.get("description"):
        inp["description"] = str(args["description"])
    if args.get("priority") is not None:
        try:
            inp["priority"] = int(args["priority"])
        except Exception:
            pass
    if args.get("assignee"):
        inp["assigneeId"] = str(args["assignee"])
    query = """
    mutation Create($input: IssueCreateInput!) {
      issueCreate(input: $input) {
        success
        issue { id identifier title url }
      }
    }"""
    res = _linear_query(query, {"input": inp})
    if not res.get("ok"):
        return res
    ic = res["data"].get("issueCreate", {})
    if not ic.get("success"):
        return {"ok": False, "error": "Linear issueCreate failed",
                "detail": ic}
    return {"ok": True, "issue": ic.get("issue")}


def _linear_issue_update(args: dict) -> dict:
    """Update a Linear issue. Pass issue_id + any of title/description/
    priority/stateId/assigneeId.  MEDIUM — mutates remote state."""
    issue_id = str(args.get("issue_id", "")).strip()
    if not issue_id:
        return {"ok": False, "error": "issue_id required"}
    field_map = {
        "title": "title",
        "description": "description",
        "priority": "priority",
        "state": "stateId",
        "state_id": "stateId",
        "stateId": "stateId",
        "assignee": "assigneeId",
        "assignee_id": "assigneeId",
        "assigneeId": "assigneeId",
    }
    inp: Dict[str, Any] = {}
    for k, v in args.items():
        if k == "issue_id":
            continue
        gk = field_map.get(k)
        if not gk:
            continue
        if gk == "priority":
            try:
                inp[gk] = int(v)
            except Exception:
                continue
        else:
            inp[gk] = v
    if not inp:
        return {"ok": False, "error": "no updatable fields provided"}
    query = """
    mutation Update($id: String!, $input: IssueUpdateInput!) {
      issueUpdate(id: $id, input: $input) {
        success
        issue { id identifier title url state { name } }
      }
    }"""
    res = _linear_query(query, {"id": issue_id, "input": inp})
    if not res.get("ok"):
        return res
    iu = res["data"].get("issueUpdate", {})
    if not iu.get("success"):
        return {"ok": False, "error": "Linear issueUpdate failed",
                "detail": iu}
    return {"ok": True, "issue": iu.get("issue")}


def _linear_teams(args: dict) -> dict:
    """List Linear teams (id, key, name)."""
    query = """
    query { teams { nodes { id key name } } }"""
    res = _linear_query(query)
    if not res.get("ok"):
        return res
    nodes = res["data"].get("teams", {}).get("nodes", [])
    return {"ok": True, "count": len(nodes), "teams": nodes}


def _linear_my_issues(args: dict) -> dict:
    """List Linear issues assigned to the authenticated user."""
    query = """
    query {
      viewer {
        name
        assignedIssues(first: 50, orderBy: updatedAt) {
          nodes {
            id identifier title priority url
            state { name type }
            team { key name }
            updatedAt
          }
        }
      }
    }"""
    res = _linear_query(query)
    if not res.get("ok"):
        return res
    viewer = res["data"].get("viewer", {}) or {}
    nodes = viewer.get("assignedIssues", {}).get("nodes", [])
    return {"ok": True, "user": viewer.get("name"),
            "count": len(nodes), "issues": nodes}


def _linear_cycles(args: dict) -> dict:
    """List cycles (sprints) for a Linear team."""
    team_id = str(args.get("team_id", "")).strip()
    if not team_id:
        return {"ok": False, "error": "team_id required"}
    query = """
    query Cycles($id: String!) {
      team(id: $id) {
        key name
        cycles(first: 30) {
          nodes { id number name startsAt endsAt completedAt }
        }
      }
    }"""
    res = _linear_query(query, {"id": team_id})
    if not res.get("ok"):
        return res
    team = res["data"].get("team")
    if not team:
        return {"ok": False, "error": f"Linear team not found: {team_id}"}
    nodes = team.get("cycles", {}).get("nodes", [])
    return {"ok": True, "team": team.get("key"),
            "count": len(nodes), "cycles": nodes}


# ──────────────────────────────────────────────────────────────────────────
# JIRA  (REST API v3 — Atlassian Cloud)
# ──────────────────────────────────────────────────────────────────────────

def _jira_conf() -> Optional[Dict[str, str]]:
    """Return {base, email, token} or None if any credential is missing."""
    domain = _get_secret("JIRA_DOMAIN")
    email = _get_secret("JIRA_EMAIL")
    token = _get_secret("JIRA_API_TOKEN")
    if not (domain and email and token):
        return None
    domain = domain.replace("https://", "").replace("http://", "").strip("/")
    return {
        "base": f"https://{domain}",
        "email": email,
        "token": token,
    }


def _jira_request(method: str, path: str, *, params: Optional[dict] = None,
                  body: Optional[dict] = None) -> Dict[str, Any]:
    """Make an authenticated Jira REST call. Returns {ok, json} or error."""
    conf = _jira_conf()
    if conf is None:
        return _missing(["JIRA_DOMAIN", "JIRA_EMAIL", "JIRA_API_TOKEN"], "Jira")
    try:
        resp = requests.request(
            method,
            f"{conf['base']}{path}",
            auth=(conf["email"], conf["token"]),
            headers={"Accept": "application/json",
                     "Content-Type": "application/json"},
            params=params,
            json=body,
            timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code >= 300:
            return _http_error(resp, "Jira")
        if resp.status_code == 204 or not resp.text:
            return {"ok": True, "json": {}}
        return {"ok": True, "json": resp.json()}
    except Exception as e:
        return _err(e)


def _jira_adf(text: str) -> dict:
    """Wrap plain text into a minimal Atlassian Document Format node."""
    return {
        "type": "doc",
        "version": 1,
        "content": [{
            "type": "paragraph",
            "content": [{"type": "text", "text": str(text)}],
        }],
    }


def _jira_slim_issue(issue: dict) -> dict:
    """Reduce a Jira issue payload to the fields Leon cares about."""
    f = issue.get("fields", {}) or {}
    assignee = f.get("assignee") or {}
    status = f.get("status") or {}
    priority = f.get("priority") or {}
    itype = f.get("issuetype") or {}
    return {
        "key": issue.get("key"),
        "summary": f.get("summary"),
        "status": status.get("name"),
        "type": itype.get("name"),
        "priority": priority.get("name"),
        "assignee": assignee.get("displayName"),
        "updated": f.get("updated"),
    }


def _jira_search(args: dict) -> dict:
    """Search Jira issues with a JQL query string."""
    jql = str(args.get("jql", "")).strip()
    if not jql:
        return {"ok": False, "error": "jql required"}
    try:
        limit = int(args.get("limit", 30))
    except Exception:
        limit = 30
    res = _jira_request(
        "GET", "/rest/api/3/search",
        params={"jql": jql, "maxResults": limit,
                "fields": "summary,status,issuetype,priority,assignee,updated"},
    )
    if not res.get("ok"):
        return res
    issues = res["json"].get("issues", [])
    return {
        "ok": True,
        "total": res["json"].get("total"),
        "count": len(issues),
        "issues": [_jira_slim_issue(i) for i in issues],
    }


def _jira_issue_get(args: dict) -> dict:
    """Fetch a single Jira issue by key (e.g. PROJ-42)."""
    key = str(args.get("issue_key", "")).strip()
    if not key:
        return {"ok": False, "error": "issue_key required"}
    res = _jira_request("GET", f"/rest/api/3/issue/{key}")
    if not res.get("ok"):
        return res
    issue = res["json"]
    slim = _jira_slim_issue(issue)
    f = issue.get("fields", {}) or {}
    desc = f.get("description")
    slim["description"] = desc if isinstance(desc, str) else None
    slim["reporter"] = (f.get("reporter") or {}).get("displayName")
    slim["created"] = f.get("created")
    return {"ok": True, "issue": slim}


def _jira_issue_create(args: dict) -> dict:
    """Create a Jira issue.  MEDIUM — mutates remote state."""
    project_key = str(args.get("project_key", "")).strip()
    summary = str(args.get("summary", "")).strip()
    if not project_key or not summary:
        return {"ok": False, "error": "project_key and summary required"}
    issue_type = str(args.get("issue_type", "Task")).strip() or "Task"
    fields: Dict[str, Any] = {
        "project": {"key": project_key},
        "summary": summary,
        "issuetype": {"name": issue_type},
    }
    if args.get("description"):
        fields["description"] = _jira_adf(args["description"])
    res = _jira_request("POST", "/rest/api/3/issue", body={"fields": fields})
    if not res.get("ok"):
        return res
    created = res["json"]
    return {"ok": True, "key": created.get("key"), "id": created.get("id"),
            "url": created.get("self")}


def _jira_issue_transition(args: dict) -> dict:
    """Transition a Jira issue by transition name (e.g. "Done").
    MEDIUM — mutates remote state."""
    key = str(args.get("issue_key", "")).strip()
    name = str(args.get("transition_name", "")).strip()
    if not key or not name:
        return {"ok": False, "error": "issue_key and transition_name required"}
    res = _jira_request("GET", f"/rest/api/3/issue/{key}/transitions")
    if not res.get("ok"):
        return res
    transitions = res["json"].get("transitions", [])
    match = next(
        (t for t in transitions
         if str(t.get("name", "")).lower() == name.lower()),
        None,
    )
    if match is None:
        return {"ok": False,
                "error": f"transition '{name}' not available",
                "available": [t.get("name") for t in transitions]}
    res2 = _jira_request(
        "POST", f"/rest/api/3/issue/{key}/transitions",
        body={"transition": {"id": match["id"]}},
    )
    if not res2.get("ok"):
        return res2
    return {"ok": True, "issue_key": key, "transitioned_to": match.get("name")}


def _jira_issue_comment(args: dict) -> dict:
    """Add a comment to a Jira issue.  MEDIUM — mutates remote state."""
    key = str(args.get("issue_key", "")).strip()
    body = str(args.get("body", "")).strip()
    if not key or not body:
        return {"ok": False, "error": "issue_key and body required"}
    res = _jira_request(
        "POST", f"/rest/api/3/issue/{key}/comment",
        body={"body": _jira_adf(body)},
    )
    if not res.get("ok"):
        return res
    return {"ok": True, "issue_key": key, "comment_id": res["json"].get("id")}


def _jira_my_issues(args: dict) -> dict:
    """List open Jira issues assigned to the current user."""
    return _jira_search({
        "jql": "assignee = currentUser() AND statusCategory != Done "
               "ORDER BY updated DESC",
        "limit": 50,
    })


def _jira_projects(args: dict) -> dict:
    """List Jira projects visible to the current user."""
    res = _jira_request("GET", "/rest/api/3/project/search",
                        params={"maxResults": 100})
    if not res.get("ok"):
        return res
    values = res["json"].get("values", [])
    projects = [{"key": p.get("key"), "name": p.get("name"),
                 "id": p.get("id")} for p in values]
    return {"ok": True, "count": len(projects), "projects": projects}


def _jira_sprints(args: dict) -> dict:
    """List sprints for a Jira board (Agile API)."""
    board_id = str(args.get("board_id", "")).strip()
    if not board_id:
        return {"ok": False, "error": "board_id required"}
    res = _jira_request("GET", f"/rest/agile/1.0/board/{board_id}/sprint",
                        params={"maxResults": 50})
    if not res.get("ok"):
        return res
    values = res["json"].get("values", [])
    sprints = [{"id": s.get("id"), "name": s.get("name"),
                "state": s.get("state"), "startDate": s.get("startDate"),
                "endDate": s.get("endDate")} for s in values]
    return {"ok": True, "count": len(sprints), "sprints": sprints}


# ──────────────────────────────────────────────────────────────────────────
# TRELLO  (REST API — https://api.trello.com/1)
# ──────────────────────────────────────────────────────────────────────────

_TRELLO_API = "https://api.trello.com/1"


def _trello_auth() -> Optional[Dict[str, str]]:
    """Return {key, token} auth params, or None if missing."""
    key = _get_secret("TRELLO_API_KEY")
    token = _get_secret("TRELLO_TOKEN")
    if not (key and token):
        return None
    return {"key": key, "token": token}


def _trello_request(method: str, path: str, *,
                    params: Optional[dict] = None) -> Dict[str, Any]:
    """Authenticated Trello REST call. Returns {ok, json} or error."""
    auth = _trello_auth()
    if auth is None:
        return _missing(["TRELLO_API_KEY", "TRELLO_TOKEN"], "Trello")
    p = dict(auth)
    if params:
        p.update(params)
    try:
        resp = requests.request(
            method, f"{_TRELLO_API}{path}", params=p,
            timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code >= 300:
            return _http_error(resp, "Trello")
        if not resp.text:
            return {"ok": True, "json": {}}
        return {"ok": True, "json": resp.json()}
    except Exception as e:
        return _err(e)


def _trello_boards(args: dict) -> dict:
    """List Trello boards for the authenticated member."""
    res = _trello_request("GET", "/members/me/boards",
                          params={"fields": "name,url,closed"})
    if not res.get("ok"):
        return res
    boards = [{"id": b.get("id"), "name": b.get("name"),
               "url": b.get("url"), "closed": b.get("closed")}
              for b in res["json"]]
    return {"ok": True, "count": len(boards), "boards": boards}


def _trello_lists(args: dict) -> dict:
    """List the lists (columns) on a Trello board."""
    board_id = str(args.get("board_id", "")).strip()
    if not board_id:
        return {"ok": False, "error": "board_id required"}
    res = _trello_request("GET", f"/boards/{board_id}/lists",
                          params={"fields": "name,closed"})
    if not res.get("ok"):
        return res
    lists = [{"id": l.get("id"), "name": l.get("name"),
              "closed": l.get("closed")} for l in res["json"]]
    return {"ok": True, "count": len(lists), "lists": lists}


def _trello_cards(args: dict) -> dict:
    """List cards in a Trello list."""
    list_id = str(args.get("list_id", "")).strip()
    if not list_id:
        return {"ok": False, "error": "list_id required"}
    res = _trello_request("GET", f"/lists/{list_id}/cards",
                          params={"fields": "name,desc,due,url,closed"})
    if not res.get("ok"):
        return res
    cards = [{"id": c.get("id"), "name": c.get("name"),
              "desc": c.get("desc"), "due": c.get("due"),
              "url": c.get("url")} for c in res["json"]]
    return {"ok": True, "count": len(cards), "cards": cards}


def _trello_card_create(args: dict) -> dict:
    """Create a Trello card in a list.  MEDIUM — mutates remote state."""
    list_id = str(args.get("list_id", "")).strip()
    name = str(args.get("name", "")).strip()
    if not list_id or not name:
        return {"ok": False, "error": "list_id and name required"}
    params: Dict[str, Any] = {"idList": list_id, "name": name}
    if args.get("desc"):
        params["desc"] = str(args["desc"])
    if args.get("due"):
        params["due"] = str(args["due"])
    res = _trello_request("POST", "/cards", params=params)
    if not res.get("ok"):
        return res
    c = res["json"]
    return {"ok": True, "card": {"id": c.get("id"), "name": c.get("name"),
                                 "url": c.get("url")}}


def _trello_card_move(args: dict) -> dict:
    """Move a Trello card to another list.  MEDIUM — mutates remote state."""
    card_id = str(args.get("card_id", "")).strip()
    target = str(args.get("target_list_id", "")).strip()
    if not card_id or not target:
        return {"ok": False, "error": "card_id and target_list_id required"}
    res = _trello_request("PUT", f"/cards/{card_id}",
                          params={"idList": target})
    if not res.get("ok"):
        return res
    return {"ok": True, "card_id": card_id, "moved_to": target}


def _trello_card_comment(args: dict) -> dict:
    """Add a comment to a Trello card.  MEDIUM — mutates remote state."""
    card_id = str(args.get("card_id", "")).strip()
    text = str(args.get("text", "")).strip()
    if not card_id or not text:
        return {"ok": False, "error": "card_id and text required"}
    res = _trello_request("POST", f"/cards/{card_id}/actions/comments",
                          params={"text": text})
    if not res.get("ok"):
        return res
    return {"ok": True, "card_id": card_id, "comment_id": res["json"].get("id")}


# ──────────────────────────────────────────────────────────────────────────
# ASANA  (REST API — https://app.asana.com/api/1.0)
# ──────────────────────────────────────────────────────────────────────────

_ASANA_API = "https://app.asana.com/api/1.0"


def _asana_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("ASANA_ACCESS_TOKEN")
    if not tok:
        return None
    return {"Authorization": f"Bearer {tok}",
            "Content-Type": "application/json"}


def _asana_request(method: str, path: str, *, params: Optional[dict] = None,
                   body: Optional[dict] = None) -> Dict[str, Any]:
    """Authenticated Asana REST call. Returns {ok, json} or error."""
    headers = _asana_headers()
    if headers is None:
        return _missing("ASANA_ACCESS_TOKEN", "Asana")
    try:
        resp = requests.request(
            method, f"{_ASANA_API}{path}", headers=headers,
            params=params, json=body, timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code >= 300:
            return _http_error(resp, "Asana")
        if not resp.text:
            return {"ok": True, "json": {}}
        return {"ok": True, "json": resp.json()}
    except Exception as e:
        return _err(e)


def _asana_default_workspace() -> Optional[str]:
    """Return the gid of the user's first workspace, or None."""
    res = _asana_request("GET", "/users/me")
    if not res.get("ok"):
        return None
    workspaces = res["json"].get("data", {}).get("workspaces", [])
    if workspaces:
        return workspaces[0].get("gid")
    return None


def _asana_projects(args: dict) -> dict:
    """List Asana projects in a workspace (default: first workspace)."""
    workspace = args.get("workspace")
    if not workspace:
        workspace = _asana_default_workspace()
        if not workspace:
            return {"ok": False,
                    "error": "no workspace found (pass workspace gid)"}
    res = _asana_request("GET", "/projects",
                         params={"workspace": str(workspace),
                                 "opt_fields": "name,archived",
                                 "limit": 100})
    if not res.get("ok"):
        return res
    data = res["json"].get("data", [])
    projects = [{"gid": p.get("gid"), "name": p.get("name"),
                 "archived": p.get("archived")} for p in data]
    return {"ok": True, "workspace": str(workspace),
            "count": len(projects), "projects": projects}


def _asana_tasks(args: dict) -> dict:
    """List tasks in an Asana project."""
    project_id = str(args.get("project_id", "")).strip()
    if not project_id:
        return {"ok": False, "error": "project_id required"}
    try:
        limit = int(args.get("limit", 30))
    except Exception:
        limit = 30
    completed = bool(args.get("completed", False))
    params: Dict[str, Any] = {
        "project": project_id,
        "opt_fields": "name,completed,due_on,assignee.name",
        "limit": limit,
    }
    if not completed:
        params["completed_since"] = "now"
    res = _asana_request("GET", "/tasks", params=params)
    if not res.get("ok"):
        return res
    data = res["json"].get("data", [])
    tasks = [{"gid": t.get("gid"), "name": t.get("name"),
              "completed": t.get("completed"), "due_on": t.get("due_on"),
              "assignee": (t.get("assignee") or {}).get("name")}
             for t in data]
    return {"ok": True, "count": len(tasks), "tasks": tasks}


def _asana_task_create(args: dict) -> dict:
    """Create an Asana task in a project.  MEDIUM — mutates remote state."""
    project_id = str(args.get("project_id", "")).strip()
    name = str(args.get("name", "")).strip()
    if not project_id or not name:
        return {"ok": False, "error": "project_id and name required"}
    data: Dict[str, Any] = {"name": name, "projects": [project_id]}
    if args.get("notes"):
        data["notes"] = str(args["notes"])
    if args.get("due_on"):
        data["due_on"] = str(args["due_on"])
    res = _asana_request("POST", "/tasks", body={"data": data})
    if not res.get("ok"):
        return res
    t = res["json"].get("data", {})
    return {"ok": True, "task": {"gid": t.get("gid"), "name": t.get("name")}}


def _asana_task_complete(args: dict) -> dict:
    """Mark an Asana task complete.  MEDIUM — mutates remote state."""
    task_id = str(args.get("task_id", "")).strip()
    if not task_id:
        return {"ok": False, "error": "task_id required"}
    res = _asana_request("PUT", f"/tasks/{task_id}",
                         body={"data": {"completed": True}})
    if not res.get("ok"):
        return res
    return {"ok": True, "task_id": task_id, "completed": True}


def _asana_my_tasks(args: dict) -> dict:
    """List incomplete Asana tasks assigned to the current user."""
    workspace = _asana_default_workspace()
    if not workspace:
        res0 = _asana_headers()
        if res0 is None:
            return _missing("ASANA_ACCESS_TOKEN", "Asana")
        return {"ok": False, "error": "no workspace found for current user"}
    res = _asana_request("GET", "/tasks", params={
        "assignee": "me",
        "workspace": workspace,
        "completed_since": "now",
        "opt_fields": "name,completed,due_on,projects.name",
        "limit": 50,
    })
    if not res.get("ok"):
        return res
    data = res["json"].get("data", [])
    tasks = [{"gid": t.get("gid"), "name": t.get("name"),
              "due_on": t.get("due_on"),
              "projects": [p.get("name") for p in (t.get("projects") or [])]}
             for t in data]
    return {"ok": True, "count": len(tasks), "tasks": tasks}


# ──────────────────────────────────────────────────────────────────────────
# CLICKUP  (REST API v2 — https://api.clickup.com/api/v2)
# ──────────────────────────────────────────────────────────────────────────

_CLICKUP_API = "https://api.clickup.com/api/v2"


def _clickup_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("CLICKUP_API_TOKEN")
    if not tok:
        return None
    return {"Authorization": tok, "Content-Type": "application/json"}


def _clickup_request(method: str, path: str, *, params: Optional[dict] = None,
                     body: Optional[dict] = None) -> Dict[str, Any]:
    """Authenticated ClickUp REST call. Returns {ok, json} or error."""
    headers = _clickup_headers()
    if headers is None:
        return _missing("CLICKUP_API_TOKEN", "ClickUp")
    try:
        resp = requests.request(
            method, f"{_CLICKUP_API}{path}", headers=headers,
            params=params, json=body, timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code >= 300:
            return _http_error(resp, "ClickUp")
        if not resp.text:
            return {"ok": True, "json": {}}
        return {"ok": True, "json": resp.json()}
    except Exception as e:
        return _err(e)


def _clickup_default_team() -> Optional[str]:
    """Return the id of the user's first ClickUp team (workspace)."""
    res = _clickup_request("GET", "/team")
    if not res.get("ok"):
        return None
    teams = res["json"].get("teams", [])
    if teams:
        return teams[0].get("id")
    return None


def _clickup_spaces(args: dict) -> dict:
    """List ClickUp spaces in a team (default: first team)."""
    team_id = args.get("team_id")
    if not team_id:
        team_id = _clickup_default_team()
        if not team_id:
            if _clickup_headers() is None:
                return _missing("CLICKUP_API_TOKEN", "ClickUp")
            return {"ok": False, "error": "no team found (pass team_id)"}
    res = _clickup_request("GET", f"/team/{team_id}/space",
                           params={"archived": "false"})
    if not res.get("ok"):
        return res
    data = res["json"].get("spaces", [])
    spaces = [{"id": s.get("id"), "name": s.get("name")} for s in data]
    return {"ok": True, "team_id": str(team_id),
            "count": len(spaces), "spaces": spaces}


def _clickup_tasks(args: dict) -> dict:
    """List tasks in a ClickUp list."""
    list_id = str(args.get("list_id", "")).strip()
    if not list_id:
        return {"ok": False, "error": "list_id required"}
    try:
        limit = int(args.get("limit", 30))
    except Exception:
        limit = 30
    res = _clickup_request("GET", f"/list/{list_id}/task",
                           params={"archived": "false"})
    if not res.get("ok"):
        return res
    data = res["json"].get("tasks", [])[:limit]
    tasks = [{"id": t.get("id"), "name": t.get("name"),
              "status": (t.get("status") or {}).get("status"),
              "due_date": t.get("due_date"),
              "assignees": [a.get("username")
                            for a in (t.get("assignees") or [])],
              "url": t.get("url")}
             for t in data]
    return {"ok": True, "count": len(tasks), "tasks": tasks}


def _clickup_task_create(args: dict) -> dict:
    """Create a ClickUp task in a list.  MEDIUM — mutates remote state."""
    list_id = str(args.get("list_id", "")).strip()
    name = str(args.get("name", "")).strip()
    if not list_id or not name:
        return {"ok": False, "error": "list_id and name required"}
    body: Dict[str, Any] = {"name": name}
    if args.get("description"):
        body["description"] = str(args["description"])
    res = _clickup_request("POST", f"/list/{list_id}/task", body=body)
    if not res.get("ok"):
        return res
    t = res["json"]
    return {"ok": True, "task": {"id": t.get("id"), "name": t.get("name"),
                                 "url": t.get("url")}}


def _clickup_task_update(args: dict) -> dict:
    """Update a ClickUp task. Pass task_id + any of name/description/
    status/priority/due_date.  MEDIUM — mutates remote state."""
    task_id = str(args.get("task_id", "")).strip()
    if not task_id:
        return {"ok": False, "error": "task_id required"}
    allowed = {"name", "description", "status", "priority",
               "due_date", "start_date", "parent", "assignees"}
    body: Dict[str, Any] = {}
    for k, v in args.items():
        if k == "task_id":
            continue
        if k in allowed:
            body[k] = v
    if not body:
        return {"ok": False, "error": "no updatable fields provided"}
    res = _clickup_request("PUT", f"/task/{task_id}", body=body)
    if not res.get("ok"):
        return res
    t = res["json"]
    return {"ok": True, "task": {"id": t.get("id"), "name": t.get("name"),
                                 "status": (t.get("status") or {}).get("status")}}


# ──────────────────────────────────────────────────────────────────────────
# GITHUB PROJECTS v2  (GraphQL — https://api.github.com/graphql)
# ──────────────────────────────────────────────────────────────────────────

_GITHUB_GQL = "https://api.github.com/graphql"


def _github_query(query: str, variables: Optional[dict] = None) -> Dict[str, Any]:
    """Run a GraphQL request against GitHub, return {ok, data} or error."""
    tok = _gh_token()
    if not tok:
        return _missing("GITHUB_TOKEN", "GitHub Projects (or run `gh auth login`)")
    try:
        resp = requests.post(
            _GITHUB_GQL,
            headers={"Authorization": f"Bearer {tok}",
                     "Content-Type": "application/json",
                     "User-Agent": "LeonBot-47industries"},
            json={"query": query, "variables": variables or {}},
            timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code >= 300:
            return _http_error(resp, "GitHub")
        body = resp.json()
        if body.get("errors"):
            return {"ok": False, "error": "GitHub GraphQL error",
                    "detail": body["errors"]}
        return {"ok": True, "data": body.get("data", {})}
    except Exception as e:
        return _err(e)


def _github_owner_kind(owner: str) -> str:
    """Decide whether `owner` is a user or org. Defaults to organization."""
    query = """
    query($login: String!) {
      repositoryOwner(login: $login) { __typename }
    }"""
    res = _github_query(query, {"login": owner})
    if res.get("ok"):
        tn = (res["data"].get("repositoryOwner") or {}).get("__typename")
        if tn == "User":
            return "user"
    return "organization"


def _github_project_list(args: dict) -> dict:
    """List GitHub Projects v2 for an owner (user or org)."""
    owner = str(args.get("owner", "")).strip()
    if not owner:
        return {"ok": False, "error": "owner required"}
    kind = _github_owner_kind(owner)
    query = """
    query($login: String!) {
      %s(login: $login) {
        projectsV2(first: 50) {
          nodes { number title url closed shortDescription }
        }
      }
    }""" % kind
    res = _github_query(query, {"login": owner})
    if not res.get("ok"):
        return res
    holder = res["data"].get(kind) or {}
    nodes = holder.get("projectsV2", {}).get("nodes", [])
    return {"ok": True, "owner": owner, "owner_kind": kind,
            "count": len(nodes), "projects": nodes}


def _github_project_items(args: dict) -> dict:
    """List items in a GitHub Projects v2 board by owner + project number."""
    owner = str(args.get("owner", "")).strip()
    project_number = args.get("project_number")
    if not owner or project_number is None:
        return {"ok": False, "error": "owner and project_number required"}
    try:
        project_number = int(project_number)
    except Exception:
        return {"ok": False, "error": "project_number must be an integer"}
    try:
        limit = int(args.get("limit", 30))
    except Exception:
        limit = 30
    kind = _github_owner_kind(owner)
    query = """
    query($login: String!, $number: Int!, $first: Int!) {
      %s(login: $login) {
        projectV2(number: $number) {
          title url
          items(first: $first) {
            nodes {
              id type
              fieldValues(first: 12) {
                nodes {
                  ... on ProjectV2ItemFieldSingleSelectValue {
                    name field { ... on ProjectV2FieldCommon { name } }
                  }
                  ... on ProjectV2ItemFieldTextValue {
                    text field { ... on ProjectV2FieldCommon { name } }
                  }
                }
              }
              content {
                ... on Issue { title number url state }
                ... on PullRequest { title number url state }
                ... on DraftIssue { title }
              }
            }
          }
        }
      }
    }""" % kind
    res = _github_query(query, {"login": owner, "number": project_number,
                                "first": limit})
    if not res.get("ok"):
        return res
    holder = res["data"].get(kind) or {}
    proj = holder.get("projectV2")
    if not proj:
        return {"ok": False,
                "error": f"project #{project_number} not found for {owner}"}
    items = []
    for node in proj.get("items", {}).get("nodes", []):
        content = node.get("content") or {}
        fields = {}
        for fv in node.get("fieldValues", {}).get("nodes", []):
            fname = (fv.get("field") or {}).get("name")
            if fname:
                fields[fname] = fv.get("name") or fv.get("text")
        items.append({
            "id": node.get("id"),
            "type": node.get("type"),
            "title": content.get("title"),
            "number": content.get("number"),
            "url": content.get("url"),
            "state": content.get("state"),
            "fields": fields,
        })
    return {"ok": True, "project": proj.get("title"),
            "url": proj.get("url"), "count": len(items), "items": items}


# ──────────────────────────────────────────────────────────────────────────
# CROSS-TOOL
# ──────────────────────────────────────────────────────────────────────────

def _configured_backends() -> Dict[str, bool]:
    """Map backend name → whether its credentials are present."""
    return {
        "linear": bool(_linear_headers()),
        "jira": bool(_jira_conf()),
        "trello": bool(_trello_auth()),
        "asana": bool(_asana_headers()),
        "clickup": bool(_clickup_headers()),
        "github": bool(_gh_token()),
    }


def _list_configured(args: dict) -> dict:
    """Report which PM backends have usable credentials."""
    backends = _configured_backends()
    configured = sorted(k for k, v in backends.items() if v)
    missing = sorted(k for k, v in backends.items() if not v)
    return {
        "ok": True,
        "configured": configured,
        "missing": missing,
        "any_configured": bool(configured),
    }


def _unified_my_tasks(args: dict) -> dict:
    """Fan out across every configured PM backend and return a single
    unified list of open tasks assigned to the current user."""
    backends = _configured_backends()
    tasks: List[Dict[str, Any]] = []
    errors: Dict[str, Any] = {}
    sources: List[str] = []

    if backends["linear"]:
        sources.append("linear")
        r = _linear_my_issues({})
        if r.get("ok"):
            for i in r.get("issues", []):
                tasks.append({
                    "source": "linear",
                    "id": i.get("identifier"),
                    "title": i.get("title"),
                    "status": (i.get("state") or {}).get("name"),
                    "url": i.get("url"),
                })
        else:
            errors["linear"] = r.get("error")

    if backends["jira"]:
        sources.append("jira")
        r = _jira_my_issues({})
        if r.get("ok"):
            for i in r.get("issues", []):
                tasks.append({
                    "source": "jira",
                    "id": i.get("key"),
                    "title": i.get("summary"),
                    "status": i.get("status"),
                    "url": None,
                })
        else:
            errors["jira"] = r.get("error")

    if backends["asana"]:
        sources.append("asana")
        r = _asana_my_tasks({})
        if r.get("ok"):
            for t in r.get("tasks", []):
                tasks.append({
                    "source": "asana",
                    "id": t.get("gid"),
                    "title": t.get("name"),
                    "status": "open",
                    "due": t.get("due_on"),
                    "url": None,
                })
        else:
            errors["asana"] = r.get("error")

    # Trello, ClickUp and GitHub Projects have no global "my open tasks"
    # endpoint without a board/list/project id, so they are not fanned out
    # here — call their per-board/list tools directly.

    return {
        "ok": True,
        "sources_queried": sources,
        "count": len(tasks),
        "tasks": tasks,
        "errors": errors,
        "note": "Trello/ClickUp/GitHub need a board/list/project id — "
                "use their per-scope tools.",
    }


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS  — dotted name → callable(dict) -> dict
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Any] = {
    # Linear
    "pm.linear_issues": _linear_issues,
    "pm.linear_issue_get": _linear_issue_get,
    "pm.linear_issue_create": _linear_issue_create,
    "pm.linear_issue_update": _linear_issue_update,
    "pm.linear_teams": _linear_teams,
    "pm.linear_my_issues": _linear_my_issues,
    "pm.linear_cycles": _linear_cycles,
    # Jira
    "pm.jira_search": _jira_search,
    "pm.jira_issue_get": _jira_issue_get,
    "pm.jira_issue_create": _jira_issue_create,
    "pm.jira_issue_transition": _jira_issue_transition,
    "pm.jira_issue_comment": _jira_issue_comment,
    "pm.jira_my_issues": _jira_my_issues,
    "pm.jira_projects": _jira_projects,
    "pm.jira_sprints": _jira_sprints,
    # Trello
    "pm.trello_boards": _trello_boards,
    "pm.trello_lists": _trello_lists,
    "pm.trello_cards": _trello_cards,
    "pm.trello_card_create": _trello_card_create,
    "pm.trello_card_move": _trello_card_move,
    "pm.trello_card_comment": _trello_card_comment,
    # Asana
    "pm.asana_projects": _asana_projects,
    "pm.asana_tasks": _asana_tasks,
    "pm.asana_task_create": _asana_task_create,
    "pm.asana_task_complete": _asana_task_complete,
    "pm.asana_my_tasks": _asana_my_tasks,
    # ClickUp
    "pm.clickup_spaces": _clickup_spaces,
    "pm.clickup_tasks": _clickup_tasks,
    "pm.clickup_task_create": _clickup_task_create,
    "pm.clickup_task_update": _clickup_task_update,
    # GitHub Projects v2
    "pm.github_project_items": _github_project_items,
    "pm.github_project_list": _github_project_list,
    # Cross-tool
    "pm.unified_my_tasks": _unified_my_tasks,
    "pm.list_configured": _list_configured,
}
