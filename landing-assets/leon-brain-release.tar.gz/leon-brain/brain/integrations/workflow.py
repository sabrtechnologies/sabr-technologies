"""Multi-step pipeline / automation builder for Leon.

Workflows are named, persisted sequences of tool calls with conditional
branching, retries, and templated arg passing between steps. Distinct
from `brain/macros.py` — macros are linear, fail-on-first; workflows
support per-step retries, on_failure policies, named result variables,
templating between steps, async + scheduled execution.

Each step shape:
    {
      "name":       "<step-name>",
      "tool":       "<dotted.tool>",
      "args":       {...},
      "on_failure": "abort" | "continue",   # default "abort"
      "retries":    <int>,                  # default 0
      "store_as":   "<var-name>"            # default = step name
    }

Args support `{{$step.field.nested}}` placeholders that get resolved from
prior step results before the call.

Persistence:
  - brain_state/workflows.json             — user-defined workflows
  - brain_state/workflow-runs.jsonl        — run audit (one JSON / line)
  - brain_state/workflow-schedules.json    — cron + one-shot schedules
"""

from __future__ import annotations

import json
import re
import threading
import time
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

_STATE_DIR = Path(__file__).resolve().parent.parent.parent / "brain_state"
_STATE_DIR.mkdir(exist_ok=True)
_WF_FILE        = _STATE_DIR / "workflows.json"
_RUNS_FILE      = _STATE_DIR / "workflow-runs.jsonl"
_SCHED_FILE     = _STATE_DIR / "workflow-schedules.json"

# In-memory run table for status/cancel (run_id → dict)
_RUNS: Dict[str, Dict[str, Any]] = {}
_RUNS_LOCK = threading.Lock()

# Cancel signals for async runs
_CANCEL_FLAGS: Dict[str, threading.Event] = {}


# ── Builtin example workflows ──────────────────────────────────────────

BUILTIN_WORKFLOWS: Dict[str, Dict[str, Any]] = {
    "daily_intel_briefing": {
        "description": "Morning weather + news + calendar in one shot.",
        "steps": [
            {"name": "weather", "tool": "info.weather_now",
             "args": {"location": "Los Angeles"},
             "on_failure": "continue", "retries": 1, "store_as": "weather"},
            {"name": "news", "tool": "info.news_hackernews_top",
             "args": {"limit": 5},
             "on_failure": "continue", "retries": 1, "store_as": "news"},
            {"name": "calendar", "tool": "calendar.today",
             "args": {}, "on_failure": "continue", "store_as": "calendar"},
            {"name": "announce", "tool": "presence.dashboard_event",
             "args": {"kind": "info", "icon": "📰",
                      "message": "Daily briefing ready"},
             "on_failure": "continue"},
        ],
    },
    "code_review_loop": {
        "description": "Diff → lint → format pass over current project.",
        "steps": [
            {"name": "diff", "tool": "git.diff", "args": {},
             "on_failure": "abort", "retries": 0, "store_as": "diff"},
            {"name": "lint", "tool": "git.lint",
             "args": {"target": "{{$diff.path}}"},
             "on_failure": "continue", "retries": 1, "store_as": "lint"},
            {"name": "format", "tool": "git.format",
             "args": {"target": "{{$diff.path}}"},
             "on_failure": "continue", "store_as": "format"},
            {"name": "report", "tool": "presence.dashboard_event",
             "args": {"kind": "success", "icon": "✓",
                      "message": "Code review pass done"},
             "on_failure": "continue"},
        ],
    },
    "evening_wrap": {
        "description": "End-of-day report + journal entry + sleep_mode macro.",
        "steps": [
            {"name": "eod", "tool": "report.end_of_day", "args": {},
             "on_failure": "continue", "retries": 1, "store_as": "eod"},
            {"name": "journal", "tool": "memory.episode_log",
             "args": {"event": "End of day wrap",
                      "tags": ["evening", "wrap"]},
             "on_failure": "continue", "store_as": "journal"},
            {"name": "sleep", "tool": "macro.run",
             "args": {"name": "sleep_mode"},
             "on_failure": "continue", "store_as": "sleep"},
        ],
    },
}


# ── Persistence helpers ────────────────────────────────────────────────

def _load_workflows() -> Dict[str, Dict[str, Any]]:
    if not _WF_FILE.exists():
        return {}
    try:
        return json.loads(_WF_FILE.read_text())
    except Exception:
        return {}


def _save_workflows(data: Dict[str, Dict[str, Any]]) -> None:
    _WF_FILE.write_text(json.dumps(data, indent=2))


def _seed_builtins_if_empty() -> None:
    """First-call auto-register so users see examples in workflow.list()."""
    data = _load_workflows()
    if data:
        return
    for name, spec in BUILTIN_WORKFLOWS.items():
        data[name] = {
            "description": spec.get("description", ""),
            "steps": spec["steps"],
            "builtin": True,
        }
    _save_workflows(data)


def _load_schedules() -> List[Dict[str, Any]]:
    if not _SCHED_FILE.exists():
        return []
    try:
        return json.loads(_SCHED_FILE.read_text())
    except Exception:
        return []


def _save_schedules(data: List[Dict[str, Any]]) -> None:
    _SCHED_FILE.write_text(json.dumps(data, indent=2))


def _append_run(entry: Dict[str, Any]) -> None:
    try:
        with _RUNS_FILE.open("a") as f:
            f.write(json.dumps(entry, default=str) + "\n")
    except OSError:
        pass


# ── Tool resolution (same pattern as macros._resolve_tool_callable) ────

_LOCAL_MODULES = (
    "brain.memory_extras",
    "brain.introspection",
    "brain.tentacle_orchestration",
    "brain.reports",
    "brain.presence",
    "brain.self_improve",
    "brain.integrations.comms",
    "brain.integrations.smart_home",
    "brain.integrations.phone",
    "brain.integrations.research",
    "brain.integrations.productivity",
    "brain.integrations.ai_providers",
    "brain.integrations.life",
)


def _resolve_tool_callable(dotted_name: str) -> Tuple[Optional[Callable], str]:
    """Returns (fn_or_None, kind) where kind is 'local' | 'actuator'."""
    for mod_path in _LOCAL_MODULES:
        try:
            m = __import__(mod_path, fromlist=["EXTRA_TOOLS"])
            et = getattr(m, "EXTRA_TOOLS", {})
            if dotted_name in et:
                return et[dotted_name], "local"
        except Exception:
            continue
    return None, "actuator"


def _invoke(tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
    fn, kind = _resolve_tool_callable(tool)
    try:
        if fn is not None:
            r = fn(args)
        else:
            from brain.actuator_client import call as _act_call
            r = _act_call(tool, args)
        if not isinstance(r, dict):
            r = {"ok": True, "result": r}
        return r
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "trace": traceback.format_exc(limit=3)}


# ── Template resolution ────────────────────────────────────────────────

_PLACEHOLDER_RE = re.compile(r"\{\{\$([a-zA-Z0-9_.\-]+)\}\}")


def _lookup_path(vars_: Dict[str, Any], dotted: str) -> Tuple[bool, Any]:
    """Walk `vars_` by .split('.'). Returns (found, value)."""
    parts = dotted.split(".")
    cur: Any = vars_
    for p in parts:
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return False, None
    return True, cur


def _render(value: Any, vars_: Dict[str, Any],
            warnings: List[str]) -> Any:
    """Recursively render templates in args. Failed lookups → keep literal."""
    if isinstance(value, str):
        # If the entire string is a single placeholder, return the raw value
        m_full = _PLACEHOLDER_RE.fullmatch(value)
        if m_full:
            ok, v = _lookup_path(vars_, m_full.group(1))
            if ok:
                return v
            warnings.append(f"unresolved placeholder: {value}")
            return value

        def _sub(m: re.Match) -> str:
            ok, v = _lookup_path(vars_, m.group(1))
            if ok:
                return str(v)
            warnings.append(f"unresolved placeholder: {m.group(0)}")
            return m.group(0)

        return _PLACEHOLDER_RE.sub(_sub, value)
    if isinstance(value, list):
        return [_render(v, vars_, warnings) for v in value]
    if isinstance(value, dict):
        return {k: _render(v, vars_, warnings) for k, v in value.items()}
    return value


# ── Core run engine ────────────────────────────────────────────────────

def _execute_workflow(spec: Dict[str, Any],
                      context: Dict[str, Any],
                      cancel_event: Optional[threading.Event] = None
                      ) -> Dict[str, Any]:
    """Run a workflow spec. Returns the full run payload."""
    steps = spec.get("steps", []) or []
    name = spec.get("name", "<inline>")
    started = time.time()
    vars_: Dict[str, Any] = {"context": dict(context or {})}
    results: List[Dict[str, Any]] = []
    warnings: List[str] = []
    aborted = False
    canceled = False

    for i, step in enumerate(steps):
        if cancel_event is not None and cancel_event.is_set():
            canceled = True
            break
        step_name = step.get("name") or f"step{i+1}"
        tool = step.get("tool")
        raw_args = step.get("args") or {}
        on_failure = step.get("on_failure", "abort")
        retries = int(step.get("retries", 0) or 0)
        store_as = step.get("store_as") or step_name

        rendered_args = _render(raw_args, vars_, warnings)

        attempt = 0
        last: Dict[str, Any] = {}
        while attempt <= retries:
            if cancel_event is not None and cancel_event.is_set():
                canceled = True
                break
            last = _invoke(tool, rendered_args)
            if last.get("ok"):
                break
            attempt += 1

        if canceled:
            break

        step_record = {
            "step":     i + 1,
            "name":     step_name,
            "tool":     tool,
            "attempts": attempt + (0 if last.get("ok") else 0) + 1
                        if last.get("ok") else attempt,
            "ok":       bool(last.get("ok")),
            "result":   last,
        }
        results.append(step_record)
        vars_[store_as] = last

        if not last.get("ok") and on_failure == "abort":
            aborted = True
            break

    finished = time.time()
    payload = {
        "ok": (not aborted) and (not canceled),
        "workflow": name,
        "ran_steps": len(results),
        "total_steps": len(steps),
        "aborted": aborted,
        "canceled": canceled,
        "duration_s": round(finished - started, 3),
        "results": results,
        "vars": vars_,
        "warnings": warnings,
        "started_at": datetime.utcfromtimestamp(started).isoformat() + "Z",
    }
    return payload


# ── Public CRUD tools ──────────────────────────────────────────────────

def _t_define(args: Dict[str, Any]) -> Dict[str, Any]:
    """Define (or overwrite) a workflow.

    Args: name, steps (list), description (optional)
    """
    name = args.get("name")
    steps = args.get("steps")
    if not name or not isinstance(steps, list):
        return {"ok": False, "error": "name + steps (list) required"}
    for s in steps:
        if not isinstance(s, dict) or "tool" not in s:
            return {"ok": False,
                    "error": "each step needs a dict with 'tool'"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    data[name] = {
        "description": args.get("description", ""),
        "steps": steps,
        "builtin": False,
    }
    _save_workflows(data)
    return {"ok": True, "workflow": name, "step_count": len(steps)}


def _t_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List defined workflows (builtins auto-registered on first call)."""
    _seed_builtins_if_empty()
    data = _load_workflows()
    summary = [{
        "name": k,
        "description": v.get("description", ""),
        "steps": len(v.get("steps", [])),
        "builtin": v.get("builtin", False),
    } for k, v in sorted(data.items())]
    return {"ok": True, "workflows": summary, "count": len(summary)}


def _t_get(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read the full spec for one workflow."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    if name not in data:
        return {"ok": False, "error": f"unknown workflow: {name}"}
    return {"ok": True, "workflow": name, "spec": data[name]}


def _t_update(args: Dict[str, Any]) -> Dict[str, Any]:
    """Patch a workflow's description and/or steps.

    Args: name, description?, steps?
    """
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    if name not in data:
        return {"ok": False, "error": f"unknown workflow: {name}"}
    if "description" in args:
        data[name]["description"] = args["description"]
    if "steps" in args:
        steps = args["steps"]
        if not isinstance(steps, list):
            return {"ok": False, "error": "steps must be a list"}
        data[name]["steps"] = steps
    data[name]["builtin"] = False
    _save_workflows(data)
    return {"ok": True, "workflow": name,
            "step_count": len(data[name]["steps"])}


def _t_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a workflow."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    data = _load_workflows()
    if name not in data:
        return {"ok": False, "error": f"unknown workflow: {name}"}
    del data[name]
    _save_workflows(data)
    return {"ok": True, "deleted": name}


def _t_export(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return JSON-encoded spec for sharing."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    if name not in data:
        return {"ok": False, "error": f"unknown workflow: {name}"}
    spec = {"name": name, **data[name]}
    return {"ok": True, "name": name,
            "json": json.dumps(spec, indent=2)}


def _t_import(args: Dict[str, Any]) -> Dict[str, Any]:
    """Import a JSON workflow spec under a given name.

    Args: name, json_text
    """
    name = args.get("name")
    text = args.get("json_text")
    if not name or not text:
        return {"ok": False, "error": "name + json_text required"}
    try:
        spec = json.loads(text)
    except Exception as e:
        return {"ok": False, "error": f"invalid JSON: {e}"}
    steps = spec.get("steps")
    if not isinstance(steps, list):
        return {"ok": False, "error": "imported spec missing 'steps' list"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    data[name] = {
        "description": spec.get("description", ""),
        "steps": steps,
        "builtin": False,
    }
    _save_workflows(data)
    return {"ok": True, "imported": name, "step_count": len(steps)}


# ── Execution tools ────────────────────────────────────────────────────

def _t_run(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run a workflow synchronously."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    if name not in data:
        return {"ok": False, "error": f"unknown workflow: {name}"}
    spec = {"name": name, **data[name]}
    context = args.get("context") or {}
    run_id = uuid.uuid4().hex[:12]
    cancel_ev = threading.Event()
    _CANCEL_FLAGS[run_id] = cancel_ev
    with _RUNS_LOCK:
        _RUNS[run_id] = {"run_id": run_id, "workflow": name,
                         "status": "running",
                         "started_at": time.time()}
    payload = _execute_workflow(spec, context, cancel_ev)
    payload["run_id"] = run_id
    with _RUNS_LOCK:
        _RUNS[run_id]["status"] = (
            "canceled" if payload["canceled"]
            else ("aborted" if payload["aborted"] else "done")
        )
        _RUNS[run_id]["finished_at"] = time.time()
        _RUNS[run_id]["payload"] = payload
    _append_run({"ts": time.time(), "run_id": run_id, **payload})
    _CANCEL_FLAGS.pop(run_id, None)
    return payload


def _t_dry_run(args: Dict[str, Any]) -> Dict[str, Any]:
    """List steps + tool resolvability, no execution."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    if name not in data:
        return {"ok": False, "error": f"unknown workflow: {name}"}
    steps = data[name].get("steps", [])
    out = []
    all_resolvable = True
    for i, s in enumerate(steps):
        fn, kind = _resolve_tool_callable(s.get("tool", ""))
        resolvable = fn is not None or kind == "actuator"
        if not resolvable:
            all_resolvable = False
        out.append({
            "step":       i + 1,
            "name":       s.get("name", f"step{i+1}"),
            "tool":       s.get("tool"),
            "args_keys":  list((s.get("args") or {}).keys()),
            "on_failure": s.get("on_failure", "abort"),
            "retries":    int(s.get("retries", 0) or 0),
            "store_as":   s.get("store_as", s.get("name", f"step{i+1}")),
            "kind":       kind,
            "resolvable": resolvable,
        })
    return {"ok": True, "workflow": name, "step_count": len(out),
            "all_resolvable": all_resolvable, "steps": out}


def _t_run_async(args: Dict[str, Any]) -> Dict[str, Any]:
    """Kick off a workflow in the background. Returns run_id immediately."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    _seed_builtins_if_empty()
    data = _load_workflows()
    if name not in data:
        return {"ok": False, "error": f"unknown workflow: {name}"}
    spec = {"name": name, **data[name]}
    context = args.get("context") or {}
    run_id = uuid.uuid4().hex[:12]
    cancel_ev = threading.Event()
    _CANCEL_FLAGS[run_id] = cancel_ev
    with _RUNS_LOCK:
        _RUNS[run_id] = {"run_id": run_id, "workflow": name,
                         "status": "running",
                         "started_at": time.time()}

    def _bg() -> None:
        try:
            payload = _execute_workflow(spec, context, cancel_ev)
            payload["run_id"] = run_id
            with _RUNS_LOCK:
                _RUNS[run_id]["status"] = (
                    "canceled" if payload["canceled"]
                    else ("aborted" if payload["aborted"] else "done")
                )
                _RUNS[run_id]["finished_at"] = time.time()
                _RUNS[run_id]["payload"] = payload
            _append_run({"ts": time.time(), "run_id": run_id, **payload})
        except Exception as e:
            with _RUNS_LOCK:
                _RUNS[run_id]["status"] = "error"
                _RUNS[run_id]["error"] = f"{type(e).__name__}: {e}"
                _RUNS[run_id]["finished_at"] = time.time()
        finally:
            _CANCEL_FLAGS.pop(run_id, None)

    threading.Thread(target=_bg, daemon=True,
                     name=f"wf-{name}-{run_id}").start()
    return {"ok": True, "run_id": run_id, "workflow": name,
            "status": "running"}


def _t_run_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read in-memory status for a run_id."""
    rid = args.get("run_id")
    if not rid:
        return {"ok": False, "error": "run_id is required"}
    with _RUNS_LOCK:
        rec = _RUNS.get(rid)
    if rec is None:
        return {"ok": False, "error": f"no such run: {rid}"}
    return {"ok": True, **rec}


def _t_recent_runs(args: Dict[str, Any]) -> Dict[str, Any]:
    """Tail of workflow-runs.jsonl."""
    limit = min(500, max(1, int(args.get("limit", 20))))
    if not _RUNS_FILE.exists():
        return {"ok": True, "runs": [], "count": 0}
    lines = _RUNS_FILE.read_text().strip().split("\n")
    runs = []
    for line in lines[-limit:]:
        try:
            runs.append(json.loads(line))
        except Exception:
            continue
    return {"ok": True, "runs": runs, "count": len(runs)}


def _t_cancel_run(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set the cancel flag on an in-flight async run."""
    rid = args.get("run_id")
    if not rid:
        return {"ok": False, "error": "run_id is required"}
    ev = _CANCEL_FLAGS.get(rid)
    if ev is None:
        return {"ok": False, "error": f"no in-flight run: {rid}"}
    ev.set()
    return {"ok": True, "run_id": rid, "signaled": True}


# ── Scheduling ─────────────────────────────────────────────────────────

def _parse_cron_field(field: str, lo: int, hi: int) -> List[int]:
    """Cron-lite: '*', single int, comma-list, '*/N' step."""
    if field == "*":
        return list(range(lo, hi + 1))
    out: List[int] = []
    for part in field.split(","):
        part = part.strip()
        if part.startswith("*/"):
            try:
                step = int(part[2:])
            except ValueError:
                continue
            out.extend(range(lo, hi + 1, max(1, step)))
        else:
            try:
                v = int(part)
                if lo <= v <= hi:
                    out.append(v)
            except ValueError:
                continue
    return sorted(set(out))


def _cron_matches(expr: str, ts: float) -> bool:
    """`m h dom mon dow`. dow: 0=Mon..6=Sun (python weekday())."""
    parts = expr.split()
    if len(parts) != 5:
        return False
    minute, hour, dom, mon, dow = parts
    dt = datetime.fromtimestamp(ts)
    if dt.minute not in _parse_cron_field(minute, 0, 59):
        return False
    if dt.hour not in _parse_cron_field(hour, 0, 23):
        return False
    if dt.day not in _parse_cron_field(dom, 1, 31):
        return False
    if dt.month not in _parse_cron_field(mon, 1, 12):
        return False
    if dt.weekday() not in _parse_cron_field(dow, 0, 6):
        return False
    return True


_SCHEDULER_STARTED = False
_SCHEDULER_LOCK = threading.Lock()


def _scheduler_loop() -> None:
    """Once-per-minute tick: fire any due one-shot + matching cron schedules."""
    last_minute = -1
    while True:
        try:
            now = time.time()
            dt = datetime.fromtimestamp(now)
            minute_key = dt.replace(second=0, microsecond=0).timestamp()
            if minute_key == last_minute:
                time.sleep(5)
                continue
            last_minute = minute_key

            schedules = _load_schedules()
            remaining: List[Dict[str, Any]] = []
            for s in schedules:
                kind = s.get("kind")
                if kind == "at":
                    when = s.get("when_ts", 0)
                    if when <= now:
                        _t_run_async({"name": s["workflow"],
                                      "context": s.get("context", {})})
                        # one-shot — do not keep
                        continue
                    remaining.append(s)
                elif kind == "cron":
                    if _cron_matches(s.get("cron", ""), now):
                        _t_run_async({"name": s["workflow"],
                                      "context": s.get("context", {})})
                    remaining.append(s)
                else:
                    remaining.append(s)
            if len(remaining) != len(schedules):
                _save_schedules(remaining)
        except Exception:
            pass
        time.sleep(20)


def _ensure_scheduler() -> None:
    global _SCHEDULER_STARTED
    with _SCHEDULER_LOCK:
        if _SCHEDULER_STARTED:
            return
        threading.Thread(target=_scheduler_loop, daemon=True,
                         name="wf-scheduler").start()
        _SCHEDULER_STARTED = True


def _t_schedule_at(args: Dict[str, Any]) -> Dict[str, Any]:
    """Schedule a one-shot run at an ISO timestamp."""
    name = args.get("name")
    when_iso = args.get("when_iso")
    if not name or not when_iso:
        return {"ok": False, "error": "name + when_iso required"}
    try:
        when_dt = datetime.fromisoformat(when_iso.replace("Z", ""))
    except Exception as e:
        return {"ok": False, "error": f"bad ISO timestamp: {e}"}
    when_ts = when_dt.timestamp()
    sid = "sch-" + uuid.uuid4().hex[:10]
    schedules = _load_schedules()
    schedules.append({
        "id": sid, "kind": "at", "workflow": name,
        "when_iso": when_iso, "when_ts": when_ts,
        "context": args.get("context") or {},
        "created_at": time.time(),
    })
    _save_schedules(schedules)
    _ensure_scheduler()
    return {"ok": True, "schedule_id": sid, "fires_at": when_iso}


def _t_schedule_cron(args: Dict[str, Any]) -> Dict[str, Any]:
    """Schedule a recurring run by 5-field cron."""
    name = args.get("name")
    expr = args.get("cron_expr")
    if not name or not expr:
        return {"ok": False, "error": "name + cron_expr required"}
    if len(expr.split()) != 5:
        return {"ok": False,
                "error": "cron_expr must be 5 fields (m h dom mon dow)"}
    sid = "sch-" + uuid.uuid4().hex[:10]
    schedules = _load_schedules()
    schedules.append({
        "id": sid, "kind": "cron", "workflow": name,
        "cron": expr, "context": args.get("context") or {},
        "created_at": time.time(),
    })
    _save_schedules(schedules)
    _ensure_scheduler()
    return {"ok": True, "schedule_id": sid, "cron": expr}


def _t_schedule_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all active schedules."""
    return {"ok": True, "schedules": _load_schedules()}


def _t_schedule_cancel(args: Dict[str, Any]) -> Dict[str, Any]:
    """Remove a schedule by id."""
    sid = args.get("schedule_id")
    if not sid:
        return {"ok": False, "error": "schedule_id required"}
    schedules = _load_schedules()
    new = [s for s in schedules if s.get("id") != sid]
    if len(new) == len(schedules):
        return {"ok": False, "error": f"no such schedule: {sid}"}
    _save_schedules(new)
    return {"ok": True, "deleted": sid}


# ── Module-load: start scheduler so cron + at fire without manual kick ──
try:
    _ensure_scheduler()
except Exception:
    pass


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # CRUD
    "workflow.define":          _t_define,
    "workflow.list":            _t_list,
    "workflow.get":             _t_get,
    "workflow.update":          _t_update,
    "workflow.delete":          _t_delete,
    "workflow.export":          _t_export,
    "workflow.import_json":     _t_import,
    # Execution
    "workflow.run":             _t_run,
    "workflow.dry_run":         _t_dry_run,
    "workflow.run_async":       _t_run_async,
    "workflow.run_status":      _t_run_status,
    "workflow.recent_runs":     _t_recent_runs,
    "workflow.cancel_run":      _t_cancel_run,
    # Schedules
    "workflow.schedule_at":     _t_schedule_at,
    "workflow.schedule_cron":   _t_schedule_cron,
    "workflow.schedule_list":   _t_schedule_list,
    "workflow.schedule_cancel": _t_schedule_cancel,
}
