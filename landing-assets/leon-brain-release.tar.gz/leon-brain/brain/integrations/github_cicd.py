"""github_cicd.py — Leon's deep GitHub + CI/CD integration hub.

Covers:
  - GitHub REST v3 (users, repos, issues, PRs, Actions, gists, notifications)
  - Vercel deployments
  - Netlify sites & deploys
  - Cloudflare Pages & DNS
  - CircleCI v2 pipelines

Each tool returns `{ok: bool, ...}` — nothing in this module raises. Credentials
read from env first, then `~/.openclaw/secrets.json`. GitHub additionally falls
back to `gh auth token` if both are missing.

Credentials read:
  - GITHUB_TOKEN          (fallback: `gh auth token`)
  - VERCEL_TOKEN
  - NETLIFY_TOKEN
  - CLOUDFLARE_API_TOKEN  + CLOUDFLARE_ACCOUNT_ID
  - CIRCLECI_TOKEN

Risk labels (advisory, surfaced via tool docstrings):
  - MEDIUM: state-changing but reversible (create issue, comment, dispatch run)
  - HIGH: destructive / irreversible (delete repo, merge PR)

EXTRA_TOOLS at the bottom maps dotted names (e.g. `gh.repo_list`) to callables
that take a single `dict` argument.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS / HELPERS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 15.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0
_GH_TOKEN_CACHE: Optional[str] = None


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file."""
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _gh_token() -> Optional[str]:
    """Env GITHUB_TOKEN → secrets.json → `gh auth token` shell fallback."""
    global _GH_TOKEN_CACHE
    if _GH_TOKEN_CACHE:
        return _GH_TOKEN_CACHE
    tok = _get_secret("GITHUB_TOKEN")
    if tok:
        _GH_TOKEN_CACHE = tok
        return tok
    # Shell fallback — gh CLI keychain
    gh_bin = shutil.which("gh")
    if not gh_bin:
        return None
    try:
        out = subprocess.run(
            [gh_bin, "auth", "token"],
            capture_output=True, text=True, timeout=5.0,
        )
        if out.returncode == 0:
            tok = (out.stdout or "").strip()
            if tok:
                _GH_TOKEN_CACHE = tok
                return tok
    except Exception:
        pass
    return None


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _wrap_http(resp: requests.Response) -> Dict[str, Any]:
    """Decode a Response into JSON when possible, else return raw text."""
    try:
        return {"status": resp.status_code, "json": resp.json()}
    except Exception:
        return {"status": resp.status_code, "text": (resp.text or "")[:2000]}


# ──────────────────────────────────────────────────────────────────────────
# GITHUB
# ──────────────────────────────────────────────────────────────────────────

_GH_API = "https://api.github.com"


def _gh_headers(extra: Optional[Dict[str, str]] = None) -> Optional[Dict[str, str]]:
    tok = _gh_token()
    if not tok:
        return None
    h = {
        "Authorization": f"Bearer {tok}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "LeonBot (47industries, v1.0)",
    }
    if extra:
        h.update(extra)
    return h


def _gh_request(method: str, path: str, **kwargs) -> Dict[str, Any]:
    """Generic GitHub REST helper. Returns `{ok, status, json|text, ...}`."""
    headers = _gh_headers()
    if not headers:
        return _missing("GITHUB_TOKEN", "GitHub")
    if "headers" in kwargs:
        headers = {**headers, **kwargs.pop("headers")}
    url = path if path.startswith("http") else f"{_GH_API}{path}"
    try:
        r = requests.request(method, url, headers=headers,
                             timeout=_DEFAULT_TIMEOUT, **kwargs)
        wrapped = _wrap_http(r)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **wrapped}
        return {"ok": True, **wrapped}
    except Exception as e:
        return _err(e)


def _gh_user_info(args: dict) -> dict:
    """User info — authenticated user if `username` omitted/None."""
    try:
        username = args.get("username")
        if username:
            return _gh_request("GET", f"/users/{username}")
        return _gh_request("GET", "/user")
    except Exception as e:
        return _err(e)


def _gh_repo_list(args: dict) -> dict:
    """List repos for `user` (or authenticated user if None). limit defaults 30."""
    try:
        user = args.get("user")
        limit = max(1, min(100, int(args.get("limit", 30))))
        if user:
            path = f"/users/{user}/repos"
        else:
            path = "/user/repos"
        res = _gh_request("GET", path, params={"per_page": limit, "sort": "updated"})
        if not res.get("ok"):
            return res
        repos = res.get("json") or []
        compact = [
            {
                "name": r.get("name"),
                "full_name": r.get("full_name"),
                "private": r.get("private"),
                "fork": r.get("fork"),
                "description": r.get("description"),
                "default_branch": r.get("default_branch"),
                "stargazers": r.get("stargazers_count"),
                "updated_at": r.get("updated_at"),
                "url": r.get("html_url"),
            }
            for r in repos if isinstance(r, dict)
        ]
        return {"ok": True, "repos": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _gh_repo_info(args: dict) -> dict:
    """Info for `owner/repo`."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        if not owner or not repo:
            return {"ok": False, "error": "owner and repo required"}
        return _gh_request("GET", f"/repos/{owner}/{repo}")
    except Exception as e:
        return _err(e)


def _gh_repo_create(args: dict) -> dict:
    """MEDIUM risk — create a repo under authenticated user."""
    try:
        name = str(args.get("name", "")).strip()
        if not name:
            return {"ok": False, "error": "name required"}
        body = {
            "name": name,
            "private": bool(args.get("private", True)),
            "auto_init": bool(args.get("auto_init", True)),
        }
        desc = args.get("description")
        if desc:
            body["description"] = str(desc)
        return _gh_request("POST", "/user/repos", json=body)
    except Exception as e:
        return _err(e)


def _gh_repo_delete(args: dict) -> dict:
    """HIGH risk — permanently delete a repo. Requires `delete_repo` scope."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        if not owner or not repo:
            return {"ok": False, "error": "owner and repo required"}
        headers = _gh_headers()
        if not headers:
            return _missing("GITHUB_TOKEN", "GitHub")
        r = requests.delete(f"{_GH_API}/repos/{owner}/{repo}",
                            headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code == 204:
            return {"ok": True, "deleted": True, "repo": f"{owner}/{repo}"}
        return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
    except Exception as e:
        return _err(e)


def _gh_issue_list(args: dict) -> dict:
    """List issues for `owner/repo`. state: open/closed/all."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        state = str(args.get("state", "open")).strip()
        limit = max(1, min(100, int(args.get("limit", 20))))
        if not owner or not repo:
            return {"ok": False, "error": "owner and repo required"}
        res = _gh_request("GET", f"/repos/{owner}/{repo}/issues",
                          params={"state": state, "per_page": limit})
        if not res.get("ok"):
            return res
        items = res.get("json") or []
        compact = [
            {
                "number": i.get("number"),
                "title": i.get("title"),
                "state": i.get("state"),
                "user": (i.get("user") or {}).get("login"),
                "labels": [l.get("name") for l in (i.get("labels") or [])],
                "comments": i.get("comments"),
                "is_pr": "pull_request" in i,
                "created_at": i.get("created_at"),
                "url": i.get("html_url"),
            }
            for i in items if isinstance(i, dict)
        ]
        return {"ok": True, "issues": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _gh_issue_get(args: dict) -> dict:
    """Get a single issue."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        number = args.get("number")
        if not owner or not repo or number in (None, ""):
            return {"ok": False, "error": "owner, repo, number required"}
        return _gh_request("GET", f"/repos/{owner}/{repo}/issues/{int(number)}")
    except Exception as e:
        return _err(e)


def _gh_issue_create(args: dict) -> dict:
    """MEDIUM risk — create an issue."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        title = str(args.get("title", "")).strip()
        if not owner or not repo or not title:
            return {"ok": False, "error": "owner, repo, title required"}
        body: Dict[str, Any] = {"title": title}
        if args.get("body"):
            body["body"] = str(args["body"])
        labels = args.get("labels")
        if labels:
            if isinstance(labels, str):
                labels = [s.strip() for s in labels.split(",") if s.strip()]
            body["labels"] = list(labels)
        return _gh_request("POST", f"/repos/{owner}/{repo}/issues", json=body)
    except Exception as e:
        return _err(e)


def _gh_issue_close(args: dict) -> dict:
    """MEDIUM risk — close an issue."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        number = args.get("number")
        if not owner or not repo or number in (None, ""):
            return {"ok": False, "error": "owner, repo, number required"}
        return _gh_request("PATCH",
                           f"/repos/{owner}/{repo}/issues/{int(number)}",
                           json={"state": "closed"})
    except Exception as e:
        return _err(e)


def _gh_issue_comment(args: dict) -> dict:
    """MEDIUM risk — post a comment on an issue or PR."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        number = args.get("number")
        body = str(args.get("body", "")).strip()
        if not owner or not repo or number in (None, "") or not body:
            return {"ok": False, "error": "owner, repo, number, body required"}
        return _gh_request("POST",
                           f"/repos/{owner}/{repo}/issues/{int(number)}/comments",
                           json={"body": body})
    except Exception as e:
        return _err(e)


def _gh_pr_list(args: dict) -> dict:
    """List PRs. state: open/closed/all."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        state = str(args.get("state", "open")).strip()
        limit = max(1, min(100, int(args.get("limit", 20))))
        if not owner or not repo:
            return {"ok": False, "error": "owner and repo required"}
        res = _gh_request("GET", f"/repos/{owner}/{repo}/pulls",
                          params={"state": state, "per_page": limit})
        if not res.get("ok"):
            return res
        items = res.get("json") or []
        compact = [
            {
                "number": p.get("number"),
                "title": p.get("title"),
                "state": p.get("state"),
                "user": (p.get("user") or {}).get("login"),
                "head": (p.get("head") or {}).get("ref"),
                "base": (p.get("base") or {}).get("ref"),
                "draft": p.get("draft"),
                "merged_at": p.get("merged_at"),
                "created_at": p.get("created_at"),
                "url": p.get("html_url"),
            }
            for p in items if isinstance(p, dict)
        ]
        return {"ok": True, "pulls": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _gh_pr_get(args: dict) -> dict:
    """Get a single PR."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        number = args.get("number")
        if not owner or not repo or number in (None, ""):
            return {"ok": False, "error": "owner, repo, number required"}
        return _gh_request("GET", f"/repos/{owner}/{repo}/pulls/{int(number)}")
    except Exception as e:
        return _err(e)


def _gh_pr_create(args: dict) -> dict:
    """MEDIUM risk — open a pull request."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        title = str(args.get("title", "")).strip()
        head = str(args.get("head", "")).strip()
        base = str(args.get("base", "main")).strip() or "main"
        if not owner or not repo or not title or not head:
            return {"ok": False, "error": "owner, repo, title, head required"}
        body: Dict[str, Any] = {"title": title, "head": head, "base": base}
        if args.get("body"):
            body["body"] = str(args["body"])
        return _gh_request("POST", f"/repos/{owner}/{repo}/pulls", json=body)
    except Exception as e:
        return _err(e)


def _gh_pr_merge(args: dict) -> dict:
    """HIGH risk — merge a PR. merge_method: merge|squash|rebase."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        number = args.get("number")
        method = str(args.get("merge_method", "squash")).strip().lower()
        if method not in ("merge", "squash", "rebase"):
            return {"ok": False, "error": "merge_method must be merge|squash|rebase"}
        if not owner or not repo or number in (None, ""):
            return {"ok": False, "error": "owner, repo, number required"}
        return _gh_request("PUT",
                           f"/repos/{owner}/{repo}/pulls/{int(number)}/merge",
                           json={"merge_method": method})
    except Exception as e:
        return _err(e)


def _gh_pr_review(args: dict) -> dict:
    """MEDIUM risk — submit a review. event: APPROVE|REQUEST_CHANGES|COMMENT."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        number = args.get("number")
        event = str(args.get("event", "APPROVE")).strip().upper()
        if event not in ("APPROVE", "REQUEST_CHANGES", "COMMENT"):
            return {"ok": False,
                    "error": "event must be APPROVE|REQUEST_CHANGES|COMMENT"}
        if not owner or not repo or number in (None, ""):
            return {"ok": False, "error": "owner, repo, number required"}
        body: Dict[str, Any] = {"event": event}
        if args.get("body"):
            body["body"] = str(args["body"])
        return _gh_request("POST",
                           f"/repos/{owner}/{repo}/pulls/{int(number)}/reviews",
                           json=body)
    except Exception as e:
        return _err(e)


def _gh_actions_list_runs(args: dict) -> dict:
    """List recent workflow runs, optionally filtered by branch."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        branch = args.get("branch")
        limit = max(1, min(100, int(args.get("limit", 20))))
        if not owner or not repo:
            return {"ok": False, "error": "owner and repo required"}
        params: Dict[str, Any] = {"per_page": limit}
        if branch:
            params["branch"] = str(branch)
        res = _gh_request("GET", f"/repos/{owner}/{repo}/actions/runs",
                          params=params)
        if not res.get("ok"):
            return res
        runs = (res.get("json") or {}).get("workflow_runs", []) or []
        compact = [
            {
                "id": r.get("id"),
                "name": r.get("name"),
                "workflow_id": r.get("workflow_id"),
                "head_branch": r.get("head_branch"),
                "head_sha": r.get("head_sha"),
                "status": r.get("status"),
                "conclusion": r.get("conclusion"),
                "event": r.get("event"),
                "actor": (r.get("actor") or {}).get("login"),
                "created_at": r.get("created_at"),
                "html_url": r.get("html_url"),
            }
            for r in runs if isinstance(r, dict)
        ]
        return {"ok": True, "runs": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _gh_actions_get_run(args: dict) -> dict:
    """Get a single workflow run."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        run_id = args.get("run_id")
        if not owner or not repo or run_id in (None, ""):
            return {"ok": False, "error": "owner, repo, run_id required"}
        return _gh_request("GET",
                           f"/repos/{owner}/{repo}/actions/runs/{int(run_id)}")
    except Exception as e:
        return _err(e)


def _gh_actions_rerun(args: dict) -> dict:
    """MEDIUM risk — re-run a workflow run."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        run_id = args.get("run_id")
        if not owner or not repo or run_id in (None, ""):
            return {"ok": False, "error": "owner, repo, run_id required"}
        headers = _gh_headers()
        if not headers:
            return _missing("GITHUB_TOKEN", "GitHub")
        r = requests.post(
            f"{_GH_API}/repos/{owner}/{repo}/actions/runs/{int(run_id)}/rerun",
            headers=headers, timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code in (201, 204):
            return {"ok": True, "run_id": int(run_id), "rerun": True}
        return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
    except Exception as e:
        return _err(e)


def _gh_actions_cancel(args: dict) -> dict:
    """MEDIUM risk — cancel an in-flight workflow run."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        run_id = args.get("run_id")
        if not owner or not repo or run_id in (None, ""):
            return {"ok": False, "error": "owner, repo, run_id required"}
        headers = _gh_headers()
        if not headers:
            return _missing("GITHUB_TOKEN", "GitHub")
        r = requests.post(
            f"{_GH_API}/repos/{owner}/{repo}/actions/runs/{int(run_id)}/cancel",
            headers=headers, timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code in (202, 204):
            return {"ok": True, "run_id": int(run_id), "cancelled": True}
        return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
    except Exception as e:
        return _err(e)


def _gh_actions_logs(args: dict) -> dict:
    """Fetch run logs as a zip. Returns `{bytes_len, content_b64, ...}`.

    GitHub responds with a 302 to a signed URL — requests follows redirects
    automatically and returns the zip body.
    """
    try:
        import base64
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        run_id = args.get("run_id")
        if not owner or not repo or run_id in (None, ""):
            return {"ok": False, "error": "owner, repo, run_id required"}
        headers = _gh_headers()
        if not headers:
            return _missing("GITHUB_TOKEN", "GitHub")
        r = requests.get(
            f"{_GH_API}/repos/{owner}/{repo}/actions/runs/{int(run_id)}/logs",
            headers=headers, timeout=_DEFAULT_TIMEOUT, allow_redirects=True,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        body = r.content or b""
        # Cap base64 payload at ~2MB raw to keep tool-call sizes sane.
        cap = 2 * 1024 * 1024
        truncated = len(body) > cap
        payload = body[:cap]
        return {
            "ok": True,
            "run_id": int(run_id),
            "bytes_len": len(body),
            "truncated": truncated,
            "content_type": r.headers.get("Content-Type", "application/zip"),
            "content_b64": base64.b64encode(payload).decode("ascii"),
        }
    except Exception as e:
        return _err(e)


def _gh_actions_list_workflows(args: dict) -> dict:
    """List defined workflows for a repo."""
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        if not owner or not repo:
            return {"ok": False, "error": "owner and repo required"}
        res = _gh_request("GET", f"/repos/{owner}/{repo}/actions/workflows")
        if not res.get("ok"):
            return res
        wfs = (res.get("json") or {}).get("workflows", []) or []
        compact = [
            {
                "id": w.get("id"),
                "name": w.get("name"),
                "path": w.get("path"),
                "state": w.get("state"),
                "created_at": w.get("created_at"),
                "html_url": w.get("html_url"),
            }
            for w in wfs if isinstance(w, dict)
        ]
        return {"ok": True, "workflows": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _gh_actions_dispatch(args: dict) -> dict:
    """MEDIUM risk — manually trigger a workflow_dispatch.

    `workflow_id` may be the numeric id or the filename (e.g. `ci.yml`).
    """
    try:
        owner = str(args.get("owner", "")).strip()
        repo = str(args.get("repo", "")).strip()
        wf = args.get("workflow_id")
        ref = str(args.get("ref", "main")).strip() or "main"
        inputs = args.get("inputs") or {}
        if not owner or not repo or wf in (None, ""):
            return {"ok": False, "error": "owner, repo, workflow_id required"}
        if not isinstance(inputs, dict):
            return {"ok": False, "error": "inputs must be an object/dict"}
        wf_str = str(wf).strip()
        headers = _gh_headers()
        if not headers:
            return _missing("GITHUB_TOKEN", "GitHub")
        body: Dict[str, Any] = {"ref": ref}
        if inputs:
            body["inputs"] = inputs
        r = requests.post(
            f"{_GH_API}/repos/{owner}/{repo}/actions/workflows/{wf_str}/dispatches",
            headers=headers, json=body, timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code == 204:
            return {"ok": True, "dispatched": True, "workflow_id": wf_str, "ref": ref}
        return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
    except Exception as e:
        return _err(e)


def _gh_gist_create(args: dict) -> dict:
    """MEDIUM risk — create a gist."""
    try:
        content = args.get("content")
        if content is None or content == "":
            return {"ok": False, "error": "content required"}
        filename = str(args.get("filename", "gist.txt")).strip() or "gist.txt"
        public = bool(args.get("public", False))
        body: Dict[str, Any] = {
            "files": {filename: {"content": str(content)}},
            "public": public,
        }
        desc = args.get("description")
        if desc:
            body["description"] = str(desc)
        return _gh_request("POST", "/gists", json=body)
    except Exception as e:
        return _err(e)


def _gh_gist_list(args: dict) -> dict:
    """List gists for the authenticated user."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
        res = _gh_request("GET", "/gists", params={"per_page": limit})
        if not res.get("ok"):
            return res
        items = res.get("json") or []
        compact = [
            {
                "id": g.get("id"),
                "description": g.get("description"),
                "public": g.get("public"),
                "files": list((g.get("files") or {}).keys()),
                "created_at": g.get("created_at"),
                "url": g.get("html_url"),
            }
            for g in items if isinstance(g, dict)
        ]
        return {"ok": True, "gists": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _gh_notifications_list(args: dict) -> dict:
    """List notifications for the authenticated user."""
    try:
        unread = bool(args.get("unread", True))
        limit = max(1, min(50, int(args.get("limit", 30))))
        res = _gh_request("GET", "/notifications",
                          params={"all": str(not unread).lower(),
                                  "per_page": limit})
        if not res.get("ok"):
            return res
        items = res.get("json") or []
        compact = [
            {
                "id": n.get("id"),
                "unread": n.get("unread"),
                "reason": n.get("reason"),
                "title": (n.get("subject") or {}).get("title"),
                "type": (n.get("subject") or {}).get("type"),
                "url": (n.get("subject") or {}).get("url"),
                "repo": (n.get("repository") or {}).get("full_name"),
                "updated_at": n.get("updated_at"),
            }
            for n in items if isinstance(n, dict)
        ]
        return {"ok": True, "notifications": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# VERCEL
# ──────────────────────────────────────────────────────────────────────────

_VERCEL_API = "https://api.vercel.com"


def _vercel_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("VERCEL_TOKEN")
    if not tok:
        return None
    return {
        "Authorization": f"Bearer {tok}",
        "Content-Type": "application/json",
    }


def _vercel_deployments_list(args: dict) -> dict:
    """List recent deployments, optionally filtered by project name."""
    try:
        project = args.get("project_name")
        limit = max(1, min(100, int(args.get("limit", 20))))
        headers = _vercel_headers()
        if not headers:
            return _missing("VERCEL_TOKEN", "Vercel")
        params: Dict[str, Any] = {"limit": limit}
        if project:
            params["app"] = str(project)
        r = requests.get(f"{_VERCEL_API}/v6/deployments",
                         headers=headers, params=params,
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json() or {}
        deps = data.get("deployments", []) or []
        compact = [
            {
                "uid": d.get("uid"),
                "name": d.get("name"),
                "url": d.get("url"),
                "state": d.get("state"),
                "ready_state": d.get("readyState"),
                "type": d.get("type"),
                "target": d.get("target"),
                "created": d.get("created"),
                "creator": (d.get("creator") or {}).get("username"),
            }
            for d in deps if isinstance(d, dict)
        ]
        return {"ok": True, "deployments": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _vercel_deployment_status(args: dict) -> dict:
    """Status for a single deployment id."""
    try:
        dep_id = str(args.get("deployment_id", "")).strip()
        if not dep_id:
            return {"ok": False, "error": "deployment_id required"}
        headers = _vercel_headers()
        if not headers:
            return _missing("VERCEL_TOKEN", "Vercel")
        r = requests.get(f"{_VERCEL_API}/v13/deployments/{dep_id}",
                         headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        d = r.json() or {}
        return {
            "ok": True,
            "id": d.get("id") or d.get("uid"),
            "name": d.get("name"),
            "url": d.get("url"),
            "state": d.get("readyState") or d.get("state"),
            "target": d.get("target"),
            "created": d.get("createdAt") or d.get("created"),
            "ready": d.get("ready"),
            "error": d.get("errorMessage"),
            "raw": d,
        }
    except Exception as e:
        return _err(e)


def _vercel_deployment_logs(args: dict) -> dict:
    """Build/runtime logs for a deployment (best-effort across API versions)."""
    try:
        dep_id = str(args.get("deployment_id", "")).strip()
        limit = max(1, min(1000, int(args.get("limit", 200))))
        if not dep_id:
            return {"ok": False, "error": "deployment_id required"}
        headers = _vercel_headers()
        if not headers:
            return _missing("VERCEL_TOKEN", "Vercel")
        r = requests.get(
            f"{_VERCEL_API}/v2/deployments/{dep_id}/events",
            headers=headers, params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        # Response is usually a JSON array of event objects.
        try:
            events = r.json()
        except Exception:
            events = []
        if not isinstance(events, list):
            events = []
        compact = [
            {
                "type": e.get("type"),
                "created": e.get("created") or e.get("date"),
                "text": e.get("text") or e.get("payload", {}).get("text", ""),
                "level": (e.get("payload") or {}).get("level"),
            }
            for e in events if isinstance(e, dict)
        ]
        return {"ok": True, "events": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# NETLIFY
# ──────────────────────────────────────────────────────────────────────────

_NETLIFY_API = "https://api.netlify.com/api/v1"


def _netlify_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("NETLIFY_TOKEN")
    if not tok:
        return None
    return {
        "Authorization": f"Bearer {tok}",
        "Content-Type": "application/json",
    }


def _netlify_sites_list(args: dict) -> dict:
    """List Netlify sites for the authenticated account."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
        headers = _netlify_headers()
        if not headers:
            return _missing("NETLIFY_TOKEN", "Netlify")
        r = requests.get(f"{_NETLIFY_API}/sites",
                         headers=headers, params={"per_page": limit},
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        sites = r.json() or []
        if not isinstance(sites, list):
            sites = []
        compact = [
            {
                "id": s.get("id"),
                "name": s.get("name"),
                "url": s.get("url"),
                "ssl_url": s.get("ssl_url"),
                "admin_url": s.get("admin_url"),
                "custom_domain": s.get("custom_domain"),
                "state": s.get("state"),
                "updated_at": s.get("updated_at"),
            }
            for s in sites if isinstance(s, dict)
        ]
        return {"ok": True, "sites": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _netlify_deploys_list(args: dict) -> dict:
    """List deploys for a Netlify site id."""
    try:
        site_id = str(args.get("site_id", "")).strip()
        limit = max(1, min(100, int(args.get("limit", 20))))
        if not site_id:
            return {"ok": False, "error": "site_id required"}
        headers = _netlify_headers()
        if not headers:
            return _missing("NETLIFY_TOKEN", "Netlify")
        r = requests.get(f"{_NETLIFY_API}/sites/{site_id}/deploys",
                         headers=headers, params={"per_page": limit},
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        deps = r.json() or []
        if not isinstance(deps, list):
            deps = []
        compact = [
            {
                "id": d.get("id"),
                "state": d.get("state"),
                "name": d.get("name"),
                "url": d.get("deploy_ssl_url") or d.get("deploy_url"),
                "branch": d.get("branch"),
                "commit_ref": d.get("commit_ref"),
                "commit_url": d.get("commit_url"),
                "title": d.get("title"),
                "error_message": d.get("error_message"),
                "created_at": d.get("created_at"),
            }
            for d in deps if isinstance(d, dict)
        ]
        return {"ok": True, "deploys": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _netlify_deploy_status(args: dict) -> dict:
    """Status for a single Netlify deploy id."""
    try:
        deploy_id = str(args.get("deploy_id", "")).strip()
        if not deploy_id:
            return {"ok": False, "error": "deploy_id required"}
        headers = _netlify_headers()
        if not headers:
            return _missing("NETLIFY_TOKEN", "Netlify")
        r = requests.get(f"{_NETLIFY_API}/deploys/{deploy_id}",
                         headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        d = r.json() or {}
        return {
            "ok": True,
            "id": d.get("id"),
            "state": d.get("state"),
            "site_id": d.get("site_id"),
            "url": d.get("deploy_ssl_url") or d.get("deploy_url"),
            "branch": d.get("branch"),
            "commit_ref": d.get("commit_ref"),
            "error_message": d.get("error_message"),
            "created_at": d.get("created_at"),
            "updated_at": d.get("updated_at"),
            "raw": d,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CLOUDFLARE
# ──────────────────────────────────────────────────────────────────────────

_CF_API = "https://api.cloudflare.com/client/v4"


def _cf_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("CLOUDFLARE_API_TOKEN")
    if not tok:
        return None
    return {
        "Authorization": f"Bearer {tok}",
        "Content-Type": "application/json",
    }


def _cf_account_id() -> Optional[str]:
    return _get_secret("CLOUDFLARE_ACCOUNT_ID")


def _cf_pages_list_projects(args: dict) -> dict:
    """List Cloudflare Pages projects for the configured account."""
    try:
        headers = _cf_headers()
        if not headers:
            return _missing("CLOUDFLARE_API_TOKEN", "Cloudflare")
        account = _cf_account_id()
        if not account:
            return _missing("CLOUDFLARE_ACCOUNT_ID", "Cloudflare")
        r = requests.get(
            f"{_CF_API}/accounts/{account}/pages/projects",
            headers=headers, timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        payload = r.json() or {}
        if not payload.get("success", False):
            return {"ok": False, "error": "cloudflare reported failure",
                    "raw": payload}
        results = payload.get("result", []) or []
        compact = [
            {
                "name": p.get("name"),
                "subdomain": p.get("subdomain"),
                "domains": p.get("domains"),
                "production_branch": p.get("production_branch"),
                "created_on": p.get("created_on"),
                "latest_deployment_id": (p.get("latest_deployment") or {}).get("id"),
                "latest_deployment_url": (p.get("latest_deployment") or {}).get("url"),
            }
            for p in results if isinstance(p, dict)
        ]
        return {"ok": True, "projects": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _cf_pages_deploys(args: dict) -> dict:
    """List deployments for a Cloudflare Pages project."""
    try:
        project = str(args.get("project_name", "")).strip()
        if not project:
            return {"ok": False, "error": "project_name required"}
        headers = _cf_headers()
        if not headers:
            return _missing("CLOUDFLARE_API_TOKEN", "Cloudflare")
        account = _cf_account_id()
        if not account:
            return _missing("CLOUDFLARE_ACCOUNT_ID", "Cloudflare")
        r = requests.get(
            f"{_CF_API}/accounts/{account}/pages/projects/{project}/deployments",
            headers=headers, timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        payload = r.json() or {}
        if not payload.get("success", False):
            return {"ok": False, "error": "cloudflare reported failure",
                    "raw": payload}
        results = payload.get("result", []) or []
        compact = [
            {
                "id": d.get("id"),
                "url": d.get("url"),
                "environment": d.get("environment"),
                "created_on": d.get("created_on"),
                "modified_on": d.get("modified_on"),
                "latest_stage": (d.get("latest_stage") or {}).get("name"),
                "status": (d.get("latest_stage") or {}).get("status"),
                "branch": (d.get("deployment_trigger") or {})
                            .get("metadata", {}).get("branch"),
                "commit_hash": (d.get("deployment_trigger") or {})
                                .get("metadata", {}).get("commit_hash"),
            }
            for d in results if isinstance(d, dict)
        ]
        return {"ok": True, "deployments": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _cf_dns_records(args: dict) -> dict:
    """List DNS records for a zone id."""
    try:
        zone_id = str(args.get("zone_id", "")).strip()
        if not zone_id:
            return {"ok": False, "error": "zone_id required"}
        headers = _cf_headers()
        if not headers:
            return _missing("CLOUDFLARE_API_TOKEN", "Cloudflare")
        r = requests.get(
            f"{_CF_API}/zones/{zone_id}/dns_records",
            headers=headers, params={"per_page": 100},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        payload = r.json() or {}
        if not payload.get("success", False):
            return {"ok": False, "error": "cloudflare reported failure",
                    "raw": payload}
        results = payload.get("result", []) or []
        compact = [
            {
                "id": d.get("id"),
                "type": d.get("type"),
                "name": d.get("name"),
                "content": d.get("content"),
                "ttl": d.get("ttl"),
                "proxied": d.get("proxied"),
                "created_on": d.get("created_on"),
                "modified_on": d.get("modified_on"),
            }
            for d in results if isinstance(d, dict)
        ]
        return {"ok": True, "records": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CIRCLECI
# ──────────────────────────────────────────────────────────────────────────

_CCI_API = "https://circleci.com/api/v2"


def _cci_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("CIRCLECI_TOKEN")
    if not tok:
        return None
    return {
        "Circle-Token": tok,
        "Accept": "application/json",
    }


def _cci_pipelines_list(args: dict) -> dict:
    """List pipelines for a project slug like `gh/<owner>/<repo>`."""
    try:
        slug = str(args.get("slug", "")).strip()
        limit = max(1, min(100, int(args.get("limit", 20))))
        if not slug:
            return {"ok": False, "error": "slug required (e.g. gh/owner/repo)"}
        headers = _cci_headers()
        if not headers:
            return _missing("CIRCLECI_TOKEN", "CircleCI")
        r = requests.get(
            f"{_CCI_API}/project/{slug}/pipeline",
            headers=headers, timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        payload = r.json() or {}
        items = (payload.get("items") or [])[:limit]
        compact = [
            {
                "id": p.get("id"),
                "number": p.get("number"),
                "state": p.get("state"),
                "created_at": p.get("created_at"),
                "updated_at": p.get("updated_at"),
                "branch": (p.get("vcs") or {}).get("branch"),
                "revision": (p.get("vcs") or {}).get("revision"),
                "trigger_type": (p.get("trigger") or {}).get("type"),
                "actor": ((p.get("trigger") or {}).get("actor") or {}).get("login"),
            }
            for p in items if isinstance(p, dict)
        ]
        return {"ok": True, "pipelines": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _cci_pipeline_status(args: dict) -> dict:
    """Status (+ workflows) for a single pipeline id."""
    try:
        pid = str(args.get("pipeline_id", "")).strip()
        if not pid:
            return {"ok": False, "error": "pipeline_id required"}
        headers = _cci_headers()
        if not headers:
            return _missing("CIRCLECI_TOKEN", "CircleCI")
        r = requests.get(f"{_CCI_API}/pipeline/{pid}",
                         headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        pipeline = r.json() or {}
        # Also fetch workflows for richer status
        wf_r = requests.get(f"{_CCI_API}/pipeline/{pid}/workflow",
                            headers=headers, timeout=_DEFAULT_TIMEOUT)
        workflows: List[Dict[str, Any]] = []
        if wf_r.status_code < 400:
            try:
                wf_items = (wf_r.json() or {}).get("items") or []
                workflows = [
                    {
                        "id": w.get("id"),
                        "name": w.get("name"),
                        "status": w.get("status"),
                        "created_at": w.get("created_at"),
                        "stopped_at": w.get("stopped_at"),
                    }
                    for w in wf_items if isinstance(w, dict)
                ]
            except Exception:
                workflows = []
        return {
            "ok": True,
            "id": pipeline.get("id"),
            "number": pipeline.get("number"),
            "state": pipeline.get("state"),
            "created_at": pipeline.get("created_at"),
            "updated_at": pipeline.get("updated_at"),
            "branch": (pipeline.get("vcs") or {}).get("branch"),
            "revision": (pipeline.get("vcs") or {}).get("revision"),
            "workflows": workflows,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # GitHub
    "gh.user_info": _gh_user_info,
    "gh.repo_list": _gh_repo_list,
    "gh.repo_info": _gh_repo_info,
    "gh.repo_create": _gh_repo_create,
    "gh.repo_delete": _gh_repo_delete,
    "gh.issue_list": _gh_issue_list,
    "gh.issue_get": _gh_issue_get,
    "gh.issue_create": _gh_issue_create,
    "gh.issue_close": _gh_issue_close,
    "gh.issue_comment": _gh_issue_comment,
    "gh.pr_list": _gh_pr_list,
    "gh.pr_get": _gh_pr_get,
    "gh.pr_create": _gh_pr_create,
    "gh.pr_merge": _gh_pr_merge,
    "gh.pr_review": _gh_pr_review,
    "gh.actions_list_runs": _gh_actions_list_runs,
    "gh.actions_get_run": _gh_actions_get_run,
    "gh.actions_rerun": _gh_actions_rerun,
    "gh.actions_cancel": _gh_actions_cancel,
    "gh.actions_logs": _gh_actions_logs,
    "gh.actions_list_workflows": _gh_actions_list_workflows,
    "gh.actions_dispatch": _gh_actions_dispatch,
    "gh.gist_create": _gh_gist_create,
    "gh.gist_list": _gh_gist_list,
    "gh.notifications_list": _gh_notifications_list,
    # Vercel
    "vercel.deployments_list": _vercel_deployments_list,
    "vercel.deployment_status": _vercel_deployment_status,
    "vercel.deployment_logs": _vercel_deployment_logs,
    # Netlify
    "netlify.sites_list": _netlify_sites_list,
    "netlify.deploys_list": _netlify_deploys_list,
    "netlify.deploy_status": _netlify_deploy_status,
    # Cloudflare
    "cloudflare.pages_list_projects": _cf_pages_list_projects,
    "cloudflare.pages_deploys": _cf_pages_deploys,
    "cloudflare.dns_records": _cf_dns_records,
    # CircleCI
    "circleci.pipelines_list": _cci_pipelines_list,
    "circleci.pipeline_status": _cci_pipeline_status,
}
