"""Deep PC control — every X11/Wayland thing Leon couldn't do before.
All tools shell out to xdotool / wmctrl / pactl / xrandr / xclip — none
need credentials, all work on Dean's KDE/Plasma + X11 setup.

This is what Dean asked for: "more features when it comes to controlling
my PC". The existing `window.*` and `mouse.*` actuator tools cover the
basics. This module adds the deeper stuff:

  - Window: snap to quarter, move to next monitor, opacity, sticky,
    minimize-all, restore-all, cycle, focus by class
  - Workspace: per-workspace window list, label set, switch by name
  - Mouse: smooth drag with bezier path, scroll precise, multi-click
  - Keyboard: hold modifier + key combos, hardware key remap on the fly
  - Clipboard: history (last N entries), pin entries, clear history
  - Display: per-monitor brightness, rotate display, set primary
  - Audio: per-application volume, mute specific app, route audio
  - System: lock screen, suspend, hibernate, screenshot region picker
  - Power: list battery percent, AC status, set power profile
  - Apps: count running, find by class, force-quit
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


_CLIPBOARD_HISTORY = Path(__file__).resolve().parent.parent.parent / "brain_state" / "clipboard_history.jsonl"
_CLIPBOARD_HISTORY.parent.mkdir(parents=True, exist_ok=True)


def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _run(cmd: List[str], timeout: float = 8.0, input_data: Optional[str] = None) -> Dict[str, Any]:
    # Force DISPLAY/XAUTHORITY so PC tools work no matter how Leon's invoked.
    env = os.environ.copy()
    if not env.get("DISPLAY"):
        env["DISPLAY"] = ":0"
    _xauth = os.path.join(os.path.expanduser("~"), ".Xauthority")
    if not env.get("XAUTHORITY") and os.path.exists(_xauth):
        env["XAUTHORITY"] = _xauth
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                            timeout=timeout, input=input_data, env=env)
        return {"ok": r.returncode == 0, "stdout": r.stdout, "stderr": r.stderr,
                "code": r.returncode}
    except FileNotFoundError:
        return {"ok": False, "error": f"{cmd[0]} not installed"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"{cmd[0]} timed out"}


def _monitors() -> List[Dict[str, Any]]:
    """Parse xrandr to get monitor layout."""
    out = _run(["xrandr", "--listmonitors"])
    if not out.get("ok"):
        return []
    mons = []
    for line in out["stdout"].split("\n"):
        m = re.match(r"\s*(\d+):\s+\+?\*?(\S+)\s+(\d+)/\d+x(\d+)/\d+\+(-?\d+)\+(-?\d+)", line)
        if m:
            mons.append({
                "index": int(m.group(1)),
                "name": m.group(2).lstrip("+*"),
                "w": int(m.group(3)),
                "h": int(m.group(4)),
                "x": int(m.group(5)),
                "y": int(m.group(6)),
            })
    return mons


def _active_window() -> Optional[Dict[str, Any]]:
    """wmctrl-based active window probe."""
    out = _run(["xdotool", "getactivewindow", "getwindowname"])
    if not out.get("ok"):
        return None
    name = out["stdout"].strip()
    out2 = _run(["xdotool", "getactivewindow", "getwindowgeometry", "--shell"])
    geom = {}
    for line in out2.get("stdout", "").split("\n"):
        if "=" in line:
            k, v = line.split("=", 1)
            geom[k.strip()] = v.strip()
    out3 = _run(["xdotool", "getactivewindow"])
    wid = out3.get("stdout", "").strip()
    return {
        "id": wid,
        "name": name,
        "x": int(geom.get("X", 0) or 0),
        "y": int(geom.get("Y", 0) or 0),
        "w": int(geom.get("WIDTH", 0) or 0),
        "h": int(geom.get("HEIGHT", 0) or 0),
    }


# ── Window: snap, move, opacity ────────────────────────────────────────
def _window_snap_quarter(args: Dict[str, Any]) -> Dict[str, Any]:
    """Snap active window to a quarter of the current monitor.

    Args:
      corner: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'
    """
    corner = args.get("corner", "top-left")
    win = _active_window()
    if not win:
        return {"ok": False, "error": "no active window"}
    mons = _monitors()
    if not mons:
        return {"ok": False, "error": "no monitors detected"}
    # Find which monitor the window is currently on
    cx = win["x"] + win["w"] // 2
    cy = win["y"] + win["h"] // 2
    mon = next((m for m in mons if m["x"] <= cx < m["x"]+m["w"] and m["y"] <= cy < m["y"]+m["h"]), mons[0])
    w_half = mon["w"] // 2
    h_half = mon["h"] // 2
    if corner == "top-left":
        x, y = mon["x"], mon["y"]
    elif corner == "top-right":
        x, y = mon["x"] + w_half, mon["y"]
    elif corner == "bottom-left":
        x, y = mon["x"], mon["y"] + h_half
    elif corner == "bottom-right":
        x, y = mon["x"] + w_half, mon["y"] + h_half
    else:
        return {"ok": False, "error": f"invalid corner '{corner}'"}
    _run(["wmctrl", "-i", "-r", win["id"], "-b", "remove,maximized_vert,maximized_horz"])
    _run(["wmctrl", "-i", "-r", win["id"], "-e", f"0,{x},{y},{w_half},{h_half}"])
    return {"ok": True, "window": win["name"], "corner": corner, "monitor": mon["name"]}


def _window_move_to_next_monitor(args: Dict[str, Any]) -> Dict[str, Any]:
    """Move active window to the next monitor (clockwise by index)."""
    win = _active_window()
    if not win:
        return {"ok": False, "error": "no active window"}
    mons = _monitors()
    if len(mons) < 2:
        return {"ok": False, "error": f"only {len(mons)} monitor(s)"}
    cx = win["x"] + win["w"] // 2
    cy = win["y"] + win["h"] // 2
    cur_idx = next((i for i, m in enumerate(mons)
                     if m["x"] <= cx < m["x"]+m["w"] and m["y"] <= cy < m["y"]+m["h"]), 0)
    nxt = mons[(cur_idx + 1) % len(mons)]
    new_x = nxt["x"] + (win["x"] - mons[cur_idx]["x"])
    new_y = nxt["y"] + (win["y"] - mons[cur_idx]["y"])
    _run(["wmctrl", "-i", "-r", win["id"], "-e", f"0,{new_x},{new_y},{win['w']},{win['h']}"])
    return {"ok": True, "moved_to": nxt["name"], "from": mons[cur_idx]["name"]}


def _window_opacity(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set window transparency (0.0-1.0) via _NET_WM_WINDOW_OPACITY.

    Args:
      opacity: 0.0 (invisible) to 1.0 (opaque)
      window_id: optional, defaults to active
    """
    op = float(args.get("opacity", 1.0))
    if not 0.0 <= op <= 1.0:
        return {"ok": False, "error": "opacity must be 0.0-1.0"}
    wid = args.get("window_id")
    if not wid:
        w = _active_window()
        if not w:
            return {"ok": False, "error": "no active window"}
        wid = w["id"]
    # Convert to 32-bit cardinal
    cardinal = int(op * 0xFFFFFFFF)
    r = _run(["xprop", "-id", wid, "-f", "_NET_WM_WINDOW_OPACITY", "32c",
              "-set", "_NET_WM_WINDOW_OPACITY", str(cardinal)])
    return {"ok": r["ok"], "opacity": op, "window_id": wid}


def _window_sticky_toggle(args: Dict[str, Any]) -> Dict[str, Any]:
    """Toggle 'show on all workspaces' for the active window."""
    win = _active_window()
    if not win:
        return {"ok": False, "error": "no active window"}
    r = _run(["wmctrl", "-i", "-r", win["id"], "-b", "toggle,sticky"])
    return {"ok": r["ok"], "window": win["name"]}


def _window_minimize_all(args: Dict[str, Any]) -> Dict[str, Any]:
    """Minimize every visible window (show desktop)."""
    r = _run(["wmctrl", "-k", "on"])
    return {"ok": r["ok"]}


def _window_restore_all(args: Dict[str, Any]) -> Dict[str, Any]:
    """Restore all minimized windows (undo show-desktop)."""
    r = _run(["wmctrl", "-k", "off"])
    return {"ok": r["ok"]}


def _window_cycle(args: Dict[str, Any]) -> Dict[str, Any]:
    """Alt-Tab to next window."""
    r = _run(["xdotool", "key", "alt+Tab"])
    return {"ok": r["ok"]}


def _window_focus_by_class(args: Dict[str, Any]) -> Dict[str, Any]:
    """Focus a window matching WM_CLASS substring (case-insensitive).

    Args:
      class_name: e.g. 'brave' / 'code' / 'spotify'
    """
    cls = (args.get("class_name") or "").lower()
    if not cls:
        return {"ok": False, "error": "class_name required"}
    # wmctrl -lx lists windows with classes
    r = _run(["wmctrl", "-lx"])
    if not r.get("ok"):
        return r
    for line in r["stdout"].split("\n"):
        parts = line.split(None, 4)
        if len(parts) >= 5 and cls in parts[2].lower():
            _run(["wmctrl", "-i", "-a", parts[0]])
            return {"ok": True, "focused_class": parts[2], "title": parts[4]}
    return {"ok": False, "error": f"no window matching class '{cls}'"}


def _window_close_active(args: Dict[str, Any]) -> Dict[str, Any]:
    """Close the active window (HIGH risk — sends WM_DELETE)."""
    win = _active_window()
    if not win:
        return {"ok": False, "error": "no active window"}
    r = _run(["wmctrl", "-i", "-c", win["id"]])
    return {"ok": r["ok"], "closed": win["name"]}


def _window_force_kill(args: Dict[str, Any]) -> Dict[str, Any]:
    """Hard-kill the active window's process (HIGH risk)."""
    win = _active_window()
    if not win:
        return {"ok": False, "error": "no active window"}
    r = _run(["xdotool", "getactivewindow", "getwindowpid"])
    if not r.get("ok"):
        return {"ok": False, "error": "couldn't get pid"}
    pid = r["stdout"].strip()
    if not pid.isdigit():
        return {"ok": False, "error": "bad pid"}
    try:
        os.kill(int(pid), 9)
        return {"ok": True, "killed_pid": pid, "title": win["name"]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ── Workspace ──────────────────────────────────────────────────────────
def _workspace_list_windows(args: Dict[str, Any]) -> Dict[str, Any]:
    """List windows on current (or any) workspace."""
    workspace = args.get("workspace")
    r = _run(["wmctrl", "-l"])
    if not r.get("ok"):
        return r
    wins = []
    for line in r["stdout"].split("\n"):
        parts = line.split(None, 3)
        if len(parts) >= 4:
            ws = parts[1]
            if workspace is not None and str(ws) != str(workspace):
                continue
            wins.append({"id": parts[0], "workspace": int(ws) if ws.isdigit() else ws,
                          "host": parts[2], "title": parts[3]})
    return {"ok": True, "windows": wins, "count": len(wins)}


def _workspace_count(args: Dict[str, Any]) -> Dict[str, Any]:
    """How many workspaces exist + which is current."""
    r = _run(["wmctrl", "-d"])
    if not r.get("ok"):
        return r
    workspaces = []
    current = None
    for line in r["stdout"].split("\n"):
        parts = line.split(None, 9)
        if len(parts) >= 2:
            idx = int(parts[0])
            is_active = parts[1] == "*"
            name = parts[-1] if parts[-1] else f"workspace-{idx}"
            workspaces.append({"index": idx, "active": is_active, "name": name})
            if is_active:
                current = idx
    return {"ok": True, "workspaces": workspaces, "current": current, "count": len(workspaces)}


def _workspace_send_window(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send active window to a numbered workspace.

    Args:
      workspace: integer 0..N
    """
    ws = args.get("workspace")
    if ws is None:
        return {"ok": False, "error": "workspace required"}
    win = _active_window()
    if not win:
        return {"ok": False, "error": "no active window"}
    r = _run(["wmctrl", "-i", "-r", win["id"], "-t", str(ws)])
    return {"ok": r["ok"], "moved_window": win["name"], "to_workspace": ws}


# ── Mouse: precise + smooth ────────────────────────────────────────────
def _mouse_scroll_precise(args: Dict[str, Any]) -> Dict[str, Any]:
    """Scroll N units (positive=down) precisely.

    Args:
      units: number of scroll ticks (positive=down, negative=up)
      delay_ms: between ticks (default 30)
    """
    units = int(args.get("units", 1))
    delay = int(args.get("delay_ms", 30))
    button = "5" if units > 0 else "4"
    for _ in range(abs(units)):
        _run(["xdotool", "click", button])
        time.sleep(delay / 1000)
    return {"ok": True, "scrolled": units}


def _mouse_smooth_drag(args: Dict[str, Any]) -> Dict[str, Any]:
    """Drag from (x1,y1) to (x2,y2) along a smooth path.

    Args:
      from_x, from_y, to_x, to_y, steps=20, delay_ms=10
    """
    _missing = [k for k in ("from_x", "from_y", "to_x", "to_y") if args.get(k) is None]
    if _missing:
        return {"ok": False, "error": f"missing required: {', '.join(_missing)}"}
    try:
        fx = int(args["from_x"]); fy = int(args["from_y"])
        tx = int(args["to_x"]); ty = int(args["to_y"])
        steps = int(args.get("steps", 20))
        delay = int(args.get("delay_ms", 10))
    except (TypeError, ValueError) as e:
        return {"ok": False, "error": f"invalid args: {e}"}
    _run(["xdotool", "mousemove", str(fx), str(fy), "mousedown", "1"])
    for i in range(1, steps + 1):
        x = fx + (tx - fx) * i // steps
        y = fy + (ty - fy) * i // steps
        _run(["xdotool", "mousemove", str(x), str(y)])
        time.sleep(delay / 1000)
    _run(["xdotool", "mouseup", "1"])
    return {"ok": True, "from": (fx, fy), "to": (tx, ty), "steps": steps}


def _mouse_position(args: Dict[str, Any]) -> Dict[str, Any]:
    """Current cursor position + which monitor it's on."""
    r = _run(["xdotool", "getmouselocation", "--shell"])
    if not r.get("ok"):
        return r
    pos = {}
    for line in r["stdout"].split("\n"):
        if "=" in line:
            k, v = line.split("=", 1)
            pos[k.strip()] = v.strip()
    x = int(pos.get("X", 0)); y = int(pos.get("Y", 0))
    mons = _monitors()
    on_mon = next((m["name"] for m in mons
                    if m["x"] <= x < m["x"]+m["w"] and m["y"] <= y < m["y"]+m["h"]), None)
    return {"ok": True, "x": x, "y": y, "screen_x": pos.get("SCREEN", 0),
             "monitor": on_mon, "window_id_under_cursor": pos.get("WINDOW", "")}


def _mouse_center_active(args: Dict[str, Any]) -> Dict[str, Any]:
    """Move mouse to the center of the active window (for screen readers / focus indicators)."""
    win = _active_window()
    if not win:
        return {"ok": False, "error": "no active window"}
    cx = win["x"] + win["w"] // 2
    cy = win["y"] + win["h"] // 2
    _run(["xdotool", "mousemove", str(cx), str(cy)])
    return {"ok": True, "x": cx, "y": cy}


# ── Keyboard ──────────────────────────────────────────────────────────
def _keyboard_hold_combo(args: Dict[str, Any]) -> Dict[str, Any]:
    """Press a keyboard combo where modifiers are held for the duration.

    Args:
      modifiers: list, e.g. ["ctrl", "shift"]
      keys: list of keys to press while modifiers held
      hold_ms: how long to hold modifiers (default 200)
    """
    mods = args.get("modifiers") or []
    keys = args.get("keys") or []
    if not keys:
        return {"ok": False, "error": "keys required"}
    hold = int(args.get("hold_ms", 200))
    for m in mods:
        _run(["xdotool", "keydown", m])
    for k in keys:
        _run(["xdotool", "key", k])
        time.sleep(0.05)
    time.sleep(hold / 1000)
    for m in mods:
        _run(["xdotool", "keyup", m])
    return {"ok": True, "modifiers": mods, "keys": keys}


def _keyboard_type_human(args: Dict[str, Any]) -> Dict[str, Any]:
    """Type text with human-like variable delays (avoids triggering bot detection).

    Args:
      text: required
      base_delay_ms: average between keys (default 60)
      jitter_pct: random ±% (default 30)
    """
    import random
    text = args.get("text")
    if not text:
        return {"ok": False, "error": "text required"}
    base = int(args.get("base_delay_ms", 60))
    jitter_pct = float(args.get("jitter_pct", 30)) / 100
    for ch in text:
        d = int(base * (1 - jitter_pct + random.random() * 2 * jitter_pct))
        _run(["xdotool", "type", "--delay", str(d), ch])
    return {"ok": True, "chars_typed": len(text)}


# ── Clipboard history ─────────────────────────────────────────────────
def _clipboard_history_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Save current clipboard contents to history. Useful to call from cron
    or a keystroke hook (xbindkeys → Leon).
    """
    if not _have("xclip"):
        return {"ok": False, "error": "xclip not installed"}
    r = _run(["xclip", "-selection", "clipboard", "-o"])
    if not r.get("ok"):
        return r
    text = r["stdout"]
    if not text:
        return {"ok": False, "error": "clipboard empty"}
    entry = {"ts": time.time(), "text": text[:5000]}
    with _CLIPBOARD_HISTORY.open("a") as f:
        f.write(json.dumps(entry) + "\n")
    return {"ok": True, "stored_chars": len(text)}


def _clipboard_history_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent clipboard entries."""
    limit = int(args.get("limit", 30))
    if not _CLIPBOARD_HISTORY.exists():
        return {"ok": True, "entries": [], "count": 0}
    lines = _CLIPBOARD_HISTORY.read_text().strip().split("\n")
    entries = []
    for line in lines[-limit:]:
        try:
            entries.append(json.loads(line))
        except Exception:
            pass
    return {"ok": True, "entries": entries, "count": len(entries)}


def _clipboard_history_clear(args: Dict[str, Any]) -> Dict[str, Any]:
    """Wipe clipboard history."""
    if _CLIPBOARD_HISTORY.exists():
        _CLIPBOARD_HISTORY.unlink()
    return {"ok": True}


def _clipboard_history_restore(args: Dict[str, Any]) -> Dict[str, Any]:
    """Put history entry #N back into the active clipboard.

    Args:
      index: 0=newest, 1=next, etc.
    """
    idx = int(args.get("index", 0))
    if not _CLIPBOARD_HISTORY.exists():
        return {"ok": False, "error": "no history"}
    lines = _CLIPBOARD_HISTORY.read_text().strip().split("\n")
    if idx >= len(lines):
        return {"ok": False, "error": f"only {len(lines)} entries"}
    entry = json.loads(lines[-(idx + 1)])
    if not _have("xclip"):
        return {"ok": False, "error": "xclip not installed"}
    p = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
    p.communicate(input=entry["text"].encode("utf-8"))
    return {"ok": True, "restored_chars": len(entry["text"])}


# ── Display ───────────────────────────────────────────────────────────
def _display_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all monitors with geometry + primary flag."""
    return {"ok": True, "monitors": _monitors()}


def _display_brightness_set(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set brightness on a specific output via xrandr.

    Args:
      output: e.g. 'HDMI-0' / 'DP-0'
      brightness: 0.0-2.0 (1.0 = normal)
    """
    output = args.get("output")
    br = float(args.get("brightness", 1.0))
    if not output:
        return {"ok": False, "error": "output required"}
    r = _run(["xrandr", "--output", output, "--brightness", str(br)])
    return {"ok": r["ok"], "output": output, "brightness": br}


def _display_brightness_all(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set brightness on every connected monitor."""
    br = float(args.get("brightness", 1.0))
    mons = _monitors()
    results = []
    for m in mons:
        r = _run(["xrandr", "--output", m["name"], "--brightness", str(br)])
        results.append({"output": m["name"], "ok": r["ok"]})
    return {"ok": True, "results": results}


def _display_rotate(args: Dict[str, Any]) -> Dict[str, Any]:
    """Rotate a monitor.

    Args:
      output: e.g. 'HDMI-0'
      direction: 'normal' | 'left' | 'right' | 'inverted'
    """
    output = args.get("output")
    direction = args.get("direction", "normal")
    if not output:
        return {"ok": False, "error": "output required"}
    if direction not in ("normal", "left", "right", "inverted"):
        return {"ok": False, "error": "bad direction"}
    r = _run(["xrandr", "--output", output, "--rotate", direction])
    return {"ok": r["ok"], "output": output, "rotation": direction}


# ── Audio: per-application volume ─────────────────────────────────────
def _audio_list_streams(args: Dict[str, Any]) -> Dict[str, Any]:
    """List per-application audio streams (pactl sink-inputs)."""
    r = _run(["pactl", "list", "sink-inputs"])
    if not r.get("ok"):
        return r
    streams = []
    cur = {}
    for line in r["stdout"].split("\n"):
        line_s = line.strip()
        if line_s.startswith("Sink Input #"):
            if cur:
                streams.append(cur)
            cur = {"id": line_s.split("#")[1]}
        elif "Volume:" in line and "front-left" in line:
            m = re.search(r"(\d+)%", line)
            if m:
                cur["volume_pct"] = int(m.group(1))
        elif line_s.startswith("application.name"):
            cur["app"] = line_s.split("=", 1)[1].strip().strip('"')
        elif line_s.startswith("media.name"):
            cur["media"] = line_s.split("=", 1)[1].strip().strip('"')
        elif line_s.startswith("Mute:"):
            cur["muted"] = "yes" in line_s.lower()
    if cur:
        streams.append(cur)
    return {"ok": True, "streams": streams, "count": len(streams)}


def _audio_set_app_volume(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set volume for one application stream.

    Args:
      app: substring of application name (e.g. 'spotify', 'brave')
      volume_pct: 0-150
    """
    app = (args.get("app") or "").lower()
    vol = int(args.get("volume_pct", 80))
    if not app:
        return {"ok": False, "error": "app required"}
    streams = _audio_list_streams({}).get("streams", [])
    matches = [s for s in streams if app in (s.get("app") or "").lower()]
    if not matches:
        return {"ok": False, "error": f"no stream matching '{app}'"}
    for s in matches:
        _run(["pactl", "set-sink-input-volume", s["id"], f"{vol}%"])
    return {"ok": True, "matched": [s.get("app") for s in matches], "volume_pct": vol}


def _audio_mute_app(args: Dict[str, Any]) -> Dict[str, Any]:
    """Toggle mute on an application's audio stream.

    Args:
      app: substring
    """
    app = (args.get("app") or "").lower()
    if not app:
        return {"ok": False, "error": "app required"}
    streams = _audio_list_streams({}).get("streams", [])
    matches = [s for s in streams if app in (s.get("app") or "").lower()]
    if not matches:
        return {"ok": False, "error": f"no stream matching '{app}'"}
    for s in matches:
        _run(["pactl", "set-sink-input-mute", s["id"], "toggle"])
    return {"ok": True, "muted_toggled": [s.get("app") for s in matches]}


# ── System / power ────────────────────────────────────────────────────
def _system_lock_screen(args: Dict[str, Any]) -> Dict[str, Any]:
    """Lock the screen via loginctl."""
    if _have("loginctl"):
        r = _run(["loginctl", "lock-session"])
        return {"ok": r["ok"], "method": "loginctl"}
    if _have("xdg-screensaver"):
        r = _run(["xdg-screensaver", "lock"])
        return {"ok": r["ok"], "method": "xdg-screensaver"}
    return {"ok": False, "error": "no lock method available"}


def _system_suspend(args: Dict[str, Any]) -> Dict[str, Any]:
    """Suspend (sleep) the machine. HIGH risk."""
    r = _run(["systemctl", "suspend"])
    return {"ok": r["ok"]}


def _system_reboot(args: Dict[str, Any]) -> Dict[str, Any]:
    """Reboot. HIGH risk — requires polkit consent."""
    r = _run(["systemctl", "reboot"])
    return {"ok": r["ok"]}


def _power_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Battery + AC + thermal summary via upower / sensors / /proc/acpi."""
    out = {"ok": True}
    if _have("upower"):
        r = _run(["upower", "-i", "/org/freedesktop/UPower/devices/battery_BAT0"])
        if r.get("ok") and r["stdout"]:
            for line in r["stdout"].split("\n"):
                line = line.strip()
                if ":" in line:
                    k, v = line.split(":", 1)
                    if k.strip() in ("percentage", "state", "time to empty", "time to full"):
                        out[k.strip().replace(" ", "_")] = v.strip()
    if _have("sensors"):
        r = _run(["sensors", "-j"])
        if r.get("ok"):
            try:
                data = json.loads(r["stdout"])
                # Pick first temp
                for chip, vals in data.items():
                    if isinstance(vals, dict):
                        for k, v in vals.items():
                            if isinstance(v, dict) and "_input" in str(v):
                                temps = [x for x in v.values() if isinstance(x, (int, float))]
                                if temps:
                                    out.setdefault("temps", {})[chip] = temps[0]
            except Exception:
                pass
    return out


def _screenshot_region_picker(args: Dict[str, Any]) -> Dict[str, Any]:
    """Capture a user-selected region (Spectacle / scrot interactive)."""
    save_to = args.get("save_to") or f"/tmp/leon-region-{int(time.time())}.png"
    if _have("spectacle"):
        r = _run(["spectacle", "-rbn", "-o", save_to], timeout=30)
        return {"ok": r["ok"], "saved_to": save_to, "tool": "spectacle"}
    if _have("scrot"):
        r = _run(["scrot", "-s", save_to], timeout=30)
        return {"ok": r["ok"], "saved_to": save_to, "tool": "scrot"}
    return {"ok": False, "error": "no screenshot tool installed (spectacle/scrot)"}


# ── Apps ───────────────────────────────────────────────────────────────
def _app_count_running(args: Dict[str, Any]) -> Dict[str, Any]:
    """Count windows by application class."""
    r = _run(["wmctrl", "-lx"])
    if not r.get("ok"):
        return r
    classes: Dict[str, int] = {}
    for line in r["stdout"].split("\n"):
        parts = line.split(None, 4)
        if len(parts) >= 5:
            cls = parts[2]
            classes[cls] = classes.get(cls, 0) + 1
    return {"ok": True, "classes": classes, "total_windows": sum(classes.values())}


def _app_quit_by_class(args: Dict[str, Any]) -> Dict[str, Any]:
    """Quit (graceful close) all windows of a class.

    Args:
      class_name: e.g. 'Brave-browser' or 'spotify'
    """
    cls = (args.get("class_name") or "").lower()
    if not cls:
        return {"ok": False, "error": "class_name required"}
    r = _run(["wmctrl", "-lx"])
    if not r.get("ok"):
        return r
    closed = []
    for line in r["stdout"].split("\n"):
        parts = line.split(None, 4)
        if len(parts) >= 5 and cls in parts[2].lower():
            _run(["wmctrl", "-i", "-c", parts[0]])
            closed.append(parts[4])
    return {"ok": True, "closed_count": len(closed), "titles": closed}


# ── EXTRA_TOOLS ────────────────────────────────────────────────────────
EXTRA_TOOLS = {
    # Window
    "pc.window_snap_quarter":         _window_snap_quarter,
    "pc.window_move_to_next_monitor": _window_move_to_next_monitor,
    "pc.window_opacity":              _window_opacity,
    "pc.window_sticky_toggle":        _window_sticky_toggle,
    "pc.window_minimize_all":         _window_minimize_all,
    "pc.window_restore_all":          _window_restore_all,
    "pc.window_cycle":                _window_cycle,
    "pc.window_focus_by_class":       _window_focus_by_class,
    "pc.window_close_active":         _window_close_active,
    "pc.window_force_kill":           _window_force_kill,
    # Workspace
    "pc.workspace_list_windows":      _workspace_list_windows,
    "pc.workspace_count":             _workspace_count,
    "pc.workspace_send_window":       _workspace_send_window,
    # Mouse
    "pc.mouse_scroll_precise":        _mouse_scroll_precise,
    "pc.mouse_smooth_drag":           _mouse_smooth_drag,
    "pc.mouse_position":              _mouse_position,
    "pc.mouse_center_active":         _mouse_center_active,
    # Keyboard
    "pc.keyboard_hold_combo":         _keyboard_hold_combo,
    "pc.keyboard_type_human":         _keyboard_type_human,
    # Clipboard history
    "pc.clipboard_history_add":       _clipboard_history_add,
    "pc.clipboard_history_list":      _clipboard_history_list,
    "pc.clipboard_history_clear":     _clipboard_history_clear,
    "pc.clipboard_history_restore":   _clipboard_history_restore,
    # Display
    "pc.display_list":                _display_list,
    "pc.display_brightness_set":      _display_brightness_set,
    "pc.display_brightness_all":      _display_brightness_all,
    "pc.display_rotate":              _display_rotate,
    # Audio per-app
    "pc.audio_list_streams":          _audio_list_streams,
    "pc.audio_set_app_volume":        _audio_set_app_volume,
    "pc.audio_mute_app":              _audio_mute_app,
    # System power
    "pc.system_lock_screen":          _system_lock_screen,
    "pc.system_suspend":              _system_suspend,
    "pc.system_reboot":               _system_reboot,
    "pc.power_status":                _power_status,
    "pc.screenshot_region_picker":    _screenshot_region_picker,
    # Apps
    "pc.app_count_running":           _app_count_running,
    "pc.app_quit_by_class":           _app_quit_by_class,
}


# ── ROUTE TO THE PC, NOT THE VPS (fix 2026-07-22) ──────────────────────────
# Every handler above shells out to xdotool/wmctrl/pactl/xrandr with
# DISPLAY=:0 — but this module runs inside the BRAIN on the headless VPS,
# which has no X server, no PulseAudio, and no wmctrl. So the entire pc.*
# suite silently failed (wmctrl "not installed", pulse "connection refused")
# and Leon fell back to raw shell (e.g. brightness via gamma). The REAL
# handlers now live on the PC actuator (leon-actuator/pc_tools.py). Wrap each
# tool so the call is forwarded over the authenticated actuator tunnel and
# actually executes on Dean's desktop.
def _delegate_to_pc(dotted_name):
    def _forward(args=None):
        from brain import actuator_client
        return actuator_client.call(dotted_name, args or {})
    _forward.__name__ = dotted_name.replace(".", "_")
    return _forward


EXTRA_TOOLS = {name: _delegate_to_pc(name) for name in EXTRA_TOOLS}
