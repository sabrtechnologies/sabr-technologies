"""
devtools.py — Developer utility tools for Leon.

Mostly LOCAL, stdlib-only. No credentials, no persistent network state.
A few tools (http_request, http_test_endpoint, webhook_inspect) reach the
network via `requests` if available.

Every tool returns a dict with an "ok" boolean and never raises.
Export: EXTRA_TOOLS — dict of tool name -> callable.
"""

import base64
import binascii
import colorsys
import csv
import datetime as _dt
import difflib
import hashlib
import html as _html
import io
import json
import math
import re
import urllib.parse
import uuid as _uuid

try:
    import yaml as _yaml
except Exception:  # pragma: no cover
    _yaml = None

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def _err(msg):
    return {"ok": False, "error": str(msg)}


def _ok(**kw):
    d = {"ok": True}
    d.update(kw)
    return d


def _safe(fn):
    """Wrap a tool so any exception becomes {ok: False, error: ...}."""
    def wrapped(*a, **kw):
        try:
            return fn(*a, **kw)
        except Exception as e:
            return _err("%s: %s" % (type(e).__name__, e))
    wrapped.__name__ = getattr(fn, "__name__", "tool")
    wrapped.__doc__ = fn.__doc__
    return wrapped


def _parse_json(text):
    """Return (obj, None) or (None, error_str)."""
    try:
        return json.loads(text), None
    except json.JSONDecodeError as e:
        return None, "JSON error at line %d col %d: %s" % (e.lineno, e.colno, e.msg)
    except Exception as e:
        return None, str(e)


def _dt_now_utc():
    return _dt.datetime.now(_dt.timezone.utc)


def _parse_date(s):
    """Best-effort parse of a human date string into an aware datetime (UTC)."""
    s = str(s).strip()
    # epoch seconds / millis
    if re.fullmatch(r"-?\d{10,13}", s):
        ts = int(s)
        if len(s.lstrip("-")) >= 13:
            ts = ts / 1000.0
        return _dt.datetime.fromtimestamp(ts, _dt.timezone.utc)
    # ISO 8601
    iso = s.replace("Z", "+00:00")
    try:
        d = _dt.datetime.fromisoformat(iso)
        if d.tzinfo is None:
            d = d.replace(tzinfo=_dt.timezone.utc)
        return d
    except Exception:
        pass
    fmts = [
        "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
        "%Y/%m/%d %H:%M:%S", "%Y/%m/%d", "%m/%d/%Y %H:%M:%S",
        "%m/%d/%Y", "%d-%m-%Y", "%d %b %Y", "%b %d %Y", "%b %d, %Y",
        "%B %d, %Y", "%d %B %Y", "%H:%M:%S", "%H:%M",
    ]
    for f in fmts:
        try:
            d = _dt.datetime.strptime(s, f)
            if "%Y" not in f:  # time-only -> attach today
                today = _dt_now_utc()
                d = d.replace(year=today.year, month=today.month, day=today.day)
            return d.replace(tzinfo=_dt.timezone.utc)
        except Exception:
            continue
    raise ValueError("could not parse date: %r" % s)


# --------------------------------------------------------------------------
# JSON / data
# --------------------------------------------------------------------------

@_safe
def json_format(text, indent=2):
    """Pretty-print JSON."""
    obj, err = _parse_json(text)
    if err:
        return _err(err)
    return _ok(result=json.dumps(obj, indent=int(indent), ensure_ascii=False, sort_keys=False))


@_safe
def json_minify(text):
    """Strip whitespace from JSON."""
    obj, err = _parse_json(text)
    if err:
        return _err(err)
    return _ok(result=json.dumps(obj, separators=(",", ":"), ensure_ascii=False))


@_safe
def json_validate(text):
    """Check whether text is valid JSON; report where it breaks."""
    obj, err = _parse_json(text)
    if err:
        return _ok(valid=False, error=err)
    return _ok(valid=True, type=type(obj).__name__)


@_safe
def json_query(text, path):
    """Extract a value via a dotted path, e.g. 'data.users.0.name'."""
    obj, err = _parse_json(text)
    if err:
        return _err(err)
    cur = obj
    parts = [p for p in str(path).split(".") if p != ""]
    for i, p in enumerate(parts):
        if isinstance(cur, dict):
            if p not in cur:
                return _err("key %r not found at %s" % (p, ".".join(parts[:i]) or "<root>"))
            cur = cur[p]
        elif isinstance(cur, list):
            try:
                idx = int(p)
            except ValueError:
                return _err("expected list index at %r, got %r" % (".".join(parts[:i]), p))
            if not (-len(cur) <= idx < len(cur)):
                return _err("index %d out of range (len %d)" % (idx, len(cur)))
            cur = cur[idx]
        else:
            return _err("cannot descend into %s at %r" % (type(cur).__name__, p))
    return _ok(value=cur, type=type(cur).__name__)


@_safe
def json_to_yaml(text):
    """Convert JSON text to YAML."""
    obj, err = _parse_json(text)
    if err:
        return _err(err)
    if _yaml is None:
        return _err("PyYAML not installed (pip install pyyaml)")
    return _ok(result=_yaml.safe_dump(obj, sort_keys=False, allow_unicode=True))


@_safe
def yaml_to_json(text):
    """Convert YAML text to JSON."""
    if _yaml is None:
        return _err("PyYAML not installed (pip install pyyaml)")
    obj = _yaml.safe_load(text)
    return _ok(result=json.dumps(obj, indent=2, ensure_ascii=False))


def _json_diff(a, b, path=""):
    """Recursive structural diff. Returns list of change dicts."""
    out = []
    if type(a) is not type(b) and not (isinstance(a, (int, float)) and isinstance(b, (int, float))):
        out.append({"path": path or "<root>", "change": "type",
                     "from": a, "to": b})
        return out
    if isinstance(a, dict):
        for k in a:
            p = "%s.%s" % (path, k) if path else k
            if k not in b:
                out.append({"path": p, "change": "removed", "from": a[k]})
            else:
                out.extend(_json_diff(a[k], b[k], p))
        for k in b:
            if k not in a:
                p = "%s.%s" % (path, k) if path else k
                out.append({"path": p, "change": "added", "to": b[k]})
    elif isinstance(a, list):
        for i in range(max(len(a), len(b))):
            p = "%s[%d]" % (path, i)
            if i >= len(a):
                out.append({"path": p, "change": "added", "to": b[i]})
            elif i >= len(b):
                out.append({"path": p, "change": "removed", "from": a[i]})
            else:
                out.extend(_json_diff(a[i], b[i], p))
    else:
        if a != b:
            out.append({"path": path or "<root>", "change": "value",
                        "from": a, "to": b})
    return out


@_safe
def json_diff(a_text, b_text):
    """Structural diff of two JSON documents."""
    a, ea = _parse_json(a_text)
    if ea:
        return _err("a: " + ea)
    b, eb = _parse_json(b_text)
    if eb:
        return _err("b: " + eb)
    diff = _json_diff(a, b)
    return _ok(changes=diff, count=len(diff), identical=not diff)


@_safe
def csv_to_json(text):
    """Convert CSV text to a JSON array of objects (first row = headers)."""
    rows = list(csv.DictReader(io.StringIO(text)))
    return _ok(result=json.dumps(rows, indent=2, ensure_ascii=False), rows=len(rows))


@_safe
def json_to_csv(text):
    """Convert a JSON array of objects to CSV."""
    obj, err = _parse_json(text)
    if err:
        return _err(err)
    if not isinstance(obj, list):
        return _err("expected a JSON array of objects")
    if not obj:
        return _ok(result="", rows=0)
    fields = []
    for row in obj:
        if not isinstance(row, dict):
            return _err("every element must be an object")
        for k in row:
            if k not in fields:
                fields.append(k)
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    w.writeheader()
    for row in obj:
        w.writerow({k: row.get(k, "") for k in fields})
    return _ok(result=buf.getvalue(), rows=len(obj))


# --------------------------------------------------------------------------
# encoding / hashing
# --------------------------------------------------------------------------

@_safe
def base64_encode(text):
    """Base64-encode a UTF-8 string."""
    return _ok(result=base64.b64encode(str(text).encode("utf-8")).decode("ascii"))


@_safe
def base64_decode(text):
    """Base64-decode to a UTF-8 string."""
    raw = base64.b64decode(_pad_b64(str(text)), validate=False)
    try:
        return _ok(result=raw.decode("utf-8"))
    except UnicodeDecodeError:
        return _ok(result=raw.hex(), note="not valid UTF-8; returned hex")


def _pad_b64(s):
    s = s.strip()
    return s + "=" * (-len(s) % 4)


@_safe
def url_encode(text):
    """Percent-encode a string for safe URL use."""
    return _ok(result=urllib.parse.quote(str(text), safe=""))


@_safe
def url_decode(text):
    """Decode a percent-encoded string."""
    return _ok(result=urllib.parse.unquote(str(text)))


@_safe
def hash_text(text, algo="sha256"):
    """Hash text. algo: sha256 / md5 / sha1 / sha512."""
    algo = str(algo).lower()
    valid = {"sha256", "md5", "sha1", "sha512"}
    if algo not in valid:
        return _err("algo must be one of %s" % sorted(valid))
    h = hashlib.new(algo, str(text).encode("utf-8"))
    return _ok(algo=algo, result=h.hexdigest())


@_safe
def html_escape(text):
    """Escape HTML special characters."""
    return _ok(result=_html.escape(str(text), quote=True))


@_safe
def html_unescape(text):
    """Unescape HTML entities."""
    return _ok(result=_html.unescape(str(text)))


@_safe
def text_to_hex(text):
    """Convert a string to its hex representation."""
    return _ok(result=str(text).encode("utf-8").hex())


@_safe
def hex_to_text(hex):
    """Convert a hex string back to text."""
    clean = re.sub(r"[\s:]", "", str(hex))
    try:
        raw = bytes.fromhex(clean)
    except ValueError as e:
        return _err("invalid hex: %s" % e)
    try:
        return _ok(result=raw.decode("utf-8"))
    except UnicodeDecodeError:
        return _ok(result=raw.decode("latin-1"), note="not valid UTF-8; decoded as latin-1")


# --------------------------------------------------------------------------
# regex
# --------------------------------------------------------------------------

_FLAG_MAP = {
    "i": re.IGNORECASE, "ignorecase": re.IGNORECASE,
    "m": re.MULTILINE, "multiline": re.MULTILINE,
    "s": re.DOTALL, "dotall": re.DOTALL,
    "x": re.VERBOSE, "verbose": re.VERBOSE,
    "a": re.ASCII, "ascii": re.ASCII,
}


def _build_flags(flags):
    f = 0
    if not flags:
        return f
    if isinstance(flags, int):
        return flags
    for tok in re.split(r"[,\s|]+", str(flags).lower()):
        if tok and tok in _FLAG_MAP:
            f |= _FLAG_MAP[tok]
    return f


@_safe
def regex_test(pattern, text, flags=None):
    """Test a regex against text. Returns all matches with groups."""
    rx = re.compile(pattern, _build_flags(flags))
    matches = []
    for m in rx.finditer(text):
        matches.append({
            "match": m.group(0),
            "span": list(m.span()),
            "groups": list(m.groups()),
            "named": m.groupdict(),
        })
    return _ok(matched=bool(matches), count=len(matches), matches=matches)


@_safe
def regex_replace(pattern, replacement, text):
    """Replace all regex matches in text."""
    result, n = re.subn(pattern, replacement, text)
    return _ok(result=result, replacements=n)


@_safe
def regex_extract_all(pattern, text):
    """Return every substring matching the pattern."""
    rx = re.compile(pattern)
    found = [m.group(0) for m in rx.finditer(text)]
    return _ok(matches=found, count=len(found))


_REGEX_TOKENS = [
    (r"\\d", "any digit (0-9)"),
    (r"\\D", "any non-digit"),
    (r"\\w", "any word char (letter, digit, underscore)"),
    (r"\\W", "any non-word char"),
    (r"\\s", "any whitespace"),
    (r"\\S", "any non-whitespace"),
    (r"\\b", "a word boundary"),
    (r"\\B", "a non-word-boundary"),
    (r"\.", "a literal dot"),
    (r"\^", "start of string/line"),
    (r"\$", "end of string/line"),
    (r"\*", "zero or more of the previous"),
    (r"\+", "one or more of the previous"),
    (r"\?", "optional (zero or one) of the previous"),
    (r"\{\d+,?\d*\}", "a specific repetition count"),
    (r"\[\^[^\]]*\]", "any char NOT in the set"),
    (r"\[[^\]]*\]", "any one char from the set"),
    (r"\(\?:", "a non-capturing group"),
    (r"\(\?P<\w+>", "a named capturing group"),
    (r"\(", "the start of a capturing group"),
    (r"\)", "the end of a group"),
    (r"\|", "OR (alternation)"),
]


@_safe
def regex_explain(pattern):
    """Break a regex into human-readable parts."""
    parts = []
    for tok, desc in _REGEX_TOKENS:
        for m in re.finditer(tok, pattern):
            parts.append({"token": m.group(0), "at": m.start(), "means": desc})
    parts.sort(key=lambda p: p["at"])
    try:
        re.compile(pattern)
        valid = True
        verr = None
    except re.error as e:
        valid = False
        verr = str(e)
    summary = "; ".join("%s = %s" % (p["token"], p["means"]) for p in parts) or \
        "literal text only"
    return _ok(valid=valid, error=verr, parts=parts, summary=summary)


# --------------------------------------------------------------------------
# time / cron
# --------------------------------------------------------------------------

@_safe
def timestamp_to_date(ts, tz="UTC"):
    """Convert a unix timestamp to a readable date (UTC)."""
    try:
        ts = float(ts)
    except (TypeError, ValueError):
        return _err("ts must be a number")
    if ts > 1e12:  # millis
        ts = ts / 1000.0
    d = _dt.datetime.fromtimestamp(ts, _dt.timezone.utc)
    return _ok(
        iso=d.isoformat(),
        readable=d.strftime("%A, %B %d %Y, %H:%M:%S UTC"),
        unix=int(ts),
        tz=str(tz),
    )


@_safe
def date_to_timestamp(date_str):
    """Convert a readable date string to a unix timestamp."""
    d = _parse_date(date_str)
    return _ok(unix=int(d.timestamp()), unix_ms=int(d.timestamp() * 1000),
               iso=d.isoformat())


_CRON_NAMES = {
    "@yearly": "0 0 1 1 *", "@annually": "0 0 1 1 *",
    "@monthly": "0 0 1 * *", "@weekly": "0 0 * * 0",
    "@daily": "0 0 * * *", "@midnight": "0 0 * * *",
    "@hourly": "0 * * * *",
}
_CRON_FIELDS = [
    ("minute", 0, 59), ("hour", 0, 23), ("day-of-month", 1, 31),
    ("month", 1, 12), ("day-of-week", 0, 6),
]
_DOW = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
_MON = ["", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"]
_DOW_ALIAS = {"sun": 0, "mon": 1, "tue": 2, "wed": 3, "thu": 4, "fri": 5, "sat": 6}
_MON_ALIAS = {m[:3].lower(): i for i, m in enumerate(_MON) if m}


def _cron_field_values(token, lo, hi, aliases=None):
    """Expand one cron field token into a sorted set of ints."""
    token = token.strip()
    if aliases:
        for name, num in aliases.items():
            token = re.sub(r"\b%s\b" % name, str(num), token, flags=re.IGNORECASE)
    vals = set()
    for part in token.split(","):
        part = part.strip()
        step = 1
        if "/" in part:
            part, step_s = part.split("/", 1)
            step = int(step_s)
        if part in ("*", ""):
            rng = range(lo, hi + 1)
        elif "-" in part:
            a, b = part.split("-", 1)
            rng = range(int(a), int(b) + 1)
        else:
            v = int(part)
            rng = range(v, v + 1)
        for v in rng:
            if lo <= v <= hi and (v - rng.start) % step == 0:
                vals.add(v)
    return sorted(vals)


def _parse_cron(expr):
    """Return list of 5 value-sets, or raise ValueError."""
    expr = expr.strip()
    if expr.lower() in _CRON_NAMES:
        expr = _CRON_NAMES[expr.lower()]
    fields = expr.split()
    if len(fields) != 5:
        raise ValueError("expected 5 cron fields, got %d" % len(fields))
    out = []
    for tok, (name, lo, hi) in zip(fields, _CRON_FIELDS):
        alias = None
        if name == "day-of-week":
            alias = _DOW_ALIAS
        elif name == "month":
            alias = _MON_ALIAS
        vals = _cron_field_values(tok, lo, hi, alias)
        if not vals:
            raise ValueError("field %r (%s) yields no values" % (tok, name))
        out.append(vals)
    return out


def _cron_field_phrase(token, name):
    token = token.strip()
    if token == "*":
        return "every %s" % name
    if "/" in token and token.startswith("*"):
        return "every %s %ss" % (token.split("/")[1], name)
    if "-" in token and "," not in token:
        return "%ss %s through %s" % (name, *token.split("-"))
    return "%s %s" % (name, token)


@_safe
def cron_explain(expr):
    """Explain a cron expression in plain English."""
    raw = expr.strip()
    if raw.lower() in _CRON_NAMES:
        norm = _CRON_NAMES[raw.lower()]
    else:
        norm = raw
    fields = norm.split()
    if len(fields) != 5:
        return _err("expected 5 cron fields, got %d" % len(fields))
    minute, hour, dom, month, dow = fields
    bits = []
    if minute == "0" and hour != "*":
        bits.append("at the top of hour %s" % hour)
    elif minute != "*" and hour != "*":
        bits.append("at %s:%s" % (hour.zfill(2) if hour.isdigit() else hour,
                                  minute.zfill(2) if minute.isdigit() else minute))
    else:
        bits.append(_cron_field_phrase(minute, "minute"))
        bits.append(_cron_field_phrase(hour, "hour"))
    if dom != "*":
        bits.append("on day-of-month %s" % dom)
    if month != "*":
        if month.isdigit():
            bits.append("in %s" % _MON[int(month)])
        else:
            bits.append("in month %s" % month)
    if dow != "*":
        if dow.isdigit():
            bits.append("on %s" % _DOW[int(dow) % 7])
        else:
            bits.append("on day-of-week %s" % dow)
    # validate
    try:
        _parse_cron(raw)
        valid = True
        verr = None
    except Exception as e:
        valid = False
        verr = str(e)
    return _ok(valid=valid, error=verr, expression=norm,
               english="Runs " + ", ".join(bits) + ".")


@_safe
def cron_next_runs(expr, count=5):
    """Return the next N times a cron expression fires (UTC)."""
    try:
        minute_s, hour_s, dom_s, month_s, dow_s = _parse_cron(expr)
    except Exception as e:
        return _err(str(e))
    count = max(1, min(int(count), 100))
    now = _dt_now_utc().replace(second=0, microsecond=0) + _dt.timedelta(minutes=1)
    runs = []
    cur = now
    limit = 0
    minute_set = set(minute_s)
    hour_set = set(hour_s)
    dom_set = set(dom_s)
    month_set = set(month_s)
    dow_set = set(dow_s)
    dom_restricted = len(dom_set) < 31
    dow_restricted = len(dow_set) < 7
    while len(runs) < count and limit < 366 * 24 * 60:
        limit += 1
        if cur.month in month_set and cur.hour in hour_set and cur.minute in minute_set:
            # cron weekday: Mon=0..Sun=6 -> convert to Sun=0..Sat=6
            cron_dow = (cur.weekday() + 1) % 7
            dom_match = cur.day in dom_set
            dow_match = cron_dow in dow_set
            if dom_restricted and dow_restricted:
                day_ok = dom_match or dow_match
            elif dom_restricted:
                day_ok = dom_match
            elif dow_restricted:
                day_ok = dow_match
            else:
                day_ok = True
            if day_ok:
                runs.append(cur.isoformat())
        cur += _dt.timedelta(minutes=1)
    return _ok(next_runs=runs, count=len(runs))


@_safe
def time_diff(date_a, date_b):
    """Compute the duration between two dates."""
    a = _parse_date(date_a)
    b = _parse_date(date_b)
    delta = b - a
    secs = delta.total_seconds()
    sign = "" if secs >= 0 else "-"
    s = abs(secs)
    days = int(s // 86400)
    hours = int((s % 86400) // 3600)
    mins = int((s % 3600) // 60)
    rem = int(s % 60)
    human = sign + ", ".join(
        "%d%s" % (v, u) for v, u in
        [(days, "d"), (hours, "h"), (mins, "m"), (rem, "s")] if v
    ) or "0s"
    return _ok(seconds=secs, days=delta.days, human=human,
               from_date=a.isoformat(), to_date=b.isoformat())


# --------------------------------------------------------------------------
# JWT / auth / uuid
# --------------------------------------------------------------------------

@_safe
def jwt_decode(token):
    """Decode a JWT's header and payload. Does NOT verify the signature."""
    token = str(token).strip()
    parts = token.split(".")
    if len(parts) not in (2, 3):
        return _err("not a JWT: expected 2-3 dot-separated segments")

    def _seg(seg):
        raw = base64.urlsafe_b64decode(_pad_b64(seg))
        return json.loads(raw.decode("utf-8"))

    try:
        header = _seg(parts[0])
        payload = _seg(parts[1])
    except Exception as e:
        return _err("malformed JWT segment: %s" % e)
    info = {}
    for claim, label in [("exp", "expires"), ("iat", "issued_at"), ("nbf", "not_before")]:
        if claim in payload:
            try:
                info[label] = _dt.datetime.fromtimestamp(
                    payload[claim], _dt.timezone.utc).isoformat()
            except Exception:
                pass
    expired = None
    if "exp" in payload:
        try:
            expired = float(payload["exp"]) < _dt_now_utc().timestamp()
        except Exception:
            pass
    return _ok(header=header, payload=payload, claims=info, expired=expired,
               signature_present=len(parts) == 3, verified=False,
               note="signature NOT verified")


@_safe
def uuid_generate(version=4, count=1):
    """Generate one or more UUIDs. version 1 or 4."""
    version = int(version)
    count = max(1, min(int(count), 1000))
    if version == 4:
        gen = lambda: str(_uuid.uuid4())
    elif version == 1:
        gen = lambda: str(_uuid.uuid1())
    else:
        return _err("version must be 1 or 4")
    ids = [gen() for _ in range(count)]
    return _ok(uuids=ids, count=len(ids), version=version)


@_safe
def password_strength(password):
    """Estimate password entropy and brute-force crack time."""
    pw = str(password)
    if not pw:
        return _err("empty password")
    pool = 0
    if re.search(r"[a-z]", pw):
        pool += 26
    if re.search(r"[A-Z]", pw):
        pool += 26
    if re.search(r"\d", pw):
        pool += 10
    if re.search(r"[^a-zA-Z0-9]", pw):
        pool += 33
    pool = max(pool, 1)
    entropy = len(pw) * math.log2(pool)
    # assume 10 billion guesses/sec, average half the keyspace
    combos = 2 ** entropy
    seconds = (combos / 2) / 1e10
    for unit, span in [("years", 31557600), ("days", 86400),
                       ("hours", 3600), ("minutes", 60), ("seconds", 1)]:
        if seconds >= span:
            crack = "%.1f %s" % (seconds / span, unit)
            break
    else:
        crack = "instant"
    if entropy < 28:
        rating = "very weak"
    elif entropy < 36:
        rating = "weak"
    elif entropy < 60:
        rating = "reasonable"
    elif entropy < 128:
        rating = "strong"
    else:
        rating = "very strong"
    return _ok(length=len(pw), charset_size=pool,
               entropy_bits=round(entropy, 1), rating=rating,
               crack_time_estimate=crack)


# --------------------------------------------------------------------------
# color
# --------------------------------------------------------------------------

def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def _rgb_to_hex(r, g, b):
    return "#%02x%02x%02x" % (int(round(r)), int(round(g)), int(round(b)))


def _hex_to_rgb(h):
    h = h.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) != 6:
        raise ValueError("hex must be 3 or 6 digits")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _rgb_to_hsl(r, g, b):
    h, l, s = colorsys.rgb_to_hls(r / 255.0, g / 255.0, b / 255.0)
    return (round(h * 360), round(s * 100), round(l * 100))


def _hsl_to_rgb(h, s, l):
    r, g, b = colorsys.hls_to_rgb((h % 360) / 360.0, l / 100.0, s / 100.0)
    return (r * 255, g * 255, b * 255)


def _parse_color(value):
    """Return (r, g, b) from hex / rgb() / hsl() input."""
    v = str(value).strip().lower()
    if v.startswith("#") or re.fullmatch(r"[0-9a-f]{3}|[0-9a-f]{6}", v):
        return _hex_to_rgb(v)
    m = re.match(r"rgba?\(([^)]+)\)", v)
    if m:
        nums = [float(x.strip().rstrip("%")) for x in m.group(1).split(",")[:3]]
        return tuple(_clamp(n, 0, 255) for n in nums)
    m = re.match(r"hsla?\(([^)]+)\)", v)
    if m:
        nums = [float(x.strip().rstrip("%deg")) for x in m.group(1).split(",")[:3]]
        return _hsl_to_rgb(*nums)
    # bare "r,g,b"
    m = re.fullmatch(r"\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*", v)
    if m:
        return tuple(int(x) for x in m.groups())
    raise ValueError("unrecognized color: %r" % value)


@_safe
def color_convert(value):
    """Auto-detect a color (hex/rgb/hsl) and return all formats."""
    r, g, b = _parse_color(value)
    h, s, l = _rgb_to_hsl(r, g, b)
    return _ok(
        hex=_rgb_to_hex(r, g, b),
        rgb="rgb(%d, %d, %d)" % (int(r), int(g), int(b)),
        hsl="hsl(%d, %d%%, %d%%)" % (h, s, l),
        rgb_tuple=[int(r), int(g), int(b)],
        hsl_tuple=[h, s, l],
    )


@_safe
def color_palette(base_hex, scheme="complementary"):
    """Generate a color palette: complementary / triadic / analogous."""
    r, g, b = _parse_color(base_hex)
    h, s, l = _rgb_to_hsl(r, g, b)
    scheme = str(scheme).lower()
    if scheme == "complementary":
        offsets = [0, 180]
    elif scheme == "triadic":
        offsets = [0, 120, 240]
    elif scheme == "analogous":
        offsets = [-30, 0, 30]
    else:
        return _err("scheme must be complementary/triadic/analogous")
    colors = []
    for off in offsets:
        rr, gg, bb = _hsl_to_rgb((h + off) % 360, s, l)
        colors.append(_rgb_to_hex(rr, gg, bb))
    return _ok(scheme=scheme, base=_rgb_to_hex(r, g, b), palette=colors)


# --------------------------------------------------------------------------
# API testing
# --------------------------------------------------------------------------

def _need_requests():
    if _requests is None:
        return _err("requests library not installed (pip install requests)")
    return None


@_safe
def http_request(method, url, headers=None, body=None, params=None):
    """Generic HTTP request. Returns status, headers, body. MEDIUM risk."""
    miss = _need_requests()
    if miss:
        return miss
    method = str(method).upper()
    if method not in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
        return _err("unsupported method: %s" % method)
    kw = {"timeout": 20}
    if headers:
        kw["headers"] = headers if isinstance(headers, dict) else json.loads(headers)
    if params:
        kw["params"] = params if isinstance(params, dict) else json.loads(params)
    if body is not None:
        if isinstance(body, (dict, list)):
            kw["json"] = body
        else:
            kw["data"] = body
    resp = _requests.request(method, url, **kw)
    text = resp.text
    truncated = False
    if len(text) > 20000:
        text = text[:20000]
        truncated = True
    try:
        parsed = resp.json()
    except Exception:
        parsed = None
    return _ok(
        status=resp.status_code,
        ok_status=resp.ok,
        headers=dict(resp.headers),
        body=text,
        json=parsed,
        elapsed_ms=round(resp.elapsed.total_seconds() * 1000, 1),
        truncated=truncated,
        url=resp.url,
    )


@_safe
def http_test_endpoint(url, expected_status=200):
    """Quick health check against a URL."""
    miss = _need_requests()
    if miss:
        return miss
    try:
        resp = _requests.get(url, timeout=15)
    except Exception as e:
        return _ok(reachable=False, healthy=False, error=str(e))
    expected = int(expected_status)
    return _ok(
        reachable=True,
        healthy=resp.status_code == expected,
        status=resp.status_code,
        expected=expected,
        elapsed_ms=round(resp.elapsed.total_seconds() * 1000, 1),
    )


@_safe
def webhook_inspect(url):
    """POST a small test payload to a webhook and return what came back."""
    miss = _need_requests()
    if miss:
        return miss
    payload = {
        "source": "leon.devtools.webhook_inspect",
        "test": True,
        "timestamp": _dt_now_utc().isoformat(),
        "nonce": str(_uuid.uuid4()),
    }
    try:
        resp = _requests.post(url, json=payload, timeout=15)
    except Exception as e:
        return _ok(delivered=False, error=str(e), sent=payload)
    text = resp.text
    if len(text) > 8000:
        text = text[:8000]
    return _ok(
        delivered=True,
        status=resp.status_code,
        sent=payload,
        response_headers=dict(resp.headers),
        response_body=text,
        elapsed_ms=round(resp.elapsed.total_seconds() * 1000, 1),
    )


# --------------------------------------------------------------------------
# text utilities
# --------------------------------------------------------------------------

_LOREM = (
    "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod "
    "tempor incididunt ut labore et dolore magna aliqua ut enim ad minim "
    "veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea "
    "commodo consequat duis aute irure dolor in reprehenderit in voluptate "
    "velit esse cillum dolore eu fugiat nulla pariatur excepteur sint "
    "occaecat cupidatat non proident sunt in culpa qui officia deserunt "
    "mollit anim id est laborum"
).split()


@_safe
def lorem_ipsum(paragraphs=3):
    """Generate placeholder lorem-ipsum text."""
    paragraphs = max(1, min(int(paragraphs), 50))
    out = []
    idx = 0
    for p in range(paragraphs):
        sentences = []
        for _ in range(4 + (p % 3)):
            n = 8 + ((idx * 7) % 9)
            words = [_LOREM[(idx + i) % len(_LOREM)] for i in range(n)]
            idx += n
            sent = " ".join(words)
            sentences.append(sent[0].upper() + sent[1:] + ".")
        out.append(" ".join(sentences))
    text = "\n\n".join(out)
    return _ok(text=text, paragraphs=paragraphs,
               word_count=len(text.split()))


@_safe
def slugify(text):
    """Convert text to a URL-safe slug."""
    s = str(text).strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[\s_-]+", "-", s)
    s = s.strip("-")
    return _ok(slug=s)


def _split_words(text):
    """Split arbitrary text into lowercase words for case conversion."""
    s = str(text)
    # split camelCase / PascalCase boundaries
    s = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", s)
    s = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", s)
    words = re.split(r"[\s_\-./]+", s)
    return [w.lower() for w in words if w]


@_safe
def case_convert(text, target):
    """Convert text case: snake / camel / pascal / kebab / title."""
    words = _split_words(text)
    if not words:
        return _ok(result="")
    target = str(target).lower()
    if target == "snake":
        result = "_".join(words)
    elif target == "kebab":
        result = "-".join(words)
    elif target == "camel":
        result = words[0] + "".join(w.capitalize() for w in words[1:])
    elif target == "pascal":
        result = "".join(w.capitalize() for w in words)
    elif target == "title":
        result = " ".join(w.capitalize() for w in words)
    else:
        return _err("target must be snake/camel/pascal/kebab/title")
    return _ok(result=result, target=target)


@_safe
def word_count(text):
    """Count words, characters, lines, and estimate reading time."""
    s = str(text)
    words = len(s.split())
    lines = s.count("\n") + 1 if s else 0
    chars = len(s)
    chars_no_space = len(re.sub(r"\s", "", s))
    minutes = words / 200.0  # ~200 wpm
    if minutes < 1:
        reading = "%d sec" % max(1, round(minutes * 60))
    else:
        reading = "%.1f min" % minutes
    return _ok(words=words, characters=chars,
               characters_no_spaces=chars_no_space,
               lines=lines, reading_time=reading)


@_safe
def diff_text(a, b):
    """Produce a unified diff between two text blocks."""
    a_lines = str(a).splitlines(keepends=True)
    b_lines = str(b).splitlines(keepends=True)
    diff = list(difflib.unified_diff(a_lines, b_lines,
                                     fromfile="a", tofile="b", lineterm=""))
    added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
    ratio = difflib.SequenceMatcher(None, str(a), str(b)).ratio()
    return _ok(diff="\n".join(diff), added=added, removed=removed,
               similarity=round(ratio, 4), identical=str(a) == str(b))


# --------------------------------------------------------------------------
# tool registry
# --------------------------------------------------------------------------

EXTRA_TOOLS = {
    # JSON / data
    "dev.json_format": json_format,
    "dev.json_minify": json_minify,
    "dev.json_validate": json_validate,
    "dev.json_query": json_query,
    "dev.json_to_yaml": json_to_yaml,
    "dev.yaml_to_json": yaml_to_json,
    "dev.json_diff": json_diff,
    "dev.csv_to_json": csv_to_json,
    "dev.json_to_csv": json_to_csv,
    # encoding / hashing
    "dev.base64_encode": base64_encode,
    "dev.base64_decode": base64_decode,
    "dev.url_encode": url_encode,
    "dev.url_decode": url_decode,
    "dev.hash_text": hash_text,
    "dev.html_escape": html_escape,
    "dev.html_unescape": html_unescape,
    "dev.hex_to_text": hex_to_text,
    "dev.text_to_hex": text_to_hex,
    # regex
    "dev.regex_test": regex_test,
    "dev.regex_replace": regex_replace,
    "dev.regex_extract_all": regex_extract_all,
    "dev.regex_explain": regex_explain,
    # time / cron
    "dev.timestamp_to_date": timestamp_to_date,
    "dev.date_to_timestamp": date_to_timestamp,
    "dev.cron_explain": cron_explain,
    "dev.cron_next_runs": cron_next_runs,
    "dev.time_diff": time_diff,
    # JWT / auth
    "dev.jwt_decode": jwt_decode,
    "dev.uuid_generate": uuid_generate,
    "dev.password_strength": password_strength,
    # color
    "dev.color_convert": color_convert,
    "dev.color_palette": color_palette,
    # API testing
    "dev.http_request": http_request,
    "dev.http_test_endpoint": http_test_endpoint,
    "dev.webhook_inspect": webhook_inspect,
    # text utilities
    "dev.lorem_ipsum": lorem_ipsum,
    "dev.slugify": slugify,
    "dev.case_convert": case_convert,
    "dev.word_count": word_count,
    "dev.diff_text": diff_text,
}


# ── Adapter: dispatcher calls fn({...}); these fns take kwargs. Bridge it. ──
def _adapt_devtool(fn):
    def _wrapped(args):
        try:
            return fn(**(args or {}))
        except TypeError as e:
            return {"ok": False, "error": f"bad args: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    _wrapped.__name__ = getattr(fn, "__name__", "tool")
    _wrapped.__doc__ = fn.__doc__
    return _wrapped


EXTRA_TOOLS = {k: _adapt_devtool(v) for k, v in EXTRA_TOOLS.items()}
