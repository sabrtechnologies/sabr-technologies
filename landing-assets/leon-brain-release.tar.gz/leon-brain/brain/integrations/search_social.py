"""search_social.py — Leon's web search + social media hub.

Web search engines (Brave Search, DuckDuckGo, SerpApi, Kagi, You.com, Tavily)
plus social platforms (Twitter/X v2, Reddit, Bluesky, Mastodon, LinkedIn,
YouTube deeper, News APIs). Style mirrors `comms.py`: lazy credential load
(env first, then `~/.openclaw/secrets.json`), single `requests` call with a
10s default timeout, never raises — every exception becomes
`{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `search.brave`,
`social.twitter_search`) to callables that take a single `dict` argument.

Credentials read (all optional — tools return helpful errors if missing):
  Web search:
    BRAVE_SEARCH_API_KEY, SERPAPI_KEY, KAGI_API_KEY, YOU_API_KEY, TAVILY_API_KEY
  Twitter/X:
    TWITTER_BEARER_TOKEN  (read)
    TWITTER_API_KEY, TWITTER_API_SECRET,
    TWITTER_ACCESS_TOKEN, TWITTER_ACCESS_TOKEN_SECRET  (OAuth1 user-context write)
  Reddit:
    REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET, REDDIT_USER_AGENT  (app)
    REDDIT_USER_OAUTH_TOKEN  (already-minted user token for write)
  Bluesky:
    BSKY_HANDLE, BSKY_APP_PASSWORD
  Mastodon:
    MASTODON_ACCESS_TOKEN
  LinkedIn:
    PROXYCURL_API_KEY  (third-party read)
    LINKEDIN_ACCESS_TOKEN  (post share)
  YouTube:
    YOUTUBE_API_KEY
  News:
    NEWSAPI_KEY, NYT_API_KEY

Secrets file fallback: `~/.openclaw/secrets.json` (flat JSON object).
"""

from __future__ import annotations

import base64
import html
import json
import os
import re
import time
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS / HELPERS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 10.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0

_UA = "LeonBot/1.0 (+47industries; brain/search_social)"


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and mtime-cache) the secrets JSON file. Never raises."""
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    v = _load_secrets_file().get(key)
    return v if v else None


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _wrap_http(resp: requests.Response) -> Dict[str, Any]:
    try:
        return {"status": resp.status_code, "json": resp.json()}
    except Exception:
        return {"status": resp.status_code, "text": resp.text[:2000]}


def _strip_html(s: str) -> str:
    """Cheap HTML tag stripper for snippet fields."""
    if not s:
        return ""
    s = re.sub(r"<[^>]+>", "", s)
    return html.unescape(s).strip()


# ──────────────────────────────────────────────────────────────────────────
# WEB SEARCH — BRAVE
# ──────────────────────────────────────────────────────────────────────────

_BRAVE_API = "https://api.search.brave.com/res/v1"


def _brave_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("BRAVE_SEARCH_API_KEY")
    if not tok:
        return None
    return {
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "X-Subscription-Token": tok,
        "User-Agent": _UA,
    }


def _search_brave(args: dict) -> dict:
    """Brave Web Search."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        count = max(1, min(20, int(args.get("count", 10))))
        headers = _brave_headers()
        if not headers:
            return _missing("BRAVE_SEARCH_API_KEY", "Brave Search")
        r = requests.get(
            f"{_BRAVE_API}/web/search",
            headers=headers,
            params={"q": query, "count": count},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        web = (data.get("web") or {}).get("results") or []
        results = [
            {
                "title": w.get("title"),
                "url": w.get("url"),
                "description": _strip_html(w.get("description", "")),
                "age": w.get("age"),
            }
            for w in web[:count]
        ]
        return {"ok": True, "count": len(results), "results": results}
    except Exception as e:
        return _err(e)


def _search_brave_news(args: dict) -> dict:
    """Brave News Search."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        count = max(1, min(20, int(args.get("count", 10))))
        headers = _brave_headers()
        if not headers:
            return _missing("BRAVE_SEARCH_API_KEY", "Brave Search")
        r = requests.get(
            f"{_BRAVE_API}/news/search",
            headers=headers,
            params={"q": query, "count": count},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        items = data.get("results") or []
        results = [
            {
                "title": n.get("title"),
                "url": n.get("url"),
                "description": _strip_html(n.get("description", "")),
                "age": n.get("age"),
                "source": (n.get("meta_url") or {}).get("hostname"),
            }
            for n in items[:count]
        ]
        return {"ok": True, "count": len(results), "results": results}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# WEB SEARCH — DUCKDUCKGO (free instant-answer API)
# ──────────────────────────────────────────────────────────────────────────

def _search_ddg(args: dict) -> dict:
    """DuckDuckGo Instant Answer API. No key required.

    Note: DDG's IA API only returns 'related topics', not full SERPs. Useful
    for a quick definition / disambiguation. For deeper results pair with
    Brave or SerpApi.
    """
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(1, min(30, int(args.get("limit", 10))))
        r = requests.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        results: List[Dict[str, Any]] = []
        if data.get("AbstractText"):
            results.append({
                "title": data.get("Heading") or query,
                "url": data.get("AbstractURL"),
                "description": data.get("AbstractText"),
                "source": data.get("AbstractSource"),
                "kind": "abstract",
            })
        for t in (data.get("RelatedTopics") or []):
            if "Topics" in t:
                for sub in t.get("Topics", []):
                    if "FirstURL" in sub:
                        results.append({
                            "title": _strip_html(sub.get("Text", ""))[:120],
                            "url": sub.get("FirstURL"),
                            "description": _strip_html(sub.get("Text", "")),
                            "kind": "related",
                        })
            elif "FirstURL" in t:
                results.append({
                    "title": _strip_html(t.get("Text", ""))[:120],
                    "url": t.get("FirstURL"),
                    "description": _strip_html(t.get("Text", "")),
                    "kind": "related",
                })
            if len(results) >= limit:
                break
        return {"ok": True, "count": len(results), "results": results[:limit]}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# WEB SEARCH — SERPAPI
# ──────────────────────────────────────────────────────────────────────────

def _search_serpapi(args: dict) -> dict:
    """SerpApi (Google/Bing/etc.). Needs SERPAPI_KEY."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        engine = str(args.get("engine", "google")).strip() or "google"
        key = _get_secret("SERPAPI_KEY")
        if not key:
            return _missing("SERPAPI_KEY", "SerpApi")
        r = requests.get(
            "https://serpapi.com/search.json",
            params={"q": query, "engine": engine, "api_key": key},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        organic = data.get("organic_results") or []
        results = [
            {
                "title": o.get("title"),
                "url": o.get("link"),
                "description": o.get("snippet"),
                "position": o.get("position"),
            }
            for o in organic
        ]
        return {
            "ok": True,
            "engine": engine,
            "count": len(results),
            "results": results,
            "answer_box": data.get("answer_box"),
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# WEB SEARCH — KAGI
# ──────────────────────────────────────────────────────────────────────────

def _search_kagi(args: dict) -> dict:
    """Kagi Search API. Needs KAGI_API_KEY (paid)."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(1, min(20, int(args.get("limit", 10))))
        key = _get_secret("KAGI_API_KEY")
        if not key:
            return _missing("KAGI_API_KEY", "Kagi")
        r = requests.get(
            "https://kagi.com/api/v0/search",
            headers={"Authorization": f"Bot {key}", "User-Agent": _UA},
            params={"q": query, "limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        items = data.get("data") or []
        results = []
        for it in items:
            if it.get("t") == 0:  # search result
                results.append({
                    "title": it.get("title"),
                    "url": it.get("url"),
                    "description": _strip_html(it.get("snippet", "")),
                })
        return {"ok": True, "count": len(results), "results": results[:limit]}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# WEB SEARCH — YOU.COM
# ──────────────────────────────────────────────────────────────────────────

def _search_you(args: dict) -> dict:
    """You.com Search API. Needs YOU_API_KEY."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(1, min(20, int(args.get("limit", 10))))
        key = _get_secret("YOU_API_KEY")
        if not key:
            return _missing("YOU_API_KEY", "You.com")
        r = requests.get(
            "https://api.ydc-index.io/search",
            headers={"X-API-Key": key, "User-Agent": _UA},
            params={"query": query, "num_web_results": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        hits = ((data.get("hits") or []) if isinstance(data, dict) else [])
        results = [
            {
                "title": h.get("title"),
                "url": h.get("url"),
                "description": _strip_html(" ".join(h.get("snippets", []) or [])),
            }
            for h in hits[:limit]
        ]
        return {"ok": True, "count": len(results), "results": results}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# WEB SEARCH — TAVILY (AI-agent oriented)
# ──────────────────────────────────────────────────────────────────────────

def _search_tavily(args: dict) -> dict:
    """Tavily Search — designed for AI agents. Needs TAVILY_API_KEY."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        max_results = max(1, min(20, int(args.get("max_results", 10))))
        key = _get_secret("TAVILY_API_KEY")
        if not key:
            return _missing("TAVILY_API_KEY", "Tavily")
        r = requests.post(
            "https://api.tavily.com/search",
            json={
                "api_key": key,
                "query": query,
                "max_results": max_results,
                "include_answer": True,
            },
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        items = data.get("results") or []
        results = [
            {
                "title": it.get("title"),
                "url": it.get("url"),
                "description": it.get("content"),
                "score": it.get("score"),
            }
            for it in items
        ]
        return {
            "ok": True,
            "answer": data.get("answer"),
            "count": len(results),
            "results": results,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TWITTER / X (v2 API)
# ──────────────────────────────────────────────────────────────────────────

_TW_API = "https://api.twitter.com/2"


def _tw_bearer_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("TWITTER_BEARER_TOKEN")
    if not tok:
        return None
    return {"Authorization": f"Bearer {tok}", "User-Agent": _UA}


def _twitter_search(args: dict) -> dict:
    """Recent search (last 7 days). Needs TWITTER_BEARER_TOKEN."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(10, min(100, int(args.get("limit", 20))))
        headers = _tw_bearer_headers()
        if not headers:
            return _missing("TWITTER_BEARER_TOKEN", "Twitter/X")
        r = requests.get(
            f"{_TW_API}/tweets/search/recent",
            headers=headers,
            params={
                "query": query,
                "max_results": limit,
                "tweet.fields": "created_at,public_metrics,author_id,lang",
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        tweets = data.get("data") or []
        return {"ok": True, "count": len(tweets), "tweets": tweets}
    except Exception as e:
        return _err(e)


def _twitter_user(args: dict) -> dict:
    """Lookup user by handle. Needs TWITTER_BEARER_TOKEN."""
    try:
        handle = str(args.get("handle", "")).lstrip("@").strip()
        if not handle:
            return {"ok": False, "error": "handle required"}
        headers = _tw_bearer_headers()
        if not headers:
            return _missing("TWITTER_BEARER_TOKEN", "Twitter/X")
        r = requests.get(
            f"{_TW_API}/users/by/username/{handle}",
            headers=headers,
            params={"user.fields": "description,public_metrics,verified,created_at,location"},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "user": (r.json().get("data") or {})}
    except Exception as e:
        return _err(e)


def _twitter_user_tweets(args: dict) -> dict:
    """Fetch recent tweets for a handle. Needs TWITTER_BEARER_TOKEN."""
    try:
        handle = str(args.get("handle", "")).lstrip("@").strip()
        if not handle:
            return {"ok": False, "error": "handle required"}
        limit = max(5, min(100, int(args.get("limit", 20))))
        # Resolve user id first.
        u = _twitter_user({"handle": handle})
        if not u.get("ok"):
            return u
        user_id = (u.get("user") or {}).get("id")
        if not user_id:
            return {"ok": False, "error": "user id not found for handle"}
        headers = _tw_bearer_headers()
        if not headers:
            return _missing("TWITTER_BEARER_TOKEN", "Twitter/X")
        r = requests.get(
            f"{_TW_API}/users/{user_id}/tweets",
            headers=headers,
            params={
                "max_results": limit,
                "tweet.fields": "created_at,public_metrics,lang",
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {
            "ok": True,
            "user_id": user_id,
            "count": len(data.get("data") or []),
            "tweets": data.get("data") or [],
        }
    except Exception as e:
        return _err(e)


def _twitter_trending(args: dict) -> dict:
    """Trends by WOEID (1=Worldwide, 23424977=US). Uses v1.1 trends endpoint
    via bearer token. Twitter has been deprecating this; falls back to error
    with a friendly message on 4xx."""
    try:
        woeid = int(args.get("woeid", 1))
        headers = _tw_bearer_headers()
        if not headers:
            return _missing("TWITTER_BEARER_TOKEN", "Twitter/X")
        r = requests.get(
            "https://api.twitter.com/1.1/trends/place.json",
            headers=headers,
            params={"id": woeid},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {
                "ok": False,
                "error": f"HTTP {r.status_code} — trends/place may be unavailable on your plan",
                **_wrap_http(r),
            }
        data = r.json()
        if not isinstance(data, list) or not data:
            return {"ok": False, "error": "empty response", "raw": data}
        trends = data[0].get("trends") or []
        return {
            "ok": True,
            "woeid": woeid,
            "as_of": data[0].get("as_of"),
            "count": len(trends),
            "trends": [
                {"name": t.get("name"), "url": t.get("url"),
                 "tweet_volume": t.get("tweet_volume")}
                for t in trends
            ],
        }
    except Exception as e:
        return _err(e)


def _twitter_post(args: dict) -> dict:
    """Post a tweet (or reply). HIGH risk.

    Needs OAuth 1.0a user context: TWITTER_API_KEY, TWITTER_API_SECRET,
    TWITTER_ACCESS_TOKEN, TWITTER_ACCESS_TOKEN_SECRET. Uses requests-oauthlib
    if available, otherwise returns a helpful error.
    """
    try:
        text = str(args.get("text", "")).strip()
        if not text:
            return {"ok": False, "error": "text required"}
        reply_to_id = args.get("reply_to_id")
        ck = _get_secret("TWITTER_API_KEY")
        cs = _get_secret("TWITTER_API_SECRET")
        at = _get_secret("TWITTER_ACCESS_TOKEN")
        ats = _get_secret("TWITTER_ACCESS_TOKEN_SECRET")
        missing = [n for n, v in [
            ("TWITTER_API_KEY", ck), ("TWITTER_API_SECRET", cs),
            ("TWITTER_ACCESS_TOKEN", at), ("TWITTER_ACCESS_TOKEN_SECRET", ats),
        ] if not v]
        if missing:
            return {
                "ok": False,
                "error": "credentials missing — needs " + ", ".join(missing) +
                         " (OAuth1 user context) for Twitter/X writes",
            }
        try:
            from requests_oauthlib import OAuth1
        except Exception:
            return {
                "ok": False,
                "error": "requests_oauthlib not installed — `pip install requests-oauthlib`",
            }
        auth = OAuth1(ck, cs, at, ats)
        payload: Dict[str, Any] = {"text": text[:280]}
        if reply_to_id:
            payload["reply"] = {"in_reply_to_tweet_id": str(reply_to_id)}
        r = requests.post(
            f"{_TW_API}/tweets",
            auth=auth,
            json=payload,
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json().get("data") or {}
        return {"ok": True, "tweet_id": data.get("id"), "text": data.get("text")}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# REDDIT
# ──────────────────────────────────────────────────────────────────────────

_REDDIT_OAUTH = "https://oauth.reddit.com"
_REDDIT_PUBLIC = "https://www.reddit.com"


def _reddit_ua() -> str:
    return _get_secret("REDDIT_USER_AGENT") or "LeonBot/1.0 by 47industries"


def _reddit_app_token() -> Optional[str]:
    """Mint a script-app token from REDDIT_CLIENT_ID/SECRET, cached briefly."""
    cid = _get_secret("REDDIT_CLIENT_ID")
    csec = _get_secret("REDDIT_CLIENT_SECRET")
    if not (cid and csec):
        return None
    try:
        r = requests.post(
            "https://www.reddit.com/api/v1/access_token",
            auth=(cid, csec),
            data={"grant_type": "client_credentials"},
            headers={"User-Agent": _reddit_ua()},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return None
        return r.json().get("access_token")
    except Exception:
        return None


def _reddit_user_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("REDDIT_USER_OAUTH_TOKEN")
    if not tok:
        return None
    return {"Authorization": f"Bearer {tok}", "User-Agent": _reddit_ua()}


def _reddit_subreddit_about(args: dict) -> dict:
    """GET /r/{name}/about — sidebar/meta. No auth required."""
    try:
        name = str(args.get("name", "")).lstrip("/").lstrip("r/").strip()
        if not name:
            return {"ok": False, "error": "name required"}
        r = requests.get(
            f"{_REDDIT_PUBLIC}/r/{name}/about.json",
            headers={"User-Agent": _reddit_ua()},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = (r.json().get("data") or {})
        return {
            "ok": True,
            "name": data.get("display_name"),
            "title": data.get("title"),
            "subscribers": data.get("subscribers"),
            "active": data.get("active_user_count"),
            "description": data.get("public_description"),
            "over18": data.get("over18"),
            "created_utc": data.get("created_utc"),
            "url": f"https://reddit.com/r/{data.get('display_name')}",
        }
    except Exception as e:
        return _err(e)


def _reddit_subscribe(args: dict) -> dict:
    """Subscribe to a subreddit. MEDIUM risk.
    Needs REDDIT_USER_OAUTH_TOKEN.
    """
    try:
        name = str(args.get("name", "")).lstrip("/").lstrip("r/").strip()
        if not name:
            return {"ok": False, "error": "name required"}
        headers = _reddit_user_headers()
        if not headers:
            return _missing("REDDIT_USER_OAUTH_TOKEN", "Reddit (user)")
        r = requests.post(
            f"{_REDDIT_OAUTH}/api/subscribe",
            headers=headers,
            data={"action": "sub", "sr_name": name},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "subreddit": name, "action": "sub"}
    except Exception as e:
        return _err(e)


def _reddit_post(args: dict) -> dict:
    """Submit a post. HIGH risk. Needs REDDIT_USER_OAUTH_TOKEN."""
    try:
        sub = str(args.get("subreddit", "")).lstrip("/").lstrip("r/").strip()
        title = str(args.get("title", "")).strip()
        text = args.get("text")
        url = args.get("url")
        if not sub or not title:
            return {"ok": False, "error": "subreddit and title required"}
        if not text and not url:
            return {"ok": False, "error": "either text or url required"}
        headers = _reddit_user_headers()
        if not headers:
            return _missing("REDDIT_USER_OAUTH_TOKEN", "Reddit (user)")
        form: Dict[str, Any] = {
            "sr": sub,
            "title": title[:300],
            "api_type": "json",
            "kind": "self" if text else "link",
        }
        if text:
            form["text"] = str(text)
        if url:
            form["url"] = str(url)
        r = requests.post(
            f"{_REDDIT_OAUTH}/api/submit",
            headers=headers,
            data=form,
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "response": data}
    except Exception as e:
        return _err(e)


def _reddit_comment(args: dict) -> dict:
    """Post a comment. HIGH risk. Needs REDDIT_USER_OAUTH_TOKEN."""
    try:
        post_id = str(args.get("post_id", "")).strip()
        text = str(args.get("text", "")).strip()
        if not post_id or not text:
            return {"ok": False, "error": "post_id and text required"}
        # Reddit "thing" prefix t3_ for link, t1_ for comment.
        thing_id = post_id if post_id.startswith(("t1_", "t3_")) else f"t3_{post_id}"
        headers = _reddit_user_headers()
        if not headers:
            return _missing("REDDIT_USER_OAUTH_TOKEN", "Reddit (user)")
        r = requests.post(
            f"{_REDDIT_OAUTH}/api/comment",
            headers=headers,
            data={"thing_id": thing_id, "text": text, "api_type": "json"},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "response": r.json()}
    except Exception as e:
        return _err(e)


def _reddit_inbox(args: dict) -> dict:
    """Fetch the authed user's inbox. Needs REDDIT_USER_OAUTH_TOKEN."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
        headers = _reddit_user_headers()
        if not headers:
            return _missing("REDDIT_USER_OAUTH_TOKEN", "Reddit (user)")
        r = requests.get(
            f"{_REDDIT_OAUTH}/message/inbox",
            headers=headers,
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        children = ((data.get("data") or {}).get("children") or [])
        items = [c.get("data") for c in children]
        return {"ok": True, "count": len(items), "messages": items}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# BLUESKY (AT Protocol)
# ──────────────────────────────────────────────────────────────────────────

_BSKY_API = "https://bsky.social/xrpc"


def _bsky_session() -> Optional[Dict[str, Any]]:
    """Create an app-password session. Cached in module memory for ~10 min."""
    handle = _get_secret("BSKY_HANDLE")
    pw = _get_secret("BSKY_APP_PASSWORD")
    if not (handle and pw):
        return None
    global _BSKY_SESSION_CACHE
    now = time.time()
    cache = globals().get("_BSKY_SESSION_CACHE")
    if cache and cache.get("expires_at", 0) > now:
        return cache
    try:
        r = requests.post(
            f"{_BSKY_API}/com.atproto.server.createSession",
            json={"identifier": handle, "password": pw},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return None
        data = r.json()
        sess = {
            "accessJwt": data.get("accessJwt"),
            "did": data.get("did"),
            "handle": data.get("handle"),
            "expires_at": now + 600,
        }
        globals()["_BSKY_SESSION_CACHE"] = sess
        return sess
    except Exception:
        return None


def _bluesky_feed_timeline(args: dict) -> dict:
    """Fetch the authed user's home timeline. Needs BSKY_HANDLE + BSKY_APP_PASSWORD."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
        sess = _bsky_session()
        if not sess:
            return _missing("BSKY_HANDLE/BSKY_APP_PASSWORD", "Bluesky")
        r = requests.get(
            f"{_BSKY_API}/app.bsky.feed.getTimeline",
            headers={
                "Authorization": f"Bearer {sess['accessJwt']}",
                "User-Agent": _UA,
            },
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        feed = data.get("feed") or []
        items = []
        for f in feed[:limit]:
            post = (f.get("post") or {})
            rec = (post.get("record") or {})
            author = (post.get("author") or {})
            items.append({
                "uri": post.get("uri"),
                "author_handle": author.get("handle"),
                "author_name": author.get("displayName"),
                "text": rec.get("text"),
                "created_at": rec.get("createdAt"),
                "like_count": post.get("likeCount"),
                "repost_count": post.get("repostCount"),
                "reply_count": post.get("replyCount"),
            })
        return {"ok": True, "count": len(items), "posts": items}
    except Exception as e:
        return _err(e)


def _bluesky_post(args: dict) -> dict:
    """Create a post. MEDIUM risk. Needs BSKY_HANDLE + BSKY_APP_PASSWORD."""
    try:
        text = str(args.get("text", "")).strip()
        if not text:
            return {"ok": False, "error": "text required"}
        sess = _bsky_session()
        if not sess:
            return _missing("BSKY_HANDLE/BSKY_APP_PASSWORD", "Bluesky")
        now_iso = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())
        record = {
            "$type": "app.bsky.feed.post",
            "text": text[:300],
            "createdAt": now_iso,
        }
        r = requests.post(
            f"{_BSKY_API}/com.atproto.repo.createRecord",
            headers={
                "Authorization": f"Bearer {sess['accessJwt']}",
                "Content-Type": "application/json",
                "User-Agent": _UA,
            },
            json={
                "repo": sess["did"],
                "collection": "app.bsky.feed.post",
                "record": record,
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "uri": data.get("uri"), "cid": data.get("cid")}
    except Exception as e:
        return _err(e)


def _bluesky_user(args: dict) -> dict:
    """Lookup a Bluesky profile by handle. Public; no auth required."""
    try:
        handle = str(args.get("handle", "")).lstrip("@").strip()
        if not handle:
            return {"ok": False, "error": "handle required"}
        # Public AppView is fine for profiles.
        r = requests.get(
            "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile",
            params={"actor": handle},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {
            "ok": True,
            "handle": data.get("handle"),
            "did": data.get("did"),
            "display_name": data.get("displayName"),
            "description": data.get("description"),
            "followers": data.get("followersCount"),
            "follows": data.get("followsCount"),
            "posts": data.get("postsCount"),
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# MASTODON
# ──────────────────────────────────────────────────────────────────────────

def _mastodon_post(args: dict) -> dict:
    """Create a status. MEDIUM risk. Needs MASTODON_ACCESS_TOKEN."""
    try:
        text = str(args.get("text", "")).strip()
        if not text:
            return {"ok": False, "error": "text required"}
        instance = str(args.get("instance", "mastodon.social")).strip().rstrip("/")
        if not instance.startswith("http"):
            instance = f"https://{instance}"
        tok = _get_secret("MASTODON_ACCESS_TOKEN")
        if not tok:
            return _missing("MASTODON_ACCESS_TOKEN", "Mastodon")
        r = requests.post(
            f"{instance}/api/v1/statuses",
            headers={
                "Authorization": f"Bearer {tok}",
                "User-Agent": _UA,
            },
            data={"status": text[:500]},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {
            "ok": True,
            "id": data.get("id"),
            "url": data.get("url"),
            "created_at": data.get("created_at"),
        }
    except Exception as e:
        return _err(e)


def _mastodon_feed_timeline(args: dict) -> dict:
    """Fetch the home timeline. Needs MASTODON_ACCESS_TOKEN."""
    try:
        instance = str(args.get("instance", "mastodon.social")).strip().rstrip("/")
        if not instance.startswith("http"):
            instance = f"https://{instance}"
        limit = max(1, min(40, int(args.get("limit", 20))))
        tok = _get_secret("MASTODON_ACCESS_TOKEN")
        if not tok:
            return _missing("MASTODON_ACCESS_TOKEN", "Mastodon")
        r = requests.get(
            f"{instance}/api/v1/timelines/home",
            headers={"Authorization": f"Bearer {tok}", "User-Agent": _UA},
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        statuses = r.json() or []
        items = [
            {
                "id": s.get("id"),
                "url": s.get("url"),
                "account": (s.get("account") or {}).get("acct"),
                "content": _strip_html(s.get("content", "")),
                "created_at": s.get("created_at"),
                "favourites": s.get("favourites_count"),
                "reblogs": s.get("reblogs_count"),
                "replies": s.get("replies_count"),
            }
            for s in statuses[:limit]
        ]
        return {"ok": True, "count": len(items), "statuses": items}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# LINKEDIN (very limited free)
# ──────────────────────────────────────────────────────────────────────────

def _linkedin_profile_lookup(args: dict) -> dict:
    """Look up a LinkedIn profile via Proxycurl. Needs PROXYCURL_API_KEY."""
    try:
        target = str(args.get("handle_or_url", "")).strip()
        if not target:
            return {"ok": False, "error": "handle_or_url required"}
        key = _get_secret("PROXYCURL_API_KEY")
        if not key:
            return _missing("PROXYCURL_API_KEY", "LinkedIn (Proxycurl)")
        # Accept bare handle, vanity name, or full URL.
        if target.startswith("http"):
            url = target
        else:
            handle = target.lstrip("@").lstrip("/")
            handle = handle.replace("in/", "")
            url = f"https://www.linkedin.com/in/{handle}/"
        r = requests.get(
            "https://nubela.co/proxycurl/api/v2/linkedin",
            headers={"Authorization": f"Bearer {key}", "User-Agent": _UA},
            params={"url": url, "use_cache": "if-present"},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {
            "ok": True,
            "url": url,
            "full_name": data.get("full_name"),
            "headline": data.get("headline"),
            "occupation": data.get("occupation"),
            "summary": data.get("summary"),
            "country": data.get("country_full_name"),
            "experiences": data.get("experiences"),
            "education": data.get("education"),
        }
    except Exception as e:
        return _err(e)


def _linkedin_post(args: dict) -> dict:
    """Share a text post on LinkedIn. MEDIUM risk. Needs LINKEDIN_ACCESS_TOKEN
    (and the token's owner URN — fetched via /v2/userinfo)."""
    try:
        text = str(args.get("text", "")).strip()
        if not text:
            return {"ok": False, "error": "text required"}
        tok = _get_secret("LINKEDIN_ACCESS_TOKEN")
        if not tok:
            return _missing("LINKEDIN_ACCESS_TOKEN", "LinkedIn")
        headers = {
            "Authorization": f"Bearer {tok}",
            "X-Restli-Protocol-Version": "2.0.0",
            "Content-Type": "application/json",
            "User-Agent": _UA,
        }
        # Resolve author URN.
        ui = requests.get(
            "https://api.linkedin.com/v2/userinfo",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if ui.status_code >= 400:
            return {"ok": False, "error": f"userinfo HTTP {ui.status_code}", **_wrap_http(ui)}
        sub = ui.json().get("sub")
        if not sub:
            return {"ok": False, "error": "could not resolve LinkedIn user URN"}
        author = f"urn:li:person:{sub}"
        body = {
            "author": author,
            "lifecycleState": "PUBLISHED",
            "specificContent": {
                "com.linkedin.ugc.ShareContent": {
                    "shareCommentary": {"text": text[:3000]},
                    "shareMediaCategory": "NONE",
                }
            },
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"},
        }
        r = requests.post(
            "https://api.linkedin.com/v2/ugcPosts",
            headers=headers,
            json=body,
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {
            "ok": True,
            "id": r.headers.get("x-restli-id") or r.json().get("id"),
            "author": author,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# YOUTUBE (deeper)
# ──────────────────────────────────────────────────────────────────────────

_YT_API = "https://www.googleapis.com/youtube/v3"


def _youtube_channel_stats(args: dict) -> dict:
    """Get channel stats by id or @handle. Needs YOUTUBE_API_KEY."""
    try:
        ident = str(args.get("channel_id_or_handle", "")).strip()
        if not ident:
            return {"ok": False, "error": "channel_id_or_handle required"}
        key = _get_secret("YOUTUBE_API_KEY")
        if not key:
            return _missing("YOUTUBE_API_KEY", "YouTube")
        params: Dict[str, Any] = {
            "part": "snippet,statistics,brandingSettings",
            "key": key,
        }
        if ident.startswith("@"):
            params["forHandle"] = ident
        elif ident.startswith("UC") and len(ident) >= 20:
            params["id"] = ident
        else:
            params["forHandle"] = "@" + ident.lstrip("@")
        r = requests.get(
            f"{_YT_API}/channels",
            params=params,
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        items = r.json().get("items") or []
        if not items:
            return {"ok": False, "error": "channel not found"}
        ch = items[0]
        return {
            "ok": True,
            "id": ch.get("id"),
            "title": (ch.get("snippet") or {}).get("title"),
            "description": (ch.get("snippet") or {}).get("description"),
            "custom_url": (ch.get("snippet") or {}).get("customUrl"),
            "subscribers": (ch.get("statistics") or {}).get("subscriberCount"),
            "videos": (ch.get("statistics") or {}).get("videoCount"),
            "views": (ch.get("statistics") or {}).get("viewCount"),
        }
    except Exception as e:
        return _err(e)


def _youtube_video_info(args: dict) -> dict:
    """Get video metadata by id. Needs YOUTUBE_API_KEY."""
    try:
        vid = str(args.get("video_id", "")).strip()
        if not vid:
            return {"ok": False, "error": "video_id required"}
        key = _get_secret("YOUTUBE_API_KEY")
        if not key:
            return _missing("YOUTUBE_API_KEY", "YouTube")
        r = requests.get(
            f"{_YT_API}/videos",
            params={
                "part": "snippet,statistics,contentDetails",
                "id": vid,
                "key": key,
            },
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        items = r.json().get("items") or []
        if not items:
            return {"ok": False, "error": "video not found"}
        v = items[0]
        return {
            "ok": True,
            "id": v.get("id"),
            "title": (v.get("snippet") or {}).get("title"),
            "channel": (v.get("snippet") or {}).get("channelTitle"),
            "channel_id": (v.get("snippet") or {}).get("channelId"),
            "published": (v.get("snippet") or {}).get("publishedAt"),
            "description": (v.get("snippet") or {}).get("description"),
            "tags": (v.get("snippet") or {}).get("tags") or [],
            "duration": (v.get("contentDetails") or {}).get("duration"),
            "views": (v.get("statistics") or {}).get("viewCount"),
            "likes": (v.get("statistics") or {}).get("likeCount"),
            "comments": (v.get("statistics") or {}).get("commentCount"),
        }
    except Exception as e:
        return _err(e)


def _youtube_video_comments(args: dict) -> dict:
    """Top-level comments for a video. Needs YOUTUBE_API_KEY."""
    try:
        vid = str(args.get("video_id", "")).strip()
        if not vid:
            return {"ok": False, "error": "video_id required"}
        limit = max(1, min(100, int(args.get("limit", 20))))
        key = _get_secret("YOUTUBE_API_KEY")
        if not key:
            return _missing("YOUTUBE_API_KEY", "YouTube")
        r = requests.get(
            f"{_YT_API}/commentThreads",
            params={
                "part": "snippet",
                "videoId": vid,
                "maxResults": limit,
                "order": "relevance",
                "textFormat": "plainText",
                "key": key,
            },
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        items = r.json().get("items") or []
        out = []
        for it in items:
            top = ((it.get("snippet") or {}).get("topLevelComment") or {})
            snip = (top.get("snippet") or {})
            out.append({
                "id": top.get("id"),
                "author": snip.get("authorDisplayName"),
                "text": snip.get("textDisplay"),
                "likes": snip.get("likeCount"),
                "published": snip.get("publishedAt"),
            })
        return {"ok": True, "count": len(out), "comments": out}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# NEWS
# ──────────────────────────────────────────────────────────────────────────

def _news_newsapi(args: dict) -> dict:
    """NewsAPI.org /v2/everything. Needs NEWSAPI_KEY."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        page = max(1, int(args.get("page", 1)))
        key = _get_secret("NEWSAPI_KEY")
        if not key:
            return _missing("NEWSAPI_KEY", "NewsAPI")
        r = requests.get(
            "https://newsapi.org/v2/everything",
            params={"q": query, "page": page, "pageSize": 20, "sortBy": "publishedAt"},
            headers={"X-Api-Key": key, "User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        arts = data.get("articles") or []
        results = [
            {
                "title": a.get("title"),
                "url": a.get("url"),
                "description": a.get("description"),
                "source": (a.get("source") or {}).get("name"),
                "published": a.get("publishedAt"),
                "author": a.get("author"),
            }
            for a in arts
        ]
        return {
            "ok": True,
            "total": data.get("totalResults"),
            "page": page,
            "count": len(results),
            "articles": results,
        }
    except Exception as e:
        return _err(e)


def _news_nytimes(args: dict) -> dict:
    """NYTimes Article Search. Needs NYT_API_KEY."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        page = max(0, int(args.get("page", 0)))
        key = _get_secret("NYT_API_KEY")
        if not key:
            return _missing("NYT_API_KEY", "NYTimes")
        r = requests.get(
            "https://api.nytimes.com/svc/search/v2/articlesearch.json",
            params={"q": query, "page": page, "api-key": key},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        docs = ((data.get("response") or {}).get("docs") or [])
        results = [
            {
                "title": (d.get("headline") or {}).get("main"),
                "url": d.get("web_url"),
                "abstract": d.get("abstract"),
                "lead": d.get("lead_paragraph"),
                "published": d.get("pub_date"),
                "section": d.get("section_name"),
                "byline": (d.get("byline") or {}).get("original"),
            }
            for d in docs
        ]
        return {
            "ok": True,
            "page": page,
            "count": len(results),
            "articles": results,
        }
    except Exception as e:
        return _err(e)


def _news_bbc_top(args: dict) -> dict:
    """BBC top stories via public RSS. No key required."""
    try:
        r = requests.get(
            "https://feeds.bbci.co.uk/news/rss.xml",
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", "text": r.text[:500]}
        root = ET.fromstring(r.content)
        channel = root.find("channel")
        items = channel.findall("item") if channel is not None else []
        out = []
        for it in items[:30]:
            out.append({
                "title": (it.findtext("title") or "").strip(),
                "url": (it.findtext("link") or "").strip(),
                "description": _strip_html(it.findtext("description") or ""),
                "published": (it.findtext("pubDate") or "").strip(),
            })
        return {"ok": True, "count": len(out), "articles": out}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS — dotted-name registry consumed by the responder / MCP server
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Web search
    "search.brave": _search_brave,
    "search.brave_news": _search_brave_news,
    "search.ddg": _search_ddg,
    "search.serpapi": _search_serpapi,
    "search.kagi": _search_kagi,
    "search.you": _search_you,
    "search.tavily": _search_tavily,

    # Twitter / X
    "social.twitter_search": _twitter_search,
    "social.twitter_user": _twitter_user,
    "social.twitter_user_tweets": _twitter_user_tweets,
    "social.twitter_trending": _twitter_trending,
    "social.twitter_post": _twitter_post,

    # Reddit
    "social.reddit_subreddit_about": _reddit_subreddit_about,
    "social.reddit_subscribe": _reddit_subscribe,
    "social.reddit_post": _reddit_post,
    "social.reddit_comment": _reddit_comment,
    "social.reddit_inbox": _reddit_inbox,

    # Bluesky
    "social.bluesky_feed_timeline": _bluesky_feed_timeline,
    "social.bluesky_post": _bluesky_post,
    "social.bluesky_user": _bluesky_user,

    # Mastodon
    "social.mastodon_post": _mastodon_post,
    "social.mastodon_feed_timeline": _mastodon_feed_timeline,

    # LinkedIn
    "social.linkedin_profile_lookup": _linkedin_profile_lookup,
    "social.linkedin_post": _linkedin_post,

    # YouTube (deeper)
    "social.youtube_channel_stats": _youtube_channel_stats,
    "social.youtube_video_info": _youtube_video_info,
    "social.youtube_video_comments": _youtube_video_comments,

    # News
    "social.news_newsapi": _news_newsapi,
    "social.news_nytimes": _news_nytimes,
    "social.news_bbc_top": _news_bbc_top,
}
