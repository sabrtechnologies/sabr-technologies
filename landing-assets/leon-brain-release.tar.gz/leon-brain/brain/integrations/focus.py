"""
focus.py — Leon's focus enforcement & distraction control surface.

Gives Leon teeth: it can block distracting websites (via the system
hosts file), kill distracting apps, run timed deep-work sessions, log
distractions, track screen time, and score how focused Dean's day was.

Persistence is local SQLite at `brain_state/focus.db` (auto-created on
first call). Website blocks are written to a managed section of
`/etc/hosts` between `# LEON-BLOCK-START` and `# LEON-BLOCK-END`. That
needs root, so a fallback user-level block list is ALWAYS kept at
`brain_state/blocklist.json`; if `/etc/hosts` isn't writable, the tool
returns a clear message plus the exact `pkexec`/`sudo` command Dean can
run to apply the block himself.

Each tool takes a single `args` dict and returns `{"ok": True, ...}` or
`{"ok": False, "error": "..."}`. Tools never raise — every entry point
is wrapped. The `EXTRA_TOOLS` dict at the bottom maps dotted tool names
(`focus.block_website`, `focus.session_start`, ...) to implementations.

Style matches `brain/integrations/productivity.py` (SQLite-backed) and
`brain/integrations/pc_control.py` (process inspection / killing).
"""

from __future__ import annotations

import json
import os
import shutil
import signal
import sqlite3
import subprocess
import threading
import time
import traceback
from datetime import datetime, date, timedelta
from typing import Any, Callable, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────────
# PATHS & CONNECTION
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/) — this file is brain/integrations/focus.py."""
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _brain_state_dir() -> str:
    d = os.path.join(_project_root(), "brain_state")
    os.makedirs(d, exist_ok=True)
    return d


def _db_path() -> str:
    return os.path.join(_brain_state_dir(), "focus.db")


def _blocklist_json_path() -> str:
    return os.path.join(_brain_state_dir(), "blocklist.json")


HOSTS_PATH = "/etc/hosts"
BLOCK_START = "# LEON-BLOCK-START"
BLOCK_END = "# LEON-BLOCK-END"
HOSTS_REDIRECT = "127.0.0.1"


_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS focus_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,
    duration_min INTEGER NOT NULL,
    block_preset TEXT,
    started_at REAL DEFAULT (strftime('%s','now')),
    ends_at REAL,
    ended_at REAL,
    status TEXT DEFAULT 'active',
    distraction_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS distractions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    note TEXT,
    session_id INTEGER,
    logged_at REAL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS blocked_sites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT NOT NULL UNIQUE,
    preset TEXT,
    expires_at REAL,
    created_at REAL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS blocked_apps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    app_name TEXT NOT NULL UNIQUE,
    expires_at REAL,
    created_at REAL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS screen_limits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    app TEXT NOT NULL UNIQUE,
    limit_min INTEGER NOT NULL,
    created_at REAL DEFAULT (strftime('%s','now'))
);
"""


def _conn() -> sqlite3.Connection:
    """Process-wide singleton connection, schema ensured."""
    global _DB_CONN
    if _DB_CONN is None:
        _DB_CONN = sqlite3.connect(_db_path(), check_same_thread=False)
        _DB_CONN.row_factory = sqlite3.Row
        _DB_CONN.executescript(_SCHEMA_SQL)
        _DB_CONN.commit()
    return _DB_CONN


def _tool(fn: Callable[[Dict[str, Any]], Dict[str, Any]]) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    """Wrap a tool so it can never raise and always serializes cleanly."""

    def wrapped(args: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        try:
            with _DB_LOCK:
                result = fn(args or {})
            if not isinstance(result, dict):
                return {"ok": True, "result": result}
            result.setdefault("ok", True)
            return result
        except Exception as e:  # noqa: BLE001 — tools must never raise
            return {
                "ok": False,
                "error": f"{type(e).__name__}: {e}",
                "trace": traceback.format_exc().splitlines()[-3:],
            }

    wrapped.__name__ = getattr(fn, "__name__", "tool")
    return wrapped


# ──────────────────────────────────────────────────────────────────────────
# GENERIC HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _now() -> float:
    return time.time()


def _today_start() -> float:
    return datetime.combine(date.today(), datetime.min.time()).timestamp()


def _fmt_dur(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m}m"
    if m:
        return f"{m}m {s}s"
    return f"{s}s"


def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _norm_domain(domain: str) -> str:
    """Strip scheme, path, leading www. — leave a bare hostname."""
    d = (domain or "").strip().lower()
    for pre in ("https://", "http://"):
        if d.startswith(pre):
            d = d[len(pre):]
    d = d.split("/")[0].split("?")[0]
    if d.startswith("www."):
        d = d[4:]
    return d


# Presets: dotted-name -> list of bare domains.
_PRESETS: Dict[str, List[str]] = {
    "social": [
        "twitter.com", "x.com", "instagram.com", "facebook.com",
        "tiktok.com", "reddit.com", "snapchat.com", "threads.net",
    ],
    "news": [
        "cnn.com", "bbc.com", "foxnews.com", "nytimes.com",
        "news.ycombinator.com", "theguardian.com", "reuters.com",
    ],
    "entertainment": [
        "youtube.com", "netflix.com", "twitch.tv", "hulu.com",
        "disneyplus.com", "9gag.com",
    ],
}
_PRESETS["all_distractions"] = sorted(
    set(_PRESETS["social"] + _PRESETS["news"] + _PRESETS["entertainment"])
)


# ──────────────────────────────────────────────────────────────────────────
# HOSTS FILE / BLOCKLIST HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _load_fallback_blocklist() -> List[str]:
    path = _blocklist_json_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            data = data.get("domains", [])
        return [str(x) for x in data]
    except Exception:
        return []


def _save_fallback_blocklist(domains: List[str]) -> None:
    path = _blocklist_json_path()
    payload = {
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "note": "Leon user-level fallback blocklist — applied to /etc/hosts when run with root.",
        "domains": sorted(set(domains)),
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)


def _hosts_block_text(domains: List[str]) -> str:
    """Build the managed-section body for /etc/hosts."""
    lines = [BLOCK_START, f"# Managed by Leon focus.py — edited {datetime.now().isoformat(timespec='seconds')}"]
    for d in sorted(set(domains)):
        if not d:
            continue
        lines.append(f"{HOSTS_REDIRECT} {d}")
        lines.append(f"{HOSTS_REDIRECT} www.{d}")
    lines.append(BLOCK_END)
    return "\n".join(lines)


def _strip_managed_section(text: str) -> str:
    """Remove an existing Leon managed block from hosts text."""
    out: List[str] = []
    skipping = False
    for line in text.splitlines():
        if line.strip() == BLOCK_START:
            skipping = True
            continue
        if line.strip() == BLOCK_END:
            skipping = False
            continue
        if not skipping:
            out.append(line)
    return "\n".join(out).rstrip() + "\n"


def _build_new_hosts(domains: List[str]) -> str:
    """Return the full desired /etc/hosts content given a domain list."""
    try:
        with open(HOSTS_PATH, "r", encoding="utf-8") as fh:
            current = fh.read()
    except Exception:
        current = "127.0.0.1 localhost\n"
    base = _strip_managed_section(current)
    if not domains:
        return base
    return base.rstrip() + "\n\n" + _hosts_block_text(domains) + "\n"


def _sudo_apply_command() -> str:
    """The command Dean can run to push the fallback blocklist into /etc/hosts."""
    script = os.path.abspath(__file__)
    helper = (
        "python3 -c \"import sys; sys.path.insert(0, '{root}'); "
        "from brain.integrations import focus; "
        "print(focus._apply_blocklist_to_hosts())\""
    ).format(root=_project_root())
    cmd = f"pkexec {helper}"
    return cmd if _have("pkexec") else f"sudo {helper}"


def _apply_blocklist_to_hosts() -> str:
    """Rewrite /etc/hosts managed section from the fallback blocklist + DB.

    Intended to be called as root (via the command from _sudo_apply_command).
    Returns a human-readable status string.
    """
    domains = _load_fallback_blocklist()
    try:
        rows = _conn().execute(
            "SELECT domain FROM blocked_sites "
            "WHERE expires_at IS NULL OR expires_at > ?",
            (_now(),),
        ).fetchall()
        domains = sorted(set(domains) | {r["domain"] for r in rows})
    except Exception:
        pass
    new_text = _build_new_hosts(domains)
    try:
        with open(HOSTS_PATH, "w", encoding="utf-8") as fh:
            fh.write(new_text)
        return f"Applied {len(domains)} blocked domain(s) to {HOSTS_PATH}."
    except PermissionError:
        return f"Permission denied writing {HOSTS_PATH} — run as root."
    except Exception as e:  # noqa: BLE001
        return f"Failed to write {HOSTS_PATH}: {e}"


def _try_write_hosts(domains: List[str]) -> Dict[str, Any]:
    """Attempt to write the managed section. Returns a status dict."""
    new_text = _build_new_hosts(domains)
    if os.access(HOSTS_PATH, os.W_OK):
        try:
            with open(HOSTS_PATH, "w", encoding="utf-8") as fh:
                fh.write(new_text)
            return {"hosts_applied": True, "domains_in_hosts": len(domains)}
        except Exception as e:  # noqa: BLE001
            return {
                "hosts_applied": False,
                "reason": f"write failed: {e}",
                "sudo_command": _sudo_apply_command(),
            }
    return {
        "hosts_applied": False,
        "reason": f"{HOSTS_PATH} not writable by this process (needs root)",
        "sudo_command": _sudo_apply_command(),
        "note": "Block saved to brain_state/blocklist.json — run the sudo_command to enforce it system-wide.",
    }


def _active_db_domains() -> List[str]:
    rows = _conn().execute(
        "SELECT domain FROM blocked_sites WHERE expires_at IS NULL OR expires_at > ?",
        (_now(),),
    ).fetchall()
    return [r["domain"] for r in rows]


def _sync_blocks() -> Dict[str, Any]:
    """Reconcile DB blocked_sites -> fallback json -> /etc/hosts (best effort)."""
    # purge expired
    _conn().execute(
        "DELETE FROM blocked_sites WHERE expires_at IS NOT NULL AND expires_at <= ?",
        (_now(),),
    )
    _conn().commit()
    domains = _active_db_domains()
    _save_fallback_blocklist(domains)
    status = _try_write_hosts(domains)
    status["domains"] = domains
    return status


# ──────────────────────────────────────────────────────────────────────────
# PROCESS HELPERS (app blocking)
# ──────────────────────────────────────────────────────────────────────────


def _list_processes() -> List[Dict[str, Any]]:
    """Return [{pid, name, cmd}] of running processes (best effort)."""
    procs: List[Dict[str, Any]] = []
    try:
        out = subprocess.run(
            ["ps", "-eo", "pid=,comm=,args="],
            capture_output=True, text=True, timeout=8,
        ).stdout
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(None, 2)
            if len(parts) < 2:
                continue
            pid = parts[0]
            name = parts[1]
            cmd = parts[2] if len(parts) > 2 else name
            if not pid.isdigit():
                continue
            procs.append({"pid": int(pid), "name": name, "cmd": cmd})
    except Exception:
        pass
    return procs


def _matching_pids(app_name: str) -> List[Dict[str, Any]]:
    """Find running processes whose comm or args matches app_name (case-insensitive)."""
    needle = (app_name or "").strip().lower()
    if not needle:
        return []
    hits: List[Dict[str, Any]] = []
    for p in _list_processes():
        if needle in p["name"].lower() or needle in p["cmd"].lower():
            hits.append(p)
    return hits


def _kill_pid(pid: int) -> bool:
    """SIGTERM then SIGKILL a pid. Returns True if it's gone."""
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return True
    except Exception:
        return False
    for _ in range(10):
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return True
        except Exception:
            return False
        time.sleep(0.1)
    try:
        os.kill(pid, signal.SIGKILL)
        return True
    except Exception:
        return False


def _active_blocked_apps() -> List[str]:
    rows = _conn().execute(
        "SELECT app_name FROM blocked_apps WHERE expires_at IS NULL OR expires_at > ?",
        (_now(),),
    ).fetchall()
    return [r["app_name"] for r in rows]


# ──────────────────────────────────────────────────────────────────────────
# SESSION HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _active_session() -> Optional[sqlite3.Row]:
    return _conn().execute(
        "SELECT * FROM focus_sessions WHERE status = 'active' "
        "ORDER BY id DESC LIMIT 1"
    ).fetchone()


# ──────────────────────────────────────────────────────────────────────────
# SCREEN-TIME HELPERS — best effort from window-focus logs in brain_state/
# ──────────────────────────────────────────────────────────────────────────


def _window_focus_log_path() -> Optional[str]:
    """Locate a window/active-window sampling log if one exists in brain_state/."""
    bs = _brain_state_dir()
    for name in (
        "window_focus.jsonl", "active_window.jsonl", "window_log.jsonl",
        "screen_time.jsonl", "focus_samples.jsonl",
    ):
        p = os.path.join(bs, name)
        if os.path.exists(p):
            return p
    return None


def _read_focus_samples(since: float) -> List[Dict[str, Any]]:
    """Parse window-focus samples since a timestamp. Each row should carry a
    timestamp (ts/time/timestamp) and an app/window/title field."""
    path = _window_focus_log_path()
    if not path:
        return []
    samples: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                ts = rec.get("ts") or rec.get("time") or rec.get("timestamp")
                if ts is None:
                    continue
                try:
                    ts = float(ts)
                except Exception:
                    continue
                if ts < since:
                    continue
                app = (
                    rec.get("app") or rec.get("app_name") or rec.get("class")
                    or rec.get("window") or rec.get("title") or "unknown"
                )
                samples.append({"ts": ts, "app": str(app)})
    except Exception:
        return []
    samples.sort(key=lambda r: r["ts"])
    return samples


def _usage_from_samples(samples: List[Dict[str, Any]]) -> Dict[str, float]:
    """Estimate seconds per app by diffing consecutive sample timestamps.
    Gaps > 5 min are treated as idle (capped)."""
    usage: Dict[str, float] = {}
    for i, s in enumerate(samples):
        if i + 1 < len(samples):
            dt = samples[i + 1]["ts"] - s["ts"]
        else:
            dt = min(_now() - s["ts"], 300)
        dt = max(0.0, min(dt, 300.0))
        usage[s["app"]] = usage.get(s["app"], 0.0) + dt
    return usage


# ──────────────────────────────────────────────────────────────────────────
# WEBSITE BLOCKING TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _block_website(args: Dict[str, Any]) -> Dict[str, Any]:
    domain = _norm_domain(args.get("domain", ""))
    if not domain:
        return {"ok": False, "error": "domain required"}
    duration_min = args.get("duration_min")
    expires_at = _now() + float(duration_min) * 60 if duration_min else None
    _conn().execute(
        "INSERT INTO blocked_sites (domain, expires_at) VALUES (?, ?) "
        "ON CONFLICT(domain) DO UPDATE SET expires_at = excluded.expires_at",
        (domain, expires_at),
    )
    _conn().commit()
    status = _sync_blocks()
    return {
        "ok": True,
        "blocked": domain,
        "expires_in_min": duration_min,
        "total_blocked": len(status["domains"]),
        **status,
    }


def _unblock_website(args: Dict[str, Any]) -> Dict[str, Any]:
    domain = _norm_domain(args.get("domain", ""))
    if not domain:
        return {"ok": False, "error": "domain required"}
    cur = _conn().execute("DELETE FROM blocked_sites WHERE domain = ?", (domain,))
    _conn().commit()
    status = _sync_blocks()
    return {
        "ok": True,
        "unblocked": domain,
        "was_blocked": cur.rowcount > 0,
        "total_blocked": len(status["domains"]),
        **status,
    }


def _blocklist(args: Dict[str, Any]) -> Dict[str, Any]:
    rows = _conn().execute(
        "SELECT domain, preset, expires_at, created_at FROM blocked_sites "
        "ORDER BY created_at DESC"
    ).fetchall()
    items = []
    for r in rows:
        exp = r["expires_at"]
        active = exp is None or exp > _now()
        items.append({
            "domain": r["domain"],
            "preset": r["preset"],
            "active": active,
            "expires_in_min": round((exp - _now()) / 60, 1) if exp else None,
        })
    return {"ok": True, "count": len(items), "domains": items}


def _block_preset(args: Dict[str, Any]) -> Dict[str, Any]:
    preset = (args.get("preset") or "").strip().lower()
    if preset not in _PRESETS:
        return {
            "ok": False,
            "error": f"unknown preset '{preset}'",
            "available": sorted(_PRESETS.keys()),
        }
    duration_min = args.get("duration_min")
    expires_at = _now() + float(duration_min) * 60 if duration_min else None
    domains = _PRESETS[preset]
    for d in domains:
        _conn().execute(
            "INSERT INTO blocked_sites (domain, preset, expires_at) VALUES (?, ?, ?) "
            "ON CONFLICT(domain) DO UPDATE SET preset = excluded.preset, "
            "expires_at = excluded.expires_at",
            (d, preset, expires_at),
        )
    _conn().commit()
    status = _sync_blocks()
    return {
        "ok": True,
        "preset": preset,
        "added": domains,
        "total_blocked": len(status["domains"]),
        **status,
    }


def _unblock_all(args: Dict[str, Any]) -> Dict[str, Any]:
    cur = _conn().execute("DELETE FROM blocked_sites")
    _conn().commit()
    status = _sync_blocks()
    return {
        "ok": True,
        "removed": cur.rowcount,
        "total_blocked": 0,
        **status,
    }


def _block_status(args: Dict[str, Any]) -> Dict[str, Any]:
    domains = _active_db_domains()
    hosts_active = False
    hosts_count = 0
    try:
        with open(HOSTS_PATH, "r", encoding="utf-8") as fh:
            text = fh.read()
        if BLOCK_START in text and BLOCK_END in text:
            section = text.split(BLOCK_START, 1)[1].split(BLOCK_END, 1)[0]
            hosts_count = sum(
                1 for ln in section.splitlines()
                if ln.strip().startswith(HOSTS_REDIRECT) and "www." not in ln
            )
            hosts_active = hosts_count > 0
    except Exception:
        pass
    in_sync = hosts_count == len(domains)
    res = {
        "ok": True,
        "hosts_managed_section_active": hosts_active,
        "domains_in_hosts": hosts_count,
        "domains_in_db": len(domains),
        "in_sync": in_sync,
        "fallback_blocklist": _blocklist_json_path(),
        "hosts_writable": os.access(HOSTS_PATH, os.W_OK),
    }
    if not in_sync:
        res["note"] = "DB and /etc/hosts differ — likely /etc/hosts needs root to update."
        res["sudo_command"] = _sudo_apply_command()
    return res


# ──────────────────────────────────────────────────────────────────────────
# APP BLOCKING TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _block_app(args: Dict[str, Any]) -> Dict[str, Any]:
    app = (args.get("app_name") or "").strip()
    if not app:
        return {"ok": False, "error": "app_name required"}
    duration_min = args.get("duration_min", 60) or 60
    expires_at = _now() + float(duration_min) * 60
    _conn().execute(
        "INSERT INTO blocked_apps (app_name, expires_at) VALUES (?, ?) "
        "ON CONFLICT(app_name) DO UPDATE SET expires_at = excluded.expires_at",
        (app, expires_at),
    )
    _conn().commit()
    running = _matching_pids(app)
    return {
        "ok": True,
        "blocked_app": app,
        "expires_in_min": duration_min,
        "currently_running": len(running),
        "note": "Call focus.enforce_app_blocks (or run a routine) to kill it.",
    }


def _unblock_app(args: Dict[str, Any]) -> Dict[str, Any]:
    app = (args.get("app_name") or "").strip()
    if not app:
        return {"ok": False, "error": "app_name required"}
    cur = _conn().execute("DELETE FROM blocked_apps WHERE app_name = ?", (app,))
    _conn().commit()
    return {"ok": True, "unblocked_app": app, "was_blocked": cur.rowcount > 0}


def _app_blocklist(args: Dict[str, Any]) -> Dict[str, Any]:
    rows = _conn().execute(
        "SELECT app_name, expires_at, created_at FROM blocked_apps "
        "ORDER BY created_at DESC"
    ).fetchall()
    items = []
    for r in rows:
        exp = r["expires_at"]
        active = exp is None or exp > _now()
        items.append({
            "app_name": r["app_name"],
            "active": active,
            "expires_in_min": round((exp - _now()) / 60, 1) if exp else None,
        })
    return {"ok": True, "count": len(items), "apps": items}


def _enforce_app_blocks(args: Dict[str, Any]) -> Dict[str, Any]:
    # purge expired registrations first
    _conn().execute(
        "DELETE FROM blocked_apps WHERE expires_at IS NOT NULL AND expires_at <= ?",
        (_now(),),
    )
    _conn().commit()
    killed: List[Dict[str, Any]] = []
    survived: List[Dict[str, Any]] = []
    own_pid = os.getpid()
    for app in _active_blocked_apps():
        for proc in _matching_pids(app):
            if proc["pid"] == own_pid:
                continue
            ok = _kill_pid(proc["pid"])
            entry = {"app": app, "pid": proc["pid"], "name": proc["name"]}
            (killed if ok else survived).append(entry)
    if killed:
        _distraction_log({
            "source": "app",
            "note": "auto-killed blocked app(s): "
                    + ", ".join(sorted({k["app"] for k in killed})),
        })
    return {
        "ok": True,
        "killed": killed,
        "killed_count": len(killed),
        "survived": survived,
        "monitored_apps": _active_blocked_apps(),
    }


# ──────────────────────────────────────────────────────────────────────────
# DEEP-WORK SESSION TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _session_start(args: Dict[str, Any]) -> Dict[str, Any]:
    if _active_session():
        return {
            "ok": False,
            "error": "a focus session is already active — end it first",
        }
    label = (args.get("label") or "Deep work").strip()
    duration_min = int(args.get("duration_min", 90) or 90)
    block_preset = args.get("block_preset")
    started = _now()
    ends = started + duration_min * 60
    cur = _conn().execute(
        "INSERT INTO focus_sessions (label, duration_min, block_preset, "
        "started_at, ends_at, status) VALUES (?, ?, ?, ?, ?, 'active')",
        (label, duration_min, block_preset, started, ends),
    )
    _conn().commit()
    sid = cur.lastrowid
    res: Dict[str, Any] = {
        "ok": True,
        "session_id": sid,
        "label": label,
        "duration_min": duration_min,
        "ends_at": datetime.fromtimestamp(ends).isoformat(timespec="seconds"),
    }
    if block_preset:
        block_res = _block_preset({"preset": block_preset, "duration_min": duration_min})
        res["block_preset"] = block_preset
        res["block_applied"] = block_res.get("ok", False)
        if not block_res.get("hosts_applied", True):
            res["block_note"] = block_res.get("note")
            res["sudo_command"] = block_res.get("sudo_command")
    return res


def _session_status(args: Dict[str, Any]) -> Dict[str, Any]:
    s = _active_session()
    if not s:
        return {"ok": True, "active": False}
    remaining = max(0.0, s["ends_at"] - _now())
    return {
        "ok": True,
        "active": True,
        "session_id": s["id"],
        "label": s["label"],
        "duration_min": s["duration_min"],
        "elapsed": _fmt_dur(_now() - s["started_at"]),
        "remaining": _fmt_dur(remaining),
        "remaining_min": round(remaining / 60, 1),
        "overdue": remaining <= 0,
        "block_preset": s["block_preset"],
        "distraction_count": s["distraction_count"],
    }


def _session_end(args: Dict[str, Any]) -> Dict[str, Any]:
    s = _active_session()
    if not s:
        return {"ok": False, "error": "no active focus session"}
    ended = _now()
    elapsed = ended - s["started_at"]
    completed = elapsed >= s["duration_min"] * 60 * 0.9
    _conn().execute(
        "UPDATE focus_sessions SET ended_at = ?, status = ? WHERE id = ?",
        (ended, "completed" if completed else "ended_early", s["id"]),
    )
    _conn().commit()
    block_lifted = None
    if s["block_preset"]:
        # remove only domains that belong to this preset
        _conn().execute(
            "DELETE FROM blocked_sites WHERE preset = ?", (s["block_preset"],)
        )
        _conn().commit()
        block_lifted = _sync_blocks()
    return {
        "ok": True,
        "session_id": s["id"],
        "label": s["label"],
        "status": "completed" if completed else "ended_early",
        "planned_min": s["duration_min"],
        "actual": _fmt_dur(elapsed),
        "actual_min": round(elapsed / 60, 1),
        "distractions": s["distraction_count"],
        "blocks_lifted": bool(s["block_preset"]),
        "block_status": block_lifted,
    }


def _session_extend(args: Dict[str, Any]) -> Dict[str, Any]:
    s = _active_session()
    if not s:
        return {"ok": False, "error": "no active focus session"}
    extra = int(args.get("extra_min", 30) or 30)
    new_end = s["ends_at"] + extra * 60
    _conn().execute(
        "UPDATE focus_sessions SET ends_at = ?, duration_min = duration_min + ? "
        "WHERE id = ?",
        (new_end, extra, s["id"]),
    )
    _conn().commit()
    return {
        "ok": True,
        "session_id": s["id"],
        "extended_by_min": extra,
        "new_ends_at": datetime.fromtimestamp(new_end).isoformat(timespec="seconds"),
        "remaining": _fmt_dur(max(0.0, new_end - _now())),
    }


def _session_history(args: Dict[str, Any]) -> Dict[str, Any]:
    limit = int(args.get("limit", 20) or 20)
    rows = _conn().execute(
        "SELECT * FROM focus_sessions ORDER BY started_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    items = []
    for r in rows:
        end = r["ended_at"] or r["ends_at"]
        actual = (end - r["started_at"]) if end else (_now() - r["started_at"])
        items.append({
            "id": r["id"],
            "label": r["label"],
            "status": r["status"],
            "started_at": datetime.fromtimestamp(r["started_at"]).isoformat(timespec="seconds"),
            "planned_min": r["duration_min"],
            "actual_min": round(actual / 60, 1),
            "block_preset": r["block_preset"],
            "distractions": r["distraction_count"],
        })
    return {"ok": True, "count": len(items), "sessions": items}


def _session_log_distraction(args: Dict[str, Any]) -> Dict[str, Any]:
    s = _active_session()
    if not s:
        return {
            "ok": False,
            "error": "no active focus session — use focus.distraction_log instead",
        }
    what = (args.get("what") or "").strip() or "unspecified"
    _conn().execute(
        "INSERT INTO distractions (source, note, session_id) VALUES ('session', ?, ?)",
        (what, s["id"]),
    )
    _conn().execute(
        "UPDATE focus_sessions SET distraction_count = distraction_count + 1 WHERE id = ?",
        (s["id"],),
    )
    _conn().commit()
    return {
        "ok": True,
        "session_id": s["id"],
        "logged": what,
        "session_distraction_count": s["distraction_count"] + 1,
    }


# ──────────────────────────────────────────────────────────────────────────
# DISTRACTION TRACKING TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _distraction_log(args: Dict[str, Any]) -> Dict[str, Any]:
    source = (args.get("source") or "").strip()
    if not source:
        return {"ok": False, "error": "source required"}
    note = args.get("note")
    s = _active_session()
    sid = s["id"] if s else None
    _conn().execute(
        "INSERT INTO distractions (source, note, session_id) VALUES (?, ?, ?)",
        (source, note, sid),
    )
    if sid is not None:
        _conn().execute(
            "UPDATE focus_sessions SET distraction_count = distraction_count + 1 WHERE id = ?",
            (sid,),
        )
    _conn().commit()
    return {"ok": True, "logged": source, "note": note, "during_session": sid}


def _distraction_today(args: Dict[str, Any]) -> Dict[str, Any]:
    start = _today_start()
    rows = _conn().execute(
        "SELECT source, COUNT(*) AS n FROM distractions WHERE logged_at >= ? "
        "GROUP BY source ORDER BY n DESC",
        (start,),
    ).fetchall()
    total = sum(r["n"] for r in rows)
    return {
        "ok": True,
        "date": date.today().isoformat(),
        "total": total,
        "by_source": {r["source"]: r["n"] for r in rows},
    }


def _distraction_trend(args: Dict[str, Any]) -> Dict[str, Any]:
    days = int(args.get("days", 7) or 7)
    start = _today_start() - (days - 1) * 86400
    rows = _conn().execute(
        "SELECT logged_at, source FROM distractions WHERE logged_at >= ?",
        (start,),
    ).fetchall()
    buckets: Dict[str, int] = {}
    for i in range(days):
        d = (date.today() - timedelta(days=days - 1 - i)).isoformat()
        buckets[d] = 0
    for r in rows:
        d = date.fromtimestamp(r["logged_at"]).isoformat()
        if d in buckets:
            buckets[d] += 1
    total = sum(buckets.values())
    return {
        "ok": True,
        "days": days,
        "per_day": buckets,
        "total": total,
        "avg_per_day": round(total / days, 2),
    }


# ──────────────────────────────────────────────────────────────────────────
# SCREEN-TIME TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _screen_time_today(args: Dict[str, Any]) -> Dict[str, Any]:
    start = _today_start()
    samples = _read_focus_samples(start)
    if not samples:
        return {
            "ok": True,
            "date": date.today().isoformat(),
            "tracked": False,
            "note": "No window-focus log found in brain_state/ "
                    "(window_focus.jsonl / active_window.jsonl). "
                    "Screen time can't be measured without active-window sampling.",
        }
    usage = _usage_from_samples(samples)
    total = sum(usage.values())
    return {
        "ok": True,
        "date": date.today().isoformat(),
        "tracked": True,
        "total": _fmt_dur(total),
        "total_min": round(total / 60, 1),
        "samples": len(samples),
        "source": _window_focus_log_path(),
    }


def _app_usage_today(args: Dict[str, Any]) -> Dict[str, Any]:
    start = _today_start()
    samples = _read_focus_samples(start)
    if not samples:
        return {
            "ok": True,
            "tracked": False,
            "note": "No window-focus log in brain_state/ — per-app usage unavailable.",
        }
    usage = _usage_from_samples(samples)
    ranked = sorted(usage.items(), key=lambda kv: kv[1], reverse=True)
    return {
        "ok": True,
        "date": date.today().isoformat(),
        "tracked": True,
        "apps": [
            {"app": app, "time": _fmt_dur(sec), "minutes": round(sec / 60, 1)}
            for app, sec in ranked
        ],
        "total_min": round(sum(usage.values()) / 60, 1),
    }


def _set_screen_time_limit(args: Dict[str, Any]) -> Dict[str, Any]:
    app = (args.get("app") or "").strip()
    minutes = args.get("minutes")
    if not app or minutes is None:
        return {"ok": False, "error": "app and minutes required"}
    minutes = int(minutes)
    _conn().execute(
        "INSERT INTO screen_limits (app, limit_min) VALUES (?, ?) "
        "ON CONFLICT(app) DO UPDATE SET limit_min = excluded.limit_min",
        (app, minutes),
    )
    _conn().commit()
    return {"ok": True, "app": app, "limit_min": minutes}


def _screen_time_limits(args: Dict[str, Any]) -> Dict[str, Any]:
    rows = _conn().execute(
        "SELECT app, limit_min FROM screen_limits ORDER BY app"
    ).fetchall()
    # cross-reference with today's usage when available
    samples = _read_focus_samples(_today_start())
    usage = _usage_from_samples(samples) if samples else {}
    limits = []
    for r in rows:
        used_min = 0.0
        for app_key, sec in usage.items():
            if r["app"].lower() in app_key.lower():
                used_min += sec / 60
        limits.append({
            "app": r["app"],
            "limit_min": r["limit_min"],
            "used_min": round(used_min, 1),
            "over_limit": used_min > r["limit_min"],
        })
    return {
        "ok": True,
        "count": len(limits),
        "limits": limits,
        "usage_tracked": bool(samples),
    }


# ──────────────────────────────────────────────────────────────────────────
# FOCUS SCORING TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _deep_work_minutes(since: float, until: Optional[float] = None) -> float:
    """Total minutes spent in focus sessions in [since, until]."""
    until = until or _now()
    rows = _conn().execute(
        "SELECT started_at, ended_at, ends_at, status FROM focus_sessions "
        "WHERE started_at >= ? AND started_at <= ?",
        (since, until),
    ).fetchall()
    total = 0.0
    for r in rows:
        end = r["ended_at"]
        if end is None:  # still active or never ended
            end = min(r["ends_at"], _now())
        total += max(0.0, end - r["started_at"])
    return total / 60


def _focus_score_today(args: Dict[str, Any]) -> Dict[str, Any]:
    start = _today_start()
    dw_min = _deep_work_minutes(start)
    completed = _conn().execute(
        "SELECT COUNT(*) AS n FROM focus_sessions "
        "WHERE started_at >= ? AND status = 'completed'",
        (start,),
    ).fetchone()["n"]
    distractions = _conn().execute(
        "SELECT COUNT(*) AS n FROM distractions WHERE logged_at >= ?",
        (start,),
    ).fetchone()["n"]

    # Composite 0-100:
    #   deep-work component (max 60): 240 min of deep work == full marks
    #   sessions component (max 25): 3 completed sessions == full marks
    #   distraction penalty (max -35): -5 per distraction
    dw_comp = min(60.0, dw_min / 240 * 60)
    sess_comp = min(25.0, completed / 3 * 25)
    distr_pen = min(35.0, distractions * 5)
    base = 15.0  # baseline so a quiet, distraction-free day isn't a zero
    score = max(0.0, min(100.0, base + dw_comp + sess_comp - distr_pen))

    if score >= 80:
        grade = "locked in"
    elif score >= 60:
        grade = "solid"
    elif score >= 40:
        grade = "scattered"
    else:
        grade = "off the rails"

    return {
        "ok": True,
        "date": date.today().isoformat(),
        "score": round(score, 1),
        "grade": grade,
        "deep_work_min": round(dw_min, 1),
        "sessions_completed": completed,
        "distractions": distractions,
        "components": {
            "deep_work": round(dw_comp, 1),
            "sessions": round(sess_comp, 1),
            "distraction_penalty": round(-distr_pen, 1),
            "baseline": base,
        },
    }


def _focus_streak(args: Dict[str, Any]) -> Dict[str, Any]:
    rows = _conn().execute(
        "SELECT started_at FROM focus_sessions WHERE status = 'completed'"
    ).fetchall()
    days_with = {date.fromtimestamp(r["started_at"]).isoformat() for r in rows}
    streak = 0
    cursor = date.today()
    # allow today to be unfinished — start the count from today or yesterday
    if cursor.isoformat() not in days_with:
        cursor = cursor - timedelta(days=1)
    while cursor.isoformat() in days_with:
        streak += 1
        cursor = cursor - timedelta(days=1)
    return {
        "ok": True,
        "streak_days": streak,
        "today_counted": date.today().isoformat() in days_with,
        "total_focus_days": len(days_with),
    }


def _daily_focus_report(args: Dict[str, Any]) -> Dict[str, Any]:
    score = _focus_score_today({})
    streak = _focus_streak({})
    distr = _distraction_today({})
    screen = _screen_time_today({})
    sessions = _conn().execute(
        "SELECT label, status, duration_min FROM focus_sessions "
        "WHERE started_at >= ? ORDER BY started_at",
        (_today_start(),),
    ).fetchall()

    lines: List[str] = []
    lines.append(f"# Focus Report — {date.today().isoformat()}")
    lines.append("")
    lines.append(f"**Focus score:** {score['score']}/100 — _{score['grade']}_")
    lines.append(f"**Streak:** {streak['streak_days']} day(s)")
    lines.append("")
    lines.append("## Deep work")
    lines.append(f"- {score['deep_work_min']} min across {len(sessions)} session(s)")
    lines.append(f"- {score['sessions_completed']} completed")
    if sessions:
        for s in sessions:
            mark = "x" if s["status"] == "completed" else " "
            lines.append(f"  - [{mark}] {s['label']} ({s['duration_min']} min, {s['status']})")
    lines.append("")
    lines.append("## Distractions")
    lines.append(f"- {distr['total']} logged today")
    for src, n in distr["by_source"].items():
        lines.append(f"  - {src}: {n}")
    lines.append("")
    lines.append("## Screen time")
    if screen.get("tracked"):
        lines.append(f"- {screen['total']} of active screen time")
    else:
        lines.append("- not tracked (no window-focus log)")
    lines.append("")
    if score["score"] >= 80:
        lines.append("> Locked in. Keep this rhythm.")
    elif score["score"] >= 60:
        lines.append("> Solid day. Trim distractions to push into the 80s.")
    else:
        lines.append("> Scattered. Start one 90-min session with a block preset tomorrow.")

    md = "\n".join(lines)
    return {
        "ok": True,
        "date": date.today().isoformat(),
        "markdown": md,
        "score": score["score"],
        "grade": score["grade"],
    }


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS EXPORT
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # website blocking
    "focus.block_website": _tool(_block_website),
    "focus.unblock_website": _tool(_unblock_website),
    "focus.blocklist": _tool(_blocklist),
    "focus.block_preset": _tool(_block_preset),
    "focus.unblock_all": _tool(_unblock_all),
    "focus.block_status": _tool(_block_status),
    # app blocking
    "focus.block_app": _tool(_block_app),
    "focus.unblock_app": _tool(_unblock_app),
    "focus.app_blocklist": _tool(_app_blocklist),
    "focus.enforce_app_blocks": _tool(_enforce_app_blocks),
    # deep-work sessions
    "focus.session_start": _tool(_session_start),
    "focus.session_status": _tool(_session_status),
    "focus.session_end": _tool(_session_end),
    "focus.session_extend": _tool(_session_extend),
    "focus.session_history": _tool(_session_history),
    "focus.session_log_distraction": _tool(_session_log_distraction),
    # distraction tracking
    "focus.distraction_log": _tool(_distraction_log),
    "focus.distraction_today": _tool(_distraction_today),
    "focus.distraction_trend": _tool(_distraction_trend),
    # screen time
    "focus.screen_time_today": _tool(_screen_time_today),
    "focus.app_usage_today": _tool(_app_usage_today),
    "focus.set_screen_time_limit": _tool(_set_screen_time_limit),
    "focus.screen_time_limits": _tool(_screen_time_limits),
    # focus scoring
    "focus.focus_score_today": _tool(_focus_score_today),
    "focus.focus_streak": _tool(_focus_streak),
    "focus.daily_focus_report": _tool(_daily_focus_report),
}
