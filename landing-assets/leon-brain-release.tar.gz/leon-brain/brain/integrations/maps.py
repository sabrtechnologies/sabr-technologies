"""
maps.py — Leon's maps, navigation, traffic, and POI tool surface.

Gives Leon the ability to answer geo questions: "where am I?", "how
long to drive to X?", "what's the closest gas station / coffee shop /
hospital?", "show me transit stops nearby", "what's the route with
traffic?".

Design mirrors `brain/integrations/life.py`:

  - One function per tool, taking a single `args` dict.
  - Every function returns `{"ok": True, "result": ...}` or
    `{"ok": False, "error": "..."}` — never raises out.
  - FREE APIs first: OpenStreetMap Nominatim (geocoding), OSRM
    (routing), Photon (autocomplete), Overpass (POIs by OSM tag),
    ipapi.co (IP geo), sunrise-sunset-style public endpoints.
  - Premium fallback: Google Maps Platform if `GOOGLE_MAPS_API_KEY`
    is set — used for Directions+traffic and Transit, where free
    options are weak.
  - All network calls use `_get` with a 10s timeout.

EXTRA_TOOLS at the bottom maps dotted names like `maps.geocode` to
the implementing function.
"""

from __future__ import annotations

import math
import os
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import quote

import requests


# ──────────────────────────────────────────────────────────────────────────
# HTTP HELPERS
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_TIMEOUT = 10
_USER_AGENT = os.environ.get(
    "LEON_HTTP_CONTACT",
    "Leon/1.0 (Leon; Sabr; contact: support@sabrtechnologies.com)")


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    h = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
    if extra:
        h.update(extra)
    return h


def _get(url: str, params: Optional[dict] = None, headers: Optional[dict] = None,
         timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    """GET with uniform error envelope. Returns {ok, status, json|text} or {ok:False, error}."""
    try:
        r = requests.get(url, params=params, headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        try:
            out["json"] = r.json()
        except ValueError:
            out["text"] = r.text
    else:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


def _post(url: str, data: Optional[str] = None, headers: Optional[dict] = None,
          timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    """POST raw body (Overpass uses form-encoded `data=` query)."""
    try:
        r = requests.post(url, data=data, headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        try:
            out["json"] = r.json()
        except ValueError:
            out["text"] = r.text
    else:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


def _env(name: str) -> Optional[str]:
    v = os.environ.get(name)
    return v.strip() if v and v.strip() else None


def _require_arg(args: dict, key: str) -> Any:
    if key not in args or args[key] in (None, ""):
        raise KeyError(key)
    return args[key]


def _opt_float(args: dict, key: str) -> Optional[float]:
    v = args.get(key)
    if v in (None, ""):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _opt_int(args: dict, key: str, default: Optional[int] = None) -> Optional[int]:
    v = args.get(key, default)
    if v in (None, ""):
        return default
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


# ──────────────────────────────────────────────────────────────────────────
# INTERNAL: GEOCODING / IP-GEO / OVERPASS / OSRM / GOOGLE FALLBACK
# ──────────────────────────────────────────────────────────────────────────


def _nominatim_search(query: str, limit: int = 1) -> Dict[str, Any]:
    return _get(
        "https://nominatim.openstreetmap.org/search",
        params={"q": query, "format": "json", "addressdetails": 1, "limit": limit},
    )


def _nominatim_reverse(lat: float, lon: float) -> Dict[str, Any]:
    return _get(
        "https://nominatim.openstreetmap.org/reverse",
        params={"lat": lat, "lon": lon, "format": "json", "addressdetails": 1, "zoom": 18},
    )


def _geocode_one(address: str) -> Tuple[Optional[float], Optional[float], Optional[dict]]:
    """Internal: address -> (lat, lon, raw). Google if key, else Nominatim."""
    gkey = _env("GOOGLE_MAPS_API_KEY")
    if gkey:
        resp = _get(
            "https://maps.googleapis.com/maps/api/geocode/json",
            params={"address": address, "key": gkey},
        )
        if resp.get("ok"):
            j = resp.get("json") or {}
            results = j.get("results") or []
            if results:
                loc = results[0]["geometry"]["location"]
                return float(loc["lat"]), float(loc["lng"]), results[0]
    resp = _nominatim_search(address, limit=1)
    if resp.get("ok"):
        items = resp.get("json") or []
        if items:
            return float(items[0]["lat"]), float(items[0]["lon"]), items[0]
    return None, None, None


def _ip_geo() -> Dict[str, Any]:
    """Public IP geolocation via ipapi.co (free, no key)."""
    resp = _get("https://ipapi.co/json/")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "ipapi failed")}
    j = resp.get("json") or {}
    if j.get("error"):
        return {"ok": False, "error": j.get("reason") or "ipapi error"}
    return {
        "ok": True,
        "lat": j.get("latitude"),
        "lon": j.get("longitude"),
        "city": j.get("city"),
        "region": j.get("region"),
        "country": j.get("country_name"),
        "postal": j.get("postal"),
        "ip": j.get("ip"),
        "raw": j,
    }


def _overpass_query(ql: str) -> Dict[str, Any]:
    """Run an Overpass QL query against the public endpoint."""
    return _post(
        "https://overpass-api.de/api/interpreter",
        data=f"data={quote(ql)}",
        headers={"Content-Type": "application/x-www-form-urlencoded",
                 "Accept": "application/json"},
    )


def _overpass_nodes_around(tag_filter: str, lat: float, lon: float,
                           radius_m: int, limit: int) -> Dict[str, Any]:
    """
    Generic Overpass "nodes/ways/relations with tag X within radius" search.
    `tag_filter` is the bracketed selector e.g. '["amenity"="fuel"]'.
    """
    ql = (
        "[out:json][timeout:25];"
        f"(node{tag_filter}(around:{int(radius_m)},{lat},{lon});"
        f" way{tag_filter}(around:{int(radius_m)},{lat},{lon});"
        f" relation{tag_filter}(around:{int(radius_m)},{lat},{lon}););"
        "out center tags qt;"
    )
    resp = _overpass_query(ql)
    if not resp.get("ok"):
        return resp
    elements = (resp.get("json") or {}).get("elements") or []
    items: List[dict] = []
    for el in elements:
        tags = el.get("tags") or {}
        if el.get("type") == "node":
            la, lo = el.get("lat"), el.get("lon")
        else:
            c = el.get("center") or {}
            la, lo = c.get("lat"), c.get("lon")
        if la is None or lo is None:
            continue
        items.append({
            "id": el.get("id"),
            "type": el.get("type"),
            "lat": la,
            "lon": lo,
            "name": tags.get("name"),
            "brand": tags.get("brand"),
            "operator": tags.get("operator"),
            "tags": tags,
            "distance_m": _haversine_m(lat, lon, la, lo),
        })
    items.sort(key=lambda x: x["distance_m"])
    return {"ok": True, "items": items[:limit]}


_OSRM_MODE = {
    "driving": "driving",
    "car": "driving",
    "drive": "driving",
    "walking": "walking",
    "walk": "walking",
    "foot": "walking",
    "cycling": "cycling",
    "cycle": "cycling",
    "bike": "cycling",
    "bicycle": "cycling",
}


def _osrm_route(from_lat: float, from_lon: float, to_lat: float, to_lon: float,
                mode: str, alternatives: bool = False, steps: bool = True) -> Dict[str, Any]:
    profile = _OSRM_MODE.get((mode or "driving").lower(), "driving")
    url = (
        f"https://router.project-osrm.org/route/v1/{profile}/"
        f"{from_lon},{from_lat};{to_lon},{to_lat}"
    )
    return _get(url, params={
        "overview": "simplified",
        "alternatives": "true" if alternatives else "false",
        "steps": "true" if steps else "false",
        "annotations": "duration,distance",
    })


def _format_osrm_route(rt: dict, steps: bool = True) -> dict:
    out = {
        "distance_m": rt.get("distance"),
        "duration_s": rt.get("duration"),
        "duration_min": round((rt.get("duration") or 0) / 60.0, 1),
        "distance_km": round((rt.get("distance") or 0) / 1000.0, 2),
        "geometry": rt.get("geometry"),
    }
    if steps:
        legs = rt.get("legs") or []
        leg_steps: List[dict] = []
        for leg in legs:
            for s in leg.get("steps") or []:
                man = s.get("maneuver") or {}
                leg_steps.append({
                    "instruction": man.get("type") + (
                        f" {man.get('modifier')}" if man.get("modifier") else ""
                    ),
                    "name": s.get("name"),
                    "distance_m": s.get("distance"),
                    "duration_s": s.get("duration"),
                })
        out["steps"] = leg_steps
    return out


def _google_directions(from_addr: str, to_addr: str, mode: str = "driving",
                       departure_iso: Optional[str] = None,
                       alternatives: bool = False) -> Optional[Dict[str, Any]]:
    """Premium fallback. Returns None if no key, else uniform dict."""
    gkey = _env("GOOGLE_MAPS_API_KEY")
    if not gkey:
        return None
    gmode = {"driving": "driving", "car": "driving", "walking": "walking",
             "walk": "walking", "cycling": "bicycling", "bike": "bicycling",
             "transit": "transit"}.get((mode or "driving").lower(), "driving")
    params = {
        "origin": from_addr,
        "destination": to_addr,
        "mode": gmode,
        "key": gkey,
        "alternatives": "true" if alternatives else "false",
        "departure_time": "now" if gmode == "driving" else None,
    }
    if departure_iso:
        try:
            import datetime as _dt
            ts = int(_dt.datetime.fromisoformat(departure_iso.replace("Z", "+00:00")).timestamp())
            params["departure_time"] = ts
        except Exception:
            pass
    params = {k: v for k, v in params.items() if v is not None}
    resp = _get("https://maps.googleapis.com/maps/api/directions/json", params=params)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "google directions failed")}
    j = resp.get("json") or {}
    if j.get("status") not in ("OK",):
        return {"ok": False, "error": f"google: {j.get('status')} {j.get('error_message','')}"}
    return {"ok": True, "json": j}


# ──────────────────────────────────────────────────────────────────────────
# HAVERSINE
# ──────────────────────────────────────────────────────────────────────────


def _haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371000.0
    rl1, rl2 = math.radians(lat1), math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(rl1) * math.cos(rl2) * math.sin(dlon / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


# ──────────────────────────────────────────────────────────────────────────
# GEOCODING
# ──────────────────────────────────────────────────────────────────────────


def geocode(args: dict) -> dict:
    """Address → lat/lon. Google if GOOGLE_MAPS_API_KEY set, else Nominatim."""
    try:
        address = str(_require_arg(args, "address"))
    except KeyError:
        return {"ok": False, "error": "address is required"}
    lat, lon, raw = _geocode_one(address)
    if lat is None:
        return {"ok": False, "error": f"no geocode result for {address!r}"}
    display = None
    if isinstance(raw, dict):
        display = raw.get("display_name") or raw.get("formatted_address")
    return {
        "ok": True,
        "result": {
            "address": address,
            "lat": lat,
            "lon": lon,
            "display_name": display,
            "source": "google" if _env("GOOGLE_MAPS_API_KEY") else "nominatim",
        },
    }


def reverse_geocode(args: dict) -> dict:
    """lat/lon → address."""
    lat = _opt_float(args, "lat")
    lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    gkey = _env("GOOGLE_MAPS_API_KEY")
    if gkey:
        resp = _get(
            "https://maps.googleapis.com/maps/api/geocode/json",
            params={"latlng": f"{lat},{lon}", "key": gkey},
        )
        if resp.get("ok"):
            results = (resp.get("json") or {}).get("results") or []
            if results:
                r0 = results[0]
                return {"ok": True, "result": {
                    "address": r0.get("formatted_address"),
                    "lat": lat, "lon": lon,
                    "components": r0.get("address_components"),
                    "source": "google",
                }}
    resp = _nominatim_reverse(lat, lon)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "reverse geocode failed")}
    j = resp.get("json") or {}
    return {"ok": True, "result": {
        "address": j.get("display_name"),
        "lat": lat, "lon": lon,
        "components": j.get("address") or {},
        "source": "nominatim",
    }}


def search_nearby(args: dict) -> dict:
    """Free-form nearby search via Overpass. `query` is matched against name/amenity/shop tags."""
    try:
        query = str(_require_arg(args, "query")).strip()
    except KeyError:
        return {"ok": False, "error": "query is required"}
    lat = _opt_float(args, "lat")
    lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 5000) or 5000
    limit = _opt_int(args, "limit", 20) or 20

    # Search across common OSM "what is this place" tags using regex.
    qesc = query.replace('"', '\\"')
    ql = (
        "[out:json][timeout:25];"
        "("
        f'node["name"~"{qesc}",i](around:{radius},{lat},{lon});'
        f'node["amenity"~"{qesc}",i](around:{radius},{lat},{lon});'
        f'node["shop"~"{qesc}",i](around:{radius},{lat},{lon});'
        f'node["tourism"~"{qesc}",i](around:{radius},{lat},{lon});'
        f'node["leisure"~"{qesc}",i](around:{radius},{lat},{lon});'
        f'way["name"~"{qesc}",i](around:{radius},{lat},{lon});'
        ");"
        "out center tags qt;"
    )
    resp = _overpass_query(ql)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "overpass failed")}
    elements = (resp.get("json") or {}).get("elements") or []
    items: List[dict] = []
    for el in elements:
        tags = el.get("tags") or {}
        if el.get("type") == "node":
            la, lo = el.get("lat"), el.get("lon")
        else:
            c = el.get("center") or {}
            la, lo = c.get("lat"), c.get("lon")
        if la is None or lo is None:
            continue
        items.append({
            "id": el.get("id"),
            "name": tags.get("name"),
            "category": tags.get("amenity") or tags.get("shop") or tags.get("tourism") or tags.get("leisure"),
            "lat": la, "lon": lo,
            "distance_m": _haversine_m(lat, lon, la, lo),
            "tags": tags,
        })
    items.sort(key=lambda x: x["distance_m"])
    return {"ok": True, "result": {"query": query, "count": len(items[:limit]), "items": items[:limit]}}


def address_autocomplete(args: dict) -> dict:
    """Photon (Komoot) autocomplete — free, no key. Optional lat/lon bias."""
    try:
        partial = str(_require_arg(args, "partial"))
    except KeyError:
        return {"ok": False, "error": "partial is required"}
    lat = _opt_float(args, "lat")
    lon = _opt_float(args, "lon")
    limit = _opt_int(args, "limit", 10) or 10
    params = {"q": partial, "limit": limit}
    if lat is not None and lon is not None:
        params["lat"] = lat
        params["lon"] = lon
    resp = _get("https://photon.komoot.io/api/", params=params)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "photon failed")}
    feats = ((resp.get("json") or {}).get("features")) or []
    items = []
    for f in feats:
        props = f.get("properties") or {}
        coords = (f.get("geometry") or {}).get("coordinates") or [None, None]
        items.append({
            "name": props.get("name"),
            "country": props.get("country"),
            "state": props.get("state"),
            "city": props.get("city") or props.get("town") or props.get("village"),
            "street": props.get("street"),
            "housenumber": props.get("housenumber"),
            "postcode": props.get("postcode"),
            "label": ", ".join(filter(None, [
                props.get("name"), props.get("street"), props.get("city"),
                props.get("state"), props.get("country"),
            ])),
            "lon": coords[0],
            "lat": coords[1],
            "osm_type": props.get("osm_type"),
            "osm_id": props.get("osm_id"),
        })
    return {"ok": True, "result": {"partial": partial, "count": len(items), "items": items}}


# ──────────────────────────────────────────────────────────────────────────
# DIRECTIONS
# ──────────────────────────────────────────────────────────────────────────


def directions(args: dict) -> dict:
    """Door-to-door directions by address. OSRM (free) for car/walk/bike."""
    try:
        from_addr = str(_require_arg(args, "from_address"))
        to_addr = str(_require_arg(args, "to_address"))
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}
    mode = (args.get("mode") or "driving").lower()

    f_lat, f_lon, _ = _geocode_one(from_addr)
    if f_lat is None:
        return {"ok": False, "error": f"could not geocode from_address: {from_addr!r}"}
    t_lat, t_lon, _ = _geocode_one(to_addr)
    if t_lat is None:
        return {"ok": False, "error": f"could not geocode to_address: {to_addr!r}"}

    # If transit requested, defer to Google.
    if mode in ("transit", "bus", "train", "rail"):
        gres = _google_directions(from_addr, to_addr, mode="transit")
        if gres is None:
            return {"ok": False, "error": "transit requires GOOGLE_MAPS_API_KEY"}
        return gres if not gres.get("ok") else {"ok": True, "result": {
            "mode": "transit",
            "source": "google",
            "raw": gres.get("json"),
        }}

    resp = _osrm_route(f_lat, f_lon, t_lat, t_lon, mode, alternatives=False, steps=True)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "osrm failed")}
    j = resp.get("json") or {}
    if j.get("code") != "Ok" or not j.get("routes"):
        return {"ok": False, "error": f"osrm: {j.get('code')} {j.get('message','')}"}
    fmt = _format_osrm_route(j["routes"][0], steps=True)
    return {"ok": True, "result": {
        "mode": mode,
        "from": {"address": from_addr, "lat": f_lat, "lon": f_lon},
        "to": {"address": to_addr, "lat": t_lat, "lon": t_lon},
        "source": "osrm",
        **fmt,
    }}


def directions_latlon(args: dict) -> dict:
    """Directions between two raw lat/lon pairs."""
    f_lat = _opt_float(args, "from_lat")
    f_lon = _opt_float(args, "from_lon")
    t_lat = _opt_float(args, "to_lat")
    t_lon = _opt_float(args, "to_lon")
    if None in (f_lat, f_lon, t_lat, t_lon):
        return {"ok": False, "error": "from_lat, from_lon, to_lat, to_lon are all required"}
    mode = (args.get("mode") or "driving").lower()
    resp = _osrm_route(f_lat, f_lon, t_lat, t_lon, mode, alternatives=False, steps=True)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "osrm failed")}
    j = resp.get("json") or {}
    if j.get("code") != "Ok" or not j.get("routes"):
        return {"ok": False, "error": f"osrm: {j.get('code')} {j.get('message','')}"}
    fmt = _format_osrm_route(j["routes"][0], steps=True)
    return {"ok": True, "result": {
        "mode": mode,
        "from": {"lat": f_lat, "lon": f_lon},
        "to": {"lat": t_lat, "lon": t_lon},
        "source": "osrm",
        **fmt,
    }}


def travel_time(args: dict) -> dict:
    """Just the minutes (and km). Uses Google if key + departure to factor traffic."""
    try:
        from_addr = str(_require_arg(args, "from_addr"))
        to_addr = str(_require_arg(args, "to_addr"))
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}
    mode = (args.get("mode") or "driving").lower()
    departure_iso = args.get("departure_iso")

    gres = _google_directions(from_addr, to_addr, mode=mode, departure_iso=departure_iso)
    if gres is not None and gres.get("ok"):
        routes = (gres.get("json") or {}).get("routes") or []
        if routes:
            leg = (routes[0].get("legs") or [{}])[0]
            dur = leg.get("duration_in_traffic") or leg.get("duration") or {}
            dist = leg.get("distance") or {}
            return {"ok": True, "result": {
                "minutes": round((dur.get("value") or 0) / 60.0, 1),
                "duration_text": dur.get("text"),
                "distance_km": round((dist.get("value") or 0) / 1000.0, 2),
                "distance_text": dist.get("text"),
                "mode": mode,
                "source": "google",
                "traffic": "duration_in_traffic" in leg,
            }}

    # Free path: geocode + OSRM
    f_lat, f_lon, _ = _geocode_one(from_addr)
    t_lat, t_lon, _ = _geocode_one(to_addr)
    if None in (f_lat, t_lat):
        return {"ok": False, "error": "could not geocode one of the endpoints"}
    resp = _osrm_route(f_lat, f_lon, t_lat, t_lon, mode, alternatives=False, steps=False)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "osrm failed")}
    j = resp.get("json") or {}
    if j.get("code") != "Ok" or not j.get("routes"):
        return {"ok": False, "error": f"osrm: {j.get('code')}"}
    rt = j["routes"][0]
    return {"ok": True, "result": {
        "minutes": round((rt.get("duration") or 0) / 60.0, 1),
        "distance_km": round((rt.get("distance") or 0) / 1000.0, 2),
        "mode": mode,
        "source": "osrm",
        "traffic": False,
    }}


def eta_to(args: dict) -> dict:
    """ETA from current location (IP-geo if not provided) to a destination."""
    try:
        dest = str(_require_arg(args, "destination_address"))
    except KeyError:
        return {"ok": False, "error": "destination_address is required"}
    lat = _opt_float(args, "current_lat")
    lon = _opt_float(args, "current_lon")
    if lat is None or lon is None:
        geo = _ip_geo()
        if not geo.get("ok"):
            return {"ok": False, "error": f"could not determine current location: {geo.get('error')}"}
        lat = geo.get("lat")
        lon = geo.get("lon")
        if lat is None or lon is None:
            return {"ok": False, "error": "ipapi returned no coordinates"}

    t_lat, t_lon, _ = _geocode_one(dest)
    if t_lat is None:
        return {"ok": False, "error": f"could not geocode destination: {dest!r}"}

    resp = _osrm_route(lat, lon, t_lat, t_lon, "driving", alternatives=False, steps=False)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "osrm failed")}
    j = resp.get("json") or {}
    if j.get("code") != "Ok" or not j.get("routes"):
        return {"ok": False, "error": f"osrm: {j.get('code')}"}
    rt = j["routes"][0]
    return {"ok": True, "result": {
        "destination": dest,
        "from": {"lat": lat, "lon": lon},
        "minutes": round((rt.get("duration") or 0) / 60.0, 1),
        "distance_km": round((rt.get("distance") or 0) / 1000.0, 2),
        "source": "osrm",
    }}


# ──────────────────────────────────────────────────────────────────────────
# TRAFFIC
# ──────────────────────────────────────────────────────────────────────────


def traffic_now(args: dict) -> dict:
    """Best-effort live traffic. Google's `duration_in_traffic` if key, else OSRM baseline."""
    try:
        from_addr = str(_require_arg(args, "from_addr"))
        to_addr = str(_require_arg(args, "to_addr"))
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}

    gres = _google_directions(from_addr, to_addr, mode="driving")
    if gres is not None and gres.get("ok"):
        routes = (gres.get("json") or {}).get("routes") or []
        if routes:
            leg = (routes[0].get("legs") or [{}])[0]
            d_free = leg.get("duration") or {}
            d_traf = leg.get("duration_in_traffic") or {}
            base_min = round((d_free.get("value") or 0) / 60.0, 1)
            live_min = round((d_traf.get("value") or 0) / 60.0, 1) if d_traf else None
            delay = round(live_min - base_min, 1) if live_min is not None else None
            return {"ok": True, "result": {
                "minutes_free_flow": base_min,
                "minutes_with_traffic": live_min,
                "traffic_delay_min": delay,
                "summary": routes[0].get("summary"),
                "source": "google",
            }}

    # OSRM baseline only — no live traffic, but at least returns a duration.
    f_lat, f_lon, _ = _geocode_one(from_addr)
    t_lat, t_lon, _ = _geocode_one(to_addr)
    if None in (f_lat, t_lat):
        return {"ok": False, "error": "could not geocode endpoints"}
    resp = _osrm_route(f_lat, f_lon, t_lat, t_lon, "driving", alternatives=False, steps=False)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "osrm failed")}
    j = resp.get("json") or {}
    if j.get("code") != "Ok" or not j.get("routes"):
        return {"ok": False, "error": f"osrm: {j.get('code')}"}
    rt = j["routes"][0]
    return {"ok": True, "result": {
        "minutes_free_flow": round((rt.get("duration") or 0) / 60.0, 1),
        "minutes_with_traffic": None,
        "traffic_delay_min": None,
        "note": "set GOOGLE_MAPS_API_KEY for live traffic",
        "source": "osrm",
    }}


def alternate_routes(args: dict) -> dict:
    """Up to N alternative routes between two addresses (OSRM)."""
    try:
        from_addr = str(_require_arg(args, "from_addr"))
        to_addr = str(_require_arg(args, "to_addr"))
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}
    max_alts = _opt_int(args, "max_alts", 3) or 3

    f_lat, f_lon, _ = _geocode_one(from_addr)
    t_lat, t_lon, _ = _geocode_one(to_addr)
    if None in (f_lat, t_lat):
        return {"ok": False, "error": "could not geocode endpoints"}

    resp = _osrm_route(f_lat, f_lon, t_lat, t_lon, "driving", alternatives=True, steps=False)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "osrm failed")}
    j = resp.get("json") or {}
    if j.get("code") != "Ok" or not j.get("routes"):
        return {"ok": False, "error": f"osrm: {j.get('code')}"}
    routes = j.get("routes") or []
    formatted = [_format_osrm_route(rt, steps=False) for rt in routes[:max_alts]]
    return {"ok": True, "result": {
        "from": from_addr, "to": to_addr,
        "count": len(formatted),
        "routes": formatted,
        "source": "osrm",
    }}


# ──────────────────────────────────────────────────────────────────────────
# POIs — Overpass-backed
# ──────────────────────────────────────────────────────────────────────────


def gas_stations(args: dict) -> dict:
    """OSM amenity=fuel within radius."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 5000) or 5000
    limit = _opt_int(args, "limit", 10) or 10
    res = _overpass_nodes_around('["amenity"="fuel"]', lat, lon, radius, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def restaurants(args: dict) -> dict:
    """OSM amenity=restaurant (optionally filtered by cuisine tag)."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 2000) or 2000
    limit = _opt_int(args, "limit", 20) or 20
    cuisine = args.get("cuisine")
    if cuisine:
        cesc = str(cuisine).replace('"', '\\"')
        sel = f'["amenity"="restaurant"]["cuisine"~"{cesc}",i]'
    else:
        sel = '["amenity"="restaurant"]'
    res = _overpass_nodes_around(sel, lat, lon, radius, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def coffee_shops(args: dict) -> dict:
    """OSM amenity=cafe."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 2000) or 2000
    limit = _opt_int(args, "limit", 20) or 20
    res = _overpass_nodes_around('["amenity"="cafe"]', lat, lon, radius, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def parking(args: dict) -> dict:
    """OSM amenity=parking."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 1000) or 1000
    limit = _opt_int(args, "limit", 10) or 10
    res = _overpass_nodes_around('["amenity"="parking"]', lat, lon, radius, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def ev_charging(args: dict) -> dict:
    """OSM amenity=charging_station."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 20000) or 20000
    limit = _opt_int(args, "limit", 10) or 10
    res = _overpass_nodes_around('["amenity"="charging_station"]', lat, lon, radius, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def atms(args: dict) -> dict:
    """OSM amenity=atm."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 2000) or 2000
    limit = _opt_int(args, "limit", 10) or 10
    res = _overpass_nodes_around('["amenity"="atm"]', lat, lon, radius, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def pharmacies(args: dict) -> dict:
    """OSM amenity=pharmacy."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 2000) or 2000
    limit = _opt_int(args, "limit", 10) or 10
    res = _overpass_nodes_around('["amenity"="pharmacy"]', lat, lon, radius, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def hospitals_nearest(args: dict) -> dict:
    """Nearest N hospitals within a wide radius (50km)."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    limit = _opt_int(args, "limit", 5) or 5
    res = _overpass_nodes_around('["amenity"="hospital"]', lat, lon, 50000, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


def airports_nearest(args: dict) -> dict:
    """Nearest N airports within 200km."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    limit = _opt_int(args, "limit", 5) or 5
    res = _overpass_nodes_around('["aeroway"="aerodrome"]', lat, lon, 200000, limit)
    if not res.get("ok"):
        return res
    return {"ok": True, "result": {"count": len(res["items"]), "items": res["items"]}}


# ──────────────────────────────────────────────────────────────────────────
# TRANSIT
# ──────────────────────────────────────────────────────────────────────────


def transit_directions(args: dict) -> dict:
    """Public-transit directions. Requires GOOGLE_MAPS_API_KEY (no good free alt)."""
    try:
        from_addr = str(_require_arg(args, "from_addr"))
        to_addr = str(_require_arg(args, "to_addr"))
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}
    departure_iso = args.get("departure_iso")
    gres = _google_directions(from_addr, to_addr, mode="transit", departure_iso=departure_iso)
    if gres is None:
        return {"ok": False, "error": "transit directions require GOOGLE_MAPS_API_KEY"}
    if not gres.get("ok"):
        return gres
    j = gres.get("json") or {}
    routes = j.get("routes") or []
    if not routes:
        return {"ok": False, "error": "no transit routes found"}
    leg = (routes[0].get("legs") or [{}])[0]
    steps = []
    for s in leg.get("steps") or []:
        td = s.get("transit_details") or {}
        steps.append({
            "travel_mode": s.get("travel_mode"),
            "instruction": s.get("html_instructions"),
            "duration": (s.get("duration") or {}).get("text"),
            "distance": (s.get("distance") or {}).get("text"),
            "line": (td.get("line") or {}).get("short_name") or (td.get("line") or {}).get("name"),
            "headsign": td.get("headsign"),
            "departure_stop": (td.get("departure_stop") or {}).get("name"),
            "arrival_stop": (td.get("arrival_stop") or {}).get("name"),
            "departure_time": (td.get("departure_time") or {}).get("text"),
            "arrival_time": (td.get("arrival_time") or {}).get("text"),
            "num_stops": td.get("num_stops"),
        })
    return {"ok": True, "result": {
        "from": leg.get("start_address"),
        "to": leg.get("end_address"),
        "duration": (leg.get("duration") or {}).get("text"),
        "duration_min": round(((leg.get("duration") or {}).get("value") or 0) / 60.0, 1),
        "distance": (leg.get("distance") or {}).get("text"),
        "departure_time": (leg.get("departure_time") or {}).get("text"),
        "arrival_time": (leg.get("arrival_time") or {}).get("text"),
        "steps": steps,
        "source": "google",
    }}


def transit_stops_nearby(args: dict) -> dict:
    """Bus stops, tram stops, train/subway stations within radius (OSM)."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    radius = _opt_int(args, "radius_m", 500) or 500

    ql = (
        "[out:json][timeout:25];"
        "("
        f'node["highway"="bus_stop"](around:{radius},{lat},{lon});'
        f'node["railway"="station"](around:{radius},{lat},{lon});'
        f'node["railway"="tram_stop"](around:{radius},{lat},{lon});'
        f'node["railway"="subway_entrance"](around:{radius},{lat},{lon});'
        f'node["public_transport"="stop_position"](around:{radius},{lat},{lon});'
        f'node["public_transport"="platform"](around:{radius},{lat},{lon});'
        ");"
        "out tags qt;"
    )
    resp = _overpass_query(ql)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "overpass failed")}
    elements = (resp.get("json") or {}).get("elements") or []
    items = []
    for el in elements:
        tags = el.get("tags") or {}
        la, lo = el.get("lat"), el.get("lon")
        if la is None or lo is None:
            continue
        kind = (tags.get("highway") or tags.get("railway") or
                tags.get("public_transport") or "stop")
        items.append({
            "id": el.get("id"),
            "name": tags.get("name"),
            "kind": kind,
            "ref": tags.get("ref"),
            "network": tags.get("network"),
            "operator": tags.get("operator"),
            "lat": la, "lon": lo,
            "distance_m": _haversine_m(lat, lon, la, lo),
            "tags": tags,
        })
    items.sort(key=lambda x: x["distance_m"])
    return {"ok": True, "result": {"count": len(items), "items": items}}


# ──────────────────────────────────────────────────────────────────────────
# LOCAL CONTEXT
# ──────────────────────────────────────────────────────────────────────────


def where_am_i(args: dict) -> dict:
    """Public-IP geolocation → city/region/lat/lon."""
    geo = _ip_geo()
    if not geo.get("ok"):
        return {"ok": False, "error": geo.get("error", "ipapi failed")}
    return {"ok": True, "result": {
        "city": geo.get("city"),
        "region": geo.get("region"),
        "country": geo.get("country"),
        "postal": geo.get("postal"),
        "lat": geo.get("lat"),
        "lon": geo.get("lon"),
        "ip": geo.get("ip"),
        "source": "ipapi",
    }}


def what_neighborhood(args: dict) -> dict:
    """Reverse-geocode and pull out neighborhood/suburb/district."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    resp = _nominatim_reverse(lat, lon)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "nominatim failed")}
    j = resp.get("json") or {}
    addr = j.get("address") or {}
    return {"ok": True, "result": {
        "neighborhood": (addr.get("neighbourhood") or addr.get("suburb")
                         or addr.get("quarter") or addr.get("city_district")
                         or addr.get("district")),
        "suburb": addr.get("suburb"),
        "city_district": addr.get("city_district"),
        "city": addr.get("city") or addr.get("town") or addr.get("village"),
        "county": addr.get("county"),
        "state": addr.get("state"),
        "country": addr.get("country"),
        "postcode": addr.get("postcode"),
        "display_name": j.get("display_name"),
        "raw_address": addr,
        "source": "nominatim",
    }}


# ──────────────────────────────────────────────────────────────────────────
# MISC
# ──────────────────────────────────────────────────────────────────────────


def distance_between(args: dict) -> dict:
    """Great-circle distance between two lat/lon points (Haversine)."""
    lat1 = _opt_float(args, "lat1"); lon1 = _opt_float(args, "lon1")
    lat2 = _opt_float(args, "lat2"); lon2 = _opt_float(args, "lon2")
    if None in (lat1, lon1, lat2, lon2):
        return {"ok": False, "error": "lat1, lon1, lat2, lon2 are all required"}
    unit = (args.get("unit") or "km").lower()
    meters = _haversine_m(lat1, lon1, lat2, lon2)
    if unit in ("m", "meter", "meters"):
        val = meters; label = "m"
    elif unit in ("mi", "mile", "miles"):
        val = meters / 1609.344; label = "mi"
    elif unit in ("nm", "nautical", "nautical_miles"):
        val = meters / 1852.0; label = "nm"
    else:
        val = meters / 1000.0; label = "km"
    return {"ok": True, "result": {"distance": round(val, 4), "unit": label,
                                   "meters": round(meters, 2)}}


def tile_url(args: dict) -> dict:
    """Return a raster tile URL for a given z/x/y."""
    z = _opt_int(args, "z")
    x = _opt_int(args, "x")
    y = _opt_int(args, "y")
    if None in (z, x, y):
        return {"ok": False, "error": "z, x, y are required"}
    provider = (args.get("provider") or "osm").lower()
    providers = {
        "osm": f"https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "carto-light": f"https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
        "carto-dark": f"https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
        "opentopomap": f"https://a.tile.opentopomap.org/{z}/{x}/{y}.png",
        "esri-satellite": (
            f"https://server.arcgisonline.com/ArcGIS/rest/services/"
            f"World_Imagery/MapServer/tile/{z}/{y}/{x}"
        ),
    }
    if provider not in providers:
        return {"ok": False, "error": f"unknown provider {provider!r}; "
                                       f"valid: {list(providers.keys())}"}
    return {"ok": True, "result": {
        "url": providers[provider],
        "provider": provider,
        "z": z, "x": x, "y": y,
        "attribution": "© OpenStreetMap contributors" if provider == "osm" else None,
    }}


def static_map(args: dict) -> dict:
    """Return a URL to a static-map image centered on lat/lon."""
    lat = _opt_float(args, "lat"); lon = _opt_float(args, "lon")
    if lat is None or lon is None:
        return {"ok": False, "error": "lat and lon are required"}
    zoom = _opt_int(args, "zoom", 15) or 15
    width = _opt_int(args, "width", 600) or 600
    height = _opt_int(args, "height", 400) or 400

    gkey = _env("GOOGLE_MAPS_API_KEY")
    if gkey:
        url = (
            "https://maps.googleapis.com/maps/api/staticmap"
            f"?center={lat},{lon}&zoom={zoom}&size={width}x{height}"
            f"&markers=color:red%7C{lat},{lon}&key={gkey}"
        )
        return {"ok": True, "result": {
            "url": url, "provider": "google", "lat": lat, "lon": lon,
            "zoom": zoom, "width": width, "height": height,
        }}

    # Free fallback: staticmap.openstreetmap.de
    url = (
        "https://staticmap.openstreetmap.de/staticmap.php"
        f"?center={lat},{lon}&zoom={zoom}&size={width}x{height}"
        f"&markers={lat},{lon},red-pushpin"
    )
    return {"ok": True, "result": {
        "url": url, "provider": "osm-staticmap", "lat": lat, "lon": lon,
        "zoom": zoom, "width": width, "height": height,
        "attribution": "© OpenStreetMap contributors",
    }}


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS — dotted-name registry
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # geocoding
    "maps.geocode": geocode,
    "maps.reverse_geocode": reverse_geocode,
    "maps.search_nearby": search_nearby,
    "maps.address_autocomplete": address_autocomplete,
    # directions
    "maps.directions": directions,
    "maps.directions_latlon": directions_latlon,
    "maps.travel_time": travel_time,
    "maps.eta_to": eta_to,
    # traffic
    "maps.traffic_now": traffic_now,
    "maps.alternate_routes": alternate_routes,
    # POIs
    "maps.gas_stations": gas_stations,
    "maps.restaurants": restaurants,
    "maps.coffee_shops": coffee_shops,
    "maps.parking": parking,
    "maps.ev_charging": ev_charging,
    "maps.atms": atms,
    "maps.pharmacies": pharmacies,
    "maps.hospitals_nearest": hospitals_nearest,
    "maps.airports_nearest": airports_nearest,
    # transit
    "maps.transit_directions": transit_directions,
    "maps.transit_stops_nearby": transit_stops_nearby,
    # local context
    "maps.where_am_i": where_am_i,
    "maps.what_neighborhood": what_neighborhood,
    # misc
    "maps.distance_between": distance_between,
    "maps.tile_url": tile_url,
    "maps.static_map": static_map,
}
