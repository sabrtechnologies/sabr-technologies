"""marketing.py — Leon's marketing & web-analytics hub.

Covers email marketing (Mailchimp, ConvertKit), social scheduling (Buffer),
web analytics (Google Analytics 4, Plausible), and a batch of free SEO / web
health checks (meta tags, headings, page speed, broken links, sitemap,
robots.txt, domain age).

Every tool reads credentials lazily (env first, then
`~/.openclaw/secrets.json`), makes `requests` calls with a 12s default
timeout, and returns the standard `{ok, ...}` contract. Nothing in this
module raises — every exception is wrapped into
`{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `marketing.mailchimp_lists`)
to callables that take a single `dict` argument. Import that dict from the
responder / MCP server to register everything in one shot.

Credentials read:
  - MAILCHIMP_API_KEY        (datacenter suffix is in the key after the dash,
                              e.g. "abc123...-us21")
  - CONVERTKIT_API_KEY       (public, used for reads)
  - CONVERTKIT_API_SECRET    (used for member-level / write endpoints)
  - BUFFER_ACCESS_TOKEN
  - GA4_PROPERTY_ID          (numeric property id)
  - GA4_ACCESS_TOKEN         (OAuth2 bearer for the Data API)
  - PLAUSIBLE_API_KEY
  - PAGESPEED_API_KEY        (optional — PageSpeed works keyless at low rate)

Secrets file fallback: `~/.openclaw/secrets.json` — a flat JSON object,
e.g. `{"MAILCHIMP_API_KEY": "...", "BUFFER_ACCESS_TOKEN": "...", ...}`.
"""

from __future__ import annotations

import json
import os
import re
import socket
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import urljoin, urlparse

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 12.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0
_UA = "LeonBot (47industries, marketing/1.0)"


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file.

    Returns `{}` on any error — caller falls through to a missing-credential
    message. Never raises, never logs values.
    """
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _wrap_http(resp: requests.Response) -> Dict[str, Any]:
    """Decode a Response into JSON when possible, else return raw text."""
    try:
        return {"status": resp.status_code, "json": resp.json()}
    except Exception:
        return {"status": resp.status_code, "text": resp.text[:2000]}


def _normalize_url(value: str) -> str:
    """Ensure a string has a scheme; default to https://."""
    value = (value or "").strip()
    if not value:
        return ""
    if not re.match(r"^https?://", value, re.I):
        value = "https://" + value
    return value


def _domain_root(value: str) -> str:
    """Return scheme://host for a domain or URL."""
    u = _normalize_url(value)
    p = urlparse(u)
    return f"{p.scheme}://{p.netloc}"


# ──────────────────────────────────────────────────────────────────────────
# MAILCHIMP
# ──────────────────────────────────────────────────────────────────────────


def _mailchimp_base() -> Optional[Dict[str, Any]]:
    """Return {base_url, auth} or None when the key is missing/malformed.

    The Mailchimp datacenter (e.g. "us21") is the suffix of the API key
    after the final dash.
    """
    key = _get_secret("MAILCHIMP_API_KEY")
    if not key or "-" not in key:
        return None
    dc = key.rsplit("-", 1)[-1].strip()
    if not dc:
        return None
    return {
        "base": f"https://{dc}.api.mailchimp.com/3.0",
        "auth": ("leon", key),
    }


def _mailchimp_lists(args: dict) -> dict:
    """List Mailchimp audiences (lists)."""
    try:
        cfg = _mailchimp_base()
        if not cfg:
            return _missing("MAILCHIMP_API_KEY", "Mailchimp")
        r = requests.get(
            f"{cfg['base']}/lists",
            auth=cfg["auth"],
            params={"count": 100, "fields": "lists.id,lists.name,"
                    "lists.stats.member_count,lists.stats.unsubscribe_count"},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        lists = (r.json() or {}).get("lists", [])
        compact = [
            {
                "id": l.get("id"),
                "name": l.get("name"),
                "members": (l.get("stats") or {}).get("member_count"),
                "unsubscribes": (l.get("stats") or {}).get("unsubscribe_count"),
            }
            for l in lists
        ]
        return {"ok": True, "lists": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _mailchimp_list_members(args: dict) -> dict:
    """List members of a Mailchimp audience."""
    try:
        list_id = str(args.get("list_id", "")).strip()
        if not list_id:
            return {"ok": False, "error": "list_id required"}
        limit = max(1, min(1000, int(args.get("limit", 30))))
        cfg = _mailchimp_base()
        if not cfg:
            return _missing("MAILCHIMP_API_KEY", "Mailchimp")
        r = requests.get(
            f"{cfg['base']}/lists/{list_id}/members",
            auth=cfg["auth"],
            params={"count": limit, "fields": "members.id,members.email_address,"
                    "members.status,members.merge_fields,total_items"},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        body = r.json() or {}
        members = body.get("members", [])
        compact = [
            {
                "id": m.get("id"),
                "email": m.get("email_address"),
                "status": m.get("status"),
                "merge_fields": m.get("merge_fields"),
            }
            for m in members
        ]
        return {"ok": True, "members": compact, "count": len(compact),
                "total": body.get("total_items")}
    except Exception as e:
        return _err(e)


def _mailchimp_add_subscriber(args: dict) -> dict:
    """Add (or update) a subscriber on a Mailchimp audience. MEDIUM."""
    try:
        list_id = str(args.get("list_id", "")).strip()
        email = str(args.get("email", "")).strip()
        if not list_id or not email:
            return {"ok": False, "error": "list_id and email required"}
        cfg = _mailchimp_base()
        if not cfg:
            return _missing("MAILCHIMP_API_KEY", "Mailchimp")
        merge: Dict[str, str] = {}
        if args.get("first_name"):
            merge["FNAME"] = str(args["first_name"])
        if args.get("last_name"):
            merge["LNAME"] = str(args["last_name"])
        import hashlib
        sub_hash = hashlib.md5(email.lower().encode("utf-8")).hexdigest()
        payload = {
            "email_address": email,
            "status_if_new": "subscribed",
            "status": "subscribed",
        }
        if merge:
            payload["merge_fields"] = merge
        r = requests.put(
            f"{cfg['base']}/lists/{list_id}/members/{sub_hash}",
            auth=cfg["auth"],
            json=payload,
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json() or {}
        return {"ok": True, "id": data.get("id"), "email": data.get("email_address"),
                "status": data.get("status")}
    except Exception as e:
        return _err(e)


def _mailchimp_campaigns(args: dict) -> dict:
    """List Mailchimp campaigns (most recent first)."""
    try:
        limit = max(1, min(1000, int(args.get("limit", 20))))
        cfg = _mailchimp_base()
        if not cfg:
            return _missing("MAILCHIMP_API_KEY", "Mailchimp")
        r = requests.get(
            f"{cfg['base']}/campaigns",
            auth=cfg["auth"],
            params={"count": limit, "sort_field": "create_time",
                    "sort_dir": "DESC"},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        camps = (r.json() or {}).get("campaigns", [])
        compact = [
            {
                "id": c.get("id"),
                "status": c.get("status"),
                "type": c.get("type"),
                "subject": (c.get("settings") or {}).get("subject_line"),
                "send_time": c.get("send_time"),
                "emails_sent": c.get("emails_sent"),
            }
            for c in camps
        ]
        return {"ok": True, "campaigns": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _mailchimp_campaign_report(args: dict) -> dict:
    """Fetch the report (opens, clicks, bounces) for a campaign."""
    try:
        campaign_id = str(args.get("campaign_id", "")).strip()
        if not campaign_id:
            return {"ok": False, "error": "campaign_id required"}
        cfg = _mailchimp_base()
        if not cfg:
            return _missing("MAILCHIMP_API_KEY", "Mailchimp")
        r = requests.get(
            f"{cfg['base']}/reports/{campaign_id}",
            auth=cfg["auth"],
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        d = r.json() or {}
        opens = d.get("opens") or {}
        clicks = d.get("clicks") or {}
        bounces = d.get("bounces") or {}
        return {
            "ok": True,
            "campaign_id": campaign_id,
            "subject": d.get("subject_line"),
            "emails_sent": d.get("emails_sent"),
            "opens": {
                "total": opens.get("opens_total"),
                "unique": opens.get("unique_opens"),
                "open_rate": opens.get("open_rate"),
            },
            "clicks": {
                "total": clicks.get("clicks_total"),
                "unique": clicks.get("unique_clicks"),
                "click_rate": clicks.get("click_rate"),
            },
            "bounces": {
                "hard": bounces.get("hard_bounces"),
                "soft": bounces.get("soft_bounces"),
            },
            "unsubscribed": d.get("unsubscribed"),
        }
    except Exception as e:
        return _err(e)


def _mailchimp_create_campaign(args: dict) -> dict:
    """Create a regular Mailchimp campaign (draft, not sent). MEDIUM."""
    try:
        list_id = str(args.get("list_id", "")).strip()
        subject = str(args.get("subject", "")).strip()
        from_name = str(args.get("from_name", "")).strip()
        reply_to = str(args.get("reply_to", "")).strip()
        if not (list_id and subject and from_name and reply_to):
            return {"ok": False,
                    "error": "list_id, subject, from_name, reply_to required"}
        cfg = _mailchimp_base()
        if not cfg:
            return _missing("MAILCHIMP_API_KEY", "Mailchimp")
        payload = {
            "type": "regular",
            "recipients": {"list_id": list_id},
            "settings": {
                "subject_line": subject,
                "from_name": from_name,
                "reply_to": reply_to,
            },
        }
        r = requests.post(
            f"{cfg['base']}/campaigns",
            auth=cfg["auth"],
            json=payload,
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        d = r.json() or {}
        return {"ok": True, "campaign_id": d.get("id"), "status": d.get("status"),
                "web_id": d.get("web_id")}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CONVERTKIT
# ──────────────────────────────────────────────────────────────────────────

_CONVERTKIT_API = "https://api.convertkit.com/v3"


def _convertkit_key(secret: bool = False) -> Optional[str]:
    """Return the ConvertKit public key, or the secret when secret=True."""
    if secret:
        return _get_secret("CONVERTKIT_API_SECRET")
    return _get_secret("CONVERTKIT_API_KEY")


def _convertkit_subscribers(args: dict) -> dict:
    """List ConvertKit subscribers (needs the API secret)."""
    try:
        limit = max(1, min(50, int(args.get("limit", 30))))
        sec = _convertkit_key(secret=True)
        if not sec:
            return _missing("CONVERTKIT_API_SECRET", "ConvertKit")
        r = requests.get(
            f"{_CONVERTKIT_API}/subscribers",
            params={"api_secret": sec, "page": 1},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        body = r.json() or {}
        subs = body.get("subscribers", [])[:limit]
        compact = [
            {
                "id": s.get("id"),
                "email": s.get("email_address"),
                "first_name": s.get("first_name"),
                "state": s.get("state"),
                "created_at": s.get("created_at"),
            }
            for s in subs
        ]
        return {"ok": True, "subscribers": compact, "count": len(compact),
                "total": body.get("total_subscribers")}
    except Exception as e:
        return _err(e)


def _convertkit_add_subscriber(args: dict) -> dict:
    """Add a subscriber to ConvertKit (via the account-wide form). MEDIUM.

    ConvertKit has no generic "add subscriber" — subscribers join through a
    form, sequence, or tag. This uses the tag endpoint when `tags` is given,
    otherwise the first available form.
    """
    try:
        email = str(args.get("email", "")).strip()
        if not email:
            return {"ok": False, "error": "email required"}
        key = _convertkit_key()
        if not key:
            return _missing("CONVERTKIT_API_KEY", "ConvertKit")
        payload: Dict[str, Any] = {"api_key": key, "email": email}
        if args.get("first_name"):
            payload["first_name"] = str(args["first_name"])

        tags = args.get("tags")
        if tags:
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",") if t.strip()]
            results = []
            for tag_id in tags:
                rt = requests.post(
                    f"{_CONVERTKIT_API}/tags/{tag_id}/subscribe",
                    json=payload,
                    headers={"User-Agent": _UA, "Content-Type": "application/json"},
                    timeout=_DEFAULT_TIMEOUT,
                )
                results.append({"tag_id": tag_id, "status": rt.status_code})
            ok = all(x["status"] < 400 for x in results)
            return {"ok": ok, "email": email, "tag_results": results}

        # No tags — find a form and subscribe to it.
        rf = requests.get(
            f"{_CONVERTKIT_API}/forms",
            params={"api_key": key},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if rf.status_code >= 400:
            return {"ok": False, "error": f"forms HTTP {rf.status_code}",
                    **_wrap_http(rf)}
        forms = (rf.json() or {}).get("forms", [])
        if not forms:
            return {"ok": False, "error": "no ConvertKit forms found — pass "
                    "tags=[tag_id] or create a form first"}
        form_id = forms[0].get("id")
        r = requests.post(
            f"{_CONVERTKIT_API}/forms/{form_id}/subscribe",
            json=payload,
            headers={"User-Agent": _UA, "Content-Type": "application/json"},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        d = (r.json() or {}).get("subscription", {})
        return {"ok": True, "email": email, "form_id": form_id,
                "subscription_id": d.get("id"), "state": d.get("state")}
    except Exception as e:
        return _err(e)


def _convertkit_tags(args: dict) -> dict:
    """List ConvertKit tags."""
    try:
        key = _convertkit_key()
        if not key:
            return _missing("CONVERTKIT_API_KEY", "ConvertKit")
        r = requests.get(
            f"{_CONVERTKIT_API}/tags",
            params={"api_key": key},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        tags = (r.json() or {}).get("tags", [])
        compact = [
            {"id": t.get("id"), "name": t.get("name"),
             "created_at": t.get("created_at")}
            for t in tags
        ]
        return {"ok": True, "tags": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _convertkit_broadcasts(args: dict) -> dict:
    """List ConvertKit broadcasts (one-off emails)."""
    try:
        sec = _convertkit_key(secret=True)
        if not sec:
            return _missing("CONVERTKIT_API_SECRET", "ConvertKit")
        r = requests.get(
            f"{_CONVERTKIT_API}/broadcasts",
            params={"api_secret": sec},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        bc = (r.json() or {}).get("broadcasts", [])
        compact = [
            {"id": b.get("id"), "subject": b.get("subject"),
             "created_at": b.get("created_at")}
            for b in bc
        ]
        return {"ok": True, "broadcasts": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _convertkit_sequences(args: dict) -> dict:
    """List ConvertKit sequences (drip courses)."""
    try:
        key = _convertkit_key()
        if not key:
            return _missing("CONVERTKIT_API_KEY", "ConvertKit")
        r = requests.get(
            f"{_CONVERTKIT_API}/sequences",
            params={"api_key": key},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        seqs = (r.json() or {}).get("courses", [])
        compact = [
            {"id": s.get("id"), "name": s.get("name"),
             "created_at": s.get("created_at")}
            for s in seqs
        ]
        return {"ok": True, "sequences": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# BUFFER
# ──────────────────────────────────────────────────────────────────────────

_BUFFER_API = "https://api.bufferapp.com/1"


def _buffer_token() -> Optional[str]:
    return _get_secret("BUFFER_ACCESS_TOKEN")


def _buffer_profiles(args: dict) -> dict:
    """List connected Buffer social profiles."""
    try:
        tok = _buffer_token()
        if not tok:
            return _missing("BUFFER_ACCESS_TOKEN", "Buffer")
        r = requests.get(
            f"{_BUFFER_API}/profiles.json",
            params={"access_token": tok},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        profs = r.json() or []
        compact = [
            {
                "id": p.get("id"),
                "service": p.get("service"),
                "username": p.get("formatted_username") or p.get("service_username"),
                "default": p.get("default"),
            }
            for p in profs
        ]
        return {"ok": True, "profiles": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _buffer_schedule_post(args: dict) -> dict:
    """Queue a post to a Buffer profile. MEDIUM.

    `scheduled_at` — ISO8601 string or epoch seconds. Omit to add to the
    profile's normal posting queue.
    """
    try:
        profile_id = str(args.get("profile_id", "")).strip()
        text = str(args.get("text", ""))
        if not profile_id or not text:
            return {"ok": False, "error": "profile_id and text required"}
        tok = _buffer_token()
        if not tok:
            return _missing("BUFFER_ACCESS_TOKEN", "Buffer")
        form: Dict[str, Any] = {
            "access_token": tok,
            "profile_ids[]": profile_id,
            "text": text,
        }
        sched = args.get("scheduled_at")
        if sched:
            epoch: Optional[int] = None
            if isinstance(sched, (int, float)):
                epoch = int(sched)
            else:
                s = str(sched).strip()
                if s.isdigit():
                    epoch = int(s)
                else:
                    try:
                        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
                        if dt.tzinfo is None:
                            dt = dt.replace(tzinfo=timezone.utc)
                        epoch = int(dt.timestamp())
                    except Exception:
                        return {"ok": False,
                                "error": f"could not parse scheduled_at: {sched}"}
            if epoch is not None:
                form["scheduled_at"] = epoch
        else:
            form["now"] = "false"
        r = requests.post(
            f"{_BUFFER_API}/updates/create.json",
            data=form,
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        d = r.json() or {}
        updates = d.get("updates", [])
        return {"ok": bool(d.get("success", True)),
                "buffer_count": d.get("buffer_count"),
                "update_ids": [u.get("id") for u in updates]}
    except Exception as e:
        return _err(e)


def _buffer_pending(args: dict) -> dict:
    """List pending (queued) updates for a Buffer profile."""
    try:
        profile_id = str(args.get("profile_id", "")).strip()
        if not profile_id:
            return {"ok": False, "error": "profile_id required"}
        tok = _buffer_token()
        if not tok:
            return _missing("BUFFER_ACCESS_TOKEN", "Buffer")
        r = requests.get(
            f"{_BUFFER_API}/profiles/{profile_id}/updates/pending.json",
            params={"access_token": tok},
            headers={"User-Agent": _UA},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        d = r.json() or {}
        updates = d.get("updates", [])
        compact = [
            {
                "id": u.get("id"),
                "text": u.get("text"),
                "status": u.get("status"),
                "due_at": u.get("due_at"),
            }
            for u in updates
        ]
        return {"ok": True, "pending": compact, "count": len(compact),
                "total": d.get("total")}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GOOGLE ANALYTICS 4
# ──────────────────────────────────────────────────────────────────────────

_GA4_DATA_API = "https://analyticsdata.googleapis.com/v1beta"


def _ga4_creds(property_id: Optional[str]) -> Optional[Dict[str, str]]:
    """Return {property_id, token} or None when missing."""
    pid = (property_id or "").strip() or _get_secret("GA4_PROPERTY_ID")
    tok = _get_secret("GA4_ACCESS_TOKEN")
    if not pid or not tok:
        return None
    pid = pid.replace("properties/", "").strip()
    return {"property_id": pid, "token": tok}


def _ga4_headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "User-Agent": _UA,
    }


def _ga4_rows(body: dict) -> List[Dict[str, Any]]:
    """Flatten a GA4 report response into a list of {dim..., metric...} dicts."""
    dim_headers = [h.get("name") for h in body.get("dimensionHeaders", [])]
    met_headers = [h.get("name") for h in body.get("metricHeaders", [])]
    rows = []
    for row in body.get("rows", []):
        rec: Dict[str, Any] = {}
        for i, dv in enumerate(row.get("dimensionValues", [])):
            name = dim_headers[i] if i < len(dim_headers) else f"dim{i}"
            rec[name] = dv.get("value")
        for i, mv in enumerate(row.get("metricValues", [])):
            name = met_headers[i] if i < len(met_headers) else f"metric{i}"
            rec[name] = mv.get("value")
        rows.append(rec)
    return rows


def _ga4_realtime_users(args: dict) -> dict:
    """Active users in the last 30 minutes (GA4 realtime report)."""
    try:
        cfg = _ga4_creds(args.get("property_id"))
        if not cfg:
            return _missing("GA4_PROPERTY_ID + GA4_ACCESS_TOKEN", "Google Analytics 4")
        r = requests.post(
            f"{_GA4_DATA_API}/properties/{cfg['property_id']}:runRealtimeReport",
            headers=_ga4_headers(cfg["token"]),
            json={"metrics": [{"name": "activeUsers"}]},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        rows = _ga4_rows(r.json() or {})
        active = 0
        if rows:
            try:
                active = int(rows[0].get("activeUsers", 0))
            except Exception:
                active = rows[0].get("activeUsers")
        return {"ok": True, "active_users": active,
                "property_id": cfg["property_id"]}
    except Exception as e:
        return _err(e)


def _ga4_report(args: dict) -> dict:
    """Run an arbitrary GA4 report.

    `metrics` — list/CSV of metric names (e.g. "sessions,activeUsers").
    `dimensions` — optional list/CSV of dimension names.
    `days` — trailing window (default 7).
    """
    try:
        cfg = _ga4_creds(args.get("property_id"))
        if not cfg:
            return _missing("GA4_PROPERTY_ID + GA4_ACCESS_TOKEN", "Google Analytics 4")
        metrics = args.get("metrics")
        if isinstance(metrics, str):
            metrics = [m.strip() for m in metrics.split(",") if m.strip()]
        if not metrics:
            return {"ok": False, "error": "metrics required (list or CSV)"}
        dims = args.get("dimensions")
        if isinstance(dims, str):
            dims = [d.strip() for d in dims.split(",") if d.strip()]
        days = max(1, min(365, int(args.get("days", 7))))
        payload: Dict[str, Any] = {
            "dateRanges": [{"startDate": f"{days}daysAgo", "endDate": "today"}],
            "metrics": [{"name": m} for m in metrics],
            "limit": 250,
        }
        if dims:
            payload["dimensions"] = [{"name": d} for d in dims]
        r = requests.post(
            f"{_GA4_DATA_API}/properties/{cfg['property_id']}:runReport",
            headers=_ga4_headers(cfg["token"]),
            json=payload,
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        body = r.json() or {}
        rows = _ga4_rows(body)
        return {"ok": True, "rows": rows, "count": len(rows),
                "row_total": body.get("rowCount")}
    except Exception as e:
        return _err(e)


def _ga4_top_pages(args: dict) -> dict:
    """Top pages by views over a trailing window."""
    try:
        limit = max(1, min(250, int(args.get("limit", 20))))
        res = _ga4_report({
            "metrics": ["screenPageViews", "activeUsers"],
            "dimensions": ["pagePath"],
            "days": args.get("days", 7),
            "property_id": args.get("property_id"),
        })
        if not res.get("ok"):
            return res
        rows = sorted(
            res["rows"],
            key=lambda x: int(x.get("screenPageViews", 0) or 0),
            reverse=True,
        )[:limit]
        return {"ok": True, "top_pages": rows, "count": len(rows)}
    except Exception as e:
        return _err(e)


def _ga4_traffic_sources(args: dict) -> dict:
    """Sessions broken down by channel grouping."""
    try:
        res = _ga4_report({
            "metrics": ["sessions", "activeUsers"],
            "dimensions": ["sessionDefaultChannelGroup"],
            "days": args.get("days", 7),
            "property_id": args.get("property_id"),
        })
        if not res.get("ok"):
            return res
        rows = sorted(
            res["rows"],
            key=lambda x: int(x.get("sessions", 0) or 0),
            reverse=True,
        )
        return {"ok": True, "sources": rows, "count": len(rows)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# PLAUSIBLE
# ──────────────────────────────────────────────────────────────────────────

_PLAUSIBLE_API = "https://plausible.io/api/v1"


def _plausible_headers() -> Optional[Dict[str, str]]:
    key = _get_secret("PLAUSIBLE_API_KEY")
    if not key:
        return None
    return {"Authorization": f"Bearer {key}", "User-Agent": _UA}


def _plausible_stats(args: dict) -> dict:
    """Aggregate stats (visitors, pageviews, bounce rate) for a site."""
    try:
        site_id = str(args.get("site_id", "")).strip()
        if not site_id:
            return {"ok": False, "error": "site_id required"}
        headers = _plausible_headers()
        if not headers:
            return _missing("PLAUSIBLE_API_KEY", "Plausible")
        period = str(args.get("period", "7d")).strip() or "7d"
        r = requests.get(
            f"{_PLAUSIBLE_API}/stats/aggregate",
            headers=headers,
            params={
                "site_id": site_id,
                "period": period,
                "metrics": "visitors,pageviews,bounce_rate,"
                           "visit_duration,visits",
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        results = (r.json() or {}).get("results", {})
        compact = {k: (v or {}).get("value") for k, v in results.items()}
        return {"ok": True, "site_id": site_id, "period": period,
                "stats": compact}
    except Exception as e:
        return _err(e)


def _plausible_top_pages(args: dict) -> dict:
    """Top pages for a Plausible site."""
    try:
        site_id = str(args.get("site_id", "")).strip()
        if not site_id:
            return {"ok": False, "error": "site_id required"}
        headers = _plausible_headers()
        if not headers:
            return _missing("PLAUSIBLE_API_KEY", "Plausible")
        period = str(args.get("period", "7d")).strip() or "7d"
        r = requests.get(
            f"{_PLAUSIBLE_API}/stats/breakdown",
            headers=headers,
            params={
                "site_id": site_id,
                "period": period,
                "property": "event:page",
                "metrics": "visitors,pageviews",
                "limit": 30,
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        results = (r.json() or {}).get("results", [])
        return {"ok": True, "site_id": site_id, "period": period,
                "top_pages": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _plausible_top_sources(args: dict) -> dict:
    """Top referral sources for a Plausible site."""
    try:
        site_id = str(args.get("site_id", "")).strip()
        if not site_id:
            return {"ok": False, "error": "site_id required"}
        headers = _plausible_headers()
        if not headers:
            return _missing("PLAUSIBLE_API_KEY", "Plausible")
        period = str(args.get("period", "7d")).strip() or "7d"
        r = requests.get(
            f"{_PLAUSIBLE_API}/stats/breakdown",
            headers=headers,
            params={
                "site_id": site_id,
                "period": period,
                "property": "visit:source",
                "metrics": "visitors",
                "limit": 30,
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        results = (r.json() or {}).get("results", [])
        return {"ok": True, "site_id": site_id, "period": period,
                "top_sources": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _plausible_realtime(args: dict) -> dict:
    """Current visitors on a Plausible site."""
    try:
        site_id = str(args.get("site_id", "")).strip()
        if not site_id:
            return {"ok": False, "error": "site_id required"}
        headers = _plausible_headers()
        if not headers:
            return _missing("PLAUSIBLE_API_KEY", "Plausible")
        r = requests.get(
            f"{_PLAUSIBLE_API}/stats/realtime/visitors",
            headers=headers,
            params={"site_id": site_id},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        try:
            visitors = int(r.text.strip())
        except Exception:
            visitors = r.text.strip()
        return {"ok": True, "site_id": site_id, "current_visitors": visitors}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# SEO / WEB CHECKS — HTML parsing helpers
# ──────────────────────────────────────────────────────────────────────────


class _MetaParser(HTMLParser):
    """Collects <title>, meta tags, link[rel], and headings from a page."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title: str = ""
        self._in_title = False
        self.metas: List[Dict[str, str]] = []
        self.links: List[Dict[str, str]] = []
        self.headings: List[Dict[str, str]] = []
        self._heading_tag: Optional[str] = None
        self._heading_buf: List[str] = []
        self.anchors: List[str] = []

    def handle_starttag(self, tag: str, attrs: Any) -> None:
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "title":
            self._in_title = True
        elif tag == "meta":
            self.metas.append(a)
        elif tag == "link":
            self.links.append(a)
        elif tag in ("h1", "h2", "h3"):
            self._heading_tag = tag
            self._heading_buf = []
        elif tag == "a" and a.get("href"):
            self.anchors.append(a["href"])

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self._in_title = False
        elif tag in ("h1", "h2", "h3") and self._heading_tag == tag:
            text = " ".join("".join(self._heading_buf).split())
            self.headings.append({"tag": tag, "text": text[:300]})
            self._heading_tag = None
            self._heading_buf = []

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title += data
        if self._heading_tag:
            self._heading_buf.append(data)


def _fetch_html(url: str) -> Dict[str, Any]:
    """GET a URL and return {ok, text, final_url, status} or an error dict."""
    try:
        r = requests.get(
            url,
            headers={"User-Agent": _UA, "Accept": "text/html,*/*"},
            timeout=_DEFAULT_TIMEOUT,
            allow_redirects=True,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}",
                    "status": r.status_code}
        return {"ok": True, "text": r.text, "final_url": r.url,
                "status": r.status_code}
    except Exception as e:
        return _err(e)


def _seo_meta_check(args: dict) -> dict:
    """Audit a page's title, meta description, OG tags, and canonical."""
    try:
        url = _normalize_url(str(args.get("url", "")))
        if not url:
            return {"ok": False, "error": "url required"}
        fetched = _fetch_html(url)
        if not fetched.get("ok"):
            return fetched
        p = _MetaParser()
        p.feed(fetched["text"])

        title = " ".join(p.title.split())
        description = ""
        robots = ""
        og: Dict[str, str] = {}
        twitter: Dict[str, str] = {}
        for m in p.metas:
            name = (m.get("name") or "").lower()
            prop = (m.get("property") or "").lower()
            content = m.get("content", "")
            if name == "description":
                description = content
            elif name == "robots":
                robots = content
            elif prop.startswith("og:"):
                og[prop] = content
            elif name.startswith("twitter:"):
                twitter[name] = content

        canonical = ""
        for l in p.links:
            if (l.get("rel") or "").lower() == "canonical":
                canonical = l.get("href", "")
                break

        issues = []
        if not title:
            issues.append("missing <title>")
        elif not (10 <= len(title) <= 60):
            issues.append(f"title length {len(title)} (ideal 10-60)")
        if not description:
            issues.append("missing meta description")
        elif not (50 <= len(description) <= 160):
            issues.append(f"meta description length {len(description)} "
                          f"(ideal 50-160)")
        if not og:
            issues.append("no Open Graph tags")
        if not canonical:
            issues.append("no canonical link")

        return {
            "ok": True,
            "url": fetched["final_url"],
            "title": title,
            "title_length": len(title),
            "meta_description": description,
            "description_length": len(description),
            "canonical": canonical,
            "robots": robots,
            "open_graph": og,
            "twitter_card": twitter,
            "issues": issues,
        }
    except Exception as e:
        return _err(e)


def _seo_headings(args: dict) -> dict:
    """Report the H1/H2/H3 outline of a page."""
    try:
        url = _normalize_url(str(args.get("url", "")))
        if not url:
            return {"ok": False, "error": "url required"}
        fetched = _fetch_html(url)
        if not fetched.get("ok"):
            return fetched
        p = _MetaParser()
        p.feed(fetched["text"])
        h1 = [h for h in p.headings if h["tag"] == "h1"]
        h2 = [h for h in p.headings if h["tag"] == "h2"]
        h3 = [h for h in p.headings if h["tag"] == "h3"]
        issues = []
        if len(h1) == 0:
            issues.append("no H1 on page")
        elif len(h1) > 1:
            issues.append(f"{len(h1)} H1 tags (should be exactly 1)")
        return {
            "ok": True,
            "url": fetched["final_url"],
            "outline": p.headings,
            "counts": {"h1": len(h1), "h2": len(h2), "h3": len(h3)},
            "issues": issues,
        }
    except Exception as e:
        return _err(e)


def _page_speed(args: dict) -> dict:
    """Run Google PageSpeed Insights on a URL (Lighthouse scores)."""
    try:
        url = _normalize_url(str(args.get("url", "")))
        if not url:
            return {"ok": False, "error": "url required"}
        params: Dict[str, Any] = {
            "url": url,
            "category": ["performance", "seo", "accessibility", "best-practices"],
            "strategy": str(args.get("strategy", "mobile")),
        }
        key = _get_secret("PAGESPEED_API_KEY")
        if key:
            params["key"] = key
        r = requests.get(
            "https://www.googleapis.com/pagespeedonline/v5/runPagespeed",
            params=params,
            headers={"User-Agent": _UA},
            timeout=max(_DEFAULT_TIMEOUT, 30.0),
        )
        if r.status_code >= 400:
            hint = "" if key else " (try setting PAGESPEED_API_KEY if rate-limited)"
            return {"ok": False, "error": f"HTTP {r.status_code}{hint}",
                    **_wrap_http(r)}
        d = r.json() or {}
        lh = d.get("lighthouseResult", {})
        cats = lh.get("categories", {})
        scores = {
            name: round((c.get("score") or 0) * 100)
            for name, c in cats.items()
        }
        audits = lh.get("audits", {})
        metrics = {}
        for k in ("first-contentful-paint", "largest-contentful-paint",
                  "cumulative-layout-shift", "total-blocking-time",
                  "speed-index", "interactive"):
            if k in audits:
                metrics[k] = audits[k].get("displayValue")
        return {
            "ok": True,
            "url": url,
            "scores": scores,
            "metrics": metrics,
            "keyed": bool(key),
        }
    except Exception as e:
        return _err(e)


def _broken_links(args: dict) -> dict:
    """Crawl one page and HEAD-check every link it contains."""
    try:
        url = _normalize_url(str(args.get("url", "")))
        if not url:
            return {"ok": False, "error": "url required"}
        limit = max(1, min(200, int(args.get("limit", 100))))
        fetched = _fetch_html(url)
        if not fetched.get("ok"):
            return fetched
        p = _MetaParser()
        p.feed(fetched["text"])
        base = fetched["final_url"]

        seen: List[str] = []
        for href in p.anchors:
            href = href.strip()
            if not href or href.startswith(("#", "mailto:", "tel:", "javascript:")):
                continue
            absolute = urljoin(base, href)
            if absolute.startswith(("http://", "https://")) and absolute not in seen:
                seen.append(absolute)
            if len(seen) >= limit:
                break

        broken: List[Dict[str, Any]] = []
        checked = 0
        for link in seen:
            checked += 1
            try:
                hr = requests.head(
                    link, headers={"User-Agent": _UA},
                    timeout=_DEFAULT_TIMEOUT, allow_redirects=True,
                )
                code = hr.status_code
                if code == 405 or code >= 400:
                    # Some servers reject HEAD — retry with a ranged GET.
                    gr = requests.get(
                        link, headers={"User-Agent": _UA, "Range": "bytes=0-0"},
                        timeout=_DEFAULT_TIMEOUT, allow_redirects=True, stream=True,
                    )
                    code = gr.status_code
                    gr.close()
                if code >= 400:
                    broken.append({"url": link, "status": code})
            except Exception as e:
                broken.append({"url": link, "status": None,
                               "error": f"{type(e).__name__}"})
        return {
            "ok": True,
            "url": base,
            "links_found": len(seen),
            "links_checked": checked,
            "broken": broken,
            "broken_count": len(broken),
        }
    except Exception as e:
        return _err(e)


def _sitemap_urls(args: dict) -> dict:
    """Fetch and parse a domain's sitemap.xml (follows sitemap indexes once)."""
    try:
        domain = str(args.get("domain", "")).strip()
        if not domain:
            return {"ok": False, "error": "domain required"}
        root = _domain_root(domain)

        def _grab(sitemap_url: str) -> Dict[str, Any]:
            r = requests.get(
                sitemap_url, headers={"User-Agent": _UA},
                timeout=_DEFAULT_TIMEOUT,
            )
            if r.status_code >= 400:
                return {"ok": False, "status": r.status_code, "text": ""}
            return {"ok": True, "status": r.status_code, "text": r.text}

        # Honour a Sitemap: directive in robots.txt if present.
        sitemap_url = root + "/sitemap.xml"
        try:
            rob = requests.get(root + "/robots.txt",
                               headers={"User-Agent": _UA},
                               timeout=_DEFAULT_TIMEOUT)
            if rob.status_code < 400:
                m = re.search(r"(?im)^\s*sitemap:\s*(\S+)", rob.text)
                if m:
                    sitemap_url = m.group(1).strip()
        except Exception:
            pass

        first = _grab(sitemap_url)
        if not first["ok"]:
            return {"ok": False, "error": f"sitemap fetch failed "
                    f"(HTTP {first['status']}) at {sitemap_url}"}
        text = first["text"]
        loc_urls = re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", text, re.I)

        is_index = "<sitemapindex" in text.lower()
        nested_counts: List[Dict[str, Any]] = []
        if is_index:
            all_urls: List[str] = []
            for sm in loc_urls[:25]:
                sub = _grab(sm.strip())
                if sub["ok"]:
                    sub_urls = re.findall(r"<loc>\s*([^<\s]+)\s*</loc>",
                                          sub["text"], re.I)
                    all_urls.extend(sub_urls)
                    nested_counts.append({"sitemap": sm.strip(),
                                          "urls": len(sub_urls)})
            urls = all_urls
        else:
            urls = loc_urls

        return {
            "ok": True,
            "sitemap_url": sitemap_url,
            "is_index": is_index,
            "nested_sitemaps": nested_counts or None,
            "url_count": len(urls),
            "urls": urls[:500],
        }
    except Exception as e:
        return _err(e)


def _robots_txt(args: dict) -> dict:
    """Fetch and summarize a domain's robots.txt."""
    try:
        domain = str(args.get("domain", "")).strip()
        if not domain:
            return {"ok": False, "error": "domain required"}
        root = _domain_root(domain)
        r = requests.get(root + "/robots.txt",
                         headers={"User-Agent": _UA},
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}",
                    "url": root + "/robots.txt"}
        text = r.text
        sitemaps = re.findall(r"(?im)^\s*sitemap:\s*(\S+)", text)
        agents: List[Dict[str, Any]] = []
        current: Optional[Dict[str, Any]] = None
        for line in text.splitlines():
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            if ":" not in line:
                continue
            field, _, value = line.partition(":")
            field = field.strip().lower()
            value = value.strip()
            if field == "user-agent":
                if current is None or current.get("_started_rules"):
                    current = {"user_agent": value, "disallow": [],
                               "allow": [], "_started_rules": False}
                    agents.append(current)
                else:
                    current["user_agent"] = value
            elif field == "disallow" and current is not None:
                current["disallow"].append(value)
                current["_started_rules"] = True
            elif field == "allow" and current is not None:
                current["allow"].append(value)
                current["_started_rules"] = True
        for a in agents:
            a.pop("_started_rules", None)
        return {
            "ok": True,
            "url": root + "/robots.txt",
            "sitemaps": sitemaps,
            "agents": agents,
            "raw": text[:3000],
        }
    except Exception as e:
        return _err(e)


def _domain_age(args: dict) -> dict:
    """Look up a domain's registration / creation date via RDAP."""
    try:
        domain = str(args.get("domain", "")).strip()
        if not domain:
            return {"ok": False, "error": "domain required"}
        # Strip scheme / path / port / leading www.
        host = urlparse(_normalize_url(domain)).netloc or domain
        host = host.split("@")[-1].split(":")[0].strip().lower()
        if host.startswith("www."):
            host = host[4:]
        if not host:
            return {"ok": False, "error": "could not parse a domain from input"}

        r = requests.get(
            f"https://rdap.org/domain/{host}",
            headers={"User-Agent": _UA, "Accept": "application/rdap+json"},
            timeout=_DEFAULT_TIMEOUT,
            allow_redirects=True,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"RDAP HTTP {r.status_code}",
                    "domain": host}
        d = r.json() or {}
        events = {e.get("eventAction"): e.get("eventDate")
                  for e in d.get("events", [])}
        created = events.get("registration")
        expires = events.get("expiration")
        updated = events.get("last changed") or events.get("last update of RDAP database")

        age_days = None
        age_years = None
        if created:
            try:
                cdt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                if cdt.tzinfo is None:
                    cdt = cdt.replace(tzinfo=timezone.utc)
                delta = datetime.now(timezone.utc) - cdt
                age_days = delta.days
                age_years = round(delta.days / 365.25, 2)
            except Exception:
                pass

        registrar = None
        for ent in d.get("entities", []):
            roles = ent.get("roles", [])
            if "registrar" in roles:
                for v in (ent.get("vcardArray") or [[], []])[1]:
                    if isinstance(v, list) and v and v[0] == "fn":
                        registrar = v[3]
                        break
                break

        return {
            "ok": True,
            "domain": host,
            "created": created,
            "expires": expires,
            "updated": updated,
            "age_days": age_days,
            "age_years": age_years,
            "registrar": registrar,
            "status": d.get("status"),
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CROSS-BACKEND
# ──────────────────────────────────────────────────────────────────────────


def _list_configured(args: dict) -> dict:
    """Report which marketing backends have credentials present."""
    try:
        mc = _get_secret("MAILCHIMP_API_KEY")
        backends = {
            "mailchimp": {
                "configured": bool(mc and "-" in (mc or "")),
                "needs": "MAILCHIMP_API_KEY",
                "datacenter": (mc.rsplit("-", 1)[-1] if mc and "-" in mc else None),
            },
            "convertkit": {
                "configured": bool(_get_secret("CONVERTKIT_API_KEY")),
                "has_secret": bool(_get_secret("CONVERTKIT_API_SECRET")),
                "needs": "CONVERTKIT_API_KEY (+ CONVERTKIT_API_SECRET for reads)",
            },
            "buffer": {
                "configured": bool(_get_secret("BUFFER_ACCESS_TOKEN")),
                "needs": "BUFFER_ACCESS_TOKEN",
            },
            "ga4": {
                "configured": bool(_get_secret("GA4_PROPERTY_ID")
                                   and _get_secret("GA4_ACCESS_TOKEN")),
                "needs": "GA4_PROPERTY_ID + GA4_ACCESS_TOKEN",
            },
            "plausible": {
                "configured": bool(_get_secret("PLAUSIBLE_API_KEY")),
                "needs": "PLAUSIBLE_API_KEY",
            },
            "pagespeed": {
                "configured": True,
                "keyed": bool(_get_secret("PAGESPEED_API_KEY")),
                "needs": "PAGESPEED_API_KEY (optional — works keyless at low rate)",
            },
            "seo_checks": {
                "configured": True,
                "needs": "nothing — meta/headings/links/sitemap/robots/RDAP "
                         "are keyless",
            },
        }
        ready = [k for k, v in backends.items() if v.get("configured")]
        return {"ok": True, "backends": backends, "ready": ready,
                "ready_count": len(ready)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Mailchimp
    "marketing.mailchimp_lists": _mailchimp_lists,
    "marketing.mailchimp_list_members": _mailchimp_list_members,
    "marketing.mailchimp_add_subscriber": _mailchimp_add_subscriber,
    "marketing.mailchimp_campaigns": _mailchimp_campaigns,
    "marketing.mailchimp_campaign_report": _mailchimp_campaign_report,
    "marketing.mailchimp_create_campaign": _mailchimp_create_campaign,
    # ConvertKit
    "marketing.convertkit_subscribers": _convertkit_subscribers,
    "marketing.convertkit_add_subscriber": _convertkit_add_subscriber,
    "marketing.convertkit_tags": _convertkit_tags,
    "marketing.convertkit_broadcasts": _convertkit_broadcasts,
    "marketing.convertkit_sequences": _convertkit_sequences,
    # Buffer / social scheduling
    "marketing.buffer_profiles": _buffer_profiles,
    "marketing.buffer_schedule_post": _buffer_schedule_post,
    "marketing.buffer_pending": _buffer_pending,
    # Google Analytics 4
    "marketing.ga4_realtime_users": _ga4_realtime_users,
    "marketing.ga4_report": _ga4_report,
    "marketing.ga4_top_pages": _ga4_top_pages,
    "marketing.ga4_traffic_sources": _ga4_traffic_sources,
    # Plausible
    "marketing.plausible_stats": _plausible_stats,
    "marketing.plausible_top_pages": _plausible_top_pages,
    "marketing.plausible_top_sources": _plausible_top_sources,
    "marketing.plausible_realtime": _plausible_realtime,
    # SEO / web checks
    "marketing.seo_meta_check": _seo_meta_check,
    "marketing.seo_headings": _seo_headings,
    "marketing.page_speed": _page_speed,
    "marketing.broken_links": _broken_links,
    "marketing.sitemap_urls": _sitemap_urls,
    "marketing.robots_txt": _robots_txt,
    "marketing.domain_age": _domain_age,
    # Cross
    "marketing.list_configured": _list_configured,
}
