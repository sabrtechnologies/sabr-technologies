"""
phone.py — Leon's phone control surface (KDE Connect + Twilio fallback).

Dean's daily-driver phone is already paired to this workstation over KDE
Connect (kdeconnect ports 1714-1764 are firewall-allowed). The KDE tools
in this module shell out to `kdeconnect-cli` to send SMS, ring the lost
phone, push notifications, share URLs / files / text, and read battery
state — no extra service, no API key.

When sending from Dean's phone number isn't viable (e.g. an automated
outbound call, a number Dean doesn't want to expose, or while the phone
is offline), the `twilio_*` tools provide a programmable fallback over
the Twilio REST API. They lazy-load credentials from the environment:

    TWILIO_ACCOUNT_SID
    TWILIO_AUTH_TOKEN
    TWILIO_FROM_NUMBER

If any are missing, the affected tools return a helpful error rather
than raising.

Misc tools: `dial_number` opens a tel:// URI via xdg-open (KDE Connect's
phone-link picks it up), and a tiny JSON-backed contacts store at
`brain_state/contacts.json` gives Leon a place to remember numbers
without depending on Akonadi being populated.

Each tool takes a single `args` dict and returns either
`{"ok": True, "result": ...}` or `{"ok": False, "error": "..."}`.
The EXTRA_TOOLS dict at the bottom maps dotted tool names (e.g.
`phone.kde_send_sms`) to implementing functions — import this dict from
the responder / MCP server to register them in one shot.
"""

from __future__ import annotations

import base64
import glob
import json
import os
import shutil
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from typing import Any, Callable, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────────
# PATHS, CONSTANTS, HELPERS
# ──────────────────────────────────────────────────────────────────────────


_HTTP_TIMEOUT = 15.0
_CLI_TIMEOUT = 20.0
_CONTACTS_LOCK = threading.Lock()


def _project_root() -> str:
    """Project directory (parent of brain/). Used to locate brain_state/."""
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _brain_state_dir() -> str:
    d = os.path.join(_project_root(), "brain_state")
    os.makedirs(d, exist_ok=True)
    return d


def _contacts_path() -> str:
    return os.path.join(_brain_state_dir(), "contacts.json")


def _kde_data_dir() -> str:
    return os.path.expanduser("~/.local/share/kdeconnect")


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


def _have_kdeconnect() -> Optional[str]:
    """Return path to `kdeconnect-cli`, or None if not installed."""
    return shutil.which("kdeconnect-cli")


def _require_kde() -> Optional[Dict[str, Any]]:
    """Return an error-dict if kdeconnect-cli isn't installed, else None."""
    if _have_kdeconnect() is None:
        return _err("kdeconnect-cli not installed (sudo apt install kdeconnect)")
    return None


def _run_cli(cmd: List[str], timeout: float = _CLI_TIMEOUT) -> Dict[str, Any]:
    """Run a subprocess and return {ok, stdout, stderr, returncode}. Never
    raises — all exceptions become an `ok: False` dict."""
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return {
            "ok": proc.returncode == 0,
            "stdout": proc.stdout or "",
            "stderr": proc.stderr or "",
            "returncode": proc.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "stdout": "", "stderr": f"timeout after {timeout}s", "returncode": -1}
    except FileNotFoundError as e:
        return {"ok": False, "stdout": "", "stderr": str(e), "returncode": -1}
    except Exception as e:
        return {"ok": False, "stdout": "", "stderr": f"{type(e).__name__}: {e}", "returncode": -1}


def _parse_kde_device_lines(text: str) -> List[Dict[str, str]]:
    """Parse `kdeconnect-cli --list-*` output into [{id, name, status}, ...].
    Each non-empty line typically looks like:
        - Pixel 7 (abc123def456): paired and reachable
    We also handle `--id-only` output where each line is just an ID."""
    out: List[Dict[str, str]] = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        # `--id-only` form: just the device ID, no spaces
        if " " not in line and "(" not in line:
            out.append({"id": line, "name": "", "status": ""})
            continue
        # Strip leading "- " bullet if present
        if line.startswith("- "):
            line = line[2:].strip()
        name = line
        dev_id = ""
        status = ""
        if "(" in line and ")" in line:
            name = line.split("(", 1)[0].strip()
            rest = line.split("(", 1)[1]
            dev_id = rest.split(")", 1)[0].strip()
            tail = rest.split(")", 1)[1].strip()
            if tail.startswith(":"):
                status = tail[1:].strip()
            else:
                status = tail
        out.append({"id": dev_id, "name": name, "status": status})
    return out


def _primary_device_id() -> Optional[str]:
    """Find a reachable, paired device ID — used when caller omits one.
    Returns None if no device is reachable."""
    if _have_kdeconnect() is None:
        return None
    # Prefer reachable+paired
    r = _run_cli(["kdeconnect-cli", "--list-available", "--id-only"])
    if r["ok"]:
        for line in r["stdout"].splitlines():
            line = line.strip()
            if line:
                return line
    # Fall back to any known device
    r = _run_cli(["kdeconnect-cli", "--list-devices", "--id-only"])
    if r["ok"]:
        for line in r["stdout"].splitlines():
            line = line.strip()
            if line:
                return line
    return None


def _resolve_device(args: Dict[str, Any]) -> Optional[str]:
    """Pull `device_id` from args, falling back to the primary device."""
    dev = (args.get("device_id") or "").strip() if args else ""
    if dev:
        return dev
    return _primary_device_id()


# ──────────────────────────────────────────────────────────────────────────
# KDE CONNECT TOOLS
# ──────────────────────────────────────────────────────────────────────────


def kde_list_devices(args: Dict[str, Any]) -> Dict[str, Any]:
    """List paired/available KDE Connect devices. Returns id+name+status
    for each. Uses `--list-available` by default; pass `all=True` to
    include unreachable paired devices."""
    miss = _require_kde()
    if miss:
        return miss
    include_all = bool(args.get("all", False)) if args else False
    flag = "--list-devices" if include_all else "--list-available"
    # First call: pretty form for names+status
    pretty = _run_cli(["kdeconnect-cli", flag])
    if not pretty["ok"]:
        return _err(f"kdeconnect-cli {flag} failed: {pretty['stderr'].strip() or pretty['stdout'].strip()}")
    devices = _parse_kde_device_lines(pretty["stdout"])
    # If parsing didn't yield IDs, supplement with `--id-only`
    if devices and not any(d.get("id") for d in devices):
        ids = _run_cli(["kdeconnect-cli", flag, "--id-only"])
        if ids["ok"]:
            id_list = [ln.strip() for ln in ids["stdout"].splitlines() if ln.strip()]
            for i, d in enumerate(devices):
                if i < len(id_list):
                    d["id"] = id_list[i]
    return _ok({"count": len(devices), "devices": devices})


def kde_send_sms(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send an SMS from Dean's phone via KDE Connect.
    Args: device_id (optional — auto-resolved), number, message."""
    miss = _require_kde()
    if miss:
        return miss
    number = (args.get("number") or "").strip()
    message = args.get("message") or ""
    if not number:
        return _err("number is required")
    if not message:
        return _err("message is required")
    dev = _resolve_device(args)
    if not dev:
        return _err("no KDE Connect device available (is your phone paired and reachable?)")
    r = _run_cli([
        "kdeconnect-cli",
        "--device", dev,
        "--send-sms", message,
        "--destination", number,
    ])
    if not r["ok"]:
        return _err(f"send-sms failed: {r['stderr'].strip() or r['stdout'].strip()}")
    return _ok({"device_id": dev, "number": number, "chars": len(message)})


def kde_ring(args: Dict[str, Any]) -> Dict[str, Any]:
    """Ring the phone to find it. Args: device_id (optional)."""
    miss = _require_kde()
    if miss:
        return miss
    dev = _resolve_device(args)
    if not dev:
        return _err("no KDE Connect device available")
    r = _run_cli(["kdeconnect-cli", "--device", dev, "--ring"])
    if not r["ok"]:
        return _err(f"ring failed: {r['stderr'].strip() or r['stdout'].strip()}")
    return _ok({"device_id": dev, "rang": True})


def kde_battery(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read phone battery level. Tries qdbus first, then KDE Connect's
    on-disk cache as a fallback. Args: device_id (optional)."""
    miss = _require_kde()
    if miss:
        return miss
    dev = _resolve_device(args)
    if not dev:
        return _err("no KDE Connect device available")
    # Try qdbus (KDE Connect exposes a Battery interface per device)
    qdbus = shutil.which("qdbus") or shutil.which("qdbus6") or shutil.which("qdbus-qt5")
    if qdbus:
        path = f"/modules/kdeconnect/devices/{dev}/battery"
        charge = _run_cli([qdbus, "org.kde.kdeconnect", path, "org.kde.kdeconnect.device.battery.charge"])
        charging = _run_cli([qdbus, "org.kde.kdeconnect", path, "org.kde.kdeconnect.device.battery.isCharging"])
        if charge["ok"] and charge["stdout"].strip():
            try:
                level = int(charge["stdout"].strip())
                is_charging = charging["stdout"].strip().lower() == "true" if charging["ok"] else None
                return _ok({"device_id": dev, "level": level, "charging": is_charging, "source": "qdbus"})
            except ValueError:
                pass
    # On-disk cache fallback — KDE Connect's config dir
    config_dir = os.path.join(os.path.expanduser("~/.config/kdeconnect"), dev)
    for fname in ("battery", "battery.conf", "device.conf"):
        candidate = os.path.join(config_dir, fname)
        if os.path.isfile(candidate):
            try:
                with open(candidate, "r", encoding="utf-8", errors="ignore") as f:
                    text = f.read()
                # Look for a `charge=NN` style line
                for line in text.splitlines():
                    if "=" in line and ("charge" in line.lower() or "level" in line.lower()):
                        val = line.split("=", 1)[1].strip()
                        try:
                            return _ok({"device_id": dev, "level": int(val), "source": candidate})
                        except ValueError:
                            continue
            except Exception:
                continue
    return _err("battery level unavailable (qdbus + cache both empty — is the phone reachable?)")


def kde_share_url(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open a URL on the phone (KDE Connect's Share plugin).
    Args: url, device_id (optional)."""
    miss = _require_kde()
    if miss:
        return miss
    url = (args.get("url") or "").strip()
    if not url:
        return _err("url is required")
    dev = _resolve_device(args)
    if not dev:
        return _err("no KDE Connect device available")
    r = _run_cli(["kdeconnect-cli", "--device", dev, "--share", url])
    if not r["ok"]:
        return _err(f"share failed: {r['stderr'].strip() or r['stdout'].strip()}")
    return _ok({"device_id": dev, "url": url})


def kde_share_text(args: Dict[str, Any]) -> Dict[str, Any]:
    """Push text to the phone's clipboard via KDE Connect's --share-text.
    Args: text, device_id (optional)."""
    miss = _require_kde()
    if miss:
        return miss
    text = args.get("text") or ""
    if not text:
        return _err("text is required")
    dev = _resolve_device(args)
    if not dev:
        return _err("no KDE Connect device available")
    # Newer kdeconnect-cli has --share-text; older versions only --share.
    r = _run_cli(["kdeconnect-cli", "--device", dev, "--share-text", text])
    if not r["ok"]:
        # Fallback: write to a tempfile and --share it (lands as a file, not clipboard,
        # but is the best we can do on old kdeconnect-cli versions).
        return _err(f"share-text failed: {r['stderr'].strip() or r['stdout'].strip()}")
    return _ok({"device_id": dev, "chars": len(text)})


def kde_send_file(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send a file to the phone. Args: file_path, device_id (optional)."""
    miss = _require_kde()
    if miss:
        return miss
    file_path = (args.get("file_path") or "").strip()
    if not file_path:
        return _err("file_path is required")
    file_path = os.path.expanduser(file_path)
    if not os.path.isfile(file_path):
        return _err(f"file not found: {file_path}")
    dev = _resolve_device(args)
    if not dev:
        return _err("no KDE Connect device available")
    r = _run_cli(
        ["kdeconnect-cli", "--device", dev, "--share", file_path],
        timeout=120.0,  # transfers can be slow
    )
    if not r["ok"]:
        return _err(f"send-file failed: {r['stderr'].strip() or r['stdout'].strip()}")
    return _ok({"device_id": dev, "file": file_path, "bytes": os.path.getsize(file_path)})


def kde_notification(args: Dict[str, Any]) -> Dict[str, Any]:
    """Push a notification to the phone. Args: title, message, device_id (optional)."""
    miss = _require_kde()
    if miss:
        return miss
    title = (args.get("title") or "").strip()
    message = args.get("message") or ""
    if not title:
        return _err("title is required")
    dev = _resolve_device(args)
    if not dev:
        return _err("no KDE Connect device available")
    cmd = ["kdeconnect-cli", "--device", dev, "--send-notification", title]
    if message:
        cmd.extend(["--message", message])
    r = _run_cli(cmd)
    if not r["ok"]:
        return _err(f"send-notification failed: {r['stderr'].strip() or r['stdout'].strip()}")
    return _ok({"device_id": dev, "title": title})


def kde_read_notifications(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read recent phone notifications cached by KDE Connect under
    `~/.local/share/kdeconnect/{device_id}/notifications/`. Returns the
    most-recently-modified entries (default limit 20). Args: device_id
    (optional), limit (optional)."""
    miss = _require_kde()
    if miss:
        return miss
    dev = _resolve_device(args)
    limit = int(args.get("limit", 20)) if args else 20
    base = _kde_data_dir()
    if not os.path.isdir(base):
        return _err(f"no KDE Connect data dir at {base}")
    search_dirs: List[str] = []
    if dev:
        search_dirs.append(os.path.join(base, dev))
    else:
        # All device subdirs
        try:
            for entry in os.listdir(base):
                p = os.path.join(base, entry)
                if os.path.isdir(p):
                    search_dirs.append(p)
        except OSError as e:
            return _err(f"listing {base}: {e}")
    found: List[Dict[str, Any]] = []
    for d in search_dirs:
        for sub in ("notifications", "Notifications"):
            ndir = os.path.join(d, sub)
            if os.path.isdir(ndir):
                for path in glob.glob(os.path.join(ndir, "*")):
                    try:
                        st = os.stat(path)
                    except OSError:
                        continue
                    entry: Dict[str, Any] = {
                        "path": path,
                        "mtime": st.st_mtime,
                        "size": st.st_size,
                    }
                    # Try to read JSON / text content
                    try:
                        with open(path, "r", encoding="utf-8", errors="ignore") as f:
                            raw = f.read(4096)
                        try:
                            entry["content"] = json.loads(raw)
                        except json.JSONDecodeError:
                            entry["content"] = raw
                    except Exception:
                        pass
                    found.append(entry)
    found.sort(key=lambda e: e["mtime"], reverse=True)
    return _ok({"count": len(found), "notifications": found[:limit]})


def kde_pair_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Report pair status for a given device. Args: device_id (required)."""
    miss = _require_kde()
    if miss:
        return miss
    dev = (args.get("device_id") or "").strip()
    if not dev:
        return _err("device_id is required")
    # Pull both lists and check membership.
    paired = _run_cli(["kdeconnect-cli", "--list-devices", "--id-only"])
    available = _run_cli(["kdeconnect-cli", "--list-available", "--id-only"])
    paired_ids = {ln.strip() for ln in (paired["stdout"] or "").splitlines() if ln.strip()}
    avail_ids = {ln.strip() for ln in (available["stdout"] or "").splitlines() if ln.strip()}
    return _ok({
        "device_id": dev,
        "paired": dev in paired_ids,
        "reachable": dev in avail_ids,
    })


# ──────────────────────────────────────────────────────────────────────────
# TWILIO TOOLS
# ──────────────────────────────────────────────────────────────────────────


def _twilio_creds() -> Dict[str, Optional[str]]:
    """Lazy-load Twilio creds from the environment."""
    return {
        "sid": os.environ.get("TWILIO_ACCOUNT_SID"),
        "token": os.environ.get("TWILIO_AUTH_TOKEN"),
        "from": os.environ.get("TWILIO_FROM_NUMBER"),
    }


def _twilio_require(need_from: bool = True) -> Optional[Dict[str, Any]]:
    """Return an error-dict if creds are missing, else None."""
    c = _twilio_creds()
    missing = []
    if not c["sid"]:
        missing.append("TWILIO_ACCOUNT_SID")
    if not c["token"]:
        missing.append("TWILIO_AUTH_TOKEN")
    if need_from and not c["from"]:
        missing.append("TWILIO_FROM_NUMBER")
    if missing:
        return _err(f"Twilio credentials missing in env: {', '.join(missing)}")
    return None


def _twilio_request(method: str, path: str, form: Optional[Dict[str, str]] = None,
                    query: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Tiny urllib-based Twilio REST client. `path` is appended to
    https://api.twilio.com/2010-04-01/Accounts/{SID}/. Returns the parsed
    JSON body, or {"ok": False, "error": ...} on failure."""
    c = _twilio_creds()
    sid, token = c["sid"], c["token"]
    if not sid or not token:
        return _err("Twilio creds not loaded")
    url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/{path.lstrip('/')}"
    if query:
        q = urllib.parse.urlencode({k: v for k, v in query.items() if v is not None})
        if q:
            url = f"{url}?{q}"
    body: Optional[bytes] = None
    headers = {
        "Authorization": "Basic " + base64.b64encode(f"{sid}:{token}".encode()).decode(),
        "Accept": "application/json",
    }
    if form is not None:
        body = urllib.parse.urlencode(form).encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=_HTTP_TIMEOUT) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            try:
                return {"ok": True, "status": resp.status, "json": json.loads(raw)}
            except json.JSONDecodeError:
                return {"ok": True, "status": resp.status, "raw": raw}
    except urllib.error.HTTPError as e:
        err_body = ""
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        return _err(f"Twilio HTTP {e.code}: {err_body or e.reason}")
    except urllib.error.URLError as e:
        return _err(f"Twilio URL error: {e.reason}")
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def twilio_send_sms(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send an SMS via Twilio. Args: to_number, message."""
    miss = _twilio_require()
    if miss:
        return miss
    to = (args.get("to_number") or "").strip()
    body = args.get("message") or ""
    if not to:
        return _err("to_number is required")
    if not body:
        return _err("message is required")
    c = _twilio_creds()
    res = _twilio_request("POST", "Messages.json", form={
        "To": to,
        "From": c["from"] or "",
        "Body": body,
    })
    if not res.get("ok"):
        return res
    return _ok(res.get("json") or res)


def twilio_send_mms(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send an MMS via Twilio. Args: to_number, message, media_url."""
    miss = _twilio_require()
    if miss:
        return miss
    to = (args.get("to_number") or "").strip()
    body = args.get("message") or ""
    media_url = (args.get("media_url") or "").strip()
    if not to:
        return _err("to_number is required")
    if not media_url:
        return _err("media_url is required")
    c = _twilio_creds()
    res = _twilio_request("POST", "Messages.json", form={
        "To": to,
        "From": c["from"] or "",
        "Body": body,
        "MediaUrl": media_url,
    })
    if not res.get("ok"):
        return res
    return _ok(res.get("json") or res)


def twilio_make_call(args: Dict[str, Any]) -> Dict[str, Any]:
    """Initiate a phone call via Twilio. Args: to_number, twiml_url_or_text.
    If `twiml_url_or_text` looks like a URL, it's passed as `Url`; otherwise
    it's wrapped in a <Say> TwiML document and sent inline via `Twiml`."""
    miss = _twilio_require()
    if miss:
        return miss
    to = (args.get("to_number") or "").strip()
    twiml = (args.get("twiml_url_or_text") or "").strip()
    if not to:
        return _err("to_number is required")
    if not twiml:
        return _err("twiml_url_or_text is required")
    c = _twilio_creds()
    form = {"To": to, "From": c["from"] or ""}
    if twiml.startswith(("http://", "https://")):
        form["Url"] = twiml
    else:
        # Inline TwiML — Twilio accepts a raw document via the `Twiml` param
        safe = twiml.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        form["Twiml"] = f"<Response><Say>{safe}</Say></Response>"
    res = _twilio_request("POST", "Calls.json", form=form)
    if not res.get("ok"):
        return res
    return _ok(res.get("json") or res)


def twilio_list_recent_sms(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent SMS messages. Args: limit (default 20)."""
    miss = _twilio_require(need_from=False)
    if miss:
        return miss
    limit = int(args.get("limit", 20)) if args else 20
    res = _twilio_request("GET", "Messages.json", query={"PageSize": min(max(limit, 1), 100)})
    if not res.get("ok"):
        return res
    body = res.get("json") or {}
    messages = body.get("messages", []) if isinstance(body, dict) else []
    return _ok({"count": len(messages), "messages": messages[:limit]})


def twilio_list_recent_calls(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent calls. Args: limit (default 20)."""
    miss = _twilio_require(need_from=False)
    if miss:
        return miss
    limit = int(args.get("limit", 20)) if args else 20
    res = _twilio_request("GET", "Calls.json", query={"PageSize": min(max(limit, 1), 100)})
    if not res.get("ok"):
        return res
    body = res.get("json") or {}
    calls = body.get("calls", []) if isinstance(body, dict) else []
    return _ok({"count": len(calls), "calls": calls[:limit]})


def twilio_account_balance(args: Dict[str, Any]) -> Dict[str, Any]:
    """Get the Twilio account balance."""
    miss = _twilio_require(need_from=False)
    if miss:
        return miss
    res = _twilio_request("GET", "Balance.json")
    if not res.get("ok"):
        return res
    return _ok(res.get("json") or res)


# ──────────────────────────────────────────────────────────────────────────
# MISC PHONE HELPERS
# ──────────────────────────────────────────────────────────────────────────


def dial_number(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open a tel:// URI via xdg-open — KDE Connect's phone-link picks
    it up and dials on the paired phone. Args: number."""
    number = (args.get("number") or "").strip()
    if not number:
        return _err("number is required")
    xdg = shutil.which("xdg-open")
    if xdg is None:
        return _err("xdg-open not installed (sudo apt install xdg-utils)")
    # Strip spaces / hyphens — tel: URIs should be terse
    cleaned = "".join(ch for ch in number if ch.isdigit() or ch in "+*#")
    if not cleaned:
        return _err(f"no dialable digits in {number!r}")
    r = _run_cli([xdg, f"tel:{cleaned}"], timeout=5.0)
    if not r["ok"]:
        return _err(f"xdg-open failed: {r['stderr'].strip() or r['stdout'].strip()}")
    return _ok({"dialed": cleaned})


def _load_contacts() -> List[Dict[str, Any]]:
    path = _contacts_path()
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return [c for c in data if isinstance(c, dict)]
        return []
    except (json.JSONDecodeError, OSError):
        return []


def _save_contacts(contacts: List[Dict[str, Any]]) -> None:
    path = _contacts_path()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(contacts, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def _scan_akonadi_contacts(query: str) -> List[Dict[str, Any]]:
    """Best-effort scan of KDE PIM (Akonadi) vCard files for a name
    substring match. Returns [] if Akonadi data isn't present."""
    base = os.path.expanduser("~/.local/share/akonadi")
    if not os.path.isdir(base):
        return []
    q = query.lower()
    hits: List[Dict[str, Any]] = []
    # vCards live under file-backed resources; we scan any *.vcf we find.
    patterns = [
        os.path.join(base, "**", "*.vcf"),
        os.path.expanduser("~/.local/share/contacts/**/*.vcf"),
    ]
    seen: set = set()
    for pat in patterns:
        for path in glob.glob(pat, recursive=True):
            if path in seen:
                continue
            seen.add(path)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    raw = f.read()
            except OSError:
                continue
            name = ""
            tel = ""
            email = ""
            for line in raw.splitlines():
                up = line.upper()
                if up.startswith("FN:") or up.startswith("FN;"):
                    name = line.split(":", 1)[-1].strip()
                elif up.startswith("TEL"):
                    tel = line.split(":", 1)[-1].strip()
                elif up.startswith("EMAIL"):
                    email = line.split(":", 1)[-1].strip()
            if name and q in name.lower():
                hits.append({"name": name, "number": tel, "email": email, "source": path})
    return hits


def contacts_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search contacts by name (case-insensitive substring). Checks
    Akonadi vCards first, then the JSON fallback. Args: name_query."""
    q = (args.get("name_query") or "").strip()
    if not q:
        return _err("name_query is required")
    results = _scan_akonadi_contacts(q)
    ql = q.lower()
    with _CONTACTS_LOCK:
        for c in _load_contacts():
            name = str(c.get("name", ""))
            if ql in name.lower():
                results.append({**c, "source": "contacts.json"})
    return _ok({"count": len(results), "contacts": results})


def contacts_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add or upsert a contact in brain_state/contacts.json.
    Args: name, number, email (optional), notes (optional)."""
    name = (args.get("name") or "").strip()
    number = (args.get("number") or "").strip()
    if not name:
        return _err("name is required")
    if not number:
        return _err("number is required")
    email = args.get("email")
    notes = args.get("notes")
    with _CONTACTS_LOCK:
        contacts = _load_contacts()
        # Upsert by case-insensitive name match
        existing = None
        for c in contacts:
            if str(c.get("name", "")).lower() == name.lower():
                existing = c
                break
        now = time.time()
        if existing:
            existing["number"] = number
            if email is not None:
                existing["email"] = email
            if notes is not None:
                existing["notes"] = notes
            existing["updated_ts"] = now
            saved = existing
        else:
            saved = {
                "name": name,
                "number": number,
                "email": email,
                "notes": notes,
                "created_ts": now,
                "updated_ts": now,
            }
            contacts.append(saved)
        try:
            _save_contacts(contacts)
        except OSError as e:
            return _err(f"writing contacts.json: {e}")
    return _ok(saved)


def contacts_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all contacts in brain_state/contacts.json."""
    with _CONTACTS_LOCK:
        contacts = _load_contacts()
    return _ok({"count": len(contacts), "contacts": contacts})


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # KDE Connect
    "phone.kde_list_devices": kde_list_devices,
    "phone.kde_send_sms": kde_send_sms,
    "phone.kde_ring": kde_ring,
    "phone.kde_battery": kde_battery,
    "phone.kde_share_url": kde_share_url,
    "phone.kde_share_text": kde_share_text,
    "phone.kde_send_file": kde_send_file,
    "phone.kde_notification": kde_notification,
    "phone.kde_read_notifications": kde_read_notifications,
    "phone.kde_pair_status": kde_pair_status,
    # Twilio
    "phone.twilio_send_sms": twilio_send_sms,
    "phone.twilio_send_mms": twilio_send_mms,
    "phone.twilio_make_call": twilio_make_call,
    "phone.twilio_list_recent_sms": twilio_list_recent_sms,
    "phone.twilio_list_recent_calls": twilio_list_recent_calls,
    "phone.twilio_account_balance": twilio_account_balance,
    # Misc
    "phone.dial_number": dial_number,
    "phone.contacts_search": contacts_search,
    "phone.contacts_add": contacts_add,
    "phone.contacts_list": contacts_list,
}
