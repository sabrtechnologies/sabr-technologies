"""AI provider wrappers for Leon — second-opinion, image gen, translation, TTS.

All tools return {"ok": bool, ...} and never raise. Credentials are read lazily
from environment variables; missing keys produce a clean error response.
"""

from __future__ import annotations

import base64
import os
from typing import Any, Callable, Dict, List, Optional

import requests


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

# 30s was too short for real work: auditing a whole install script through
# gemini or a local qwen reliably blew past it, so compare_models kept
# returning "one model answered, two timed out" — which reads as a
# comparison but is actually a single opinion. This is a ceiling, not a
# delay; fast calls still return fast.
_DEFAULT_TIMEOUT = int(os.environ.get("LEON_AI_TIMEOUT", "120"))
_IMAGE_TIMEOUT = 60


def _env(name: str) -> Optional[str]:
    """Return env var or None if missing/empty."""
    val = os.environ.get(name)
    return val.strip() if val and val.strip() else None


def _missing(var: str) -> Dict[str, Any]:
    """Standard missing-credential response."""
    return {"ok": False, "error": f"credentials missing — needs {var} env var"}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _save_bytes(data: bytes, path: str) -> Optional[str]:
    """Write bytes to path. Returns path on success, None on failure."""
    try:
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        with open(path, "wb") as f:
            f.write(data)
        return path
    except Exception:
        return None


def _post_json(url: str, headers: Dict[str, str], payload: Dict[str, Any],
               timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    """POST JSON, return {"ok": True, "data": ...} or error dict."""
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=timeout)
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        return {"ok": True, "data": r.json()}
    except requests.Timeout:
        return _err(f"timeout after {timeout}s")
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _get_json(url: str, headers: Optional[Dict[str, str]] = None,
              timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    try:
        r = requests.get(url, headers=headers or {}, timeout=timeout)
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        return {"ok": True, "data": r.json()}
    except requests.Timeout:
        return _err(f"timeout after {timeout}s")
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------

def openai_chat(args: dict) -> dict:
    """OpenAI Chat Completions. args: prompt, model, system, max_tokens."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return _missing("OPENAI_API_KEY")
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    messages: List[Dict[str, str]] = []
    system = args.get("system")
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    payload = {
        "model": args.get("model", "gpt-4o-mini"),
        "messages": messages,
        "max_tokens": args.get("max_tokens", 1024),
    }
    res = _post_json(
        "https://api.openai.com/v1/chat/completions",
        {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        payload,
    )
    if not res["ok"]:
        return res
    try:
        text = res["data"]["choices"][0]["message"]["content"]
        usage = res["data"].get("usage", {})
        return {"ok": True, "text": text, "model": payload["model"], "usage": usage}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


def openai_complete(args: dict) -> dict:
    """Convenience: same as openai_chat but minimal args."""
    return openai_chat({"prompt": args.get("prompt"), "model": args.get("model", "gpt-4o-mini")})


def openai_embed(args: dict) -> dict:
    """OpenAI embeddings. args: text, model."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return _missing("OPENAI_API_KEY")
    text = args.get("text")
    if not text:
        return _err("text required")
    payload = {"input": text, "model": args.get("model", "text-embedding-3-small")}
    res = _post_json(
        "https://api.openai.com/v1/embeddings",
        {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        payload,
    )
    if not res["ok"]:
        return res
    try:
        vec = res["data"]["data"][0]["embedding"]
        return {"ok": True, "embedding": vec, "dim": len(vec), "model": payload["model"]}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


def openai_image_generate(args: dict) -> dict:
    """DALL-E image generation. args: prompt, size, quality, model, save_to."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return _missing("OPENAI_API_KEY")
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    model = args.get("model") or _env("OPENAI_IMAGE_MODEL") or "gpt-image-1.5"
    payload = {
        "model": model,
        "prompt": prompt,
        "size": args.get("size", "1024x1024"),
        "n": 1,
    }
    quality = args.get("quality")
    if model.startswith("gpt-image"):
        # gpt-image-* only accepts low|medium|high|auto, and always returns b64.
        payload["quality"] = {"standard": "medium", "hd": "high"}.get(
            quality or "medium", quality or "medium")
    else:
        payload["quality"] = quality or "standard"
    res = _post_json(
        "https://api.openai.com/v1/images/generations",
        {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        payload,
        timeout=_IMAGE_TIMEOUT,
    )
    if not res["ok"]:
        return res
    try:
        item = res["data"]["data"][0]
    except Exception as e:
        return _err(f"unexpected response shape: {e}")
    url = item.get("url")
    b64 = item.get("b64_json")
    if not url and not b64:
        return _err("unexpected response shape: no url or b64_json")
    out: Dict[str, Any] = {"ok": True, "model": payload["model"]}
    if url:
        out["url"] = url
    save_to = args.get("save_to")
    if save_to:
        try:
            if b64:
                import base64
                content = base64.b64decode(b64)
            else:
                content = requests.get(url, timeout=_IMAGE_TIMEOUT).content
            saved = _save_bytes(content, save_to)
            if saved:
                out["saved_to"] = saved
            else:
                out["save_error"] = "failed to write file"
        except Exception as e:
            out["save_error"] = str(e)
    elif b64:
        out["b64_json"] = b64
    return out


def openai_image_variation(args: dict) -> dict:
    """DALL-E 2 image variation. args: image_path, n, size."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return _missing("OPENAI_API_KEY")
    path = args.get("image_path")
    if not path or not os.path.exists(path):
        return _err(f"image_path missing or not found: {path}")
    try:
        with open(path, "rb") as f:
            files = {"image": (os.path.basename(path), f, "image/png")}
            data = {"n": str(args.get("n", 1)), "size": args.get("size", "1024x1024")}
            r = requests.post(
                "https://api.openai.com/v1/images/variations",
                headers={"Authorization": f"Bearer {key}"},
                files=files, data=data, timeout=_IMAGE_TIMEOUT,
            )
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        urls = [d["url"] for d in r.json().get("data", [])]
        return {"ok": True, "urls": urls, "count": len(urls)}
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def openai_transcribe(args: dict) -> dict:
    """Whisper transcription. args: audio_path, model."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return _missing("OPENAI_API_KEY")
    path = args.get("audio_path")
    if not path or not os.path.exists(path):
        return _err(f"audio_path missing or not found: {path}")
    try:
        with open(path, "rb") as f:
            files = {"file": (os.path.basename(path), f, "application/octet-stream")}
            data = {"model": args.get("model", "whisper-1")}
            r = requests.post(
                "https://api.openai.com/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {key}"},
                files=files, data=data, timeout=_IMAGE_TIMEOUT,
            )
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        j = r.json()
        return {"ok": True, "text": j.get("text", ""), "raw": j}
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def openai_speech(args: dict) -> dict:
    """OpenAI TTS. args: text, voice, model, save_to."""
    key = _env("OPENAI_API_KEY")
    if not key:
        return _missing("OPENAI_API_KEY")
    text = args.get("text")
    if not text:
        return _err("text required")
    payload = {
        "model": args.get("model", "tts-1"),
        "input": text,
        "voice": args.get("voice", "alloy"),
    }
    try:
        r = requests.post(
            "https://api.openai.com/v1/audio/speech",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json=payload, timeout=_IMAGE_TIMEOUT,
        )
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        save_to = args.get("save_to")
        if save_to:
            saved = _save_bytes(r.content, save_to)
            if saved:
                return {"ok": True, "saved_to": saved, "bytes": len(r.content)}
            return _err("failed to write file")
        return {"ok": True, "bytes": len(r.content), "b64": base64.b64encode(r.content).decode()}
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ---------------------------------------------------------------------------
# Google Gemini
# ---------------------------------------------------------------------------

def gemini_chat(args: dict) -> dict:
    """Gemini chat. args: prompt, model, system."""
    key = _env("GEMINI_API_KEY") or _env("GOOGLE_API_KEY")
    if not key:
        return _missing("GEMINI_API_KEY")
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    model = args.get("model", "gemini-flash-latest")
    payload: Dict[str, Any] = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
    }
    system = args.get("system")
    if system:
        payload["systemInstruction"] = {"parts": [{"text": system}]}
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    res = _post_json(url, {"Content-Type": "application/json"}, payload)
    if not res["ok"]:
        return res
    try:
        text = res["data"]["candidates"][0]["content"]["parts"][0]["text"]
        return {"ok": True, "text": text, "model": model}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


def gemini_vision(args: dict) -> dict:
    """Gemini multimodal vision. args: image_path_or_url, prompt, model."""
    key = _env("GEMINI_API_KEY") or _env("GOOGLE_API_KEY")
    if not key:
        return _missing("GEMINI_API_KEY")
    img = args.get("image_path_or_url")
    prompt = args.get("prompt")
    if not img or not prompt:
        return _err("image_path_or_url and prompt required")
    # fetch image bytes
    try:
        if img.startswith("http://") or img.startswith("https://"):
            r = requests.get(img, timeout=_DEFAULT_TIMEOUT)
            if r.status_code >= 400:
                return _err(f"image fetch HTTP {r.status_code}")
            blob = r.content
            mime = r.headers.get("Content-Type", "image/jpeg").split(";")[0]
        else:
            if not os.path.exists(img):
                return _err(f"image not found: {img}")
            with open(img, "rb") as f:
                blob = f.read()
            ext = os.path.splitext(img)[1].lower().lstrip(".")
            mime = f"image/{ 'jpeg' if ext in ('jpg','jpeg') else (ext or 'png') }"
    except Exception as e:
        return _err(f"image load failed: {e}")
    model = args.get("model", "gemini-flash-latest")
    payload = {
        "contents": [{
            "role": "user",
            "parts": [
                {"text": prompt},
                {"inline_data": {"mime_type": mime, "data": base64.b64encode(blob).decode()}},
            ],
        }],
    }
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    res = _post_json(url, {"Content-Type": "application/json"}, payload, timeout=_IMAGE_TIMEOUT)
    if not res["ok"]:
        return res
    try:
        text = res["data"]["candidates"][0]["content"]["parts"][0]["text"]
        return {"ok": True, "text": text, "model": model}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


# ---------------------------------------------------------------------------
# Mistral
# ---------------------------------------------------------------------------

def mistral_chat(args: dict) -> dict:
    """Mistral chat. args: prompt, model, system."""
    key = _env("MISTRAL_API_KEY")
    if not key:
        return _missing("MISTRAL_API_KEY")
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    messages: List[Dict[str, str]] = []
    system = args.get("system")
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    payload = {"model": args.get("model", "mistral-small-latest"), "messages": messages}
    res = _post_json(
        "https://api.mistral.ai/v1/chat/completions",
        {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        payload,
    )
    if not res["ok"]:
        return res
    try:
        text = res["data"]["choices"][0]["message"]["content"]
        return {"ok": True, "text": text, "model": payload["model"]}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


# ---------------------------------------------------------------------------
# Together AI
# ---------------------------------------------------------------------------

def together_chat(args: dict) -> dict:
    """Together AI chat (OpenAI-compatible). args: prompt, model."""
    key = _env("TOGETHER_API_KEY")
    if not key:
        return _missing("TOGETHER_API_KEY")
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    payload = {
        "model": args.get("model", "meta-llama/Llama-3.3-70B-Instruct-Turbo"),
        "messages": [{"role": "user", "content": prompt}],
    }
    res = _post_json(
        "https://api.together.xyz/v1/chat/completions",
        {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        payload,
    )
    if not res["ok"]:
        return res
    try:
        text = res["data"]["choices"][0]["message"]["content"]
        return {"ok": True, "text": text, "model": payload["model"]}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


# ---------------------------------------------------------------------------
# Ollama (local — no creds)
# ---------------------------------------------------------------------------

_OLLAMA_BASE = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")


def ollama_chat(args: dict) -> dict:
    """Ollama local chat. args: prompt, model, system."""
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    messages: List[Dict[str, str]] = []
    system = args.get("system")
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    payload = {
        "model": args.get("model", "llama3.2:1b"),
        "messages": messages,
        "stream": False,
    }
    res = _post_json(f"{_OLLAMA_BASE}/api/chat", {"Content-Type": "application/json"}, payload)
    if not res["ok"]:
        return res
    try:
        text = res["data"]["message"]["content"]
        return {"ok": True, "text": text, "model": payload["model"]}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


def ollama_list_models(args: dict) -> dict:
    """List Ollama installed models."""
    res = _get_json(f"{_OLLAMA_BASE}/api/tags")
    if not res["ok"]:
        return res
    models = [m.get("name") for m in res["data"].get("models", [])]
    return {"ok": True, "models": models, "count": len(models)}


def ollama_pull(args: dict) -> dict:
    """Pull an Ollama model. args: model_name. Long-running (timeout 300s)."""
    name = args.get("model_name")
    if not name:
        return _err("model_name required")
    res = _post_json(
        f"{_OLLAMA_BASE}/api/pull",
        {"Content-Type": "application/json"},
        {"name": name, "stream": False},
        timeout=300,
    )
    if not res["ok"]:
        return res
    return {"ok": True, "model": name, "status": res["data"].get("status", "done")}


def ollama_embed(args: dict) -> dict:
    """Ollama embeddings. args: text, model."""
    text = args.get("text")
    if not text:
        return _err("text required")
    payload = {"model": args.get("model", "nomic-embed-text"), "input": text}
    res = _post_json(f"{_OLLAMA_BASE}/api/embed", {"Content-Type": "application/json"}, payload)
    if not res["ok"]:
        return res
    try:
        embs = res["data"].get("embeddings", [])
        vec = embs[0] if embs else res["data"].get("embedding", [])
        return {"ok": True, "embedding": vec, "dim": len(vec), "model": payload["model"]}
    except Exception as e:
        return _err(f"unexpected response shape: {e}")


# ---------------------------------------------------------------------------
# Stability AI
# ---------------------------------------------------------------------------

def stability_text_to_image(args: dict) -> dict:
    """Stability text-to-image. args: prompt, save_to, model."""
    key = _env("STABILITY_API_KEY")
    if not key:
        return _missing("STABILITY_API_KEY")
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    model = args.get("model", "stable-diffusion-3-medium")
    try:
        r = requests.post(
            "https://api.stability.ai/v2beta/stable-image/generate/sd3",
            headers={"Authorization": f"Bearer {key}", "Accept": "image/*"},
            files={"none": ""},
            data={"prompt": prompt, "model": model, "output_format": "png"},
            timeout=_IMAGE_TIMEOUT,
        )
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        save_to = args.get("save_to")
        if save_to:
            saved = _save_bytes(r.content, save_to)
            if saved:
                return {"ok": True, "saved_to": saved, "bytes": len(r.content), "model": model}
            return _err("failed to write file")
        return {"ok": True, "bytes": len(r.content), "model": model,
                "b64": base64.b64encode(r.content).decode()}
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ---------------------------------------------------------------------------
# Translation
# ---------------------------------------------------------------------------

def deepl_translate(args: dict) -> dict:
    """DeepL translate. args: text, target_lang, source_lang."""
    key = _env("DEEPL_API_KEY")
    if not key:
        return _missing("DEEPL_API_KEY")
    text = args.get("text")
    target = args.get("target_lang")
    if not text or not target:
        return _err("text and target_lang required")
    # free vs pro endpoint: free keys end in ":fx"
    base = "https://api-free.deepl.com" if key.endswith(":fx") else "https://api.deepl.com"
    data = {"text": text, "target_lang": target.upper()}
    src = args.get("source_lang")
    if src:
        data["source_lang"] = src.upper()
    try:
        r = requests.post(
            f"{base}/v2/translate",
            headers={"Authorization": f"DeepL-Auth-Key {key}"},
            data=data, timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        j = r.json()
        translations = j.get("translations", [])
        if not translations:
            return _err("no translations returned")
        return {
            "ok": True,
            "text": translations[0]["text"],
            "detected_source": translations[0].get("detected_source_language"),
            "target_lang": target.upper(),
        }
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def libretranslate(args: dict) -> dict:
    """LibreTranslate (self-host). args: text, target_lang, source_lang."""
    text = args.get("text")
    target = args.get("target_lang")
    if not text or not target:
        return _err("text and target_lang required")
    base = os.environ.get("LIBRETRANSLATE_URL", "http://localhost:5000").rstrip("/")
    payload = {
        "q": text,
        "source": args.get("source_lang", "auto"),
        "target": target,
        "format": "text",
    }
    api_key = _env("LIBRETRANSLATE_API_KEY")
    if api_key:
        payload["api_key"] = api_key
    res = _post_json(f"{base}/translate", {"Content-Type": "application/json"}, payload)
    if not res["ok"]:
        return res
    return {
        "ok": True,
        "text": res["data"].get("translatedText", ""),
        "detected_source": (res["data"].get("detectedLanguage") or {}).get("language"),
        "target_lang": target,
    }


# ---------------------------------------------------------------------------
# ElevenLabs
# ---------------------------------------------------------------------------

def elevenlabs_tts(args: dict) -> dict:
    """ElevenLabs TTS. args: text, voice_id, save_to."""
    key = _env("ELEVENLABS_API_KEY")
    if not key:
        return _missing("ELEVENLABS_API_KEY")
    text = args.get("text")
    if not text:
        return _err("text required")
    voice_id = args.get("voice_id") or os.environ.get("ELEVENLABS_VOICE_ID", "21m00Tcm4TlvDq8ikWAM")
    try:
        r = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={"xi-api-key": key, "Content-Type": "application/json",
                     "Accept": "audio/mpeg"},
            json={"text": text, "model_id": "eleven_multilingual_v2"},
            timeout=_IMAGE_TIMEOUT,
        )
        if r.status_code >= 400:
            return _err(f"HTTP {r.status_code}: {r.text[:300]}")
        save_to = args.get("save_to")
        if save_to:
            saved = _save_bytes(r.content, save_to)
            if saved:
                return {"ok": True, "saved_to": saved, "bytes": len(r.content), "voice_id": voice_id}
            return _err("failed to write file")
        return {"ok": True, "bytes": len(r.content), "voice_id": voice_id,
                "b64": base64.b64encode(r.content).decode()}
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def elevenlabs_list_voices(args: dict) -> dict:
    """List available ElevenLabs voices."""
    key = _env("ELEVENLABS_API_KEY")
    if not key:
        return _missing("ELEVENLABS_API_KEY")
    res = _get_json("https://api.elevenlabs.io/v1/voices", {"xi-api-key": key})
    if not res["ok"]:
        return res
    voices = [{"voice_id": v.get("voice_id"), "name": v.get("name"),
               "category": v.get("category")} for v in res["data"].get("voices", [])]
    return {"ok": True, "voices": voices, "count": len(voices)}


# ---------------------------------------------------------------------------
# Misc — multi-provider helpers
# ---------------------------------------------------------------------------

def _dispatch_compare(spec: str, prompt: str) -> Dict[str, Any]:
    """Run a single 'provider/model' spec for compare_models. Returns dict."""
    try:
        provider, model = spec.split("/", 1)
    except ValueError:
        return {"ok": False, "error": f"bad spec '{spec}', expected provider/model"}
    provider = provider.lower()
    if provider == "openai":
        return openai_chat({"prompt": prompt, "model": model})
    if provider == "gemini":
        return gemini_chat({"prompt": prompt, "model": model})
    if provider == "mistral":
        return mistral_chat({"prompt": prompt, "model": model})
    if provider == "together":
        return together_chat({"prompt": prompt, "model": model})
    if provider == "ollama":
        return ollama_chat({"prompt": prompt, "model": model})
    if provider == "claude":
        # Claude is handled via the main CLI elsewhere; signal skip cleanly.
        return {"ok": False, "error": "claude provider not callable here — use Leon's main CLI bridge"}
    return {"ok": False, "error": f"unknown provider '{provider}'"}


def compare_models(args: dict) -> dict:
    """Call multiple models side-by-side. args: prompt, models (list of 'provider/model')."""
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    # Default to whatever is ACTUALLY reachable right now, cheapest first.
    # The old hardcoded default listed gemini (key may be absent) and
    # claude/haiku (not callable from here at all), so the common case was a
    # "comparison" of one working model and two canned error strings.
    models = args.get("models") or args.get("providers")
    if models and all("/" not in str(m) for m in models):
        # Caller passed bare provider names — expand to that provider's default.
        _defaults = dict(_CHEAP_ORDER)
        models = [f"{m}/{_defaults[m]}" for m in models if m in _defaults]
    if not models:
        models = [f"{p}/{m}" for p, m in _CHEAP_ORDER if _provider_available(p)]
    if not models:
        return _err("no AI provider available — set an API key or run Ollama locally")
    results: Dict[str, Any] = {}
    for spec in models:
        r = _dispatch_compare(spec, prompt)
        if r.get("ok"):
            results[spec] = {"ok": True, "text": r.get("text", "")}
        else:
            results[spec] = {"ok": False, "error": r.get("error", "unknown")}
    return {"ok": True, "prompt": prompt, "results": results,
            "succeeded": [s for s, v in results.items() if v["ok"]]}


# rough $/1M-token "cheap-ness" rank — lower is cheaper. Local first.
_CHEAP_ORDER = [
    # Local model name comes from the same env var local_llm.py uses, so the two
    # can never drift apart again. Hardcoding llama3.2:1b here meant cheapest_chat
    # kept picking a model that was never pulled on this box.
    ("ollama", os.environ.get("LEON_LOCAL_MODEL", "qwen2.5:3b-instruct-q4_K_M")),
    ("gemini", "gemini-flash-latest"),     # very cheap
    ("openai", "gpt-4o-mini"),          # cheap
    ("mistral", "mistral-small-latest"),
    ("together", "meta-llama/Llama-3.3-70B-Instruct-Turbo"),
]


def _provider_available(provider: str) -> bool:
    """Quick availability check (cred or local reachability)."""
    if provider == "ollama":
        # Not enough that the daemon answers — the model must actually be pulled,
        # otherwise every call 404s and we silently fall through to a PAID
        # provider while believing the free one was tried.
        try:
            r = requests.get(f"{_OLLAMA_BASE}/api/tags", timeout=2)
            if r.status_code >= 400:
                return False
            want = dict(_CHEAP_ORDER)["ollama"]
            names = {m.get("name", "") for m in (r.json().get("models") or [])}
            return want in names or any(n.split(":")[0] == want.split(":")[0] for n in names)
        except Exception:
            return False
    return bool({
        "openai": _env("OPENAI_API_KEY"),
        "gemini": _env("GEMINI_API_KEY") or _env("GOOGLE_API_KEY"),
        "mistral": _env("MISTRAL_API_KEY"),
        "together": _env("TOGETHER_API_KEY"),
    }.get(provider))


def cheapest_chat(args: dict) -> dict:
    """Pick cheapest available provider and answer. args: prompt."""
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    for provider, model in _CHEAP_ORDER:
        if not _provider_available(provider):
            continue
        r = _dispatch_compare(f"{provider}/{model}", prompt)
        if r.get("ok"):
            return {"ok": True, "text": r["text"], "provider": provider, "model": model}
    return _err("no AI provider available — set an API key or run Ollama locally")


# ---------------------------------------------------------------------------
# EXTRA_TOOLS export
# ---------------------------------------------------------------------------

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # OpenAI
    "ai.openai_chat": openai_chat,
    "ai.openai_complete": openai_complete,
    "ai.openai_embed": openai_embed,
    "ai.openai_image_generate": openai_image_generate,
    "ai.openai_image_variation": openai_image_variation,
    "ai.openai_transcribe": openai_transcribe,
    "ai.openai_speech": openai_speech,
    # Gemini
    "ai.gemini_chat": gemini_chat,
    "ai.gemini_vision": gemini_vision,
    # Mistral
    "ai.mistral_chat": mistral_chat,
    # Together
    "ai.together_chat": together_chat,
    # Ollama
    "ai.ollama_chat": ollama_chat,
    "ai.ollama_list_models": ollama_list_models,
    "ai.ollama_pull": ollama_pull,
    "ai.ollama_embed": ollama_embed,
    # Stability
    "ai.stability_text_to_image": stability_text_to_image,
    # Translation
    "ai.deepl_translate": deepl_translate,
    "ai.libretranslate": libretranslate,
    # ElevenLabs
    "ai.elevenlabs_tts": elevenlabs_tts,
    "ai.elevenlabs_list_voices": elevenlabs_list_voices,
    # Misc
    "ai.compare_models": compare_models,
    "ai.cheapest_chat": cheapest_chat,
}

# Short, provider-agnostic aliases. These are the names the tool router
# promotes to the live surface (see brain/tool_router.py AI_PROVIDER_TOOLS).
# They point at the same callables as the entries above, so both the long
# provider-qualified name and the short name resolve. Keys are dotted here;
# server/init_brain.py converts "ai.x" -> "ai_x" when registering local_tools.
EXTRA_TOOLS.update({
    "ai.image_generate": openai_image_generate,     # DALL-E 3 via OpenAI
    "ai.transcribe": openai_transcribe,             # Whisper
    "ai.speak": openai_speech,                      # OpenAI TTS
    "ai.stability_image": stability_text_to_image,  # Stability SD3
    "ai.translate": deepl_translate,                # DeepL
})
