"""Image + audio AI operations for Leon.

All tools return ``{"ok": bool, ...}`` and never raise. Heavy deps (rembg,
Real-ESRGAN, opencv, tesseract, pyzbar, faster-whisper, openai, stability,
elevenlabs, sox) are imported lazily inside each tool so that importing this
module is cheap and works in stripped-down environments.

Outputs land in ``~/Documents/leon-images/`` (auto-created on import). Reads
are path-restricted: only files under the user's HOME or ``/tmp`` are allowed
to be opened.
"""

from __future__ import annotations

import base64
import datetime as _dt
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Paths / constants
# ---------------------------------------------------------------------------

HOME = Path.home()
OUTPUT_DIR = HOME / "Documents" / "leon-images"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

_ALLOWED_READ_ROOTS = [HOME, Path("/tmp")]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _err(msg: str, **extra: Any) -> Dict[str, Any]:
    out = {"ok": False, "error": msg}
    out.update(extra)
    return out


def _ok(**fields: Any) -> Dict[str, Any]:
    out = {"ok": True}
    out.update(fields)
    return out


def _resolve_read(path: str) -> Path:
    """Resolve a user-supplied path and ensure it lives under an allowed root."""
    p = Path(path).expanduser().resolve()
    for root in _ALLOWED_READ_ROOTS:
        try:
            p.relative_to(root.resolve())
            return p
        except ValueError:
            continue
    raise PermissionError(f"path outside allowed roots: {p}")


def _resolve_input(path: str) -> Path:
    p = _resolve_read(path)
    if not p.exists():
        raise FileNotFoundError(f"input not found: {p}")
    return p


def _out_path(output_path: Optional[str], base_name: str, ext: str) -> Path:
    if output_path:
        p = Path(output_path).expanduser()
        if not p.is_absolute():
            p = OUTPUT_DIR / p
    else:
        ts = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        p = OUTPUT_DIR / f"{base_name}-{ts}{ext}"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


def _try_import(name: str):
    try:
        mod = __import__(name)
        for part in name.split(".")[1:]:
            mod = getattr(mod, part)
        return mod
    except Exception:
        return None


def _get_moondream():
    """Best-effort fetch of an already-loaded Moondream2 model from Leon."""
    # Try common locations used elsewhere in the codebase.
    for path in (
        "brain.integrations.moondream",
        "brain.vision.moondream",
        "brain.moondream",
    ):
        mod = _try_import(path)
        if mod is None:
            continue
        for attr in ("MODEL", "model", "get_model", "MOONDREAM", "moondream"):
            obj = getattr(mod, attr, None)
            if obj is None:
                continue
            if callable(obj):
                try:
                    obj = obj()
                except Exception:
                    continue
            return obj
    return None


# ---------------------------------------------------------------------------
# Background / segmentation
# ---------------------------------------------------------------------------

def remove_background(input_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    rembg = _try_import("rembg")
    if rembg is None:
        return _err("rembg not installed (pip install rembg)")
    try:
        with open(inp, "rb") as f:
            data = f.read()
        out_bytes = rembg.remove(data)
        out = _out_path(output_path, f"{inp.stem}-nobg", ".png")
        with open(out, "wb") as f:
            f.write(out_bytes)
        return _ok(output_path=str(out), bytes=len(out_bytes))
    except Exception as e:
        return _err(f"rembg failed: {e}")


def replace_background(input_path: str, new_bg_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
        bg = _resolve_input(new_bg_path)
    except Exception as e:
        return _err(str(e))
    rembg = _try_import("rembg")
    PIL = _try_import("PIL.Image")
    if rembg is None or PIL is None:
        return _err("requires rembg and Pillow")
    try:
        from PIL import Image
        with open(inp, "rb") as f:
            data = f.read()
        cut_bytes = rembg.remove(data)
        import io
        fg = Image.open(io.BytesIO(cut_bytes)).convert("RGBA")
        bg_img = Image.open(bg).convert("RGBA").resize(fg.size)
        bg_img.paste(fg, (0, 0), fg)
        out = _out_path(output_path, f"{inp.stem}-replaced", ".png")
        bg_img.convert("RGB").save(out)
        return _ok(output_path=str(out))
    except Exception as e:
        return _err(f"replace_background failed: {e}")


def crop_to_subject(input_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    md = _get_moondream()
    if md is None:
        return _err("Moondream2 not available")
    try:
        from PIL import Image
        img = Image.open(inp).convert("RGB")
        # Try detect API
        boxes = []
        if hasattr(md, "detect"):
            try:
                res = md.detect(img, "subject")
                boxes = res.get("objects", res) if isinstance(res, dict) else res
            except Exception:
                boxes = []
        if not boxes:
            return _err("no subject detected")
        b = boxes[0]
        if isinstance(b, dict):
            x1, y1, x2, y2 = b.get("x_min", b.get("x1", 0)), b.get("y_min", b.get("y1", 0)), \
                              b.get("x_max", b.get("x2", 1)), b.get("y_max", b.get("y2", 1))
        else:
            x1, y1, x2, y2 = b[:4]
        W, H = img.size
        # Moondream typically returns normalized coords in [0,1]
        if max(x1, y1, x2, y2) <= 1.5:
            x1, x2 = int(x1 * W), int(x2 * W)
            y1, y2 = int(y1 * H), int(y2 * H)
        cropped = img.crop((int(x1), int(y1), int(x2), int(y2)))
        out = _out_path(output_path, f"{inp.stem}-crop", ".png")
        cropped.save(out)
        return _ok(output_path=str(out), bbox=[int(x1), int(y1), int(x2), int(y2)])
    except Exception as e:
        return _err(f"crop_to_subject failed: {e}")


# ---------------------------------------------------------------------------
# Upscaling / enhancement
# ---------------------------------------------------------------------------

def upscale(input_path: str, scale: int = 2, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    scale = max(1, min(int(scale), 8))
    out = _out_path(output_path, f"{inp.stem}-up{scale}x", inp.suffix or ".png")

    # 1. Try realesrgan-ncnn-vulkan CLI binary
    bin_path = _which("realesrgan-ncnn-vulkan") or _which("upscayl-bin")
    if bin_path:
        try:
            res = subprocess.run(
                [bin_path, "-i", str(inp), "-o", str(out), "-s", str(scale)],
                capture_output=True, text=True, timeout=300,
            )
            if res.returncode == 0 and out.exists():
                return _ok(output_path=str(out), method="realesrgan-cli", scale=scale)
        except Exception:
            pass

    # 2. Try python realesrgan
    realesrgan = _try_import("realesrgan")
    if realesrgan is not None:
        try:
            from PIL import Image
            import numpy as np
            from realesrgan import RealESRGANer
            img = np.array(Image.open(inp).convert("RGB"))
            upsampler = RealESRGANer(scale=scale, model_path=None, model=None)
            out_arr, _ = upsampler.enhance(img, outscale=scale)
            Image.fromarray(out_arr).save(out)
            return _ok(output_path=str(out), method="realesrgan-py", scale=scale)
        except Exception:
            pass

    # 3. Fallback: Pillow LANCZOS resize
    PIL = _try_import("PIL.Image")
    if PIL is None:
        return _err("no upscaler available (install realesrgan or Pillow)")
    try:
        from PIL import Image
        img = Image.open(inp)
        new_size = (img.width * scale, img.height * scale)
        resized = img.resize(new_size, Image.LANCZOS)
        resized.save(out)
        return _ok(output_path=str(out), method="pillow-lanczos", scale=scale,
                    note="real-esrgan not installed; used Lanczos fallback")
    except Exception as e:
        return _err(f"upscale failed: {e}")


def denoise(input_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    out = _out_path(output_path, f"{inp.stem}-denoise", inp.suffix or ".png")
    cv2 = _try_import("cv2")
    if cv2 is not None:
        try:
            img = cv2.imread(str(inp))
            if img is None:
                return _err("cv2 could not read image")
            cleaned = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)
            cv2.imwrite(str(out), cleaned)
            return _ok(output_path=str(out), method="cv2-nlmeans")
        except Exception:
            pass
    PIL = _try_import("PIL.Image")
    if PIL is None:
        return _err("requires opencv or Pillow")
    try:
        from PIL import Image, ImageFilter
        img = Image.open(inp)
        cleaned = img.filter(ImageFilter.MedianFilter(size=3))
        cleaned.save(out)
        return _ok(output_path=str(out), method="pillow-median")
    except Exception as e:
        return _err(f"denoise failed: {e}")


def enhance_lighting(input_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    PIL = _try_import("PIL.Image")
    if PIL is None:
        return _err("Pillow not installed")
    try:
        from PIL import Image, ImageEnhance, ImageOps
        img = Image.open(inp).convert("RGB")
        img = ImageOps.autocontrast(img, cutoff=2)
        img = ImageEnhance.Brightness(img).enhance(1.08)
        img = ImageEnhance.Contrast(img).enhance(1.1)
        img = ImageEnhance.Color(img).enhance(1.05)
        out = _out_path(output_path, f"{inp.stem}-lit", inp.suffix or ".png")
        img.save(out)
        return _ok(output_path=str(out))
    except Exception as e:
        return _err(f"enhance_lighting failed: {e}")


# ---------------------------------------------------------------------------
# Face / object detection
# ---------------------------------------------------------------------------

def _haar_cascade():
    cv2 = _try_import("cv2")
    if cv2 is None:
        return None, None
    try:
        path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        if not os.path.exists(path):
            return None, None
        return cv2, cv2.CascadeClassifier(path)
    except Exception:
        return None, None


def detect_faces(input_path: str) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    # Prefer face_recognition (dlib HOG) — more accurate.
    fr = _try_import("face_recognition")
    if fr is not None:
        try:
            img = fr.load_image_file(str(inp))
            locs = fr.face_locations(img)
            # face_recognition returns (top, right, bottom, left)
            boxes = [{"x": l, "y": t, "w": r - l, "h": b - t} for (t, r, b, l) in locs]
            return _ok(faces=boxes, count=len(boxes), method="face_recognition")
        except Exception:
            pass
    cv2, cascade = _haar_cascade()
    if cv2 is None or cascade is None:
        return _err("requires opencv-python or face_recognition")
    try:
        img = cv2.imread(str(inp))
        if img is None:
            return _err("cv2 could not read image")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        rects = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        boxes = [{"x": int(x), "y": int(y), "w": int(w), "h": int(h)} for (x, y, w, h) in rects]
        return _ok(faces=boxes, count=len(boxes), method="haarcascade")
    except Exception as e:
        return _err(f"detect_faces failed: {e}")


def blur_faces(input_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    cv2 = _try_import("cv2")
    if cv2 is None:
        return _err("opencv-python required for blur_faces")
    try:
        det = detect_faces(input_path)
        if not det.get("ok"):
            return det
        img = cv2.imread(str(inp))
        for f in det["faces"]:
            x, y, w, h = f["x"], f["y"], f["w"], f["h"]
            roi = img[y:y + h, x:x + w]
            if roi.size == 0:
                continue
            ksize = max(15, (w // 4) | 1)
            blurred = cv2.GaussianBlur(roi, (ksize, ksize), 0)
            img[y:y + h, x:x + w] = blurred
        out = _out_path(output_path, f"{inp.stem}-blurfaces", inp.suffix or ".png")
        cv2.imwrite(str(out), img)
        return _ok(output_path=str(out), faces_blurred=det["count"])
    except Exception as e:
        return _err(f"blur_faces failed: {e}")


def count_objects(input_path: str, target: str) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    md = _get_moondream()
    if md is None:
        return _err("Moondream2 not available")
    try:
        from PIL import Image
        img = Image.open(inp).convert("RGB")
        if hasattr(md, "count"):
            try:
                res = md.count(img, target)
                count = res.get("count") if isinstance(res, dict) else res
                return _ok(count=int(count), target=target, method="moondream.count")
            except Exception:
                pass
        # Fallback: query
        if hasattr(md, "query"):
            ans = md.query(img, f"How many {target} are in this image? Reply with just a number.")
            text = ans.get("answer", ans) if isinstance(ans, dict) else str(ans)
            digits = "".join(c for c in str(text) if c.isdigit())
            count = int(digits) if digits else 0
            return _ok(count=count, target=target, raw_answer=str(text), method="moondream.query")
        return _err("Moondream2 has no count/query method")
    except Exception as e:
        return _err(f"count_objects failed: {e}")


def find_object_bbox(input_path: str, target: str) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    md = _get_moondream()
    if md is None:
        return _err("Moondream2 not available")
    try:
        from PIL import Image
        img = Image.open(inp).convert("RGB")
        if not hasattr(md, "detect"):
            return _err("Moondream2 has no detect method")
        res = md.detect(img, target)
        boxes = res.get("objects", res) if isinstance(res, dict) else res
        W, H = img.size
        norm = []
        for b in boxes or []:
            if isinstance(b, dict):
                x1 = b.get("x_min", b.get("x1"))
                y1 = b.get("y_min", b.get("y1"))
                x2 = b.get("x_max", b.get("x2"))
                y2 = b.get("y_max", b.get("y2"))
            else:
                x1, y1, x2, y2 = b[:4]
            if max(x1, y1, x2, y2) <= 1.5:
                x1, x2 = x1 * W, x2 * W
                y1, y2 = y1 * H, y2 * H
            norm.append({"x1": int(x1), "y1": int(y1), "x2": int(x2), "y2": int(y2)})
        return _ok(target=target, bboxes=norm, count=len(norm))
    except Exception as e:
        return _err(f"find_object_bbox failed: {e}")


# ---------------------------------------------------------------------------
# OCR / extraction
# ---------------------------------------------------------------------------

def ocr_full(input_path: str, lang: str = "eng") -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    pyt = _try_import("pytesseract")
    if pyt is None or _which("tesseract") is None:
        return _err("tesseract + pytesseract not installed")
    try:
        from PIL import Image
        text = pyt.image_to_string(Image.open(inp), lang=lang)
        return _ok(text=text.strip(), chars=len(text), lang=lang)
    except Exception as e:
        return _err(f"ocr_full failed: {e}")


def ocr_bboxes(input_path: str, lang: str = "eng") -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    pyt = _try_import("pytesseract")
    if pyt is None or _which("tesseract") is None:
        return _err("tesseract + pytesseract not installed")
    try:
        from PIL import Image
        data = pyt.image_to_data(Image.open(inp), lang=lang, output_type=pyt.Output.DICT)
        words = []
        n = len(data.get("text", []))
        for i in range(n):
            txt = data["text"][i]
            if not txt or not txt.strip():
                continue
            words.append({
                "text": txt,
                "x": int(data["left"][i]),
                "y": int(data["top"][i]),
                "w": int(data["width"][i]),
                "h": int(data["height"][i]),
                "conf": float(data["conf"][i]) if str(data["conf"][i]).replace("-", "").isdigit() else 0.0,
            })
        return _ok(words=words, count=len(words), lang=lang)
    except Exception as e:
        return _err(f"ocr_bboxes failed: {e}")


def qr_decode(input_path: str) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    pyzbar = _try_import("pyzbar.pyzbar")
    if pyzbar is None:
        return _err("pyzbar not installed (pip install pyzbar)")
    try:
        from PIL import Image
        results = pyzbar.decode(Image.open(inp))
        codes = []
        for r in results:
            codes.append({
                "data": r.data.decode("utf-8", errors="replace"),
                "type": r.type,
                "rect": {"x": r.rect.left, "y": r.rect.top, "w": r.rect.width, "h": r.rect.height},
            })
        return _ok(codes=codes, count=len(codes))
    except Exception as e:
        return _err(f"qr_decode failed: {e}")


def qr_generate(text: str, output_path: str) -> Dict[str, Any]:
    qrcode = _try_import("qrcode")
    if qrcode is None:
        return _err("qrcode library not installed (pip install qrcode[pil])")
    try:
        out = _out_path(output_path, "qr", ".png")
        img = qrcode.make(text)
        img.save(out)
        return _ok(output_path=str(out), text=text)
    except Exception as e:
        return _err(f"qr_generate failed: {e}")


# ---------------------------------------------------------------------------
# Generation / transformation
# ---------------------------------------------------------------------------

def generate_via_openai(prompt: str, size: str = "1024x1024", save_to: Optional[str] = None) -> Dict[str, Any]:
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return _err("OPENAI_API_KEY not set")
    openai = _try_import("openai")
    if openai is None:
        return _err("openai package not installed")
    try:
        client = openai.OpenAI(api_key=key)
        model = os.environ.get("OPENAI_IMAGE_MODEL") or "gpt-image-1.5"
        kwargs = {"model": model, "prompt": prompt, "size": size, "n": 1}
        if not model.startswith("gpt-image"):
            # gpt-image-* always returns b64 and rejects response_format
            kwargs["response_format"] = "b64_json"
        res = client.images.generate(**kwargs)
        b64 = res.data[0].b64_json
        out = _out_path(save_to, "openai", ".png")
        with open(out, "wb") as f:
            f.write(base64.b64decode(b64))
        return _ok(output_path=str(out), prompt=prompt, size=size, provider="openai")
    except Exception as e:
        return _err(f"openai generate failed: {e}")


def generate_via_stability(prompt: str, save_to: Optional[str] = None) -> Dict[str, Any]:
    key = os.environ.get("STABILITY_API_KEY")
    if not key:
        return _err("STABILITY_API_KEY not set")
    requests = _try_import("requests")
    if requests is None:
        return _err("requests not installed")
    try:
        url = "https://api.stability.ai/v2beta/stable-image/generate/core"
        headers = {"Authorization": f"Bearer {key}", "Accept": "image/*"}
        files = {"none": ""}
        data = {"prompt": prompt, "output_format": "png"}
        r = requests.post(url, headers=headers, files=files, data=data, timeout=120)
        if r.status_code != 200:
            return _err(f"stability HTTP {r.status_code}: {r.text[:200]}")
        out = _out_path(save_to, "stability", ".png")
        with open(out, "wb") as f:
            f.write(r.content)
        return _ok(output_path=str(out), prompt=prompt, provider="stability")
    except Exception as e:
        return _err(f"stability generate failed: {e}")


def style_transfer(input_path: str, style_name: str) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    key = os.environ.get("STABILITY_API_KEY")
    if not key:
        return _err("STABILITY_API_KEY not set")
    requests = _try_import("requests")
    if requests is None:
        return _err("requests not installed")
    try:
        url = "https://api.stability.ai/v2beta/stable-image/control/style"
        headers = {"Authorization": f"Bearer {key}", "Accept": "image/*"}
        with open(inp, "rb") as f:
            files = {"image": f}
            data = {"prompt": style_name, "output_format": "png"}
            r = requests.post(url, headers=headers, files=files, data=data, timeout=180)
        if r.status_code != 200:
            return _err(f"stability stylize HTTP {r.status_code}: {r.text[:200]}")
        out = _out_path(None, f"{inp.stem}-styled-{style_name.replace(' ', '_')}", ".png")
        with open(out, "wb") as f:
            f.write(r.content)
        return _ok(output_path=str(out), style=style_name)
    except Exception as e:
        return _err(f"style_transfer failed: {e}")


def colorize_grayscale(input_path: str, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return _err("OPENAI_API_KEY not set (no offline colorizer available)")
    openai = _try_import("openai")
    if openai is None:
        return _err("openai package not installed")
    try:
        client = openai.OpenAI(api_key=key)
        with open(inp, "rb") as f:
            res = client.images.edit(
                model="gpt-image-1",
                image=f,
                prompt="Colorize this grayscale photograph realistically and naturally.",
                size="1024x1024",
            )
        b64 = res.data[0].b64_json
        out = _out_path(output_path, f"{inp.stem}-color", ".png")
        with open(out, "wb") as f:
            f.write(base64.b64decode(b64))
        return _ok(output_path=str(out))
    except Exception as e:
        return _err(f"colorize_grayscale failed: {e}")


# ---------------------------------------------------------------------------
# Audio AI
# ---------------------------------------------------------------------------

def clone_via_elevenlabs(text: str, voice_id: str, save_to: Optional[str] = None) -> Dict[str, Any]:
    key = os.environ.get("ELEVENLABS_API_KEY")
    if not key:
        return _err("ELEVENLABS_API_KEY not set")
    requests = _try_import("requests")
    if requests is None:
        return _err("requests not installed")
    try:
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
        headers = {
            "xi-api-key": key,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
        }
        payload = {"text": text, "model_id": "eleven_multilingual_v2"}
        r = requests.post(url, json=payload, headers=headers, timeout=120)
        if r.status_code != 200:
            return _err(f"elevenlabs HTTP {r.status_code}: {r.text[:200]}")
        out = _out_path(save_to, f"clone-{voice_id[:8]}", ".mp3")
        with open(out, "wb") as f:
            f.write(r.content)
        return _ok(output_path=str(out), voice_id=voice_id, bytes=len(r.content))
    except Exception as e:
        return _err(f"clone_via_elevenlabs failed: {e}")


def list_elevenlabs_voices() -> Dict[str, Any]:
    key = os.environ.get("ELEVENLABS_API_KEY")
    if not key:
        return _err("ELEVENLABS_API_KEY not set")
    requests = _try_import("requests")
    if requests is None:
        return _err("requests not installed")
    try:
        r = requests.get("https://api.elevenlabs.io/v1/voices",
                          headers={"xi-api-key": key}, timeout=30)
        if r.status_code != 200:
            return _err(f"elevenlabs HTTP {r.status_code}")
        data = r.json()
        voices = []
        for v in data.get("voices", []):
            voices.append({
                "voice_id": v.get("voice_id"),
                "name": v.get("name"),
                "category": v.get("category"),
                "description": v.get("description"),
            })
        return _ok(voices=voices, count=len(voices))
    except Exception as e:
        return _err(f"list_elevenlabs_voices failed: {e}")


def voice_change_pitch(input_audio: str, semitones: int = 4, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_audio)
    except Exception as e:
        return _err(str(e))
    sox = _which("sox")
    if sox is None:
        return _err("sox not installed (apt install sox)")
    try:
        out = _out_path(output_path, f"{inp.stem}-pitch{int(semitones):+d}", inp.suffix or ".wav")
        # sox pitch takes cents — 100 cents per semitone
        cents = int(semitones) * 100
        res = subprocess.run([sox, str(inp), str(out), "pitch", str(cents)],
                              capture_output=True, text=True, timeout=120)
        if res.returncode != 0:
            return _err(f"sox failed: {res.stderr[:200]}")
        return _ok(output_path=str(out), semitones=int(semitones))
    except Exception as e:
        return _err(f"voice_change_pitch failed: {e}")


def voice_to_text_local(input_audio: str) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_audio)
    except Exception as e:
        return _err(str(e))
    fw = _try_import("faster_whisper")
    if fw is None:
        return _err("faster-whisper not installed (pip install faster-whisper)")
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel("base", device="cpu", compute_type="int8")
        segments, info = model.transcribe(str(inp))
        text_parts: List[str] = []
        seg_list = []
        for s in segments:
            text_parts.append(s.text)
            seg_list.append({"start": s.start, "end": s.end, "text": s.text})
        return _ok(text="".join(text_parts).strip(),
                    segments=seg_list,
                    language=info.language,
                    language_probability=info.language_probability)
    except Exception as e:
        return _err(f"voice_to_text_local failed: {e}")


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def list_recent_outputs(limit: int = 20) -> Dict[str, Any]:
    try:
        files = []
        for p in OUTPUT_DIR.iterdir():
            if not p.is_file():
                continue
            st = p.stat()
            files.append({
                "path": str(p),
                "name": p.name,
                "size": st.st_size,
                "mtime": st.st_mtime,
                "mtime_iso": _dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
            })
        files.sort(key=lambda f: f["mtime"], reverse=True)
        return _ok(files=files[:max(1, int(limit))], total=len(files), dir=str(OUTPUT_DIR))
    except Exception as e:
        return _err(f"list_recent_outputs failed: {e}")


def compare_two(image_a_path: str, image_b_path: str) -> Dict[str, Any]:
    try:
        a = _resolve_input(image_a_path)
        b = _resolve_input(image_b_path)
    except Exception as e:
        return _err(str(e))
    md = _get_moondream()
    if md is None:
        return _err("Moondream2 not available")
    try:
        from PIL import Image
        img_a = Image.open(a).convert("RGB")
        img_b = Image.open(b).convert("RGB")
        # Try multi-image first
        if hasattr(md, "query"):
            try:
                ans = md.query([img_a, img_b], "How are these two images different?")
                text = ans.get("answer", ans) if isinstance(ans, dict) else str(ans)
                return _ok(comparison=str(text), method="multi-image-query")
            except Exception:
                pass
            # Fallback: describe each
            def _desc(im):
                r = md.query(im, "Describe this image in one sentence.")
                return r.get("answer", r) if isinstance(r, dict) else str(r)
            da, db = _desc(img_a), _desc(img_b)
            return _ok(image_a=str(da), image_b=str(db), method="separate-descriptions",
                        note="Moondream did not accept multi-image input")
        return _err("Moondream2 has no query method")
    except Exception as e:
        return _err(f"compare_two failed: {e}")


def thumbnail(input_path: str, max_dim: int = 400, output_path: Optional[str] = None) -> Dict[str, Any]:
    try:
        inp = _resolve_input(input_path)
    except Exception as e:
        return _err(str(e))
    PIL = _try_import("PIL.Image")
    if PIL is None:
        return _err("Pillow not installed")
    try:
        from PIL import Image
        img = Image.open(inp)
        img.thumbnail((int(max_dim), int(max_dim)), Image.LANCZOS)
        out = _out_path(output_path, f"{inp.stem}-thumb", inp.suffix or ".png")
        img.save(out)
        return _ok(output_path=str(out), size=list(img.size), max_dim=int(max_dim))
    except Exception as e:
        return _err(f"thumbnail failed: {e}")


# ---------------------------------------------------------------------------
# EXTRA_TOOLS
# ---------------------------------------------------------------------------

EXTRA_TOOLS: Dict[str, Any] = {
    # Background / segmentation
    "image.remove_background": remove_background,
    "image.replace_background": replace_background,
    "image.crop_to_subject": crop_to_subject,
    # Upscaling / enhancement
    "image.upscale": upscale,
    "image.denoise": denoise,
    "image.enhance_lighting": enhance_lighting,
    # Face / object detection
    "image.detect_faces": detect_faces,
    "image.blur_faces": blur_faces,
    "image.count_objects": count_objects,
    "image.find_object_bbox": find_object_bbox,
    # OCR / extraction
    "image.ocr_full": ocr_full,
    "image.ocr_bboxes": ocr_bboxes,
    "image.qr_decode": qr_decode,
    "image.qr_generate": qr_generate,
    # Generation / transformation
    "image.generate_via_openai": generate_via_openai,
    "image.generate_via_stability": generate_via_stability,
    "image.style_transfer": style_transfer,
    "image.colorize_grayscale": colorize_grayscale,
    # Audio AI
    "audio.clone_via_elevenlabs": clone_via_elevenlabs,
    "audio.list_elevenlabs_voices": list_elevenlabs_voices,
    "audio.voice_change_pitch": voice_change_pitch,
    "audio.voice_to_text_local": voice_to_text_local,
    # Convenience
    "image.list_recent_outputs": list_recent_outputs,
    "image.compare_two": compare_two,
    "image.thumbnail": thumbnail,
}


# ── Adapter ─────────────────────────────────────────────────────────────
# brain.integrations tools are dispatched as `fn(args_dict) -> dict`. Some
# tools in this module were authored with kwarg signatures
# (`def tool(name, value)`) instead of `def tool(args: dict)`. This wrapper
# makes both styles work: it calls the dict form first, and on a signature
# mismatch retries with kwargs. Every tool returns a dict and never raises.
def _adapt(fn):
    _fname = getattr(fn, "__name__", "tool")

    def _wrapped(args=None):
        a = args if isinstance(args, dict) else {}
        try:
            r = fn(a)
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except TypeError as e:
            if f"{_fname}()" not in str(e):
                return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        try:
            r = fn(**a)
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except TypeError as e:
            return {"ok": False, "error": f"bad args for {_fname}: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    _wrapped.__name__ = _fname
    _wrapped.__doc__ = getattr(fn, "__doc__", None)
    return _wrapped


EXTRA_TOOLS = {k: _adapt(v) for k, v in EXTRA_TOOLS.items()}
