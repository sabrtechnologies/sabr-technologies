"""
media.py — Local photo / screenshot / video / PDF / document tooling for Leon.

Tools constrained to user dirs: ~/Desktop, ~/Pictures, ~/Downloads, ~/Documents.
Image content search uses brain.local_vision.LocalVision (Moondream2) if available.
Each tool returns {"ok": bool, ...}. EXTRA_TOOLS dict at bottom.
"""

from __future__ import annotations

import base64
import csv
import io
import json
import os
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# -------- Pillow (assumed installed) ----------------------------------------
try:
    from PIL import Image, ExifTags  # type: ignore
    _PIL_OK = True
except Exception as _e:  # pragma: no cover
    _PIL_OK = False
    _PIL_ERR = str(_e)


# -------- Constants & helpers -----------------------------------------------

_HOME = Path.home()
_ALLOWED_ROOTS = [
    _HOME / "Desktop",
    _HOME / "Pictures",
    _HOME / "Downloads",
    _HOME / "Documents",
]

_IMG_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".bmp", ".tiff", ".tif", ".gif"}
_VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".wmv", ".flv"}
_PDF_EXTS = {".pdf"}

_SCREENSHOT_DIRS = [
    _HOME / "Desktop",
    _HOME / "Pictures" / "Screenshots",
    _HOME / "Pictures" / "screenshots",
    _HOME / "Pictures",
]


def _ok(**kw) -> dict:
    out = {"ok": True}
    out.update(kw)
    return out


def _err(msg: str, **kw) -> dict:
    out = {"ok": False, "error": str(msg)}
    out.update(kw)
    return out


def _expand(p: str | Path) -> Path:
    return Path(os.path.expanduser(str(p))).resolve()


def _is_allowed(p: Path) -> bool:
    """True if p is inside one of the allowed user dirs."""
    try:
        rp = p.resolve()
    except Exception:
        return False
    for root in _ALLOWED_ROOTS:
        try:
            rp.relative_to(root.resolve())
            return True
        except ValueError:
            continue
    return False


def _check_path(p: str | Path, must_exist: bool = True) -> Tuple[Optional[Path], Optional[dict]]:
    """Return (resolved_path, None) or (None, err_dict)."""
    if not p:
        return None, _err("path required")
    rp = _expand(p)
    if not _is_allowed(rp):
        return None, _err(
            f"path outside allowed roots ({rp}). Allowed: ~/Desktop, ~/Pictures, ~/Downloads, ~/Documents"
        )
    if must_exist and not rp.exists():
        return None, _err(f"path does not exist: {rp}")
    return rp, None


def _default_dir(d: Optional[str]) -> Path:
    if d:
        return _expand(d)
    return _HOME / "Pictures"


def _which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


def _file_modified(p: Path) -> float:
    try:
        return p.stat().st_mtime
    except Exception:
        return 0.0


def _scan_dir(root: Path, exts: set, recursive: bool = True) -> List[Path]:
    out: List[Path] = []
    if not root.exists() or not root.is_dir():
        return out
    if recursive:
        for dirpath, dirnames, filenames in os.walk(root):
            # Skip dot dirs
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            for fn in filenames:
                if Path(fn).suffix.lower() in exts:
                    out.append(Path(dirpath) / fn)
    else:
        for child in root.iterdir():
            if child.is_file() and child.suffix.lower() in exts:
                out.append(child)
    return out


def _img_to_b64(img, fmt: str = "JPEG", quality: int = 75) -> str:
    buf = io.BytesIO()
    if fmt.upper() == "JPEG" and img.mode != "RGB":
        img = img.convert("RGB")
    img.save(buf, format=fmt, quality=quality)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _thumb_b64(path: Path, size: int = 200) -> Optional[str]:
    if not _PIL_OK:
        return None
    try:
        with Image.open(path) as im:
            im.thumbnail((size, size))
            return _img_to_b64(im, "JPEG", 70)
    except Exception:
        return None


def _exif(path: Path) -> Dict[str, Any]:
    if not _PIL_OK:
        return {}
    data: Dict[str, Any] = {}
    try:
        with Image.open(path) as im:
            data["width"], data["height"] = im.size
            data["mode"] = im.mode
            raw = getattr(im, "_getexif", lambda: None)()
            if not raw:
                return data
            tagmap = {ExifTags.TAGS.get(k, k): v for k, v in raw.items()}
            for key in ("Make", "Model", "DateTime", "DateTimeOriginal", "Orientation",
                        "LensModel", "FNumber", "ExposureTime", "ISOSpeedRatings",
                        "FocalLength", "Software"):
                if key in tagmap:
                    val = tagmap[key]
                    try:
                        json.dumps(val)
                        data[key] = val
                    except Exception:
                        data[key] = str(val)
            # GPS
            gps_raw = tagmap.get("GPSInfo")
            if gps_raw:
                gps_named = {ExifTags.GPSTAGS.get(k, k): v for k, v in gps_raw.items()}
                lat = _gps_dms_to_deg(gps_named.get("GPSLatitude"), gps_named.get("GPSLatitudeRef"))
                lon = _gps_dms_to_deg(gps_named.get("GPSLongitude"), gps_named.get("GPSLongitudeRef"))
                if lat is not None and lon is not None:
                    data["gps_lat"] = lat
                    data["gps_lon"] = lon
    except Exception as e:
        data["_exif_error"] = str(e)
    return data


def _gps_dms_to_deg(dms, ref) -> Optional[float]:
    if not dms or not ref:
        return None
    try:
        def _f(x):
            try:
                return float(x[0]) / float(x[1])
            except Exception:
                return float(x)
        d = _f(dms[0]); m = _f(dms[1]); s = _f(dms[2])
        deg = d + m / 60.0 + s / 3600.0
        if ref in ("S", "W"):
            deg = -deg
        return deg
    except Exception:
        return None


def _exif_datetime(exif: Dict[str, Any]) -> Optional[datetime]:
    for k in ("DateTimeOriginal", "DateTime"):
        v = exif.get(k)
        if not v:
            continue
        try:
            return datetime.strptime(str(v), "%Y:%m:%d %H:%M:%S")
        except Exception:
            try:
                return datetime.fromisoformat(str(v))
            except Exception:
                continue
    return None


def _haversine_km(lat1, lon1, lat2, lon2) -> float:
    import math
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


# -------- Moondream wrapper (graceful) ---------------------------------------

_VISION = None
_VISION_TRIED = False


def _vision():
    """Lazy-load LocalVision. Returns instance or None."""
    global _VISION, _VISION_TRIED
    if _VISION_TRIED:
        return _VISION
    _VISION_TRIED = True
    try:
        from brain.local_vision import LocalVision  # type: ignore
        _VISION = LocalVision()
    except Exception:
        _VISION = None
    return _VISION


def _moondream_caption(path: Path) -> Optional[str]:
    v = _vision()
    if v is None:
        return None
    try:
        if hasattr(v, "caption"):
            return v.caption(str(path))
        if hasattr(v, "describe"):
            return v.describe(str(path))
    except Exception:
        return None
    return None


def _moondream_query(path: Path, prompt: str) -> Optional[str]:
    v = _vision()
    if v is None:
        return None
    for method in ("query", "ask", "answer", "describe", "caption"):
        if hasattr(v, method):
            try:
                fn = getattr(v, method)
                # Try (path, prompt), fall back to (path)
                try:
                    return fn(str(path), prompt)
                except TypeError:
                    return fn(str(path))
            except Exception:
                continue
    return None


# -------- Photo library tools -----------------------------------------------

def _t_list_photos(args: dict) -> dict:
    if not _PIL_OK:
        return _err(f"Pillow not available: {_PIL_ERR}")
    d = args.get("dir")
    limit = int(args.get("limit", 50) or 50)
    sort = args.get("sort", "modified_desc")
    include_thumb = bool(args.get("thumbnails", True))
    root = _default_dir(d)
    rp, e = _check_path(root, must_exist=True)
    if e:
        return e
    files = _scan_dir(rp, _IMG_EXTS, recursive=True)
    if sort == "modified_desc":
        files.sort(key=_file_modified, reverse=True)
    elif sort == "modified_asc":
        files.sort(key=_file_modified)
    elif sort == "name":
        files.sort(key=lambda p: p.name.lower())
    files = files[:limit]
    out = []
    for p in files:
        item = {
            "path": str(p),
            "name": p.name,
            "size": p.stat().st_size,
            "modified": _file_modified(p),
        }
        if include_thumb:
            item["thumbnail_b64"] = _thumb_b64(p, 160)
        out.append(item)
    return _ok(dir=str(rp), count=len(out), photos=out)


def _t_photo_info(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    exif = _exif(rp)
    return _ok(
        path=str(rp),
        size=rp.stat().st_size,
        modified=_file_modified(rp),
        exif=exif,
    )


def _t_photo_caption(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    cap = _moondream_caption(rp)
    if cap is None:
        return _err("Moondream2 (brain.local_vision.LocalVision) not available", path=str(rp))
    return _ok(path=str(rp), caption=cap)


def _t_photo_describe(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    detail = args.get("detail", "brief")
    prompt = "Describe this image in detail." if detail == "detailed" else "Describe this image in one or two sentences."
    desc = _moondream_query(rp, prompt)
    if desc is None:
        return _err("Moondream2 not available", path=str(rp))
    return _ok(path=str(rp), description=desc, detail=detail)


def _fuzzy_score(query: str, text: str) -> float:
    q = query.lower().strip()
    t = (text or "").lower()
    if not q or not t:
        return 0.0
    # Simple: token overlap + substring boost
    q_tokens = set(w for w in q.replace(",", " ").split() if len(w) > 1)
    t_tokens = set(w for w in t.replace(",", " ").split() if len(w) > 1)
    if not q_tokens:
        return 1.0 if q in t else 0.0
    overlap = len(q_tokens & t_tokens) / len(q_tokens)
    sub = 1.0 if q in t else 0.0
    return min(1.0, 0.6 * overlap + 0.4 * sub)


def _t_photo_find_by_content(args: dict) -> dict:
    query = args.get("query") or ""
    if not query:
        return _err("query required")
    if _vision() is None:
        return _err("Moondream2 not available — cannot search by content")
    d = args.get("dir")
    max_results = int(args.get("max_results", 10) or 10)
    scan_cap = int(args.get("scan_limit", 50) or 50)  # safety
    root = _default_dir(d)
    rp, e = _check_path(root)
    if e:
        return e
    files = _scan_dir(rp, _IMG_EXTS, recursive=True)
    files.sort(key=_file_modified, reverse=True)
    files = files[:scan_cap]
    scored: List[Tuple[float, str, str]] = []
    for p in files:
        cap = _moondream_caption(p) or ""
        score = _fuzzy_score(query, cap)
        if score > 0:
            scored.append((score, str(p), cap))
    scored.sort(key=lambda x: x[0], reverse=True)
    matches = [{"path": p, "caption": c, "score": round(s, 3)} for s, p, c in scored[:max_results]]
    return _ok(query=query, scanned=len(files), matches=matches)


def _t_photos_by_date(args: dict) -> dict:
    if not _PIL_OK:
        return _err("Pillow not available")
    try:
        start = datetime.fromisoformat(args.get("start_iso"))
        end = datetime.fromisoformat(args.get("end_iso"))
    except Exception as ex:
        return _err(f"start_iso/end_iso must be ISO format: {ex}")
    root = _default_dir(args.get("dir"))
    rp, e = _check_path(root)
    if e:
        return e
    files = _scan_dir(rp, _IMG_EXTS, recursive=True)
    out = []
    for p in files:
        exif = _exif(p)
        dt = _exif_datetime(exif) or datetime.fromtimestamp(_file_modified(p))
        if start <= dt <= end:
            out.append({"path": str(p), "datetime": dt.isoformat(), "from_exif": _exif_datetime(exif) is not None})
    out.sort(key=lambda x: x["datetime"], reverse=True)
    return _ok(start=start.isoformat(), end=end.isoformat(), count=len(out), photos=out[:200])


def _t_photos_by_location(args: dict) -> dict:
    if not _PIL_OK:
        return _err("Pillow not available")
    try:
        lat = float(args.get("lat"))
        lon = float(args.get("lon"))
    except Exception:
        return _err("lat and lon required (numeric)")
    radius_km = float(args.get("radius_km", 5))
    root = _default_dir(args.get("dir"))
    rp, e = _check_path(root)
    if e:
        return e
    files = _scan_dir(rp, _IMG_EXTS, recursive=True)
    matches = []
    for p in files:
        exif = _exif(p)
        plat, plon = exif.get("gps_lat"), exif.get("gps_lon")
        if plat is None or plon is None:
            continue
        dist = _haversine_km(lat, lon, plat, plon)
        if dist <= radius_km:
            matches.append({"path": str(p), "lat": plat, "lon": plon, "distance_km": round(dist, 3)})
    matches.sort(key=lambda x: x["distance_km"])
    return _ok(center={"lat": lat, "lon": lon}, radius_km=radius_km, count=len(matches), photos=matches)


def _t_screenshot_gallery(args: dict) -> dict:
    if not _PIL_OK:
        return _err("Pillow not available")
    limit = int(args.get("limit", 30) or 30)
    found: List[Path] = []
    for d in _SCREENSHOT_DIRS:
        if not d.exists():
            continue
        for p in d.iterdir() if d.is_dir() else []:
            if not p.is_file():
                continue
            if p.suffix.lower() not in _IMG_EXTS:
                continue
            name = p.name.lower()
            # Common screenshot patterns
            if (
                "screenshot" in name
                or "screen shot" in name
                or name.startswith("scrot")
                or name.startswith("spectacle")
                or d.name.lower() in ("screenshots",)
            ):
                found.append(p)
    # Dedup
    seen = set()
    unique = []
    for p in found:
        rp = str(p.resolve())
        if rp in seen:
            continue
        seen.add(rp)
        unique.append(p)
    unique.sort(key=_file_modified, reverse=True)
    unique = unique[:limit]
    out = [
        {
            "path": str(p),
            "name": p.name,
            "modified": _file_modified(p),
            "size": p.stat().st_size,
            "thumbnail_b64": _thumb_b64(p, 160),
        }
        for p in unique
    ]
    return _ok(count=len(out), screenshots=out)


# -------- Photo manipulation ------------------------------------------------

def _resolve_save_as(src: Path, save_as: Optional[str], suffix: str) -> Tuple[Optional[Path], Optional[dict]]:
    if save_as:
        sp = _expand(save_as)
        if not _is_allowed(sp):
            return None, _err(f"save_as outside allowed roots: {sp}")
        sp.parent.mkdir(parents=True, exist_ok=True)
        return sp, None
    out = src.with_name(f"{src.stem}_{suffix}{src.suffix}")
    return out, None


def _t_photo_resize(args: dict) -> dict:
    if not _PIL_OK:
        return _err("Pillow not available")
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    max_dim = int(args.get("max_dim", 1920) or 1920)
    sp, e2 = _resolve_save_as(rp, args.get("save_as"), f"r{max_dim}")
    if e2:
        return e2
    try:
        with Image.open(rp) as im:
            im.thumbnail((max_dim, max_dim))
            im.save(sp)
            w, h = im.size
        return _ok(saved=str(sp), width=w, height=h)
    except Exception as ex:
        return _err(f"resize failed: {ex}")


def _t_photo_thumbnail(args: dict) -> dict:
    if not _PIL_OK:
        return _err("Pillow not available")
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    size = int(args.get("size", 200) or 200)
    b64 = _thumb_b64(rp, size)
    if b64 is None:
        return _err("thumbnail failed")
    return _ok(path=str(rp), size=size, thumbnail_b64=b64, mime="image/jpeg")


def _t_photo_rotate(args: dict) -> dict:
    if not _PIL_OK:
        return _err("Pillow not available")
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    deg = float(args.get("degrees", 90) or 90)
    sp, e2 = _resolve_save_as(rp, args.get("save_as"), f"rot{int(deg)}")
    if e2:
        return e2
    try:
        with Image.open(rp) as im:
            rotated = im.rotate(-deg, expand=True)  # PIL: positive=CCW; user expects CW positive
            rotated.save(sp)
        return _ok(saved=str(sp), degrees=deg)
    except Exception as ex:
        return _err(f"rotate failed: {ex}")


def _t_photo_crop(args: dict) -> dict:
    if not _PIL_OK:
        return _err("Pillow not available")
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    try:
        x = int(args["x"]); y = int(args["y"])
        w = int(args["w"]); h = int(args["h"])
    except Exception:
        return _err("x, y, w, h required (int)")
    sp, e2 = _resolve_save_as(rp, args.get("save_as"), f"crop")
    if e2:
        return e2
    try:
        with Image.open(rp) as im:
            box = (x, y, x + w, y + h)
            cropped = im.crop(box)
            cropped.save(sp)
        return _ok(saved=str(sp), box={"x": x, "y": y, "w": w, "h": h})
    except Exception as ex:
        return _err(f"crop failed: {ex}")


def _t_photo_to_base64(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    try:
        with open(rp, "rb") as f:
            data = f.read()
        mime = "image/jpeg" if rp.suffix.lower() in (".jpg", ".jpeg") else f"image/{rp.suffix.lstrip('.').lower()}"
        return _ok(path=str(rp), mime=mime, base64=base64.b64encode(data).decode("ascii"), bytes=len(data))
    except Exception as ex:
        return _err(f"read failed: {ex}")


# -------- PDF tools ---------------------------------------------------------

def _t_pdf_list(args: dict) -> dict:
    limit = int(args.get("limit", 30) or 30)
    root = _expand(args.get("dir") or (_HOME / "Documents"))
    rp, e = _check_path(root)
    if e:
        return e
    files = _scan_dir(rp, _PDF_EXTS, recursive=True)
    files.sort(key=_file_modified, reverse=True)
    files = files[:limit]
    out = [{"path": str(p), "name": p.name, "size": p.stat().st_size, "modified": _file_modified(p)} for p in files]
    return _ok(dir=str(rp), count=len(out), pdfs=out)


def _pdftotext_extract(path: Path, page: Optional[int]) -> Optional[str]:
    if not _which("pdftotext"):
        return None
    try:
        cmd = ["pdftotext", "-layout"]
        if page is not None:
            cmd += ["-f", str(page), "-l", str(page)]
        cmd += [str(path), "-"]
        r = subprocess.run(cmd, capture_output=True, timeout=60)
        if r.returncode == 0:
            return r.stdout.decode("utf-8", errors="replace")
    except Exception:
        return None
    return None


def _pypdf2_extract(path: Path, page: Optional[int]) -> Optional[str]:
    try:
        try:
            from pypdf import PdfReader  # type: ignore
        except Exception:
            from PyPDF2 import PdfReader  # type: ignore
    except Exception:
        return None
    try:
        reader = PdfReader(str(path))
        if page is not None:
            idx = page - 1
            if 0 <= idx < len(reader.pages):
                return reader.pages[idx].extract_text() or ""
            return ""
        return "\n\n".join((p.extract_text() or "") for p in reader.pages)
    except Exception:
        return None


def _t_pdf_text(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    page = args.get("page")
    if page is not None:
        try:
            page = int(page)
        except Exception:
            return _err("page must be int")
    text = _pdftotext_extract(rp, page)
    method = "pdftotext"
    if text is None:
        text = _pypdf2_extract(rp, page)
        method = "pypdf"
    if text is None:
        return _err("No PDF text extractor available (install poppler-utils or pypdf)")
    return _ok(path=str(rp), page=page, method=method, length=len(text), text=text)


def _t_pdf_summary(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    text = _pdftotext_extract(rp, None) or _pypdf2_extract(rp, None)
    if not text:
        return _err("Could not extract text from PDF")
    text = text.strip()
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if api_key:
        try:
            import anthropic  # type: ignore
            client = anthropic.Anthropic(api_key=api_key)
            snippet = text[:12000]
            msg = client.messages.create(
                model="claude-haiku-4-5",
                max_tokens=300,
                messages=[{
                    "role": "user",
                    "content": f"Summarize this document in 3 sentences:\n\n{snippet}",
                }],
            )
            summary = "".join(getattr(b, "text", "") for b in msg.content).strip()
            return _ok(path=str(rp), method="anthropic", summary=summary, text_length=len(text))
        except Exception as ex:
            return _ok(path=str(rp), method="fallback", summary=text[:500],
                       text_length=len(text), note=f"anthropic failed: {ex}")
    return _ok(path=str(rp), method="fallback", summary=text[:500], text_length=len(text))


def _t_pdf_page_image(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    page = int(args.get("page", 1) or 1)
    dpi = int(args.get("dpi", 150) or 150)
    if not _which("pdftoppm"):
        return _err("pdftoppm not installed (install poppler-utils)")
    try:
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            prefix = os.path.join(td, "page")
            r = subprocess.run(
                ["pdftoppm", "-r", str(dpi), "-f", str(page), "-l", str(page), "-png", str(rp), prefix],
                capture_output=True, timeout=120,
            )
            if r.returncode != 0:
                return _err(f"pdftoppm failed: {r.stderr.decode('utf-8', errors='replace')}")
            # File could be page-1.png or page-01.png
            for fn in os.listdir(td):
                if fn.endswith(".png"):
                    with open(os.path.join(td, fn), "rb") as f:
                        b64 = base64.b64encode(f.read()).decode("ascii")
                    return _ok(path=str(rp), page=page, dpi=dpi, mime="image/png", base64=b64)
            return _err("pdftoppm produced no output")
    except Exception as ex:
        return _err(f"pdf_page_image failed: {ex}")


def _t_pdf_metadata(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    # Try pypdf first for metadata
    try:
        try:
            from pypdf import PdfReader  # type: ignore
        except Exception:
            from PyPDF2 import PdfReader  # type: ignore
        reader = PdfReader(str(rp))
        info = reader.metadata or {}
        meta = {
            "title": str(info.get("/Title", "")) or None,
            "author": str(info.get("/Author", "")) or None,
            "subject": str(info.get("/Subject", "")) or None,
            "creator": str(info.get("/Creator", "")) or None,
            "producer": str(info.get("/Producer", "")) or None,
            "pages": len(reader.pages),
        }
        return _ok(path=str(rp), metadata=meta)
    except Exception:
        pass
    # Fallback: pdfinfo
    if _which("pdfinfo"):
        try:
            r = subprocess.run(["pdfinfo", str(rp)], capture_output=True, timeout=30)
            if r.returncode == 0:
                meta = {}
                for line in r.stdout.decode("utf-8", errors="replace").splitlines():
                    if ":" in line:
                        k, v = line.split(":", 1)
                        meta[k.strip()] = v.strip()
                return _ok(path=str(rp), metadata=meta, method="pdfinfo")
        except Exception:
            pass
    return _err("No PDF metadata reader available (install pypdf or poppler-utils)")


def _t_pdf_ocr_page(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    page = int(args.get("page", 1) or 1)
    dpi = int(args.get("dpi", 200) or 200)
    if not _which("pdftoppm"):
        return _err("pdftoppm not installed (install poppler-utils)")
    if not _which("tesseract"):
        return _err("tesseract not installed")
    try:
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            prefix = os.path.join(td, "page")
            r = subprocess.run(
                ["pdftoppm", "-r", str(dpi), "-f", str(page), "-l", str(page), "-png", str(rp), prefix],
                capture_output=True, timeout=120,
            )
            if r.returncode != 0:
                return _err(f"pdftoppm failed: {r.stderr.decode('utf-8', errors='replace')}")
            png_path = None
            for fn in os.listdir(td):
                if fn.endswith(".png"):
                    png_path = os.path.join(td, fn)
                    break
            if not png_path:
                return _err("pdftoppm produced no image")
            r2 = subprocess.run(["tesseract", png_path, "-", "-l", "eng"], capture_output=True, timeout=120)
            if r2.returncode != 0:
                return _err(f"tesseract failed: {r2.stderr.decode('utf-8', errors='replace')}")
            text = r2.stdout.decode("utf-8", errors="replace")
            return _ok(path=str(rp), page=page, dpi=dpi, length=len(text), text=text)
    except Exception as ex:
        return _err(f"pdf_ocr_page failed: {ex}")


# -------- Video tools -------------------------------------------------------

def _t_video_list(args: dict) -> dict:
    limit = int(args.get("limit", 20) or 20)
    root = _expand(args.get("dir") or (_HOME / "Videos" if (_HOME / "Videos").exists() else _HOME / "Desktop"))
    # Allow ~/Videos as a courtesy if user has it — but only if inside allowed roots.
    # We keep strict policy: only allowed roots permitted.
    rp, e = _check_path(root)
    if e:
        # Fall back to Desktop scan if user's default isn't allowed
        rp, e = _check_path(_HOME / "Desktop")
        if e:
            return e
    files = _scan_dir(rp, _VIDEO_EXTS, recursive=True)
    files.sort(key=_file_modified, reverse=True)
    files = files[:limit]
    out = [{"path": str(p), "name": p.name, "size": p.stat().st_size, "modified": _file_modified(p)} for p in files]
    return _ok(dir=str(rp), count=len(out), videos=out)


def _t_video_info(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    if not _which("ffprobe"):
        return _err("ffprobe not installed")
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-print_format", "json",
             "-show_format", "-show_streams", str(rp)],
            capture_output=True, timeout=30,
        )
        if r.returncode != 0:
            return _err(f"ffprobe failed: {r.stderr.decode('utf-8', errors='replace')}")
        data = json.loads(r.stdout.decode("utf-8", errors="replace"))
        fmt = data.get("format", {})
        streams = data.get("streams", [])
        vstream = next((s for s in streams if s.get("codec_type") == "video"), {})
        astream = next((s for s in streams if s.get("codec_type") == "audio"), {})
        info = {
            "duration_sec": float(fmt.get("duration", 0)) if fmt.get("duration") else None,
            "size": int(fmt.get("size", 0)) if fmt.get("size") else None,
            "bitrate": int(fmt.get("bit_rate", 0)) if fmt.get("bit_rate") else None,
            "format_name": fmt.get("format_name"),
            "video_codec": vstream.get("codec_name"),
            "width": vstream.get("width"),
            "height": vstream.get("height"),
            "fps": vstream.get("r_frame_rate"),
            "audio_codec": astream.get("codec_name"),
            "audio_channels": astream.get("channels"),
        }
        return _ok(path=str(rp), info=info)
    except Exception as ex:
        return _err(f"video_info failed: {ex}")


def _t_video_thumbnail(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    t = float(args.get("time_sec", 2) or 2)
    if not _which("ffmpeg"):
        return _err("ffmpeg not installed")
    try:
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
            outp = tmp.name
        r = subprocess.run(
            ["ffmpeg", "-y", "-ss", str(t), "-i", str(rp), "-frames:v", "1", "-q:v", "3", outp],
            capture_output=True, timeout=60,
        )
        if r.returncode != 0:
            try: os.unlink(outp)
            except Exception: pass
            return _err(f"ffmpeg failed: {r.stderr.decode('utf-8', errors='replace')[-500:]}")
        with open(outp, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        try: os.unlink(outp)
        except Exception: pass
        return _ok(path=str(rp), time_sec=t, mime="image/jpeg", base64=b64)
    except Exception as ex:
        return _err(f"video_thumbnail failed: {ex}")


def _t_video_extract_audio(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    if not _which("ffmpeg"):
        return _err("ffmpeg not installed")
    save_as = args.get("save_as")
    if save_as:
        sp = _expand(save_as)
        if not _is_allowed(sp):
            return _err(f"save_as outside allowed roots: {sp}")
    else:
        sp = rp.with_suffix(".mp3")
    sp.parent.mkdir(parents=True, exist_ok=True)
    ext = sp.suffix.lower()
    codec_args = ["-vn"]
    if ext == ".mp3":
        codec_args += ["-acodec", "libmp3lame", "-q:a", "2"]
    elif ext == ".wav":
        codec_args += ["-acodec", "pcm_s16le"]
    else:
        codec_args += ["-acodec", "copy"]
    try:
        r = subprocess.run(
            ["ffmpeg", "-y", "-i", str(rp)] + codec_args + [str(sp)],
            capture_output=True, timeout=600,
        )
        if r.returncode != 0:
            return _err(f"ffmpeg failed: {r.stderr.decode('utf-8', errors='replace')[-500:]}")
        return _ok(saved=str(sp), size=sp.stat().st_size)
    except Exception as ex:
        return _err(f"extract_audio failed: {ex}")


# -------- Documents ---------------------------------------------------------

def _t_docx_text(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    try:
        import docx  # type: ignore
    except Exception:
        return _err("python-docx not installed (pip install python-docx)")
    try:
        d = docx.Document(str(rp))
        paragraphs = [p.text for p in d.paragraphs]
        text = "\n".join(paragraphs)
        return _ok(path=str(rp), paragraphs=len(paragraphs), length=len(text), text=text)
    except Exception as ex:
        return _err(f"docx_text failed: {ex}")


def _t_spreadsheet_read(args: dict) -> dict:
    rp, e = _check_path(args.get("path"))
    if e:
        return e
    ext = rp.suffix.lower()
    max_rows = int(args.get("max_rows", 500) or 500)
    if ext == ".csv":
        try:
            with open(rp, "r", encoding="utf-8", errors="replace", newline="") as f:
                reader = csv.reader(f)
                rows = []
                for i, row in enumerate(reader):
                    if i >= max_rows:
                        break
                    rows.append(row)
            return _ok(path=str(rp), format="csv", rows=len(rows), data=rows)
        except Exception as ex:
            return _err(f"csv read failed: {ex}")
    if ext in (".xlsx", ".xlsm"):
        try:
            from openpyxl import load_workbook  # type: ignore
        except Exception:
            return _err("openpyxl not installed (pip install openpyxl)")
        try:
            wb = load_workbook(str(rp), read_only=True, data_only=True)
            sheets = {}
            for name in wb.sheetnames:
                ws = wb[name]
                rows = []
                for i, row in enumerate(ws.iter_rows(values_only=True)):
                    if i >= max_rows:
                        break
                    rows.append(list(row))
                sheets[name] = rows
            return _ok(path=str(rp), format="xlsx", sheets=list(sheets.keys()), data=sheets)
        except Exception as ex:
            return _err(f"xlsx read failed: {ex}")
    return _err(f"unsupported spreadsheet extension: {ext}")


# -------- EXTRA_TOOLS export ------------------------------------------------

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Photo library
    "media.list_photos": _t_list_photos,
    "media.photo_info": _t_photo_info,
    "media.photo_caption": _t_photo_caption,
    "media.photo_describe": _t_photo_describe,
    "media.photo_find_by_content": _t_photo_find_by_content,
    "media.photos_by_date": _t_photos_by_date,
    "media.photos_by_location": _t_photos_by_location,
    "media.screenshot_gallery": _t_screenshot_gallery,
    # Manipulation
    "media.photo_resize": _t_photo_resize,
    "media.photo_thumbnail": _t_photo_thumbnail,
    "media.photo_rotate": _t_photo_rotate,
    "media.photo_crop": _t_photo_crop,
    "media.photo_to_base64": _t_photo_to_base64,
    # PDF
    "media.pdf_list": _t_pdf_list,
    "media.pdf_text": _t_pdf_text,
    "media.pdf_summary": _t_pdf_summary,
    "media.pdf_page_image": _t_pdf_page_image,
    "media.pdf_metadata": _t_pdf_metadata,
    "media.pdf_ocr_page": _t_pdf_ocr_page,
    # Video
    "media.video_list": _t_video_list,
    "media.video_info": _t_video_info,
    "media.video_thumbnail": _t_video_thumbnail,
    "media.video_extract_audio": _t_video_extract_audio,
    # Documents
    "media.docx_text": _t_docx_text,
    "media.spreadsheet_read": _t_spreadsheet_read,
}
