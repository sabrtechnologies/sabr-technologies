"""
coding.py — Leon's software-engineering tool surface.

This module gives Leon hands-on developer reflexes: deep git inspection
(log/diff/show/blame/branch/who-owns/unmerged), Docker control (ps/logs/
exec/stop/compose), package managers (npm/pip install + outdated), code
quality (black/ruff/prettier/eslint + auto test runner), and project
scaffolding (python/node/html boilerplate).

Tools shell out to system binaries via `subprocess.run(..., capture_output=
True, text=True, timeout=N)` so they never block forever. If a binary is
missing the tool returns a clean `{"ok": False, "error": "...not
installed..."}` instead of crashing.

All filesystem operations are constrained to the owner's Desktop
subtree (`_DESKTOP_ROOT`, derived from the running user's home) unless the caller explicitly passes `allow_outside_desktop: true`
— this keeps a misfired tool from touching system directories.

Each tool takes a single `args` dict and returns either
`{"ok": True, "result": ...}` or `{"ok": False, "error": "..."}`. The
EXTRA_TOOLS dict at the bottom maps dotted tool names (e.g. `git.log`,
`docker.ps`, `scaffold.python_project`) to the implementing function —
import this dict from the responder / MCP server to register them in
one shot.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from typing import Any, Callable, Dict, List, Optional, Union


# ──────────────────────────────────────────────────────────────────────────
# CONSTANTS & HELPERS
# ──────────────────────────────────────────────────────────────────────────


_DESKTOP_ROOT = os.path.join(os.path.expanduser("~"), "Desktop")
_DEFAULT_TIMEOUT = 30


def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _which(binary: str) -> Optional[str]:
    """Return absolute path of `binary` on PATH, or None if not present."""
    return shutil.which(binary)


def _missing(binary: str) -> Dict[str, Any]:
    return _err(f"{binary} is not installed or not on PATH")


def _resolve_cwd(args: Dict[str, Any]) -> Optional[str]:
    """Resolve working directory: arg `cwd` → arg `path` → CWD.
    Returns None if resolution fails so callers can early-return."""
    candidate = args.get("cwd") or args.get("path") or os.getcwd()
    candidate = os.path.abspath(os.path.expanduser(str(candidate)))
    if not os.path.isdir(candidate):
        # Some tools accept a file path; fall back to its dirname.
        if os.path.isfile(candidate):
            return os.path.dirname(candidate)
        return None
    return candidate


def _check_in_desktop(path: str, args: Dict[str, Any]) -> Optional[str]:
    """Return None if path is safe, else an error message string.
    Permits any path under _DESKTOP_ROOT unless caller passes
    `allow_outside_desktop: true`."""
    if args.get("allow_outside_desktop") is True:
        return None
    real = os.path.realpath(path)
    if real == _DESKTOP_ROOT or real.startswith(_DESKTOP_ROOT + os.sep):
        return None
    return (
        f"path '{path}' is outside {_DESKTOP_ROOT}; "
        "pass allow_outside_desktop=true to override"
    )


def _run(
    cmd: List[str],
    cwd: Optional[str] = None,
    timeout: int = _DEFAULT_TIMEOUT,
    input_text: Optional[str] = None,
) -> Dict[str, Any]:
    """Wrap subprocess.run with our error contract. Returns a dict with
    stdout/stderr/code on success-or-nonzero, or an error string on
    timeout / FileNotFoundError. Never raises."""
    try:
        proc = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
            input=input_text,
        )
        return {
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "code": proc.returncode,
            "cmd": " ".join(cmd),
            "cwd": cwd,
        }
    except subprocess.TimeoutExpired:
        return {"_error": f"timeout after {timeout}s: {' '.join(cmd)}"}
    except FileNotFoundError:
        return {"_error": f"binary not found: {cmd[0]}"}
    except Exception as exc:  # noqa: BLE001
        return {"_error": f"{type(exc).__name__}: {exc}"}


def _wrap_run(result: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a `_run` dict into our public {ok, result|error} shape.
    Non-zero exit codes are still `ok: True` so the caller can read
    stderr — only hard failures (missing binary / timeout) are errors."""
    if "_error" in result:
        return _err(result["_error"])
    return _ok(result)


# ──────────────────────────────────────────────────────────────────────────
# GIT — INSPECTION
# ──────────────────────────────────────────────────────────────────────────


def git_log(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run `git log` with optional limit and oneline formatting."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    limit = int(args.get("limit", 20))
    oneline = bool(args.get("oneline", True))
    cmd = ["git", "log", f"-{limit}"]
    if oneline:
        cmd.append("--oneline")
    else:
        cmd.extend(["--pretty=format:%h %an %ad %s", "--date=short"])
    return _wrap_run(_run(cmd, cwd=cwd))


def git_diff(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git diff` — unstaged by default; pass `staged=true` for staged
    diff, or `file=<path>` to limit to one file."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    cmd = ["git", "diff"]
    if args.get("staged"):
        cmd.append("--staged")
    if args.get("file"):
        cmd.extend(["--", str(args["file"])])
    return _wrap_run(_run(cmd, cwd=cwd, timeout=60))


def git_show(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git show <ref>` — defaults to HEAD."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    ref = str(args.get("ref", "HEAD"))
    return _wrap_run(_run(["git", "show", ref], cwd=cwd, timeout=60))


def git_blame(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git blame <file>` with optional line range."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    file = args.get("file")
    if not file:
        return _err("file is required")
    cmd = ["git", "blame"]
    line_start = args.get("line_start")
    line_end = args.get("line_end")
    if line_start and line_end:
        cmd.extend(["-L", f"{int(line_start)},{int(line_end)}"])
    elif line_start:
        cmd.extend(["-L", f"{int(line_start)},+1"])
    cmd.append(str(file))
    return _wrap_run(_run(cmd, cwd=cwd, timeout=60))


def git_branch_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List local + remote branches via `git branch -a`."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    return _wrap_run(_run(["git", "branch", "-a", "--no-color"], cwd=cwd))


def git_recent_commits_by_file(args: Dict[str, Any]) -> Dict[str, Any]:
    """Recent commits that touched a specific file."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    file = args.get("file")
    if not file:
        return _err("file is required")
    limit = int(args.get("limit", 10))
    cmd = [
        "git", "log", f"-{limit}",
        "--pretty=format:%h %an %ad %s",
        "--date=short",
        "--", str(file),
    ]
    return _wrap_run(_run(cmd, cwd=cwd))


def git_who_owns(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return the committer who has touched `file` most often, plus the
    tally of each contributor."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    file = args.get("file")
    if not file:
        return _err("file is required")
    result = _run(
        ["git", "log", "--pretty=format:%an", "--", str(file)],
        cwd=cwd,
    )
    if "_error" in result:
        return _err(result["_error"])
    counts: Dict[str, int] = {}
    for line in result["stdout"].splitlines():
        name = line.strip()
        if not name:
            continue
        counts[name] = counts.get(name, 0) + 1
    if not counts:
        return _ok({"owner": None, "tally": {}, "file": file})
    owner = max(counts.items(), key=lambda kv: kv[1])[0]
    return _ok({"owner": owner, "tally": counts, "file": file})


def git_list_files_changed_since(args: Dict[str, Any]) -> Dict[str, Any]:
    """Files changed since a given ref (default HEAD~10)."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    since = str(args.get("since", "HEAD~10"))
    result = _run(
        ["git", "diff", "--name-only", f"{since}..HEAD"],
        cwd=cwd,
    )
    if "_error" in result:
        return _err(result["_error"])
    files = [ln for ln in result["stdout"].splitlines() if ln.strip()]
    return _ok({"since": since, "files": files, "count": len(files)})


def git_unmerged_files(args: Dict[str, Any]) -> Dict[str, Any]:
    """Files currently in merge conflict (`git diff --name-only
    --diff-filter=U`)."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    result = _run(
        ["git", "diff", "--name-only", "--diff-filter=U"],
        cwd=cwd,
    )
    if "_error" in result:
        return _err(result["_error"])
    files = [ln for ln in result["stdout"].splitlines() if ln.strip()]
    return _ok({"files": files, "count": len(files)})


def git_stash_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git stash list`."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    return _wrap_run(_run(["git", "stash", "list"], cwd=cwd))


# ──────────────────────────────────────────────────────────────────────────
# GIT — MUTATIONS (MEDIUM RISK)
# ──────────────────────────────────────────────────────────────────────────


def git_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git add` — paths may be a list, a single string, or '.'."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    paths = args.get("paths")
    if paths is None:
        return _err("paths is required (list, string, or '.')")
    if isinstance(paths, str):
        path_list = [paths]
    elif isinstance(paths, list):
        path_list = [str(p) for p in paths]
    else:
        return _err("paths must be list or string")
    return _wrap_run(_run(["git", "add", *path_list], cwd=cwd))


def git_commit(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git commit -m <message>` — MEDIUM risk: writes history."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    message = args.get("message")
    if not message:
        return _err("message is required")
    return _wrap_run(_run(["git", "commit", "-m", str(message)], cwd=cwd))


def git_create_branch(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git checkout -b <branch_name>` — creates + switches.
    MEDIUM risk: changes working tree state."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    branch = args.get("branch_name") or args.get("branch")
    if not branch:
        return _err("branch_name is required")
    return _wrap_run(_run(["git", "checkout", "-b", str(branch)], cwd=cwd))


def git_checkout(args: Dict[str, Any]) -> Dict[str, Any]:
    """`git checkout <ref>` — MEDIUM risk: changes working tree."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("git"):
        return _missing("git")
    ref = args.get("ref")
    if not ref:
        return _err("ref is required")
    return _wrap_run(_run(["git", "checkout", str(ref)], cwd=cwd))


# ──────────────────────────────────────────────────────────────────────────
# DOCKER
# ──────────────────────────────────────────────────────────────────────────


def docker_ps(args: Dict[str, Any]) -> Dict[str, Any]:
    """`docker ps`; pass `all=true` to include stopped containers."""
    if not _which("docker"):
        return _missing("docker")
    cmd = ["docker", "ps"]
    if args.get("all"):
        cmd.append("-a")
    return _wrap_run(_run(cmd, timeout=20))


def docker_images(args: Dict[str, Any]) -> Dict[str, Any]:
    """`docker images`."""
    if not _which("docker"):
        return _missing("docker")
    return _wrap_run(_run(["docker", "images"], timeout=20))


def docker_logs(args: Dict[str, Any]) -> Dict[str, Any]:
    """Tail `lines` (default 50) of a container's logs."""
    if not _which("docker"):
        return _missing("docker")
    container = args.get("container")
    if not container:
        return _err("container is required")
    lines = int(args.get("lines", 50))
    return _wrap_run(_run(
        ["docker", "logs", "--tail", str(lines), str(container)],
        timeout=30,
    ))


def docker_exec(args: Dict[str, Any]) -> Dict[str, Any]:
    """`docker exec <container> <cmd>` — MEDIUM risk: arbitrary code.
    `cmd` may be a string (split on spaces) or a list."""
    if not _which("docker"):
        return _missing("docker")
    container = args.get("container")
    if not container:
        return _err("container is required")
    cmd = args.get("cmd")
    if not cmd:
        return _err("cmd is required")
    if isinstance(cmd, str):
        cmd_parts = cmd.split()
    elif isinstance(cmd, list):
        cmd_parts = [str(c) for c in cmd]
    else:
        return _err("cmd must be string or list")
    timeout = int(args.get("timeout", 20))
    return _wrap_run(_run(
        ["docker", "exec", str(container), *cmd_parts],
        timeout=timeout,
    ))


def docker_stop(args: Dict[str, Any]) -> Dict[str, Any]:
    """`docker stop <container>` — MEDIUM risk."""
    if not _which("docker"):
        return _missing("docker")
    container = args.get("container")
    if not container:
        return _err("container is required")
    return _wrap_run(_run(
        ["docker", "stop", str(container)],
        timeout=30,
    ))


def docker_compose_up(args: Dict[str, Any]) -> Dict[str, Any]:
    """`docker compose up` in cwd; detached by default. MEDIUM risk."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    # Prefer `docker compose` (v2) but fall back to `docker-compose`.
    base: List[str]
    if _which("docker"):
        base = ["docker", "compose"]
    elif _which("docker-compose"):
        base = ["docker-compose"]
    else:
        return _missing("docker / docker-compose")
    cmd = base + ["up"]
    if args.get("detach", True):
        cmd.append("-d")
    return _wrap_run(_run(cmd, cwd=cwd, timeout=120))


def docker_compose_down(args: Dict[str, Any]) -> Dict[str, Any]:
    """`docker compose down` in cwd. MEDIUM risk."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if _which("docker"):
        base = ["docker", "compose"]
    elif _which("docker-compose"):
        base = ["docker-compose"]
    else:
        return _missing("docker / docker-compose")
    return _wrap_run(_run(base + ["down"], cwd=cwd, timeout=60))


# ──────────────────────────────────────────────────────────────────────────
# PACKAGE MANAGERS
# ──────────────────────────────────────────────────────────────────────────


def pkg_npm_install(args: Dict[str, Any]) -> Dict[str, Any]:
    """`npm install <package>` in cwd; `dev=true` adds `--save-dev`.
    MEDIUM risk: writes node_modules + package.json."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("npm"):
        return _missing("npm")
    package = args.get("package")
    if not package:
        return _err("package is required")
    cmd = ["npm", "install", str(package)]
    if args.get("dev"):
        cmd.append("--save-dev")
    return _wrap_run(_run(cmd, cwd=cwd, timeout=300))


def pkg_pip_install(args: Dict[str, Any]) -> Dict[str, Any]:
    """`pip install <package>`. MEDIUM risk: mutates Python env."""
    package = args.get("package")
    if not package:
        return _err("package is required")
    pip_bin = _which("pip3") or _which("pip")
    if not pip_bin:
        return _missing("pip")
    return _wrap_run(_run(
        [pip_bin, "install", str(package)],
        timeout=300,
    ))


def pkg_pip_freeze(args: Dict[str, Any]) -> Dict[str, Any]:
    """`pip freeze` — list installed packages."""
    cwd = args.get("cwd")
    if cwd:
        cwd = os.path.abspath(os.path.expanduser(str(cwd)))
        if not os.path.isdir(cwd):
            cwd = None
    pip_bin = _which("pip3") or _which("pip")
    if not pip_bin:
        return _missing("pip")
    result = _run([pip_bin, "freeze"], cwd=cwd, timeout=30)
    if "_error" in result:
        return _err(result["_error"])
    packages = [ln for ln in result["stdout"].splitlines() if ln.strip()]
    return _ok({"packages": packages, "count": len(packages)})


def pkg_outdated_npm(args: Dict[str, Any]) -> Dict[str, Any]:
    """`npm outdated` in cwd. Exit code 1 is normal when something is
    outdated — we still return the stdout."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    if not _which("npm"):
        return _missing("npm")
    return _wrap_run(_run(["npm", "outdated"], cwd=cwd, timeout=60))


def pkg_outdated_pip(args: Dict[str, Any]) -> Dict[str, Any]:
    """`pip list --outdated`."""
    pip_bin = _which("pip3") or _which("pip")
    if not pip_bin:
        return _missing("pip")
    return _wrap_run(_run(
        [pip_bin, "list", "--outdated"],
        timeout=60,
    ))


# ──────────────────────────────────────────────────────────────────────────
# CODE QUALITY
# ──────────────────────────────────────────────────────────────────────────


def code_format_python(args: Dict[str, Any]) -> Dict[str, Any]:
    """Format Python with `black` (default) or `ruff format`."""
    target = args.get("file_or_dir") or args.get("path")
    if not target:
        return _err("file_or_dir is required")
    target_abs = os.path.abspath(os.path.expanduser(str(target)))
    guard = _check_in_desktop(target_abs, args)
    if guard:
        return _err(guard)
    if not os.path.exists(target_abs):
        return _err(f"path does not exist: {target_abs}")
    formatter = (args.get("formatter") or "black").lower()
    if formatter == "black":
        if not _which("black"):
            return _missing("black")
        return _wrap_run(_run(["black", target_abs], timeout=120))
    if formatter == "ruff":
        if not _which("ruff"):
            return _missing("ruff")
        return _wrap_run(_run(
            ["ruff", "format", target_abs],
            timeout=120,
        ))
    return _err(f"unknown formatter: {formatter} (use black or ruff)")


def code_lint_python(args: Dict[str, Any]) -> Dict[str, Any]:
    """Lint Python with `ruff check` (default) or `pylint`."""
    target = args.get("file_or_dir") or args.get("path")
    if not target:
        return _err("file_or_dir is required")
    target_abs = os.path.abspath(os.path.expanduser(str(target)))
    guard = _check_in_desktop(target_abs, args)
    if guard:
        return _err(guard)
    if not os.path.exists(target_abs):
        return _err(f"path does not exist: {target_abs}")
    linter = (args.get("linter") or "ruff").lower()
    if linter == "ruff":
        if not _which("ruff"):
            return _missing("ruff")
        return _wrap_run(_run(
            ["ruff", "check", target_abs],
            timeout=120,
        ))
    if linter == "pylint":
        if not _which("pylint"):
            return _missing("pylint")
        return _wrap_run(_run(["pylint", target_abs], timeout=120))
    return _err(f"unknown linter: {linter} (use ruff or pylint)")


def code_format_js(args: Dict[str, Any]) -> Dict[str, Any]:
    """Format JS/TS with `prettier`."""
    target = args.get("file_or_dir") or args.get("path")
    if not target:
        return _err("file_or_dir is required")
    target_abs = os.path.abspath(os.path.expanduser(str(target)))
    guard = _check_in_desktop(target_abs, args)
    if guard:
        return _err(guard)
    if not os.path.exists(target_abs):
        return _err(f"path does not exist: {target_abs}")
    formatter = (args.get("formatter") or "prettier").lower()
    if formatter != "prettier":
        return _err(f"unknown formatter: {formatter} (use prettier)")
    # Prefer npx so a project-local prettier is picked up if present.
    if _which("prettier"):
        cmd = ["prettier", "--write", target_abs]
    elif _which("npx"):
        cmd = ["npx", "--no-install", "prettier", "--write", target_abs]
    else:
        return _missing("prettier")
    return _wrap_run(_run(cmd, timeout=120))


def code_lint_js(args: Dict[str, Any]) -> Dict[str, Any]:
    """Lint JS/TS with `eslint`."""
    target = args.get("file_or_dir") or args.get("path")
    if not target:
        return _err("file_or_dir is required")
    target_abs = os.path.abspath(os.path.expanduser(str(target)))
    guard = _check_in_desktop(target_abs, args)
    if guard:
        return _err(guard)
    if not os.path.exists(target_abs):
        return _err(f"path does not exist: {target_abs}")
    if _which("eslint"):
        cmd = ["eslint", target_abs]
    elif _which("npx"):
        cmd = ["npx", "--no-install", "eslint", target_abs]
    else:
        return _missing("eslint")
    return _wrap_run(_run(cmd, timeout=120))


def code_run_tests(args: Dict[str, Any]) -> Dict[str, Any]:
    """Auto-detect test framework by looking for config files in cwd:
    pytest (pytest.ini / pyproject.toml with [tool.pytest] / tests/),
    jest (jest.config.* or package.json with `jest`), or mocha
    (.mocharc.* or package.json with `mocha`). Override with
    `framework=pytest|jest|mocha`."""
    cwd = _resolve_cwd(args)
    if cwd is None:
        return _err("could not resolve cwd")
    framework = (args.get("framework") or "auto").lower()
    if framework == "auto":
        framework = _detect_test_framework(cwd)
    if framework == "pytest":
        if not _which("pytest"):
            return _missing("pytest")
        return _wrap_run(_run(["pytest", "-q"], cwd=cwd, timeout=600))
    if framework == "jest":
        if _which("jest"):
            cmd = ["jest"]
        elif _which("npx"):
            cmd = ["npx", "--no-install", "jest"]
        else:
            return _missing("jest")
        return _wrap_run(_run(cmd, cwd=cwd, timeout=600))
    if framework == "mocha":
        if _which("mocha"):
            cmd = ["mocha"]
        elif _which("npx"):
            cmd = ["npx", "--no-install", "mocha"]
        else:
            return _missing("mocha")
        return _wrap_run(_run(cmd, cwd=cwd, timeout=600))
    if framework == "none":
        return _err("no test framework detected; pass framework=...")
    return _err(f"unknown framework: {framework}")


def _detect_test_framework(cwd: str) -> str:
    """Return 'pytest' | 'jest' | 'mocha' | 'none' based on cwd contents."""
    # Pytest signals
    if os.path.isfile(os.path.join(cwd, "pytest.ini")):
        return "pytest"
    if os.path.isdir(os.path.join(cwd, "tests")):
        if any(
            f.startswith("test_") and f.endswith(".py")
            for f in os.listdir(os.path.join(cwd, "tests"))
            if os.path.isfile(os.path.join(cwd, "tests", f))
        ):
            return "pytest"
    pyproject = os.path.join(cwd, "pyproject.toml")
    if os.path.isfile(pyproject):
        try:
            with open(pyproject, "r", encoding="utf-8") as fh:
                if "[tool.pytest" in fh.read():
                    return "pytest"
        except OSError:
            pass
    # JS signals
    for fn in os.listdir(cwd):
        if fn.startswith("jest.config."):
            return "jest"
        if fn.startswith(".mocharc"):
            return "mocha"
    pkg_json = os.path.join(cwd, "package.json")
    if os.path.isfile(pkg_json):
        try:
            with open(pkg_json, "r", encoding="utf-8") as fh:
                content = fh.read()
                if '"jest"' in content:
                    return "jest"
                if '"mocha"' in content:
                    return "mocha"
        except OSError:
            pass
    return "none"


# ──────────────────────────────────────────────────────────────────────────
# PROJECT SCAFFOLDING
# ──────────────────────────────────────────────────────────────────────────


def _resolve_scaffold_parent(args: Dict[str, Any]) -> Union[str, Dict[str, Any]]:
    """Resolve scaffold parent dir; default = Desktop. Returns abs path
    or an error dict."""
    parent = args.get("parent") or _DESKTOP_ROOT
    parent_abs = os.path.abspath(os.path.expanduser(str(parent)))
    guard = _check_in_desktop(parent_abs, args)
    if guard:
        return _err(guard)
    if not os.path.isdir(parent_abs):
        return _err(f"parent does not exist: {parent_abs}")
    return parent_abs


def scaffold_python_project(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a minimal Python project: src package, README, .gitignore,
    pyproject.toml, optional venv (with_venv=True) and pytest skeleton
    (with_pytest=True)."""
    name = args.get("name")
    if not name:
        return _err("name is required")
    name = str(name).strip()
    if not name or "/" in name or name.startswith("."):
        return _err("name must be a simple folder name")
    parent = _resolve_scaffold_parent(args)
    if isinstance(parent, dict):
        return parent
    project = os.path.join(parent, name)
    if os.path.exists(project):
        return _err(f"already exists: {project}")
    try:
        os.makedirs(os.path.join(project, name))
        with open(os.path.join(project, name, "__init__.py"), "w") as fh:
            fh.write(f'"""{name} package."""\n')
        with open(os.path.join(project, "README.md"), "w") as fh:
            fh.write(f"# {name}\n\nA new Python project.\n")
        with open(os.path.join(project, ".gitignore"), "w") as fh:
            fh.write(
                "__pycache__/\n*.pyc\n.venv/\nvenv/\n.pytest_cache/\n"
                "dist/\nbuild/\n*.egg-info/\n.env\n"
            )
        with open(os.path.join(project, "pyproject.toml"), "w") as fh:
            fh.write(
                f'[project]\nname = "{name}"\nversion = "0.1.0"\n'
                f'description = ""\nrequires-python = ">=3.10"\n'
                f'dependencies = []\n\n'
                f'[build-system]\nrequires = ["setuptools"]\n'
                f'build-backend = "setuptools.build_meta"\n'
            )
    except OSError as exc:
        return _err(f"failed to create files: {exc}")
    created: List[str] = [
        os.path.join(name, "__init__.py"),
        "README.md", ".gitignore", "pyproject.toml",
    ]
    if args.get("with_pytest", True):
        try:
            os.makedirs(os.path.join(project, "tests"))
            with open(
                os.path.join(project, "tests", "test_basic.py"), "w"
            ) as fh:
                fh.write(
                    "def test_truth():\n    assert True\n"
                )
            created.append("tests/test_basic.py")
        except OSError as exc:
            return _err(f"pytest scaffold failed: {exc}")
    venv_result: Optional[Dict[str, Any]] = None
    if args.get("with_venv", True):
        py = _which("python3") or _which("python")
        if py:
            venv_result = _run(
                [py, "-m", "venv", ".venv"],
                cwd=project,
                timeout=60,
            )
    return _ok({
        "path": project,
        "created": created,
        "venv": venv_result,
    })


def scaffold_node_project(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a minimal Node project: package.json (via `npm/pnpm/yarn
    init -y`), index.js, README, .gitignore."""
    name = args.get("name")
    if not name:
        return _err("name is required")
    name = str(name).strip()
    if not name or "/" in name or name.startswith("."):
        return _err("name must be a simple folder name")
    parent = _resolve_scaffold_parent(args)
    if isinstance(parent, dict):
        return parent
    project = os.path.join(parent, name)
    if os.path.exists(project):
        return _err(f"already exists: {project}")
    pm = (args.get("package_manager") or "npm").lower()
    if pm not in ("npm", "pnpm", "yarn"):
        return _err(f"unknown package_manager: {pm}")
    if not _which(pm):
        return _missing(pm)
    try:
        os.makedirs(project)
        with open(os.path.join(project, "index.js"), "w") as fh:
            fh.write(
                'console.log("hello from ' + name + '");\n'
            )
        with open(os.path.join(project, "README.md"), "w") as fh:
            fh.write(f"# {name}\n\nA new Node project.\n")
        with open(os.path.join(project, ".gitignore"), "w") as fh:
            fh.write("node_modules/\n.env\ndist/\n*.log\n")
    except OSError as exc:
        return _err(f"failed to create files: {exc}")
    init_result = _run([pm, "init", "-y"], cwd=project, timeout=60)
    return _ok({
        "path": project,
        "package_manager": pm,
        "created": ["index.js", "README.md", ".gitignore", "package.json"],
        "init": init_result,
    })


def scaffold_html_project(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a tiny static-site folder: index.html + style.css +
    script.js, all linked together."""
    name = args.get("name")
    if not name:
        return _err("name is required")
    name = str(name).strip()
    if not name or "/" in name or name.startswith("."):
        return _err("name must be a simple folder name")
    parent = _resolve_scaffold_parent(args)
    if isinstance(parent, dict):
        return parent
    project = os.path.join(parent, name)
    if os.path.exists(project):
        return _err(f"already exists: {project}")
    try:
        os.makedirs(project)
        html = (
            "<!doctype html>\n<html lang=\"en\">\n<head>\n"
            "  <meta charset=\"utf-8\">\n"
            f"  <title>{name}</title>\n"
            "  <link rel=\"stylesheet\" href=\"style.css\">\n"
            "</head>\n<body>\n"
            f"  <h1>{name}</h1>\n"
            "  <script src=\"script.js\"></script>\n"
            "</body>\n</html>\n"
        )
        css = (
            "body {\n  font-family: -apple-system, system-ui, sans-serif;\n"
            "  background: #0a0a0a;\n  color: #00ffc8;\n"
            "  margin: 2rem;\n}\n"
        )
        js = 'console.log("hello from ' + name + '");\n'
        with open(os.path.join(project, "index.html"), "w") as fh:
            fh.write(html)
        with open(os.path.join(project, "style.css"), "w") as fh:
            fh.write(css)
        with open(os.path.join(project, "script.js"), "w") as fh:
            fh.write(js)
    except OSError as exc:
        return _err(f"failed to create files: {exc}")
    return _ok({
        "path": project,
        "created": ["index.html", "style.css", "script.js"],
    })


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # Git — inspection
    "git.log": git_log,
    "git.diff": git_diff,
    "git.show": git_show,
    "git.blame": git_blame,
    "git.branch_list": git_branch_list,
    "git.recent_commits_by_file": git_recent_commits_by_file,
    "git.who_owns": git_who_owns,
    "git.list_files_changed_since": git_list_files_changed_since,
    "git.unmerged_files": git_unmerged_files,
    "git.stash_list": git_stash_list,
    # Git — mutations
    "git.add": git_add,
    "git.commit": git_commit,
    "git.create_branch": git_create_branch,
    "git.checkout": git_checkout,
    # Docker
    "docker.ps": docker_ps,
    "docker.images": docker_images,
    "docker.logs": docker_logs,
    "docker.exec": docker_exec,
    "docker.stop": docker_stop,
    "docker.compose_up": docker_compose_up,
    "docker.compose_down": docker_compose_down,
    # Package managers
    "pkg.npm_install": pkg_npm_install,
    "pkg.pip_install": pkg_pip_install,
    "pkg.pip_freeze": pkg_pip_freeze,
    "pkg.outdated_npm": pkg_outdated_npm,
    "pkg.outdated_pip": pkg_outdated_pip,
    # Code quality
    "code.format_python": code_format_python,
    "code.lint_python": code_lint_python,
    "code.format_js": code_format_js,
    "code.lint_js": code_lint_js,
    "code.run_tests": code_run_tests,
    # Scaffolding
    "scaffold.python_project": scaffold_python_project,
    "scaffold.node_project": scaffold_node_project,
    "scaffold.html_project": scaffold_html_project,
}
