"""
productivity.py — Leon's productivity tool surface.

Gives Leon the ability to manage Dean's day-to-day execution: tasks,
journal entries, habits, time tracking, pomodoros, focus blocks, and
daily/weekly reviews.

All persistence is local SQLite at `brain_state/productivity.db` (auto-
created on first call). Each tool takes a single `args` dict and returns
`{"ok": True, "result": ...}` or `{"ok": False, "error": "..."}`. The
`EXTRA_TOOLS` dict at the bottom maps dotted tool names (e.g.
`task.add`, `journal.entry_add`) to the implementing function.

Style matches `brain/memory_extras.py`.
"""

from __future__ import annotations

import os
import sqlite3
import threading
import time
from datetime import datetime, date, timedelta
from typing import Any, Callable, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────────
# PATHS & CONNECTION
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/)."""
    # this file lives at brain/integrations/productivity.py — two levels up
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "productivity.db")


_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    status TEXT DEFAULT 'open',
    priority TEXT DEFAULT 'normal',
    due_date TEXT,
    tags TEXT,
    created_at REAL DEFAULT (strftime('%s','now')),
    completed_at REAL,
    project TEXT
);
CREATE TABLE IF NOT EXISTS journal (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_text TEXT NOT NULL,
    mood TEXT,
    tags TEXT,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS habits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    target_frequency_per_week INTEGER DEFAULT 7,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS habit_completions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    habit_id INTEGER NOT NULL,
    completed_at REAL DEFAULT (strftime('%s','now')),
    notes TEXT,
    FOREIGN KEY (habit_id) REFERENCES habits(id)
);
CREATE TABLE IF NOT EXISTS time_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project TEXT,
    description TEXT,
    started_at REAL,
    ended_at REAL,
    duration_seconds REAL,
    tags TEXT
);
CREATE TABLE IF NOT EXISTS pomodoros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT,
    started_at REAL,
    ended_at REAL,
    duration_seconds REAL,
    completed INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS focus_blocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT,
    started_at REAL,
    planned_duration_seconds REAL,
    ended_at REAL,
    distractions_count INTEGER DEFAULT 0
);
"""


def _conn() -> sqlite3.Connection:
    """Lazy SQLite connection. Creates schema on first call."""
    global _DB_CONN
    if _DB_CONN is not None:
        return _DB_CONN
    with _DB_LOCK:
        if _DB_CONN is not None:
            return _DB_CONN
        conn = sqlite3.connect(
            _db_path(),
            timeout=30,
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
        _DB_CONN = conn
    return _DB_CONN


# ──────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _row(r: sqlite3.Row) -> Optional[Dict[str, Any]]:
    if r is None:
        return None
    return {k: r[k] for k in r.keys()}


def _rows(rs) -> List[Dict[str, Any]]:
    return [_row(r) for r in rs]


def _today_str() -> str:
    return date.today().isoformat()


def _week_bounds(ref: Optional[date] = None) -> (date, date):
    """Return (monday, sunday) of the week containing ref (default today)."""
    d = ref or date.today()
    monday = d - timedelta(days=d.weekday())
    sunday = monday + timedelta(days=6)
    return monday, sunday


def _normalize_tags(tags: Any) -> Optional[str]:
    if tags is None:
        return None
    if isinstance(tags, list):
        return ",".join(str(t).strip() for t in tags if str(t).strip())
    return str(tags).strip() or None


def _resolve_habit(name_or_id: Any) -> Optional[Dict[str, Any]]:
    """Look up a habit by integer id or name. Returns row or None."""
    if name_or_id is None:
        return None
    c = _conn()
    if isinstance(name_or_id, int) or (
        isinstance(name_or_id, str) and name_or_id.isdigit()
    ):
        r = c.execute(
            "SELECT * FROM habits WHERE id = ?", (int(name_or_id),)
        ).fetchone()
    else:
        r = c.execute(
            "SELECT * FROM habits WHERE name = ?", (str(name_or_id),)
        ).fetchone()
    return _row(r)


def _presence_try(fn_name: str, args: Dict[str, Any]) -> None:
    """Best-effort call into brain.presence.<fn_name>(args). Silently ignored
    if the module or tool isn't available — productivity tools must not raise."""
    try:
        from brain import presence  # type: ignore
        fn = getattr(presence, fn_name, None)
        if callable(fn):
            fn(args)
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────────────────
# TASKS
# ──────────────────────────────────────────────────────────────────────────


_VALID_PRIORITY = {"low", "normal", "high"}
_VALID_STATUS = {"open", "done"}


def task_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add a new task. Returns the inserted row."""
    title = (args.get("title") or "").strip()
    if not title:
        return _err("title is required")
    priority = (args.get("priority") or "normal").lower()
    if priority not in _VALID_PRIORITY:
        return _err(f"priority must be one of {sorted(_VALID_PRIORITY)}")
    due_date = args.get("due_date")
    tags = _normalize_tags(args.get("tags"))
    project = args.get("project")
    try:
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                """INSERT INTO tasks (title, status, priority, due_date, tags, project)
                   VALUES (?, 'open', ?, ?, ?, ?)""",
                (title, priority, due_date, tags, project),
            )
            c.commit()
            new_id = cur.lastrowid
        row = c.execute("SELECT * FROM tasks WHERE id = ?", (new_id,)).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"task_add failed: {e}")


def task_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List tasks. status in {open, done, all}; optional project filter."""
    status = (args.get("status") or "open").lower()
    limit = int(args.get("limit") or 50)
    project = args.get("project")
    where = []
    params: List[Any] = []
    if status != "all":
        if status not in _VALID_STATUS:
            return _err("status must be open, done, or all")
        where.append("status = ?")
        params.append(status)
    if project:
        where.append("project = ?")
        params.append(project)
    sql = "SELECT * FROM tasks"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY (status='done'), priority='high' DESC, due_date IS NULL, due_date ASC, id DESC LIMIT ?"
    params.append(limit)
    try:
        rows = _conn().execute(sql, params).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"task_list failed: {e}")


def task_complete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Mark a task done. Sets completed_at to now."""
    task_id = args.get("task_id")
    if task_id is None:
        return _err("task_id is required")
    try:
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                "UPDATE tasks SET status='done', completed_at=? WHERE id=?",
                (time.time(), int(task_id)),
            )
            c.commit()
        if cur.rowcount == 0:
            return _err(f"no task with id {task_id}")
        row = c.execute("SELECT * FROM tasks WHERE id=?", (int(task_id),)).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"task_complete failed: {e}")


def task_reopen(args: Dict[str, Any]) -> Dict[str, Any]:
    """Re-open a previously completed task."""
    task_id = args.get("task_id")
    if task_id is None:
        return _err("task_id is required")
    try:
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                "UPDATE tasks SET status='open', completed_at=NULL WHERE id=?",
                (int(task_id),),
            )
            c.commit()
        if cur.rowcount == 0:
            return _err(f"no task with id {task_id}")
        row = c.execute("SELECT * FROM tasks WHERE id=?", (int(task_id),)).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"task_reopen failed: {e}")


def task_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a task permanently."""
    task_id = args.get("task_id")
    if task_id is None:
        return _err("task_id is required")
    try:
        c = _conn()
        with _DB_LOCK:
            cur = c.execute("DELETE FROM tasks WHERE id=?", (int(task_id),))
            c.commit()
        if cur.rowcount == 0:
            return _err(f"no task with id {task_id}")
        return _ok({"deleted": int(task_id)})
    except Exception as e:
        return _err(f"task_delete failed: {e}")


def task_update(args: Dict[str, Any]) -> Dict[str, Any]:
    """Update fields on a task. Accepts title, priority, due_date, tags,
    project, status."""
    task_id = args.get("task_id")
    if task_id is None:
        return _err("task_id is required")
    allowed = {"title", "priority", "due_date", "tags", "project", "status"}
    fields = {k: v for k, v in args.items() if k in allowed}
    if not fields:
        return _err("no updatable fields provided")
    if "priority" in fields and fields["priority"] not in _VALID_PRIORITY:
        return _err(f"priority must be one of {sorted(_VALID_PRIORITY)}")
    if "status" in fields and fields["status"] not in _VALID_STATUS:
        return _err("status must be open or done")
    if "tags" in fields:
        fields["tags"] = _normalize_tags(fields["tags"])
    set_clause = ", ".join(f"{k}=?" for k in fields.keys())
    params = list(fields.values()) + [int(task_id)]
    try:
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(f"UPDATE tasks SET {set_clause} WHERE id=?", params)
            c.commit()
        if cur.rowcount == 0:
            return _err(f"no task with id {task_id}")
        row = c.execute("SELECT * FROM tasks WHERE id=?", (int(task_id),)).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"task_update failed: {e}")


def task_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Substring search over task titles (case-insensitive)."""
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query is required")
    try:
        rows = _conn().execute(
            "SELECT * FROM tasks WHERE title LIKE ? ORDER BY id DESC LIMIT 100",
            (f"%{query}%",),
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"task_search failed: {e}")


def task_today(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open tasks with due_date today or overdue."""
    today = _today_str()
    try:
        rows = _conn().execute(
            """SELECT * FROM tasks
               WHERE status='open' AND due_date IS NOT NULL AND due_date <= ?
               ORDER BY due_date ASC, priority='high' DESC, id ASC""",
            (today,),
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"task_today failed: {e}")


def task_this_week(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open tasks due within the next 7 days."""
    today = date.today()
    end = (today + timedelta(days=7)).isoformat()
    start = today.isoformat()
    try:
        rows = _conn().execute(
            """SELECT * FROM tasks
               WHERE status='open' AND due_date IS NOT NULL
                 AND due_date >= ? AND due_date <= ?
               ORDER BY due_date ASC, priority='high' DESC""",
            (start, end),
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"task_this_week failed: {e}")


def task_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """Counts of tasks broken down by status and priority."""
    try:
        c = _conn()
        by_status = {
            r["status"]: r["n"]
            for r in c.execute(
                "SELECT status, COUNT(*) as n FROM tasks GROUP BY status"
            ).fetchall()
        }
        by_priority = {
            r["priority"]: r["n"]
            for r in c.execute(
                "SELECT priority, COUNT(*) as n FROM tasks WHERE status='open' GROUP BY priority"
            ).fetchall()
        }
        total = c.execute("SELECT COUNT(*) as n FROM tasks").fetchone()["n"]
        return _ok(
            {
                "total": total,
                "by_status": by_status,
                "open_by_priority": by_priority,
            }
        )
    except Exception as e:
        return _err(f"task_summary failed: {e}")


# ──────────────────────────────────────────────────────────────────────────
# JOURNAL
# ──────────────────────────────────────────────────────────────────────────


def journal_entry_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add a journal entry. mood is free-form string."""
    text = (args.get("text") or "").strip()
    if not text:
        return _err("text is required")
    mood = args.get("mood")
    tags = _normalize_tags(args.get("tags"))
    try:
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                "INSERT INTO journal (entry_text, mood, tags) VALUES (?, ?, ?)",
                (text, mood, tags),
            )
            c.commit()
            new_id = cur.lastrowid
        row = c.execute("SELECT * FROM journal WHERE id=?", (new_id,)).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"journal_entry_add failed: {e}")


def journal_entry_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List journal entries newest first. Optional `since` (epoch seconds
    or ISO date)."""
    limit = int(args.get("limit") or 20)
    since = args.get("since")
    sql = "SELECT * FROM journal"
    params: List[Any] = []
    if since is not None:
        try:
            if isinstance(since, (int, float)):
                since_ts = float(since)
            else:
                since_ts = datetime.fromisoformat(str(since)).timestamp()
        except Exception:
            return _err("since must be epoch seconds or ISO date")
        sql += " WHERE created_at >= ?"
        params.append(since_ts)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    try:
        rows = _conn().execute(sql, params).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"journal_entry_list failed: {e}")


def journal_entry_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Substring search over journal entry_text."""
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query is required")
    try:
        rows = _conn().execute(
            "SELECT * FROM journal WHERE entry_text LIKE ? ORDER BY id DESC LIMIT 100",
            (f"%{query}%",),
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"journal_entry_search failed: {e}")


def journal_today_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """All of today's journal entries concatenated, plus mood list."""
    start = datetime.combine(date.today(), datetime.min.time()).timestamp()
    end = start + 86400
    try:
        rows = _conn().execute(
            "SELECT * FROM journal WHERE created_at >= ? AND created_at < ? ORDER BY id ASC",
            (start, end),
        ).fetchall()
        entries = _rows(rows)
        text = "\n\n".join(e["entry_text"] for e in entries)
        moods = [e["mood"] for e in entries if e["mood"]]
        return _ok(
            {
                "date": _today_str(),
                "count": len(entries),
                "text": text,
                "moods": moods,
                "entries": entries,
            }
        )
    except Exception as e:
        return _err(f"journal_today_summary failed: {e}")


def journal_this_week_digest(args: Dict[str, Any]) -> Dict[str, Any]:
    """Bullet digest of this week's journal entries (one bullet per entry,
    truncated to ~140 chars)."""
    monday, sunday = _week_bounds()
    start = datetime.combine(monday, datetime.min.time()).timestamp()
    end = datetime.combine(sunday + timedelta(days=1), datetime.min.time()).timestamp()
    try:
        rows = _conn().execute(
            "SELECT * FROM journal WHERE created_at >= ? AND created_at < ? ORDER BY created_at ASC",
            (start, end),
        ).fetchall()
        entries = _rows(rows)
        bullets = []
        for e in entries:
            d = datetime.fromtimestamp(e["created_at"]).strftime("%a %H:%M")
            snippet = e["entry_text"].strip().replace("\n", " ")
            if len(snippet) > 140:
                snippet = snippet[:137] + "..."
            mood = f" [{e['mood']}]" if e["mood"] else ""
            bullets.append(f"- {d}{mood}: {snippet}")
        digest = "\n".join(bullets) if bullets else "(no entries this week)"
        return _ok(
            {
                "week_start": monday.isoformat(),
                "week_end": sunday.isoformat(),
                "count": len(entries),
                "digest": digest,
            }
        )
    except Exception as e:
        return _err(f"journal_this_week_digest failed: {e}")


# ──────────────────────────────────────────────────────────────────────────
# HABITS
# ──────────────────────────────────────────────────────────────────────────


def habit_define(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create (or upsert) a habit definition."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    target = int(args.get("target_per_week") or 7)
    if target < 1 or target > 7:
        return _err("target_per_week must be in 1..7")
    try:
        c = _conn()
        with _DB_LOCK:
            c.execute(
                """INSERT INTO habits (name, target_frequency_per_week)
                   VALUES (?, ?)
                   ON CONFLICT(name) DO UPDATE SET
                     target_frequency_per_week = excluded.target_frequency_per_week""",
                (name, target),
            )
            c.commit()
        row = c.execute("SELECT * FROM habits WHERE name=?", (name,)).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"habit_define failed: {e}")


def habit_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all defined habits."""
    try:
        rows = _conn().execute(
            "SELECT * FROM habits ORDER BY name ASC"
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"habit_list failed: {e}")


def habit_complete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Log a habit completion now."""
    key = args.get("name_or_id")
    if key is None:
        return _err("name_or_id is required")
    habit = _resolve_habit(key)
    if habit is None:
        return _err(f"no habit matching {key!r}")
    notes = args.get("notes")
    try:
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                "INSERT INTO habit_completions (habit_id, notes) VALUES (?, ?)",
                (habit["id"], notes),
            )
            c.commit()
            new_id = cur.lastrowid
        row = c.execute(
            "SELECT * FROM habit_completions WHERE id=?", (new_id,)
        ).fetchone()
        return _ok({"habit": habit, "completion": _row(row)})
    except Exception as e:
        return _err(f"habit_complete failed: {e}")


def habit_streak(args: Dict[str, Any]) -> Dict[str, Any]:
    """Current consecutive-day streak for a habit. Today counts only if
    completed today; otherwise streak is measured up through yesterday."""
    key = args.get("name_or_id")
    if key is None:
        return _err("name_or_id is required")
    habit = _resolve_habit(key)
    if habit is None:
        return _err(f"no habit matching {key!r}")
    try:
        rows = _conn().execute(
            "SELECT completed_at FROM habit_completions WHERE habit_id=? ORDER BY completed_at DESC",
            (habit["id"],),
        ).fetchall()
        days_done = set()
        for r in rows:
            days_done.add(date.fromtimestamp(r["completed_at"]).isoformat())
        if not days_done:
            return _ok({"habit": habit["name"], "streak_days": 0})
        today = date.today()
        # Start at today if done today, else yesterday.
        cursor = today if today.isoformat() in days_done else today - timedelta(days=1)
        streak = 0
        while cursor.isoformat() in days_done:
            streak += 1
            cursor -= timedelta(days=1)
        return _ok({"habit": habit["name"], "streak_days": streak})
    except Exception as e:
        return _err(f"habit_streak failed: {e}")


def habit_weekly_progress(args: Dict[str, Any]) -> Dict[str, Any]:
    """Completions this week vs target."""
    key = args.get("name_or_id")
    if key is None:
        return _err("name_or_id is required")
    habit = _resolve_habit(key)
    if habit is None:
        return _err(f"no habit matching {key!r}")
    monday, sunday = _week_bounds()
    start = datetime.combine(monday, datetime.min.time()).timestamp()
    end = datetime.combine(sunday + timedelta(days=1), datetime.min.time()).timestamp()
    try:
        n = _conn().execute(
            """SELECT COUNT(DISTINCT date(completed_at,'unixepoch','localtime')) as n
               FROM habit_completions
               WHERE habit_id=? AND completed_at >= ? AND completed_at < ?""",
            (habit["id"], start, end),
        ).fetchone()["n"]
        target = habit["target_frequency_per_week"] or 7
        return _ok(
            {
                "habit": habit["name"],
                "completions_this_week": int(n),
                "target": target,
                "pct": round(100.0 * n / target, 1) if target else 0.0,
                "week_start": monday.isoformat(),
            }
        )
    except Exception as e:
        return _err(f"habit_weekly_progress failed: {e}")


def habit_all_progress(args: Dict[str, Any]) -> Dict[str, Any]:
    """Weekly progress summary across all habits."""
    try:
        habits = _conn().execute(
            "SELECT * FROM habits ORDER BY name ASC"
        ).fetchall()
        out = []
        for h in habits:
            res = habit_weekly_progress({"name_or_id": h["id"]})
            if res.get("ok"):
                streak = habit_streak({"name_or_id": h["id"]})
                payload = res["result"]
                if streak.get("ok"):
                    payload["streak_days"] = streak["result"]["streak_days"]
                out.append(payload)
        return _ok(out)
    except Exception as e:
        return _err(f"habit_all_progress failed: {e}")


# ──────────────────────────────────────────────────────────────────────────
# TIME TRACKING
# ──────────────────────────────────────────────────────────────────────────


def _active_time_entry() -> Optional[Dict[str, Any]]:
    r = _conn().execute(
        "SELECT * FROM time_entries WHERE ended_at IS NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return _row(r)


def time_start(args: Dict[str, Any]) -> Dict[str, Any]:
    """Start a timer. Auto-stops any currently-running timer first."""
    project = (args.get("project") or "").strip()
    if not project:
        return _err("project is required")
    description = args.get("description")
    tags = _normalize_tags(args.get("tags"))
    try:
        # Auto-stop existing
        existing = _active_time_entry()
        if existing:
            time_stop({})
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                """INSERT INTO time_entries (project, description, started_at, tags)
                   VALUES (?, ?, ?, ?)""",
                (project, description, time.time(), tags),
            )
            c.commit()
            new_id = cur.lastrowid
        row = c.execute("SELECT * FROM time_entries WHERE id=?", (new_id,)).fetchone()
        return _ok({"started": _row(row), "auto_stopped_previous": bool(existing)})
    except Exception as e:
        return _err(f"time_start failed: {e}")


def time_stop(args: Dict[str, Any]) -> Dict[str, Any]:
    """Stop the active timer."""
    try:
        active = _active_time_entry()
        if not active:
            return _err("no active timer")
        now = time.time()
        duration = now - (active["started_at"] or now)
        c = _conn()
        with _DB_LOCK:
            c.execute(
                "UPDATE time_entries SET ended_at=?, duration_seconds=? WHERE id=?",
                (now, duration, active["id"]),
            )
            c.commit()
        row = c.execute(
            "SELECT * FROM time_entries WHERE id=?", (active["id"],)
        ).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"time_stop failed: {e}")


def time_current(args: Dict[str, Any]) -> Dict[str, Any]:
    """What's running right now and how long it's been."""
    try:
        active = _active_time_entry()
        if not active:
            return _ok({"running": False})
        elapsed = time.time() - (active["started_at"] or time.time())
        return _ok(
            {
                "running": True,
                "entry": active,
                "elapsed_seconds": round(elapsed, 1),
                "elapsed_minutes": round(elapsed / 60.0, 2),
            }
        )
    except Exception as e:
        return _err(f"time_current failed: {e}")


def time_list_recent(args: Dict[str, Any]) -> Dict[str, Any]:
    """Most recent time entries."""
    limit = int(args.get("limit") or 20)
    try:
        rows = _conn().execute(
            "SELECT * FROM time_entries ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"time_list_recent failed: {e}")


def _bucket_time(start_ts: float, end_ts: float) -> Dict[str, float]:
    rows = _conn().execute(
        """SELECT project, started_at, ended_at, duration_seconds
           FROM time_entries
           WHERE started_at < ? AND (ended_at IS NULL OR ended_at >= ?)""",
        (end_ts, start_ts),
    ).fetchall()
    totals: Dict[str, float] = {}
    now = time.time()
    for r in rows:
        s = max(r["started_at"] or 0, start_ts)
        e = min(r["ended_at"] or now, end_ts)
        if e > s:
            totals[r["project"] or "(none)"] = totals.get(r["project"] or "(none)", 0.0) + (e - s)
    return totals


def time_daily_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """Per-project time totals for a date (default today)."""
    date_str = args.get("date")
    try:
        d = date.fromisoformat(date_str) if date_str else date.today()
    except Exception:
        return _err("date must be ISO YYYY-MM-DD")
    start = datetime.combine(d, datetime.min.time()).timestamp()
    end = start + 86400
    try:
        totals = _bucket_time(start, end)
        return _ok(
            {
                "date": d.isoformat(),
                "by_project_seconds": {k: round(v, 1) for k, v in totals.items()},
                "by_project_minutes": {k: round(v / 60.0, 1) for k, v in totals.items()},
                "total_seconds": round(sum(totals.values()), 1),
                "total_minutes": round(sum(totals.values()) / 60.0, 1),
            }
        )
    except Exception as e:
        return _err(f"time_daily_summary failed: {e}")


def time_weekly_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """Per-project time totals for the current week (Mon–Sun)."""
    monday, sunday = _week_bounds()
    start = datetime.combine(monday, datetime.min.time()).timestamp()
    end = datetime.combine(sunday + timedelta(days=1), datetime.min.time()).timestamp()
    try:
        totals = _bucket_time(start, end)
        return _ok(
            {
                "week_start": monday.isoformat(),
                "week_end": sunday.isoformat(),
                "by_project_seconds": {k: round(v, 1) for k, v in totals.items()},
                "by_project_hours": {k: round(v / 3600.0, 2) for k, v in totals.items()},
                "total_hours": round(sum(totals.values()) / 3600.0, 2),
            }
        )
    except Exception as e:
        return _err(f"time_weekly_summary failed: {e}")


# ──────────────────────────────────────────────────────────────────────────
# POMODORO
# ──────────────────────────────────────────────────────────────────────────


def _active_pomodoro() -> Optional[Dict[str, Any]]:
    r = _conn().execute(
        "SELECT * FROM pomodoros WHERE ended_at IS NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return _row(r)


def pomodoro_start(args: Dict[str, Any]) -> Dict[str, Any]:
    """Start a pomodoro. Default 25 min. Best-effort presence status update."""
    label = (args.get("label") or "").strip() or "focus"
    duration_minutes = float(args.get("duration_minutes") or 25)
    if duration_minutes <= 0:
        return _err("duration_minutes must be > 0")
    try:
        # Cancel any existing
        existing = _active_pomodoro()
        if existing:
            pomodoro_cancel({})
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                """INSERT INTO pomodoros (label, started_at, duration_seconds, completed)
                   VALUES (?, ?, ?, 0)""",
                (label, time.time(), duration_minutes * 60.0),
            )
            c.commit()
            new_id = cur.lastrowid
        row = c.execute("SELECT * FROM pomodoros WHERE id=?", (new_id,)).fetchone()
        _presence_try(
            "set_status_message",
            {"message": f"Pomodoro: {label} ({int(duration_minutes)}m)"},
        )
        return _ok(_row(row))
    except Exception as e:
        return _err(f"pomodoro_start failed: {e}")


def pomodoro_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Active pomodoro state + remaining seconds."""
    try:
        active = _active_pomodoro()
        if not active:
            return _ok({"running": False})
        elapsed = time.time() - (active["started_at"] or time.time())
        remaining = (active["duration_seconds"] or 0) - elapsed
        return _ok(
            {
                "running": True,
                "pomodoro": active,
                "elapsed_seconds": round(elapsed, 1),
                "remaining_seconds": round(remaining, 1),
                "remaining_minutes": round(remaining / 60.0, 2),
                "overrun": remaining < 0,
            }
        )
    except Exception as e:
        return _err(f"pomodoro_status failed: {e}")


def pomodoro_cancel(args: Dict[str, Any]) -> Dict[str, Any]:
    """Abort current pomodoro (marks ended_at but completed=0)."""
    try:
        active = _active_pomodoro()
        if not active:
            return _err("no active pomodoro")
        now = time.time()
        c = _conn()
        with _DB_LOCK:
            c.execute(
                "UPDATE pomodoros SET ended_at=?, completed=0 WHERE id=?",
                (now, active["id"]),
            )
            c.commit()
        row = c.execute(
            "SELECT * FROM pomodoros WHERE id=?", (active["id"],)
        ).fetchone()
        _presence_try("set_status_message", {"message": ""})
        return _ok(_row(row))
    except Exception as e:
        return _err(f"pomodoro_cancel failed: {e}")


def pomodoro_complete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Mark current pomodoro complete and play success chime."""
    try:
        active = _active_pomodoro()
        if not active:
            return _err("no active pomodoro")
        now = time.time()
        c = _conn()
        with _DB_LOCK:
            c.execute(
                "UPDATE pomodoros SET ended_at=?, completed=1 WHERE id=?",
                (now, active["id"]),
            )
            c.commit()
        row = c.execute(
            "SELECT * FROM pomodoros WHERE id=?", (active["id"],)
        ).fetchone()
        _presence_try("play_chime", {"sound": "success"})
        _presence_try("set_status_message", {"message": ""})
        return _ok(_row(row))
    except Exception as e:
        return _err(f"pomodoro_complete failed: {e}")


def pomodoro_history(args: Dict[str, Any]) -> Dict[str, Any]:
    """Recent pomodoros."""
    limit = int(args.get("limit") or 20)
    try:
        rows = _conn().execute(
            "SELECT * FROM pomodoros ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"pomodoro_history failed: {e}")


# ──────────────────────────────────────────────────────────────────────────
# FOCUS BLOCKS
# ──────────────────────────────────────────────────────────────────────────


def _active_focus_block() -> Optional[Dict[str, Any]]:
    r = _conn().execute(
        "SELECT * FROM focus_blocks WHERE ended_at IS NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return _row(r)


def focus_start(args: Dict[str, Any]) -> Dict[str, Any]:
    """Start a longer focus block. Default 90 min."""
    label = (args.get("label") or "").strip() or "deep work"
    duration_minutes = float(args.get("duration_minutes") or 90)
    if duration_minutes <= 0:
        return _err("duration_minutes must be > 0")
    try:
        existing = _active_focus_block()
        if existing:
            focus_end({})
        c = _conn()
        with _DB_LOCK:
            cur = c.execute(
                """INSERT INTO focus_blocks
                   (label, started_at, planned_duration_seconds, distractions_count)
                   VALUES (?, ?, ?, 0)""",
                (label, time.time(), duration_minutes * 60.0),
            )
            c.commit()
            new_id = cur.lastrowid
        row = c.execute(
            "SELECT * FROM focus_blocks WHERE id=?", (new_id,)
        ).fetchone()
        _presence_try(
            "set_status_message",
            {"message": f"Focus block: {label} ({int(duration_minutes)}m)"},
        )
        return _ok(_row(row))
    except Exception as e:
        return _err(f"focus_start failed: {e}")


def focus_distraction(args: Dict[str, Any]) -> Dict[str, Any]:
    """Increment distraction counter on the current focus block."""
    try:
        active = _active_focus_block()
        if not active:
            return _err("no active focus block")
        c = _conn()
        with _DB_LOCK:
            c.execute(
                "UPDATE focus_blocks SET distractions_count = distractions_count + 1 WHERE id=?",
                (active["id"],),
            )
            c.commit()
        row = c.execute(
            "SELECT * FROM focus_blocks WHERE id=?", (active["id"],)
        ).fetchone()
        return _ok(_row(row))
    except Exception as e:
        return _err(f"focus_distraction failed: {e}")


def focus_end(args: Dict[str, Any]) -> Dict[str, Any]:
    """Close the current focus block."""
    try:
        active = _active_focus_block()
        if not active:
            return _err("no active focus block")
        now = time.time()
        c = _conn()
        with _DB_LOCK:
            c.execute(
                "UPDATE focus_blocks SET ended_at=? WHERE id=?",
                (now, active["id"]),
            )
            c.commit()
        row = c.execute(
            "SELECT * FROM focus_blocks WHERE id=?", (active["id"],)
        ).fetchone()
        _presence_try("set_status_message", {"message": ""})
        return _ok(_row(row))
    except Exception as e:
        return _err(f"focus_end failed: {e}")


def focus_history(args: Dict[str, Any]) -> Dict[str, Any]:
    """Recent focus blocks."""
    limit = int(args.get("limit") or 10)
    try:
        rows = _conn().execute(
            "SELECT * FROM focus_blocks ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return _ok(_rows(rows))
    except Exception as e:
        return _err(f"focus_history failed: {e}")


# ──────────────────────────────────────────────────────────────────────────
# REVIEWS
# ──────────────────────────────────────────────────────────────────────────


def _summarize_moods(entries: List[Dict[str, Any]]) -> Optional[str]:
    moods = [e["mood"] for e in entries if e.get("mood")]
    if not moods:
        return None
    counts: Dict[str, int] = {}
    for m in moods:
        counts[m] = counts.get(m, 0) + 1
    parts = [f"{m}×{n}" for m, n in sorted(counts.items(), key=lambda x: -x[1])]
    return ", ".join(parts)


def review_daily(args: Dict[str, Any]) -> Dict[str, Any]:
    """Composite daily review: tasks completed, habits done, time by project,
    pomodoros, journal mood summary."""
    date_str = args.get("date")
    try:
        d = date.fromisoformat(date_str) if date_str else date.today()
    except Exception:
        return _err("date must be ISO YYYY-MM-DD")
    start = datetime.combine(d, datetime.min.time()).timestamp()
    end = start + 86400
    try:
        c = _conn()
        # Tasks completed
        tasks_done = _rows(
            c.execute(
                "SELECT * FROM tasks WHERE completed_at >= ? AND completed_at < ? ORDER BY completed_at ASC",
                (start, end),
            ).fetchall()
        )
        # Habits completed today
        habits_done = _rows(
            c.execute(
                """SELECT habit_completions.*, habits.name as habit_name
                   FROM habit_completions JOIN habits ON habits.id = habit_completions.habit_id
                   WHERE completed_at >= ? AND completed_at < ?
                   ORDER BY completed_at ASC""",
                (start, end),
            ).fetchall()
        )
        # Time by project
        time_buckets = _bucket_time(start, end)
        # Pomodoros
        pomos = _rows(
            c.execute(
                """SELECT * FROM pomodoros
                   WHERE started_at >= ? AND started_at < ?
                   ORDER BY started_at ASC""",
                (start, end),
            ).fetchall()
        )
        pomos_completed = sum(1 for p in pomos if p["completed"])
        # Focus blocks
        focuses = _rows(
            c.execute(
                """SELECT * FROM focus_blocks
                   WHERE started_at >= ? AND started_at < ?
                   ORDER BY started_at ASC""",
                (start, end),
            ).fetchall()
        )
        # Journal
        journal_entries = _rows(
            c.execute(
                "SELECT * FROM journal WHERE created_at >= ? AND created_at < ? ORDER BY created_at ASC",
                (start, end),
            ).fetchall()
        )
        return _ok(
            {
                "date": d.isoformat(),
                "tasks_completed_count": len(tasks_done),
                "tasks_completed": tasks_done,
                "habits_completed_count": len(habits_done),
                "habits_completed": habits_done,
                "time_by_project_minutes": {
                    k: round(v / 60.0, 1) for k, v in time_buckets.items()
                },
                "total_tracked_minutes": round(sum(time_buckets.values()) / 60.0, 1),
                "pomodoros_started": len(pomos),
                "pomodoros_completed": pomos_completed,
                "focus_blocks": len(focuses),
                "focus_distractions": sum(f["distractions_count"] or 0 for f in focuses),
                "journal_entry_count": len(journal_entries),
                "mood_summary": _summarize_moods(journal_entries),
            }
        )
    except Exception as e:
        return _err(f"review_daily failed: {e}")


def review_weekly(args: Dict[str, Any]) -> Dict[str, Any]:
    """Composite weekly review for the current week (Mon–Sun)."""
    monday, sunday = _week_bounds()
    start = datetime.combine(monday, datetime.min.time()).timestamp()
    end = datetime.combine(sunday + timedelta(days=1), datetime.min.time()).timestamp()
    try:
        c = _conn()
        tasks_done = _rows(
            c.execute(
                "SELECT * FROM tasks WHERE completed_at >= ? AND completed_at < ? ORDER BY completed_at ASC",
                (start, end),
            ).fetchall()
        )
        habits_done = _rows(
            c.execute(
                """SELECT habit_completions.*, habits.name as habit_name
                   FROM habit_completions JOIN habits ON habits.id = habit_completions.habit_id
                   WHERE completed_at >= ? AND completed_at < ?
                   ORDER BY completed_at ASC""",
                (start, end),
            ).fetchall()
        )
        time_buckets = _bucket_time(start, end)
        pomos = _rows(
            c.execute(
                "SELECT * FROM pomodoros WHERE started_at >= ? AND started_at < ?",
                (start, end),
            ).fetchall()
        )
        pomos_completed = sum(1 for p in pomos if p["completed"])
        focuses = _rows(
            c.execute(
                "SELECT * FROM focus_blocks WHERE started_at >= ? AND started_at < ?",
                (start, end),
            ).fetchall()
        )
        journal_entries = _rows(
            c.execute(
                "SELECT * FROM journal WHERE created_at >= ? AND created_at < ?",
                (start, end),
            ).fetchall()
        )
        # Habit weekly progress
        habit_rows = c.execute("SELECT * FROM habits ORDER BY name ASC").fetchall()
        habit_progress = []
        for h in habit_rows:
            res = habit_weekly_progress({"name_or_id": h["id"]})
            if res.get("ok"):
                habit_progress.append(res["result"])
        return _ok(
            {
                "week_start": monday.isoformat(),
                "week_end": sunday.isoformat(),
                "tasks_completed_count": len(tasks_done),
                "tasks_completed": tasks_done,
                "habit_progress": habit_progress,
                "habit_completions_count": len(habits_done),
                "time_by_project_hours": {
                    k: round(v / 3600.0, 2) for k, v in time_buckets.items()
                },
                "total_tracked_hours": round(sum(time_buckets.values()) / 3600.0, 2),
                "pomodoros_started": len(pomos),
                "pomodoros_completed": pomos_completed,
                "focus_blocks": len(focuses),
                "focus_distractions": sum(f["distractions_count"] or 0 for f in focuses),
                "journal_entry_count": len(journal_entries),
                "mood_summary": _summarize_moods(journal_entries),
            }
        )
    except Exception as e:
        return _err(f"review_weekly failed: {e}")


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS EXPORT
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # tasks
    "task.add": task_add,
    "task.list": task_list,
    "task.complete": task_complete,
    "task.reopen": task_reopen,
    "task.delete": task_delete,
    "task.update": task_update,
    "task.search": task_search,
    "task.today": task_today,
    "task.this_week": task_this_week,
    "task.summary": task_summary,
    # journal
    "journal.entry_add": journal_entry_add,
    "journal.entry_list": journal_entry_list,
    "journal.entry_search": journal_entry_search,
    "journal.today_summary": journal_today_summary,
    "journal.this_week_digest": journal_this_week_digest,
    # habits
    "habit.define": habit_define,
    "habit.list": habit_list,
    "habit.complete": habit_complete,
    "habit.streak": habit_streak,
    "habit.weekly_progress": habit_weekly_progress,
    "habit.all_progress": habit_all_progress,
    # time tracking
    "time.start": time_start,
    "time.stop": time_stop,
    "time.current": time_current,
    "time.list_recent": time_list_recent,
    "time.daily_summary": time_daily_summary,
    "time.weekly_summary": time_weekly_summary,
    # pomodoro
    "pomodoro.start": pomodoro_start,
    "pomodoro.status": pomodoro_status,
    "pomodoro.cancel": pomodoro_cancel,
    "pomodoro.complete": pomodoro_complete,
    "pomodoro.history": pomodoro_history,
    # focus blocks
    "focus.start": focus_start,
    "focus.distraction": focus_distraction,
    "focus.end": focus_end,
    "focus.history": focus_history,
    # reviews
    "review.daily": review_daily,
    "review.weekly": review_weekly,
}
