"""email_power.py — Leon's deep email tooling.

Three surfaces in one module:

  1. Gmail API (deep)   — OAuth, full message/thread CRUD, labels, filters,
                          attachments. Token read from the OpenClaw OAuth
                          store (`~/.openclaw/google-oauth/tokens.json`) and
                          auto-refreshed via `credentials.json`, or from the
                          `GMAIL_ACCESS_TOKEN` env var.
  2. Smart triage       — heuristic inbox classification, thread summaries,
                          unanswered-thread detection, sender analysis,
                          cleanup suggestions. Optional Anthropic API for
                          richer summaries / reply drafts.
  3. Generic IMAP/SMTP  — works with any provider (Fastmail, Proton Bridge,
                          Migadu, …) via env IMAP_HOST/IMAP_USER/IMAP_PASSWORD
                          and SMTP_HOST/SMTP_USER/SMTP_PASSWORD.

Every tool follows the brain-wide contract: a single `dict` argument in,
`{"ok": bool, ...}` out, and **nothing ever raises** — exceptions are wrapped
into `{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `email.gmail_inbox`) to
callables. Import that dict from the responder / MCP server to register
everything in one shot.

Credentials read:
  - GMAIL_ACCESS_TOKEN          (optional — overrides the OAuth store)
  - OpenClaw OAuth store        ~/.openclaw/google-oauth/{tokens,credentials}.json
  - IMAP_HOST / IMAP_USER / IMAP_PASSWORD   [+ IMAP_PORT, default 993]
  - SMTP_HOST / SMTP_USER / SMTP_PASSWORD   [+ SMTP_PORT, default 587]
  - ANTHROPIC_API_KEY           (optional — enables AI summaries / drafts)
  - DEAN_EMAIL                  (optional — used by find_unanswered)

Risk tags (for the responder's confirmation layer) are declared in
`EXTRA_TOOLS_RISK` — HIGH for anything that sends or destroys, MEDIUM for
anything that mutates state (drafts, labels, archive), unset = low/read-only.
"""

from __future__ import annotations

import base64
import email
import email.utils
import imaplib
import json
import mimetypes
import os
import re
import smtplib
import ssl
import time
from collections import Counter
from email.header import decode_header, make_header
from email.message import EmailMessage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests


# ──────────────────────────────────────────────────────────────────────────
# CONSTANTS / ENVELOPES
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 15.0
_GMAIL_API = "https://gmail.googleapis.com/gmail/v1"
_GOOGLE_OAUTH_DIR = Path.home() / ".openclaw" / "google-oauth"
_TOKENS_PATH = _GOOGLE_OAUTH_DIR / "tokens.json"
_CREDS_PATH = _GOOGLE_OAUTH_DIR / "credentials.json"
_TOKEN_URI = "https://oauth2.googleapis.com/token"

# in-process cache so we don't hammer the token-refresh endpoint
_TOKEN_CACHE: Dict[str, Any] = {"access_token": None, "expiry": 0.0}


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _fail(msg: str) -> Dict[str, Any]:
    """Plain failure envelope for expected (non-exception) errors."""
    return {"ok": False, "error": msg}


def _arg(args: dict, key: str, default: Any = None) -> Any:
    """Defensive arg getter — treats non-dict input as empty."""
    if not isinstance(args, dict):
        return default
    return args.get(key, default)


# ──────────────────────────────────────────────────────────────────────────
# GMAIL — OAUTH TOKEN HANDLING
# ──────────────────────────────────────────────────────────────────────────

def _gmail_token() -> Tuple[Optional[str], Optional[str]]:
    """Return `(access_token, error)`.

    Resolution order:
      1. `GMAIL_ACCESS_TOKEN` env var (used verbatim, no refresh).
      2. In-process cache, if still valid (>60s headroom).
      3. The OpenClaw OAuth store — refreshed if expired and a refresh token
         + client credentials are available.

    Exactly one of the two return slots is non-None.
    """
    env_tok = os.environ.get("GMAIL_ACCESS_TOKEN")
    if env_tok:
        return env_tok.strip(), None

    now = time.time()
    cached = _TOKEN_CACHE.get("access_token")
    if cached and _TOKEN_CACHE.get("expiry", 0.0) - 60 > now:
        return cached, None

    if not _TOKENS_PATH.exists():
        return None, (
            "Gmail not authorized — no token. Set GMAIL_ACCESS_TOKEN env var, "
            f"or run `openclaw-mcp auth:google` to create {_TOKENS_PATH}."
        )

    try:
        tokens = json.loads(_TOKENS_PATH.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        return None, f"could not read token store {_TOKENS_PATH}: {e}"

    access = tokens.get("access_token")
    refresh = tokens.get("refresh_token")
    # google-auth stores expiry_date in ms; treat anything large as ms.
    expiry = tokens.get("expiry_date") or 0
    try:
        expiry = float(expiry)
        if expiry > 1e12:
            expiry /= 1000.0
    except Exception:  # noqa: BLE001
        expiry = 0.0

    if access and expiry - 60 > now:
        _TOKEN_CACHE["access_token"] = access
        _TOKEN_CACHE["expiry"] = expiry
        return access, None

    # token expired (or no expiry recorded) — try a refresh
    if not refresh:
        if access:
            # no way to refresh, but we have *something* — let the caller try
            return access, None
        return None, "Gmail token expired and no refresh_token available."

    refreshed, rerr = _gmail_refresh(refresh)
    if rerr:
        # Do NOT silently fall back to the expired access token — that just
        # produces a cryptic Gmail-API 401 downstream and hides the real
        # cause. Surface the refresh failure so Leon (and Dean) see that a
        # re-auth is needed. (Found 2026-06-13: a dead refresh token was
        # masked as a 401 because the stale token got returned here.)
        return None, (f"Gmail re-authorization needed — token refresh failed: "
                      f"{rerr}. Re-run the Google auth flow.")
    return refreshed, None


def _gmail_refresh(refresh_token: str) -> Tuple[Optional[str], Optional[str]]:
    """Exchange a refresh token for a fresh access token; persist it back."""
    if not _CREDS_PATH.exists():
        return None, (
            f"cannot refresh Gmail token — missing {_CREDS_PATH}. "
            "Re-run `openclaw-mcp auth:google`."
        )
    try:
        creds = json.loads(_CREDS_PATH.read_text(encoding="utf-8"))
        installed = creds.get("installed") or creds.get("web") or {}
        client_id = installed.get("client_id")
        client_secret = installed.get("client_secret")
        token_uri = installed.get("token_uri") or _TOKEN_URI
        if not client_id or not client_secret:
            return None, "credentials.json has no client_id/client_secret."

        resp = requests.post(
            token_uri,
            data={
                "client_id": client_id,
                "client_secret": client_secret,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token",
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if resp.status_code != 200:
            return None, f"token refresh failed ({resp.status_code}): {resp.text[:300]}"
        body = resp.json()
        access = body.get("access_token")
        if not access:
            return None, "token refresh returned no access_token."
        expires_in = float(body.get("expires_in", 3600))
        expiry = time.time() + expires_in

        _TOKEN_CACHE["access_token"] = access
        _TOKEN_CACHE["expiry"] = expiry

        # persist (best-effort) so other processes benefit
        try:
            stored = json.loads(_TOKENS_PATH.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            stored = {}
        stored["access_token"] = access
        stored["expiry_date"] = int(expiry * 1000)
        if body.get("refresh_token"):
            stored["refresh_token"] = body["refresh_token"]
        stored.setdefault("token_type", body.get("token_type", "Bearer"))
        try:
            _TOKENS_PATH.write_text(json.dumps(stored, indent=2), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass  # cache still holds it for this process
        return access, None
    except Exception as e:  # noqa: BLE001
        return None, f"{type(e).__name__}: {e}"


def _gmail_headers() -> Tuple[Optional[Dict[str, str]], Optional[Dict[str, Any]]]:
    """Build auth headers; second slot is an error envelope when unavailable."""
    tok, err = _gmail_token()
    if err:
        return None, _fail(err)
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}, None


def _gmail_req(
    method: str,
    path: str,
    *,
    params: Optional[dict] = None,
    body: Optional[dict] = None,
) -> Dict[str, Any]:
    """Single Gmail API call. Returns `{"ok": True, "data": json}` or an error.

    On a 401 it refreshes the token once and retries — covers the case where
    a cached/env token went stale mid-session.
    """
    headers, herr = _gmail_headers()
    if herr:
        return herr
    url = path if path.startswith("http") else f"{_GMAIL_API}{path}"

    def _do(h: Dict[str, str]) -> requests.Response:
        return requests.request(
            method, url, headers=h, params=params,
            json=body, timeout=_DEFAULT_TIMEOUT,
        )

    try:
        resp = _do(headers)
        if resp.status_code == 401 and not os.environ.get("GMAIL_ACCESS_TOKEN"):
            # force a refresh and retry once
            _TOKEN_CACHE["expiry"] = 0.0
            headers, herr = _gmail_headers()
            if herr:
                return herr
            resp = _do(headers)
        if resp.status_code >= 400:
            detail = resp.text[:400]
            try:
                j = resp.json()
                detail = j.get("error", {}).get("message", detail)
            except Exception:  # noqa: BLE001
                pass
            return {"ok": False, "error": f"Gmail API {resp.status_code}: {detail}",
                    "status": resp.status_code}
        if resp.status_code == 204 or not resp.content:
            return {"ok": True, "data": {}}
        return {"ok": True, "data": resp.json()}
    except Exception as e:  # noqa: BLE001
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GMAIL — MESSAGE PARSING HELPERS
# ──────────────────────────────────────────────────────────────────────────

def _b64url_decode(data: str) -> bytes:
    """Decode Gmail's URL-safe, unpadded base64."""
    if not data:
        return b""
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii")


def _headers_to_dict(headers: List[dict]) -> Dict[str, str]:
    """Flatten a Gmail payload `headers` array into a case-insensitive-ish map."""
    out: Dict[str, str] = {}
    for h in headers or []:
        name = str(h.get("name", "")).strip()
        if name:
            out[name.lower()] = h.get("value", "")
    return out


def _decode_mime(value: str) -> str:
    """Decode RFC 2047 encoded-word headers (=?utf-8?B?...?=) to plain text."""
    if not value:
        return ""
    try:
        return str(make_header(decode_header(value)))
    except Exception:  # noqa: BLE001
        return value


def _walk_gmail_parts(payload: dict) -> Tuple[str, str, List[dict]]:
    """Walk a Gmail payload tree.

    Returns `(text_body, html_body, attachments)` where attachments is a list
    of `{filename, mimeType, size, attachmentId}` dicts.
    """
    text_parts: List[str] = []
    html_parts: List[str] = []
    attachments: List[dict] = []

    def _recurse(part: dict) -> None:
        mime = part.get("mimeType", "")
        body = part.get("body", {}) or {}
        filename = part.get("filename", "")
        sub_parts = part.get("parts", [])

        if filename:
            attachments.append({
                "filename": filename,
                "mimeType": mime,
                "size": body.get("size", 0),
                "attachmentId": body.get("attachmentId"),
            })
        elif mime == "text/plain" and body.get("data"):
            text_parts.append(_b64url_decode(body["data"]).decode("utf-8", "replace"))
        elif mime == "text/html" and body.get("data"):
            html_parts.append(_b64url_decode(body["data"]).decode("utf-8", "replace"))

        for sp in sub_parts:
            _recurse(sp)

    _recurse(payload or {})
    return "\n".join(text_parts).strip(), "\n".join(html_parts).strip(), attachments


def _html_to_text(html: str) -> str:
    """Crude HTML → text fallback when an email has no plain-text part."""
    if not html:
        return ""
    txt = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
    txt = re.sub(r"(?i)<br\s*/?>", "\n", txt)
    txt = re.sub(r"(?i)</p>", "\n\n", txt)
    txt = re.sub(r"<[^>]+>", " ", txt)
    txt = re.sub(r"&nbsp;", " ", txt)
    txt = re.sub(r"&amp;", "&", txt)
    txt = re.sub(r"&lt;", "<", txt).replace("&gt;", ">").replace("&quot;", '"')
    txt = re.sub(r"[ \t]+", " ", txt)
    txt = re.sub(r"\n\s*\n\s*\n+", "\n\n", txt)
    return txt.strip()


def _message_summary(msg: dict) -> Dict[str, Any]:
    """Condense a Gmail message resource into a UI-friendly summary dict."""
    payload = msg.get("payload", {}) or {}
    hdrs = _headers_to_dict(payload.get("headers", []))
    return {
        "id": msg.get("id"),
        "threadId": msg.get("threadId"),
        "from": _decode_mime(hdrs.get("from", "")),
        "to": _decode_mime(hdrs.get("to", "")),
        "subject": _decode_mime(hdrs.get("subject", "(no subject)")),
        "date": hdrs.get("date", ""),
        "snippet": msg.get("snippet", ""),
        "labelIds": msg.get("labelIds", []),
        "unread": "UNREAD" in (msg.get("labelIds") or []),
    }


def _get_message_raw(message_id: str, fmt: str = "full") -> Dict[str, Any]:
    """Fetch one message resource (format=full|metadata|minimal|raw)."""
    return _gmail_req("GET", f"/users/me/messages/{message_id}",
                      params={"format": fmt})


def _extract_email_addr(value: str) -> str:
    """Pull the bare `addr@domain` out of a `Name <addr@domain>` header."""
    name, addr = email.utils.parseaddr(value or "")
    return (addr or value or "").lower().strip()


# ──────────────────────────────────────────────────────────────────────────
# ANTHROPIC (optional) — used by summary / draft helpers
# ──────────────────────────────────────────────────────────────────────────

def _anthropic_key() -> Optional[str]:
    return os.environ.get("ANTHROPIC_API_KEY") or None


def _anthropic_complete(prompt: str, *, max_tokens: int = 600,
                        system: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    """Call the Anthropic Messages API via the official SDK. Returns `(text, error)`.

    Migrated 2026-06-11 from raw `requests` to the `anthropic` SDK
    (typed errors, automatic 429/5xx retries) and from Haiku to Fable 5 —
    outreach copy is Dean-facing, peak quality is worth it. Fable notes:
    thinking is always on and bills inside max_tokens, so the cap is
    floored at 4000 (it's a ceiling, not a spend — short replies stay
    short). Safety classifiers can decline with stop_reason="refusal" on
    an HTTP 200; those retry once on Opus 4.8.
    """
    key = _anthropic_key()
    if not key:
        return None, "ANTHROPIC_API_KEY not set"
    try:
        import anthropic
    except ImportError as e:
        return None, f"anthropic SDK not installed: {e}"
    try:
        client = anthropic.Anthropic(api_key=key, timeout=120.0)
        kwargs = {
            "model": os.environ.get("EMAIL_AI_MODEL", "claude-fable-5"),
            "max_tokens": max(max_tokens, 4000),
            "messages": [{"role": "user", "content": prompt}],
        }
        if system:
            kwargs["system"] = system
        resp = client.messages.create(**kwargs)
        if getattr(resp, "stop_reason", None) == "refusal":
            kwargs["model"] = "claude-opus-4-8"
            resp = client.messages.create(**kwargs)
            if getattr(resp, "stop_reason", None) == "refusal":
                return None, "model declined the request"
        text = "".join(
            b.text for b in resp.content if getattr(b, "type", "") == "text"
        )
        return text.strip(), None
    except Exception as e:  # noqa: BLE001
        return None, f"{type(e).__name__}: {e}"


# ──────────────────────────────────────────────────────────────────────────
# GMAIL — READ TOOLS
# ──────────────────────────────────────────────────────────────────────────

def _batch_get_summaries(ids: List[str], fmt: str = "metadata") -> List[dict]:
    """Fetch summaries for a list of message ids (sequential, bounded)."""
    out: List[dict] = []
    for mid in ids:
        r = _gmail_req("GET", f"/users/me/messages/{mid}",
                       params={"format": fmt,
                               "metadataHeaders": ["From", "To", "Subject", "Date"]})
        if r.get("ok"):
            out.append(_message_summary(r["data"]))
        else:
            out.append({"id": mid, "error": r.get("error")})
    return out


def _gmail_inbox(args: dict) -> dict:
    """List inbox messages (messages.list + per-message metadata get)."""
    try:
        limit = int(_arg(args, "limit", 20) or 20)
        limit = max(1, min(limit, 100))
        query = _arg(args, "query")
        params: Dict[str, Any] = {"maxResults": limit, "labelIds": ["INBOX"]}
        if query:
            params["q"] = query
        lst = _gmail_req("GET", "/users/me/messages", params=params)
        if not lst.get("ok"):
            return lst
        ids = [m["id"] for m in lst["data"].get("messages", [])]
        msgs = _batch_get_summaries(ids)
        return {"ok": True, "count": len(msgs), "messages": msgs,
                "resultSizeEstimate": lst["data"].get("resultSizeEstimate")}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_search(args: dict) -> dict:
    """Search all mail with Gmail query syntax (e.g. `from:x is:unread`)."""
    try:
        query = str(_arg(args, "query", "") or "").strip()
        if not query:
            return _fail("gmail_search needs a 'query' (Gmail search syntax)")
        limit = max(1, min(int(_arg(args, "limit", 20) or 20), 100))
        lst = _gmail_req("GET", "/users/me/messages",
                         params={"q": query, "maxResults": limit})
        if not lst.get("ok"):
            return lst
        ids = [m["id"] for m in lst["data"].get("messages", [])]
        return {"ok": True, "query": query, "count": len(ids),
                "messages": _batch_get_summaries(ids)}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_read(args: dict) -> dict:
    """Fetch one message with full decoded body + attachment manifest."""
    try:
        mid = str(_arg(args, "message_id", "") or "").strip()
        if not mid:
            return _fail("gmail_read needs a 'message_id'")
        r = _get_message_raw(mid, "full")
        if not r.get("ok"):
            return r
        msg = r["data"]
        payload = msg.get("payload", {}) or {}
        text, html, atts = _walk_gmail_parts(payload)
        if not text and html:
            text = _html_to_text(html)
        summary = _message_summary(msg)
        summary.update({
            "body": text,
            "body_html": html if html else None,
            "attachments": atts,
            "sizeEstimate": msg.get("sizeEstimate"),
        })
        summary["ok"] = True
        return summary
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_thread(args: dict) -> dict:
    """Fetch a whole thread, each message condensed with its decoded body."""
    try:
        tid = str(_arg(args, "thread_id", "") or "").strip()
        if not tid:
            return _fail("gmail_thread needs a 'thread_id'")
        r = _gmail_req("GET", f"/users/me/threads/{tid}", params={"format": "full"})
        if not r.get("ok"):
            return r
        msgs = []
        for m in r["data"].get("messages", []):
            text, html, atts = _walk_gmail_parts(m.get("payload", {}) or {})
            if not text and html:
                text = _html_to_text(html)
            s = _message_summary(m)
            s["body"] = text
            s["attachments"] = atts
            msgs.append(s)
        return {"ok": True, "threadId": tid, "count": len(msgs), "messages": msgs}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_unread_count(args: dict) -> dict:
    """Total unread count (inbox + label totals from the INBOX label)."""
    try:
        r = _gmail_req("GET", "/users/me/labels/INBOX")
        if not r.get("ok"):
            return r
        d = r["data"]
        return {"ok": True,
                "unread": d.get("messagesUnread", 0),
                "total": d.get("messagesTotal", 0),
                "threads_unread": d.get("threadsUnread", 0)}
    except Exception as e:  # noqa: BLE001
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GMAIL — WRITE / MUTATE TOOLS
# ──────────────────────────────────────────────────────────────────────────

def _build_raw_message(to: str, subject: str, body: str, *,
                        cc: Optional[str] = None, bcc: Optional[str] = None,
                        html: bool = False,
                        headers: Optional[Dict[str, str]] = None) -> str:
    """Construct a base64url RFC-822 message for the Gmail send/draft endpoints."""
    msg = EmailMessage()
    msg["To"] = to
    msg["Subject"] = subject
    if cc:
        msg["Cc"] = cc
    if bcc:
        msg["Bcc"] = bcc
    for k, v in (headers or {}).items():
        msg[k] = v
    if html:
        msg.set_content(_html_to_text(body))   # plain-text fallback part
        msg.add_alternative(body, subtype="html")
    else:
        msg.set_content(body)
    return _b64url_encode(msg.as_bytes())


def _gmail_send(args: dict) -> dict:
    """Send an email immediately. HIGH risk."""
    try:
        to = str(_arg(args, "to", "") or "").strip()
        subject = str(_arg(args, "subject", "") or "")
        body = str(_arg(args, "body", "") or "")
        if not to:
            return _fail("gmail_send needs a 'to' recipient")
        raw = _build_raw_message(
            to, subject, body,
            cc=_arg(args, "cc"), bcc=_arg(args, "bcc"),
            html=bool(_arg(args, "html", False)),
        )
        r = _gmail_req("POST", "/users/me/messages/send", body={"raw": raw})
        if not r.get("ok"):
            return r
        return {"ok": True, "sent": True, "id": r["data"].get("id"),
                "threadId": r["data"].get("threadId"), "to": to}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_draft(args: dict) -> dict:
    """Create a draft (does NOT send). MEDIUM risk."""
    try:
        to = str(_arg(args, "to", "") or "").strip()
        if not to:
            return _fail("gmail_draft needs a 'to' recipient")
        raw = _build_raw_message(
            to, str(_arg(args, "subject", "") or ""),
            str(_arg(args, "body", "") or ""),
            cc=_arg(args, "cc"),
            html=bool(_arg(args, "html", False)),
        )
        r = _gmail_req("POST", "/users/me/drafts", body={"message": {"raw": raw}})
        if not r.get("ok"):
            return r
        return {"ok": True, "draft": True, "draftId": r["data"].get("id"),
                "messageId": (r["data"].get("message") or {}).get("id"), "to": to}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_reply(args: dict) -> dict:
    """Create a reply *as a draft* (does not send). MEDIUM risk.

    Threads correctly via In-Reply-To / References and re-uses the original
    Subject (prefixed `Re:`). Set `reply_all` to include the original Cc list.
    """
    try:
        mid = str(_arg(args, "message_id", "") or "").strip()
        body = str(_arg(args, "body", "") or "")
        if not mid:
            return _fail("gmail_reply needs a 'message_id'")
        orig = _get_message_raw(mid, "metadata")
        if not orig.get("ok"):
            return orig
        omsg = orig["data"]
        hdrs = _headers_to_dict((omsg.get("payload", {}) or {}).get("headers", []))

        reply_to = _decode_mime(hdrs.get("reply-to") or hdrs.get("from", ""))
        subject = _decode_mime(hdrs.get("subject", ""))
        if subject and not subject.lower().startswith("re:"):
            subject = f"Re: {subject}"
        msg_id_hdr = hdrs.get("message-id", "")
        refs = (hdrs.get("references", "") + " " + msg_id_hdr).strip()

        cc = None
        if bool(_arg(args, "reply_all", False)):
            cc_parts = [hdrs.get("cc", ""), hdrs.get("to", "")]
            cc = ", ".join(p for p in cc_parts if p) or None

        extra_headers: Dict[str, str] = {}
        if msg_id_hdr:
            extra_headers["In-Reply-To"] = msg_id_hdr
        if refs:
            extra_headers["References"] = refs

        raw = _build_raw_message(reply_to, subject, body, cc=cc,
                                 headers=extra_headers)
        r = _gmail_req("POST", "/users/me/drafts",
                       body={"message": {"raw": raw,
                                         "threadId": omsg.get("threadId")}})
        if not r.get("ok"):
            return r
        return {"ok": True, "draft": True, "reply": True,
                "draftId": r["data"].get("id"),
                "threadId": omsg.get("threadId"), "to": reply_to,
                "note": "created as a draft — not sent"}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_modify(message_id: str, add: Optional[List[str]] = None,
                  remove: Optional[List[str]] = None) -> Dict[str, Any]:
    """Low-level messages.modify wrapper."""
    body: Dict[str, Any] = {}
    if add:
        body["addLabelIds"] = add
    if remove:
        body["removeLabelIds"] = remove
    return _gmail_req("POST", f"/users/me/messages/{message_id}/modify", body=body)


def _gmail_archive(args: dict) -> dict:
    """Remove a message from the inbox (archive). MEDIUM risk."""
    mid = str(_arg(args, "message_id", "") or "").strip()
    if not mid:
        return _fail("gmail_archive needs a 'message_id'")
    r = _gmail_modify(mid, remove=["INBOX"])
    return {"ok": True, "archived": mid} if r.get("ok") else r


def _gmail_trash(args: dict) -> dict:
    """Move a message to Trash. HIGH risk."""
    mid = str(_arg(args, "message_id", "") or "").strip()
    if not mid:
        return _fail("gmail_trash needs a 'message_id'")
    r = _gmail_req("POST", f"/users/me/messages/{mid}/trash")
    return {"ok": True, "trashed": mid} if r.get("ok") else r


def _gmail_mark_read(args: dict) -> dict:
    """Mark a message as read (remove UNREAD label)."""
    mid = str(_arg(args, "message_id", "") or "").strip()
    if not mid:
        return _fail("gmail_mark_read needs a 'message_id'")
    r = _gmail_modify(mid, remove=["UNREAD"])
    return {"ok": True, "message_id": mid, "unread": False} if r.get("ok") else r


def _gmail_mark_unread(args: dict) -> dict:
    """Mark a message as unread (add UNREAD label)."""
    mid = str(_arg(args, "message_id", "") or "").strip()
    if not mid:
        return _fail("gmail_mark_unread needs a 'message_id'")
    r = _gmail_modify(mid, add=["UNREAD"])
    return {"ok": True, "message_id": mid, "unread": True} if r.get("ok") else r


def _gmail_star(args: dict) -> dict:
    """Star a message."""
    mid = str(_arg(args, "message_id", "") or "").strip()
    if not mid:
        return _fail("gmail_star needs a 'message_id'")
    r = _gmail_modify(mid, add=["STARRED"])
    return {"ok": True, "message_id": mid, "starred": True} if r.get("ok") else r


def _gmail_unstar(args: dict) -> dict:
    """Remove the star from a message."""
    mid = str(_arg(args, "message_id", "") or "").strip()
    if not mid:
        return _fail("gmail_unstar needs a 'message_id'")
    r = _gmail_modify(mid, remove=["STARRED"])
    return {"ok": True, "message_id": mid, "starred": False} if r.get("ok") else r


# ──────────────────────────────────────────────────────────────────────────
# GMAIL — LABELS & FILTERS
# ──────────────────────────────────────────────────────────────────────────

def _gmail_labels_list(args: dict) -> dict:
    """List every label on the account."""
    r = _gmail_req("GET", "/users/me/labels")
    if not r.get("ok"):
        return r
    labels = [{"id": l.get("id"), "name": l.get("name"),
               "type": l.get("type")} for l in r["data"].get("labels", [])]
    return {"ok": True, "count": len(labels), "labels": labels}


def _resolve_label_id(name: str) -> Tuple[Optional[str], Optional[str]]:
    """Map a label *name* to its id (case-insensitive). System labels too."""
    r = _gmail_req("GET", "/users/me/labels")
    if not r.get("ok"):
        return None, r.get("error")
    want = name.strip().lower()
    for l in r["data"].get("labels", []):
        if str(l.get("name", "")).lower() == want or str(l.get("id", "")).lower() == want:
            return l.get("id"), None
    return None, None  # not found, but no error


def _gmail_label_create(args: dict) -> dict:
    """Create a new user label. MEDIUM risk."""
    try:
        name = str(_arg(args, "name", "") or "").strip()
        if not name:
            return _fail("gmail_label_create needs a 'name'")
        existing, _ = _resolve_label_id(name)
        if existing:
            return {"ok": True, "labelId": existing, "name": name,
                    "note": "label already existed"}
        r = _gmail_req("POST", "/users/me/labels", body={
            "name": name,
            "labelListVisibility": "labelShow",
            "messageListVisibility": "show",
        })
        if not r.get("ok"):
            return r
        return {"ok": True, "created": True, "labelId": r["data"].get("id"),
                "name": r["data"].get("name")}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_label_add(args: dict) -> dict:
    """Apply a label (by name) to a message — auto-creating it if needed. MEDIUM."""
    try:
        mid = str(_arg(args, "message_id", "") or "").strip()
        label_name = str(_arg(args, "label_name", "") or "").strip()
        if not mid or not label_name:
            return _fail("gmail_label_add needs 'message_id' and 'label_name'")
        lid, lerr = _resolve_label_id(label_name)
        if lerr:
            return _fail(lerr)
        if not lid:
            created = _gmail_label_create({"name": label_name})
            if not created.get("ok"):
                return created
            lid = created["labelId"]
        r = _gmail_modify(mid, add=[lid])
        if not r.get("ok"):
            return r
        return {"ok": True, "message_id": mid, "label": label_name, "labelId": lid}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _gmail_filter_create(args: dict) -> dict:
    """Create a Gmail filter. MEDIUM risk.

    `criteria` — Gmail filter criteria, e.g. `{"from": "x@y.com"}`,
                 `{"subject": "invoice"}`, `{"hasAttachment": true}`.
    `action`   — e.g. `{"addLabelIds": ["Label_5"]}`,
                 `{"removeLabelIds": ["INBOX"]}`. Label *names* in
                 add/removeLabelIds are auto-resolved to ids.
    """
    try:
        criteria = _arg(args, "criteria")
        action = _arg(args, "action")
        if not isinstance(criteria, dict) or not criteria:
            return _fail("gmail_filter_create needs a non-empty 'criteria' dict")
        if not isinstance(action, dict) or not action:
            return _fail("gmail_filter_create needs a non-empty 'action' dict")

        # resolve any label names → ids inside the action
        resolved_action: Dict[str, Any] = dict(action)
        for key in ("addLabelIds", "removeLabelIds"):
            vals = resolved_action.get(key)
            if isinstance(vals, list):
                out = []
                for v in vals:
                    if isinstance(v, str) and not v.startswith(("Label_", "INBOX",
                                                                "SPAM", "TRASH",
                                                                "UNREAD", "STARRED",
                                                                "IMPORTANT",
                                                                "CATEGORY_")):
                        lid, _ = _resolve_label_id(v)
                        out.append(lid or v)
                    else:
                        out.append(v)
                resolved_action[key] = out

        r = _gmail_req("POST", "/users/me/settings/filters",
                       body={"criteria": criteria, "action": resolved_action})
        if not r.get("ok"):
            return r
        return {"ok": True, "created": True, "filterId": r["data"].get("id"),
                "criteria": criteria, "action": resolved_action}
    except Exception as e:  # noqa: BLE001
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GMAIL — ATTACHMENTS
# ──────────────────────────────────────────────────────────────────────────

def _gmail_get_attachment(args: dict) -> dict:
    """Download an attachment to disk.

    `attachment_id` comes from the `attachments` list returned by
    `gmail_read`. `save_to` is an absolute path (a directory is also
    accepted — the filename is then taken from the message).
    """
    try:
        mid = str(_arg(args, "message_id", "") or "").strip()
        aid = str(_arg(args, "attachment_id", "") or "").strip()
        save_to = str(_arg(args, "save_to", "") or "").strip()
        if not mid or not aid or not save_to:
            return _fail("gmail_get_attachment needs 'message_id', "
                         "'attachment_id' and 'save_to'")
        r = _gmail_req("GET",
                       f"/users/me/messages/{mid}/attachments/{aid}")
        if not r.get("ok"):
            return r
        data = r["data"].get("data", "")
        raw = _b64url_decode(data)

        dest = Path(save_to).expanduser()
        if dest.is_dir() or save_to.endswith(os.sep):
            # need a filename — pull it from the message manifest
            fname = "attachment.bin"
            full = _get_message_raw(mid, "full")
            if full.get("ok"):
                _, _, atts = _walk_gmail_parts(full["data"].get("payload", {}) or {})
                for a in atts:
                    if a.get("attachmentId") == aid and a.get("filename"):
                        fname = a["filename"]
                        break
            dest = dest / fname
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
        return {"ok": True, "saved_to": str(dest), "bytes": len(raw)}
    except Exception as e:  # noqa: BLE001
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# SMART TRIAGE
# ──────────────────────────────────────────────────────────────────────────

_URGENT_KEYWORDS = (
    "urgent", "asap", "immediately", "deadline", "overdue", "action required",
    "final notice", "important", "time sensitive", "expires", "expiring",
    "payment failed", "security alert", "suspended", "verify your",
    "last chance", "respond by", "approval needed", "wire", "invoice due",
)
_NEWSLETTER_KEYWORDS = (
    "newsletter", "digest", "weekly", "unsubscribe", "this week in",
    "new post", "promo", "% off", "sale", "deal", "webinar", "no-reply",
    "noreply", "donotreply", "mailchimp", "substack", "marketing",
)
_SPAM_KEYWORDS = (
    "you won", "winner", "claim your prize", "viagra", "crypto giveaway",
    "double your", "act now", "risk-free", "make money fast",
    "congratulations you", "nigerian prince", "100% free", "click here now",
)
_NEWSLETTER_SENDER_HINTS = (
    "no-reply", "noreply", "donotreply", "newsletter", "news@", "info@",
    "updates@", "notifications@", "hello@", "team@", "mailer", "marketing@",
    "digest", "substack.com", "mailchimp", "sendgrid",
)


def _classify_message(summary: dict) -> Tuple[str, str]:
    """Heuristically classify a message. Returns `(category, reason)`.

    Categories: urgent | normal | newsletter | spam.
    """
    subj = (summary.get("subject") or "").lower()
    sender = (summary.get("from") or "").lower()
    snippet = (summary.get("snippet") or "").lower()
    haystack = f"{subj} {snippet}"
    labels = summary.get("labelIds") or []

    if "SPAM" in labels:
        return "spam", "Gmail flagged it as spam"
    for kw in _SPAM_KEYWORDS:
        if kw in haystack:
            return "spam", f"spam phrase: '{kw}'"

    if "CATEGORY_PROMOTIONS" in labels or "CATEGORY_UPDATES" in labels:
        return "newsletter", "Gmail promotions/updates category"
    for hint in _NEWSLETTER_SENDER_HINTS:
        if hint in sender:
            return "newsletter", f"bulk sender pattern: '{hint}'"
    for kw in _NEWSLETTER_KEYWORDS:
        if kw in haystack:
            return "newsletter", f"newsletter keyword: '{kw}'"

    for kw in _URGENT_KEYWORDS:
        if kw in haystack:
            return "urgent", f"urgent keyword: '{kw}'"
    if "IMPORTANT" in labels:
        return "urgent", "Gmail marked it important"
    if subj.startswith("re:") or subj.startswith("fwd:"):
        return "normal", "part of an existing conversation"

    return "normal", "no strong signal — default"


def _triage_inbox(args: dict) -> dict:
    """Classify unread inbox messages into urgent / normal / newsletter / spam."""
    try:
        limit = max(1, min(int(_arg(args, "limit", 30) or 30), 100))
        lst = _gmail_req("GET", "/users/me/messages",
                         params={"maxResults": limit, "q": "is:unread in:inbox"})
        if not lst.get("ok"):
            return lst
        ids = [m["id"] for m in lst["data"].get("messages", [])]
        summaries = _batch_get_summaries(ids)

        buckets: Dict[str, List[dict]] = {
            "urgent": [], "normal": [], "newsletter": [], "spam": []}
        for s in summaries:
            if s.get("error"):
                continue
            cat, reason = _classify_message(s)
            buckets[cat].append({
                "id": s["id"], "from": s["from"], "subject": s["subject"],
                "date": s.get("date"), "reason": reason,
            })
        return {
            "ok": True,
            "scanned": len(summaries),
            "counts": {k: len(v) for k, v in buckets.items()},
            "urgent": buckets["urgent"],
            "normal": buckets["normal"],
            "newsletter": buckets["newsletter"],
            "spam": buckets["spam"],
        }
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _summarize_thread(args: dict) -> dict:
    """Summarize a thread — Anthropic API if a key is set, else a text excerpt."""
    try:
        tid = str(_arg(args, "thread_id", "") or "").strip()
        if not tid:
            return _fail("summarize_thread needs a 'thread_id'")
        thread = _gmail_thread({"thread_id": tid})
        if not thread.get("ok"):
            return thread

        chunks = []
        for m in thread["messages"]:
            chunks.append(
                f"From: {m.get('from')}\nDate: {m.get('date')}\n"
                f"Subject: {m.get('subject')}\n\n{m.get('body', '')[:4000]}"
            )
        full_text = "\n\n--- next message ---\n\n".join(chunks)

        if _anthropic_key():
            text, aerr = _anthropic_complete(
                "Summarize this email thread in 3-5 concise bullet points. "
                "End with a one-line 'Bottom line:' and, if any, a "
                "'Needs reply:' note.\n\n" + full_text[:24000],
                max_tokens=500,
                system="You are an executive assistant. Be terse and factual.",
            )
            if text:
                return {"ok": True, "thread_id": tid, "method": "anthropic",
                        "message_count": len(thread["messages"]),
                        "summary": text}
            # fall through to excerpt if the API failed
        excerpt = full_text[:500].strip()
        return {"ok": True, "thread_id": tid, "method": "excerpt",
                "message_count": len(thread["messages"]),
                "summary": excerpt + ("…" if len(full_text) > 500 else ""),
                "note": "set ANTHROPIC_API_KEY for an AI summary"}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _find_unanswered(args: dict) -> dict:
    """Find threads whose last message is from someone else (you owe a reply).

    Uses `DEAN_EMAIL` to identify Dean's own messages; if unset, the
    authenticated profile address is fetched once.
    """
    try:
        days = max(1, min(int(_arg(args, "days", 7) or 7), 90))
        me = (os.environ.get("DEAN_EMAIL") or "").lower().strip()
        if not me:
            prof = _gmail_req("GET", "/users/me/profile")
            if prof.get("ok"):
                me = str(prof["data"].get("emailAddress", "")).lower()

        q = f"in:inbox newer_than:{days}d -in:chats"
        lst = _gmail_req("GET", "/users/me/threads",
                         params={"q": q, "maxResults": 50})
        if not lst.get("ok"):
            return lst

        unanswered = []
        for t in lst["data"].get("threads", []):
            tid = t.get("id")
            tr = _gmail_req("GET", f"/users/me/threads/{tid}",
                            params={"format": "metadata",
                                    "metadataHeaders": ["From", "Subject", "Date"]})
            if not tr.get("ok"):
                continue
            msgs = tr["data"].get("messages", [])
            if not msgs:
                continue
            last = msgs[-1]
            hdrs = _headers_to_dict((last.get("payload", {}) or {}).get("headers", []))
            last_from = _extract_email_addr(_decode_mime(hdrs.get("from", "")))
            if me and last_from == me:
                continue  # Dean sent the last message — answered
            if "SENT" in (last.get("labelIds") or []):
                continue
            unanswered.append({
                "threadId": tid,
                "last_from": _decode_mime(hdrs.get("from", "")),
                "subject": _decode_mime(hdrs.get("subject", "(no subject)")),
                "date": hdrs.get("date", ""),
                "messages_in_thread": len(msgs),
                "snippet": last.get("snippet", ""),
            })
        return {"ok": True, "days": days, "count": len(unanswered),
                "unanswered": unanswered,
                "note": None if me else "DEAN_EMAIL not set — used profile address"}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _important_senders(args: dict) -> dict:
    """Rank inbox senders by frequency — surfaces who emails Dean most."""
    try:
        limit = max(20, min(int(_arg(args, "limit", 200) or 200), 500))
        lst = _gmail_req("GET", "/users/me/messages",
                         params={"maxResults": limit, "labelIds": ["INBOX"]})
        if not lst.get("ok"):
            return lst
        ids = [m["id"] for m in lst["data"].get("messages", [])]
        counter: Counter = Counter()
        display: Dict[str, str] = {}
        for s in _batch_get_summaries(ids):
            raw_from = s.get("from", "")
            addr = _extract_email_addr(raw_from)
            if addr:
                counter[addr] += 1
                display.setdefault(addr, raw_from)
        top = [{"email": a, "display": display.get(a, a), "count": c}
               for a, c in counter.most_common(25)]
        return {"ok": True, "scanned": len(ids), "unique_senders": len(counter),
                "top_senders": top}
    except Exception as e:  # noqa: BLE001
        return _err(e)


def _cleanup_suggestions(args: dict) -> dict:
    """Suggest archive/cleanup candidates: old newsletters, large attachments."""
    try:
        suggestions: List[dict] = []

        # 1. old promotional / newsletter mail still in inbox
        promo = _gmail_req("GET", "/users/me/messages", params={
            "maxResults": 50,
            "q": "in:inbox (category:promotions OR unsubscribe) older_than:14d",
        })
        if promo.get("ok"):
            ids = [m["id"] for m in promo["data"].get("messages", [])]
            for s in _batch_get_summaries(ids[:30]):
                if s.get("error"):
                    continue
                suggestions.append({
                    "type": "old_newsletter",
                    "id": s["id"], "from": s["from"], "subject": s["subject"],
                    "date": s.get("date"),
                    "action": "archive — promotional mail >14d old",
                })

        # 2. large mail (likely big attachments)
        big = _gmail_req("GET", "/users/me/messages", params={
            "maxResults": 25,
            "q": "in:inbox larger:5M",
        })
        if big.get("ok"):
            ids = [m["id"] for m in big["data"].get("messages", [])]
            for s in _batch_get_summaries(ids[:15]):
                if s.get("error"):
                    continue
                suggestions.append({
                    "type": "large_attachment",
                    "id": s["id"], "from": s["from"], "subject": s["subject"],
                    "date": s.get("date"),
                    "action": "review/archive — >5MB, likely a large attachment",
                })

        # 3. stale unread (>30d, never opened)
        stale = _gmail_req("GET", "/users/me/messages", params={
            "maxResults": 25,
            "q": "in:inbox is:unread older_than:30d",
        })
        if stale.get("ok"):
            ids = [m["id"] for m in stale["data"].get("messages", [])]
            for s in _batch_get_summaries(ids[:15]):
                if s.get("error"):
                    continue
                suggestions.append({
                    "type": "stale_unread",
                    "id": s["id"], "from": s["from"], "subject": s["subject"],
                    "date": s.get("date"),
                    "action": "archive or mark read — unread >30d",
                })

        by_type: Counter = Counter(s["type"] for s in suggestions)
        return {"ok": True, "count": len(suggestions),
                "by_type": dict(by_type), "suggestions": suggestions}
    except Exception as e:  # noqa: BLE001
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# COMPOSE HELPERS
# ──────────────────────────────────────────────────────────────────────────

def _draft_reply_suggestion(args: dict) -> dict:
    """Generate suggested reply text for a message. Does NOT send or draft.

    Needs `ANTHROPIC_API_KEY`. `tone` ∈ professional|friendly|brief|warm|firm.
    """
    try:
        mid = str(_arg(args, "message_id", "") or "").strip()
        if not mid:
            return _fail("draft_reply_suggestion needs a 'message_id'")
        tone = str(_arg(args, "tone", "professional") or "professional").strip()
        if not _anthropic_key():
            return _fail("draft_reply_suggestion needs ANTHROPIC_API_KEY set")

        msg = _gmail_read({"message_id": mid})
        if not msg.get("ok"):
            return msg
        prompt = (
            f"Write a {tone} reply to the email below. Sign off as Dean. "
            "Return only the reply body — no subject line, no preamble.\n\n"
            f"From: {msg.get('from')}\nSubject: {msg.get('subject')}\n\n"
            f"{(msg.get('body') or '')[:8000]}"
        )
        text, aerr = _anthropic_complete(
            prompt, max_tokens=600,
            system=("You draft email replies for Dean Sabr, CEO of "
                    "Sabr. Match the requested tone. Be concise."),
        )
        if aerr:
            return _fail(aerr)
        return {"ok": True, "message_id": mid, "tone": tone,
                "suggested_reply": text,
                "note": "suggestion only — not sent, not saved as a draft"}
    except Exception as e:  # noqa: BLE001
        return _err(e)


_ACTION_PATTERNS = (
    r"(?i)\bplease\s+(?:can you\s+)?([a-z][^.!?\n]{6,140})",
    r"(?i)\bcould you\s+([a-z][^.!?\n]{6,140})",
    r"(?i)\bcan you\s+([a-z][^.!?\n]{6,140})",
    r"(?i)\bwe need (?:you )?to\s+([a-z][^.!?\n]{6,140})",
    r"(?i)\b(?:action required|to-?do|todo|next step)s?\s*[:\-]\s*([^\n]{6,140})",
    r"(?i)\b(?:by|before|due)\s+(?:end of |eod |cob )?[a-z0-9 ,/]{3,40}",
    r"(?i)\blet me know\s+([^.!?\n]{6,140})",
    r"(?i)\bplease (?:confirm|review|send|sign|approve|schedule)\b[^.!?\n]{0,140}",
)


def _extract_action_items(args: dict) -> dict:
    """Pull TODOs / asks / deadlines out of an email body.

    Uses the Anthropic API when available for a clean list; otherwise falls
    back to regex pattern-matching on imperative / request phrasing.
    """
    try:
        mid = str(_arg(args, "message_id", "") or "").strip()
        if not mid:
            return _fail("extract_action_items needs a 'message_id'")
        msg = _gmail_read({"message_id": mid})
        if not msg.get("ok"):
            return msg
        body = msg.get("body") or ""

        if _anthropic_key():
            text, aerr = _anthropic_complete(
                "Extract every concrete action item, request, question, or "
                "deadline aimed at the recipient from this email. Return a "
                "plain bullet list (one per line, starting with '- '). If "
                "there are none, reply exactly 'NONE'.\n\n" + body[:10000],
                max_tokens=400,
                system="You extract actionable items from emails. Be precise.",
            )
            if text:
                if text.strip().upper() == "NONE":
                    items: List[str] = []
                else:
                    items = [ln.lstrip("-• ").strip()
                             for ln in text.splitlines()
                             if ln.strip() and ln.strip().upper() != "NONE"]
                return {"ok": True, "message_id": mid, "method": "anthropic",
                        "count": len(items), "action_items": items}

        # regex fallback
        found: List[str] = []
        seen: set = set()
        for pat in _ACTION_PATTERNS:
            for m in re.finditer(pat, body):
                snippet = m.group(0).strip()
                snippet = re.sub(r"\s+", " ", snippet)
                key = snippet.lower()
                if snippet and key not in seen and len(snippet) > 8:
                    seen.add(key)
                    found.append(snippet)
        return {"ok": True, "message_id": mid, "method": "regex",
                "count": len(found), "action_items": found[:25],
                "note": "set ANTHROPIC_API_KEY for higher-quality extraction"}
    except Exception as e:  # noqa: BLE001
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GENERIC IMAP / SMTP
# ──────────────────────────────────────────────────────────────────────────

def _imap_creds() -> Tuple[Optional[Tuple[str, str, str, int]], Optional[Dict[str, Any]]]:
    """Return `((host, user, password, port), None)` or `(None, error)`."""
    host = os.environ.get("IMAP_HOST")
    user = os.environ.get("IMAP_USER")
    pwd = os.environ.get("IMAP_PASSWORD")
    if not (host and user and pwd):
        return None, _fail(
            "IMAP not configured — set IMAP_HOST, IMAP_USER and "
            "IMAP_PASSWORD env vars (works with Fastmail, Proton Bridge, etc).")
    try:
        port = int(os.environ.get("IMAP_PORT", "993"))
    except Exception:  # noqa: BLE001
        port = 993
    return (host, user, pwd, port), None


def _smtp_creds() -> Tuple[Optional[Tuple[str, str, str, int]], Optional[Dict[str, Any]]]:
    """Return `((host, user, password, port), None)` or `(None, error)`."""
    host = os.environ.get("SMTP_HOST")
    user = os.environ.get("SMTP_USER")
    pwd = os.environ.get("SMTP_PASSWORD")
    if not (host and user and pwd):
        return None, _fail(
            "SMTP not configured — set SMTP_HOST, SMTP_USER and "
            "SMTP_PASSWORD env vars.")
    try:
        port = int(os.environ.get("SMTP_PORT", "587"))
    except Exception:  # noqa: BLE001
        port = 587
    return (host, user, pwd, port), None


def _imap_connect(host: str, user: str, pwd: str, port: int) -> imaplib.IMAP4:
    """Open an authenticated IMAP4 connection (SSL on 993, STARTTLS otherwise)."""
    if port == 993:
        conn: imaplib.IMAP4 = imaplib.IMAP4_SSL(host, port, timeout=_DEFAULT_TIMEOUT)
    else:
        conn = imaplib.IMAP4(host, port, timeout=_DEFAULT_TIMEOUT)
        try:
            conn.starttls(ssl_context=ssl.create_default_context())
        except Exception:  # noqa: BLE001
            pass
    conn.login(user, pwd)
    return conn


def _decode_imap_part(msg: email.message.Message) -> Tuple[str, List[str]]:
    """Return `(best_text_body, attachment_filenames)` for a parsed message."""
    text = ""
    html = ""
    atts: List[str] = []
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            disp = str(part.get("Content-Disposition") or "")
            if "attachment" in disp.lower():
                fname = part.get_filename()
                if fname:
                    atts.append(_decode_mime(fname))
                continue
            try:
                payload = part.get_payload(decode=True)
            except Exception:  # noqa: BLE001
                payload = None
            if not payload:
                continue
            charset = part.get_content_charset() or "utf-8"
            decoded = payload.decode(charset, "replace")
            if ctype == "text/plain" and not text:
                text = decoded
            elif ctype == "text/html" and not html:
                html = decoded
    else:
        try:
            payload = msg.get_payload(decode=True)
            charset = msg.get_content_charset() or "utf-8"
            decoded = (payload or b"").decode(charset, "replace")
        except Exception:  # noqa: BLE001
            decoded = ""
        if msg.get_content_type() == "text/html":
            html = decoded
        else:
            text = decoded
    if not text and html:
        text = _html_to_text(html)
    return text.strip(), atts


def _imap_envelope(msg: email.message.Message, uid: Optional[str] = None) -> dict:
    """Build a summary dict from a parsed IMAP message's headers."""
    return {
        "uid": uid,
        "from": _decode_mime(msg.get("From", "")),
        "to": _decode_mime(msg.get("To", "")),
        "subject": _decode_mime(msg.get("Subject", "(no subject)")),
        "date": msg.get("Date", ""),
        "message_id": msg.get("Message-ID", ""),
    }


def _imap_fetch_summaries(conn: imaplib.IMAP4, uids: List[bytes]) -> List[dict]:
    """Fetch header-only summaries for a list of UIDs."""
    out: List[dict] = []
    for uid in uids:
        uid_s = uid.decode() if isinstance(uid, bytes) else str(uid)
        typ, data = conn.uid("FETCH", uid_s,
                             "(BODY.PEEK[HEADER.FIELDS (FROM TO SUBJECT DATE MESSAGE-ID)])")
        if typ != "OK" or not data or not data[0]:
            continue
        raw = data[0][1]
        if isinstance(raw, bytes):
            parsed = email.message_from_bytes(raw)
            out.append(_imap_envelope(parsed, uid_s))
    return out


def _imap_inbox(args: dict) -> dict:
    """List the most recent messages in an IMAP folder."""
    creds, cerr = _imap_creds()
    if cerr:
        return cerr
    host, user, pwd, port = creds
    folder = str(_arg(args, "folder", "INBOX") or "INBOX")
    limit = max(1, min(int(_arg(args, "limit", 20) or 20), 100))
    conn = None
    try:
        conn = _imap_connect(host, user, pwd, port)
        typ, _ = conn.select(folder, readonly=True)
        if typ != "OK":
            return _fail(f"could not open folder '{folder}'")
        typ, data = conn.uid("SEARCH", None, "ALL")
        if typ != "OK":
            return _fail("IMAP SEARCH failed")
        uids = data[0].split()
        recent = uids[-limit:][::-1]
        return {"ok": True, "folder": folder, "total": len(uids),
                "count": len(recent),
                "messages": _imap_fetch_summaries(conn, recent)}
    except Exception as e:  # noqa: BLE001
        return _err(e)
    finally:
        if conn is not None:
            try:
                conn.logout()
            except Exception:  # noqa: BLE001
                pass


def _imap_search(args: dict) -> dict:
    """Search an IMAP folder.

    `query` may be a raw IMAP search string (e.g. `FROM "x@y.com" UNSEEN`) or
    plain text — plain text is wrapped as a TEXT search automatically.
    """
    creds, cerr = _imap_creds()
    if cerr:
        return cerr
    host, user, pwd, port = creds
    folder = str(_arg(args, "folder", "INBOX") or "INBOX")
    limit = max(1, min(int(_arg(args, "limit", 20) or 20), 100))
    query = str(_arg(args, "query", "") or "").strip()
    if not query:
        return _fail("imap_search needs a 'query'")
    conn = None
    try:
        conn = _imap_connect(host, user, pwd, port)
        typ, _ = conn.select(folder, readonly=True)
        if typ != "OK":
            return _fail(f"could not open folder '{folder}'")
        # decide raw vs. plain-text query
        imap_keywords = ("FROM", "TO", "SUBJECT", "BODY", "TEXT", "SINCE",
                         "BEFORE", "UNSEEN", "SEEN", "ALL", "FLAGGED",
                         "ANSWERED", "HEADER", "OR", "NOT")
        first_word = query.split(" ", 1)[0].upper()
        if first_word in imap_keywords:
            typ, data = conn.uid("SEARCH", None, query)
        else:
            typ, data = conn.uid("SEARCH", None, "TEXT", f'"{query}"')
        if typ != "OK":
            return _fail(f"IMAP SEARCH failed for query: {query}")
        uids = data[0].split()
        hits = uids[-limit:][::-1]
        return {"ok": True, "folder": folder, "query": query,
                "count": len(hits),
                "messages": _imap_fetch_summaries(conn, hits)}
    except Exception as e:  # noqa: BLE001
        return _err(e)
    finally:
        if conn is not None:
            try:
                conn.logout()
            except Exception:  # noqa: BLE001
                pass


def _imap_read(args: dict) -> dict:
    """Fetch one IMAP message by UID with full decoded body + attachment list."""
    creds, cerr = _imap_creds()
    if cerr:
        return cerr
    host, user, pwd, port = creds
    folder = str(_arg(args, "folder", "INBOX") or "INBOX")
    uid = str(_arg(args, "uid", "") or "").strip()
    if not uid:
        return _fail("imap_read needs a 'uid'")
    conn = None
    try:
        conn = _imap_connect(host, user, pwd, port)
        typ, _ = conn.select(folder, readonly=True)
        if typ != "OK":
            return _fail(f"could not open folder '{folder}'")
        typ, data = conn.uid("FETCH", uid, "(RFC822)")
        if typ != "OK" or not data or not data[0]:
            return _fail(f"message uid {uid} not found in '{folder}'")
        raw = data[0][1]
        if not isinstance(raw, bytes):
            return _fail("unexpected IMAP FETCH payload")
        parsed = email.message_from_bytes(raw)
        body, atts = _decode_imap_part(parsed)
        env = _imap_envelope(parsed, uid)
        env.update({"ok": True, "folder": folder, "body": body,
                    "attachments": atts})
        return env
    except Exception as e:  # noqa: BLE001
        return _err(e)
    finally:
        if conn is not None:
            try:
                conn.logout()
            except Exception:  # noqa: BLE001
                pass


def _smtp_send(args: dict) -> dict:
    """Send an email through a generic SMTP server. HIGH risk."""
    creds, cerr = _smtp_creds()
    if cerr:
        return cerr
    host, user, pwd, port = creds
    to = str(_arg(args, "to", "") or "").strip()
    if not to:
        return _fail("smtp_send needs a 'to' recipient")
    subject = str(_arg(args, "subject", "") or "")
    body = str(_arg(args, "body", "") or "")
    cc = _arg(args, "cc")
    is_html = bool(_arg(args, "html", False))
    from_addr = os.environ.get("SMTP_FROM", user)

    server = None
    try:
        if is_html:
            msg: email.message.Message = MIMEMultipart("alternative")
            msg.attach(MIMEText(_html_to_text(body), "plain", "utf-8"))
            msg.attach(MIMEText(body, "html", "utf-8"))
        else:
            msg = MIMEText(body, "plain", "utf-8")
        msg["From"] = from_addr
        msg["To"] = to
        msg["Subject"] = subject
        if cc:
            msg["Cc"] = cc

        recipients = [a.strip() for a in to.split(",") if a.strip()]
        if cc:
            recipients += [a.strip() for a in str(cc).split(",") if a.strip()]

        if port == 465:
            server = smtplib.SMTP_SSL(host, port, timeout=_DEFAULT_TIMEOUT)
        else:
            server = smtplib.SMTP(host, port, timeout=_DEFAULT_TIMEOUT)
            server.ehlo()
            try:
                server.starttls(context=ssl.create_default_context())
                server.ehlo()
            except Exception:  # noqa: BLE001
                pass
        server.login(user, pwd)
        server.sendmail(from_addr, recipients, msg.as_string())
        return {"ok": True, "sent": True, "to": to, "via": f"{host}:{port}"}
    except Exception as e:  # noqa: BLE001
        return _err(e)
    finally:
        if server is not None:
            try:
                server.quit()
            except Exception:  # noqa: BLE001
                pass


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Gmail — read
    "email.gmail_inbox": _gmail_inbox,
    "email.gmail_search": _gmail_search,
    "email.gmail_read": _gmail_read,
    "email.gmail_thread": _gmail_thread,
    "email.gmail_unread_count": _gmail_unread_count,
    # Gmail — write / mutate
    "email.gmail_send": _gmail_send,
    "email.gmail_draft": _gmail_draft,
    "email.gmail_reply": _gmail_reply,
    "email.gmail_archive": _gmail_archive,
    "email.gmail_trash": _gmail_trash,
    "email.gmail_mark_read": _gmail_mark_read,
    "email.gmail_mark_unread": _gmail_mark_unread,
    "email.gmail_star": _gmail_star,
    "email.gmail_unstar": _gmail_unstar,
    # Gmail — labels & filters
    "email.gmail_labels_list": _gmail_labels_list,
    "email.gmail_label_add": _gmail_label_add,
    "email.gmail_label_create": _gmail_label_create,
    "email.gmail_filter_create": _gmail_filter_create,
    # Gmail — attachments
    "email.gmail_get_attachment": _gmail_get_attachment,
    # Smart triage
    "email.triage_inbox": _triage_inbox,
    "email.summarize_thread": _summarize_thread,
    "email.find_unanswered": _find_unanswered,
    "email.important_senders": _important_senders,
    "email.cleanup_suggestions": _cleanup_suggestions,
    # Generic IMAP / SMTP
    "email.imap_inbox": _imap_inbox,
    "email.imap_search": _imap_search,
    "email.imap_read": _imap_read,
    "email.smtp_send": _smtp_send,
    # Compose helpers
    "email.draft_reply_suggestion": _draft_reply_suggestion,
    "email.extract_action_items": _extract_action_items,
}

# Risk tags for the responder's confirmation layer.
# Anything that sends mail or destroys data is HIGH; state mutations are
# MEDIUM; everything else is read-only (omitted = low risk).
EXTRA_TOOLS_RISK: Dict[str, str] = {
    "email.gmail_send": "HIGH",
    "email.gmail_trash": "HIGH",
    "email.smtp_send": "HIGH",
    "email.gmail_draft": "MEDIUM",
    "email.gmail_reply": "MEDIUM",
    "email.gmail_archive": "MEDIUM",
    "email.gmail_label_add": "MEDIUM",
    "email.gmail_label_create": "MEDIUM",
    "email.gmail_filter_create": "MEDIUM",
}


if __name__ == "__main__":  # pragma: no cover — quick manual smoke test
    print(f"email_power: {len(EXTRA_TOOLS)} tools registered")
    for name in sorted(EXTRA_TOOLS):
        risk = EXTRA_TOOLS_RISK.get(name, "")
        print(f"  {name:40s} {risk}")
