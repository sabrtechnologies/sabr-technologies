"""
video_production.py — Leon's video/audio production integration.

ffmpeg-based video & audio editing, OBS Studio control (obs-websocket v5),
GIF/clip creation, and subtitle generation.

All tools return {"ok": bool, ...} and never raise.
ffmpeg/ffprobe are shelled out; missing binaries are reported gracefully.
OBS control needs OBS_WEBSOCKET_PASSWORD env var (port 4455) and the
`websocket-client` package (lazy-imported).

Outputs land in ~/Documents/leon-video/.
Input paths are restricted to ~/Desktop, ~/Documents, ~/Downloads, ~/Videos
and the project's brain_state/ directory.
"""

import os
import json
import shutil
import base64
import hashlib
import hmac
import subprocess
import tempfile
import datetime
from pathlib import Path

# ----------------------------------------------------------------------------
# Constants / setup
# ----------------------------------------------------------------------------

HOME = Path.home()
OUTPUT_DIR = HOME / "Documents" / "leon-video"

# project brain_state dir (this file lives at brain/integrations/)
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_BRAIN_STATE = _PROJECT_ROOT / "brain_state"

# allowed input roots
_ALLOWED_ROOTS = [
    HOME / "Desktop",
    HOME / "Documents",
    HOME / "Downloads",
    HOME / "Videos",
    _BRAIN_STATE,
]

OBS_HOST = "localhost"
OBS_PORT = 4455

# auto-create output dir on import
try:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def _ffmpeg_bin():
    """Return path to ffmpeg or None."""
    return shutil.which("ffmpeg")


def _ffprobe_bin():
    """Return path to ffprobe or None."""
    return shutil.which("ffprobe")


def _have_ffmpeg():
    return _ffmpeg_bin() is not None


def _check_ffmpeg():
    """Return None if ffmpeg available, else an error dict."""
    if not _have_ffmpeg():
        return {"ok": False, "error": "ffmpeg not installed"}
    return None


def _check_ffprobe():
    if not _ffprobe_bin():
        return {"ok": False, "error": "ffmpeg not installed (ffprobe missing)"}
    return None


def _resolve_input(path):
    """
    Resolve and validate an input path against the allowed roots.
    Returns (Path, None) on success or (None, error_dict) on failure.
    """
    try:
        p = Path(os.path.expanduser(str(path))).resolve()
    except Exception as e:
        return None, {"ok": False, "error": f"bad path: {e}"}
    if not p.exists():
        return None, {"ok": False, "error": f"file not found: {p}"}
    for root in _ALLOWED_ROOTS:
        try:
            root_r = root.resolve()
        except Exception:
            continue
        try:
            p.relative_to(root_r)
            return p, None
        except ValueError:
            continue
    return None, {
        "ok": False,
        "error": f"path not allowed: {p} (must be under Desktop/Documents/"
                 f"Downloads/Videos/brain_state)",
    }


def _resolve_inputs(paths):
    """Resolve a list of input paths. Returns (list[Path], None) or (None, err)."""
    if not paths or not isinstance(paths, (list, tuple)):
        return None, {"ok": False, "error": "expected a non-empty list of paths"}
    resolved = []
    for raw in paths:
        p, err = _resolve_input(raw)
        if err:
            return None, err
        resolved.append(p)
    return resolved, None


def _stamp():
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


def _out_path(src, suffix, ext=None, explicit=None):
    """
    Build an output path inside OUTPUT_DIR.
    If `explicit` is given it is used verbatim (under OUTPUT_DIR if relative).
    """
    if explicit:
        ep = Path(os.path.expanduser(str(explicit)))
        if not ep.is_absolute():
            ep = OUTPUT_DIR / ep
        ep.parent.mkdir(parents=True, exist_ok=True)
        return ep
    src = Path(src)
    stem = src.stem
    use_ext = ext if ext else src.suffix.lstrip(".")
    name = f"{stem}-{suffix}-{_stamp()}.{use_ext}"
    return OUTPUT_DIR / name


def _run(cmd, timeout=900):
    """
    Run a command list. Returns (ok, stdout, stderr) — never raises.
    """
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )
        out = proc.stdout.decode("utf-8", "replace")
        err = proc.stderr.decode("utf-8", "replace")
        return proc.returncode == 0, out, err
    except subprocess.TimeoutExpired:
        return False, "", "command timed out"
    except FileNotFoundError as e:
        return False, "", f"binary not found: {e}"
    except Exception as e:
        return False, "", str(e)


def _ffmpeg_run(args, output_path, timeout=900):
    """
    Run `ffmpeg -y <args>`. On success return result dict with output path/size.
    """
    chk = _check_ffmpeg()
    if chk:
        return chk
    cmd = [_ffmpeg_bin(), "-y", "-hide_banner", "-loglevel", "error"] + list(args)
    ok, out, err = _run(cmd, timeout=timeout)
    if not ok:
        return {"ok": False, "error": (err or out or "ffmpeg failed").strip()[:600]}
    op = Path(output_path)
    if not op.exists():
        return {"ok": False, "error": "ffmpeg ran but produced no output",
                "stderr": err.strip()[:400]}
    return {
        "ok": True,
        "output": str(op),
        "size_mb": round(op.stat().st_size / (1024 * 1024), 2),
    }


def _probe(path):
    """Run ffprobe on a path. Returns (dict, None) or (None, error_dict)."""
    chk = _check_ffprobe()
    if chk:
        return None, chk
    cmd = [
        _ffprobe_bin(), "-v", "quiet", "-print_format", "json",
        "-show_format", "-show_streams", str(path),
    ]
    ok, out, err = _run(cmd, timeout=60)
    if not ok:
        return None, {"ok": False, "error": (err or "ffprobe failed").strip()[:400]}
    try:
        return json.loads(out), None
    except Exception as e:
        return None, {"ok": False, "error": f"could not parse ffprobe output: {e}"}


def _duration(path):
    """Return float duration in seconds or None."""
    data, err = _probe(path)
    if err:
        return None
    try:
        return float(data.get("format", {}).get("duration"))
    except (TypeError, ValueError):
        return None


def _fps_from_stream(stream):
    """Parse a video stream's frame rate into a float."""
    rate = stream.get("avg_frame_rate") or stream.get("r_frame_rate") or "0/0"
    try:
        num, den = rate.split("/")
        num, den = float(num), float(den)
        return round(num / den, 3) if den else 0.0
    except Exception:
        return 0.0


# ----------------------------------------------------------------------------
# OBS helpers (obs-websocket v5)
# ----------------------------------------------------------------------------

def _obs_password():
    return os.environ.get("OBS_WEBSOCKET_PASSWORD", "")


class _OBSConn:
    """Minimal obs-websocket v5 client over websocket-client."""

    def __init__(self, ws):
        self.ws = ws
        self._id = 0

    def _next_id(self):
        self._id += 1
        return str(self._id)

    def request(self, request_type, request_data=None, timeout=10):
        """Send an op6 request, return the responseData dict."""
        rid = self._next_id()
        payload = {
            "op": 6,
            "d": {
                "requestType": request_type,
                "requestId": rid,
                "requestData": request_data or {},
            },
        }
        self.ws.send(json.dumps(payload))
        # read until we get the matching op7 response
        for _ in range(50):
            raw = self.ws.recv()
            if not raw:
                continue
            msg = json.loads(raw)
            if msg.get("op") == 7 and msg.get("d", {}).get("requestId") == rid:
                d = msg["d"]
                status = d.get("requestStatus", {})
                if not status.get("result"):
                    raise RuntimeError(
                        status.get("comment") or f"OBS request {request_type} failed"
                    )
                return d.get("responseData", {}) or {}
        raise RuntimeError("no matching OBS response received")

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass


def _obs_connect():
    """
    Connect + authenticate to obs-websocket v5.
    Returns (_OBSConn, None) or (None, error_dict).
    """
    try:
        import websocket  # websocket-client
    except ImportError:
        return None, {
            "ok": False,
            "error": "websocket-client not installed (pip install websocket-client)",
        }

    url = f"ws://{OBS_HOST}:{OBS_PORT}"
    try:
        ws = websocket.create_connection(url, timeout=8)
    except Exception as e:
        return None, {
            "ok": False,
            "error": f"could not connect to OBS at {url} "
                     f"(is OBS running with obs-websocket enabled?): {e}",
        }

    try:
        # Hello (op 0)
        hello = json.loads(ws.recv())
        d = hello.get("d", {})
        auth = d.get("authentication")

        identify = {"op": 1, "d": {"rpcVersion": d.get("rpcVersion", 1)}}

        if auth:
            password = _obs_password()
            if not password:
                ws.close()
                return None, {
                    "ok": False,
                    "error": "OBS requires auth but OBS_WEBSOCKET_PASSWORD is not set",
                }
            challenge = auth["challenge"]
            salt = auth["salt"]
            secret = base64.b64encode(
                hashlib.sha256((password + salt).encode()).digest()
            ).decode()
            auth_resp = base64.b64encode(
                hashlib.sha256((secret + challenge).encode()).digest()
            ).decode()
            identify["d"]["authentication"] = auth_resp

        ws.send(json.dumps(identify))
        # Identified (op 2)
        ident = json.loads(ws.recv())
        if ident.get("op") != 2:
            ws.close()
            return None, {"ok": False, "error": "OBS did not acknowledge identify"}
    except Exception as e:
        try:
            ws.close()
        except Exception:
            pass
        return None, {"ok": False, "error": f"OBS handshake failed: {e}"}

    return _OBSConn(ws), None


def _obs_do(fn):
    """Connect, run fn(conn), close, wrap errors."""
    conn, err = _obs_connect()
    if err:
        return err
    try:
        result = fn(conn)
    except Exception as e:
        conn.close()
        return {"ok": False, "error": f"OBS error: {e}"}
    conn.close()
    return result


# ============================================================================
# ffmpeg editing tools
# ============================================================================

def video_info(path):
    """ffprobe summary: duration, codec, resolution, fps, bitrate."""
    p, err = _resolve_input(path)
    if err:
        return err
    data, perr = _probe(p)
    if perr:
        return perr
    fmt = data.get("format", {})
    streams = data.get("streams", [])
    vstream = next((s for s in streams if s.get("codec_type") == "video"), None)
    astream = next((s for s in streams if s.get("codec_type") == "audio"), None)

    info = {
        "ok": True,
        "path": str(p),
        "duration_sec": round(float(fmt["duration"]), 2) if fmt.get("duration") else None,
        "size_mb": round(int(fmt["size"]) / (1024 * 1024), 2) if fmt.get("size") else None,
        "bitrate_kbps": round(int(fmt["bit_rate"]) / 1000) if fmt.get("bit_rate") else None,
        "format": fmt.get("format_name"),
    }
    if vstream:
        info["video_codec"] = vstream.get("codec_name")
        info["resolution"] = f"{vstream.get('width')}x{vstream.get('height')}"
        info["width"] = vstream.get("width")
        info["height"] = vstream.get("height")
        info["fps"] = _fps_from_stream(vstream)
    if astream:
        info["audio_codec"] = astream.get("codec_name")
        info["sample_rate"] = astream.get("sample_rate")
        info["channels"] = astream.get("channels")
    return info


def video_trim(path, start_sec, end_sec, output_path=None):
    """Cut a clip from start_sec to end_sec."""
    p, err = _resolve_input(path)
    if err:
        return err
    try:
        start = float(start_sec)
        end = float(end_sec)
    except (TypeError, ValueError):
        return {"ok": False, "error": "start_sec and end_sec must be numbers"}
    if end <= start:
        return {"ok": False, "error": "end_sec must be greater than start_sec"}
    out = _out_path(p, "trim", explicit=output_path)
    return _ffmpeg_run(
        ["-ss", str(start), "-to", str(end), "-i", str(p),
         "-c", "copy", str(out)],
        out,
    )


def video_concat(paths, output_path=None):
    """Join multiple clips end-to-end (re-encoded for safety)."""
    inputs, err = _resolve_inputs(paths)
    if err:
        return err
    if len(inputs) < 2:
        return {"ok": False, "error": "need at least 2 clips to concat"}
    out = _out_path(inputs[0], "concat", explicit=output_path)

    args = []
    for ip in inputs:
        args += ["-i", str(ip)]
    n = len(inputs)
    streams = "".join(f"[{i}:v:0][{i}:a:0]" for i in range(n))
    filt = f"{streams}concat=n={n}:v=1:a=1[v][a]"
    args += ["-filter_complex", filt, "-map", "[v]", "-map", "[a]", str(out)]
    return _ffmpeg_run(args, out)


def video_compress(path, target_mb=None, crf=28, output_path=None):
    """Compress a video. If target_mb given, target a bitrate; else use CRF."""
    p, err = _resolve_input(path)
    if err:
        return err
    out = _out_path(p, "compressed", ext="mp4", explicit=output_path)

    if target_mb:
        try:
            target_mb = float(target_mb)
        except (TypeError, ValueError):
            return {"ok": False, "error": "target_mb must be a number"}
        dur = _duration(p)
        if not dur or dur <= 0:
            return {"ok": False, "error": "could not determine duration for target_mb"}
        # leave ~128k for audio
        total_kbps = (target_mb * 8192) / dur
        audio_kbps = 128
        video_kbps = max(100, total_kbps - audio_kbps)
        return _ffmpeg_run(
            ["-i", str(p), "-c:v", "libx264", "-b:v", f"{int(video_kbps)}k",
             "-c:a", "aac", "-b:a", f"{audio_kbps}k", "-preset", "medium",
             str(out)],
            out,
        )
    return _ffmpeg_run(
        ["-i", str(p), "-c:v", "libx264", "-crf", str(int(crf)),
         "-preset", "medium", "-c:a", "aac", "-b:a", "128k", str(out)],
        out,
    )


def video_resize(path, width, height=None, output_path=None):
    """Resize a video. height=None keeps aspect ratio (-1)."""
    p, err = _resolve_input(path)
    if err:
        return err
    try:
        w = int(width)
    except (TypeError, ValueError):
        return {"ok": False, "error": "width must be an integer"}
    h = "-2" if height is None else str(int(height))
    out = _out_path(p, f"{w}w", explicit=output_path)
    return _ffmpeg_run(
        ["-i", str(p), "-vf", f"scale={w}:{h}", "-c:a", "copy", str(out)],
        out,
    )


def video_to_gif(path, start_sec=0, duration_sec=5, fps=12, width=480, output_path=None):
    """Make an animated GIF from a clip (two-pass palette for quality)."""
    p, err = _resolve_input(path)
    if err:
        return err
    chk = _check_ffmpeg()
    if chk:
        return chk
    try:
        start = float(start_sec)
        dur = float(duration_sec)
        fps = int(fps)
        width = int(width)
    except (TypeError, ValueError):
        return {"ok": False, "error": "start_sec/duration_sec/fps/width must be numbers"}
    out = _out_path(p, "gif", ext="gif", explicit=output_path)

    palette = Path(tempfile.gettempdir()) / f"leon-gifpal-{_stamp()}.png"
    vf = f"fps={fps},scale={width}:-1:flags=lanczos"
    # pass 1: palette
    r1 = _ffmpeg_run(
        ["-ss", str(start), "-t", str(dur), "-i", str(p),
         "-vf", f"{vf},palettegen", str(palette)],
        palette,
    )
    if not r1.get("ok"):
        return r1
    # pass 2: render
    r2 = _ffmpeg_run(
        ["-ss", str(start), "-t", str(dur), "-i", str(p), "-i", str(palette),
         "-filter_complex", f"{vf}[x];[x][1:v]paletteuse", str(out)],
        out,
    )
    try:
        palette.unlink()
    except Exception:
        pass
    return r2


def video_extract_audio(path, output_path=None, fmt="mp3"):
    """Extract the audio track into a separate file."""
    p, err = _resolve_input(path)
    if err:
        return err
    fmt = (fmt or "mp3").lstrip(".")
    out = _out_path(p, "audio", ext=fmt, explicit=output_path)
    codec = {"mp3": "libmp3lame", "wav": "pcm_s16le", "aac": "aac",
             "m4a": "aac", "flac": "flac", "ogg": "libvorbis"}.get(fmt, "libmp3lame")
    return _ffmpeg_run(
        ["-i", str(p), "-vn", "-acodec", codec, str(out)],
        out,
    )


def video_extract_frames(path, fps=1, output_dir=None):
    """Save every Nth frame as PNG (fps frames per second)."""
    p, err = _resolve_input(path)
    if err:
        return err
    chk = _check_ffmpeg()
    if chk:
        return chk
    try:
        fps = float(fps)
    except (TypeError, ValueError):
        return {"ok": False, "error": "fps must be a number"}
    if output_dir:
        odir = Path(os.path.expanduser(str(output_dir)))
        if not odir.is_absolute():
            odir = OUTPUT_DIR / odir
    else:
        odir = OUTPUT_DIR / f"{p.stem}-frames-{_stamp()}"
    odir.mkdir(parents=True, exist_ok=True)
    pattern = str(odir / "frame-%05d.png")

    cmd = [_ffmpeg_bin(), "-y", "-hide_banner", "-loglevel", "error",
           "-i", str(p), "-vf", f"fps={fps}", pattern]
    ok, out, errtxt = _run(cmd)
    if not ok:
        return {"ok": False, "error": (errtxt or "ffmpeg failed").strip()[:400]}
    frames = sorted(odir.glob("frame-*.png"))
    return {
        "ok": True,
        "output_dir": str(odir),
        "frame_count": len(frames),
    }


def video_thumbnail(path, time_sec=2, output_path=None):
    """Grab a single still frame as a thumbnail PNG."""
    p, err = _resolve_input(path)
    if err:
        return err
    try:
        t = float(time_sec)
    except (TypeError, ValueError):
        return {"ok": False, "error": "time_sec must be a number"}
    out = _out_path(p, "thumb", ext="png", explicit=output_path)
    return _ffmpeg_run(
        ["-ss", str(t), "-i", str(p), "-vframes", "1", str(out)],
        out,
    )


def video_speed(path, multiplier=2.0, output_path=None):
    """Speed up (>1) or slow down (<1) a video including audio."""
    p, err = _resolve_input(path)
    if err:
        return err
    try:
        m = float(multiplier)
    except (TypeError, ValueError):
        return {"ok": False, "error": "multiplier must be a number"}
    if m <= 0:
        return {"ok": False, "error": "multiplier must be positive"}
    out = _out_path(p, f"{m}x", explicit=output_path)

    # video: setpts = 1/m ; audio: atempo (chained, each must be 0.5-2.0)
    vfilter = f"setpts={1.0 / m:.6f}*PTS"
    remaining = m
    atempo_parts = []
    while remaining > 2.0:
        atempo_parts.append("atempo=2.0")
        remaining /= 2.0
    while remaining < 0.5:
        atempo_parts.append("atempo=0.5")
        remaining /= 0.5
    atempo_parts.append(f"atempo={remaining:.6f}")
    afilter = ",".join(atempo_parts)

    return _ffmpeg_run(
        ["-i", str(p),
         "-filter_complex", f"[0:v]{vfilter}[v];[0:a]{afilter}[a]",
         "-map", "[v]", "-map", "[a]", str(out)],
        out,
    )


def video_rotate(path, degrees=90, output_path=None):
    """Rotate a video by 90/180/270 degrees."""
    p, err = _resolve_input(path)
    if err:
        return err
    try:
        deg = int(degrees) % 360
    except (TypeError, ValueError):
        return {"ok": False, "error": "degrees must be an integer"}
    transpose = {
        90: "transpose=1",
        180: "transpose=1,transpose=1",
        270: "transpose=2",
        0: None,
    }.get(deg)
    if transpose is None and deg != 0:
        return {"ok": False, "error": "degrees must be one of 0, 90, 180, 270"}
    out = _out_path(p, f"rot{deg}", explicit=output_path)
    if deg == 0:
        return {"ok": False, "error": "0 degrees is a no-op"}
    return _ffmpeg_run(
        ["-i", str(p), "-vf", transpose, "-c:a", "copy", str(out)],
        out,
    )


def video_add_watermark(path, watermark_image, position="bottom-right", output_path=None):
    """Overlay a watermark image onto a video."""
    p, err = _resolve_input(path)
    if err:
        return err
    wm, werr = _resolve_input(watermark_image)
    if werr:
        return {"ok": False, "error": f"watermark: {werr.get('error')}"}
    pos = {
        "top-left": "10:10",
        "top-right": "W-w-10:10",
        "bottom-left": "10:H-h-10",
        "bottom-right": "W-w-10:H-h-10",
        "center": "(W-w)/2:(H-h)/2",
    }.get(position)
    if pos is None:
        return {"ok": False, "error": "position must be top/bottom-left/right or center"}
    out = _out_path(p, "watermark", explicit=output_path)
    return _ffmpeg_run(
        ["-i", str(p), "-i", str(wm),
         "-filter_complex", f"overlay={pos}",
         "-c:a", "copy", str(out)],
        out,
    )


def video_crop(path, x, y, w, h, output_path=None):
    """Crop a rectangular region (x,y top-left, w x h)."""
    p, err = _resolve_input(path)
    if err:
        return err
    try:
        x, y, w, h = int(x), int(y), int(w), int(h)
    except (TypeError, ValueError):
        return {"ok": False, "error": "x, y, w, h must be integers"}
    if w <= 0 or h <= 0:
        return {"ok": False, "error": "w and h must be positive"}
    out = _out_path(p, "crop", explicit=output_path)
    return _ffmpeg_run(
        ["-i", str(p), "-vf", f"crop={w}:{h}:{x}:{y}", "-c:a", "copy", str(out)],
        out,
    )


def video_merge_audio(video_path, audio_path, output_path=None):
    """Replace/add an audio track onto a video."""
    v, verr = _resolve_input(video_path)
    if verr:
        return verr
    a, aerr = _resolve_input(audio_path)
    if aerr:
        return {"ok": False, "error": f"audio: {aerr.get('error')}"}
    out = _out_path(v, "audiomerge", explicit=output_path)
    return _ffmpeg_run(
        ["-i", str(v), "-i", str(a),
         "-map", "0:v:0", "-map", "1:a:0",
         "-c:v", "copy", "-c:a", "aac", "-shortest", str(out)],
        out,
    )


def video_fade(path, fade_in_sec=1, fade_out_sec=1, output_path=None):
    """Add a fade-in at the start and fade-out at the end (video + audio)."""
    p, err = _resolve_input(path)
    if err:
        return err
    try:
        fin = float(fade_in_sec)
        fout = float(fade_out_sec)
    except (TypeError, ValueError):
        return {"ok": False, "error": "fade_in_sec/fade_out_sec must be numbers"}
    dur = _duration(p)
    if not dur or dur <= 0:
        return {"ok": False, "error": "could not determine duration"}
    out_start = max(0.0, dur - fout)

    vf = []
    af = []
    if fin > 0:
        vf.append(f"fade=t=in:st=0:d={fin}")
        af.append(f"afade=t=in:st=0:d={fin}")
    if fout > 0:
        vf.append(f"fade=t=out:st={out_start:.3f}:d={fout}")
        af.append(f"afade=t=out:st={out_start:.3f}:d={fout}")
    if not vf:
        return {"ok": False, "error": "at least one fade must be > 0"}
    out = _out_path(p, "fade", explicit=output_path)
    return _ffmpeg_run(
        ["-i", str(p), "-vf", ",".join(vf), "-af", ",".join(af),
         "-c:a", "aac", str(out)],
        out,
    )


def video_screenshot_grid(path, rows=3, cols=3, output_path=None):
    """Build a contact-sheet of evenly spaced frames."""
    p, err = _resolve_input(path)
    if err:
        return err
    chk = _check_ffmpeg()
    if chk:
        return chk
    try:
        rows = int(rows)
        cols = int(cols)
    except (TypeError, ValueError):
        return {"ok": False, "error": "rows and cols must be integers"}
    if rows < 1 or cols < 1:
        return {"ok": False, "error": "rows and cols must be >= 1"}
    dur = _duration(p)
    if not dur or dur <= 0:
        return {"ok": False, "error": "could not determine duration"}
    total = rows * cols
    # one frame every (dur/total) seconds
    interval = dur / total
    fps = 1.0 / interval if interval > 0 else 1.0
    out = _out_path(p, "grid", ext="png", explicit=output_path)
    vf = f"fps={fps:.6f},scale=320:-1,tile={cols}x{rows}"
    return _ffmpeg_run(
        ["-i", str(p), "-vf", vf, "-frames:v", "1", str(out)],
        out,
    )


# ============================================================================
# Audio tools
# ============================================================================

def audio_normalize(path, output_path=None):
    """Normalize loudness with the EBU R128 loudnorm filter."""
    p, err = _resolve_input(path)
    if err:
        return err
    out = _out_path(p, "normalized", explicit=output_path)
    return _ffmpeg_run(
        ["-i", str(p), "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", str(out)],
        out,
    )


def audio_trim_silence(path, output_path=None):
    """Remove leading/trailing silence (and long internal gaps)."""
    p, err = _resolve_input(path)
    if err:
        return err
    out = _out_path(p, "desilenced", explicit=output_path)
    sr = ("silenceremove=start_periods=1:start_duration=0.3:start_threshold=-40dB:"
          "stop_periods=-1:stop_duration=0.3:stop_threshold=-40dB")
    return _ffmpeg_run(
        ["-i", str(p), "-af", sr, str(out)],
        out,
    )


def audio_to_mp3(path, output_path=None, bitrate="192k"):
    """Convert any audio (or video's audio) to MP3."""
    p, err = _resolve_input(path)
    if err:
        return err
    out = _out_path(p, "mp3", ext="mp3", explicit=output_path)
    return _ffmpeg_run(
        ["-i", str(p), "-vn", "-acodec", "libmp3lame", "-b:a", str(bitrate),
         str(out)],
        out,
    )


def audio_concat(paths, output_path=None):
    """Join multiple audio files end-to-end."""
    inputs, err = _resolve_inputs(paths)
    if err:
        return err
    if len(inputs) < 2:
        return {"ok": False, "error": "need at least 2 audio files to concat"}
    out = _out_path(inputs[0], "audioconcat", ext="mp3", explicit=output_path)
    args = []
    for ip in inputs:
        args += ["-i", str(ip)]
    n = len(inputs)
    streams = "".join(f"[{i}:a:0]" for i in range(n))
    filt = f"{streams}concat=n={n}:v=0:a=1[a]"
    args += ["-filter_complex", filt, "-map", "[a]", str(out)]
    return _ffmpeg_run(args, out)


# ============================================================================
# Subtitle tools
# ============================================================================

def _fmt_ts(seconds):
    """Format seconds as SRT timestamp HH:MM:SS,mmm."""
    if seconds < 0:
        seconds = 0
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def generate_subtitles(video_path, output_srt=None):
    """Transcribe a video's audio to a .srt file using faster-whisper."""
    p, err = _resolve_input(video_path)
    if err:
        return err
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        return {
            "ok": False,
            "error": "faster-whisper not installed (pip install faster-whisper)",
        }
    chk = _check_ffmpeg()
    if chk:
        return chk

    # extract audio to a temp wav
    tmp_wav = Path(tempfile.gettempdir()) / f"leon-subs-{_stamp()}.wav"
    extract = _ffmpeg_run(
        ["-i", str(p), "-vn", "-ac", "1", "-ar", "16000",
         "-acodec", "pcm_s16le", str(tmp_wav)],
        tmp_wav,
    )
    if not extract.get("ok"):
        return {"ok": False, "error": f"audio extraction failed: {extract.get('error')}"}

    if output_srt:
        srt = Path(os.path.expanduser(str(output_srt)))
        if not srt.is_absolute():
            srt = OUTPUT_DIR / srt
    else:
        srt = OUTPUT_DIR / f"{p.stem}-{_stamp()}.srt"
    srt.parent.mkdir(parents=True, exist_ok=True)

    try:
        model = WhisperModel("base", device="cpu", compute_type="int8")
        segments, _info = model.transcribe(str(tmp_wav))
        lines = []
        count = 0
        for seg in segments:
            count += 1
            lines.append(str(count))
            lines.append(f"{_fmt_ts(seg.start)} --> {_fmt_ts(seg.end)}")
            lines.append(seg.text.strip())
            lines.append("")
        srt.write_text("\n".join(lines), encoding="utf-8")
    except Exception as e:
        return {"ok": False, "error": f"transcription failed: {e}"}
    finally:
        try:
            tmp_wav.unlink()
        except Exception:
            pass

    return {
        "ok": True,
        "output": str(srt),
        "segments": count,
    }


def burn_subtitles(video_path, srt_path, output_path=None):
    """Hardcode an .srt subtitle file into a video."""
    p, err = _resolve_input(video_path)
    if err:
        return err
    srt, serr = _resolve_input(srt_path)
    if serr:
        return {"ok": False, "error": f"srt: {serr.get('error')}"}
    out = _out_path(p, "subbed", ext="mp4", explicit=output_path)
    # escape path for the subtitles filter
    srt_escaped = str(srt).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
    return _ffmpeg_run(
        ["-i", str(p), "-vf", f"subtitles='{srt_escaped}'",
         "-c:a", "copy", str(out)],
        out,
    )


# ============================================================================
# OBS Studio tools (obs-websocket v5)
# ============================================================================

def obs_status():
    """Report OBS connection, streaming and recording state."""
    def _do(conn):
        ver = conn.request("GetVersion")
        rec = conn.request("GetRecordStatus")
        stream = conn.request("GetStreamStatus")
        return {
            "ok": True,
            "connected": True,
            "obs_version": ver.get("obsVersion"),
            "websocket_version": ver.get("obsWebSocketVersion"),
            "recording": bool(rec.get("outputActive")),
            "record_duration_sec": round(rec.get("outputDuration", 0) / 1000, 1),
            "streaming": bool(stream.get("outputActive")),
            "stream_duration_sec": round(stream.get("outputDuration", 0) / 1000, 1),
        }
    return _obs_do(_do)


def obs_start_recording():
    """Start OBS recording. [MEDIUM]"""
    def _do(conn):
        conn.request("StartRecord")
        return {"ok": True, "recording": True}
    return _obs_do(_do)


def obs_stop_recording():
    """Stop OBS recording. [MEDIUM]"""
    def _do(conn):
        resp = conn.request("StopRecord")
        return {"ok": True, "recording": False,
                "output_path": resp.get("outputPath")}
    return _obs_do(_do)


def obs_start_streaming():
    """Start OBS streaming. [HIGH]"""
    def _do(conn):
        conn.request("StartStream")
        return {"ok": True, "streaming": True}
    return _obs_do(_do)


def obs_stop_streaming():
    """Stop OBS streaming. [MEDIUM]"""
    def _do(conn):
        conn.request("StopStream")
        return {"ok": True, "streaming": False}
    return _obs_do(_do)


def obs_scene_list():
    """List all OBS scenes and the current program scene."""
    def _do(conn):
        resp = conn.request("GetSceneList")
        scenes = [s.get("sceneName") for s in resp.get("scenes", [])]
        return {
            "ok": True,
            "scenes": scenes,
            "current_scene": resp.get("currentProgramSceneName"),
            "count": len(scenes),
        }
    return _obs_do(_do)


def obs_scene_switch(scene_name):
    """Switch the OBS program scene. [MEDIUM]"""
    if not scene_name:
        return {"ok": False, "error": "scene_name required"}

    def _do(conn):
        conn.request("SetCurrentProgramScene", {"sceneName": scene_name})
        return {"ok": True, "current_scene": scene_name}
    return _obs_do(_do)


def obs_toggle_source(scene_name, source_name):
    """Toggle visibility of a source within a scene. [MEDIUM]"""
    if not scene_name or not source_name:
        return {"ok": False, "error": "scene_name and source_name required"}

    def _do(conn):
        items = conn.request("GetSceneItemList", {"sceneName": scene_name})
        item_id = None
        for it in items.get("sceneItems", []):
            if it.get("sourceName") == source_name:
                item_id = it.get("sceneItemId")
                break
        if item_id is None:
            raise RuntimeError(f"source '{source_name}' not found in scene '{scene_name}'")
        cur = conn.request("GetSceneItemEnabled",
                           {"sceneName": scene_name, "sceneItemId": item_id})
        new_state = not bool(cur.get("sceneItemEnabled"))
        conn.request("SetSceneItemEnabled", {
            "sceneName": scene_name,
            "sceneItemId": item_id,
            "sceneItemEnabled": new_state,
        })
        return {"ok": True, "scene": scene_name, "source": source_name,
                "enabled": new_state}
    return _obs_do(_do)


# ============================================================================
# Convenience
# ============================================================================

def list_outputs(limit=20):
    """List the most recent files in ~/Documents/leon-video/."""
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = 20
    try:
        files = [f for f in OUTPUT_DIR.iterdir() if f.is_file()]
        files.sort(key=lambda f: f.stat().st_mtime, reverse=True)
        out = []
        for f in files[:limit]:
            st = f.stat()
            out.append({
                "name": f.name,
                "path": str(f),
                "size_mb": round(st.st_size / (1024 * 1024), 2),
                "modified": datetime.datetime.fromtimestamp(
                    st.st_mtime).isoformat(timespec="seconds"),
            })
        return {"ok": True, "output_dir": str(OUTPUT_DIR),
                "count": len(out), "files": out}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ============================================================================
# EXTRA_TOOLS export
# ============================================================================

EXTRA_TOOLS = {
    # ffmpeg editing
    "video.info": video_info,
    "video.trim": video_trim,
    "video.concat": video_concat,
    "video.compress": video_compress,
    "video.resize": video_resize,
    "video.to_gif": video_to_gif,
    "video.extract_audio": video_extract_audio,
    "video.extract_frames": video_extract_frames,
    "video.thumbnail": video_thumbnail,
    "video.speed": video_speed,
    "video.rotate": video_rotate,
    "video.add_watermark": video_add_watermark,
    "video.crop": video_crop,
    "video.merge_audio": video_merge_audio,
    "video.fade": video_fade,
    "video.screenshot_grid": video_screenshot_grid,
    # audio
    "video.audio_normalize": audio_normalize,
    "video.audio_trim_silence": audio_trim_silence,
    "video.audio_to_mp3": audio_to_mp3,
    "video.audio_concat": audio_concat,
    # subtitles
    "video.generate_subtitles": generate_subtitles,
    "video.burn_subtitles": burn_subtitles,
    # OBS Studio
    "obs.status": obs_status,
    "obs.start_recording": obs_start_recording,
    "obs.stop_recording": obs_stop_recording,
    "obs.start_streaming": obs_start_streaming,
    "obs.stop_streaming": obs_stop_streaming,
    "obs.scene_list": obs_scene_list,
    "obs.scene_switch": obs_scene_switch,
    "obs.toggle_source": obs_toggle_source,
    # convenience
    "video.list_outputs": list_outputs,
}


# ── Adapter ─────────────────────────────────────────────────────────────
# brain.integrations tools are dispatched as `fn(args_dict) -> dict`. Some
# tools in this module were authored with kwarg signatures
# (`def tool(name, value)`) instead of `def tool(args: dict)`. This wrapper
# makes both styles work: it calls the dict form first, and on a signature
# mismatch retries with kwargs. Every tool returns a dict and never raises.
def _adapt(fn):
    _fname = getattr(fn, "__name__", "tool")

    def _wrapped(args=None):
        a = args if isinstance(args, dict) else {}
        try:
            r = fn(a)
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except TypeError as e:
            if f"{_fname}()" not in str(e):
                return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        try:
            r = fn(**a)
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except TypeError as e:
            return {"ok": False, "error": f"bad args for {_fname}: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    _wrapped.__name__ = _fname
    _wrapped.__doc__ = getattr(fn, "__doc__", None)
    return _wrapped


EXTRA_TOOLS = {k: _adapt(v) for k, v in EXTRA_TOOLS.items()}
