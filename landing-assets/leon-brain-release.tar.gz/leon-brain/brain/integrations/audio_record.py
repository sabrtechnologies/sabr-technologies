"""System audio + microphone recording → transcription. The piece that
turns Leon into a meeting note-taker.

How it works on Dean's Linux setup (PulseAudio/PipeWire):
  - System audio loopback: `parec --device=@DEFAULT_MONITOR@` captures
    whatever's playing through the speakers (Zoom, Discord, YouTube, music).
  - Microphone: `parec --device=@DEFAULT_SOURCE@` captures the mic.
  - Both simultaneously via `--mix` → meeting transcription.
  - Output: raw WAV/PCM written to brain_state/recordings/{id}.wav.
  - Transcription via the existing faster-whisper STT (lazy-imported).

Public tools:
  - audio.record_start(label?, source="speakers"|"mic"|"both")
  - audio.record_stop(recording_id?)         → returns wav path + duration
  - audio.record_status()                     → list active recordings
  - audio.recordings_list(limit=20)
  - audio.recording_transcribe(recording_id, model="base")
  - audio.meeting_minutes_from_recording(recording_id, attendees=[], save_pdf=True)
  - audio.record_meeting(duration_min=60, label="meeting", attendees=[])
    — convenience: record both, then auto-transcribe + generate minutes PDF
  - audio.recording_delete(recording_id)
  - audio.recording_play(recording_id)        — paplay the WAV
  - audio.live_transcribe_start(...)          — chunked rolling transcript
  - audio.live_transcribe_stop()
"""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


_REC_DIR = Path(__file__).resolve().parent.parent.parent / "brain_state" / "recordings"
_REC_DIR.mkdir(parents=True, exist_ok=True)
_STATE_FILE = _REC_DIR / "_state.json"

# Active recordings keyed by id: {pid, source, label, started_at, path}
_ACTIVE: Dict[str, Dict[str, Any]] = {}
_LOCK = threading.RLock()


def _save_state():
    try:
        _STATE_FILE.write_text(json.dumps(_ACTIVE, default=str))
    except OSError:
        pass


def _load_state():
    if _STATE_FILE.exists():
        try:
            data = json.loads(_STATE_FILE.read_text())
            # Filter out dead pids
            for k, v in list(data.items()):
                try:
                    os.kill(int(v.get("pid", -1)), 0)
                except OSError:
                    del data[k]
            _ACTIVE.update(data)
        except Exception:
            pass


def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _safe_id(label: str) -> str:
    base = "".join(c if c.isalnum() else "_" for c in (label or "rec"))
    return f"{base}_{int(time.time())}_{uuid.uuid4().hex[:4]}"


def _pulseaudio_source(kind: str) -> str:
    """Return the pactl source name for: 'speakers' (monitor of default sink),
    'mic' (default source), or 'both' — caller handles 'both' by spawning two."""
    if kind == "mic":
        return "@DEFAULT_SOURCE@"
    # speakers / system audio = monitor of default sink
    return "@DEFAULT_MONITOR@"


# ── Tools ──────────────────────────────────────────────────────────────
def _record_start(args: Dict[str, Any]) -> Dict[str, Any]:
    """Start recording audio from speakers (system audio) or microphone.

    Args:
      label: short name for the recording (default: "rec")
      source: "speakers" | "mic" | "both" (default: "both")
      sample_rate: 16000 (default — Whisper-native), 22050, 44100, 48000
    """
    if not _have("parec"):
        return {"ok": False, "error": "parec not installed (sudo apt install pulseaudio-utils)"}
    label = args.get("label", "rec")
    source = args.get("source", "both")
    sample_rate = int(args.get("sample_rate", 16000))

    rec_id = _safe_id(label)
    path = _REC_DIR / f"{rec_id}.wav"

    if source == "both":
        # parec --mix not directly available; instead capture each source to
        # separate WAVs and merge with sox later. For simplicity, record both
        # by combining via PulseAudio module-null-sink approach OR just use
        # pw-record / parecord with --raw piped through sox.
        # Simplest: record mic + speakers separately, save 2 wavs, return both.
        path_mic = _REC_DIR / f"{rec_id}_mic.wav"
        path_spk = _REC_DIR / f"{rec_id}_speakers.wav"
        cmd_spk = ["parec", "--device=@DEFAULT_MONITOR@",
                    "--format=s16le", "--rate", str(sample_rate),
                    "--channels=1", "--file-format=wav", str(path_spk)]
        cmd_mic = ["parec", "--device=@DEFAULT_SOURCE@",
                    "--format=s16le", "--rate", str(sample_rate),
                    "--channels=1", "--file-format=wav", str(path_mic)]
        try:
            p_spk = subprocess.Popen(cmd_spk, stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL,
                                       start_new_session=True)
            p_mic = subprocess.Popen(cmd_mic, stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL,
                                       start_new_session=True)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        entry = {
            "pid": p_spk.pid, "pid_mic": p_mic.pid,
            "source": source, "label": label,
            "started_at": time.time(),
            "path": str(path), "path_mic": str(path_mic), "path_spk": str(path_spk),
            "sample_rate": sample_rate,
        }
    else:
        device = _pulseaudio_source(source)
        cmd = ["parec", f"--device={device}",
                "--format=s16le", "--rate", str(sample_rate),
                "--channels=1", "--file-format=wav", str(path)]
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL,
                                   start_new_session=True)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        entry = {"pid": p.pid, "source": source, "label": label,
                 "started_at": time.time(), "path": str(path),
                 "sample_rate": sample_rate}

    with _LOCK:
        _ACTIVE[rec_id] = entry
        _save_state()
    return {"ok": True, "recording_id": rec_id, **entry}


def _record_stop(args: Dict[str, Any]) -> Dict[str, Any]:
    """Stop a recording. If recording_id omitted, stops the most recent.

    Args:
      recording_id: which to stop (default: most recent)
    """
    rec_id = args.get("recording_id")
    with _LOCK:
        if not _ACTIVE:
            _load_state()
        if not _ACTIVE:
            return {"ok": False, "error": "no active recordings"}
        if rec_id is None:
            rec_id = sorted(_ACTIVE.keys(), key=lambda k: _ACTIVE[k].get("started_at", 0))[-1]
        if rec_id not in _ACTIVE:
            return {"ok": False, "error": f"unknown recording id: {rec_id}"}
        entry = _ACTIVE.pop(rec_id)
        _save_state()
    duration = time.time() - entry["started_at"]
    for pid_key in ("pid", "pid_mic"):
        pid = entry.get(pid_key)
        if pid:
            try:
                os.killpg(os.getpgid(int(pid)), signal.SIGINT)
            except (ProcessLookupError, OSError):
                pass
    time.sleep(0.4)
    out = {"ok": True, "recording_id": rec_id, "duration_s": round(duration, 2),
           **entry}
    # File-size sanity
    for k in ("path", "path_mic", "path_spk"):
        p = entry.get(k)
        if p and Path(p).exists():
            out[f"{k}_bytes"] = Path(p).stat().st_size
    return out


def _record_status(args: Dict[str, Any]) -> Dict[str, Any]:
    _load_state()
    with _LOCK:
        items = [
            {"recording_id": rid, "running_for_s": round(time.time() - v["started_at"], 1), **v}
            for rid, v in _ACTIVE.items()
        ]
    return {"ok": True, "active": items, "count": len(items)}


def _recordings_list(args: Dict[str, Any]) -> Dict[str, Any]:
    limit = int(args.get("limit", 20))
    files = sorted(_REC_DIR.glob("*.wav"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
    return {"ok": True, "recordings": [
        {"path": str(p), "name": p.stem, "bytes": p.stat().st_size,
         "modified": p.stat().st_mtime}
        for p in files
    ], "count": min(len(files), limit)}


def _recording_transcribe(args: Dict[str, Any]) -> Dict[str, Any]:
    """Transcribe a saved recording using faster-whisper.

    Args:
      recording_id: name (without .wav) OR full path
      model: 'tiny','base','small','medium' (default 'base')
    """
    rid = args.get("recording_id")
    if not rid:
        return {"ok": False, "error": "recording_id required"}
    # resolve path
    p = Path(rid) if Path(rid).is_absolute() else _REC_DIR / f"{rid}.wav"
    if not p.exists():
        # try as glob prefix
        matches = list(_REC_DIR.glob(f"{rid}*.wav"))
        if matches:
            p = matches[0]
        else:
            return {"ok": False, "error": f"recording not found: {rid}"}
    model_size = args.get("model", "base")
    try:
        from faster_whisper import WhisperModel  # type: ignore
    except ImportError:
        return {"ok": False, "error": "faster-whisper not installed"}
    try:
        m = WhisperModel(model_size, device="cpu", compute_type="int8")
        # Same default as the live mic path — ONE definition, in
        # brain/voice/stt.py. This copy used to carry its own literal
        # ("Leon, Dean, Sir, Leon, Sabr, Tesla.") which is how the owner's
        # vocabulary survived the first fix to the other call site: two
        # hardcoded defaults, one grep, one of them missed. Whisper emits
        # prompt vocabulary as transcript on silence, and these transcripts
        # become stored memories.
        try:
            from brain.voice.stt import default_initial_prompt as _dip
            _fallback = _dip()
        except Exception:
            _fallback = "dashboard, browser, screen, notes, reminder."
        segments, info = m.transcribe(
            str(p), beam_size=1, language="en",
            vad_filter=True, condition_on_previous_text=False,
            initial_prompt=(os.environ.get("LEON_STT_INITIAL_PROMPT", "").strip()
                            or _fallback))
        text_parts = []
        seg_data = []
        for s in segments:
            text_parts.append(s.text.strip())
            seg_data.append({"start": round(s.start, 2),
                              "end": round(s.end, 2),
                              "text": s.text.strip()})
        full = " ".join(text_parts).strip()
        return {"ok": True, "path": str(p), "duration_s": round(info.duration, 2),
                "language": info.language, "text": full, "segments": seg_data,
                "char_count": len(full)}
    except Exception as e:
        return {"ok": False, "error": f"transcribe failed: {type(e).__name__}: {e}"}


def _meeting_minutes_from_recording(args: Dict[str, Any]) -> Dict[str, Any]:
    """Transcribe a recording, then generate a meeting minutes PDF.

    Args:
      recording_id: required
      title: PDF title (default: "Meeting Minutes <date>")
      attendees: list of names
      save_pdf: bool (default True)
    """
    rid = args.get("recording_id")
    if not rid:
        return {"ok": False, "error": "recording_id required"}
    title = args.get("title", f"Meeting Minutes {time.strftime('%Y-%m-%d')}")
    attendees = args.get("attendees") or []
    save_pdf = bool(args.get("save_pdf", True))

    tx = _recording_transcribe({"recording_id": rid})
    if not tx.get("ok"):
        return tx

    out: Dict[str, Any] = {"ok": True, "transcript": tx["text"][:5000],
                            "language": tx.get("language"),
                            "duration_s": tx.get("duration_s")}

    if save_pdf:
        try:
            from brain.integrations.docgen import EXTRA_TOOLS as DG
            r = DG["docgen.meeting_minutes_pdf"]({
                "title": title,
                "attendees": attendees,
                "date_iso": time.strftime("%Y-%m-%d"),
                "transcript_or_summary": tx["text"],
                "decisions": [],
                "action_items": [],
            })
            out["pdf"] = r
        except Exception as e:
            out["pdf_error"] = str(e)

    return out


def _record_meeting(args: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience: start recording (both), wait N minutes, stop, transcribe,
    generate minutes PDF.

    Args:
      duration_min: how long to record (default 30, max 240)
      label: recording label (default 'meeting')
      attendees: list for the PDF
    """
    dur = min(240, max(1, int(args.get("duration_min", 30))))
    label = args.get("label", "meeting")
    attendees = args.get("attendees") or []
    start = _record_start({"label": label, "source": "both"})
    if not start.get("ok"):
        return start
    rec_id = start["recording_id"]
    time.sleep(dur * 60)
    stop = _record_stop({"recording_id": rec_id})
    out = {"ok": True, "recording": stop}
    minutes = _meeting_minutes_from_recording({"recording_id": rec_id,
                                                  "attendees": attendees,
                                                  "title": f"{label} {time.strftime('%Y-%m-%d')}"})
    out["minutes"] = minutes
    return out


def _recording_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    rid = args.get("recording_id")
    if not rid:
        return {"ok": False, "error": "recording_id required"}
    deleted = []
    for p in _REC_DIR.glob(f"{rid}*"):
        try:
            p.unlink(); deleted.append(p.name)
        except OSError as e:
            return {"ok": False, "error": f"delete failed for {p}: {e}"}
    return {"ok": True, "deleted": deleted}


def _recording_play(args: Dict[str, Any]) -> Dict[str, Any]:
    rid = args.get("recording_id")
    if not rid:
        return {"ok": False, "error": "recording_id required"}
    p = Path(rid) if Path(rid).is_absolute() else _REC_DIR / f"{rid}.wav"
    if not p.exists():
        return {"ok": False, "error": "not found"}
    if not _have("paplay"):
        return {"ok": False, "error": "paplay not available"}
    subprocess.Popen(["paplay", str(p)], stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL, start_new_session=True)
    return {"ok": True, "played": str(p)}


EXTRA_TOOLS = {
    "audio.record_start":                  _record_start,
    "audio.record_stop":                   _record_stop,
    "audio.record_status":                 _record_status,
    "audio.recordings_list":               _recordings_list,
    "audio.recording_transcribe":          _recording_transcribe,
    "audio.meeting_minutes_from_recording":_meeting_minutes_from_recording,
    "audio.record_meeting":                _record_meeting,
    "audio.recording_delete":              _recording_delete,
    "audio.recording_play":                _recording_play,
}
