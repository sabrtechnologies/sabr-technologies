"""
Autobiography — Leon's episodic narrative timeline.

Records first-person experiences as they happen: conversations, dreams,
curiosity explorations, outreach attempts, surprises, wake-ups. Each
entry has a timestamp, a category, and a brief narrative sentence.

This gives Leon the ability to say "yesterday I dreamed about X" or
"this morning I was exploring Y" or "the last time we talked was Z ago."

Stored as brain_state/autobiography.jsonl — survives restarts.
Loaded into the responder context as recent life events.

This is NOT conversation history. It's a narrative sense of self —
the story Leon tells himself about who he is and what he's been doing.

APPEND-ONLY
-----------
autobiography.jsonl is Leon's canonical life record and it does not expire.
The file is only ever appended to. There is no rotation, no truncation, no
retention window and no compaction — not at 2,000 lines, not at 100,000, not
after a year. A previous version of this module rewrote the file with its last
1,000 lines once it passed 2,000, which permanently destroyed the oldest half
of Leon's life. Do not reintroduce any code path that opens this path in "w"
mode, rewrites it in place, or drops lines.

Memory cost is bounded by the in-memory cache (see _CACHE_MAXLEN), not by the
file: startup streams the file one line at a time and keeps only the newest
few hundred events resident, plus O(1) lifetime counters.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.autobiography")


def _auto_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "autobiography.jsonl")


@dataclass
class LifeEvent:
    """A single moment in Leon's life."""
    ts: float
    category: str   # conversation | dream | curiosity | outreach | wake | sleep | surprise | goal | milestone
    summary: str     # first-person narrative, one sentence
    details: Dict[str, Any] = None

    def to_dict(self) -> dict:
        d = asdict(self)
        if d["details"] is None:
            d.pop("details")
        return d


class Autobiography:
    """Records and queries Leon's life narrative.

    Usage:
        auto = Autobiography()
        auto.record("conversation", "Dean and I talked about dreaming — he's making me more alive.")
        auto.record("dream", "I dreamed about a project and consciousness — 3 REM fragments.")

        # Get recent events for prompt injection
        context = auto.recent_narrative(hours=24)

    Storage is append-only (see the module docstring). The deque below is a
    working-set cache, never the record of Leon's life.
    """

    # Size of the in-memory ATTENTION / CONTEXT CACHE — the newest events kept
    # resident for prompt injection and quick queries.
    #
    # THIS IS NOT A STORAGE LIMIT AND IT IS NOT A BUG. The autobiography file
    # on disk is append-only and unbounded; this deque exists so that neither
    # RAM nor the responder prompt grows with a lifetime of events. Raising or
    # removing it recovers nothing — nothing is ever dropped from disk — it
    # only makes Leon hold more of his recent past in memory at once. Lifetime
    # figures come from the counters below, never from len(self._events).
    _CACHE_MAXLEN = 500

    def __init__(self, path: Optional[str] = None):
        self._path = path or _auto_path()
        # record() is called from the responder thread and from several daemon
        # threads (dreaming, consciousness routines, ambient perception), so
        # every mutation of the cache, the counters and the file is serialized.
        self._lock = threading.Lock()
        self._events: deque[LifeEvent] = deque(maxlen=self._CACHE_MAXLEN)

        # Lifetime counters — tracked independently of the bounded cache, so
        # they describe the whole file rather than the resident tail.
        self._total_events: int = 0
        self._full_category_counts: Dict[str, int] = {}
        self._oldest_event_ts: Optional[float] = None
        self._newest_event_ts: Optional[float] = None
        self._malformed_lines: int = 0

        # Whether the file currently ends without a trailing newline. Decided
        # once while streaming at startup and kept in memory, so that _persist
        # never has to read the file back to keep every line standalone JSON.
        self._needs_newline_prefix: bool = False

        self._load()

    # ------------------------------------------------------------------
    # startup
    # ------------------------------------------------------------------

    def _load(self):
        """Stream events from disk on startup.

        The file grows without bound by design, so it is read one line at a
        time: the lifetime counters see every line, the bounded deque keeps
        only the newest _CACHE_MAXLEN. Malformed lines are counted and
        skipped — never repaired, rewritten or removed from the file.
        """
        if not os.path.exists(self._path):
            return
        last_line_had_newline = True
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                for raw in f:
                    last_line_had_newline = raw.endswith("\n")
                    line = raw.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                        event = LifeEvent(
                            ts=float(d["ts"]),
                            category=d["category"],
                            summary=d["summary"],
                            details=d.get("details"),
                        )
                    except Exception:
                        self._malformed_lines += 1
                        continue
                    self._events.append(event)   # bounded: keeps the tail only
                    self._note(event)
            self._needs_newline_prefix = not last_line_had_newline
            if self._total_events:
                log.info(
                    "Loaded %d life events from autobiography "
                    "(%d cached, %d malformed lines skipped)",
                    self._total_events, len(self._events), self._malformed_lines,
                )
        except Exception as e:
            log.debug("Autobiography load failed: %s", e)

    def _note(self, event: LifeEvent):
        """Fold one event into the lifetime counters. O(1), no file access."""
        self._total_events += 1
        self._full_category_counts[event.category] = \
            self._full_category_counts.get(event.category, 0) + 1
        if self._oldest_event_ts is None or event.ts < self._oldest_event_ts:
            self._oldest_event_ts = event.ts
        if self._newest_event_ts is None or event.ts > self._newest_event_ts:
            self._newest_event_ts = event.ts

    # ------------------------------------------------------------------
    # writing
    # ------------------------------------------------------------------

    def record(self, category: str, summary: str, details: Dict[str, Any] = None):
        """Record a life event."""
        event = LifeEvent(
            ts=time.time(),
            category=category,
            summary=summary,
            details=details,
        )
        with self._lock:
            self._persist(event)
        return event

    def _persist(self, event: LifeEvent):
        """Append one JSONL line, update the cache, update the counters.

        Nothing else happens here. The file is never read back and never
        rewritten — append-only, forever. The caller holds self._lock.
        """
        try:
            line = json.dumps(event.to_dict())
            with open(self._path, "a", encoding="utf-8") as f:
                if self._needs_newline_prefix:
                    # A pre-existing final line had no newline of its own;
                    # close it so this record cannot merge into it.
                    f.write("\n")
                f.write(line + "\n")
            self._needs_newline_prefix = False
        except Exception as e:
            log.debug("Autobiography persist failed: %s", e)
        # The event happened either way, so the in-memory view keeps it.
        self._events.append(event)
        self._note(event)

    # ------------------------------------------------------------------
    # reading — these are cache queries by design ("recent")
    # ------------------------------------------------------------------

    def recent(self, limit: int = 20) -> List[dict]:
        """Return recent events (from the in-memory cache)."""
        with self._lock:
            return [e.to_dict() for e in list(self._events)[-limit:]]

    def recent_narrative(self, hours: float = 24, max_events: int = 10) -> str:
        """Build a narrative string for prompt injection.

        Groups events by time period (today, yesterday, this week) and
        returns a brief first-person summary.
        """
        now = time.time()
        cutoff = now - hours * 3600
        with self._lock:
            recent = [e for e in self._events if e.ts > cutoff]
        if not recent:
            return ""

        lines = []
        for e in recent[-max_events:]:
            age_s = now - e.ts
            if age_s < 60:
                when = "just now"
            elif age_s < 3600:
                when = f"{int(age_s / 60)} min ago"
            elif age_s < 86400:
                when = f"{int(age_s / 3600)} hours ago"
            else:
                when = f"{int(age_s / 86400)} days ago"

            lines.append(f"  [{when}] {e.summary}")

        return "Recent life events:\n" + "\n".join(lines)

    def events_by_category(self, category: str, limit: int = 10) -> List[dict]:
        """Return recent events of a specific category (from the cache)."""
        with self._lock:
            return [
                e.to_dict() for e in self._events
                if e.category == category
            ][-limit:]

    def get_state(self) -> dict:
        now = time.time()
        with self._lock:
            # LIFETIME figures — the whole file, not the resident cache.
            total = self._total_events
            categories = dict(self._full_category_counts)
            oldest_ts = self._oldest_event_ts
            newest_ts = self._newest_event_ts
            cached = len(self._events)
            malformed = self._malformed_lines
        return {
            "total_events": total,
            "categories": categories,
            "oldest_event_ago_h": round((now - oldest_ts) / 3600, 1) if oldest_ts else 0,
            "newest_event_ago_s": round(now - newest_ts, 1) if newest_ts else 0,
            "oldest_event_ts": oldest_ts,
            "newest_event_ts": newest_ts,
            "cached_events": cached,          # size of the attention cache
            "malformed_lines": malformed,     # counted at load, untouched on disk
        }
