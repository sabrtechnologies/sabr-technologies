"""QV2-writer: the sole writer of the writer-owned files (spec 7.4, 10).

Files under the state dir (``brain_state/v2/quantum`` by default):

  decisions/YYYY-MM-DD.d.jsonl     qv2.d/1 compact line for EVERY decision seen
  decisions/YYYY-MM-DD.full.jsonl  qv2.decision/2 full records (sampling rules)
  aggregates/YYYY-MM-DD.jsonl      5-minute pooled buckets
  counters/YYYY-MM-DD.jsonl        60 s cumulative counters, boot, gap,
                                   policy_refused and clean_close records
  causal/experiments.jsonl, causal/prereg/<id>.json
  activity.json                    {ts, last_user_message_age_s}, every 30 s

Days are UTC. Records are append-only and each line is flushed; fsync runs
on causal records, counter snapshots, bucket rollovers and clean_close.
Closed day files are gzipped the next day (write .gz, fsync, verify line
count and sha256 of the decompressed content, then unlink the original).
Nothing else is ever removed. Nothing outside the state dir is written.
"""
import collections
import datetime
import gzip
import hashlib
import json
import math
import os
import re
import secrets
import shutil
import threading
import time

from . import authority, filelock, legacy_model, policy, prep
from .provenance import (SCHEMA_AGGREGATE, SCHEMA_CAUSAL, SCHEMA_COMPACT, SCHEMA_COUNTERS,
                         SCHEMA_DECISION, Source, clip_labels, map_legacy_source)

BUCKET_S = 300
DRAIN_BATCH = 256
POLL_KILL_S = 5.0
ACTIVITY_S = 30.0
COUNTERS_S = 60.0
CAUSAL_TICK_S = 1.0
ROTATE_CHECK_S = 600.0
CLOSE_DRAIN_BUDGET_S = 0.5
OVERHEAD_EDGES_US = (1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 5000)
LEGACY_EDGES_MS = (1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 30000)
#: Attribute names read (read-only) from the live brain for activity.json;
#: the same source the sleep daemon uses.
LEGACY_METER_ATTR = "consciousness_meter"
LEGACY_MSG_TS_ATTR = "_last_user_message_ts"
_DAY_FILE = re.compile(r"^(\d{4}-\d{2}-\d{2})\..*jsonl$")
_PKG_DIR = os.path.dirname(os.path.abspath(__file__))


def utc_day(ts):
    return datetime.datetime.fromtimestamp(ts, datetime.timezone.utc).strftime("%Y-%m-%d")


def _clean(x):
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        return repr(x)
    return x


def clean_scores(scores, cap=64):
    if scores is None:
        return None
    out = []
    for s in list(scores)[:cap]:
        try:
            out.append(_clean(float(s)))
        except (TypeError, ValueError):
            out.append(str(s)[:20])
    return out


def labels_sha256(labels):
    if labels is None:
        return None
    return hashlib.sha256("\x1f".join(str(x) for x in labels).encode("utf-8", "replace")).hexdigest()


def code_sha256():
    h = hashlib.sha256()
    for name in sorted(os.listdir(_PKG_DIR)):
        if name.endswith((".py", ".json")):
            with open(os.path.join(_PKG_DIR, name), "rb") as fh:
                h.update(name.encode() + b"\0" + fh.read() + b"\0")
    return h.hexdigest()


def _hist_add(hist, value, edges):
    for e in edges:
        if value <= e:
            k = "<=%s" % e
            break
    else:
        k = ">%s" % edges[-1]
    hist[k] = hist.get(k, 0) + 1


def dumps(rec):
    return json.dumps(rec, sort_keys=True, allow_nan=False, default=str, separators=(",", ":"))


def gzip_verified(path):
    """gzip a closed day file; unlink the original only after verification."""
    h, lines = hashlib.sha256(), 0
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
            lines += chunk.count(b"\n")
    want = h.hexdigest()
    gz = path + ".gz"

    def ok(p):
        hh, ll = hashlib.sha256(), 0
        try:
            with gzip.open(p, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 16), b""):
                    hh.update(chunk)
                    ll += chunk.count(b"\n")
        except (OSError, EOFError):
            return False
        return hh.hexdigest() == want and ll == lines

    if os.path.exists(gz):
        if ok(gz):
            os.unlink(path)
            return "verified_existing"
        os.replace(gz, "%s.bad-%d" % (gz, int(time.time())))
    tmp = gz + ".tmp"
    with open(path, "rb") as fi, open(tmp, "wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb") as fo:
            shutil.copyfileobj(fi, fo)
        raw.flush()
        os.fsync(raw.fileno())
    os.replace(tmp, gz)
    if ok(gz):
        os.unlink(path)
        return "rotated"
    os.replace(gz, "%s.bad-%d" % (gz, int(time.time())))
    return "verify_failed"


class _Appender:
    def __init__(self):
        self._fh = {}

    def write(self, path, lines, fsync=False):
        fh = self._fh.get(path)
        if fh is None:
            d = os.path.dirname(path)
            os.makedirs(d, exist_ok=True)
            fh = self._fh[path] = open(path, "a", encoding="utf-8")
        for line in lines:
            fh.write(line + "\n")
        fh.flush()
        if fsync:
            os.fsync(fh.fileno())

    def close_except(self, keep_day):
        for path in list(self._fh):
            if keep_day is None or keep_day not in os.path.basename(path):
                try:
                    self._fh.pop(path).close()
                except Exception:
                    pass

    def close_all(self):
        self.close_except(None)


class Store:
    def __init__(self, router, state_dir):
        self.router = router
        self.dir = state_dir
        self.clock = router._clock
        self.status = "starting"
        self.lock_mode = None
        self.no_write = False
        self._lock = None
        self._thread = None
        self._app = _Appender()
        self._aggs = {}
        self._recent = collections.deque(maxlen=100)
        self._ws_sample = 0
        self.code_sha = None
        self.written = collections.Counter()
        self.errors = collections.Counter()
        self.writer_counts = collections.Counter()
        self.discarded = 0
        self.ibm_disabled = False
        self.causal_disabled = False
        self.causal_status = {"state": "off"}
        self.setup_error = None
        self._stopped = threading.Event()

    # ── lifecycle ───────────────────────────────────────────────────────
    def start(self):
        if self._thread is None:
            self._thread = threading.Thread(target=self._run, name="QV2-writer", daemon=True)
            self._thread.start()

    def join(self, timeout):
        t = self._thread
        if t is not None:
            t.join(timeout)

    def status_block(self):
        return {"status": self.status, "lock_mode": self.lock_mode, "no_write": self.no_write,
                "written": dict(self.written), "errors": dict(self.errors),
                "discarded_no_write": self.discarded, "ibm_disabled_file": self.ibm_disabled,
                "causal_disabled_file": self.causal_disabled, "setup_error": self.setup_error,
                "code_sha256": self.code_sha}

    def recent(self, n):
        return list(self._recent)[-n:]

    def path(self, *parts):
        return os.path.join(self.dir, *parts)

    # ── main loop ───────────────────────────────────────────────────────
    def _run(self):
        try:
            self._setup()
        except Exception as e:
            self.status = "degraded"
            self.setup_error = type(e).__name__
        stop = self.router._stop
        mono = time.monotonic
        nk = na = nc = nr = nt = 0.0
        while not stop.is_set():
            try:
                self._drain(DRAIN_BATCH)
                t = mono()
                now = self.clock()
                if t >= nk:
                    nk = t + POLL_KILL_S
                    self._poll_kill_switches()
                if t >= nt:
                    nt = t + CAUSAL_TICK_S
                    self._causal_tick(now)
                if t >= na:
                    na = t + ACTIVITY_S
                    self._write_activity(now)
                if t >= nc:
                    nc = t + COUNTERS_S
                    self._write_counters(now, "snapshot")
                self._flush_buckets(now, final=False)
                if t >= nr:
                    nr = t + ROTATE_CHECK_S
                    self._rotate(now)
            except Exception as e:
                self.errors[type(e).__name__] += 1
            stop.wait(0.05)
        self._final()

    def _final(self):
        deadline = time.monotonic() + CLOSE_DRAIN_BUDGET_S
        left = 0
        try:
            while time.monotonic() < deadline:
                if not self._drain(64, fast=True):
                    break
            left = (len(self.router._shadow_q) + len(self.router._record_q))
            self._drain_causal()
            now = self.clock()
            self._flush_buckets(now, final=True)
            self._write_counters(now, "clean_close", extra={"unprocessed_on_close": left})
        except Exception as e:
            self.errors[type(e).__name__] += 1
        finally:
            self._app.close_all()
            if self._lock is not None:
                try:
                    self._lock.release()
                except Exception:
                    pass
            self.status = "closed"
            self._stopped.set()

    # ── setup ───────────────────────────────────────────────────────────
    def _setup(self):
        for sub in ("decisions", "aggregates", "counters", os.path.join("causal", "prereg")):
            os.makedirs(self.path(sub), exist_ok=True)
        lk = filelock.open_lock(self.path("writer.lock"))
        if lk is None:
            lk = filelock.InProcessLock(self.path("writer.lock"))
            self.lock_mode = "in_process_only"
        else:
            self.lock_mode = filelock.backend_name()
        if lk.acquire(blocking=False):
            self._lock = lk
            self.status = "ok" if self.lock_mode != "in_process_only" else "ok_in_process_lock"
        else:
            self.no_write = True
            self.status = "no_write"
        self.code_sha = code_sha256()
        now = self.clock()
        if self.no_write:
            return
        self._rotate(now)
        self._gap_check(now)
        r = self.router
        boot = {"kind": "boot", "boot_ts": r.boot_ts, "flags": r.cfg.flags_block(),
                "lock_mode": self.lock_mode, "code_sha256": self.code_sha,
                "state_dir": self.dir}
        recs = [boot] + [{"kind": "policy_refused", "item": a, "reason": b}
                         for a, b in r.cfg.policy_refused]
        self._counters_write(now, recs)
        self._poll_kill_switches()
        self._causal_setup(now)

    def _counters_write(self, now, recs):
        lines = []
        for rec in recs:
            base = {"schema": SCHEMA_COUNTERS, "boot_id": self.router.boot_id, "ts": now}
            base.update(rec)
            lines.append(dumps(base))
        self._write(self.path("counters", "%s.jsonl" % utc_day(now)), lines, fsync=True, key="counters")

    def _write(self, path, lines, fsync=False, key="lines"):
        if self.no_write:
            self.discarded += len(lines)
            return
        self._app.write(path, lines, fsync=fsync)
        self.written[key] += len(lines)

    def _gap_check(self, now):
        d = self.path("counters")
        names = sorted((n for n in os.listdir(d) if _DAY_FILE.match(n) or n.endswith(".jsonl.gz")),
                       reverse=True)
        last = None
        for name in names[:3]:
            p = os.path.join(d, name)
            opener = gzip.open if name.endswith(".gz") else open
            try:
                with opener(p, "rt", encoding="utf-8") as fh:
                    for line in fh:
                        try:
                            rec = json.loads(line)
                        except ValueError:
                            continue
                        if isinstance(rec, dict) and rec.get("boot_id") != self.router.boot_id:
                            last = rec
            except (OSError, EOFError):
                continue
            if last is not None:
                break
        if last is not None and last.get("kind") != "clean_close":
            lts = float(last.get("ts") or 0.0)
            self._counters_write(now, [{"kind": "gap", "prev_boot_id": last.get("boot_id"),
                                        "last_snapshot_ts": lts, "boot_ts": self.router.boot_ts,
                                        "lost_upper_bound_s": max(0.0, self.router.boot_ts - lts)}])

    # ── periodic tasks ─────────────────────────────────────────────────────
    def _poll_kill_switches(self):
        self.ibm_disabled = os.path.exists(self.path("IBM_DISABLED"))
        self.causal_disabled = os.path.exists(self.path("CAUSAL_DISABLED"))
        c = self.router._causal
        if c is not None:
            c.scheduler.disabled = self.causal_disabled

    def _write_activity(self, now):
        if self.no_write:
            return
        age = None
        try:
            meter = getattr(self.router._brain, LEGACY_METER_ATTR, None)
            ts = getattr(meter, LEGACY_MSG_TS_ATTR, None) if meter is not None else None
            if isinstance(ts, (int, float)):
                age = max(0.0, now - float(ts))
        except Exception:
            age = None
        p = self.path("activity.json")
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(dumps({"ts": now, "last_user_message_age_s": age,
                            "boot_id": self.router.boot_id}))
        os.replace(tmp, p)
        self.written["activity"] += 1

    def _write_counters(self, now, kind, extra=None):
        counts, drops = self.router.counter_snapshot()
        rec = {"kind": kind,
               "counts": [list(k) + [v] for k, v in sorted(counts.items(), key=repr)],
               "drops": [list(k) + [v] for k, v in sorted(drops.items(), key=repr)],
               "writer_counts": [list(k) + [v] for k, v in sorted(self.writer_counts.items(), key=repr)],
               "queues": {"shadow": len(self.router._shadow_q), "record": len(self.router._record_q),
                          "causal": len(self.router._causal_q)},
               "mem_estimate_bytes": self.router.mem_estimate_bytes(),
               "discarded_no_write": self.discarded}
        if extra:
            rec.update(extra)
        self._counters_write(now, [rec])

    def _rotate(self, now):
        if self.no_write:
            return
        today = utc_day(now)
        self._app.close_except(today)
        for sub in ("decisions", "aggregates", "counters"):
            d = self.path(sub)
            try:
                names = os.listdir(d)
            except OSError:
                continue
            for name in names:
                m = _DAY_FILE.match(name)
                if m and m.group(1) < today:
                    try:
                        self.written["gzip_" + gzip_verified(os.path.join(d, name))] += 1
                    except OSError as e:
                        self.errors["gzip_" + type(e).__name__] += 1

    # ── draining ──────────────────────────────────────────────────────────
    def _drain_causal(self):
        q = self.router._causal_q
        k = 0
        while True:
            try:
                item = q.popleft()
            except IndexError:
                return k
            k += 1
            try:
                self._process_causal(item)
            except Exception as e:
                self.errors["causal_" + type(e).__name__] += 1

    def _drain(self, budget, fast=False):
        did = self._drain_causal()
        for q, fn in ((self.router._shadow_q, self._process_shadow),
                      (self.router._record_q, self._process_record)):
            for _ in range(budget):
                try:
                    item = q.popleft()
                except IndexError:
                    break
                did += 1
                try:
                    fn(item, fast)
                except Exception as e:
                    self.errors["process_" + type(e).__name__] += 1
        return did

    # ── record building ───────────────────────────────────────────────────
    def _did(self, seq):
        return "%s.%d" % (self.router.boot_id, seq)

    def _compact(self, did, ts, ctx, n, route, k, src, leg, rt, fb, outcome):
        return dumps({"s": SCHEMA_COMPACT, "i": did, "t": ts, "c": ctx, "n": n, "m": route, "k": k,
                      "src": src, "leg": 1 if leg else 0, "rt": 1 if rt else 0, "f": fb, "o": outcome})

    def _flags(self, lqs):
        f = self.router.cfg.flags_block()
        f["causal"] = "on" if self.router._causal_active else "off"
        f["LEON_QUANTUM_SOURCE_at_call"] = lqs
        return f

    def _agg(self, ts, ctx, n, mode):
        b = int(ts // BUCKET_S) * BUCKET_S
        key = (b, ctx, n, mode)
        a = self._aggs.get(key)
        if a is None:
            a = self._aggs[key] = {
                "decisions": 0, "legacy_counts": {}, "legacy_counts_complete": True,
                "legacy_sources": {}, "v2_sources": {}, "v2_target_sum": [0.0] * n,
                "modeled_legacy_sum": [0.0] * n, "modeled_invalid_mass_sum": 0.0, "modeled_n": 0,
                "legacy_chosen_hist": [0] * n, "v2_chosen_hist": [0] * n, "fold_count": 0,
                "legacy_invalid_shots": 0, "legacy_shots": 0, "fallback_reasons": {},
                "outcomes": {}, "latency_hist": {"legacy_ms": {}, "router_overhead_us": {}},
                "router_overhead_us_max": 0.0}
        return a

    def _flush_buckets(self, now, final):
        if not self._aggs:
            return
        due = [k for k in self._aggs if final or k[0] + BUCKET_S + 2 <= now]
        if not due:
            return
        lines = []
        for k in sorted(due, key=repr):
            a = self._aggs.pop(k)
            rec = {"schema": SCHEMA_AGGREGATE, "boot_id": self.router.boot_id, "bucket_start": k[0],
                   "bucket_s": BUCKET_S, "context": k[1], "n": k[2], "mode": k[3],
                   "partial": bool(final and k[0] + BUCKET_S > now)}
            rec.update(a)
            lines.append(dumps(rec))
        self._write(self.path("aggregates", "%s.jsonl" % utc_day(now)), lines, fsync=True, key="aggregates")

    def _v2_target(self, scores, n):
        w, pinfo = policy.proportional(scores, n)
        support, p, ninfo = prep.normalize(w, n)
        return w, pinfo, support, p, ninfo

    def _plan_info(self, support, p):
        if 2 <= len(support) <= prep.MAX_CIRCUIT_N:
            pl = prep.plan(p)
            return pl["q"], prep.circuit_hash(pl, p)
        return None, None

    def _legacy_block(self, result, n, scores, fast):
        raw = getattr(result, "source", None)
        src, extra = map_legacy_source(raw)
        blk = {"chosen_index": getattr(result, "chosen_index", None), "source": src,
               "legacy_source_raw": raw, "latency_ms": getattr(result, "latency_ms", None),
               "pick_entropy": extra.get("pick"), "aer_seed": None}
        meas = getattr(result, "measurement", None)
        counts = getattr(result, "measurement_counts", None) or {}
        nq = int(getattr(result, "n_qubits", 0) or 0)
        shots = int(getattr(result, "shots", 0) or 0)
        if src in (Source.AER, Source.IBM_HARDWARE) and isinstance(meas, str) and meas and set(meas) <= {"0", "1"}:
            raw_index = int(meas, 2)
            clean = {}
            for bs, c in dict(counts).items():
                clean[str(bs).replace(" ", "")] = int(c)
            denom = shots or sum(clean.values()) or 1
            size = 1 << nq if nq else 0
            emp = [0.0] * size
            inv = 0
            for bs, c in clean.items():
                i = int(bs, 2)
                if i < size:
                    emp[i] += c / denom
                if i >= n:
                    inv += c
            blk.update(measurement=meas, raw_index=raw_index, folded=raw_index >= n, counts=clean,
                       empirical_p=emp, empirical_invalid_frac=inv / denom,
                       counts_complete=nq <= 4, q=nq, shots=shots)
            if not fast and 2 <= n <= prep.MAX_CIRCUIT_N:
                m = legacy_model.model(n, scores, getattr(result, "brain_state", None),
                                       getattr(result, "region_firing", None))
                blk["modeled"] = {"invalid_mass": m["invalid_mass"], "p": m["p"],
                                  "inputs_complete": m["inputs_complete"],
                                  "cx_margin_ok": m["cx_margin_ok"], "rounding": m["rounding"]}
        return blk

    def _process_shadow(self, item, fast=False):
        (ts, seq, ctx, n, scores, labels, result, lqs, rt, tname, ovh_ns, leg_ns, internal) = item
        did = self._did(seq)
        leg = self._legacy_block(result, n, scores, fast)
        src = leg["source"]
        k = leg["chosen_index"]
        compact = self._compact(did, ts, ctx, n, "shadow", k, src, True, rt, internal, "shadow")
        self._write(self.path("decisions", "%s.d.jsonl" % utc_day(ts)), [compact], key="compact")
        a = self._agg(ts, ctx, n, "shadow")
        a["decisions"] += 1
        a["legacy_sources"][src] = a["legacy_sources"].get(src, 0) + 1
        a["outcomes"]["shadow"] = a["outcomes"].get("shadow", 0) + 1
        if isinstance(k, int) and 0 <= k < n:
            a["legacy_chosen_hist"][k] += 1
        ovh_us = ovh_ns / 1000.0
        _hist_add(a["latency_hist"]["router_overhead_us"], ovh_us, OVERHEAD_EDGES_US)
        a["router_overhead_us_max"] = max(a["router_overhead_us_max"], ovh_us)
        if leg.get("latency_ms") is not None:
            _hist_add(a["latency_hist"]["legacy_ms"], float(leg["latency_ms"]), LEGACY_EDGES_MS)
        if "counts" in leg:
            for bs, c in leg["counts"].items():
                a["legacy_counts"][bs] = a["legacy_counts"].get(bs, 0) + c
            a["legacy_counts_complete"] = a["legacy_counts_complete"] and leg["counts_complete"]
            a["legacy_shots"] += leg.get("shots") or 0
            a["legacy_invalid_shots"] += int(round(leg["empirical_invalid_frac"] * (leg.get("shots") or 0)))
            if leg["folded"]:
                a["fold_count"] += 1
        if internal:
            a["fallback_reasons"][internal] = a["fallback_reasons"].get(internal, 0) + 1
        if fast:
            return
        w, pinfo, support, p, ninfo = self._v2_target(scores, n)
        for i, pi in zip(support, p):
            a["v2_target_sum"][i] += pi
        if "modeled" in leg:
            for i, pi in enumerate(leg["modeled"]["p"]):
                a["modeled_legacy_sum"][i] += pi
            a["modeled_invalid_mass_sum"] += leg["modeled"]["invalid_mass"]
            a["modeled_n"] += 1
        th = None
        if len(support) == 1:
            v2 = {"chosen_index": support[0], "source": Source.TRIVIAL, "u53": None}
        else:
            th = prep.thresholds_u53(p)
            u = secrets.randbits(53)
            v2 = {"chosen_index": support[prep.draw_index(th, u)], "source": Source.OS_ENTROPY, "u53": u}
        a["v2_chosen_hist"][v2["chosen_index"]] += 1
        a["v2_sources"][v2["source"]] = a["v2_sources"].get(v2["source"], 0) + 1
        v2.update(route_reason="shadow_draw", backend=None, shots=1, job_id=None, bitstring=None,
                  valid=True, latency_ms=None, deadline_ms=None, attempted=[v2["source"]],
                  fallback_from=None, fallback_reason=None)
        need_full = ctx != "workspace_access" or internal is not None
        if not need_full:
            self._ws_sample += 1
            need_full = (self._ws_sample % self.router.cfg.shadow_sample_workspace) == 1 \
                or self.router.cfg.shadow_sample_workspace == 1
        if not need_full:
            return
        q, ch = self._plan_info(support, p)
        rec = {"schema": SCHEMA_DECISION, "decision_id": did, "boot_id": self.router.boot_id, "ts": ts,
               "mode": "shadow", "context": ctx, "caller_thread": tname, "realtime": rt, "n": n,
               "support": support, "n_support": len(support),
               "underflow_dropped": ninfo["underflow_dropped"],
               "unreachable_support": prep.unreachable_support(th) if th else 0, "q": q,
               "labels": clip_labels(labels), "labels_sha256": labels_sha256(labels),
               "scores_raw": clean_scores(scores), "policy": pinfo, "target_p": p,
               "thresholds_u53": th, "circuit_hash": ch, "v2": v2, "legacy": leg,
               "decided_by": "legacy", "outcome": "shadow", "flags": self._flags(lqs),
               "neuromodulators": dict(getattr(result, "brain_state", None) or {}),
               "router_overhead_us": ovh_us, "internal_error": internal, "code": self.code_sha}
        self._full(rec)

    def _full(self, rec):
        line = dumps(rec)
        self._write(self.path("decisions", "%s.full.jsonl" % utc_day(rec["ts"])), [line], key="full")
        slim = dict(rec)
        slim.pop("labels", None)
        self._recent.append(slim)

    def _process_record(self, item, fast=False):
        kind = item[0]
        if kind == "auth":
            self._process_auth(item, fast)
        elif kind == "late":
            _, ts, seq, ctx, out = item
            self.writer_counts[(ctx, "authoritative", "aer", None, "late_result")] += 1
            self._full({"schema": SCHEMA_DECISION, "decision_id": self._did(seq),
                        "boot_id": self.router.boot_id, "ts": ts, "context": ctx,
                        "outcome": "late_result", "late": out, "note": "recorded, never used",
                        "code": self.code_sha})
        elif kind == "emergency":
            _, ts, seq, ctx, n, labels, dec, errcls, tname = item
            did = self._did(seq)
            self._write(self.path("decisions", "%s.d.jsonl" % utc_day(ts)),
                        [self._compact(did, ts, ctx, n, "emergency", dec.chosen_index, dec.source,
                                       False, True, "v2_internal_error", "v2_internal_error")],
                        key="compact")
            self._full({"schema": SCHEMA_DECISION, "decision_id": did, "boot_id": self.router.boot_id,
                        "ts": ts, "mode": "emergency", "context": ctx, "caller_thread": tname,
                        "realtime": True, "n": n, "labels_sha256": labels_sha256(labels),
                        "v2": dec.provenance.as_dict(), "decided_by": "v2",
                        "outcome": "v2_internal_error", "error_class": errcls, "code": self.code_sha})
        elif kind == "expired":
            _, ts, it = item
            self.writer_counts[("causal", "causal", "ibm_hardware", None, "expired_unconsumed")] += 1
            self._causal_write([{"kind": "expired_unconsumed", "ts": ts,
                                 "item": {k: it.get(k) for k in ("job_id", "backend", "pub_index",
                                                                 "shot_index", "measured_at",
                                                                 "expires_at", "n")}}])

    def _process_auth(self, item, fast):
        (_, ts, seq, ctx, n, scores, labels, dec, pinfo, ninfo, support, p, th, lqs, rt, tname,
         extra) = item
        did = self._did(seq)
        pv = dec.provenance
        self._write(self.path("decisions", "%s.d.jsonl" % utc_day(ts)),
                    [self._compact(did, ts, ctx, n, pv.route, dec.chosen_index, dec.source, False, rt,
                                   pv.fallback_reason, pv.outcome)], key="compact")
        a = self._agg(ts, ctx, n, pv.route)
        a["decisions"] += 1
        a["v2_chosen_hist"][dec.chosen_index] += 1
        a["v2_sources"][dec.source] = a["v2_sources"].get(dec.source, 0) + 1
        a["outcomes"][pv.outcome] = a["outcomes"].get(pv.outcome, 0) + 1
        for i, pi in zip(support, p):
            a["v2_target_sum"][i] += pi
        if pv.fallback_reason:
            a["fallback_reasons"][pv.fallback_reason] = a["fallback_reasons"].get(pv.fallback_reason, 0) + 1
        _hist_add(a["latency_hist"]["router_overhead_us"], pv.latency_ms * 1000.0, OVERHEAD_EDGES_US)
        if fast:
            return
        need_full = (ctx != "workspace_access" or dec.source in authority.QUANTUM_LABELLED_SOURCES
                     or pv.fallback_reason is not None or pv.outcome != "decided"
                     or pv.route != "authoritative")
        if not need_full:
            self._ws_sample += 1
            need_full = (self._ws_sample % self.router.cfg.shadow_sample_workspace) == 1 \
                or self.router.cfg.shadow_sample_workspace == 1
        if not need_full:
            return
        q, ch = self._plan_info(support, p)
        v2 = pv.as_dict()
        v2["chosen_index"] = dec.chosen_index
        if pv.outcome == "invalid_outcome" and pv.bitstring:
            v2["alarm_invalid_aer"] = True
            v2["all_ones"] = set(pv.bitstring) == {"1"}
        rec = {"schema": SCHEMA_DECISION, "decision_id": did, "boot_id": self.router.boot_id, "ts": ts,
               "mode": pv.route, "context": ctx, "caller_thread": tname, "realtime": rt, "n": n,
               "support": support, "n_support": len(support),
               "underflow_dropped": ninfo["underflow_dropped"],
               "unreachable_support": prep.unreachable_support(th) if th else 0, "q": q,
               "labels": clip_labels(labels), "labels_sha256": labels_sha256(labels),
               "scores_raw": clean_scores(scores), "policy": pinfo, "target_p": p,
               "thresholds_u53": th, "circuit_hash": ch, "v2": v2, "legacy": None,
               "decided_by": "v2", "outcome": pv.outcome, "flags": self._flags(lqs),
               "extra": extra, "code": self.code_sha}
        self._full(rec)

    # ── causal ─────────────────────────────────────────────────────────────
    def _causal_write(self, recs):
        c = self.router._causal
        lines = []
        for r in recs:
            base = {"schema": SCHEMA_CAUSAL, "boot_id": self.router.boot_id}
            if c is not None:
                base.update(entry_id=c.entry["id"], prereg_hash=c.prereg_hash)
            base.update(r)
            lines.append(dumps(base))
        self._write(self.path("causal", "experiments.jsonl"), lines, fsync=True, key="causal")

    def _process_causal(self, item):
        _, ts, seq, ctx, n, labels, r, dec, rt, tname = item
        did = self._did(seq)
        self._causal_write([{"kind": "slot_consumed", "k": r["k"], "arm": r["arm"],
                             "consumed_at": r["consumed_at"], "open_at": r["open_at"],
                             "source": r["source"], "chosen_index": r["index"], "n": n,
                             "bitstring": r.get("bitstring"), "valid": r.get("valid"),
                             "measured_at": (r.get("item") or {}).get("measured_at"),
                             "item": r.get("item"), "fallback_from": r.get("fallback_from"),
                             "fallback_reason": r.get("fallback_reason"),
                             "outcome": r.get("outcome"), "decision_id": did}])
        self._write(self.path("decisions", "%s.d.jsonl" % utc_day(ts)),
                    [self._compact(did, ts, ctx, n, "causal", r["index"], r["source"], False, rt,
                                   r.get("fallback_reason"), r.get("outcome", "decided"))], key="compact")
        self._full({"schema": SCHEMA_DECISION, "decision_id": did, "boot_id": self.router.boot_id,
                    "ts": ts, "mode": "causal", "context": ctx, "caller_thread": tname, "realtime": rt,
                    "n": n, "labels_sha256": labels_sha256(labels), "v2": dec.provenance.as_dict(),
                    "causal": {k: r.get(k) for k in ("entry_id", "prereg_hash", "k", "arm", "open_at",
                                                    "consumed_at", "fallback_from", "fallback_reason")},
                    "decided_by": "v2", "outcome": r.get("outcome", "decided"), "code": self.code_sha})

    def _causal_setup(self, now):
        cfg = self.router.cfg
        if cfg.causal != "on":
            self.causal_status = {"state": "off"}
            return
        from . import causal
        try:
            entries = causal.load_allowlist()
        except (OSError, ValueError) as e:
            self.causal_status = {"state": "inert", "reason": "allowlist_error:" + type(e).__name__}
            return
        results = {}
        chosen = None
        ibm_reasons = self._ibm_prereq_reasons()
        for entry in entries:
            ok, reasons = causal.validate_entry(
                entry, mode=cfg.mode, causal_flag=cfg.causal, gate_ready=cfg.action_gate == "ready",
                now=now, ledger_path=causal.default_migration_ledger(self.router.repo_root),
                ibm_prereq_reasons=ibm_reasons if "ibm_hardware" in (entry.get("arms") or []) else (),
                signer_fpr=authority.CAUSAL_SIGNER_FPR)
            results[entry.get("id")] = {"ok": ok, "reasons": reasons}
            if ok and chosen is None:
                chosen = entry
        self.causal_status = {"state": "inert" if chosen is None else "validated", "entries": results}
        self._counters_write(now, [{"kind": "causal_validation", "entries": results}])
        if chosen is None:
            return
        self._activate(chosen, now)

    def _activate(self, entry, now):
        from . import causal
        ph = entry["prereg_hash"]
        snap = self.path("causal", "prereg", "%s.json" % entry["id"])
        canon = causal.canonical_bytes(entry)
        if os.path.exists(snap):
            with open(snap, "rb") as fh:
                prev = json.load(fh)
            if causal.prereg_hash_of(prev) != ph:
                self.causal_status = {"state": "refused", "reason": "prereg_snapshot_mismatch"}
                return
        elif not self.no_write:
            with open(snap, "wb") as fh:
                fh.write(canon)
                fh.flush()
                os.fsync(fh.fileno())
        recs = []
        p = self.path("causal", "experiments.jsonl")
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as fh:
                for line in fh:
                    try:
                        recs.append(json.loads(line))
                    except ValueError:
                        continue
        act = [r for r in recs if r.get("kind") == "activation" and r.get("entry_id") == entry["id"]
               and r.get("prereg_hash") == ph]
        activation_ts = float(act[0]["activation_ts"]) if act else now
        sched = causal.CausalScheduler(entry, ph, activation_ts, clock=self.clock)
        sched.replay(recs)
        ctl = causal.CausalController(entry, ph, sched, clock=self.clock)
        r = self.router
        if r._aer is None:
            from .backends import AerBackend
            r._aer = AerBackend(r.cfg.aer_deadline_ms)
        ctl.aer = r._aer
        if "ibm_hardware" in entry.get("arms", ()) and not self._ibm_prereq_reasons():
            from .backends import IbmBroker
            from .ibm_runner import IbmRunner
            from .ledger import IbmLedger, default_budget_path
            broker = IbmBroker(
                state_dir=self.dir, entry=entry, runner=IbmRunner(repo_root=r.repo_root),
                ledger=IbmLedger(self.path("ibm_ledger.jsonl")),
                lock_factory=lambda: filelock.open_lock(self.path("ibm.lock")), clock=self.clock,
                repo_root=r.repo_root, budget_path=default_budget_path(r.repo_root),
                record=lambda kind, it: r._record_q.append(("expired", self.clock(), it)))
            ctl.broker = broker
            r._broker = broker
            broker.start()
        r._causal = ctl
        if not act:
            self._causal_write([{"kind": "activation", "activation_ts": activation_ts, "ts": now}])
        r._causal_active = True
        self.causal_status = {"state": "active", "entry_id": entry["id"],
                              "broker": r._broker is not None}

    def _ibm_prereq_reasons(self):
        reasons = []
        if os.path.realpath(self.dir) != os.path.realpath(authority.IBM_CANONICAL_STATE_DIR):
            reasons.append("state_dir_not_canonical")
        if not authority.f5_satisfied(self.router.repo_root):
            reasons.append("f5_not_satisfied")
        if not filelock.available():
            reasons.append("filelock_unavailable")
        if self.no_write:
            reasons.append("writer_no_write")
        return reasons

    def _causal_tick(self, now):
        c = self.router._causal
        if c is None:
            return
        recs = c.scheduler.tick(now)
        if recs:
            self._causal_write(recs)
            for r in recs:
                if r.get("kind") == "slot_open" and r.get("arm") == "aer":
                    c.request_aer(now)
