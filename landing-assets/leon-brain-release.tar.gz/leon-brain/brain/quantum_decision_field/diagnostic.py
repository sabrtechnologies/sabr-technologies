"""Out-of-process DIAGNOSTIC CLI (spec 6.4). Never feeds a decision.

    python3 -s -m brain.quantum_decision_field.diagnostic \\
        --backend {reference,statevector,aer} --sweep default --shots 100000 \\
        [--seed S | --seed-from-date] [--confirm-stat-failures]

Per circuit:
  (a) reference invalid amplitude == 0.0 bitwise
  (b) logical Statevector invalid entries == 0            (statevector, aer)
  (c) opt-1 transpiled invalid mass <= 1e-20, cz and ecr   (statevector, aer)
      opt-3 mass is reported for information only; never used in production
  (d) Aer invalid_count == 0 (bitstrings kept, all-ones flagged)     (aer)
  (e) pooled chi-square, pass if p >= 1e-3/k (Bonferroni); TVD reported (aer)

Invariant failures (a)-(d) fail immediately (exit 1). A statistical failure
triggers one confirmation run with a seed derived from "...|confirm"; the
verdict is "fail" only if both fail, else "stat_warn".

Activity gate: defers (recorded) when activity.json is missing, older than
120 s, or shows a last user message under 300 s ago; re-checks between
circuits and aborts with verdict "aborted_user_turn".

Records (qv2.diagnostic/2) go to diagnostics.jsonl under diag.lock: a
"started" record first and a "final" record last. A missing "final" means the
run was killed, and that null is kept.

Manual only, never scheduled: ``--backend ibm_hardware --max-jobs 1
--i-understand-this-spends-ibm-quota`` submits ONE calibration job (N=3, 5, 4
uniform, 4000 shots each) behind the full submit gate with the diagnostic
sub-cap; ``--collect-ibm`` later polls it and records verdict "calibration".
"""
import argparse
import datetime
import hashlib
import json
import os
import math
import sys
import time

for _k, _v in (("QISKIT_PARALLEL", "FALSE"), ("QISKIT_NUM_PROCS", "1"), ("OMP_NUM_THREADS", "1"),
               ("OPENBLAS_NUM_THREADS", "1")):
    os.environ.setdefault(_k, _v)

from . import authority, filelock, legacy_model, prep, stats  # noqa: E402
from .config import default_state_dir  # noqa: E402
from .provenance import SCHEMA_DIAGNOSTIC  # noqa: E402

SWEEP_N = (2, 3, 4, 5, 6, 7, 8, 9, 12, 16, 17, 31, 33, 100)
SMALL_SWEEP_N = (3, 5, 8)
SETS = ("uniform", "geometric", "near_tie", "sparse")
ACTIVITY_MAX_AGE_S = 120
USER_QUIET_S = 300
IBM_CAL_PUBS = ((3, 4000), (5, 4000), (4, 4000))
CZ_BASIS = ["cz", "rz", "sx", "x"]
ECR_BASIS = ["ecr", "rz", "sx", "x"]
SEED_MASK = (1 << 63) - 1


def sweep_weights(kind, n):
    """Libm-free sweep weights; all strictly positive except 'sparse'."""
    if kind == "uniform":
        return [1.0] * n
    if kind == "geometric":
        w, x = [], 1.0
        for _ in range(n):
            w.append(x)
            x = x * 0.7
        return w
    if kind == "near_tie":
        return [1.0 - 0.2 * i / (n - 1) for i in range(n)]
    if kind == "sparse":
        return [0.0 if i % 3 == 2 else float(i + 1) for i in range(n)]
    raise ValueError(kind)


def seed_from_date(day, suffix=""):
    return int.from_bytes(hashlib.sha256(("qv2-diag|%s%s" % (day, suffix)).encode()).digest()[:8],
                          "big") & SEED_MASK


def _now_day():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")


# ── activity gate ────────────────────────────────────────────────────────────

def activity_ok(state_dir, now=None):
    now = time.time() if now is None else now
    try:
        with open(os.path.join(state_dir, "activity.json"), "r", encoding="utf-8") as fh:
            a = json.load(fh)
    except (OSError, ValueError):
        return False, "activity_missing"
    ts = a.get("ts")
    if (type(ts) not in (int, float) or not math.isfinite(ts) or
            not 0 <= now - ts <= ACTIVITY_MAX_AGE_S):
        return False, "activity_stale"
    age = a.get("last_user_message_age_s")
    if type(age) not in (int, float) or not math.isfinite(age) or age < 0:
        return False, "activity_unknown"
    if age < USER_QUIET_S:
        return False, "user_active"
    return True, "ok"


# ── records ──────────────────────────────────────────────────────────────────

class DiagWriter:
    def __init__(self, state_dir):
        self.state_dir = state_dir
        self.path = os.path.join(state_dir, "diagnostics.jsonl")
        self.run_id = hashlib.sha256(os.urandom(16)).hexdigest()[:16]

    def write(self, kind, **fields):
        rec = {"schema": SCHEMA_DIAGNOSTIC, "kind": kind, "run_id": self.run_id, "ts": time.time()}
        rec.update(fields)
        os.makedirs(self.state_dir, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, sort_keys=True, default=str) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        return rec


# ── per-circuit checks ─────────────────────────────────────────────────────

def _info_only_opt3_mass(qc, n_support, basis):
    """Opt-3 invalid mass, reported for information only (it can exceed
    1e-20). Production code never transpiles above optimization_level=1."""
    from qiskit import transpile
    t3 = transpile(qc, basis_gates=basis, optimization_level=3, seed_transpiler=7)
    return prep.transpiled_invalid_mass(t3, n_support)


def check_circuit(kind, n, backend, shots, seed, k_circuits):
    w = sweep_weights(kind, n)
    support, p, info = prep.normalize(w, n)
    res = {"set": kind, "N": n, "n_support": len(support), "underflow_dropped": info["underflow_dropped"],
           "invariant_ok": True, "stat_ok": True, "failures": []}
    if len(support) < 2:
        res["trivial"] = True
        return res
    pl = prep.plan(p)
    res.update(q=pl["q"], circuit_hash=prep.circuit_hash(pl, p))
    amps = prep.reference_amplitudes(pl)
    a_ok = all(a == 0.0 for a in amps[len(support):])
    res["a_reference_invalid_zero"] = a_ok
    if not a_ok:
        res["invariant_ok"] = False
        res["failures"].append("a_reference")
    if backend == "reference":
        return res
    from qiskit.quantum_info import Statevector
    qc_logical = prep.build_qiskit_circuit(pl, measure=False)
    sv = Statevector(qc_logical).data.tolist()
    b_ok = all(x == 0 for x in sv[len(support):])
    res["b_logical_invalid_zero"] = b_ok
    if not b_ok:
        res["invariant_ok"] = False
        res["failures"].append("b_logical")
    qc = prep.build_qiskit_circuit(pl)
    masses = {}
    for name, basis in (("cz", CZ_BASIS), ("ecr", ECR_BASIS)):
        t1 = prep.transpile_one(qc, basis_gates=basis, seed_transpiler=7)
        masses[name] = prep.transpiled_invalid_mass(t1, len(support))
        res["twoq_%s" % name] = prep.two_qubit_gate_count(t1)
    res["c_transpiled_opt1_mass"] = masses
    if any(not (m <= prep.TRANSPILED_INVALID_MASS_MAX) for m in masses.values()):
        res["invariant_ok"] = False
        res["failures"].append("c_transpiled")
    try:
        res["info_opt3_mass_cz"] = _info_only_opt3_mass(qc, len(support), CZ_BASIS)
    except Exception as e:
        res["info_opt3_mass_cz"] = "error:" + type(e).__name__
    if backend != "aer":
        return res
    run = run_aer(pl, len(support), shots, seed)
    res.update(aer=run["meta"])
    if run["invalid_count"]:
        res["invariant_ok"] = False
        res["failures"].append("d_aer_invalid")
    res["d_aer_invalid_count"] = run["invalid_count"]
    res["d_invalid_bitstrings"] = run["invalid_bitstrings"]
    chi = stats.chi_square_pooled(run["valid_counts"], p)
    res["e_chi2"] = chi
    res["tvd"] = stats.tvd(stats.normalize_counts(run["valid_counts"]), p)
    alpha = 1e-3 / max(k_circuits, 1)
    if chi["p"] is not None and chi["p"] < alpha:
        res["stat_ok"] = False
    res["alpha_bonferroni"] = alpha
    return res


def run_aer(pl, n_support, shots, seed):
    from qiskit_aer import AerSimulator
    sim = AerSimulator(method="statevector", max_parallel_threads=1, max_parallel_experiments=1,
                       seed_simulator=seed)
    qc = prep.build_qiskit_circuit(pl)
    tseed = seed & 0x7FFFFFFF
    tqc = prep.transpile_one(qc, backend=sim, seed_transpiler=tseed)
    mass = prep.verify_transpiled(tqc, n_support)
    counts = sim.run(tqc, shots=shots, seed_simulator=seed).result().get_counts(0)
    valid = [0] * n_support
    inv, inv_bs = 0, {}
    for bs, c in counts.items():
        bs = bs.replace(" ", "")
        b, ok = prep.decode_bitstring(bs, n_support)
        if ok:
            valid[b] += c
        else:
            inv += c
            inv_bs[bs] = {"count": c, "all_ones": set(bs) == {"1"}}
    return {"valid_counts": valid, "invalid_count": inv, "invalid_bitstrings": inv_bs,
            "meta": {"seed_simulator": seed, "transpile_seed": tseed, "verified_mass": mass,
                     "shots": shots}}


def legacy_rows(journal_path):
    """Legacy characterization from the latest neuromodulator snapshot in the
    legacy journal tail (read-only)."""
    nm, src = None, "defaults"
    try:
        with open(journal_path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - 65536))
            tail = fh.read().decode("utf-8", "replace").splitlines()
        for line in reversed(tail):
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            if isinstance(rec, dict) and isinstance(rec.get("brain_state"), dict):
                nm, src = rec["brain_state"], "journal_tail"
                break
    except OSError:
        pass
    rows = []
    for n in (3, 4, 5, 6, 7, 8):
        m = legacy_model.model(n, [0.5] * n, nm, {})
        rows.append({"N": n, "scores": "equal", "invalid_mass": m["invalid_mass"],
                     "p_folded": m["p"], "tvd_from_uniform": legacy_model.tvd(m["p"], [1.0 / n] * n),
                     "fold_uniform_tvd": legacy_model.tvd(legacy_model.fold_of_uniform(n), [1.0 / n] * n)})
    return {"neuromodulators": nm, "neuromodulator_source": src, "rows": rows}


def _cpu_seconds():
    try:
        import resource
        r = resource.getrusage(resource.RUSAGE_SELF)
        return r.ru_utime + r.ru_stime
    except Exception:
        return time.process_time()


def run_sweep(args, state_dir, now_fn=time.time, check=check_circuit):
    w = DiagWriter(state_dir)
    lock = filelock.open_lock(os.path.join(state_dir, "diag.lock")) or filelock.InProcessLock(
        os.path.join(state_dir, "diag.lock"))
    if not lock.acquire(blocking=False):
        print("diag.lock held by another run; exiting", file=sys.stderr)
        return 3
    try:
        day = _now_day()
        seed = args.seed if args.seed is not None else (seed_from_date(day) if args.seed_from_date else 12345)
        ns = SMALL_SWEEP_N if args.sweep == "small" else SWEEP_N
        cases = [(kind, n) for n in ns for kind in SETS]
        cpu0 = _cpu_seconds()
        base = {"backend": args.backend, "sweep": args.sweep, "shots": args.shots, "seed": seed,
                "seed_from_date": bool(args.seed_from_date), "day": day}
        if not args.skip_activity_gate:
            ok, why = activity_ok(state_dir, now_fn())
            if not ok:
                w.write("deferred", reason=why, **base)
                return 0
        w.write("started", circuits=len(cases), **base)

        def one_pass(pass_seed):
            results = []
            for i, (kind, n) in enumerate(cases):
                if not args.skip_activity_gate and i:
                    ok, why = activity_ok(state_dir, now_fn())
                    if not ok:
                        return results, why
                results.append(check(kind, n, args.backend, args.shots,
                                     (pass_seed + 7919 * i) & SEED_MASK, len(cases)))
            return results, None

        results, abort = one_pass(seed)
        final = dict(base)
        final["legacy_characterization"] = legacy_rows(args.legacy_journal)
        if abort is not None:
            final.update(verdict="aborted_user_turn", reason=abort, results=results,
                         cpu_seconds=_cpu_seconds() - cpu0)
            w.write("final", **final)
            return 0
        inv_fail = [r for r in results if not r["invariant_ok"]]
        stat_fail = [r for r in results if not r["stat_ok"]]
        verdict = "pass"
        confirm = None
        if inv_fail:
            verdict = "fail"
        elif stat_fail:
            if args.confirm_stat_failures:
                cseed = seed_from_date(day, "|confirm") if args.seed_from_date else (seed ^ 0x5DEECE66D) & SEED_MASK
                cres, cabort = one_pass(cseed)
                confirm = {"seed": cseed, "stat_fail": [(r["set"], r["N"]) for r in cres if not r["stat_ok"]],
                           "aborted": cabort}
                verdict = "fail" if confirm["stat_fail"] and not cabort else "stat_warn"
            else:
                verdict = "stat_warn"
        final.update(verdict=verdict, results=results, confirmation=confirm,
                     invariant_failures=[(r["set"], r["N"], r["failures"]) for r in inv_fail],
                     stat_failures=[(r["set"], r["N"]) for r in stat_fail],
                     cpu_seconds=_cpu_seconds() - cpu0)
        w.write("final", **final)
        return 1 if inv_fail else 0
    finally:
        lock.release()


# ── manual IBM calibration (never scheduled) ─────────────────────────────────

def run_ibm_calibration(args, state_dir, runner=None, canonical_dir=None, repo_root=None,
                        budget_path=None, now_fn=time.time):
    from .ledger import IbmLedger, submit_gate, usage_allows_submit, default_budget_path
    from .ibm_runner import IbmRunner, RunnerError
    if not args.i_understand_this_spends_ibm_quota or args.max_jobs != 1:
        print("refused: --max-jobs 1 --i-understand-this-spends-ibm-quota are required", file=sys.stderr)
        return 2
    runner = runner or IbmRunner(repo_root=repo_root)
    canonical_dir = authority.IBM_CANONICAL_STATE_DIR if canonical_dir is None else canonical_dir
    w = DiagWriter(state_dir)
    lock = filelock.open_lock(os.path.join(state_dir, "ibm.lock"))
    if lock is None:
        w.write("final", backend="ibm_hardware", verdict="refused", reason="filelock_unavailable")
        return 2
    if not lock.acquire(blocking=False):
        w.write("final", backend="ibm_hardware", verdict="refused", reason="ibm_lock_busy")
        return 2
    try:
        led = IbmLedger(os.path.join(state_dir, "ibm_ledger.jsonl"))
        now = now_fn()
        st = led.replay(now)
        ok, reason = submit_gate(st, purpose="diagnostic", now=now, state_dir=state_dir,
                                 canonical_dir=canonical_dir, lock_held=lock.held,
                                 ibm_disabled=os.path.exists(os.path.join(state_dir, "IBM_DISABLED")),
                                 repo_root=repo_root,
                                 budget_path=budget_path or default_budget_path(repo_root))
        if not ok:
            w.write("final", backend="ibm_hardware", verdict="refused", reason=reason)
            return 2
        try:
            lines = runner.run("usage", {})
        except RunnerError as e:
            led.append("error", ts=now, op="usage", purpose="diagnostic", error_class=e.error_class,
                       error_digest=e.error_digest)
            w.write("final", backend="ibm_hardware", verdict="refused", reason="usage_error")
            return 2
        usage = next((x for x in reversed(lines) if x.get("op") == "usage"), None)
        led.append("usage", ts=now, purpose="diagnostic", **{k: v for k, v in (usage or {}).items() if k != "op"})
        ok, why = usage_allows_submit(usage)
        if not ok:
            w.write("final", backend="ibm_hardware", verdict="refused", reason="usage:" + why)
            return 2
        attempt_id = hashlib.sha256(os.urandom(16)).hexdigest()[:32]
        pubs = [{"n": n, "shots": s} for n, s in IBM_CAL_PUBS]
        led.append("submit_attempt", ts=now, attempt_id=attempt_id, purpose="diagnostic", entry_id=None,
                   pubs=pubs, shots=sum(s for _, s in IBM_CAL_PUBS))
        seen = {}

        def on_line(obj):
            if "job_id" in obj and "job_id" not in seen:
                seen["job_id"] = obj["job_id"]
                led.append("submitted", ts=now, attempt_id=attempt_id, job_id=obj["job_id"],
                           backend=obj.get("backend"), circuit_hashes=obj.get("circuit_hashes"),
                           transpiled_sha256=obj.get("transpiled_sha256"), twoq_gates=obj.get("twoq_gates"))
        try:
            runner.run("submit", {"attempt_id": attempt_id, "pubs": pubs,
                                  "seed_transpiler": int(attempt_id[:8], 16)}, on_line=on_line)
        except RunnerError as e:
            led.append("error", ts=now, op="submit", purpose="diagnostic", attempt_id=attempt_id,
                       error_class=e.error_class, error_digest=e.error_digest)
        w.write("final", backend="ibm_hardware", verdict="calibration_submitted", attempt_id=attempt_id,
                job_id=seen.get("job_id"))
        return 0
    finally:
        lock.release()


def collect_ibm_calibration(state_dir, runner=None, repo_root=None, now_fn=time.time):
    """Poll in-flight diagnostic attempts under ibm.lock; record the
    calibration report when a job is done, cancel it past the TTL."""
    from .ledger import IbmLedger
    from .ibm_runner import IbmRunner, RunnerError
    runner = runner or IbmRunner(repo_root=repo_root)
    w = DiagWriter(state_dir)
    lock = filelock.open_lock(os.path.join(state_dir, "ibm.lock"))
    if lock is None or not lock.acquire(blocking=False):
        return 2
    try:
        led = IbmLedger(os.path.join(state_dir, "ibm_ledger.jsonl"))
        now = now_fn()
        for att in led.replay(now).in_flight:
            if att.purpose != "diagnostic" or not att.job_id:
                continue
            if now >= att.ts + authority.IBM_JOB_TTL_S:
                try:
                    runner.run("cancel", {"job_id": att.job_id})
                    led.append("cancel", ts=now, attempt_id=att.attempt_id, job_id=att.job_id, reason="ttl")
                    led.append("expired_cancelled", ts=now, attempt_id=att.attempt_id, job_id=att.job_id)
                except RunnerError as e:
                    led.append("cancel_failed", ts=now, attempt_id=att.attempt_id, job_id=att.job_id,
                               error_class=e.error_class, error_digest=e.error_digest)
                continue
            try:
                lines = runner.run("poll", {"job_id": att.job_id})
            except RunnerError as e:
                led.append("error", ts=now, op="poll", purpose="diagnostic", attempt_id=att.attempt_id,
                           error_class=e.error_class, error_digest=e.error_digest)
                continue
            res = next((x for x in reversed(lines) if "status" in x), {})
            led.append("poll", ts=now, attempt_id=att.attempt_id, job_id=att.job_id,
                       status=str(res.get("status")))
            if str(res.get("status", "")).upper().endswith("DONE"):
                led.append("done", ts=now, attempt_id=att.attempt_id, job_id=att.job_id,
                           qpu_seconds=res.get("qpu_seconds"))
                rep = calibration_report([p.get("bitstrings") or [] for p in res.get("pubs") or []])
                w.write("final", backend="ibm_hardware", attempt_id=att.attempt_id, job_id=att.job_id,
                        **rep)
        return 0
    finally:
        lock.release()


def calibration_report(pubs_bitstrings):
    """Invalid-outcome rate per circuit, chi-square conditional on validity, TVD."""
    out = []
    for (n, _shots), bits in zip(IBM_CAL_PUBS, pubs_bitstrings):
        valid = [0] * n
        inv = 0
        for bs in bits:
            b, ok = prep.decode_bitstring(bs, n)
            if ok:
                valid[b] += 1
            else:
                inv += 1
        p = [1.0 / n] * n
        out.append({"N": n, "shots": len(bits), "invalid_rate": inv / max(len(bits), 1),
                    "chi2_given_valid": stats.chi_square_pooled(valid, p),
                    "tvd_given_valid": stats.tvd(stats.normalize_counts(valid), p)})
    return {"verdict": "calibration", "pubs": out}


def main(argv=None):
    ap = argparse.ArgumentParser(prog="brain.quantum_decision_field.diagnostic")
    ap.add_argument("--backend", choices=("reference", "statevector", "aer", "ibm_hardware"), required=True)
    ap.add_argument("--sweep", choices=("default", "small"), default="default")
    ap.add_argument("--shots", type=int, default=100000)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--seed", type=int)
    g.add_argument("--seed-from-date", action="store_true")
    ap.add_argument("--confirm-stat-failures", action="store_true")
    ap.add_argument("--state-dir", default=None)
    ap.add_argument("--legacy-journal", default=os.path.join(authority.REPO_ROOT, "brain_state",
                                                             "conscious_decisions.jsonl"))
    ap.add_argument("--skip-activity-gate", action="store_true",
                    help="off-box/test runs only; the scheduled unit never passes it")
    ap.add_argument("--max-jobs", type=int, default=0)
    ap.add_argument("--i-understand-this-spends-ibm-quota", action="store_true")
    ap.add_argument("--collect-ibm", action="store_true")
    args = ap.parse_args(argv)
    sd = os.environ.get("LEON_QV2_STATE_DIR") or args.state_dir or default_state_dir()
    sd = os.path.realpath(args.state_dir) if args.state_dir else os.path.realpath(sd)
    if args.backend == "ibm_hardware":
        if args.collect_ibm:
            return collect_ibm_calibration(sd)
        return run_ibm_calibration(args, sd)
    return run_sweep(args, sd)


if __name__ == "__main__":
    sys.exit(main())
