"""Launch and bound the IBM child process (spec 7.2).

* Command: ``systemd-run --scope ... -p MemoryMax=512M -p CPUQuota=25%
  --nice=10 -- <python> -s -m brain.quantum_decision_field.ibm_subprocess
  <op>`` when running as root on Linux with systemd-run available; otherwise
  the child is launched directly.
* ``Popen(start_new_session=True)``, no ``preexec_fn``, stdin/stdout/stderr
  pipes, a minimal environment.
* stdout is read line by line with ``selectors`` against the deadline, so a
  ``{"job_id": ...}`` line printed right after ``run()`` survives a later kill.
* On timeout: ``os.killpg(pgid, SIGKILL)`` plus ``systemctl stop <unit>.scope``.
* The token is never in argv; stderr is redacted and truncated to 300 chars.
"""
import hashlib
import json
import os
import re
import selectors
import shutil
import signal
import subprocess
import sys
import time
import uuid

from . import authority

CHILD_MODULE = "brain.quantum_decision_field.ibm_subprocess"
ENV_PASS = ("PATH", "HOME", "IBM_QUANTUM_TOKEN", "IBM_QUANTUM_INSTANCE", "LANG")
ENV_LIMITS = {"QISKIT_PARALLEL": "FALSE", "QISKIT_NUM_PROCS": "1", "OMP_NUM_THREADS": "1",
              "OPENBLAS_NUM_THREADS": "1", "RAYON_NUM_THREADS": "1"}
SECRET_ENV = ("IBM_QUANTUM_TOKEN",)
STDERR_CAP = 65536
STDOUT_CAP = 2 * 1024 * 1024
LINE_CAP = 1024
INPUT_CAP = 4096
REDACT_MAX = 300
_TOKENLIKE = re.compile(r"[A-Za-z0-9_\-\.=+/]{32,}")


class RunnerError(Exception):
    def __init__(self, error_class, digest, lines=()):
        super().__init__(error_class)
        self.error_class = error_class
        self.error_digest = digest
        self.lines = list(lines)


class RunnerTimeout(RunnerError):
    pass


def redact(text, secrets_=()):
    text = text or ""
    for s in secrets_:
        if s:
            text = text.replace(s, "[REDACTED]")
    text = _TOKENLIKE.sub("[REDACTED]", text)
    return text[:REDACT_MAX]


def digest(text):
    return hashlib.sha256((text or "").encode("utf-8", "replace")).hexdigest()[:16]


def minimal_env(source=None):
    source = os.environ if source is None else source
    env = {k: source[k] for k in ENV_PASS if source.get(k)}
    env.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
    env.setdefault("LANG", "C.UTF-8")
    env.update(ENV_LIMITS)
    return env


def scope_available():
    return (sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0
            and shutil.which("systemd-run") is not None)


class IbmRunner:
    def __init__(self, repo_root=None, python=None, use_scope=None, popen=None,
                 child_argv=None, env_source=None, clock=time.monotonic):
        self.repo_root = repo_root or authority.REPO_ROOT
        self.python = python or sys.executable
        self.use_scope = scope_available() if use_scope is None else use_scope
        self._popen = popen or subprocess.Popen
        self._child_argv = child_argv            # tests: a fake child command
        self._env_source = env_source
        self._clock = clock
        self._live = None
        self._live_unit = None

    def build_command(self, op, unit):
        if self._child_argv is not None:
            base = list(self._child_argv) + [op]
        else:
            base = [self.python, "-s", "-m", CHILD_MODULE, op]
        if not self.use_scope:
            return base
        return ["systemd-run", "--scope", "--quiet", "--collect", "--unit=" + unit,
                "-p", "MemoryMax=512M", "-p", "CPUQuota=25%", "--nice=10", "--"] + base

    def available(self):
        return self._child_argv is not None or bool(self.python)

    def _secrets(self, env):
        return [env.get(k) for k in SECRET_ENV if env.get(k)]

    def run(self, op, payload, timeout_s=None, on_line=None):
        """Run one child operation. Returns the list of JSON lines printed.
        Raises RunnerTimeout / RunnerError (with redacted digests only)."""
        timeout_s = authority.IBM_TIMEOUTS_S.get(op, 30) if timeout_s is None else timeout_s
        if op not in authority.IBM_TIMEOUTS_S:
            raise ValueError("unsupported IBM operation")
        if not 0 < timeout_s <= 120:
            raise ValueError("invalid child deadline")
        encoded = json.dumps(payload or {}, allow_nan=False).encode()
        if len(encoded) > INPUT_CAP:
            raise ValueError("IBM child payload too large")
        unit = "leon-qv2-ibm-" + uuid.uuid4().hex[:8]
        env = minimal_env(self._env_source)
        secrets_ = self._secrets(env)
        cmd = self.build_command(op, unit)
        p = self._popen(cmd, start_new_session=True, cwd=self.repo_root,
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE, env=env)
        self._live, self._live_unit = p, (unit if self.use_scope else None)
        lines, buf, err = [], b"", b""
        sel, output_bytes = None, 0
        deadline = self._clock() + timeout_s
        try:
            try:
                p.stdin.write(encoded)
                p.stdin.close()
            except (BrokenPipeError, OSError):
                pass
            sel = selectors.DefaultSelector()
            sel.register(p.stdout, selectors.EVENT_READ, "out")
            sel.register(p.stderr, selectors.EVENT_READ, "err")
            open_streams = 2
            while open_streams:
                remaining = deadline - self._clock()
                if remaining <= 0:
                    self._kill(p)
                    raise RunnerTimeout("timeout_" + op, digest(redact(err.decode("utf-8", "replace"), secrets_)), lines)
                for key, _ in sel.select(timeout=min(remaining, 0.5)):
                    chunk = os.read(key.fileobj.fileno(), 65536)
                    if not chunk:
                        sel.unregister(key.fileobj)
                        open_streams -= 1
                        continue
                    if key.data == "err":
                        if len(err) < STDERR_CAP:
                            err += chunk[:STDERR_CAP - len(err)]
                        continue
                    output_bytes += len(chunk)
                    if output_bytes > STDOUT_CAP:
                        raise RunnerError("stdout_limit", digest("stdout_limit"), lines)
                    buf += chunk
                    while b"\n" in buf:
                        raw, buf = buf.split(b"\n", 1)
                        raw = raw.strip()
                        if not raw:
                            continue
                        if len(lines) >= LINE_CAP:
                            raise RunnerError("line_limit", digest("line_limit"), lines)
                        try:
                            obj = json.loads(raw.decode("utf-8", "replace"))
                        except ValueError:
                            obj = {"unparsed": redact(raw.decode("utf-8", "replace"), secrets_)}
                        lines.append(obj)
                        if on_line is not None:
                            on_line(obj)
            sel.close()
            remaining = max(0.0, deadline - self._clock())
            try:
                rc = p.wait(timeout=max(remaining, 0.1))
            except subprocess.TimeoutExpired:
                self._kill(p)
                raise RunnerTimeout("timeout_" + op, digest(""), lines) from None
            if rc != 0:
                text = redact(err.decode("utf-8", "replace"), secrets_)
                raise RunnerError("child_exit_%d" % rc, digest(text), lines)
            return lines
        finally:
            # Callback errors and malformed/flooding children must not orphan
            # an SDK process after the caller stops observing it.
            if p.poll() is None:
                self._kill(p)
            if sel is not None:
                sel.close()
            for s in (p.stdin, p.stdout, p.stderr):
                try:
                    s.close()
                except Exception:
                    pass
            self._live, self._live_unit = None, None

    def _kill(self, p, blocking=True):
        try:
            os.killpg(p.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError):
            pass
        unit = self._live_unit
        if unit:
            try:
                cmd = ["systemctl", "stop", unit + ".scope"]
                if blocking:
                    subprocess.run(cmd, timeout=10, capture_output=True)
                else:
                    subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                     start_new_session=True)
            except Exception:
                pass
        if blocking:
            try:
                p.wait(timeout=5)
            except Exception:
                pass

    def kill_live(self):
        """Kill a running child's process group without waiting (close())."""
        p = self._live
        if p is not None and p.poll() is None:
            self._kill(p, blocking=False)
            return True
        return False
