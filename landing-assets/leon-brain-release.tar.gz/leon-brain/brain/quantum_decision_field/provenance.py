"""Source vocabulary, legacy-source mapping, decision objects, record schemas.

``V2Decision.quantum_decided`` and ``V2Decision.authorizes_action`` are class
constants ``False`` for every source (spec I8): a V2 decision is a signal and
never carries a quantum label into prompts, history or action planning.
Provenance lives only in V2 records and the status endpoint.

Aer is always described as a classical simulator with a PRNG.
"""
from dataclasses import dataclass

# ── Schemas ──────────────────────────────────────────────────────────────────
SCHEMA_COMPACT = "qv2.d/1"
SCHEMA_DECISION = "qv2.decision/2"
SCHEMA_DIAGNOSTIC = "qv2.diagnostic/2"
SCHEMA_CAUSAL = "qv2.causal/2"
SCHEMA_ANALYSIS = "qv2.analysis/2"
SCHEMA_COUNTERS = "qv2.counters/1"
SCHEMA_AGGREGATE = "qv2.aggregate/1"
SCHEMA_IBM_LEDGER = "qv2.ibm_ledger/1"


class Source:
    PRNG = "prng"                       # seeded random.Random: tests, replay, diagnostics only
    OS_ENTROPY = "os_entropy"           # secrets.randbits(53) + exact thresholds
    CLASSICAL_WEIGHTED = "classical_weighted"   # legacy engine's classical fallback
    AER = "aer"                         # AerSimulator: a classical simulator with a PRNG
    IBM_HARDWARE = "ibm_hardware"       # one physical measurement on an IBM QPU
    TRIVIAL = "trivial"                 # N' = 1, no draw
    UNKNOWN = "unknown"


SOURCES = frozenset(v for k, v in vars(Source).items() if not k.startswith("_"))
SOURCE_DESCRIPTIONS = {
    Source.PRNG: "seeded random.Random inverse CDF (tests, replay, diagnostics only)",
    Source.OS_ENTROPY: "secrets.randbits(53) with exact integer thresholds",
    Source.CLASSICAL_WEIGHTED: "legacy engine classical fallback",
    Source.AER: "AerSimulator outcome: a classical simulator with a PRNG",
    Source.IBM_HARDWARE: "one physical measurement on an IBM QPU",
    Source.TRIVIAL: "single supported choice, no draw",
}

# Route kinds ("m" in compact lines, "mode" in full records).
ROUTE_SHADOW = "shadow"                 # legacy decided; V2 observed
ROUTE_AUTHORITATIVE = "authoritative"   # V2 decided (mode on, context authoritative)
ROUTE_CAUSAL = "causal"                 # a pre-registered causal slot decided
ROUTE_GUARD = "guard"                   # IBM realtime guard: V2 decided instead of legacy
ROUTE_EMERGENCY = "emergency"           # V2-internal error on a realtime caller

ROUTE_REASONS = ("realtime_policy", "backend_classical", "backend_aer", "shadow_draw",
                 "causal_arm", "legacy_ibm_on_realtime_refused", "emergency_uniform")

OUTCOMES = ("shadow", "decided", "trivial", "invalid_outcome", "late_result",
            "expired_unconsumed", "v2_internal_error", "missed", "gap", "policy_refused")

_LEGACY_FAST = {"simulator:aer": Source.AER, "classical:weighted": Source.CLASSICAL_WEIGHTED,
                "trivial:single_candidate": Source.TRIVIAL}


def legacy_source_fast(raw):
    """Caller-path mapping: a dict hit for the common strings, else the full map."""
    s = _LEGACY_FAST.get(raw)
    return s if s is not None else map_legacy_source(raw)[0]


def map_legacy_source(raw):
    """Legacy source string -> (V2 source, extra fields)."""
    if not isinstance(raw, str) or not raw:
        return Source.UNKNOWN, {"legacy": 1}
    if raw.startswith("simulator:"):
        return Source.AER, {"legacy": 1, "pick": "quantum_rng_buffer"}
    if raw.startswith("classical"):
        return Source.CLASSICAL_WEIGHTED, {"legacy": 1, "pick": "quantum_rng_buffer"}
    if raw.startswith("ibm:"):
        return Source.IBM_HARDWARE, {"legacy": 1, "pick": "quantum_rng_buffer",
                                     "backend": raw[4:]}
    if raw.startswith("trivial"):
        return Source.TRIVIAL, {"legacy": 1}
    return Source.UNKNOWN, {"legacy": 1}


@dataclass(frozen=True)
class Provenance:
    decision_seq: int
    source: str
    route: str
    route_reason: str
    context: str
    realtime: bool
    outcome: str = "decided"
    backend: object = None
    shots: int = 1
    shots_requested: object = None
    job_id: object = None
    u53: object = None
    bitstring: object = None
    valid: object = None
    latency_ms: float = 0.0
    deadline_ms: object = None
    attempted: tuple = ()
    fallback_from: object = None
    fallback_reason: object = None
    entropy: tuple = ()

    def as_dict(self):
        return {"decision_seq": self.decision_seq, "source": self.source, "route": self.route,
                "route_reason": self.route_reason, "context": self.context,
                "realtime": self.realtime, "outcome": self.outcome, "backend": self.backend,
                "shots": self.shots, "shots_requested": self.shots_requested,
                "job_id": self.job_id, "u53": self.u53, "bitstring": self.bitstring,
                "valid": self.valid, "latency_ms": self.latency_ms,
                "deadline_ms": self.deadline_ms, "attempted": list(self.attempted),
                "fallback_from": self.fallback_from, "fallback_reason": self.fallback_reason,
                "entropy": dict(self.entropy)}


class V2Decision:
    """A decision made by the decision field. Duck-compatible with what the
    four consumers read (``chosen``, ``chosen_index``)."""

    __slots__ = ("chosen_index", "chosen", "context", "n_candidates", "candidate_labels",
                 "probabilities", "source", "provenance", "timestamp", "latency_ms")

    # Class constants for EVERY source (spec I8). __slots__ makes them
    # read-only on instances.
    quantum_decided = False
    authorizes_action = False

    def __init__(self, chosen_index, chosen, context, n_candidates, candidate_labels,
                 probabilities, source, provenance, timestamp, latency_ms):
        self.chosen_index = chosen_index
        self.chosen = chosen
        self.context = context
        self.n_candidates = n_candidates
        self.candidate_labels = candidate_labels
        self.probabilities = probabilities
        self.source = source
        self.provenance = provenance
        self.timestamp = timestamp
        self.latency_ms = latency_ms

    def to_dict(self):
        return {"chosen_index": self.chosen_index, "chosen": str(self.chosen)[:80],
                "context": self.context, "n_candidates": self.n_candidates,
                "probabilities": list(self.probabilities), "source": self.source,
                "quantum_decided": False, "authorizes_action": False,
                "timestamp": self.timestamp, "latency_ms": self.latency_ms,
                "provenance": self.provenance.as_dict() if self.provenance else None}

    def __repr__(self):
        return "V2Decision(chosen_index=%r, source=%r, context=%r)" % (
            self.chosen_index, self.source, self.context)


LABEL_MAX_CHARS = 80
LABEL_MAX_COUNT = 16


def clip_labels(labels):
    if labels is None:
        return None
    out = []
    for x in list(labels)[:LABEL_MAX_COUNT]:
        out.append(str(x)[:LABEL_MAX_CHARS])
    return out
