"""Decision field V2 (Leon V2 runbook Phase 11).

An exact, provenance-recording replacement path for the legacy decision
engine's ``decide()``. Everything defaults OFF: with ``LEON_QUANTUM_V2`` unset
or ``off`` server/init_brain.py never imports this package.

Importing this package does no I/O, starts no threads and never imports
qiskit; submodules are imported lazily by ``build_from_env``.

    build_from_env(legacy, brain, state_dir=None, env=None) -> router | None

One router per realpath(state_dir) per process (I14): a re-run of
``init_brain()`` rebinds the existing router instead of building a second
one, so threads are never duplicated. Flags are fixed for the life of the
process.
"""
import os
import threading

__all__ = ["build_from_env", "registered_routers"]

_REGISTRY = {}
_REG_LOCK = threading.Lock()


def build_from_env(legacy, brain, state_dir=None, env=None, repo_root=None, candidate_validator=None):
    """Build (or rebind) the router for this state dir.

    Returns None when the mode is off, or when ``legacy`` is None (the
    router, if one exists, is then marked suspended). Raises ValueError
    (config.ConfigError) on a syntax error or unknown flag value.
    """
    from .config import load_config
    cfg = load_config(env=env, state_dir=state_dir, repo_root=repo_root)
    if cfg.mode == "off":
        return None
    key = os.path.realpath(cfg.state_dir)
    with _REG_LOCK:
        router = _REGISTRY.get(key)
        if router is not None and router.closed:
            thread = getattr(router.store, "_thread", None)
            if thread is not None and thread.is_alive():
                raise RuntimeError("previous decision field writer is still stopping")
        if router is not None and not router.closed:
            router.rebind(legacy, brain)
            return router if legacy is not None else None
        if legacy is None:
            return None
        from .router import DecisionFieldRouter
        router = DecisionFieldRouter(legacy, brain, cfg, repo_root=repo_root,
                                     candidate_validator=candidate_validator)
        _REGISTRY[key] = router
        router.start()
        return router


def registered_routers():
    with _REG_LOCK:
        return dict(_REGISTRY)


def _reset_registry_for_tests():
    with _REG_LOCK:
        routers = list(_REGISTRY.values())
        _REGISTRY.clear()
    for r in routers:
        try:
            r.close(timeout=1.0)
        except Exception:
            pass
