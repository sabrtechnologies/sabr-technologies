"""Strict flag parsing for the decision field (spec 6.1).

Two classes of error:

* a syntax error or unknown value raises ``ConfigError`` (a ValueError). The
  router is then not built, legacy stays the sole engine, and init_brain logs
  the problem;
* a known value that is not yet permitted degrades to the most restrictive
  permitted configuration and is listed in ``Config.policy_refused``.

Flags are read once, at construction. ``parse_v2_mode`` is identical in
behaviour to ``brain.v2_config.parse_v2_mode`` (a test checks equivalence);
it returns the plain string instead of the enum so this package does not
import brain.v2_config.
"""
import os
from dataclasses import dataclass, field

from . import authority

LEGAL_MODES = ("off", "shadow", "on")
LEGAL_BACKENDS = ("classical", "aer")
LEGAL_CAUSAL = ("off", "on")
AER_DEADLINE_DEFAULT_MS = 250
AER_DEADLINE_MIN_MS = 50
AER_DEADLINE_MAX_MS = 1000
SHADOW_SAMPLE_DEFAULT = 50

ENV_MODE = "LEON_QUANTUM_V2"
ENV_AUTH = "LEON_QV2_AUTHORITATIVE_CONTEXTS"
ENV_BACKEND = "LEON_QV2_BACKEND"
ENV_DEADLINE = "LEON_QV2_AER_DEADLINE_MS"
ENV_CAUSAL = "LEON_QV2_CAUSAL"
ENV_SAMPLE = "LEON_QV2_SHADOW_SAMPLE_WORKSPACE"
ENV_STATE_DIR = "LEON_QV2_STATE_DIR"


class ConfigError(ValueError):
    pass


def parse_v2_mode(var_name, raw):
    """Strict off/shadow/on parse, identical to brain.v2_config.parse_v2_mode."""
    cleaned = raw.strip().lower()
    for mode in LEGAL_MODES:
        if cleaned == mode:
            return mode
    raise ConfigError(
        "{0}={1!r} is not a valid Leon V2 mode. Legal values are {2} "
        "(case-insensitive, surrounding whitespace ignored). Two-state values "
        "such as 1/0/true/false are not accepted - choose one of {2}, or "
        "unset {0} to take the runbook default.".format(var_name, raw, ", ".join(LEGAL_MODES)))


def _choice(env, name, legal, default):
    raw = env.get(name)
    if raw is None or not raw.strip():
        return default
    cleaned = raw.strip().lower()
    if cleaned not in legal:
        raise ConfigError("%s=%r is not valid; legal values are %s" % (name, raw, ", ".join(legal)))
    return cleaned


def _int(env, name, default):
    raw = env.get(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw.strip(), 10)
    except ValueError:
        raise ConfigError("%s=%r is not an integer" % (name, raw)) from None


def default_state_dir(repo_root=None):
    return os.path.realpath(os.path.join(repo_root or authority.REPO_ROOT,
                                         "brain_state", "v2", "quantum"))


@dataclass(frozen=True)
class Config:
    mode: str
    authoritative: frozenset
    backend: str
    aer_deadline_ms: int
    causal: str
    shadow_sample_workspace: int
    state_dir: str
    action_gate: str                       # "ready" | "absent"
    policy_refused: tuple = ()             # ((item, reason), ...)
    requested: dict = field(default_factory=dict)

    @property
    def is_on(self):
        return self.mode == "on"

    def flags_block(self):
        return {"LEON_QUANTUM_V2": self.mode, "authoritative": sorted(self.authoritative),
                "backend": self.backend, "causal": self.causal, "action_gate": self.action_gate}


def load_config(env=None, state_dir=None, repo_root=None):
    """Parse and policy-check the flags. Raises ConfigError on bad syntax."""
    env = os.environ if env is None else env
    raw_mode = env.get(ENV_MODE)
    mode = "off" if raw_mode is None or not raw_mode.strip() else parse_v2_mode(ENV_MODE, raw_mode)

    auth_raw = env.get(ENV_AUTH, "") or ""
    requested_auth = []
    if auth_raw.strip():
        for item in auth_raw.split(","):
            name = item.strip().lower()
            if not name:
                raise ConfigError("%s=%r has an empty item" % (ENV_AUTH, auth_raw))
            if name not in authority.ELIGIBLE:
                raise ConfigError("%s: %r is not an eligible context; eligible: %s"
                                  % (ENV_AUTH, name, ", ".join(sorted(authority.ELIGIBLE))))
            if name not in requested_auth:
                requested_auth.append(name)

    backend = _choice(env, ENV_BACKEND, LEGAL_BACKENDS, "classical")
    deadline = _int(env, ENV_DEADLINE, AER_DEADLINE_DEFAULT_MS)
    deadline = min(max(deadline, AER_DEADLINE_MIN_MS), AER_DEADLINE_MAX_MS)
    causal = _choice(env, ENV_CAUSAL, LEGAL_CAUSAL, "off")
    sample = _int(env, ENV_SAMPLE, SHADOW_SAMPLE_DEFAULT)
    if sample < 1:
        raise ConfigError("%s must be an integer >= 1" % ENV_SAMPLE)
    if state_dir is None:
        sd_raw = env.get(ENV_STATE_DIR)
        state_dir = sd_raw.strip() if sd_raw and sd_raw.strip() else default_state_dir(repo_root)
    state_dir = os.path.realpath(state_dir)

    gate = authority.action_gate_ready(repo_root)
    refused = []
    auth = []
    for ctx in requested_auth:
        if mode != "on":
            refused.append(("authoritative:" + ctx, "mode_not_on"))
            continue
        if ctx in authority.GATE_REQUIRED_AUTHORITATIVE:
            if not gate:
                refused.append(("authoritative:" + ctx, "action_gate_absent"))
                continue
            if not authority.change7_present(repo_root):
                refused.append(("authoritative:" + ctx, "change7_absent"))
                continue
        auth.append(ctx)
    if backend == "aer" and not gate:
        refused.append(("backend:aer", "action_gate_absent"))
        backend = "classical"
    if causal == "on":
        if mode != "on":
            refused.append(("causal", "mode_not_on"))
            causal = "off"
        elif not gate:
            refused.append(("causal", "action_gate_absent"))
            causal = "off"
    requested = {ENV_MODE: mode, ENV_AUTH: list(requested_auth),
                 ENV_BACKEND: env.get(ENV_BACKEND) or "", ENV_CAUSAL: env.get(ENV_CAUSAL) or ""}
    return Config(mode=mode, authoritative=frozenset(auth), backend=backend,
                  aer_deadline_ms=deadline, causal=causal, shadow_sample_workspace=sample,
                  state_dir=state_dir, action_gate="ready" if gate else "absent",
                  policy_refused=tuple(refused), requested=requested)
