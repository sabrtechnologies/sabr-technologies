"""Closed code constants and fail-closed readiness checks (spec 9.1, 9.2, 7.3).

Nothing here imports another Leon module. The three readiness checks parse
source files with ``ast``; they never import them:

* ``action_gate_ready()``: reads the ``ACTION_GATE_CONTRACT`` literal in
  ``brain/action_gate.py``. Absent or malformed means False.
* ``legacy_budget_cap()`` / ``f5_satisfied()``: reads ``QUANTUM_JOB_BUDGET``
  in ``brain/quantum.py``. F5 holds only when it is <= LEGACY_MAX_BUDGET (46).
* ``change7_present()``: checks that ``brain/global_workspace.py`` derives
  its tie flag from ``getattr(decision, "quantum_decided", True)`` and gates
  the selection counter on it.
"""
import ast
import os

# ── Contexts and sources ─────────────────────────────────────────────────────

ELIGIBLE = frozenset({"thought_trigger", "daydream", "dream_content", "workspace_access"})
CAUSAL_ELIGIBLE = frozenset({"dream_content", "thought_trigger"})
#: Authoritative use of these contexts needs action_gate_ready() and change #7.
GATE_REQUIRED_AUTHORITATIVE = frozenset({"workspace_access"})
#: Sources that may decide only once action_gate_ready() holds.
QUANTUM_LABELLED_SOURCES = frozenset({"aer", "ibm_hardware"})
#: Threads that are NOT realtime. Every other thread is realtime (fail safe).
NONREALTIME_THREAD_NAMES = frozenset({"DreamEngine", "DaydreamEngine"})
#: Contexts that are realtime whatever the thread.
REALTIME_CONTEXTS = frozenset({"workspace_access"})

# ── Causal limits (a violation leaves an entry inert) ────────────────────────

CAUSAL_MIN_SLOT_INTERVAL_S = 3600
CAUSAL_MAX_SLOTS_PER_24H = 4
CAUSAL_MAX_SLOTS_TOTAL = 112
CAUSAL_MAX_OPEN_S = 129600
CAUSAL_N_SET_ALLOWED = frozenset({2, 3, 4, 8})
CAUSAL_MAX_SHOTS_PER_PUB = 16
CAUSAL_MAX_RESERVOIR_TTL_S = 604800
CAUSAL_MIN_IBM_SPACING_S = 172800
CAUSAL_MAX_EXPIRY_DAYS = 90
CAUSAL_ARMS = ("aer", "ibm_hardware", "os_entropy")
#: Detached-signature signer fingerprint. None in Phase 11: every entry inert.
CAUSAL_SIGNER_FPR = None
CAUSAL_SIGNER_IDENTITY = "qv2-approver"
CAUSAL_SIGNATURE_NAMESPACE = "leon-qv2-causal"

# ── IBM caps (spec 7.3) ──────────────────────────────────────────────────────

JOINT_CAP = 60                      # legacy + V2 IBM jobs per rolling 28 days
V2_CAUSAL_CAP = 12
V2_DIAG_CAP = 2
LEGACY_MAX_BUDGET = JOINT_CAP - V2_CAUSAL_CAP - V2_DIAG_CAP     # 46 (F5)
IBM_ROLLING_WINDOW_S = 28 * 86400
IBM_MIN_SPACING_ANY_S = 6 * 3600
IBM_MIN_SPACING_CAUSAL_S = CAUSAL_MIN_IBM_SPACING_S
IBM_BREAKER_FAILURES = 3
IBM_BREAKER_OPEN_S = 86400
IBM_USAGE_RESERVE_S = 120
IBM_JOB_TTL_S = 86400
IBM_POLL_INTERVAL_S = 1800
IBM_ORPHAN_SEARCH_GAP_S = 3600
IBM_CANONICAL_STATE_DIR = "/opt/leon-brain/brain_state/v2/quantum"
IBM_TIMEOUTS_S = {"usage": 45, "submit": 90, "poll": 30, "cancel": 30, "find_by_tag": 45}

# ── ActionGate contract (spec 9.2) ───────────────────────────────────────────

ACTION_GATE_REQUIRED_KINDS = ("quantum_result", "qv2_decision")
ACTION_GATE_REQUIRED_CONSUMERS = ("goal_pursuit", "proactive", "speech_intent",
                                  "outbound", "agent_tools")

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def is_realtime(context, thread_name):
    return context in REALTIME_CONTEXTS or thread_name not in NONREALTIME_THREAD_NAMES


def _parse(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return ast.parse(fh.read(), path)
    except (OSError, SyntaxError, ValueError, UnicodeDecodeError):
        return None


def _module_assign(tree, name):
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for tgt in node.targets:
                if isinstance(tgt, ast.Name) and tgt.id == name:
                    return node.value
        elif isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name) and node.target.id == name and node.value:
                return node.value
    return None


def action_gate_contract(repo_root=None):
    """The literal ACTION_GATE_CONTRACT dict, or None."""
    tree = _parse(os.path.join(repo_root or REPO_ROOT, "brain", "action_gate.py"))
    if tree is None:
        return None
    node = _module_assign(tree, "ACTION_GATE_CONTRACT")
    if node is None:
        return None
    try:
        value = ast.literal_eval(node)
    except (ValueError, SyntaxError, TypeError):
        return None
    return value if isinstance(value, dict) else None


def action_gate_ready(repo_root=None):
    c = action_gate_contract(repo_root)
    if not c or c.get("version") != 1:
        return False
    kinds, consumers = c.get("denied_basis_kinds"), c.get("routed_consumers")
    if not isinstance(kinds, (list, tuple)) or not isinstance(consumers, (list, tuple)):
        return False
    return (all(k in kinds for k in ACTION_GATE_REQUIRED_KINDS)
            and all(k in consumers for k in ACTION_GATE_REQUIRED_CONSUMERS))


def legacy_budget_cap(repo_root=None):
    """QUANTUM_JOB_BUDGET parsed from brain/quantum.py (module level or a
    top-level class body, where QuantumRNG defines it), or None. With several
    definitions the largest wins (fail closed); a non-literal gives None."""
    tree = _parse(os.path.join(repo_root or REPO_ROOT, "brain", "quantum.py"))
    if tree is None:
        return None
    scopes = [tree] + [n for n in tree.body if isinstance(n, ast.ClassDef)]
    values = []
    for scope in scopes:
        node = _module_assign(scope, "QUANTUM_JOB_BUDGET")
        if node is None:
            continue
        try:
            value = ast.literal_eval(node)
        except (ValueError, SyntaxError, TypeError):
            return None
        if isinstance(value, bool) or not isinstance(value, int):
            return None
        values.append(value)
    return max(values) if values else None


def f5_satisfied(repo_root=None):
    cap = legacy_budget_cap(repo_root)
    return cap is not None and cap <= LEGACY_MAX_BUDGET


def change7_present(repo_root=None):
    """True when the workspace tie flag comes from the decision object.

    Requires, inside GlobalWorkspace.tick: an assignment
    ``quantum_decided = bool(getattr(decision, "quantum_decided", True))`` and
    an ``if quantum_decided:`` whose body increments ``_quantum_selections``;
    and no bare ``quantum_decided = True`` left in the function.
    """
    tree = _parse(os.path.join(repo_root or REPO_ROOT, "brain", "global_workspace.py"))
    if tree is None:
        return False
    tick = None
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == "GlobalWorkspace":
            for item in node.body:
                if isinstance(item, ast.FunctionDef) and item.name == "tick":
                    tick = item
    if tick is None:
        return False
    getattr_ok = gated_ok = False
    for node in ast.walk(tick):
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            tgt = node.targets[0]
            if isinstance(tgt, ast.Name) and tgt.id == "quantum_decided":
                v = node.value
                if isinstance(v, ast.Constant) and v.value is True:
                    return False
                if (isinstance(v, ast.Call) and isinstance(v.func, ast.Name)
                        and v.func.id == "bool" and len(v.args) == 1
                        and isinstance(v.args[0], ast.Call)
                        and isinstance(v.args[0].func, ast.Name)
                        and v.args[0].func.id == "getattr"):
                    args = v.args[0].args
                    if (len(args) == 3 and isinstance(args[1], ast.Constant)
                            and args[1].value == "quantum_decided"
                            and isinstance(args[2], ast.Constant) and args[2].value is True):
                        getattr_ok = True
        if (isinstance(node, ast.If) and isinstance(node.test, ast.Name)
                and node.test.id == "quantum_decided"):
            for sub in node.body:
                if (isinstance(sub, ast.AugAssign) and isinstance(sub.target, ast.Attribute)
                        and sub.target.attr == "_quantum_selections"):
                    gated_ok = True
    return getattr_ok and gated_ok
