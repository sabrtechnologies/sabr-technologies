"""Offline analysis CLI (spec 6.5, 10, 12).

    python3 -s -m brain.quantum_decision_field.analysis <subcommand> [...]

  shadow              pooled shadow report; ALWAYS appends a qv2.analysis/2
                      record (nulls included)
  causal --entry ID   verdict: insufficient_data | null |
                      distributional_difference | confounded (never "effect")
  baseline-snapshot   legacy journal distribution by (context, n), read-only
  backfill-june       historical record from SESSION_LOG.md lines 1731-1735,
                      refused unless their sha256 matches; idempotent
  ibm-usage           one usage child under ibm.lock (canonical dir only)
  ledger-append       validates a migration-ledger record shape, then appends

analysis.jsonl and causal/analysis.jsonl are written under analysis.lock;
the migration ledger is appended under a lock on the file itself.
"""
import argparse
import gzip
import hashlib
import json
import os
import re
import sys
import time

from . import authority, filelock, stats
from .config import default_state_dir
from .provenance import SCHEMA_ANALYSIS

JUNE_ANALYSIS_ID = "hist-2026-06-quantum-swap-1"
JUNE_LINES = (1731, 1735)
JUNE_SHA256 = "4ddc552c04dc11ac739182aaf63eab1f02e207b5d645a3c8ba1a84d90415689f"
JUNE_SOURCE = "/opt/leon-brain/SESSION_LOG.md"
VERDICTS = ("insufficient_data", "null", "distributional_difference", "confounded")
ARMS = ("aer", "ibm_hardware", "os_entropy")
_HEX40 = re.compile(r"^[0-9a-f]{40}$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_UTC = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$")


def _append(path, rec, lock_name="analysis.lock"):
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    lk = filelock.open_lock(os.path.join(d, lock_name)) or filelock.InProcessLock(os.path.join(d, lock_name))
    if not lk.acquire(blocking=True, timeout=30):
        raise TimeoutError("analysis.lock busy")
    try:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, sort_keys=True, default=str) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
    finally:
        lk.release()
    return rec


def _existing_ids(path):
    ids = set()
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    ids.add(json.loads(line).get("analysis_id"))
                except (ValueError, AttributeError):
                    continue
    except OSError:
        pass
    return ids


def _read_jsonl_any(path):
    opener = gzip.open if path.endswith(".gz") else open
    out = []
    try:
        with opener(path, "rt", encoding="utf-8") as fh:
            for line in fh:
                try:
                    rec = json.loads(line)
                except ValueError:
                    continue
                if isinstance(rec, dict):
                    out.append(rec)
    except (OSError, EOFError):
        pass
    return out


# ── shadow ───────────────────────────────────────────────────────────────────

def shadow_report(state_dir, now=None):
    now = time.time() if now is None else now
    d = os.path.join(state_dir, "aggregates")
    pooled = {}
    files = sorted(os.listdir(d)) if os.path.isdir(d) else []
    for name in files:
        for rec in _read_jsonl_any(os.path.join(d, name)):
            if rec.get("mode") != "shadow":
                continue
            key = "%s|%s" % (rec.get("context"), rec.get("n"))
            n = int(rec.get("n") or 0)
            g = pooled.setdefault(key, {"context": rec.get("context"), "n": n, "decisions": 0,
                                        "fold_count": 0, "legacy_counts": {}, "legacy_shots": 0,
                                        "legacy_invalid_shots": 0, "v2_target_sum": [0.0] * n,
                                        "modeled_legacy_sum": [0.0] * n, "modeled_n": 0,
                                        "legacy_chosen_hist": [0] * n, "v2_chosen_hist": [0] * n,
                                        "overhead_hist": {}, "buckets": 0, "partial_buckets": 0})
            g["decisions"] += rec.get("decisions", 0)
            g["fold_count"] += rec.get("fold_count", 0)
            g["legacy_shots"] += rec.get("legacy_shots", 0)
            g["legacy_invalid_shots"] += rec.get("legacy_invalid_shots", 0)
            g["modeled_n"] += rec.get("modeled_n", 0)
            g["buckets"] += 1
            g["partial_buckets"] += 1 if rec.get("partial") else 0
            for bs, c in (rec.get("legacy_counts") or {}).items():
                g["legacy_counts"][bs] = g["legacy_counts"].get(bs, 0) + c
            for f in ("v2_target_sum", "modeled_legacy_sum", "legacy_chosen_hist", "v2_chosen_hist"):
                for i, v in enumerate(rec.get(f) or []):
                    if i < n:
                        g[f][i] += v
            for k, v in ((rec.get("latency_hist") or {}).get("router_overhead_us") or {}).items():
                g["overhead_hist"][k] = g["overhead_hist"].get(k, 0) + v
    groups = []
    for key in sorted(pooled):
        g = pooled[key]
        n, dec = g["n"], g["decisions"]
        out = {k: g[k] for k in ("context", "n", "decisions", "fold_count", "legacy_shots",
                                 "legacy_invalid_shots", "buckets", "partial_buckets", "overhead_hist")}
        if dec and n:
            target = [x / dec for x in g["v2_target_sum"]]
            out["fold_rate"] = g["fold_count"] / dec
            folded = [0] * n
            for bs, c in g["legacy_counts"].items():
                i = int(bs, 2)
                folded[i if i < n else i % n] += c
            tot = sum(folded)
            if tot:
                emp = [c / tot for c in folded]
                out["pooled_legacy_measurement_tvd_vs_v2_target"] = stats.tvd(emp, target)
                out["no_bias_baseline_tvd_shots"] = stats.expected_tvd_null(target, tot)
            chosen = stats.normalize_counts(g["legacy_chosen_hist"])
            out["legacy_chosen_tvd_vs_v2_target"] = stats.tvd(chosen, target)
            out["no_bias_baseline_tvd_decisions"] = stats.expected_tvd_null(target, dec)
            out["legacy_invalid_shot_frac"] = (g["legacy_invalid_shots"] / g["legacy_shots"]
                                               if g["legacy_shots"] else None)
            if g["modeled_n"]:
                out["modeled_legacy_mean"] = [x / g["modeled_n"] for x in g["modeled_legacy_sum"]]
            out["v2_target_mean"] = target
        groups.append(out)
    return {"schema": SCHEMA_ANALYSIS, "analysis_id": "shadow-%d" % int(now), "kind": "shadow_report",
            "ts": now, "state_dir": state_dir, "aggregate_files": len(files), "groups": groups,
            "null": not groups}


# ── causal ───────────────────────────────────────────────────────────────────

def as_treated_arm(unit):
    return unit.get("source") if unit.get("source") in ARMS else None


def causal_verdict(units, outcomes=None, alpha=0.05, min_per_arm=30, n_perm=100000, seed=0):
    """units: slot_consumed records; outcomes: {decision_id: 0/1} or None."""
    per_arm = {a: 0 for a in ARMS}
    itt = {a: 0 for a in ARMS}
    for u in units:
        itt[u.get("arm")] = itt.get(u.get("arm"), 0) + 1
        a = as_treated_arm(u)
        if a:
            per_arm[a] += 1
    res = {"as_treated_per_arm": per_arm, "itt_per_arm": itt, "alpha": alpha,
           "min_per_arm_as_treated": min_per_arm}
    if min(per_arm.values()) < min_per_arm:
        res["verdict"] = "insufficient_data"
        return res
    idx = {a: i for i, a in enumerate(ARMS)}
    ncol = max(int(u.get("n") or 0) for u in units) or 1
    prim_units = [(idx[as_treated_arm(u)], int(u["chosen_index"])) for u in units if as_treated_arm(u)]
    primary = stats.mc_exact_conditional(prim_units, len(ARMS), ncol, n_perm=n_perm, seed=seed)
    res["primary"] = primary
    secondary = None
    if outcomes:
        sec_units = [(idx[as_treated_arm(u)], int(outcomes[u["decision_id"]]), int(u["chosen_index"]))
                     for u in units if as_treated_arm(u) and u.get("decision_id") in outcomes]
        if sec_units:
            secondary = stats.cmh_general(sec_units, len(ARMS), 2, ncol, seed=seed)
    res["secondary"] = secondary
    sp = None
    if secondary:
        sp = secondary.get("exact_p", secondary.get("p"))
    if primary["p"] < alpha:
        res["verdict"] = "distributional_difference"
    elif sp is not None and sp < alpha:
        res["verdict"] = "confounded"
    else:
        res["verdict"] = "null"
    return res


def dream_outcomes(units, dream_journal):
    """novel_patterns_found > 0 for the cycle whose [started_at,
    started_at+duration_s] contains the decision's consumed_at."""
    cycles = []
    for rec in _read_jsonl_any(dream_journal):
        try:
            s = float(rec.get("started_at"))
            cycles.append((s, s + float(rec.get("duration_s") or 0.0),
                           int(rec.get("novel_patterns_found") or 0)))
        except (TypeError, ValueError):
            continue
    out = {}
    for u in units:
        t = float(u.get("consumed_at") or 0.0)
        for s, e, nov in cycles:
            if s <= t <= e:
                out[u.get("decision_id")] = 1 if nov > 0 else 0
                break
    return out


def causal_analysis(state_dir, entry_id, dream_journal=None, n_perm=100000, now=None):
    now = time.time() if now is None else now
    recs = _read_jsonl_any(os.path.join(state_dir, "causal", "experiments.jsonl"))
    units = [r for r in recs if r.get("kind") == "slot_consumed" and r.get("entry_id") == entry_id]
    ph = next((r.get("prereg_hash") for r in units if r.get("prereg_hash")), None)
    seed = int(ph[:16], 16) if ph else 0
    outcomes = dream_outcomes(units, dream_journal) if dream_journal else None
    v = causal_verdict(units, outcomes, n_perm=n_perm, seed=seed)
    return {"schema": SCHEMA_ANALYSIS, "analysis_id": "causal-%s-%d" % (entry_id, int(now)),
            "kind": "causal_report", "ts": now, "entry_id": entry_id, "prereg_hash": ph,
            "units": len(units), **v,
            "interpretation": "distributional or procedural differences only"}


# ── baseline snapshot & backfill ─────────────────────────────────────────────

def baseline_snapshot(journal_path, now=None):
    now = time.time() if now is None else now
    h = hashlib.sha256()
    by = {}
    sources = {}
    lines = 0
    with open(journal_path, "rb") as fh:
        for raw in fh:
            h.update(raw)
            lines += 1
            try:
                rec = json.loads(raw)
            except ValueError:
                continue
            ctx, n = rec.get("context"), rec.get("n_candidates")
            key = "%s|%s" % (ctx, n)
            g = by.setdefault(key, {"context": ctx, "n": n, "decisions": 0, "chosen_index_hist": {},
                                    "fold_count": 0})
            g["decisions"] += 1
            ci = str(rec.get("chosen_index"))
            g["chosen_index_hist"][ci] = g["chosen_index_hist"].get(ci, 0) + 1
            m = rec.get("measurement")
            if isinstance(m, str) and m and set(m) <= {"0", "1"} and isinstance(n, int) and int(m, 2) >= n:
                g["fold_count"] += 1
            s = rec.get("source")
            sources[s] = sources.get(s, 0) + 1
    digest = h.hexdigest()
    return {"schema": SCHEMA_ANALYSIS, "analysis_id": "baseline-snapshot-%s" % digest[:16],
            "kind": "baseline_snapshot", "ts": now, "source_path": journal_path,
            "source_sha256": digest, "lines": lines, "by_context_n": [by[k] for k in sorted(by)],
            "source_counts": sources}


def backfill_june(session_log=JUNE_SOURCE, now=None):
    now = time.time() if now is None else now
    with open(session_log, "r", encoding="utf-8", errors="replace") as fh:
        all_lines = fh.readlines()
    lo, hi = JUNE_LINES
    quoted = "".join(all_lines[lo - 1:hi])          # the raw lines, newlines included
    sha = hashlib.sha256(quoted.encode("utf-8")).hexdigest()
    if sha != JUNE_SHA256:
        raise ValueError("SESSION_LOG.md lines %d-%d sha256 %s != pinned %s; refused" % (lo, hi, sha, JUNE_SHA256))
    return {"schema": SCHEMA_ANALYSIS, "analysis_id": JUNE_ANALYSIS_ID, "kind": "historical_backfill",
            "ts": now, "source_path": "%s (untracked)" % session_log, "source_lines": "%d-%d" % (lo, hi),
            "source_sha256": sha, "quoted": quoted, "design": "4 rounds classical<->ibm x 10 probes",
            "verdict": "confounded", "null_within_confound": True}


# ── ledger-append ────────────────────────────────────────────────────────────

def validate_ledger_record(rec):
    """Raise ValueError unless rec is a valid Phase 11 migration-ledger record."""
    def need(c, why):
        if not c:
            raise ValueError(why)
    need(isinstance(rec, dict), "record must be an object")
    need(rec.get("phase") == 11, "phase must be 11")
    comp = rec.get("component")
    need(comp in ("quantum_v2", "quantum_v2_causal"), "unknown component")
    need(rec.get("from") in ("off", "shadow", "on"), "bad from")
    need(rec.get("to") in ("off", "shadow", "on"), "bad to")
    need(isinstance(rec.get("git_commit"), str) and _HEX40.match(rec["git_commit"]), "git_commit must be 40 hex")
    need(isinstance(rec.get("started_utc"), str) and _UTC.match(rec["started_utc"]), "bad started_utc")
    cu = rec.get("completed_utc")
    if rec.get("to") != "off":
        need(isinstance(cu, str) and _UTC.match(cu), "to != off requires completed_utc (continuity FAIL otherwise)")
    if comp == "quantum_v2":
        need(isinstance(rec.get("step"), str) and rec["step"] in ("0", "1", "2", "3", "4", "C", "D"), "bad step")
        need(isinstance(rec.get("authoritative_contexts"), list)
             and set(rec["authoritative_contexts"]) <= authority.ELIGIBLE, "bad authoritative_contexts")
        need(rec.get("causal") in ("off", "on"), "bad causal")
        need(rec.get("git_branch") == "v2/phase11-quantum-field" or isinstance(rec.get("git_branch"), str),
             "bad git_branch")
        need(isinstance(rec.get("tests"), dict), "tests must be an object")
        need(isinstance(rec.get("gates"), dict), "gates must be an object")
        need(isinstance(rec.get("rollback"), str) and rec["rollback"], "rollback required")
        if "status" in rec:
            need(rec["status"] == "skipped_insufficient_traffic", "bad status")
    else:
        need(isinstance(rec.get("entry_id"), str) and rec["entry_id"], "entry_id required")
        need(isinstance(rec.get("prereg_hash"), str) and _HEX64.match(rec["prereg_hash"]), "prereg_hash 64 hex")
        need(isinstance(rec.get("approved_by"), str) and rec["approved_by"], "approved_by required")
        need(isinstance(rec.get("signature_sha256"), str) and _HEX64.match(rec["signature_sha256"]),
             "signature_sha256 64 hex")
        need(rec.get("to") == "on", "causal approval must be to=on")
    return True


def ledger_append(rec, ledger_path):
    validate_ledger_record(rec)
    lk = filelock.FileLock(ledger_path + ".lock") if filelock.available() else filelock.InProcessLock(ledger_path)
    if not lk.acquire(blocking=True, timeout=30):
        raise TimeoutError("ledger lock busy")
    try:
        with open(ledger_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, sort_keys=True) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
    finally:
        lk.release()
    return rec


# ── ibm-usage ────────────────────────────────────────────────────────────────

def ibm_usage(state_dir, runner=None, canonical_dir=None, repo_root=None, now=None):
    from .ledger import IbmLedger
    from .ibm_runner import IbmRunner, RunnerError
    canonical_dir = authority.IBM_CANONICAL_STATE_DIR if canonical_dir is None else canonical_dir
    if os.path.realpath(state_dir) != os.path.realpath(canonical_dir):
        return {"ok": False, "reason": "state_dir_not_canonical"}
    if os.path.exists(os.path.join(state_dir, "IBM_DISABLED")):
        return {"ok": False, "reason": "ibm_disabled"}
    lk = filelock.open_lock(os.path.join(state_dir, "ibm.lock"))
    if lk is None or not lk.acquire(blocking=False):
        return {"ok": False, "reason": "ibm_lock_unavailable"}
    try:
        led = IbmLedger(os.path.join(state_dir, "ibm_ledger.jsonl"))
        now = time.time() if now is None else now
        runner = runner or IbmRunner(repo_root=repo_root)
        try:
            lines = runner.run("usage", {})
        except RunnerError as e:
            led.append("error", ts=now, op="usage", purpose="diagnostic", error_class=e.error_class,
                       error_digest=e.error_digest)
            return {"ok": False, "reason": "usage_error"}
        usage = next((x for x in reversed(lines) if x.get("op") == "usage"), {}) or {}
        rec = led.append("usage", ts=now, purpose="operator_check",
                         **{k: v for k, v in usage.items() if k != "op"})
        return {"ok": True, "usage": rec}
    finally:
        lk.release()


def main(argv=None):
    ap = argparse.ArgumentParser(prog="brain.quantum_decision_field.analysis")
    ap.add_argument("--state-dir", default=None)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("shadow")
    c = sub.add_parser("causal")
    c.add_argument("--entry", required=True)
    c.add_argument("--dream-journal", default=os.path.join(authority.REPO_ROOT, "brain_state", "dream_journal.jsonl"))
    c.add_argument("--n-perm", type=int, default=100000)
    b = sub.add_parser("baseline-snapshot")
    b.add_argument("--journal", default=os.path.join(authority.REPO_ROOT, "brain_state", "conscious_decisions.jsonl"))
    j = sub.add_parser("backfill-june")
    j.add_argument("--session-log", default=JUNE_SOURCE)
    sub.add_parser("ibm-usage")
    la = sub.add_parser("ledger-append")
    la.add_argument("--record", required=True, help="JSON object")
    la.add_argument("--ledger", default=os.path.join(authority.REPO_ROOT, "brain_state", "v2",
                                                     "migration_ledger.jsonl"))
    args = ap.parse_args(argv)
    sd = os.path.realpath(args.state_dir or os.environ.get("LEON_QV2_STATE_DIR") or default_state_dir())
    apath = os.path.join(sd, "analysis.jsonl")
    if args.cmd == "shadow":
        rec = _append(apath, shadow_report(sd))
    elif args.cmd == "causal":
        rec = _append(os.path.join(sd, "causal", "analysis.jsonl"),
                      causal_analysis(sd, args.entry, args.dream_journal, args.n_perm))
    elif args.cmd == "baseline-snapshot":
        rec = baseline_snapshot(args.journal)
        if rec["analysis_id"] not in _existing_ids(apath):
            _append(apath, rec)
    elif args.cmd == "backfill-june":
        rec = backfill_june(args.session_log)
        if rec["analysis_id"] not in _existing_ids(apath):
            _append(apath, rec)
    elif args.cmd == "ibm-usage":
        rec = ibm_usage(sd)
    else:
        rec = ledger_append(json.loads(args.record), args.ledger)
    print(json.dumps({"ok": True, "cmd": args.cmd, "analysis_id": rec.get("analysis_id") if isinstance(rec, dict) else None},
                     sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
