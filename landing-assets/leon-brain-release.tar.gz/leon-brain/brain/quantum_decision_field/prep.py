"""Exact valid-state preparation (Phase 11 spec section 3).

Everything above ``build_qiskit_circuit`` is pure Python and is the
reference implementation from spec section 3.3, kept as written:

* ``normalize``: w / max(w), then ``math.fsum``; compaction on the
  normalized p > 0, with underflowed positive weights counted.
* ``plan``: an MSB-first RY tree with a don't-care-aware partition. Keys use
  only fsum and correctly rounded division, so they are platform
  independent.
* ``reference_amplitudes``: product form. Invalid basis states (index >= N')
  have amplitude exactly 0.0.
* ``circuit_hash``: covers N', q, float.hex(p) and the partition keys.
  Theta (libm atan2/sqrt) is deliberately excluded.
* ``thresholds_u53``: exact integer thresholds; per-bin error <= 2^-53
  relative to the exact rational target.

qiskit is imported lazily, only inside the functions below the reference
section, which run in the Aer worker, the IBM child and diagnostics.

Exactness levels, stated plainly:
  reference            invalid amplitude == 0.0 bitwise
  logical circuit      Statevector invalid entries == 0 (annotated controls)
  transpiled (opt 1)   invalid mass <= 1e-20, verified before any sampling
  Aer sampling         0 invalid outcomes expected; a residual <= 1e-15 per
                       shot is possible in principle (it would land on the
                       all-ones bitstring) and is recorded, never folded
  IBM hardware         invalid outcomes are measured and recorded
"""
import bisect, hashlib, math

SCALE = 1 << 53

#: Largest N a circuit backend accepts (q <= 10). Larger N use os_entropy
#: with fallback_reason "n_exceeds_circuit_cap".
MAX_CIRCUIT_N = 1024
#: Post-transpile verification bound (spec 3.4).
TRANSPILED_INVALID_MASS_MAX = 1e-20
#: The dense re-simulation used for verification refuses wider circuits.
MAX_VERIFY_QUBITS = 12
#: The only optimization level production code transpiles at (spec 3.4).
PRODUCTION_OPT_LEVEL = 1


class PrepError(ValueError):
    pass


class TranspiledInvalidMass(RuntimeError):
    """A transpiled circuit failed verification; it is refused, never sampled."""

    def __init__(self, mass, detail="transpiled_invalid_mass"):
        super().__init__("%s: %r" % (detail, mass))
        self.mass = mass
        self.detail = detail


# ── Reference implementation (spec 3.3, load-bearing, as written) ────────────

def n_qubits_for(n: int) -> int:
    if n < 2:
        raise PrepError("need >= 2 choices")
    return (n - 1).bit_length()

def normalize(weights, n=None):
    """-> (support, p, info); p are floats > 0; support are original indices."""
    w = [1.0] * n if weights is None else [float(x) for x in weights]
    if not w or (n is not None and len(w) != n):
        raise PrepError("empty or length mismatch")
    if any(math.isnan(x) or math.isinf(x) or x < 0.0 for x in w):
        raise PrepError("weights must be finite and >= 0")
    m = max(w)
    if m == 0.0:
        raise PrepError("all-zero weights")
    s = [x / m for x in w]                      # in [0, 1]; fsum cannot overflow
    tot = math.fsum(s)
    p_all = [x / tot for x in s]
    support = [i for i, x in enumerate(p_all) if x > 0.0]
    info = {"underflow_dropped": sum(1 for x, y in zip(w, p_all) if x > 0.0 and y == 0.0)}
    return support, [p_all[i] for i in support], info

def _node_key(pp, lo, span):
    half = span >> 1
    m = math.fsum(pp[lo:lo + span])
    if m == 0.0:
        return None                             # don't-care: zero-mass subtree
    mr = math.fsum(pp[lo + half:lo + span])
    if mr == 0.0:
        return (1.0, 0.0)                       # right half all invalid: identity, no gate
    return (math.fsum(pp[lo:lo + half]) / m, mr / m)

def _partition(keys, level):
    out = []
    def rec(prefixes, fixed):
        care = {keys[p] for p in prefixes if keys[p] is not None}
        if not care:
            return
        if len(care) == 1:
            k = care.pop()
            if k[1] != 0.0:
                out.append((tuple(b for b, _ in fixed), tuple(v for _, v in fixed), k))
            return
        used = {b for b, _ in fixed}
        bit = max(b for b in range(level) if b not in used)      # MSB of prefix first
        for v in (0, 1):
            rec([p for p in prefixes if (p >> bit) & 1 == v], fixed + [(bit, v)])
    rec(list(range(1 << level)), [])
    return tuple(out)

def plan(p):                                    # p: normalized, all > 0, len >= 2
    q = n_qubits_for(len(p))
    pp = list(p) + [0.0] * ((1 << q) - len(p))  # indices >= N' are invalid
    levels = tuple(
        _partition([_node_key(pp, pre << (q - lv), 1 << (q - lv)) for pre in range(1 << lv)], lv)
        for lv in range(q))
    return {"n": len(p), "q": q, "levels": levels}

def theta_of(key):
    return 2.0 * math.atan2(math.sqrt(key[1]), math.sqrt(key[0]))

def gate_list(pl):                              # [(target, [(ctrl_qubit, value)], theta)]
    q, out = pl["q"], []
    for lv, cubes in enumerate(pl["levels"]):
        for bits, vals, key in cubes:
            out.append((q - 1 - lv, [(q - lv + b, v) for b, v in zip(bits, vals)], theta_of(key)))
    return out

def reference_amplitudes(pl):                   # product form; invalid entries exactly 0.0
    q, out = pl["q"], []
    for b in range(1 << q):
        a = 1.0
        for lv, cubes in enumerate(pl["levels"]):
            prefix, bit, th = b >> (q - lv), (b >> (q - 1 - lv)) & 1, 0.0
            for bits, vals, key in cubes:
                if all((prefix >> x) & 1 == v for x, v in zip(bits, vals)):
                    th = theta_of(key); break
            a *= math.sin(th / 2) if bit else math.cos(th / 2)
        out.append(a)
    return out

def circuit_hash(pl, p):                        # inputs and keys only; theta (libm) excluded
    parts = ["qv2-prep-v2", "n=%d" % pl["n"], "q=%d" % pl["q"],
             "p=" + ",".join(float.hex(x) for x in p)]
    for lv, cubes in enumerate(pl["levels"]):
        for bits, vals, key in cubes:
            parts.append("L%d:%s:%s:%s,%s" % (lv, ".".join(map(str, bits)), ".".join(map(str, vals)),
                                             float.hex(key[0]), float.hex(key[1])))
    return hashlib.sha256("|".join(parts).encode()).hexdigest()

def thresholds_u53(w):                          # exact rational target w_i / sum(w)
    if not isinstance(w, (list, tuple)) or not w or len(w) > MAX_CIRCUIT_N:
        raise ValueError("invalid weights")
    if any(not math.isfinite(x) or x < 0 for x in w) or not any(x > 0 for x in w):
        raise ValueError("weights must be finite, nonnegative and nonzero")
    ratios = [float(x).as_integer_ratio() for x in w]
    den = max(b for _, b in ratios)             # powers of two
    ints = [a * (den // b) for a, b in ratios]
    total, c, t = sum(ints), 0, []
    for v in ints[:-1]:
        c += v
        t.append((2 * c * SCALE + total) // (2 * total))   # exact round-half-up
    t.append(SCALE)
    return t

def draw_index(thresholds, u53):                # first i with u53 < t[i]
    if type(u53) is not int or not 0 <= u53 < SCALE:
        raise ValueError("u53 outside sampling range")
    if not thresholds or thresholds[-1] != SCALE:
        raise ValueError("invalid thresholds")
    return bisect.bisect_right(thresholds, u53)

def decode_bitstring(bs, n_support):
    if type(n_support) is not int or not 1 <= n_support <= MAX_CIRCUIT_N:
        raise ValueError("invalid support size")
    width = max(1, (n_support - 1).bit_length())
    if not isinstance(bs, str) or len(bs) != width or any(c not in "01" for c in bs):
        return None, False
    b = int(bs, 2)
    return b, 0 <= b < n_support


# ── Helpers around the reference (pure Python) ───────────────────────────────

def unreachable_support(thresholds):
    """Candidates whose bin has zero width (p_i < 2^-54 can round to 0)."""
    prev, k = 0, 0
    for t in thresholds:
        if t == prev:
            k += 1
        prev = t
    return k


def reference_invalid_mass(amps, n_support):
    return math.fsum(a * a for a in amps[n_support:])


def uniform_plan(n):
    """Plan for the uniform distribution over n >= 2 outcomes."""
    _support, p, _info = normalize(None, n)
    return plan(p), p


# ── Qiskit circuit (lazy qiskit import; spec 3.4) ────────────────────────────

def build_qiskit_circuit(pl, measure=True):
    from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister
    from qiskit.circuit.library import RYGate
    q = pl["q"]; qc = QuantumCircuit(QuantumRegister(q, "q"))
    for tgt, ctrls, th in gate_list(pl):
        if not ctrls:
            qc.ry(th, tgt)
        else:
            state = sum(v << j for j, (_, v) in enumerate(ctrls))
            qc.append(RYGate(th).control(len(ctrls), ctrl_state=state, annotated=True),
                      [c for c, _ in ctrls] + [tgt])
    if measure:
        qc.add_register(ClassicalRegister(q, "m")); qc.measure(range(q), range(q))
    return qc


def transpile_one(circuit, *, seed_transpiler, backend=None, basis_gates=None,
                  coupling_map=None):
    """Transpile exactly ONE circuit at optimization_level=1.

    A list longer than 1 raises: with a single circuit qiskit's parallel_map
    never starts a process pool (spec 3.4 / 7.5). Opt 2/3 are never used in
    production because they can leak invalid mass (measured up to 2.3e-9).
    """
    if isinstance(circuit, (list, tuple)):
        if len(circuit) != 1:
            raise ValueError("transpile_one takes exactly one circuit, got %d" % len(circuit))
        circuit = circuit[0]
    from qiskit import transpile
    return transpile(circuit, backend=backend, basis_gates=basis_gates,
                     coupling_map=coupling_map, optimization_level=1,
                     seed_transpiler=seed_transpiler)


def measured_qubit_map(tqc):
    """{classical bit index: qubit index} from the measure instructions."""
    out = {}
    for inst in tqc.data:
        if inst.operation.name == "measure":
            out[tqc.find_bit(inst.clbits[0]).index] = tqc.find_bit(inst.qubits[0]).index
    return out


def transpiled_invalid_mass(tqc, n_support):
    """Invalid probability mass of a transpiled, measured circuit.

    Takes the qubits the circuit touches (refusing more than
    MAX_VERIFY_QUBITS), remaps them densely, computes the statevector without
    measurements, and marginalizes onto the measured qubits through the
    measure map (which encodes the final layout). Works for the Aer circuit
    (no layout) and for a backend-sized IBM circuit.
    """
    from qiskit import QuantumCircuit
    from qiskit.quantum_info import Statevector
    cmap = measured_qubit_map(tqc)
    if not cmap:
        raise TranspiledInvalidMass(float("inf"), "no_measurements")
    measured = set(cmap.values())
    active = set(measured)
    body = []
    seen_measured = set()
    for inst in tqc.data:
        name = inst.operation.name
        idx = [tqc.find_bit(qb).index for qb in inst.qubits]
        if name == "measure":
            seen_measured.update(idx)
            continue
        if name in ("barrier", "delay"):
            continue
        if name == "reset" or inst.clbits:
            raise TranspiledInvalidMass(float("inf"), "unsupported_instruction_%s" % name)
        if seen_measured.intersection(idx):
            raise TranspiledInvalidMass(float("inf"), "gate_after_measure")
        active.update(idx)
        body.append((inst.operation, idx))
    if len(active) > MAX_VERIFY_QUBITS:
        raise TranspiledInvalidMass(float("inf"), "too_many_active_qubits_%d" % len(active))
    order = sorted(active)
    pos = {qq: i for i, qq in enumerate(order)}
    dense = QuantumCircuit(len(order))
    for op, idx in body:
        dense.append(op, [pos[i] for i in idx])
    probs = Statevector(dense).probabilities().tolist()
    items = [(c, pos[qidx]) for c, qidx in cmap.items()]
    invalid = []
    for s, pr in enumerate(probs):
        if pr == 0.0:
            continue
        b = 0
        for c, d in items:
            if (s >> d) & 1:
                b |= 1 << c
        if b >= n_support:
            invalid.append(pr)
    return math.fsum(invalid)


def verify_transpiled(tqc, n_support):
    """Raise TranspiledInvalidMass unless the invalid mass is <= 1e-20."""
    mass = transpiled_invalid_mass(tqc, n_support)
    if not (mass <= TRANSPILED_INVALID_MASS_MAX):
        raise TranspiledInvalidMass(mass)
    return mass


def two_qubit_gate_count(tqc):
    return sum(1 for inst in tqc.data
               if inst.operation.num_qubits == 2 and inst.operation.name not in ("barrier",))


def logical_statevector(pl):
    """Statevector (list of complex) of the unmeasured logical circuit."""
    from qiskit.quantum_info import Statevector
    return Statevector(build_qiskit_circuit(pl, measure=False)).data.tolist()
