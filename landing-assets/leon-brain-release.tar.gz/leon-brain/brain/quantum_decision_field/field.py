"""Bounded, signal-only local possibility field. No action or network authority.

Complex amplitudes are a quantum-inspired classical representation. Phases do
not change computational-basis probabilities without an interference circuit.
The optional Aer adapter is for an explicitly designated experiment worker.
"""
from dataclasses import dataclass, field
import cmath
import hashlib
import json
import math
import secrets
import time
import uuid

from . import prep

MAX_CANDIDATES = 1024
MAX_FEATURES = 64
CONTEXT_CHANNELS = ("perception", "memory", "goals", "reward", "uncertainty", "self_state")


class CandidateRejected(ValueError):
    pass


def _finite(value, name):
    if isinstance(value, bool):
        raise ValueError(name)
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(name)
    return value


@dataclass(frozen=True)
class QuantumCandidate:
    candidate_id: str
    label: str
    value: object
    prior_logit: float = 0.0
    phase: float = 0.0
    features: tuple = ()
    risk: str = "unknown"

    def __post_init__(self):
        if not isinstance(self.candidate_id, str) or not 1 <= len(self.candidate_id) <= 128:
            raise ValueError("candidate_id")
        if not isinstance(self.label, str) or len(self.label) > 256:
            raise ValueError("label")
        if not isinstance(self.features, (list, tuple)) or len(self.features) > MAX_FEATURES:
            raise ValueError("features")
        object.__setattr__(self, "features", tuple(_finite(x, "feature") for x in self.features))
        object.__setattr__(self, "prior_logit", _finite(self.prior_logit, "prior_logit"))
        object.__setattr__(self, "phase", _finite(self.phase, "phase"))


@dataclass(frozen=True)
class PreparedField:
    candidate_ids: tuple
    probabilities: tuple
    phases: tuple
    amplitudes: tuple
    policy_version: str
    circuit_hash: str


@dataclass(frozen=True)
class QuantumDecisionV2:
    decision_id: str
    candidates: tuple
    source: str
    prepared_probabilities: tuple
    measurement: object
    chosen_id: object
    shots: int
    diagnostic: bool
    latency_ms: float
    metadata: dict = field(default_factory=dict)

    @property
    def authorizes_action(self):
        return False

    @property
    def quantum_decided(self):
        # These local candidates never claim physical hardware involvement.
        return False


def validate_candidates(candidates, authorize=None):
    if not isinstance(candidates, (tuple, list)) or not 1 <= len(candidates) <= MAX_CANDIDATES:
        raise CandidateRejected("candidate count must be 1..1024")
    candidates = tuple(candidates)
    if any(not isinstance(c, QuantumCandidate) for c in candidates):
        raise CandidateRejected("typed candidates required")
    if len({c.candidate_id for c in candidates}) != len(candidates):
        raise CandidateRejected("duplicate candidate id")
    # Reject the entire request before preparing amplitudes or drawing entropy.
    # Never silently discard an unsafe option and make a different decision.
    if any(c.risk != "low" for c in candidates):
        raise CandidateRejected("only predeclared low-risk candidates are eligible")
    if authorize is not None and any(authorize(c) is not True for c in candidates):
        raise CandidateRejected("candidate authorization refused")
    return candidates


def prepare(candidates, *, policy=None, context=None, authorize=None):
    candidates = validate_candidates(candidates, authorize)
    if policy is not None:
        policy = policy.snapshot()
    context = {} if context is None else dict(context)
    if set(context) - set(CONTEXT_CHANNELS):
        raise ValueError("unknown context channel")
    compact = tuple(_finite(context.get(k, 0.0), k) for k in CONTEXT_CHANNELS)
    if any(abs(x) > 1.0 for x in compact):
        raise ValueError("context channels must be scaled to [-1, 1]")
    logits, phases = [], []
    for candidate in candidates:
        logit, phase = candidate.prior_logit, candidate.phase
        if policy is not None:
            dl, dp = policy.predict(candidate.features + compact)
            logit += _finite(dl, "policy logit")
            phase += _finite(dp, "policy phase")
        logits.append(_finite(logit, "combined logit"))
        phases.append(math.remainder(_finite(phase, "combined phase"), 2 * math.pi))
    maximum = max(logits)
    weights = [math.exp(x - maximum) for x in logits]
    total = math.fsum(weights)
    probabilities = tuple(w / total for w in weights)
    q = (len(candidates) - 1).bit_length()
    amps = [math.sqrt(p) * cmath.exp(1j * phase) for p, phase in zip(probabilities, phases)]
    amps.extend([0j] * ((1 << q) - len(candidates)))
    version = str(getattr(policy, "version", "prior/1"))
    ids = tuple(c.candidate_id for c in candidates)
    descriptor = [ids, [p.hex() for p in probabilities], [p.hex() for p in phases], version]
    digest = hashlib.sha256(json.dumps(descriptor, separators=(",", ":")).encode()).hexdigest()
    return PreparedField(ids, probabilities, tuple(phases), tuple(amps), version, digest)


def state_preparation(prepared):
    """Lazy optional Qiskit adapter; never downloads a model or contacts IBM."""
    from qiskit import QuantumCircuit
    from qiskit.circuit.library import StatePreparation
    q = (len(prepared.amplitudes) - 1).bit_length()
    circuit = QuantumCircuit(q)
    if q:
        circuit.append(StatePreparation(list(prepared.amplitudes)), range(q))
    return circuit


class AerFieldSampler:
    """One physical-simulation shot; call only in a bounded experiment process.

    The enclosing sandbox/worker must impose a process deadline: native simulator
    calls cannot be made safely cancellable by a Python Future timeout.
    """
    def sample(self, prepared):
        from qiskit import transpile
        from qiskit_aer import AerSimulator
        circuit = state_preparation(prepared)
        circuit.measure_all()
        simulator = AerSimulator(method="statevector", max_parallel_threads=1,
                                 max_parallel_experiments=1, max_parallel_shots=1)
        seed = secrets.randbits(31)
        compiled = transpile(circuit, simulator, optimization_level=1,
                             seed_transpiler=seed, num_processes=1)
        bitstring = simulator.run(compiled, shots=1, memory=True,
                                 seed_simulator=seed).result().get_memory()[0]
        return {"bitstring": bitstring, "shots": 1, "backend": "aer_statevector",
                "seed_simulator": seed, "seed_transpiler": seed}


class LocalPossibilityField:
    """Opt-in decision signals. Default OFF; diagnostics never select a choice."""
    def __init__(self, *, enabled=False, policy=None, authorize=None, draw_u53=None,
                 aer_sampler=None, experiment_worker=False):
        if type(enabled) is not bool or type(experiment_worker) is not bool:
            raise ValueError("explicit boolean flags required")
        self.enabled, self.policy, self.authorize = enabled, policy, authorize
        self._draw = draw_u53 or (lambda: secrets.randbits(53))
        self._aer = aer_sampler
        self.experiment_worker = experiment_worker

    def decide(self, candidates, *, context=None, backend="classical", diagnostic=False, shots=1):
        if not self.enabled:
            raise RuntimeError("local possibility field is off")
        if type(diagnostic) is not bool or type(shots) is not int or not 1 <= shots <= 100000:
            raise ValueError("diagnostic/shots")
        if not diagnostic and shots != 1:
            raise ValueError("causal selection requires exactly one shot")
        if backend not in ("classical", "aer"):
            raise ValueError("hardware jobs require a separately approved experiment worker")
        if backend == "aer" and not self.experiment_worker:
            raise ValueError("Aer requires a bounded experiment worker")
        start = time.perf_counter()
        prepared = prepare(candidates, policy=self.policy, context=context, authorize=self.authorize)
        meta = {"circuit_hash": prepared.circuit_hash, "policy_version": prepared.policy_version,
                "representation": "quantum_inspired_classical", "backend": backend,
                "phases_affect_basis_probabilities": False}
        counts, invalid, result = {}, 0, None
        thresholds = prep.thresholds_u53(prepared.probabilities)
        source = "classical_weighted"
        for _ in range(shots):
            if backend == "aer" and len(candidates) > 1:
                raw = (self._aer or AerFieldSampler()).sample(prepared)
                if type(raw.get("shots")) is not int or raw["shots"] != 1 or not raw.get("backend"):
                    raise ValueError("invalid Aer provenance")
                index, valid = prep.decode_bitstring(raw.get("bitstring"), len(candidates))
                source = "aer"
                meta["last_sample"] = dict(raw)
                if not valid:
                    invalid += 1
                    if diagnostic:
                        continue
                    # Refuse invalid padded states: no modulo fold, majority,
                    # fallback entropy, retry, or action-producing choice.
                    raise ValueError("invalid measurement outcome")
            else:
                index = prep.draw_index(thresholds, self._draw())
                if backend == "aer":
                    source = "trivial"
            result = index
            counts[str(index)] = counts.get(str(index), 0) + 1
        meta.update(counts=counts, invalid_outcomes=invalid)
        return QuantumDecisionV2(uuid.uuid4().hex, prepared.candidate_ids, source,
                                 prepared.probabilities, counts if diagnostic else result,
                                 None if diagnostic else prepared.candidate_ids[result],
                                 shots, diagnostic, (time.perf_counter() - start) * 1000, meta)


def matched_comparison(prepared, *, legacy_probabilities=None, observed_counts=None):
    """Distribution comparison, not invented counterfactual task outcomes.

    Imported Aer/IBM counts are explicitly caller-supplied evidence. Missing
    hardware data remains missing; equal distributions retain a null finding.
    """
    n = len(prepared.candidate_ids)
    out = {"schema": "qv2.counterfactual/1", "candidate_ids": prepared.candidate_ids,
           "policy_version": prepared.policy_version, "circuit_hash": prepared.circuit_hash,
           "local_field": prepared.probabilities, "matched_classical": prepared.probabilities,
           "local_vs_matched_total_variation": 0.0, "task_effect": None,
           "quantum_advantage": "not_established", "observations": {}}
    if legacy_probabilities is not None:
        if len(legacy_probabilities) != n:
            raise ValueError("legacy distribution length")
        prep.normalize(legacy_probabilities, n)
        # normalize compacts zero support, so retain original basis explicitly.
        maximum = max(legacy_probabilities)
        scaled = [float(x) / maximum for x in legacy_probabilities]
        total = math.fsum(scaled)
        out["legacy"] = tuple(x / total for x in scaled)
    for source, counts in (observed_counts or {}).items():
        if source not in ("aer", "ibm_hardware") or len(counts) != n:
            raise ValueError("observation source/length")
        if any(type(x) is not int or x < 0 for x in counts) or sum(counts) <= 0:
            raise ValueError("observed counts")
        total = sum(counts)
        p = tuple(x / total for x in counts)
        tv = math.fsum(abs(x - y) for x, y in zip(p, prepared.probabilities)) / 2
        out["observations"][source] = {"provenance": "caller_supplied_unverified",
            "shots": total, "total_variation": tv,
            "finding": "descriptive_null" if tv == 0 else "descriptive_difference"}
    return out
