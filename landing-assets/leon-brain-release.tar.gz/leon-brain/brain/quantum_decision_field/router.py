"""DecisionFieldRouter: the legacy-compatible ``decide()`` (spec 6.2).

Routing, in order:
  1. an open causal slot for this context and n (inert in Phase 11);
  2. mode on and the context authoritative -> V2 decides;
  3. mode on, a realtime caller while the legacy engine would run on IBM hardware
     (unbounded transpile/run on the sim thread) -> V2 decides (the guard);
  4. otherwise legacy decides with identical arguments and the SAME object is
     returned; V2 observes (shadow).

Realtime: context workspace_access, or any thread not named DreamEngine or
DaydreamEngine (fail safe). New real-time V2 selection does O(N) local
preparation: no Aer, no IBM, no file I/O, and it never calls
legacy from an authoritative, causal or guard path. A V2-internal error on a
realtime caller gives a recorded uniform draw; on a non-realtime caller it
falls through to legacy.

Every new selection requires an injected low-risk candidate validator BEFORE
fallback handling. The callback must itself be bounded. Shadow preserves the
legacy call and needs legacy's own hardware protections. A lock is taken when
each thread first registers counters; other queues use bounded deques. Counts
precede detail enqueue. Concurrent producers can evict older detail at capacity.
"""
import collections
import itertools
import os
import secrets
import threading
import time
import uuid
from types import SimpleNamespace
from concurrent.futures import TimeoutError as FutureTimeout
from time import perf_counter_ns

from . import authority, policy, prep
from .backends import ClassicalBackend
from .provenance import (Provenance, Source, V2Decision, legacy_source_fast,
                         ROUTE_AUTHORITATIVE, ROUTE_CAUSAL, ROUTE_EMERGENCY, ROUTE_GUARD)

_NONRT = authority.NONREALTIME_THREAD_NAMES
_current_thread = threading.current_thread


class _ThreadCounters:
    __slots__ = ("counts", "drops", "name")

    def __init__(self, name):
        self.counts = {}
        self.drops = {}
        self.name = name


class DecisionFieldRouter:
    SHADOW_CAP = 1024
    RECORD_CAP = 1024

    def __init__(self, legacy, brain, cfg, *, clock=time.time, store_factory=None,
                 aer_backend=None, repo_root=None, candidate_validator=None):
        self._legacy = legacy
        self._brain = brain
        self.cfg = cfg
        self._clock = clock
        self.repo_root = repo_root
        self.candidate_validator = candidate_validator
        self.boot_id = uuid.uuid4().hex
        self.boot_ts = clock()
        self._seq = itertools.count(1)
        self._tls = threading.local()
        self._tc_all = []
        self._tc_lock = threading.Lock()
        self._shadow_q = collections.deque(maxlen=self.SHADOW_CAP)
        self._record_q = collections.deque(maxlen=self.RECORD_CAP)
        # One preregistered experiment has at most 112 consumed slots. Refuse
        # before consumption when a stalled writer has retained all of them.
        self._causal_q = collections.deque()
        self._mode_on = cfg.mode == "on"
        self._auth = frozenset(cfg.authoritative)
        self._classical = ClassicalBackend()
        self._aer_on = cfg.backend == "aer" and cfg.action_gate == "ready"
        self._aer = aer_backend
        self._deadline_s = cfg.aer_deadline_ms / 1000.0
        self._causal = None
        self._causal_active = False
        self._broker = None
        self.suspended = legacy is None
        self.closed = False
        self._stop = threading.Event()
        self.rebinds = 0
        self.internal_errors = collections.Counter()
        if store_factory is None:
            from .store import Store
            store_factory = Store
        self.store = store_factory(self, cfg.state_dir)

    # ── lifecycle ─────────────────────────────────────────────────────────
    def start(self):
        if self.closed:
            raise RuntimeError("decision field is closed")
        self.store.start()
        return self

    def rebind(self, legacy, brain):
        """Atomic reference swap; the same router keeps serving (I14)."""
        if self.closed:
            raise RuntimeError("decision field is closed")
        self._legacy = legacy
        self._brain = brain
        self.suspended = legacy is None
        self.rebinds += 1

    def attach_event_bus(self, bus, new_event):
        """Never called in Phase 11 (spec 9.3). Kept so a later phase can
        publish signal-only events with a factory passed in, without this
        package importing brain.cognition."""
        self._bus = bus
        self._new_event = new_event

    def close(self, timeout=1.0):
        """Never blocks for long: stop event, kill a live IBM child group,
        join the writer for at most ``timeout``. Never joins Aer or IBM."""
        if self.closed:
            return
        self.closed = True
        self._stop.set()
        b = self._broker
        if b is not None:
            try:
                b.stop()
            except Exception:
                pass
        if self._aer is not None:
            try:
                self._aer.shutdown()
            except Exception:
                pass
        try:
            self.store.join(timeout)
        except Exception:
            pass

    # ── caller path helpers ──────────────────────────────────────────────
    def _tc(self):
        try:
            return self._tls.c
        except AttributeError:
            tc = _ThreadCounters(_current_thread().name)
            with self._tc_lock:
                self._tc_all.append(tc)
            self._tls.c = tc
            return tc

    def _count(self, key):
        c = self._tc().counts
        c[key] = c.get(key, 0) + 1

    def _drop(self, context, source):
        d = self._tc().drops
        k = (context, source)
        d[k] = d.get(k, 0) + 1

    def _enqueue_record(self, item, context, source):
        if self.closed:
            return
        if len(self._record_q) < self.RECORD_CAP:
            self._record_q.append(item)
        else:
            self._drop(context, source)

    def _legacy_ibm_now(self, legacy):
        try:
            return str(legacy.effective_source()).startswith("ibm:")
        except Exception:
            return False

    # ── decide ───────────────────────────────────────────────────────────
    def decide(self, candidates, scores=None, labels=None, context="decision", shots=None):
        if self.closed:
            raise RuntimeError("decision field is closed")
        t0 = perf_counter_ns()
        n = len(candidates)
        if n == 0:
            raise ValueError("Cannot decide among zero candidates")
        tname = _current_thread().name
        rt = context == "workspace_access" or tname not in _NONRT
        legacy = self._legacy
        internal = None
        causal_due = self._causal_active and self._causal.slot_due(context, n)
        guard_due = self._mode_on and rt and legacy is not None and self._legacy_ibm_now(legacy)
        if causal_due or (self._mode_on and context in self._auth) or guard_due:
            # A static action-gate declaration is not candidate authorization.
            # Refusal must escape before any draw or emergency/legacy fallback.
            from .field import CandidateRejected, MAX_CANDIDATES
            if (n > MAX_CANDIDATES or self.candidate_validator is None or
                    self.candidate_validator(candidates, context) is not True):
                raise CandidateRejected("V2 selection requires explicit low-risk candidate validation")
            if shots not in (None, 1) or isinstance(shots, bool):
                raise CandidateRejected("V2 causal selection requires one shot")
            if causal_due and len(self._causal_q) >= authority.CAUSAL_MAX_SLOTS_TOTAL:
                raise CandidateRejected("causal audit queue full")
        try:
            if causal_due:
                dec = self._decide_causal(candidates, labels, context, n, shots, t0, rt, tname)
                if dec is not None:
                    return dec
            if self._mode_on and context in self._auth:
                return self._decide_authoritative(candidates, scores, labels, context, shots, t0,
                                                  rt, tname, ROUTE_AUTHORITATIVE, None)
            if guard_due:
                return self._decide_authoritative(candidates, scores, labels, context, shots, t0,
                                                  rt, tname, ROUTE_GUARD,
                                                  "legacy_ibm_on_realtime_refused")
        except Exception as e:                  # V2-internal errors only
            self.internal_errors[type(e).__name__] += 1
            if rt:
                return self._emergency_uniform(candidates, labels, context, t0, tname, e)
            internal = "v2_internal_error"
        if legacy is None:
            raise RuntimeError("decision engine suspended")
        t_l0 = perf_counter_ns()
        result = legacy.decide(candidates=candidates, scores=scores, labels=labels,
                               context=context, shots=shots)      # exceptions propagate unchanged
        t_l1 = perf_counter_ns()
        self._shadow(context, n, labels, scores, result, t0, t_l0, t_l1, rt, tname, internal)
        return result

    def _shadow(self, context, n, labels, scores, result, t0, t_l0, t_l1, rt, tname, internal):
        src = "unknown"
        try:
            src = legacy_source_fast(getattr(result, "source", None))
            self._count((context, "shadow", src, internal, "shadow"))
            if n > prep.MAX_CIRCUIT_N or not 0 <= int(getattr(result, "n_qubits", 0) or 0) <= 10:
                self._drop(context, src)
                return
            if len(self._shadow_q) < self.SHADOW_CAP:
                # The writer runs later. Copy bounded inputs so caller mutation
                # cannot silently rewrite the evidence for a past choice.
                scores = tuple(itertools.islice(scores, n)) if scores is not None else None
                labels = tuple(str(x)[:80] for x in itertools.islice(labels, n)) if labels is not None else None
                fields = {key: getattr(result, key, None) for key in
                          ("source", "chosen_index", "latency_ms", "measurement", "n_qubits", "shots")}
                for key, cap in (("measurement_counts", 1024), ("brain_state", 64), ("region_firing", 64)):
                    value = getattr(result, key, None)
                    fields[key] = dict(itertools.islice(value.items(), cap)) if isinstance(value, dict) else None
                observed = SimpleNamespace(**fields)
                ovh = (t_l0 - t0) + (perf_counter_ns() - t_l1)
                self._shadow_q.append((self._clock(), next(self._seq), context, n, scores, labels,
                                       observed, os.environ.get("LEON_QUANTUM_SOURCE"), rt, tname,
                                       ovh, t_l1 - t_l0, internal))
            else:
                self._drop(context, src)
        except Exception:
            try:
                self._drop(context, src)
            except Exception:
                pass

    def _decide_authoritative(self, candidates, scores, labels, context, shots, t0, rt, tname,
                              route, route_reason):
        n = len(candidates)
        w, pinfo = policy.proportional(scores, n)
        support, p, ninfo = prep.normalize(w, n)
        seq = next(self._seq)
        attempted = []
        fb_from = fb_reason = None
        bitstring = valid = u = None
        entropy = ()
        extra = None
        th = None
        if len(support) == 1:
            idx, source, outcome = support[0], Source.TRIVIAL, "trivial"
            route_reason = route_reason or "trivial"
        else:
            th = prep.thresholds_u53(p)
            outcome = "decided"
            use_aer = (not rt and self._aer_on and route == ROUTE_AUTHORITATIVE)
            if use_aer and n > prep.MAX_CIRCUIT_N:
                use_aer = False
                fb_from, fb_reason = Source.AER, "n_exceeds_circuit_cap"
            if use_aer:
                route_reason = route_reason or "backend_aer"
                attempted.append(Source.AER)
                aer_out, fb_reason, extra = self._aer_one(support, p, context, seq)
                if aer_out is not None:
                    bitstring = aer_out["bitstring"]
                    b, valid = prep.decode_bitstring(bitstring, len(support))
                    entropy = (("seed_simulator", aer_out["seed_simulator"]),
                               ("transpile_seed", aer_out["transpile_seed"]))
                    if valid:
                        idx, source = support[b], Source.AER
                    else:
                        fb_reason, outcome = "invalid_outcome", "invalid_outcome"
                if fb_reason is not None:
                    fb_from = Source.AER
            if not use_aer or fb_reason is not None:
                if route_reason is None:
                    route_reason = "realtime_policy" if rt else "backend_classical"
                attempted.append(Source.OS_ENTROPY)
                out = self._classical.sample(th)
                idx, source, u = support[out.index], Source.OS_ENTROPY, out.u53
                entropy = entropy + (("u53", u),)
        probs = [0.0] * n
        for i, pi in zip(support, p):
            probs[i] = pi
        lat_ms = (perf_counter_ns() - t0) / 1e6
        prov = Provenance(decision_seq=seq, source=source, route=route, route_reason=route_reason,
                          context=context, realtime=rt, outcome=outcome, shots=1,
                          shots_requested=shots, u53=u, bitstring=bitstring, valid=valid,
                          latency_ms=lat_ms,
                          deadline_ms=self.cfg.aer_deadline_ms if Source.AER in attempted else None,
                          attempted=tuple(attempted), fallback_from=fb_from,
                          fallback_reason=fb_reason, entropy=entropy)
        dec = V2Decision(idx, candidates[idx], context, n, labels, probs, source, prov,
                         self._clock(), lat_ms)
        self._count((context, route, source, fb_reason, outcome))
        self._enqueue_record(("auth", self._clock(), seq, context, n, scores, labels, dec, pinfo,
                              ninfo, support, p, th, os.environ.get("LEON_QUANTUM_SOURCE"), rt,
                              tname, extra), context, source)
        return dec

    def _aer_one(self, support, p, context, seq):
        """Non-realtime only. -> (outcome dict | None, fallback_reason | None, extra)."""
        aer = self._aer
        if aer is None:
            from .backends import AerBackend
            aer = self._aer = AerBackend(self.cfg.aer_deadline_ms)
        if aer.breaker_open():
            return None, "aer_breaker_open", None
        pl = prep.plan(p)
        ch = prep.circuit_hash(pl, p)
        seed = secrets.randbits(63)
        fut = aer.submit_one(pl, len(support), ch, seed)
        if fut is None:
            return None, "aer_busy", None
        try:
            return fut.result(timeout=self._deadline_s), None, {"circuit_hash": ch}
        except FutureTimeout:
            fut.cancel()
            aer.note_miss()

            def late(f, seq=seq, context=context):
                if f.cancelled():
                    return
                try:
                    out = f.result()
                except Exception as e:
                    out = {"error_class": type(e).__name__}
                self._enqueue_record(("late", self._clock(), seq, context, out), context, Source.AER)
            fut.add_done_callback(late)
            return None, "deadline_%d" % self.cfg.aer_deadline_ms, {"circuit_hash": ch}
        except prep.TranspiledInvalidMass:
            return None, "transpiled_invalid_mass", {"circuit_hash": ch}
        except Exception as e:
            return None, "aer_error:" + type(e).__name__, {"circuit_hash": ch}

    def _decide_causal(self, candidates, labels, context, n, shots, t0, rt, tname):
        r = self._causal.consume(n)
        if r is None:
            return None
        seq = next(self._seq)
        idx = r["index"]
        lat_ms = (perf_counter_ns() - t0) / 1e6
        prov = Provenance(decision_seq=seq, source=r["source"], route=ROUTE_CAUSAL,
                          route_reason="causal_arm", context=context, realtime=rt,
                          outcome=r.get("outcome", "decided"), shots=1, shots_requested=shots,
                          job_id=(r.get("item") or {}).get("job_id"), u53=r.get("u53"),
                          bitstring=r.get("bitstring"), valid=r.get("valid"), latency_ms=lat_ms,
                          attempted=(r["arm"],) if r["arm"] == r["source"] else (r["arm"], Source.OS_ENTROPY),
                          fallback_from=r.get("fallback_from"), fallback_reason=r.get("fallback_reason"))
        probs = [1.0 / n] * n
        dec = V2Decision(idx, candidates[idx], context, n, labels, probs, r["source"], prov,
                         self._clock(), lat_ms)
        self._count((context, ROUTE_CAUSAL, r["source"], r.get("fallback_reason"),
                     r.get("outcome", "decided")))
        self._causal_q.append(("causal", self._clock(), seq, context, n, labels, r, dec, rt, tname))
        return dec

    def _emergency_uniform(self, candidates, labels, context, t0, tname, err):
        n = len(candidates)
        i = secrets.randbelow(n)
        seq = next(self._seq)
        lat_ms = (perf_counter_ns() - t0) / 1e6
        reason = "v2_internal_error:" + type(err).__name__
        prov = Provenance(decision_seq=seq, source=Source.OS_ENTROPY, route=ROUTE_EMERGENCY,
                          route_reason="emergency_uniform", context=context, realtime=True,
                          outcome="v2_internal_error", latency_ms=lat_ms,
                          attempted=(Source.OS_ENTROPY,), fallback_reason=reason)
        dec = V2Decision(i, candidates[i], context, n, labels, [1.0 / n] * n, Source.OS_ENTROPY,
                         prov, self._clock(), lat_ms)
        try:
            self._count((context, ROUTE_EMERGENCY, Source.OS_ENTROPY, "v2_internal_error",
                         "v2_internal_error"))
            self._enqueue_record(("emergency", self._clock(), seq, context, n, labels, dec,
                                  type(err).__name__, tname), context, Source.OS_ENTROPY)
        except Exception:
            pass
        return dec

    # ── observation ──────────────────────────────────────────────────────
    def counter_snapshot(self):
        with self._tc_lock:
            tcs = list(self._tc_all)
        counts, drops = collections.Counter(), collections.Counter()
        for tc in tcs:
            for k, v in tc.counts.copy().items():
                counts[k] += v
            for k, v in tc.drops.copy().items():
                drops[k] += v
        return counts, drops

    def mem_estimate_bytes(self):
        est = len(self._shadow_q) * 5600 + len(self._record_q) * 2400 + len(self._causal_q) * 2400
        if self._aer is not None:
            est += self._aer.lru_size() * 64 * 1024
        with self._tc_lock:
            est += sum(200 * (len(tc.counts) + len(tc.drops)) for tc in self._tc_all)
        return est

    def describe(self):
        cfg = self.cfg
        refused = ",".join("%s:%s" % r for r in cfg.policy_refused) or "none"
        auth = ",".join(sorted(self._auth)) or "none"
        return ("decision field v2 mode=%s authoritative=%s backend=%s causal=%s action_gate=%s "
                "writer=%s state_dir=%s policy_refused=%s boot_id=%s"
                % (cfg.mode, auth, "aer" if self._aer_on else "classical",
                   "on" if self._causal_active else "off", cfg.action_gate,
                   self.store.status, cfg.state_dir, refused, self.boot_id[:12]))

    def stats(self):
        counts, drops = self.counter_snapshot()
        total = sum(counts.values())
        by_source = collections.Counter()
        by_outcome = collections.Counter()
        by_context = collections.Counter()
        for (ctx, route, src, fb, outcome), v in counts.items():
            by_source[src] += v
            by_outcome[outcome] += v
            by_context[ctx] += v
        out = {"mode": self.cfg.mode, "constructed": True, "suspended": self.suspended,
               "closed": self.closed, "boot_id": self.boot_id, "boot_ts": self.boot_ts,
               "flags": self.cfg.flags_block(),
               "policy_refused": [{"item": a, "reason": b} for a, b in self.cfg.policy_refused],
               "decisions_total": total, "by_source": dict(by_source),
               "by_outcome": dict(by_outcome), "by_context": dict(by_context),
               "counters": [list(k) + [v] for k, v in sorted(counts.items(), key=repr)],
               "drops": [list(k) + [v] for k, v in sorted(drops.items(), key=repr)],
               "drops_total": sum(drops.values()),
               "queues": {"shadow": len(self._shadow_q), "record": len(self._record_q),
                          "causal": len(self._causal_q)},
               "internal_errors": dict(self.internal_errors),
               "rebinds": self.rebinds, "mem_estimate_bytes": self.mem_estimate_bytes(),
               "writer": self.store.status_block(),
               "causal": self._causal_status(),
               "joint_budget": self._joint_budget()}
        return out

    def _causal_status(self):
        st = getattr(self.store, "causal_status", None)
        base = {"active": self._causal_active}
        if isinstance(st, dict):
            base.update(st)
        if self._broker is not None:
            base["reservoir"] = self._broker.reservoir_sizes()
            base["broker_last_cycle"] = self._broker.last_cycle
            base["ibm_unavailable_reason"] = self._broker.unavailable_reason
        return base

    def _joint_budget(self):
        cache = getattr(self, "_jb_cache", None)
        now = self._clock()
        if cache is not None and now - cache[0] < 60:
            return cache[1]
        from .ledger import IbmLedger, default_budget_path, legacy_jobs_used
        cap = authority.legacy_budget_cap(self.repo_root)
        led = IbmLedger(os.path.join(self.cfg.state_dir, "ibm_ledger.jsonl"))
        try:
            summ = led.replay(now).summary(now)
        except Exception as e:
            summ = {"error": type(e).__name__}
        val = {"legacy_cap_parsed": cap, "legacy_jobs_used": legacy_jobs_used(default_budget_path(self.repo_root)),
               "v2_rolling_28d": summ.get("v2_rolling_28d"),
               "f5_satisfied": cap is not None and cap <= authority.LEGACY_MAX_BUDGET,
               "last_usage": summ.get("last_usage"), "breaker_open_until": summ.get("breaker_open_until"),
               "in_flight": summ.get("in_flight")}
        self._jb_cache = (now, val)
        return val

    def recent(self, n=20):
        return self.store.recent(max(1, min(int(n), 100)))
