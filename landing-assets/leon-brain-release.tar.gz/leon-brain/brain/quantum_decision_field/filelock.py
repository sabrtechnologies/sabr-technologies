"""Cross-process file locks: fcntl.flock on POSIX, msvcrt.locking on Windows.

``open_lock(path)`` returns None when neither module exists. The IBM broker
then refuses to start, and the writer runs with an in-process lock only and
records that. Both imports are guarded (an unguarded ``import fcntl`` once took
down every router on Windows).
"""
import os
import threading
import time

try:
    import fcntl as _fcntl
except ImportError:  # pragma: no cover - Windows
    _fcntl = None
try:
    import msvcrt as _msvcrt
except ImportError:
    _msvcrt = None


def backend_name():
    if _fcntl is not None:
        return "flock"
    if _msvcrt is not None:
        return "msvcrt"
    return None


def available():
    return backend_name() is not None


class FileLock:
    """Exclusive advisory lock on ``path``. Each instance holds its own open
    file description, so two instances exclude each other even in one
    process (flock semantics)."""

    def __init__(self, path, fcntl_mod=None, msvcrt_mod=None):
        self.path = path
        self._fcntl = _fcntl if fcntl_mod is None else fcntl_mod
        self._msvcrt = _msvcrt if msvcrt_mod is None else msvcrt_mod
        self._fh = None

    @property
    def held(self):
        return self._fh is not None

    def _try_once(self, fh):
        if self._fcntl is not None:
            try:
                self._fcntl.flock(fh.fileno(), self._fcntl.LOCK_EX | self._fcntl.LOCK_NB)
                return True
            except (BlockingIOError, PermissionError):
                return False
            except OSError as e:
                if getattr(e, "errno", None) in (11, 35, 13):
                    return False
                raise
        try:
            fh.seek(0)
            self._msvcrt.locking(fh.fileno(), self._msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False

    def acquire(self, blocking=False, timeout=None):
        if self._fh is not None:
            return True
        d = os.path.dirname(self.path)
        if d:
            os.makedirs(d, exist_ok=True)
        fh = open(self.path, "a+")
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            if self._try_once(fh):
                self._fh = fh
                return True
            if not blocking or (deadline is not None and time.monotonic() >= deadline):
                fh.close()
                return False
            time.sleep(0.05)

    def release(self):
        fh, self._fh = self._fh, None
        if fh is None:
            return
        try:
            if self._fcntl is not None:
                self._fcntl.flock(fh.fileno(), self._fcntl.LOCK_UN)
            else:
                fh.seek(0)
                self._msvcrt.locking(fh.fileno(), self._msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        finally:
            fh.close()

    def __enter__(self):
        if not self.acquire(blocking=True):
            raise TimeoutError("lock not acquired: %s" % self.path)
        return self

    def __exit__(self, *exc):
        self.release()
        return False


def open_lock(path):
    """A FileLock, or None when no cross-process lock primitive exists."""
    if not available():
        return None
    return FileLock(path)


class InProcessLock:
    """Fallback when no file lock exists: excludes threads of this process
    only. Keyed by path so two writers in one process still exclude."""

    _held = {}
    _guard = threading.Lock()

    def __init__(self, path):
        self.path = path
        self._mine = False

    @property
    def held(self):
        return self._mine

    def acquire(self, blocking=False, timeout=None):
        with InProcessLock._guard:
            if self.path in InProcessLock._held:
                return self._mine
            InProcessLock._held[self.path] = True
            self._mine = True
            return True

    def release(self):
        with InProcessLock._guard:
            if self._mine:
                InProcessLock._held.pop(self.path, None)
                self._mine = False
