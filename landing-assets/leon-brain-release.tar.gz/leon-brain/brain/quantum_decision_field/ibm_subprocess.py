"""IBM child CLI (spec 7.2). The only importer of qiskit_ibm_runtime.

    python3 -s -m brain.quantum_decision_field.ibm_subprocess <op>

Reads one JSON object on stdin and prints JSON lines on stdout. Operations:
``usage``, ``submit``, ``poll``, ``cancel``, ``find_by_tag``. It runs only as
a killable child of ibm_runner (own session, systemd scope when available).
It never prints the token; errors print only the exception class.

Inside the child: RLIMIT_AS 2 GiB, nice 10, oom_score_adj 1000, qiskit
parallelism and BLAS threads limited to 1, PUBs transpiled one at a time at
optimization_level=1 with a recorded seed and verified before submission.
"""
import hashlib
import json
import os
import sys

CHANNEL = "ibm_quantum_platform"
LIMITS = {"QISKIT_PARALLEL": "FALSE", "QISKIT_NUM_PROCS": "1", "OMP_NUM_THREADS": "1",
          "OPENBLAS_NUM_THREADS": "1", "RAYON_NUM_THREADS": "1"}
OPS = ("usage", "submit", "poll", "cancel", "find_by_tag")


def _emit(obj):
    sys.stdout.write(json.dumps(obj, sort_keys=True) + "\n")
    sys.stdout.flush()


def _harden():
    os.environ.update(LIMITS)
    try:
        import resource
        lim = 2 * 1024 ** 3
        resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
    except Exception:
        pass
    try:
        os.nice(10)
    except Exception:
        pass
    try:
        with open("/proc/self/oom_score_adj", "w") as fh:
            fh.write("1000")
    except Exception:
        pass


def _service():
    from qiskit_ibm_runtime import QiskitRuntimeService
    token = os.environ.get("IBM_QUANTUM_TOKEN")
    if not token:
        raise RuntimeError("no_token")
    return QiskitRuntimeService(channel=CHANNEL, token=token,
                                instance=os.environ.get("IBM_QUANTUM_INSTANCE") or None)


def op_usage(payload):
    u = _service().usage()
    u = u if isinstance(u, dict) else {}
    out = {"op": "usage"}
    for k in ("usage_limit_reached", "usage_remaining_seconds", "usage_consumed_seconds",
              "usage_limit_seconds", "usage_allocation_seconds", "usage_period"):
        if k in u:
            v = u[k]
            out[k] = v if isinstance(v, (bool, int, float, str)) or v is None else str(v)
    _emit(out)


def op_submit(payload):
    from qiskit_ibm_runtime import SamplerV2
    from brain.quantum_decision_field import prep
    attempt_id = str(payload["attempt_id"])
    seed = int(payload.get("seed_transpiler", 11))
    service = _service()
    backend = service.least_busy(operational=True, simulator=False)
    pubs, hashes, tsha, twoq = [], [], [], []
    for spec in payload["pubs"]:
        n = int(spec["n"])
        pl, p = prep.uniform_plan(n)
        qc = prep.build_qiskit_circuit(pl)
        tqc = prep.transpile_one(qc, backend=backend, seed_transpiler=seed)
        try:
            prep.verify_transpiled(tqc, n)
        except prep.TranspiledInvalidMass as e:
            _emit({"refused_before_post": "transpiled_invalid_mass", "n": n, "detail": e.detail})
            return
        hashes.append(prep.circuit_hash(pl, p))
        from qiskit import qasm3
        tsha.append(hashlib.sha256(qasm3.dumps(tqc).encode()).hexdigest())
        twoq.append(prep.two_qubit_gate_count(tqc))
        pubs.append((tqc, None, int(spec["shots"])))
    sampler = SamplerV2(mode=backend)
    sampler.options.environment.job_tags = ["leon-qv2", attempt_id]
    job = sampler.run(pubs)
    _emit({"job_id": job.job_id(), "backend": backend.name, "circuit_hashes": hashes,
           "transpiled_sha256": tsha, "twoq_gates": twoq, "seed_transpiler": seed})


def op_poll(payload):
    service = _service()
    job = service.job(str(payload["job_id"]))
    status = str(job.status())
    out = {"job_id": job.job_id(), "status": status}
    if status.upper().endswith("DONE"):
        result = job.result()
        out["pubs"] = [{"bitstrings": list(r.data.m.get_bitstrings())} for r in result]
        try:
            out["qpu_seconds"] = float(job.usage())
        except Exception:
            out["qpu_seconds"] = None
        try:
            out["measured_at"] = str(job.metrics().get("timestamps", {}).get("finished"))
        except Exception:
            out["measured_at"] = None
    _emit(out)


def op_cancel(payload):
    service = _service()
    job = service.job(str(payload["job_id"]))
    job.cancel()
    _emit({"job_id": job.job_id(), "cancelled": True})


def op_find_by_tag(payload):
    service = _service()
    jobs = service.jobs(job_tags=[str(payload["attempt_id"])], pending=None, limit=5)
    _emit({"jobs": [{"job_id": j.job_id(), "status": str(j.status())} for j in jobs]})


def main(argv):
    if len(argv) != 1 or argv[0] not in OPS:
        _emit({"error_class": "usage_error"})
        return 2
    _harden()
    try:
        payload = json.loads(sys.stdin.read() or "{}")
        globals()["op_" + argv[0]](payload)
        return 0
    except Exception as e:     # only the class name leaves the child
        _emit({"error_class": type(e).__name__})
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
