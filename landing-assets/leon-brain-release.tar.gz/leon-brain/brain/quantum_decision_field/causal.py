"""Causal experiment: allowlist validator, burst-proof scheduler, O(1)
consumption (spec 6.5).

An allowlist entry is inert unless every check passes: mode on, causal on,
action_gate_ready(); the code constants in ``authority``; approval fields and
expiry; the prereg hash; a detached ssh-keygen signature whose signer
fingerprint equals ``authority.CAUSAL_SIGNER_FPR`` (None in Phase 11, so every
entry is inert); an exact migration-ledger match; and, for the IBM arm, F5,
the canonical state dir, file locks and a runner. Validation runs on the
QV2-writer thread only.

Honest residual: Leon runs as root and can edit code. These checks turn
self-approval into a visible multi-file code-plus-key change; they are not a
sandbox.

All arms draw the same pre-registered uniform distribution. Differences
between arms are attributed only to distributional or procedural causes.
"""
import collections
import datetime
import hashlib
import itertools
import json
import os
import re
import secrets
import subprocess
import time

from . import authority, prep

PERMS = sorted(itertools.permutations(authority.CAUSAL_ARMS))       # 6, lexicographic
ALLOWLIST_FILE = "causal_allowlist.json"
SIGNERS_FILE = "causal_allowed_signers"
SIGNATURES_DIR = "causal_signatures"
PKG_DIR = os.path.dirname(os.path.abspath(__file__))


class CausalEntryInvalid(ValueError):
    pass


def load_allowlist(path=None):
    with open(path or os.path.join(PKG_DIR, ALLOWLIST_FILE), "r", encoding="utf-8") as fh:
        data = json.load(fh)
    entries = data.get("entries") if isinstance(data, dict) else data
    if not isinstance(entries, list):
        raise CausalEntryInvalid("allowlist has no entries list")
    return entries


def canonical_bytes(entry):
    body = {k: v for k, v in entry.items() if k != "prereg_hash"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def prereg_hash_of(entry):
    return hashlib.sha256(canonical_bytes(entry)).hexdigest()


def _utc(s):
    if not isinstance(s, str) or not s:
        return None
    try:
        dt = datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    return dt.timestamp()


def check_constants(entry):
    """Raise CausalEntryInvalid on any violation of the code constants."""
    def need(cond, reason):
        if not cond:
            raise CausalEntryInvalid(reason)
    ibm = entry.get("ibm") or {}
    need(isinstance(entry.get("id"), str) and
         re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,95}", entry["id"]), "unsafe_entry_id")
    need(entry.get("context") in authority.CAUSAL_ELIGIBLE, "context_not_causal_eligible")
    need(isinstance(entry.get("slot_interval_s"), int)
         and entry["slot_interval_s"] >= authority.CAUSAL_MIN_SLOT_INTERVAL_S, "slot_interval_too_short")
    need(isinstance(entry.get("max_slots_per_24h"), int)
         and 1 <= entry["max_slots_per_24h"] <= authority.CAUSAL_MAX_SLOTS_PER_24H, "slots_per_24h_exceeded")
    need(isinstance(entry.get("max_slots_total"), int)
         and 1 <= entry["max_slots_total"] <= authority.CAUSAL_MAX_SLOTS_TOTAL, "slots_total_exceeded")
    need(isinstance(entry.get("max_open_s"), int)
         and 0 < entry["max_open_s"] <= authority.CAUSAL_MAX_OPEN_S, "max_open_exceeded")
    ns = entry.get("n_set")
    need(isinstance(ns, list) and ns and all(isinstance(n, int) and n in authority.CAUSAL_N_SET_ALLOWED
                                             for n in ns), "n_set_not_allowed")
    need(entry.get("weights") == "uniform", "weights_not_uniform")
    need(sorted(entry.get("arms") or []) == sorted(authority.CAUSAL_ARMS), "arms_mismatch")
    need(isinstance(ibm.get("shots_per_pub"), int)
         and 1 <= ibm["shots_per_pub"] <= authority.CAUSAL_MAX_SHOTS_PER_PUB, "shots_per_pub_exceeded")
    need(isinstance(entry.get("reservoir_ttl_s"), int)
         and 0 < entry["reservoir_ttl_s"] <= authority.CAUSAL_MAX_RESERVOIR_TTL_S, "reservoir_ttl_exceeded")
    need(isinstance(ibm.get("max_jobs_per_28d"), int)
         and 0 <= ibm["max_jobs_per_28d"] <= authority.V2_CAUSAL_CAP, "ibm_job_cap_exceeded")
    need(isinstance(ibm.get("min_spacing_s"), int)
         and ibm["min_spacing_s"] >= authority.CAUSAL_MIN_IBM_SPACING_S, "ibm_spacing_too_short")
    pubs = ibm.get("pubs_n")
    need(isinstance(pubs, list) and pubs and set(pubs) <= set(ns or []), "pubs_n_not_in_n_set")
    a, e = _utc(entry.get("approved_utc")), _utc(entry.get("expires_utc"))
    if entry.get("approved_utc") is not None:
        need(a is not None, "invalid_approval_time")
    if entry.get("expires_utc") is not None:
        need(e is not None, "invalid_expiry_time")
    if a is not None and e is not None:
        need(e > a, "expiry_before_approval")
        need(e <= a + authority.CAUSAL_MAX_EXPIRY_DAYS * 86400, "expiry_beyond_90_days")


_FPR = re.compile(r"(SHA256:[A-Za-z0-9+/=]+)")


def verify_signature(entry, pkg_dir=None, signer_fpr=None, run=subprocess.run):
    """ssh-keygen -Y verify over the canonical bytes. Returns (ok, reason)."""
    if signer_fpr is None:
        return False, "signer_fpr_unset"
    pkg_dir = pkg_dir or PKG_DIR
    sig = os.path.join(pkg_dir, SIGNATURES_DIR, "%s.sig" % entry.get("id"))
    signers = os.path.join(pkg_dir, SIGNERS_FILE)
    if not os.path.isfile(sig):
        return False, "signature_missing"
    if not os.path.isfile(signers) or os.path.getsize(signers) == 0:
        return False, "allowed_signers_empty"
    try:
        cp = run(["ssh-keygen", "-Y", "verify", "-f", signers, "-I", authority.CAUSAL_SIGNER_IDENTITY,
                  "-n", authority.CAUSAL_SIGNATURE_NAMESPACE, "-s", sig],
                 input=canonical_bytes(entry), capture_output=True, timeout=20)
    except (OSError, subprocess.SubprocessError) as e:
        return False, "verify_error:" + type(e).__name__
    if cp.returncode != 0:
        return False, "signature_invalid"
    text = (cp.stdout or b"").decode("utf-8", "replace") + (cp.stderr or b"").decode("utf-8", "replace")
    m = _FPR.search(text)
    if not m or m.group(1) != signer_fpr:
        return False, "signer_fingerprint_mismatch"
    return True, "ok"


def ledger_match(ledger_path, entry_id, prereg_hash):
    """Exact migration-ledger match (runtime only reads the ledger)."""
    try:
        with open(ledger_path, "r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    rec = json.loads(line)
                except ValueError:
                    continue
                if (isinstance(rec, dict) and rec.get("phase") == 11
                        and rec.get("component") == "quantum_v2_causal"
                        and rec.get("entry_id") == entry_id and rec.get("prereg_hash") == prereg_hash
                        and rec.get("to") == "on" and str(rec.get("completed_utc") or "").strip()):
                    return True
    except OSError:
        return False
    return False


def default_migration_ledger(repo_root=None):
    return os.path.join(repo_root or authority.REPO_ROOT, "brain_state", "v2", "migration_ledger.jsonl")


def validate_entry(entry, *, mode, causal_flag, gate_ready, now, ledger_path, ibm_prereq_reasons=(),
                   pkg_dir=None, signer_fpr=None, run=subprocess.run):
    """-> (ok, reasons). Any reason leaves the entry inert."""
    reasons = []
    if mode != "on":
        reasons.append("mode_not_on")
    if causal_flag != "on":
        reasons.append("causal_flag_off")
    if not gate_ready:
        reasons.append("action_gate_absent")
    try:
        check_constants(entry)
    except CausalEntryInvalid as e:
        reasons.append("constant:" + str(e))
    for f in ("approved_by", "approved_utc", "expires_utc"):
        if not entry.get(f):
            reasons.append("unapproved:" + f)
    exp = _utc(entry.get("expires_utc"))
    if exp is not None and now >= exp:
        reasons.append("expired")
    ph = entry.get("prereg_hash")
    if not ph or ph != prereg_hash_of(entry):
        reasons.append("prereg_hash_mismatch")
    if not reasons:
        ok, why = verify_signature(entry, pkg_dir=pkg_dir, signer_fpr=signer_fpr, run=run)
        if not ok:
            reasons.append("signature:" + why)
    elif signer_fpr is None:
        reasons.append("signature:signer_fpr_unset")
    if not ledger_match(ledger_path, entry.get("id"), ph):
        reasons.append("ledger_record_missing")
    for r in ibm_prereq_reasons:
        reasons.append("ibm:" + r)
    return (not reasons), reasons


def arm_for(prereg_hash, k):
    h = int.from_bytes(hashlib.sha256(("%s|%d" % (prereg_hash, k // 3)).encode()).digest(), "big")
    return PERMS[h % 6][k % 3]


def arms_for(prereg_hash, total):
    return [arm_for(prereg_hash, k) for k in range(total)]


class Slot:
    __slots__ = ("k", "open_at", "arm")

    def __init__(self, k, open_at, arm):
        self.k, self.open_at, self.arm = k, open_at, arm


class CausalScheduler:
    """At most one open slot. Slot k opens at max(activation,
    consumed_{k-1} + interval), never while max_slots_per_24h were consumed in
    the last 24 h. A slot unconsumed for max_open_s is 'missed' and the next
    opens. State is replayed from experiments.jsonl, so downtime leaves at
    most one pending slot: no backlog, no burst."""

    def __init__(self, entry, prereg_hash, activation_ts, clock=time.time):
        self.entry_id = entry["id"]
        self.context = entry["context"]
        self.n_set = frozenset(entry["n_set"])
        self.interval = entry["slot_interval_s"]
        self.per24 = entry["max_slots_per_24h"]
        self.total = entry["max_slots_total"]
        self.max_open = entry["max_open_s"]
        self.prereg_hash = prereg_hash
        self.activation_ts = activation_ts
        self.arms = arms_for(prereg_hash, self.total)
        self._clock = clock
        self._open = collections.deque()        # 0 or 1 Slot; popleft is the atomic take
        self.consumed_ts = collections.deque()  # caller appends
        self.next_k = 0
        self.last_missed_at = None
        self.disabled = False
        self.finished = False

    # Caller path (O(1), attribute reads only) ------------------------------
    def slot_due(self, context, n):
        if self.disabled or context != self.context or n not in self.n_set:
            return False
        o = self._open
        if not o:
            return False
        try:
            s = o[0]
        except IndexError:
            return False
        return self._clock() >= s.open_at

    def take_slot(self, now):
        try:
            s = self._open.popleft()
        except IndexError:
            return None
        if now < s.open_at or self.disabled:
            self._open.appendleft(s)
            return None
        self.consumed_ts.append(now)
        return s

    @property
    def open_slot(self):
        try:
            return self._open[0]
        except IndexError:
            return None

    # Writer path ------------------------------------------------------------
    def _next_open_at(self):
        basis = self.activation_ts
        if self.consumed_ts:
            basis = max(basis, self.consumed_ts[-1] + self.interval)
        if self.last_missed_at is not None:
            basis = max(basis, self.last_missed_at)
        if len(self.consumed_ts) >= self.per24:
            basis = max(basis, self.consumed_ts[-self.per24] + 86400)
        return basis

    def tick(self, now):
        out = []
        s = self.open_slot
        if s is not None:
            if now > s.open_at + self.max_open:
                try:
                    taken = self._open.popleft()
                except IndexError:
                    taken = None
                if taken is s:
                    self.last_missed_at = now
                    out.append({"kind": "slot_missed", "k": s.k, "arm": s.arm, "open_at": s.open_at,
                                "ts": now})
                elif taken is not None:
                    self._open.appendleft(taken)
            else:
                return out
        if self._open or self.finished:
            return out
        if self.next_k >= self.total:
            self.finished = True
            out.append({"kind": "entry_finished", "ts": now, "slots": self.next_k})
            return out
        slot = Slot(self.next_k, self._next_open_at(), self.arms[self.next_k])
        self.next_k += 1
        self._open.append(slot)
        out.append({"kind": "slot_open", "k": slot.k, "arm": slot.arm, "open_at": slot.open_at, "ts": now})
        return out

    def replay(self, records):
        """Rebuild from experiments.jsonl records of this entry/prereg hash."""
        opened = {}
        for rec in records:
            if rec.get("entry_id") != self.entry_id or rec.get("prereg_hash") != self.prereg_hash:
                continue
            kind = rec.get("kind")
            if kind == "slot_open":
                opened[rec["k"]] = rec
                self.next_k = max(self.next_k, rec["k"] + 1)
            elif kind == "slot_consumed":
                opened.pop(rec["k"], None)
                self.consumed_ts.append(float(rec["consumed_at"]))
            elif kind == "slot_missed":
                opened.pop(rec["k"], None)
                self.last_missed_at = float(rec["ts"])
            elif kind == "entry_finished":
                self.finished = True
        if opened:
            k = max(opened)
            rec = opened[k]
            self._open.append(Slot(k, float(rec["open_at"]), rec["arm"]))


class CausalController:
    """Consumption on the caller thread, O(1): one reservoir item decides
    exactly one decision; never a majority, never a second shot."""

    def __init__(self, entry, prereg_hash, scheduler, broker=None, aer=None, clock=time.time):
        self.entry = entry
        self.prereg_hash = prereg_hash
        self.scheduler = scheduler
        self.broker = broker
        self.aer = aer
        self.aer_reservoir = {n: collections.deque() for n in entry["n_set"]}
        self._clock = clock
        self._thresholds = {n: prep.thresholds_u53([1.0] * n) for n in entry["n_set"]}
        self.ttl_s = entry.get("reservoir_ttl_s", authority.CAUSAL_MAX_RESERVOIR_TTL_S)

    def slot_due(self, context, n):
        return self.scheduler.slot_due(context, n)

    def _os_entropy(self, n):
        u = secrets.randbits(53)
        return prep.draw_index(self._thresholds[n], u), u

    def consume(self, n):
        now = self._clock()
        slot = self.scheduler.take_slot(now)
        if slot is None:
            return None
        arm = slot.arm
        res = {"entry_id": self.entry["id"], "prereg_hash": self.prereg_hash, "k": slot.k,
               "arm": arm, "open_at": slot.open_at, "consumed_at": now, "item": None,
               "fallback_from": None, "fallback_reason": None, "bitstring": None, "valid": None}
        item = None
        if arm == "ibm_hardware":
            item = self.broker.reservoir_take(n) if self.broker is not None else None
            if item is None:
                why = getattr(self.broker, "unavailable_reason", None) if self.broker else "ibm_unavailable"
                res["fallback_reason"] = why or "reservoir_empty"
        elif arm == "aer":
            dq = self.aer_reservoir.get(n)
            while dq:
                try:
                    cand = dq.popleft()
                except IndexError:
                    break
                if cand["expires_at"] > now:
                    item = cand
                    break
            if item is None:
                res["fallback_reason"] = "reservoir_empty"
        if item is not None:
            b, valid = prep.decode_bitstring(item["bitstring"], n)
            res.update(item={k: item.get(k) for k in ("job_id", "backend", "pub_index", "shot_index",
                                                      "measured_at", "expires_at", "seed_simulator")},
                       bitstring=item["bitstring"], valid=valid)
            if valid:
                res.update(index=b, source=arm, u53=None, outcome="decided")
                return res
            res["fallback_reason"] = "invalid_outcome"
            res["outcome"] = "invalid_outcome"
        i, u = self._os_entropy(n)
        if arm != "os_entropy":
            res["fallback_from"] = arm
        res.update(index=i, source="os_entropy", u53=u)
        res.setdefault("outcome", "decided")
        return res

    # Writer path: one Aer shot per n when an aer slot opens -----------------
    def request_aer(self, now, seed_fn=None):
        if self.aer is None:
            return 0
        k = 0
        for n in self.entry["n_set"]:
            pl, p = prep.uniform_plan(n)
            ch = prep.circuit_hash(pl, p)
            seed = (seed_fn or (lambda: secrets.randbits(63)))()
            f = self.aer.submit_one(pl, n, ch, seed)
            if f is None:
                continue
            k += 1

            def done(fut, n=n, seed=seed):
                try:
                    out = fut.result()
                except Exception:
                    return
                t = self._clock()
                self.aer_reservoir[n].append({"bitstring": out["bitstring"], "measured_at": t,
                                              "expires_at": t + self.ttl_s, "seed_simulator": seed,
                                              "backend": "aer"})
            f.add_done_callback(done)
        return k
