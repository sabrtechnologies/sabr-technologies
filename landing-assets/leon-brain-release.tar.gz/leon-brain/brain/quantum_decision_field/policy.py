"""Scores -> target weights (spec 4).

Default policy: proportional(alpha=1.0). w_i = max(s_i, 0); a non-finite or
non-numeric score becomes 0 and is counted in ``sanitized``; all-zero gives
uniform with ``policy_fallback="all_zero_uniform"``; ``scores=None`` gives
uniform. With alpha == 1.0 no libm pow is called, so the target is a function
of the inputs through correctly rounded operations only. No neuromodulator
coupling in Phase 11.
"""
import math
import itertools

DEFAULT_ALPHA = 1.0


def proportional(scores, n, alpha=DEFAULT_ALPHA):
    info = {"name": "proportional", "alpha": alpha, "sanitized": 0, "policy_fallback": None}
    if scores is None:
        info["uniform_input"] = True
        return [1.0] * n, info
    vals = list(itertools.islice(scores, n))
    if len(vals) != n:
        # Same padding legacy applies, so both engines see identical inputs.
        info["length_mismatch"] = n - len(vals)
        vals = vals + [0.5] * (n - len(vals))
    w = []
    for s in vals:
        try:
            x = float(s)
        except (TypeError, ValueError, OverflowError):
            x = math.nan
        if math.isnan(x) or math.isinf(x):
            info["sanitized"] += 1
            x = 0.0
        w.append(x if x > 0.0 else 0.0)
    if alpha != 1.0:
        w = [x ** alpha for x in w]
    if not any(x > 0.0 for x in w):
        info["policy_fallback"] = "all_zero_uniform"
        w = [1.0] * n
    return w, info


class ContextualBanditPolicy:
    """Small NumPy contextual reward predictor with an auxiliary error phase.

    Features have explicit caller-defined semantics and scaling. Updating the
    phase predicts a bounded error signal; it does NOT improve sampling odds
    through interference (the local field applies no interference circuit).
    Persistence is explicit, versioned, atomic, and confined to the given path.
    No checkpoint is loaded or saved by import or constructor.
    """
    SCHEMA = 1
    DEFAULT_SIDECAR = "brain_state/v2/quantum_policy.npz"
    MAX_DIMENSIONS = 70
    MAX_CHECKPOINT_BYTES = 2 * 1024 * 1024

    def __init__(self, dimensions, learning_rate=0.05):
        import threading
        import numpy as np
        if type(dimensions) is not int or not 1 <= dimensions <= self.MAX_DIMENSIONS:
            raise ValueError("dimensions")
        if not math.isfinite(learning_rate) or not 0 < learning_rate <= 1:
            raise ValueError("learning_rate")
        self.dimensions = dimensions
        self.learning_rate = float(learning_rate)
        self.steps = 0
        self._weights = np.zeros((2, dimensions + 1), dtype=np.float64)
        self._lock = threading.RLock()

    @property
    def version(self):
        with self._lock:
            return "contextual_bandit/1:%d" % self.steps

    def _vector(self, features):
        import numpy as np
        if not isinstance(features, (tuple, list)) or len(features) != self.dimensions:
            raise ValueError("feature dimensions")
        if any(isinstance(x, bool) for x in features):
            raise ValueError("numeric features required")
        x = np.asarray((*features, 1.0), dtype=np.float64)
        if not np.isfinite(x).all() or (np.abs(x) > 1).any():
            raise ValueError("features must be finite and scaled to [-1, 1]")
        return x

    def predict(self, features):
        import numpy as np
        x = self._vector(features)
        with self._lock:
            y = self._weights @ x
        return float(np.clip(y[0], -16, 16)), math.pi * math.tanh(float(y[1]))

    def snapshot(self):
        with self._lock:
            other = type(self)(self.dimensions, self.learning_rate)
            other._weights = self._weights.copy()
            other.steps = self.steps
        return other

    def update(self, features, *, task_reward=None, prediction_error=None,
               low_risk=False, safety_critical=True):
        import numpy as np
        if low_risk is not True or safety_critical is not False:
            raise ValueError("training requires a verified non-safety-critical low-risk decision")
        if task_reward is None and prediction_error is None:
            raise ValueError("observed reward or prediction error required")
        for value in (task_reward, prediction_error):
            if value is not None and (isinstance(value, bool) or
                    not math.isfinite(value) or not -1 <= value <= 1):
                raise ValueError("observations must be finite and scaled to [-1, 1]")
        x = self._vector(features)
        with self._lock:
            target = task_reward if task_reward is not None else -abs(prediction_error)
            predicted = float(self._weights[0] @ x)
            self._weights[0] += self.learning_rate * (target - predicted) * x / float(x @ x)
            if prediction_error is not None:
                predicted_error = float(self._weights[1] @ x)
                self._weights[1] += self.learning_rate * (prediction_error - predicted_error) * x / float(x @ x)
            np.clip(self._weights, -8, 8, out=self._weights)
            self.steps += 1
            return self.version

    def save(self, path):
        import os
        from pathlib import Path
        import tempfile
        import numpy as np
        path = Path(path)
        # A caller chooses an explicitly approved sidecar location. Never infer
        # a live canonical directory or overwrite any legacy state artifact.
        if path.suffix != ".npz":
            raise ValueError("policy sidecar must use .npz")
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            weights, steps = self._weights.copy(), self.steps
        fd, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                np.savez(stream, schema=self.SCHEMA, dimensions=self.dimensions,
                         learning_rate=self.learning_rate, steps=steps, weights=weights)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    @classmethod
    def load(cls, path):
        import os
        import zipfile
        import numpy as np
        if os.path.getsize(path) > cls.MAX_CHECKPOINT_BYTES:
            raise ValueError("checkpoint too large")
        with zipfile.ZipFile(path) as archive:
            if sum(i.file_size for i in archive.infolist()) > cls.MAX_CHECKPOINT_BYTES:
                raise ValueError("expanded checkpoint too large")
            expected = {"schema.npy", "dimensions.npy", "learning_rate.npy", "steps.npy", "weights.npy"}
            if len(archive.infolist()) != 5 or set(archive.namelist()) != expected:
                raise ValueError("checkpoint members")
            # Bound array dimensions before np.load allocates from a header.
            for name in expected:
                with archive.open(name) as stream:
                    version = np.lib.format.read_magic(stream)
                    if version == (1, 0):
                        shape, _, dtype = np.lib.format.read_array_header_1_0(stream)
                    elif version == (2, 0):
                        shape, _, dtype = np.lib.format.read_array_header_2_0(stream)
                    else:
                        raise ValueError("unsupported array format")
                    if dtype.kind not in "iuf" or dtype.itemsize > 8:
                        raise ValueError("checkpoint dtype")
                    if name == "weights.npy":
                        if len(shape) != 2 or shape[0] != 2 or not 2 <= shape[1] <= cls.MAX_DIMENSIONS + 1:
                            raise ValueError("checkpoint shape")
                    elif shape != ():
                        raise ValueError("checkpoint scalar shape")
        with np.load(path, allow_pickle=False) as data:
            if set(data.files) != {"schema", "dimensions", "learning_rate", "steps", "weights"}:
                raise ValueError("checkpoint keys")
            for key in ("schema", "dimensions", "steps"):
                if data[key].shape != () or data[key].dtype.kind not in "iu":
                    raise ValueError("checkpoint scalar")
            if int(data["schema"]) != cls.SCHEMA:
                raise ValueError("checkpoint schema")
            obj = cls(int(data["dimensions"]), float(data["learning_rate"]))
            weights = data["weights"]
            steps = int(data["steps"])
            if (weights.shape != obj._weights.shape or weights.dtype.kind != "f" or
                    not np.isfinite(weights).all() or (np.abs(weights) > 8).any() or steps < 0):
                raise ValueError("invalid policy state")
            obj._weights = weights.astype(np.float64, copy=True)
            obj.steps = steps
        return obj
