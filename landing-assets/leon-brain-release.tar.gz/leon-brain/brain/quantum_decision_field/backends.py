"""Backends (spec 5.2, 7.1-7.3).

* ``ClassicalBackend``: os_entropy. ``secrets.randbits(53)`` against exact
  integer thresholds; pure Python, a few microseconds. V2's classical default.
* ``SeededPrng``: seeded ``random.Random``; tests, replay and diagnostics only,
  never production decisions.
* ``AerBackend``: AerSimulator, a classical simulator with a PRNG. One lazy
  worker thread (``QV2-aer``), one circuit per transpile/run call, opt 1 only,
  post-transpile verification, busy fast-fail, deadline miss breaker, and a
  32-entry LRU restricted to q <= 6. It can decide nothing until
  ``action_gate_ready()``.
* ``IbmBroker``: thread ``QV2-ibm``. ``decide()`` only ever calls
  ``reservoir_take`` (a deque popleft). Everything else (ledger replay, the
  submit gate, usage, submit, poll, cancel, orphan search) runs on the broker
  thread, in a killable child, under ``ibm.lock``.
"""
import collections
import os
import random
import secrets
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from . import authority, prep
from .ledger import ITT_REASON, submit_gate, usage_allows_submit
from .ibm_runner import RunnerError


class Outcome:
    __slots__ = ("index", "u53", "source", "entropy")

    def __init__(self, index, u53, source, entropy=None):
        self.index = index
        self.u53 = u53
        self.source = source
        self.entropy = entropy or {}


class ClassicalBackend:
    source = "os_entropy"

    def sample(self, thresholds):
        u = secrets.randbits(53)
        return Outcome(prep.draw_index(thresholds, u), u, "os_entropy", {"u53": u})


class SeededPrng:
    """Tests, replay and diagnostics only (source "prng")."""
    source = "prng"

    def __init__(self, seed):
        self.seed = seed
        self.counter = 0
        self._rng = random.Random(seed)

    def sample(self, thresholds):
        u = self._rng.getrandbits(53)
        self.counter += 1
        return Outcome(prep.draw_index(thresholds, u), u, "prng",
                       {"algo": "mt19937", "seed": self.seed, "counter": self.counter, "u53": u})


# ── Aer ──────────────────────────────────────────────────────────────────────

AER_LRU_SIZE = 32
AER_LRU_MAX_Q = 6
AER_BREAKER_MISSES = 3
AER_BREAKER_WINDOW_S = 600
AER_BREAKER_OPEN_S = 600


class AerBackend:
    def __init__(self, deadline_ms=250, clock=time.monotonic, run_fn=None):
        self.deadline_ms = deadline_ms
        self._clock = clock
        self._executor = None
        self._pending = None
        self._begin_lock = threading.Lock()
        self._misses = collections.deque()
        self._breaker_until = 0.0
        self._lru = collections.OrderedDict()
        self._sim = None
        self._run_fn = run_fn or self._run_one
        self.stats = collections.Counter()

    # State ----------------------------------------------------------------
    def busy(self):
        f = self._pending
        return f is not None and not f.done()

    def breaker_open(self, now=None):
        return (self._clock() if now is None else now) < self._breaker_until

    def note_miss(self, now=None):
        now = self._clock() if now is None else now
        self._misses.append(now)
        while self._misses and now - self._misses[0] > AER_BREAKER_WINDOW_S:
            self._misses.popleft()
        if len(self._misses) >= AER_BREAKER_MISSES:
            self._breaker_until = now + AER_BREAKER_OPEN_S
            self._misses.clear()
            self.stats["breaker_opened"] += 1

    def lru_size(self):
        return len(self._lru)

    # Submission -------------------------------------------------------------
    def submit_one(self, pl, n_support, chash, seed):
        """Submit one one-shot job, or return None when busy (never queues
        behind a stalled job). Only non-realtime threads and the writer call
        this."""
        if not self._begin_lock.acquire(blocking=False):
            return None
        try:
            if self.busy():
                return None
            if self._executor is None:
                self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="QV2-aer")
            f = self._executor.submit(self._run_fn, pl, n_support, chash, seed)
            self._pending = f
            return f
        finally:
            self._begin_lock.release()

    def _run_one(self, pl, n_support, chash, seed):
        from qiskit_aer import AerSimulator
        if self._sim is None:
            self._sim = AerSimulator(method="statevector", max_parallel_threads=1,
                                     max_parallel_experiments=1)
        tseed = int(chash[:8], 16)
        entry = self._lru.get(chash)
        if entry is None:
            qc = prep.build_qiskit_circuit(pl)
            tqc = prep.transpile_one(qc, backend=self._sim, seed_transpiler=tseed)
            mass = prep.verify_transpiled(tqc, n_support)
            entry = (tqc, mass)
            if pl["q"] <= AER_LRU_MAX_Q:
                self._lru[chash] = entry
                while len(self._lru) > AER_LRU_SIZE:
                    self._lru.popitem(last=False)
        else:
            self._lru.move_to_end(chash)
        tqc, mass = entry
        res = self._sim.run(tqc, shots=1, memory=True, seed_simulator=seed).result()
        bs = res.get_memory(0)[0].replace(" ", "")
        return {"bitstring": bs, "seed_simulator": seed, "transpile_seed": tseed,
                "verified_mass": mass}

    def shutdown(self):
        ex = self._executor
        if ex is not None:
            ex.shutdown(wait=False, cancel_futures=True)


# ── IBM broker ───────────────────────────────────────────────────────────────

class IbmBroker:
    """Refills the causal reservoir from IBM hardware. Starts only when mode
    is on, causal is on, an entry validated, action_gate_ready(), F5 holds,
    the state dir is canonical and file locks are available (checked by the
    caller that constructs it; ``prerequisites()`` repeats the static ones)."""

    CYCLE_S = 60

    def __init__(self, *, state_dir, entry, runner, ledger, lock_factory, clock=time.time,
                 canonical_dir=None, repo_root=None, budget_path=None, record=None,
                 purpose="causal"):
        self.state_dir = state_dir
        self.entry = entry
        self.runner = runner
        self.ledger = ledger
        self._lock_factory = lock_factory
        self._clock = clock
        self.canonical_dir = authority.IBM_CANONICAL_STATE_DIR if canonical_dir is None else canonical_dir
        self.repo_root = repo_root
        self.budget_path = budget_path
        self._record = record or (lambda kind, payload: None)
        self.purpose = purpose
        ibm = entry.get("ibm", {}) if entry else {}
        self.n_set = tuple(int(n) for n in (ibm.get("pubs_n") or (entry or {}).get("n_set") or ()))
        self.shots_per_pub = int(ibm.get("shots_per_pub", 8))
        self.low_water = int(ibm.get("refill_low_water", 6))
        self.entry_cap = int(ibm.get("max_jobs_per_28d", authority.V2_CAUSAL_CAP))
        self.ttl_s = int((entry or {}).get("reservoir_ttl_s", authority.CAUSAL_MAX_RESERVOIR_TTL_S))
        self.reservoir = {n: collections.deque() for n in self.n_set}
        self.unavailable_reason = None
        self.last_summary = None
        self.last_cycle = None
        self._stop = threading.Event()
        self._thread = None

    # Caller path (O(1)) ------------------------------------------------------
    def reservoir_take(self, n):
        dq = self.reservoir.get(n)
        if dq is None:
            return None
        now = self._clock()
        while True:
            try:
                item = dq.popleft()
            except IndexError:
                return None
            if item["expires_at"] > now:
                return item
            self._record("expired_unconsumed", item)

    def reservoir_sizes(self):
        return {str(n): len(dq) for n, dq in self.reservoir.items()}

    # Static prerequisites ---------------------------------------------------
    def prerequisites(self):
        reasons = []
        if not self.canonical_dir or os.path.realpath(self.state_dir) != os.path.realpath(self.canonical_dir):
            reasons.append("state_dir_not_canonical")
        if not authority.f5_satisfied(self.repo_root):
            reasons.append("f5_not_satisfied")
        if self._lock_factory() is None:
            reasons.append("filelock_unavailable")
        if self.runner is None or not self.runner.available():
            reasons.append("runner_unavailable")
        return reasons

    # Thread -----------------------------------------------------------------
    def start(self):
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._loop, name="QV2-ibm", daemon=True)
        self._thread.start()

    def _loop(self):
        while not self._stop.is_set():
            try:
                self.last_cycle = self.cycle()
            except Exception as e:      # never dies silently; recorded on the status
                self.last_cycle = "cycle_error:" + type(e).__name__
            self._stop.wait(self.CYCLE_S)

    def stop(self):
        self._stop.set()
        try:
            if self.runner is not None:
                self.runner.kill_live()
        except Exception:
            pass

    # One cycle ----------------------------------------------------------------
    def _disabled(self):
        return os.path.exists(os.path.join(self.state_dir, "IBM_DISABLED"))

    def _canonical(self):
        return bool(self.canonical_dir) and os.path.realpath(self.state_dir) == os.path.realpath(self.canonical_dir)

    def cycle(self, now=None):
        now = self._clock() if now is None else now
        if not self._canonical():
            self.unavailable_reason = "state_dir_not_canonical"
            return "not_canonical"
        lock = self._lock_factory()
        if lock is None:
            self.unavailable_reason = "filelock_unavailable"
            return "no_filelock"
        if not lock.acquire(blocking=False):
            return "lock_busy"
        try:
            disabled = self._disabled()
            st = self.ledger.replay(now)
            if disabled != st.kill_switch_active:
                self.ledger.append("kill_switch", ts=now, active=disabled)
            self._expire(now)
            self._resume_in_flight(st, now, disabled)
            st = self.ledger.replay(now)
            self.last_summary = st.summary(now)
            if disabled:
                self.unavailable_reason = "ibm_disabled"
                return "disabled"
            if not self.needs_refill(now):
                if not st.in_flight:
                    self.unavailable_reason = None
                return "idle"
            ok, reason = submit_gate(st, purpose=self.purpose, now=now, state_dir=self.state_dir,
                                     canonical_dir=self.canonical_dir, lock_held=lock.held,
                                     ibm_disabled=disabled, repo_root=self.repo_root,
                                     budget_path=self.budget_path,
                                     entry_id=(self.entry or {}).get("id"), entry_cap=self.entry_cap)
            if not ok:
                self.unavailable_reason = ITT_REASON.get(reason)
                return "gate:" + reason
            return self._usage_then_submit(now)
        finally:
            lock.release()

    def needs_refill(self, now):
        for n in self.n_set:
            live = sum(1 for it in self.reservoir[n] if it["expires_at"] > now)
            if live < self.low_water:
                return True
        return False

    def _expire(self, now):
        for dq in self.reservoir.values():
            keep = collections.deque()
            while True:
                try:
                    it = dq.popleft()
                except IndexError:
                    break
                if it["expires_at"] > now:
                    keep.append(it)
                else:
                    self._record("expired_unconsumed", it)
            dq.extend(keep)

    def _note_failure(self, now):
        st = self.ledger.replay(now)
        if st.consecutive_failures >= authority.IBM_BREAKER_FAILURES and not st.breaker_open(now):
            self.ledger.append("breaker", ts=now, open_until=now + authority.IBM_BREAKER_OPEN_S,
                               consecutive_failures=st.consecutive_failures)
            self.unavailable_reason = "breaker_open"

    def _err(self, now, op, e, **extra):
        self.ledger.append("error", ts=now, op=op, purpose=self.purpose,
                           error_class=getattr(e, "error_class", type(e).__name__),
                           error_digest=getattr(e, "error_digest", None), **extra)
        self._note_failure(now)

    def _resume_in_flight(self, st, now, disabled):
        for att in st.in_flight:
            if att.job_id:
                if now >= att.ts + authority.IBM_JOB_TTL_S:
                    if disabled and att.cancel_attempts >= 1:
                        continue            # kill switch: one bounded cancel only
                    if (not disabled and att.cancel_attempts and att.last_poll_ts
                            and now - att.last_poll_ts < authority.IBM_POLL_INTERVAL_S):
                        continue
                    self._cancel(att, now, reason="ttl")
                elif not disabled and (att.last_poll_ts is None
                                       or now - att.last_poll_ts >= authority.IBM_POLL_INTERVAL_S):
                    self._poll(att, now)
            elif not disabled:
                s = att.orphan_searches
                if s and now - s[-1] < authority.IBM_ORPHAN_SEARCH_GAP_S:
                    continue
                self._orphan_search(att, now)

    def _cancel(self, att, now, reason):
        try:
            self.runner.run("cancel", {"job_id": att.job_id})
        except RunnerError as e:
            self.ledger.append("cancel_failed", ts=now, attempt_id=att.attempt_id,
                               job_id=att.job_id, reason=reason,
                               error_class=e.error_class, error_digest=e.error_digest)
            self._note_failure(now)
            return False
        self.ledger.append("cancel", ts=now, attempt_id=att.attempt_id, job_id=att.job_id, reason=reason)
        self.ledger.append("expired_cancelled", ts=now, attempt_id=att.attempt_id,
                           job_id=att.job_id, reason=reason)
        return True

    def _poll(self, att, now):
        try:
            lines = self.runner.run("poll", {"job_id": att.job_id})
        except RunnerError as e:
            self.ledger.append("poll", ts=now, attempt_id=att.attempt_id, job_id=att.job_id,
                               status="poll_error")
            self._err(now, "poll", e, attempt_id=att.attempt_id)
            return
        res = next((x for x in reversed(lines) if "status" in x), {})
        status = str(res.get("status", "unknown"))
        self.ledger.append("poll", ts=now, attempt_id=att.attempt_id, job_id=att.job_id, status=status)
        up = status.upper()
        if up.endswith("DONE"):
            measured_at = now
            items = []
            pubs = att.pubs or []
            for pi, pub in enumerate(res.get("pubs") or []):
                n = int(pubs[pi]["n"]) if pi < len(pubs) else None
                for si, bs in enumerate(pub.get("bitstrings") or []):
                    items.append({"job_id": att.job_id, "backend": att.backend, "pub_index": pi,
                                  "shot_index": si, "bitstring": str(bs), "n": n,
                                  "measured_at": measured_at, "expires_at": measured_at + self.ttl_s,
                                  "attempt_id": att.attempt_id})
            for it in items:
                if it["n"] in self.reservoir:
                    self.reservoir[it["n"]].append(it)
            self.ledger.append("done", ts=now, attempt_id=att.attempt_id, job_id=att.job_id,
                               qpu_seconds=res.get("qpu_seconds"), items=len(items))
        elif any(up.endswith(s) for s in ("ERROR", "CANCELLED", "FAILED")):
            self.ledger.append("failed", ts=now, attempt_id=att.attempt_id, job_id=att.job_id,
                               error_class="job_" + up.split(".")[-1].lower())
            self._note_failure(now)

    def poll_late(self, att, now):
        """A result for an attempt already terminal (expired/cancelled) is
        recorded as late_result and never consumed."""
        try:
            lines = self.runner.run("poll", {"job_id": att.job_id})
        except RunnerError:
            return None
        res = next((x for x in reversed(lines) if "status" in x), {})
        if str(res.get("status", "")).upper().endswith("DONE"):
            self.ledger.append("late_result", ts=now, attempt_id=att.attempt_id, job_id=att.job_id)
            return res
        return None

    def _orphan_search(self, att, now):
        try:
            lines = self.runner.run("find_by_tag", {"attempt_id": att.attempt_id})
        except RunnerError as e:
            self._err(now, "find_by_tag", e, attempt_id=att.attempt_id)
            return
        res = next((x for x in reversed(lines) if "jobs" in x), {"jobs": []})
        jobs = res.get("jobs") or []
        self.ledger.append("orphan_search", ts=now, attempt_id=att.attempt_id,
                           found=bool(jobs), job_id=jobs[0]["job_id"] if jobs else None)
        if jobs:
            att.job_id = jobs[0]["job_id"]
            self._cancel(att, now, reason="orphan_recovered")
            return
        searches = att.orphan_searches + [now]
        if len(searches) >= 2 and searches[-1] - searches[0] >= authority.IBM_ORPHAN_SEARCH_GAP_S:
            self.ledger.append("orphan_not_found", ts=now, attempt_id=att.attempt_id)

    def _usage_then_submit(self, now):
        try:
            lines = self.runner.run("usage", {})
        except RunnerError as e:
            self._err(now, "usage", e)
            self.unavailable_reason = "ibm_quota_unavailable"
            return "usage_error"
        usage = next((x for x in reversed(lines) if x.get("op") == "usage"), None)
        safe = {k: v for k, v in (usage or {}).items() if k != "op"}
        self.ledger.append("usage", ts=now, purpose=self.purpose, **safe)
        ok, why = usage_allows_submit(usage)
        if not ok:
            self.unavailable_reason = "ibm_quota_unavailable"
            return "usage:" + why
        attempt_id = uuid.uuid4().hex
        pubs = [{"n": n, "shots": self.shots_per_pub} for n in self.n_set]
        self.ledger.append("submit_attempt", ts=now, attempt_id=attempt_id, purpose=self.purpose,
                           entry_id=(self.entry or {}).get("id"), pubs=pubs,
                           shots=self.shots_per_pub * len(pubs))
        seen = {}

        def on_line(obj):
            if "job_id" in obj and "job_id" not in seen:
                seen["job_id"] = obj["job_id"]
                self.ledger.append("submitted", ts=now, attempt_id=attempt_id, job_id=obj["job_id"],
                                   backend=obj.get("backend"),
                                   circuit_hashes=obj.get("circuit_hashes"),
                                   transpiled_sha256=obj.get("transpiled_sha256"),
                                   twoq_gates=obj.get("twoq_gates"),
                                   seed_transpiler=obj.get("seed_transpiler"))

        payload = {"attempt_id": attempt_id, "pubs": pubs,
                   "seed_transpiler": int(attempt_id[:8], 16)}
        try:
            lines = self.runner.run("submit", payload, on_line=on_line)
        except RunnerError as e:
            self._err(now, "submit", e, attempt_id=attempt_id, job_id_seen="job_id" in seen)
            return "submit_error"
        refused = next((x for x in lines if "refused_before_post" in x), None)
        if refused is not None and "job_id" not in seen:
            self.ledger.append("refused_before_post", ts=now, attempt_id=attempt_id,
                               detail=str(refused.get("refused_before_post")))
            return "refused_before_post"
        self.unavailable_reason = None
        return "submitted" if "job_id" in seen else "submitted_no_job_id"
