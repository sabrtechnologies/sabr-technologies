"""Pure-numpy mirror of the legacy decision engine's circuit and fold.

Read-only modeling: it never decides and uses no RNG. It mirrors the legacy
``decide`` score handling (including the ``scores=None`` branch, which skips
min-max) and ``_build_circuit`` gate for gate, in qiskit's little-endian
convention (qubit k is bit k of the basis index):

  H on all qubits
  RY(score angle) per qubit, only when |angle| > 1e-6
  RY(dopamine * pi * 0.3) on all qubits
  RZ(serotonin * pi * 0.5) on all qubits
  CRY(acetylcholine * pi * 0.4, q -> q+1) when acetylcholine > 0.25, q >= 2
  RX(norepinephrine * pi * 0.25) on all qubits
  CX(0 -> q-1) then RZ(cofiring * pi * 0.3, q-1) when the top two firing
  rates exceed 0.05 and 0.03

followed by the legacy modulo fold (index idx >= n counts as idx % n).

The legacy record keeps neuromodulators and region firing rounded to 4 dp,
and only the first 8 region_firing entries, while the co-firing layer uses
the top two of all regions. ``inputs_complete`` and ``cx_margin_ok`` say when
a modeled distribution may differ from what legacy actually ran.
"""
import math

import numpy as np

DEFAULTS = {"dopamine": 0.4, "serotonin": 0.5, "acetylcholine": 0.3,
            "norepinephrine": 0.3}
CX_TOP, CX_SECOND = 0.05, 0.03
CX_MARGIN = 5e-5
RECORDED_REGION_CAP = 8
ROUNDING_NOTE = "legacy brain_state/region_firing 4dp"


def legacy_scores(scores, n):
    """Legacy score handling: None -> [1/n]*n (no min-max); else pad/trim,
    then min-max to [0, 1], or [0.5]*n when all equal."""
    if scores is None:
        return [1.0 / n] * n
    s = [float(x) for x in list(scores)[:n]]
    while len(s) < n:
        s.append(0.5)
    lo, hi = min(s), max(s)
    if hi > lo:
        return [(x - lo) / (hi - lo) for x in s]
    return [0.5] * n


def legacy_n_qubits(n):
    return min(max(math.ceil(math.log2(n)), 1), 10)


def _score_angle(qubit, scores, n):
    total, count = 0.0, 0
    for i in range(n):
        if (i >> qubit) & 1:
            total += scores[i] if i < len(scores) else 0.5
            count += 1
    if count == 0:
        return 0.0
    return (total / count - 0.5) * math.pi * 0.5


def _ry(t):
    c, s = math.cos(t / 2), math.sin(t / 2)
    return np.array([[c, -s], [s, c]], dtype=complex)


def _rz(t):
    return np.array([[np.exp(-0.5j * t), 0], [0, np.exp(0.5j * t)]], dtype=complex)


def _rx(t):
    c, s = math.cos(t / 2), math.sin(t / 2)
    return np.array([[c, -1j * s], [-1j * s, c]], dtype=complex)


_H = np.array([[1, 1], [1, -1]], dtype=complex) / math.sqrt(2.0)


def _apply_1q(psi, gate, k, nq):
    t = psi.reshape(1 << (nq - 1 - k), 2, 1 << k)
    return np.einsum("ab,xby->xay", gate, t).reshape(-1)


def _apply_controlled(psi, gate, ctrl, tgt, nq):
    out = psi.copy()
    idx = np.arange(1 << nq)
    sel0 = idx[((idx >> ctrl) & 1 == 1) & ((idx >> tgt) & 1 == 0)]
    sel1 = sel0 | (1 << tgt)
    a0, a1 = psi[sel0], psi[sel1]
    out[sel0] = gate[0, 0] * a0 + gate[0, 1] * a1
    out[sel1] = gate[1, 0] * a0 + gate[1, 1] * a1
    return out


def _cx_gate():
    return np.array([[0, 1], [1, 0]], dtype=complex)


def legacy_statevector(n, norm_scores, neuromodulators, region_firing):
    nq = legacy_n_qubits(n)
    nm = dict(DEFAULTS)
    nm.update({k: float(v) for k, v in (neuromodulators or {}).items() if k in DEFAULTS})
    da, ser = nm["dopamine"], nm["serotonin"]
    ach, ne = nm["acetylcholine"], nm["norepinephrine"]
    psi = np.zeros(1 << nq, dtype=complex)
    psi[0] = 1.0
    for q in range(nq):
        psi = _apply_1q(psi, _H, q, nq)
    for q in range(nq):
        ang = _score_angle(q, norm_scores, n)
        if abs(ang) > 1e-6:
            psi = _apply_1q(psi, _ry(ang), q, nq)
    for q in range(nq):
        psi = _apply_1q(psi, _ry(da * math.pi * 0.3), q, nq)
    for q in range(nq):
        psi = _apply_1q(psi, _rz(ser * math.pi * 0.5), q, nq)
    if ach > 0.25 and nq >= 2:
        g = _ry(ach * math.pi * 0.4)
        for q in range(nq - 1):
            psi = _apply_controlled(psi, g, q, q + 1, nq)
    for q in range(nq):
        psi = _apply_1q(psi, _rx(ne * math.pi * 0.25), q, nq)
    if nq >= 2 and region_firing:
        vals = sorted((float(v) for v in region_firing.values()), reverse=True)
        if len(vals) >= 2 and vals[0] > CX_TOP and vals[1] > CX_SECOND:
            psi = _apply_controlled(psi, _cx_gate(), 0, nq - 1, nq)
            cof = min(vals[0], vals[1]) / max(vals[0], 0.01)
            psi = _apply_1q(psi, _rz(cof * math.pi * 0.3), nq - 1, nq)
    return psi


def modulo_fold(p_raw, n):
    out = [0.0] * n
    for idx, pr in enumerate(p_raw):
        out[idx if idx < n else idx % n] += float(pr)
    return out


def flags(region_firing_recorded):
    """(inputs_complete, cx_margin_ok) for a recorded region_firing dict."""
    rf = region_firing_recorded or {}
    inputs_complete = len(rf) < RECORDED_REGION_CAP
    vals = sorted((float(v) for v in rf.values()), reverse=True)[:2]
    cx_margin_ok = all(abs(v - CX_TOP) > CX_MARGIN and abs(v - CX_SECOND) > CX_MARGIN
                       for v in vals)
    return inputs_complete, cx_margin_ok


def model(n, scores, neuromodulators, region_firing):
    """Modeled legacy distribution for one decision.

    Returns {"q", "p_raw", "invalid_mass", "p" (folded), "inputs_complete",
    "cx_margin_ok", "rounding"}. ``scores`` are the raw scores as the caller
    passed them (None allowed).
    """
    if n < 2:
        raise ValueError("model needs n >= 2")
    ns = legacy_scores(scores, n)
    psi = legacy_statevector(n, ns, neuromodulators, region_firing)
    p_raw = (np.abs(psi) ** 2).tolist()
    invalid = math.fsum(p_raw[n:])
    inputs_complete, cx_ok = flags(region_firing)
    return {"q": legacy_n_qubits(n), "p_raw": p_raw, "invalid_mass": invalid,
            "p": modulo_fold(p_raw, n), "inputs_complete": inputs_complete,
            "cx_margin_ok": cx_ok, "rounding": ROUNDING_NOTE}


def fold_of_uniform(n):
    """Exact fold of a uniform 2^q distribution onto n (for characterization)."""
    q = legacy_n_qubits(n)
    return modulo_fold([1.0 / (1 << q)] * (1 << q), n)


def tvd(p, q):
    return 0.5 * math.fsum(abs(a - b) for a, b in zip(p, q))
