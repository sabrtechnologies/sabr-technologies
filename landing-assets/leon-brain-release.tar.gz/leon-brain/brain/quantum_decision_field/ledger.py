"""IBM ledger: write-ahead appends with fsync, replay, budget math (spec 7.3).

Written synchronously (flush + fsync on every record) by whoever holds
``ibm.lock``: the QV2-ibm broker thread, the diagnostic CLI, or
``analysis.py ibm-usage``. Never through a queue. Replayed under the lock
before every gate decision.

Every ``submit_attempt`` counts toward the budget, failures included. An
attempt is in flight until it has a terminal record.
"""
import json
import math
import os
import time

from . import authority
from .provenance import SCHEMA_IBM_LEDGER

TERMINAL_KINDS = frozenset({"done", "expired_cancelled", "failed", "refused_before_post",
                            "orphan_not_found"})
FAILURE_KINDS = frozenset({"error", "failed", "cancel_failed"})
SUCCESS_KINDS = frozenset({"usage", "submitted", "done", "cancel", "orphan_search"})
KINDS = frozenset({"usage", "submit_attempt", "submitted", "poll", "done", "cancel",
                   "cancel_failed", "expired_cancelled", "late_result", "failed",
                   "refused_before_post", "orphan_search", "orphan_not_found", "error",
                   "breaker", "kill_switch"})
PURPOSES = ("causal", "diagnostic")


class IbmLedger:
    """Append-only JSONL ledger. ``path=None`` keeps records in memory (used
    by the yield simulation; production always passes a path)."""

    def __init__(self, path, clock=time.time, fsync=True):
        self.path = path
        self.clock = clock
        self.fsync = fsync
        self._mem = [] if path is None else None

    def append(self, kind, **fields):
        if kind not in KINDS:
            raise ValueError("unknown ledger kind %r" % kind)
        rec = {"schema": SCHEMA_IBM_LEDGER, "kind": kind, "ts": fields.pop("ts", None) or self.clock()}
        rec.update(fields)
        if self._mem is not None:
            self._mem.append(rec)
            return rec
        line = json.dumps(rec, sort_keys=True, allow_nan=False) + "\n"
        d = os.path.dirname(self.path)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as fh:
            fh.write(line)
            fh.flush()
            if self.fsync:
                os.fsync(fh.fileno())
        return rec

    def records(self):
        if self._mem is not None:
            return list(self._mem)
        out = []
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except ValueError:
                        continue            # torn tail: ignored, never repaired
                    if isinstance(rec, dict):
                        out.append(rec)
        except FileNotFoundError:
            pass
        return out

    def replay(self, now=None):
        return LedgerState(self.records(), self.clock() if now is None else now)


class Attempt:
    __slots__ = ("attempt_id", "purpose", "entry_id", "ts", "job_id", "backend", "terminal",
                 "terminal_kind", "last_poll_ts", "cancel_attempts", "orphan_searches",
                 "pubs", "shots", "cancel_failed")

    def __init__(self, rec):
        self.attempt_id = rec.get("attempt_id")
        self.purpose = rec.get("purpose")
        self.entry_id = rec.get("entry_id")
        self.ts = float(rec.get("ts") or 0.0)
        self.job_id = rec.get("job_id")
        self.backend = rec.get("backend")
        self.terminal = False
        self.terminal_kind = None
        self.last_poll_ts = None
        self.cancel_attempts = 0
        self.orphan_searches = []
        self.pubs = rec.get("pubs")
        self.shots = rec.get("shots")
        self.cancel_failed = False

    def as_dict(self):
        return {"attempt_id": self.attempt_id, "purpose": self.purpose, "entry_id": self.entry_id,
                "ts": self.ts, "job_id": self.job_id, "backend": self.backend,
                "terminal": self.terminal, "terminal_kind": self.terminal_kind,
                "last_poll_ts": self.last_poll_ts, "cancel_attempts": self.cancel_attempts,
                "orphan_searches": list(self.orphan_searches)}


class LedgerState:
    def __init__(self, records, now):
        self.now = now
        self.attempts = {}
        self.order = []
        self.consecutive_failures = 0
        self.breaker_open_until = 0.0
        self.last_usage = None
        self.kill_switch_active = False
        for rec in records:
            kind = rec.get("kind")
            aid = rec.get("attempt_id")
            if kind == "submit_attempt" and aid:
                if aid not in self.attempts:
                    self.attempts[aid] = Attempt(rec)
                    self.order.append(aid)
            att = self.attempts.get(aid) if aid else None
            if att is not None:
                if rec.get("job_id") and not att.job_id:
                    att.job_id = rec.get("job_id")
                if rec.get("backend") and not att.backend:
                    att.backend = rec.get("backend")
                if kind == "poll":
                    att.last_poll_ts = float(rec.get("ts") or 0.0)
                if kind in ("cancel", "cancel_failed"):
                    att.cancel_attempts += 1
                    att.cancel_failed = kind == "cancel_failed"
                if kind == "orphan_search":
                    att.orphan_searches.append(float(rec.get("ts") or 0.0))
                if kind in TERMINAL_KINDS:
                    att.terminal = True
                    att.terminal_kind = kind
            if kind in FAILURE_KINDS:
                self.consecutive_failures += 1
            elif kind in SUCCESS_KINDS:
                self.consecutive_failures = 0
            if kind == "breaker":
                self.breaker_open_until = max(self.breaker_open_until,
                                              float(rec.get("open_until") or 0.0))
                self.consecutive_failures = 0
            if kind == "usage":
                self.last_usage = rec
            if kind == "kill_switch":
                self.kill_switch_active = bool(rec.get("active"))

    @property
    def in_flight(self):
        return [self.attempts[a] for a in self.order if not self.attempts[a].terminal]

    def breaker_open(self, now=None):
        return (self.now if now is None else now) < self.breaker_open_until

    def attempts_rolling(self, now=None, purpose=None, entry_id=None):
        now = self.now if now is None else now
        lo = now - authority.IBM_ROLLING_WINDOW_S
        k = 0
        for a in self.attempts.values():
            if a.ts <= lo:
                continue
            if purpose is not None and a.purpose != purpose:
                continue
            if entry_id is not None and a.entry_id != entry_id:
                continue
            k += 1
        return k

    def last_submit_ts(self, purpose=None):
        ts = [a.ts for a in self.attempts.values() if purpose is None or a.purpose == purpose]
        return max(ts) if ts else None

    def summary(self, now=None):
        return {"v2_rolling_28d": self.attempts_rolling(now),
                "v2_rolling_28d_causal": self.attempts_rolling(now, purpose="causal"),
                "v2_rolling_28d_diagnostic": self.attempts_rolling(now, purpose="diagnostic"),
                "in_flight": [a.as_dict() for a in self.in_flight],
                "breaker_open_until": self.breaker_open_until or None,
                "consecutive_failures": self.consecutive_failures,
                "last_usage": self.last_usage}


def legacy_jobs_used(budget_path):
    """jobs_used from quantum_budget.json (read-only). None if missing/corrupt."""
    try:
        with open(budget_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return None
    v = data.get("jobs_used") if isinstance(data, dict) else None
    if isinstance(v, bool) or not isinstance(v, int) or v < 0:
        return None
    return v


def default_budget_path(repo_root=None):
    return os.path.join(repo_root or authority.REPO_ROOT, "brain_state", "quantum_budget.json")


# Gate refusal reasons -> the intent-to-treat fallback reason (spec 6.5).
ITT_REASON = {"ibm_disabled": "ibm_disabled", "breaker_open": "breaker_open",
              "joint_budget_exhausted": "budget_exhausted", "causal_cap": "budget_exhausted",
              "entry_cap": "budget_exhausted", "diagnostic_cap": "budget_exhausted",
              "legacy_budget_unreadable": "budget_exhausted",
              "f5_not_satisfied": "budget_exhausted",
              "usage_refused": "ibm_quota_unavailable"}


def submit_gate(state, *, purpose, now, state_dir, canonical_dir, lock_held, ibm_disabled,
                repo_root=None, budget_path=None, entry_id=None, entry_cap=None):
    """Checks 1-6 of the submit gate. Returns (ok, reason). Check 7 (a fresh
    usage child) runs only after these pass, immediately before the submit."""
    if purpose not in PURPOSES:
        return False, "unknown_purpose"
    if ibm_disabled:
        return False, "ibm_disabled"
    if state.breaker_open(now):
        return False, "breaker_open"
    if not canonical_dir or os.path.realpath(state_dir) != os.path.realpath(canonical_dir):
        return False, "state_dir_not_canonical"
    if not lock_held:
        return False, "lock_not_held"
    if not authority.f5_satisfied(repo_root):
        return False, "f5_not_satisfied"
    used = legacy_jobs_used(budget_path or default_budget_path(repo_root))
    if used is None:
        return False, "legacy_budget_unreadable"
    if used + state.attempts_rolling(now) + 1 > authority.JOINT_CAP:
        return False, "joint_budget_exhausted"
    if purpose == "causal":
        if state.attempts_rolling(now, purpose="causal") + 1 > authority.V2_CAUSAL_CAP:
            return False, "causal_cap"
        if entry_cap is not None and state.attempts_rolling(now, entry_id=entry_id) + 1 > entry_cap:
            return False, "entry_cap"
    else:
        if state.attempts_rolling(now, purpose="diagnostic") + 1 > authority.V2_DIAG_CAP:
            return False, "diagnostic_cap"
    if state.in_flight:
        return False, "in_flight"
    last_any = state.last_submit_ts()
    if last_any is not None and now - last_any < authority.IBM_MIN_SPACING_ANY_S:
        return False, "spacing_any"
    if purpose == "causal":
        last_c = state.last_submit_ts("causal")
        if last_c is not None and now - last_c < authority.IBM_MIN_SPACING_CAUSAL_S:
            return False, "spacing_causal"
    return True, "ok"


def usage_allows_submit(usage):
    """Check 7, fail closed: usage_limit_reached must be exactly False and
    usage_remaining_seconds present, not None and >= the reserve."""
    if not isinstance(usage, dict):
        return False, "usage_missing"
    if "usage_limit_reached" not in usage:
        return False, "usage_limit_key_missing"
    if usage.get("usage_limit_reached") is not False:
        return False, "usage_limit_reached"
    rem = usage.get("usage_remaining_seconds")
    if (rem is None or isinstance(rem, bool) or not isinstance(rem, (int, float))
            or not math.isfinite(rem)):
        return False, "usage_remaining_missing"
    if rem < authority.IBM_USAGE_RESERVE_S:
        return False, "usage_remaining_below_reserve"
    return True, "ok"
