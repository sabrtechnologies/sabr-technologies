"""Pure statistics for diagnostics and analyses (spec 6.4, 6.5).

* ``chi2_sf``: regularized upper incomplete gamma Q(k/2, x/2); series for
  x < a+1, Lentz continued fraction otherwise. No scipy.
* ``pool_bins``: deterministic pooling. Sort bins by expected count, then
  index; accumulate until the group's E >= 5; fold any remainder into the
  last group formed; df = groups - 1; fewer than 2 groups -> chi2_na.
* ``mc_exact_conditional``: Monte Carlo exact conditional test of an r x c
  table (Freeman-Halton type) with the chi-square statistic; permutations
  from a seeded random.Random.
* ``cmh_general``: generalized Cochran-Mantel-Haenszel over strata, with a
  Monte Carlo exact fallback that permutes outcomes within strata.
* ``tvd`` and the multinomial no-bias baseline for pooled vectors.

Randomness comes only from ``random.Random(seed)``.
"""
import math
import random

import numpy as np

_EPS = 2.2e-16
_FPMIN = 1e-300


def _gser(a, x):
    ap, s = a, 1.0 / a
    d = s
    for _ in range(200000):
        ap += 1.0
        d *= x / ap
        s += d
        if abs(d) < abs(s) * _EPS:
            break
    return s * math.exp(-x + a * math.log(x) - math.lgamma(a))


def _gcf(a, x):
    b = x + 1.0 - a
    c = 1.0 / _FPMIN
    d = 1.0 / b
    h = d
    for i in range(1, 200000):
        an = -i * (i - a)
        b += 2.0
        d = an * d + b
        if abs(d) < _FPMIN:
            d = _FPMIN
        c = b + an / c
        if abs(c) < _FPMIN:
            c = _FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < _EPS:
            break
    return math.exp(-x + a * math.log(x) - math.lgamma(a)) * h


def chi2_sf(x, k):
    """P(X >= x) for X ~ chi-square with k degrees of freedom."""
    if k <= 0:
        raise ValueError("df must be positive")
    if x <= 0.0:
        return 1.0
    a, xx = k / 2.0, x / 2.0
    if xx < a + 1.0:
        return max(0.0, 1.0 - _gser(a, xx))
    return _gcf(a, xx)


def pool_bins(expected, min_expected=5.0):
    """-> list of index groups (deterministic)."""
    order = sorted(range(len(expected)), key=lambda i: (expected[i], i))
    groups, cur, cur_e = [], [], 0.0
    for i in order:
        cur.append(i)
        cur_e += expected[i]
        if cur_e >= min_expected:
            groups.append(cur)
            cur, cur_e = [], 0.0
    if cur:
        if groups:
            groups[-1] = groups[-1] + cur
        else:
            groups.append(cur)
    return groups


def chi_square_pooled(observed, probs, min_expected=5.0):
    total = sum(observed)
    expected = [total * p for p in probs]
    groups = pool_bins(expected, min_expected)
    if len(groups) < 2:
        return {"stat": "chi2_na", "groups": len(groups), "df": None, "chi2": None, "p": None}
    chi2 = 0.0
    for g in groups:
        e = math.fsum(expected[i] for i in g)
        o = sum(observed[i] for i in g)
        if e > 0:
            chi2 += (o - e) ** 2 / e
    df = len(groups) - 1
    return {"stat": "chi2", "groups": len(groups), "df": df, "chi2": chi2, "p": chi2_sf(chi2, df)}


def chi_square_naive(observed, probs):
    total = sum(observed)
    chi2 = sum((o - total * p) ** 2 / (total * p) for o, p in zip(observed, probs) if p > 0)
    df = len(probs) - 1
    return {"chi2": chi2, "df": df, "p": chi2_sf(chi2, df)}


def table_chi2(table):
    rows = [sum(r) for r in table]
    cols = [sum(c) for c in zip(*table)]
    n = sum(rows)
    if n == 0:
        return 0.0
    s = 0.0
    for i, r in enumerate(table):
        for j, o in enumerate(r):
            e = rows[i] * cols[j] / n
            if e > 0:
                s += (o - e) ** 2 / e
    return s


def _tabulate(rows, cols, n_rows, n_cols):
    t = [[0] * n_cols for _ in range(n_rows)]
    for r, c in zip(rows, cols):
        t[r][c] += 1
    return t


def mc_exact_conditional(units, n_rows, n_cols, n_perm=100000, seed=0):
    """units: [(row, col)]. Permutes column labels (margins fixed)."""
    rows = [u[0] for u in units]
    cols = [u[1] for u in units]
    obs = table_chi2(_tabulate(rows, cols, n_rows, n_cols))
    rng = random.Random(seed)
    perm = list(cols)
    ge = 0
    for _ in range(n_perm):
        rng.shuffle(perm)
        if table_chi2(_tabulate(rows, perm, n_rows, n_cols)) >= obs - 1e-12:
            ge += 1
    return {"chi2": obs, "p": (1 + ge) / (n_perm + 1), "n_perm": n_perm, "seed": seed}


def _cmh_q(strata_tables):
    r, c = strata_tables[0].shape
    dim = (r - 1) * (c - 1)
    g = np.zeros(dim)
    v = np.zeros((dim, dim))
    for t in strata_tables:
        n = t.sum()
        if n < 2:
            continue
        rs, cs = t.sum(1), t.sum(0)
        m = np.outer(rs, cs) / n
        g += (t - m)[: r - 1, : c - 1].ravel()
        pr, pc = rs / n, cs / n
        vr = np.diag(pr) - np.outer(pr, pr)
        vc = np.diag(pc) - np.outer(pc, pc)
        v += (n * n / (n - 1.0)) * np.kron(vr[: r - 1, : r - 1], vc[: c - 1, : c - 1])
    rank = int(np.linalg.matrix_rank(v)) if v.any() else 0
    if rank == 0:
        return 0.0, 0
    return float(g @ np.linalg.pinv(v) @ g), rank


def cmh_general(units, n_rows, n_cols, n_strata, exact_perm=0, seed=0):
    """units: [(row, col, stratum)]. Generalized CMH; if any expected cell
    < 5 (or exact_perm is set) also a within-strata Monte Carlo exact p."""
    tabs = [np.zeros((n_rows, n_cols)) for _ in range(n_strata)]
    for r, c, s in units:
        tabs[s][r, c] += 1
    used = [t for t in tabs if t.sum() >= 2]
    if not used:
        return {"stat": "cmh_na", "p": None}
    q, df = _cmh_q(used)
    out = {"stat": "cmh", "q": q, "df": df, "p": chi2_sf(q, df) if df else None}
    small = any((np.outer(t.sum(1), t.sum(0)) / t.sum() < 5).any() for t in used)
    if small or exact_perm:
        n_perm = exact_perm or 10000
        rng = random.Random(seed)
        by_s = {}
        for r, c, s in units:
            by_s.setdefault(s, []).append((r, c))
        ge = 0
        for _ in range(n_perm):
            pt = [np.zeros((n_rows, n_cols)) for _ in range(n_strata)]
            for s, lst in by_s.items():
                cs = [c for _, c in lst]
                rng.shuffle(cs)
                for (r, _), c in zip(lst, cs):
                    pt[s][r, c] += 1
            qq, _ = _cmh_q([t for t in pt if t.sum() >= 2])
            if qq >= q - 1e-12:
                ge += 1
        out.update(exact_p=(1 + ge) / (n_perm + 1), exact_n_perm=n_perm, small_expected=small)
    return out


def tvd(p, q):
    return 0.5 * math.fsum(abs(a - b) for a, b in zip(p, q))


def expected_tvd_null(p, n):
    """Expected TVD between an n-sample multinomial empirical distribution
    and its true p (normal approximation): the no-bias baseline."""
    if n <= 0:
        return None
    return 0.5 * math.fsum(math.sqrt(2.0 * x * (1.0 - x) / (math.pi * n)) for x in p)


def normalize_counts(counts):
    s = sum(counts)
    return [c / s for c in counts] if s else [0.0] * len(counts)
