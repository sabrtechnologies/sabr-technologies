"""Cited, revisable facts in the existing knowledge store, never in shipped seeds.

The head table is only an index into knowledge: old revisions remain available
for audit. Ingestion requires exact quotes from user conversation rows. A quote
proves provenance, not that a proposed summary follows from it; callers must
review that relationship before submitting a fact.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import time


def _connect(path, mode="ro"):
    return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=" + mode,
                           uri=True, timeout=2)


def _text(value, limit):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError("invalid or oversized fact field")
    return value.strip()


def remember(db_path, *, key, text, aliases, evidence):
    """Atomically retain a reviewed summary and its source quotes.

    Reuse a key for corrections. Older evidence cannot replace newer evidence;
    retrying identical input returns the existing id. No original row is deleted.
    """
    key, text = _text(key, 120), _text(text, 900)
    if not re.fullmatch(r"[a-z0-9][a-z0-9_.-]*", key):
        raise ValueError("key must be a stable lowercase fact identifier")
    if not isinstance(aliases, list) or not 1 <= len(aliases) <= 20:
        raise ValueError("provide 1 to 20 explicit aliases")
    aliases = sorted({_text(a, 80).lower() for a in aliases})
    if not isinstance(evidence, list) or not 1 <= len(evidence) <= 12:
        raise ValueError("provide 1 to 12 user conversation quotes")
    conn = _connect(db_path, "rw")  # Never create an empty database by mistake.
    try:
        with conn:
            conn.execute("BEGIN IMMEDIATE")
            refs = []
            for ref in evidence:
                if not isinstance(ref, dict) or type(ref.get("conversation_id")) is not int:
                    raise ValueError("each quote needs a conversation_id")
                quote = _text(ref.get("quote"), 6000)
                row = conn.execute("SELECT role, content, ts, model FROM conversation_history WHERE id=?",
                                   (ref["conversation_id"],)).fetchone()
                if (not row or row[0] != "user" or row[3] == "proactive"
                        or quote not in row[1] or not math.isfinite(float(row[2]))):
                    raise ValueError("evidence must quote an existing user conversation turn")
                refs.append({"conversation_id": ref["conversation_id"], "quote": quote,
                             "timestamp": row[2],
                             "content_sha256": hashlib.sha256(row[1].encode()).hexdigest()})
            refs.sort(key=lambda r: (r["conversation_id"], r["quote"]))
            observed = max(r["timestamp"] for r in refs)
            payload = {"key": key, "aliases": aliases, "evidence": refs, "observed": observed}
            digest = hashlib.sha256(json.dumps([text, payload], sort_keys=True).encode()).hexdigest()
            conn.execute("CREATE TABLE IF NOT EXISTS durable_fact_heads ("
                         "fact_key TEXT PRIMARY KEY, knowledge_id INTEGER NOT NULL, "
                         "observed REAL NOT NULL, digest TEXT NOT NULL)")
            head = conn.execute("SELECT knowledge_id, observed, digest FROM durable_fact_heads "
                                "WHERE fact_key=?", (key,)).fetchone()
            if head and head[2] == digest:
                if conn.execute("SELECT 1 FROM knowledge WHERE id=?", (head[0],)).fetchone():
                    return head[0]
                raise ValueError("fact was removed; explicit correction is required")
            if head and observed < head[1]:
                raise ValueError("older evidence cannot overwrite a newer fact")
            payload["previous_id"] = head[0] if head else None
            retired_turns = set()
            if head:
                previous = conn.execute("SELECT metadata FROM knowledge WHERE id=?", (head[0],)).fetchone()
                if previous:
                    prior = json.loads(previous[0])["durable_fact"]
                    retired_turns.update(prior.get("superseded_conversation_ids", []))
                    retired_turns.update(e["conversation_id"] for e in prior["evidence"])
            payload["superseded_conversation_ids"] = sorted(
                retired_turns - {e["conversation_id"] for e in refs})
            metadata = json.dumps({"durable_fact": payload}, sort_keys=True)
            row = conn.execute("INSERT INTO knowledge(text, source, tags, timestamp, metadata, strength) "
                               "VALUES (?, 'dean_stated', ?, ?, ?, 1.0)",
                               (text, ",".join(["protected", "durable_fact"] + aliases), time.time(), metadata))
            fact_id = row.lastrowid
            if head and previous:
                previous_meta = json.loads(previous[0])
                previous_meta["superseded_by"] = fact_id
                conn.execute("UPDATE knowledge SET metadata=? WHERE id=?",
                             (json.dumps(previous_meta, sort_keys=True), head[0]))
            conn.execute("INSERT OR REPLACE INTO durable_fact_heads VALUES (?, ?, ?, ?)",
                         (key, fact_id, observed, digest))
            return fact_id
    finally:
        conn.close()


def current_facts(db_path):
    """Read current canonical rows; absent schema is normal on a new instance."""
    conn = _connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        if not conn.execute("SELECT 1 FROM sqlite_master WHERE name='durable_fact_heads'").fetchone():
            return []
        rows = conn.execute("SELECT k.* FROM durable_fact_heads h JOIN knowledge k "
                            "ON k.id=h.knowledge_id ORDER BY h.fact_key").fetchall()
        out = []
        for row in rows:
            try:
                meta = json.loads(row["metadata"])
                fact = meta["durable_fact"]
                if row["source"] != "dean_stated":
                    continue
                if any(k in meta and not isinstance(meta[k], bool)
                       for k in ("revoked", "authorized", "unverified")):
                    continue
                if meta.get("revoked") or meta.get("authorized") is False or meta.get("unverified"):
                    continue
                # Scoped rows belong to the policy-aware memory service.
                if any(k in meta for k in ("owner_id", "principal_id", "identity_id", "allowed_principals")):
                    continue
                if (not isinstance(fact["aliases"], list)
                        or not all(isinstance(a, str) and a for a in fact["aliases"])
                        or not isinstance(fact["evidence"], list) or not fact["evidence"]
                        or not all(isinstance(e, dict) and type(e.get("conversation_id")) is int
                                   for e in fact["evidence"])):
                    continue
                out.append(dict(row, fact=fact))
            except (ValueError, KeyError, TypeError):
                continue
        return out
    finally:
        conn.close()


def search(db_path, query, limit=8):
    """Exact alias tokens plus topical coverage; never short-prefix names."""
    from brain.lived_recall import query_terms, _words
    terms = set(query_terms(query))
    words = set(_words(query.lower().replace("’", "'")))
    words |= {w[:-2] for w in words if w.endswith("'s")}
    if not terms or limit <= 0:
        return []
    hits = []
    for row in current_facts(db_path):
        aliases = [set(_words(a)) for a in row["fact"]["aliases"] if isinstance(a, str)]
        named = any(a and a <= words for a in aliases)
        overlap = terms & set(query_terms(row["text"]))
        if not named and not overlap:
            continue
        score = 2 * int(named) + len(overlap) / len(terms)
        hits.append((score, row))
    hits.sort(key=lambda item: (-item[0], -item[1]["fact"]["observed"], item[1]["id"]))
    return [row for _, row in hits[:limit]]


def merge_results(db_path, query, rows, limit):
    """Use the same current facts for explicit searches and automatic recall."""
    try:
        facts = search(db_path, query, limit)
    except (sqlite3.Error, OSError):
        facts = []  # Still exclude historical structured rows on read failure.
    ids = {row["id"] for row in facts}
    # Historical structured revisions must never come back via ordinary FTS.
    rest = []
    for row in rows:
        try:
            structured = "durable_fact" in json.loads(row.get("metadata") or "{}")
        except (TypeError, ValueError):
            structured = False
        if row["id"] not in ids and not structured:
            rest.append(row)
    return (facts + rest)[:limit]
