"""Small shadow status cache refreshed by the existing simulation tick.

No import-time work, capture, provider call, scene construction or persistence.
The WebSocket path only copies a fresh flat dictionary. Canonical state and
legacy sensing stay owned by their existing modules.
"""
import time

INTERVAL_S = 1.0
MAX_AGE_S = 3.0


def _owner(state):
    runtime = getattr(state, 'cognitive_runtime', None)
    owner = getattr(runtime, 'sensory', None)
    scene = getattr(state, 'scene_model', None)
    if owner is None or scene is None or getattr(owner, 'scene', None) is not scene:
        return None
    return owner if owner.mode() == 'shadow' else None


def refresh(state, *, now=None):
    """Single existing sim-thread writer; no scene-lock wait or disk work."""
    try:
        now = time.monotonic() if now is None else now
        owner = _owner(state)
        if owner is None:
            state._sensory_v2_cache = None
            return
        previous = getattr(state, '_sensory_v2_cache', None)
        if previous and previous[0] is owner and 0 <= now - previous[1] < INTERVAL_S:
            return
        data = dict(owner.scene.status_metadata(), mode='shadow', authoritative=False)
        # A pause/replacement racing the projection must not revive old evidence.
        state._sensory_v2_cache = (owner, now, data) if _owner(state) is owner else None
    except Exception:
        state._sensory_v2_cache = None


def peek(state, *, now=None):
    """OFF is absent; an enabled stale cache exposes unavailable, never old facts."""
    try:
        owner = _owner(state)
        if owner is None:
            return None
        now = time.monotonic() if now is None else now
        cached = getattr(state, '_sensory_v2_cache', None)
        if cached and cached[0] is owner and 0 <= now - cached[1] <= MAX_AGE_S:
            return dict(cached[2], projection_age_s=round(now - cached[1], 3))
        return {'mode': 'shadow', 'authoritative': False, 'available': False,
                'reason': 'no_fresh_projection'}
    except Exception:
        return None
