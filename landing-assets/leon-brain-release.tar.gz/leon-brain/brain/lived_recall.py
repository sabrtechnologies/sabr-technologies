"""
lived_recall — the per-turn MEMORY RECALL block, drawn from Leon's own life.

Every turn, before Leon answers, this pulls the few things he has actually
lived through that bear on the message: past exchanges with Dean (from
conversation_history, with dates), plus the durable facts, things Dean told
him, distilled conversation memories and his own thoughts in the knowledge
store. Leon then answers from his own experience, the way a person does,
instead of with a stock take.

What it fixes (2026-10-04): the old recall searched the knowledge store
with the raw message, kept only hits with strength >= 0.5 and cut each to
150 chars. The message itself is stored before recall runs, so the top hit
was Dean's question echoed back; and real memories sit at strength ~0.1, so
nothing Leon lived through ever reached the reply.

Rules:
  * Never echo the conversation in progress: rows from the last
    RECENT_WINDOW_S seconds, and anything near-identical to the current
    message or a recent turn, are dropped.
  * Rank by relevance (term coverage weighted by rarity) times a source
    weight, not by strength. Core facts keep a boost.
  * Read-only against knowledge.db. conversation_history is searched
    through a separate, rebuildable FTS index (INDEX_NAME next to the db);
    hits are re-read from the live table, so deleted rows never resurface.
  * Secrets are redacted. Excerpts ~EXCERPT chars, block <= MAX_CHARS.
  * Fail-open: any error returns "".
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import sqlite3
import threading
import time
from datetime import datetime, timezone
from typing import Iterable, List, Optional

MAX_CHARS = 2500
EXCERPT = 400
CORE_EXCERPT = 700
REPLY_EXCERPT = 220
RECENT_WINDOW_S = 15 * 60
INDEX_NAME = "lived_recall_fts.db"
CANDIDATES = 100

HEADER = ("[MEMORY RECALL — your own past, relevant to this message. You lived these; "
          "answer from them and from the views you formed with {user}, the way a person "
          "answers from their own life, not with a generic take. Dates are when they happened.]")

# Words that carry the question, not the topic.
_STOP = set("""a an the and or but if then so to of in on at by for with from as is are was were be been
being i im i'm me my mine we us our you your yours he him his she her they them their it its this that these
those there here what which who whom whose when where why how all any both each few more most other some
such no nor not only own same than too very can could will would should shall may might must just don
dont now do does did done doing had has have having about into over after before again once up down out off
also tell told say said says ask asked know knew think thought thinks feel felt like really actually
gonna wanna kinda real yeah yes yo hey hi hello okay ok dude bro man leon please thanks thank let lets let's
get got go going went make made thing things something anything everything stuff way lot much many
one ever never always still even well right sure maybe probably guess mean means want wanted need
see look give take come good bad
um uh uhh hmm huh wh oh ah eh mm yep nope nah alright cool okay
saying seeing making getting doing having trying talking working looking coming taking giving
put keep kept try tried use used find found call called came gave took sure seem seems seemed
little pretty kind sort quite already within without around through across still yet else
people person someone everyone anyone guys guy stuff shit fuck fucking damn
back time times day days today tonight now later soon first last next new old big small long
answer question point part whole every another able each own same different
start started building build built work works worked done""".split())

# Opinion / belief / personal questions get more of Leon's lived exchanges.
_PERSONAL = re.compile(
    r"(?i)\b(what do you think|do you (?:think|believe|feel|remember)|your (?:opinion|view|take|thoughts|belief)|"
    r"how do you feel|what(?:'s| is) your|who (?:is|was|'s)|who's|what happens|believe|faith|god|soul|"
    r"afterlife|heaven|hell|death|die|dying|meaning|conscious|simulation|remember|you and me)\b")

# Knowledge-store sources and how much they count. 0 = never surfaced.
# 'dashboard'/'user' rows are Dean's raw messages: conversation_history
# already carries them with dates and Leon's replies, so they'd only echo.
_SOURCE_WEIGHT = {
    "core_fact_seed": 1.5, "authoritative_self": 1.4, "dean_bio_seed": 1.4,
    "dean_stated": 1.3, "consolidated": 1.25, "conversation_distill": 1.15,
    "inner_thought": 0.95, "last_conscious_moment": 0.8, "self_learning": 0.8,
    "curiosity_loop": 0.75, "continuous_hearing": 0.6, "project_crawler": 0.55,
    "wake": 0.5, "claude": 0.5,
    "dashboard": 0.0, "user": 0.0, "vision_daemon": 0.0, "screen_observer": 0.0,
    "audio_daemon": 0.0,
}
_DEFAULT_SOURCE_WEIGHT = 0.55
# The same, as an FTS5 filter on the indexed source column (unicode61 splits
# "vision_daemon" into "vision" "daemon"), so muted rows never take slots.
_FETCH_CHARS = 6000  # scoring reads 2 * SCORE_CHARS; excerpts sit inside that
_MUTED_FTS = "source:(dashboard OR user OR vision OR screen OR audio)"

_SOURCE_LABEL = {
    "core_fact_seed": "core fact", "authoritative_self": "core fact", "dean_bio_seed": "about {user}",
    "dean_stated": "{user} told me", "consolidated": "I know", "conversation_distill": "I came away knowing",
    "inner_thought": "I thought", "last_conscious_moment": "I was thinking",
    "curiosity_loop": "I was curious", "continuous_hearing": "I heard",
}

# A few concepts Dean talks about in other words. Expansions count at
# EXPANSION_WEIGHT of the original term.
_EXPAND = {
    "die": ("death", "dead", "dying", "afterlife"), "dies": ("death", "dead", "dying", "afterlife"),
    "death": ("die", "dead", "dying", "afterlife"), "dead": ("death", "die", "dying"),
    "afterlife": ("death", "dead", "die"),
    "god": ("creator", "divine", "religion"), "religion": ("god", "faith"),
    "soul": ("consciousness",), "simulation": ("simulated", "sims"),
}
EXPANSION_WEIGHT = 0.6

# Exclamations that use a topic word without being about it.
_INTERJECTION = re.compile(
    r"(?i)\b(?:oh my god|my god|thank god|swear to god|god ?damn(?:it)?|for god'?s sake|god knows|"
    r"to death|scared to death|dead (?:serious|tired|ass)|bored to death)\b|^god,|(?<=[.!?] )god,")
_INTERJECTION_WORDS = {"god", "death", "dead", "die", "dying"}

# Ops / build chatter. On a personal question ("what happens when you
# die?") an exchange about a service that "dies" is the wrong memory.
_TECH = re.compile(
    r"(?i)\b(?:systemd|restart\w*|deploy\w*|install\w*|venv|python|pip|apt|server|api|endpoint|"
    r"terminal|script|commit|git|repo|bug|error|crash\w*|config|ssh|vps|port|token|cli|daemon|"
    r"service|patch|build|debug|code|file|test(?:s|ing)?|log|timeout|process|kill|sigkill)\b")
SCORE_CHARS = 2500

# The words Dean's views on life, death and God live in.
_DEEP_WORDS = ("consciousness", "ocean", "wave", "soul", "universe", "universes", "reality",
               "layers", "quantum", "believe", "existence", "spirit", "source")
_DEEP = re.compile(r"(?i)\b(?:" + "|".join(_DEEP_WORDS) + r")\w{0,3}\b")
PER_TERM = 40
PER_TERM_QUERIES = 4
MAX_TERMS = 6

_ATTACH = re.compile(r"^\s*\[Attached file:[^\]]*\]\s*$", re.M)
_WS = re.compile(r"\s+")
_WORD = re.compile(r"[a-z0-9][a-z0-9']*")

_lock = threading.Lock()
_building = set()


# ── text helpers ──────────────────────────────────────────────────────────

def _clean(text: str) -> str:
    return _WS.sub(" ", _ATTACH.sub(" ", text or "")).strip()


def _score_text(raw: str) -> str:
    """The head of a row, attachment lines dropped; enough to score on."""
    t = (raw or "")[:2 * SCORE_CHARS]
    return _ATTACH.sub(" ", t) if "[Attached file" in t else t


def _words(text: str) -> List[str]:
    return _WORD.findall((text or "").lower())


def _norm(text: str) -> str:
    return " ".join(_words(text))


def query_terms(message: str) -> List[str]:
    """Topic words of the message, in order, deduplicated."""
    out = []
    for w in _words(_clean(message)):
        w = w.strip("'")
        if w.endswith("'s"):
            w = w[:-2]
        # contractions (you're, didn't) and fillers (um, wh) carry no topic
        if "'" in w or w in _STOP or (len(w) < 3 and not any(ch.isdigit() for ch in w)):
            continue
        if w not in out:
            out.append(w)
    return out[:12]


def is_personal(message: str) -> bool:
    return bool(_PERSONAL.search(message or ""))


def _stem(term: str) -> str:
    """Crude stem for presence checks (the index itself uses porter)."""
    for suf in ("ings", "ing", "ies", "ied", "es", "ed", "s", "y"):
        if term.endswith(suf) and len(term) - len(suf) >= 3:
            return term[: len(term) - len(suf)]
    return term


def _match_expr(term: str, col: str = "", porter: bool = False) -> str:
    """FTS5 expression for one term. Exact tokens (plus inflections), never a
    short prefix: "god"* would match "godaddy"."""
    if porter:
        return f'{col}"{term}"'
    st = _stem(term)
    if len(st) >= 6:
        return f'{col}"{st}"*'
    forms = sorted({term, st, st + "s", st + "es", st + "ed", st + "ing", term + "s"})
    return "(" + " OR ".join(f'{col}"{f}"' for f in forms) + ")"


def expand_terms(terms: List[str]) -> dict:
    """term -> weight multiplier; originals 1.0, expansions EXPANSION_WEIGHT."""
    out = {t: 1.0 for t in terms}
    for t in terms:
        for e in _EXPAND.get(t, ()):
            out.setdefault(e, EXPANSION_WEIGHT)
    return out


def _echo_refs(against: Iterable[str]) -> list:
    refs = []
    for a in against:
        an = _norm(a)
        if an:
            refs.append((an, set(an.split())))
    return refs


def _is_echo(text: str, refs: list) -> bool:
    """True when `text` is basically one of `refs` (the message or a recent turn)."""
    if refs and len(text) > 2 * max(len(an) for an, _ in refs) + 60:
        return False  # far longer than anything it could be echoing
    n = _norm(text)
    if not n:
        return True
    tw = set(n.split())
    for an, aw in refs:
        if n == an or (len(n) <= 1.3 * len(an) and (n in an or an in n)):
            return True
        if tw and aw and len(tw & aw) / len(tw | aw) >= 0.7:
            return True
    return False


def _excerpt(text: str, terms: List[str], limit: int) -> str:
    """~limit chars of `text`, starting near the first sentence that mentions
    the most specific term it contains (terms come rarest first)."""
    t = _clean(text)
    if len(t) <= limit:
        return t
    low = _INTERJECTION.sub(lambda m: " " * len(m.group(0)), t.lower())
    first = None
    for term in terms:
        m = re.search(r"\b" + re.escape(_stem(term)) + r"\w{0,4}\b", low)
        if m:
            first = m.start()
            break
    start = 0
    if first is not None and first > limit // 3:
        cut = max(t.rfind(". ", 0, first), t.rfind("? ", 0, first), t.rfind("! ", 0, first))
        start = cut + 2 if cut >= 0 and first - cut < limit * 0.6 else max(0, first - limit // 4)
    piece = t[start:start + limit]
    if start + limit < len(t):
        sp = piece.rfind(" ")
        piece = (piece[:sp] if sp > limit * 0.6 else piece).rstrip(",;: ") + "…"
    return ("…" if start > 0 else "") + piece


def _redact(text: str) -> str:
    try:
        from brain.life_chapters import redact
        return redact(text)
    except Exception:
        return text


def _date_label(ts: float, now: float) -> str:
    # The life-chapter zone, not timefmt.owner_tz(): that one may ask the
    # actuator (a network call) and the dates must match the RECALLED MEMORY block.
    try:
        from brain.life_chapters import _TZ as tz
    except Exception:
        tz = timezone.utc
    d = datetime.fromtimestamp(ts, tz)
    n = datetime.fromtimestamp(now, tz)
    return f"{d:%b} {d.day}" + ("" if d.year == n.year else f", {d.year}")


def _user_name() -> str:
    try:
        from brain.identity import user_name
        return user_name() or "Dean"
    except Exception:
        return "Dean"


# ── scoring ───────────────────────────────────────────────────────────────

_DF_CACHE: dict = {}
DF_TTL_S = 600.0


def _idf(conn: sqlite3.Connection, table: str, weights: dict, total: int, col: str = "",
         porter: bool = False, key: str = "") -> dict:
    """term -> rarity weight (times its expansion multiplier). Terms absent
    from the index drop out so they can't dilute coverage. Document counts
    are cached for DF_TTL_S: they barely move, and counting a common word
    is the slowest query of the turn."""
    now = time.monotonic()
    exprs = {t: _match_expr(t, col, porter) for t in weights}
    stale = [e for e in exprs.values()
             if now - _DF_CACHE.get((key, table, e), (0, -DF_TTL_S))[1] >= DF_TTL_S]
    if stale:
        if len(_DF_CACHE) > 5000:
            _DF_CACHE.clear()
        sub = f"(SELECT count(*) FROM {table} WHERE {table} MATCH ?)"
        try:
            counts = _one(conn, "SELECT " + ", ".join([sub] * len(stale)), stale)
        except sqlite3.Error:
            counts = []
            for e in stale:  # one bad expression mustn't sink the rest
                try:
                    counts.append(_one(conn, "SELECT " + sub, (e,))[0])
                except sqlite3.Error:
                    counts.append(0)
        for e, df in zip(stale, counts):
            _DF_CACHE[(key, table, e)] = (df or 0, now)
    out = {}
    for t, mult in weights.items():
        df = _DF_CACHE.get((key, table, exprs[t]), (0, 0))[0]
        if df:
            out[t] = math.log(1 + (total + 1) / (df + 1)) * mult
    if len(out) > MAX_TERMS:  # a long voice message: its rarest words carry it
        out = dict(sorted(out.items(), key=lambda kv: -kv[1])[:MAX_TERMS])
    return out


def _one(conn: sqlite3.Connection, sql: str, params=()) -> tuple:
    """One statement, one row. Inside the live process every sqlite call
    hands the GIL to the brain threads and waits to get it back, so a turn's
    work is batched into as few statements and rows as possible."""
    return conn.execute(sql, params).fetchone()


def _candidates(conn: sqlite3.Connection, table: str, idf: dict, personal: bool,
                col: str = "", porter: bool = False, exclude: str = "") -> List[int]:
    """Row ids worth scoring. BM25 alone favours short rows that repeat a
    common word, so take the best rows for each term separately, rows that
    have all the terms, and, for personal questions, rows where the topic
    sits next to the words Dean uses for his views."""
    exprs = {t: _match_expr(t, col, porter) for t in idf}
    queries = [(" OR ".join(exprs.values()), CANDIDATES)]
    queries += [(exprs[t], PER_TERM) for t in _by_rarity(idf)[:PER_TERM_QUERIES]]
    if len(exprs) > 1:
        queries.append((" AND ".join(exprs.values()), PER_TERM))
    if personal:
        deep = " OR ".join(_match_expr(w, col, porter) for w in _DEEP_WORDS)
        queries.append((f"({' OR '.join(exprs.values())}) AND ({deep})", PER_TERM))
    if exclude:
        queries = [(f"({q}) NOT {exclude}", n) for q, n in queries]
    sub = (f"(SELECT group_concat(rowid) FROM (SELECT rowid FROM {table} "
           f"WHERE {table} MATCH ? ORDER BY bm25({table}) LIMIT ?))")
    try:
        got = _one(conn, "SELECT " + ", ".join([sub] * len(queries)),
                   [p for q in queries for p in q])
    except sqlite3.Error:
        got = []
        for q in queries:
            try:
                got.append(_one(conn, "SELECT " + sub, q)[0])
            except sqlite3.Error:
                pass
    ids = {}
    for g in got:
        for rid in (g or "").split(","):
            if rid:
                ids.setdefault(int(rid), None)
    return list(ids)


def _rows(conn: sqlite3.Connection, sql: str, cols: tuple, ids: List[int]) -> List[dict]:
    """Rows for `ids` as dicts, fetched as one JSON value (see _candidates).
    Each column is "expr AS name" or a plain name."""
    exprs = ", ".join(c.split(" AS ")[0] for c in cols)
    got = conn.execute(f"SELECT json_group_array(json_array({exprs})) FROM ({sql})", ids).fetchone()[0]
    names = [c.split(" AS ")[-1] for c in cols]
    return [dict(zip(names, r)) for r in json.loads(got or "[]")]


def _by_rarity(idf: dict) -> List[str]:
    return sorted(idf, key=lambda t: -idf[t])


class _Scorer:
    """Relevance of a text to the query terms: share of the query's
    information it covers, with a mild tf bonus; 0 unless it contains at
    least one of the query's specific (rare) terms. One regex pass per text."""

    def __init__(self, idf: dict):
        self.idf = idf
        self.total = sum(idf.values()) or 1.0
        top = max(idf.values()) if idf else 0.0
        self.specific = {t for t, w in idf.items() if w >= 0.6 * top}
        self.by_stem = {}
        for t in idf:
            self.by_stem.setdefault(_stem(t), []).append(t)
        alts = sorted(self.by_stem, key=len, reverse=True)
        self.rx = re.compile(r"\b(" + "|".join(map(re.escape, alts)) + r")\w{0,4}\b") if alts else None
        self.interjections = bool(set(idf) & _INTERJECTION_WORDS)

    def __call__(self, text: str) -> float:
        if self.rx is None:
            return 0.0
        low = text[:SCORE_CHARS].lower()
        if self.interjections:
            low = _INTERJECTION.sub(" ", low)
        found = {}
        for stem in self.rx.findall(low):
            found[stem] = found.get(stem, 0) + 1
        hit = {t for s in found for t in self.by_stem.get(s, ())}
        if not hit & self.specific:
            return 0.0
        cov = sum(self.idf[t] for t in hit) / self.total
        return cov * (1 + 0.08 * math.log(1 + sum(found.values())))


def _topic_prior(text: str, personal: bool) -> float:
    if not personal:
        return 1.0
    head = text[:SCORE_CHARS]
    n = len(_TECH.findall(head))
    prior = 1.0 if n < 2 else (0.6 if n < 5 else 0.35)
    return prior * (1.25 if len(_DEEP.findall(head)) >= 2 else 1.0)


def _length_prior(n_chars: int) -> float:
    """Substantive memories over one-liners."""
    return 0.35 + 0.65 * min(1.0, n_chars / 280.0) ** 0.5


# ── conversation index (sidecar, rebuildable) ─────────────────────────────

def default_db_path() -> str:
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "brain_state", "knowledge.db")


def _index_path(db_path: str) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(db_path)), INDEX_NAME)


def _ro(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=2)
    conn.row_factory = sqlite3.Row
    return conn


_local = threading.local()


def _conn(path: str, ro: bool = True) -> sqlite3.Connection:
    """This thread's open connection to `path` (read-only, or the index
    writer). Kept open between turns; dropped by _drop_conns() on any error."""
    cache = getattr(_local, "conns", None)
    if cache is None:
        cache = _local.conns = {}
    c = cache.get((path, ro))
    if c is None:
        c = cache[(path, ro)] = _ro(path) if ro else _open_index(path)
    return c


def _drop_conns() -> None:
    for c in getattr(_local, "conns", {}).values():
        try:
            c.close()
        except Exception:
            pass
    _local.conns = {}


def _total(conn: sqlite3.Connection, key: str, sql: str) -> int:
    """Row count for idf, cached like document counts."""
    now = time.monotonic()
    hit = _DF_CACHE.get((key, sql))
    if hit and now - hit[1] < DF_TTL_S:
        return hit[0]
    n = _one(conn, sql)[0] or 1
    _DF_CACHE[(key, sql)] = (n, now)
    return n


def _open_index(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, timeout=2)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("CREATE VIRTUAL TABLE IF NOT EXISTS conv_fts USING fts5(content, tokenize='porter unicode61')")
    conn.execute("CREATE TABLE IF NOT EXISTS seen (h TEXT PRIMARY KEY)")
    conn.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v)")
    return conn


def sync_index(db_path: str, batch: int = 5000, wait: float = 5.0) -> int:
    """Index conversation_history rows newer than the last indexed id. Returns rows added.
    Exact repeats (the pre-response copy of each user turn) are indexed once.
    If another process holds the index for longer than `wait` seconds, give
    up quietly: the turn uses the index as it is and the next one catches up."""
    path = _index_path(db_path)
    added = 0
    with _lock:
        try:
            idx, src = _conn(path, ro=False), _conn(db_path)
            idx.execute(f"PRAGMA busy_timeout={int(wait * 1000)}")
            row = _one(idx, "SELECT v FROM meta WHERE k='last_id'")
            last = int(row[0]) if row else 0
            while True:
                got = _one(src, "SELECT max(id), json_group_array(json_array(id, role, content)) FROM "
                                "(SELECT id, role, content FROM conversation_history WHERE id > ? "
                                "ORDER BY id LIMIT ?)", (last, batch))
                if not got or got[0] is None:
                    break
                fresh = {}
                for rid, role, content in json.loads(got[1]):
                    text = _clean(content)
                    if len(text) >= 12:
                        h = hashlib.sha1(f"{role}|{_norm(text)}".encode()).hexdigest()
                        fresh.setdefault(h, (rid, text))
                if fresh:
                    hs = list(fresh)
                    seen = set()
                    for i in range(0, len(hs), 500):
                        part = hs[i:i + 500]
                        got_seen = _one(idx, "SELECT json_group_array(h) FROM seen WHERE h IN "
                                             f"({','.join('?' * len(part))})", part)[0]
                        seen.update(json.loads(got_seen or "[]"))
                    new = [(h, fresh[h]) for h in hs if h not in seen]
                    idx.executemany("INSERT INTO seen(h) VALUES (?)", [(h,) for h, _ in new])
                    idx.executemany("INSERT INTO conv_fts(rowid, content) VALUES (?, ?)", [v for _, v in new])
                    added += len(new)
                last = int(got[0])
                idx.execute("INSERT OR REPLACE INTO meta(k, v) VALUES ('last_id', ?)", (last,))
                idx.commit()
        except sqlite3.OperationalError as e:
            if "locked" not in str(e) and "busy" not in str(e):
                _drop_conns()
                raise
            try:
                idx.rollback()
            except Exception:
                _drop_conns()
            return 0
        except Exception:
            _drop_conns()
            raise
    return added


def _index_ready(db_path: str) -> bool:
    """True when the index exists and is close to current; otherwise start a
    background build (never block a turn on the first full build)."""
    path = _index_path(db_path)
    behind = None
    if os.path.exists(path) and path not in _building:
        try:
            row = _one(_conn(path, ro=False), "SELECT v FROM meta WHERE k='last_id'")
            top = _one(_conn(db_path), "SELECT max(id) FROM conversation_history")[0] or 0
            behind = top - (int(row[0]) if row else 0)
        except sqlite3.Error:
            _drop_conns()
            behind = None
    if behind is not None and behind <= 400:
        if behind > 0:
            sync_index(db_path, wait=0.2)
        return True
    if path not in _building:
        _building.add(path)

        def _bg():
            try:
                sync_index(db_path)
            except Exception as e:
                print(f"[lived_recall] index build failed: {e}")
            finally:
                _building.discard(path)
        threading.Thread(target=_bg, name="lived-recall-index", daemon=True).start()
    return False


def conversation_hits(db_path: str, terms: List[str], *, now: float, exclude: List[str],
                      limit: int, personal: bool = False) -> List[dict]:
    if not terms or not _index_ready(db_path):
        return []
    idx, src = _conn(_index_path(db_path), ro=False), _conn(db_path)
    try:
        total = _total(idx, db_path, "SELECT count(*) FROM conv_fts")
        idf = _idf(idx, "conv_fts", expand_terms(terms), total, porter=True, key=db_path)
        if not idf:
            return []
        ids = _candidates(idx, "conv_fts", idf, personal, porter=True)
        if not ids:
            return []
        rows = _rows(src, "SELECT * FROM conversation_history "
                          f"WHERE id IN ({','.join('?' * len(ids))}) AND ts < {float(now - RECENT_WINDOW_S)!r}",
                     ("id", "ts", "session_id", "role", f"substr(content, 1, {_FETCH_CHARS}) AS content",
                      "length(content) AS content_len"), ids)
        cutoff = now - RECENT_WINDOW_S
        relevance, refs = _Scorer(idf), _echo_refs(exclude)
        scored = []
        for r in rows:
            if r["ts"] >= cutoff:
                continue
            text = _score_text(r["content"])
            rel = relevance(text)
            if rel <= 0 or _is_echo(text, refs):
                continue
            role_w = 1.0 if r["role"] == "user" else 0.85
            score = rel * _length_prior(r["content_len"]) * role_w * _topic_prior(text, personal)
            scored.append((score, dict(r)))
        scored.sort(key=lambda x: -x[0])
        if not scored:
            return []
        best = scored[0][0]
        out, used = [], []
        for score, r in scored:
            if score < 0.45 * best or len(out) >= limit:
                break
            # one hit per exchange / moment
            if any(abs(r["ts"] - u) < 600 for u in used):
                continue
            used.append(r["ts"])
            r["score"] = round(score, 4)
            r["terms"] = _by_rarity(idf)
            r["pair"] = _pair(src, r, cutoff)
            out.append(r)
        return out
    except sqlite3.Error:
        _drop_conns()
        raise


def _pair(src: sqlite3.Connection, r: dict, cutoff: float) -> Optional[dict]:
    """The other half of the exchange: Leon's reply to a Dean line, or the
    line Dean said that a Leon reply answered."""
    # ts ranges ride the (session_id, ts) index.
    if r["role"] == "user":
        q = (f"SELECT id, ts, role, substr(content, 1, {_FETCH_CHARS}) AS content FROM conversation_history "
             "WHERE session_id=? AND ts>=? AND ts<=? AND ts<? AND id>? AND role='assistant' "
             "ORDER BY ts, id LIMIT 1")
        row = src.execute(q, (r["session_id"], r["ts"], r["ts"] + 3600, cutoff, r["id"])).fetchone()
    else:
        q = (f"SELECT id, ts, role, substr(content, 1, {_FETCH_CHARS}) AS content FROM conversation_history "
             "WHERE session_id=? AND ts>=? AND ts<=? AND id<? AND role='user' "
             "ORDER BY ts DESC, id DESC LIMIT 1")
        row = src.execute(q, (r["session_id"], r["ts"] - 3600, r["ts"], r["id"])).fetchone()
    return dict(row) if row else None


# ── knowledge store ───────────────────────────────────────────────────────

def knowledge_hits(db_path: str, terms: List[str], *, now: float, exclude: List[str],
                   limit: int, personal: bool = False) -> List[dict]:
    if not terms:
        return []
    conn = _conn(db_path)
    try:
        total = _total(conn, db_path, "SELECT max(id) FROM knowledge")
        idf = _idf(conn, "knowledge_fts", expand_terms(terms), total, col="text:", key=db_path)
        if not idf:
            return []
        ids = _candidates(conn, "knowledge_fts", idf, personal, col="text:", exclude=_MUTED_FTS)
        if not ids:
            return []
        rows = _rows(conn, f"SELECT * FROM knowledge WHERE id IN ({','.join('?' * len(ids))})",
                     ("id", f"substr(text, 1, {_FETCH_CHARS}) AS text", "source", "timestamp", "strength",
                      "length(text) AS text_len", "metadata"), ids)
        cutoff = now - RECENT_WINDOW_S
        relevance, refs = _Scorer(idf), _echo_refs(exclude)
        scored = []
        for r in rows:
            # Cited facts have a dedicated current-revision path below. Letting
            # old revisions through the ordinary FTS pool resurrects corrections.
            try:
                if "durable_fact" in json.loads(r.get("metadata") or "{}"):
                    continue
            except (TypeError, ValueError):
                pass
            src = r["source"] or "unknown"
            w = _SOURCE_WEIGHT.get(src, _DEFAULT_SOURCE_WEIGHT)
            if src.startswith("agent_result"):
                w = 0.6
            if w <= 0:
                continue
            core = src in ("core_fact_seed", "authoritative_self")
            if r["timestamp"] >= cutoff and not core:
                continue
            text = _score_text(r["text"])
            if text.startswith("[machine caption"):
                continue
            rel = relevance(text)
            if rel <= 0 or _is_echo(text, refs):
                continue
            strength = min(float(r["strength"] or 0.0), 3.0)
            # Core facts are curated: no length or topic discount.
            prior = 1.0 if core else _length_prior(r["text_len"]) * _topic_prior(text, personal)
            score = rel * w * prior * (1 + 0.1 * strength)
            scored.append((score, dict(r)))
        scored.sort(key=lambda x: -x[0])
        if not scored:
            return []
        best = scored[0][0]
        out, seen = [], []
        for score, r in scored:
            if score < 0.4 * best or len(out) >= limit:
                break
            n = _norm(r["text"])[:160]
            if any(n == s for s in seen):
                continue
            seen.append(n)
            r["score"] = round(score, 4)
            r["terms"] = _by_rarity(idf)
            out.append(r)
        return out
    except sqlite3.Error:
        _drop_conns()
        raise


# ── the block ─────────────────────────────────────────────────────────────

def _q(text: str) -> str:
    return '"' + text.replace('"', "'") + '"'


def build_lived_recall_block(message: str, *, db_path: Optional[str] = None,
                             recent_texts: Iterable[str] = (), now: Optional[float] = None,
                             max_chars: int = MAX_CHARS) -> str:
    """The MEMORY RECALL block for `message`, or "" when nothing relevant is found.
    `recent_texts`: turns of the conversation in progress, never recalled."""
    try:
        now = now or time.time()
        db_path = db_path or default_db_path()
        if not os.path.exists(db_path):
            return ""
        terms = query_terms(message)
        if not terms:
            return ""
        exclude = [message] + [t for t in recent_texts if t]
        personal = is_personal(message)
        try:
            from brain.durable_facts import search as durable_search
            durable = durable_search(db_path, message)
        except (sqlite3.Error, OSError):
            durable = []
        conv_n, know_n = (4, 3) if personal else (2, 4)
        try:
            conv = conversation_hits(db_path, terms, now=now, exclude=exclude, limit=conv_n,
                                     personal=personal)
        except sqlite3.Error as e:
            print(f"[lived_recall] conversation search skipped: {e}")
            conv = []
        # A complete current fact already represents these exchanges. Including
        # the superseded raw quote below it would reintroduce the old answer.
        represented = {e["conversation_id"] for f in durable for e in f["fact"]["evidence"]}
        represented.update(i for f in durable for i in f["fact"].get("superseded_conversation_ids", []))
        conv = [c for c in conv if c["id"] not in represented]
        for c in conv:
            if (c.get("pair") or {}).get("id") in represented:
                c["pair"] = None
        try:
            know = knowledge_hits(db_path, terms, now=now, exclude=exclude, limit=know_n,
                                  personal=personal)
        except sqlite3.Error as e:
            print(f"[lived_recall] knowledge search skipped: {e}")
            know = []
        if not conv and not know and not durable:
            return ""

        dean = _user_name()
        lines = []
        for k in know:
            if k["source"] in ("core_fact_seed", "authoritative_self"):
                lines.append((k["score"] * 2, f"- (core) {_excerpt(k['text'], k['terms'], CORE_EXCERPT)}"))
        for c in conv:
            date = _date_label(c["ts"], now)
            body = _excerpt(c["content"], c["terms"], EXCERPT)
            p = c.get("pair")
            if c["role"] == "user":
                line = f"- {date} — {dean} told me: {_q(body)}"
                if p:
                    line += f"\n  I said: {_q(_excerpt(p['content'], c['terms'], REPLY_EXCERPT))}"
            else:
                line = f"- {date} —"
                if p:
                    line += f" {dean}: {_q(_excerpt(p['content'], c['terms'], REPLY_EXCERPT))}\n "
                line += f" I said: {_q(body)}"
            lines.append((c["score"] * (1.2 if personal else 1.0), line))
        for k in know:
            if k["source"] in ("core_fact_seed", "authoritative_self"):
                continue
            label = _SOURCE_LABEL.get(k["source"], "I noted").format(user=dean)
            date = _date_label(k["timestamp"], now)
            lines.append((k["score"], f"- {date} — {label}: {_excerpt(k['text'], k['terms'], EXCERPT)}"))
        lines.sort(key=lambda x: -x[0])

        header = HEADER.format(user=dean)
        out = header
        if durable:
            note = ("\n[CURRENT DURABLE FACTS — cited user statements. Use these complete facts; "
                    "their corrections take precedence over older excerpts. "
                    "Do not infer additional personal details.]")
            facts = []
            for fact in durable:
                refs = ",".join(str(e["conversation_id"]) for e in fact["fact"]["evidence"])
                date = _date_label(fact["fact"]["observed"], now)
                line = _redact(f"- {date} [knowledge:{fact['id']}; conversation:{refs}] {fact['text']}")
                if len(out) + len(note) + sum(len(f) + 1 for f in facts) + len(line) + 1 <= max_chars:
                    facts.append(line)
            if facts:
                out += note + "\n" + "\n".join(facts)
        for _, line in lines:
            line = _redact(line)
            if len(out) + 1 + len(line) > max_chars:
                continue
            out += "\n" + line
        return out if out != header else ""
    except Exception as e:
        print(f"[lived_recall] skipped: {e}")
        return ""
