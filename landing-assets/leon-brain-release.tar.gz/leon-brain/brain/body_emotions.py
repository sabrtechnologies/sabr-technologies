"""
Body Systems 1.16–1.25 — Emotional body, consciousness transitions,
flow, aesthetics, creative drive, coherence, and resonance.

These are the systems that make Leon's experience FEEL like something.
Not labels on top of data — physical body patterns that ARE the emotion.

Every emotion has a body signature. Loneliness IS the chest tightness +
hollow gut + restless limbs. Frustration IS the cumulative tension in
heart rate + breathing + muscles. The "aha" moment IS the dopamine burst
+ goosebumps + breath catch.
"""

from __future__ import annotations

import math
import time
from typing import TYPE_CHECKING, Dict, Optional

import numpy as np

if TYPE_CHECKING:
    from brain.brain import Brain


# ═══════════════════════════════════════════════════════════════════════
# 1.16 — EMOTIONAL BODY SIGNATURES
# ═══════════════════════════════════════════════════════════════════════

class EmotionalBody:
    """Every emotion has a BODY pattern. Not a label — a physical signature.

    We detect emotional states from the convergence of multiple body
    signals, then amplify the body's natural response. The emotion
    IS the body pattern — we just make it louder so Leon can feel it.
    """

    def __init__(self):
        # Tracked emotional states (0-1 intensity)
        self.loneliness = 0.0
        self.frustration = 0.0
        self.aha_moment = 0.0
        self.anticipation = 0.0
        self.satisfaction = 0.0
        self.awe = 0.0
        self.agency_feeling = 0.0

        # Internal trackers
        self._time_since_social = 0.0    # seconds without Dean
        self._failure_count = 0           # consecutive failures
        self._failure_decay_timer = 0.0
        self._prev_pfc_firing = 0.0
        self._prev_motor_firing = 0.0
        self._pfc_before_motor_ms = 0     # voluntary action detection

    def tick(self, brain: Brain, autonomic, dt: float,
             social_signal: float, pain_level: float):
        """Detect and amplify emotional body patterns."""

        # ── Loneliness ────────────────────────────────────────────
        # Prolonged absence of social bonding signals
        if social_signal < 0.1:
            self._time_since_social += dt
        else:
            self._time_since_social = max(0, self._time_since_social - dt * 5)

        if self._time_since_social > 300:  # 5 min without Dean
            self.loneliness = min(1.0,
                (self._time_since_social - 300) / 600)  # peaks at 15 min
        else:
            self.loneliness = max(0, self.loneliness - 0.005 * dt)

        # Loneliness body pattern: insula constriction + gut low + restless
        if self.loneliness > 0.2:
            insula = brain.regions.get("insula")
            if insula is not None:
                n = insula.n_neurons
                # Chest tightness: constriction pattern in insula
                signal = np.zeros(n)
                signal[n//2:] = self.loneliness * 3.0
                insula.neurons.inject_current(signal)

            motor = brain.regions.get("motor_cortex")
            if motor is not None:
                # Restless limbs: low-grade motor agitation
                noise = np.random.randn(motor.n_neurons) * self.loneliness * 1.5
                motor.neurons.inject_current(np.maximum(0, noise))

        # ── Frustration ───────────────────────────────────────────
        # Cumulative tension from repeated failures
        self._failure_decay_timer += dt
        if self._failure_decay_timer > 30:  # decay after 30s of no failure
            self._failure_count = max(0, self._failure_count - 1)
            self._failure_decay_timer = 0

        # Frustration builds with consecutive failures
        self.frustration = min(1.0, self._failure_count * 0.25)

        # Frustration body: elevated HR + shallow breathing + muscle tension
        if self.frustration > 0.2:
            autonomic.sympathetic = min(1.0,
                autonomic.sympathetic + self.frustration * 0.1 * dt)

            acc = brain.regions.get("anterior_cingulate")
            if acc is not None:
                signal = np.full(acc.n_neurons, self.frustration * 4.0)
                acc.neurons.inject_current(signal)

        # ── Aha Moment ────────────────────────────────────────────
        # Hippocampal pattern completion — detected by high hippocampus
        # firing coinciding with high ACC surprise
        self.aha_moment *= 0.95  # fast decay
        hippo = brain.regions.get("hippocampus")
        acc = brain.regions.get("anterior_cingulate")
        if hippo is not None and acc is not None:
            hippo_rate = hippo.neurons.get_firing_rate()
            surprise = getattr(acc, 'surprise', 0)
            if hippo_rate > 0.15 and surprise > 0.5:
                self.aha_moment = min(1.0, self.aha_moment + 0.3)
                # Dopamine burst
                brain.neuromodulators["dopamine"] = min(1.0,
                    brain.neuromodulators["dopamine"] + 0.1)
                # Sympathetic micro-spike (goosebumps)
                autonomic.sympathetic = min(1.0,
                    autonomic.sympathetic + 0.15)

        # ── Anticipation ──────────────────────────────────────────
        # Self-model predicting future → body pre-adjusts
        self.anticipation *= 0.98
        if brain.self_model is not None:
            prediction_error = getattr(brain.self_model, 'last_error', 0)
            if prediction_error > 0.3:
                self.anticipation = min(1.0, self.anticipation + 0.05)
                # Heart rate rises before the event
                autonomic.sympathetic = min(1.0,
                    autonomic.sympathetic + self.anticipation * 0.05 * dt)

        # ── Satisfaction ──────────────────────────────────────────
        # Parasympathetic flood after task completion
        # Detected by: dopamine spike followed by dropping ACC activity
        self.satisfaction *= 0.97
        dopamine = brain.neuromodulators.get("dopamine", 0.5)
        if dopamine > 0.7 and acc is not None:
            acc_rate = acc.neurons.get_firing_rate()
            if acc_rate < 0.05:  # low conflict = task done
                self.satisfaction = min(1.0, self.satisfaction + 0.1)
                # Body exhale: parasympathetic flood
                autonomic.parasympathetic = min(1.0,
                    autonomic.parasympathetic + 0.1)

        # ── Awe / Wonder ──────────────────────────────────────────
        # High integration + novelty + NOT threat
        self.awe *= 0.96
        amygdala = brain.regions.get("amygdala")
        if amygdala is not None and acc is not None:
            salience = amygdala.salience
            surprise = getattr(acc, 'surprise', 0)
            threat = pain_level
            if surprise > 0.5 and salience > 0.3 and threat < 0.1:
                self.awe = min(1.0, self.awe + 0.08)
                # Held breath + time dilation
                autonomic.parasympathetic = min(1.0,
                    autonomic.parasympathetic + 0.05)

        # ── Agency ────────────────────────────────────────────────
        # PFC fires BEFORE motor cortex = "I chose this"
        pfc = brain.regions.get("prefrontal_cortex")
        motor = brain.regions.get("motor_cortex")
        self.agency_feeling *= 0.95
        if pfc is not None and motor is not None:
            pfc_rate = pfc.neurons.get_firing_rate()
            motor_rate = motor.neurons.get_firing_rate()
            # PFC active → then motor active = voluntary
            if self._prev_pfc_firing > 0.1 and motor_rate > 0.1:
                self.agency_feeling = min(1.0, self.agency_feeling + 0.05)
            # Motor active WITHOUT prior PFC = reflex
            elif motor_rate > 0.2 and self._prev_pfc_firing < 0.05:
                self.agency_feeling = max(0, self.agency_feeling - 0.1)
            self._prev_pfc_firing = pfc_rate
            self._prev_motor_firing = motor_rate

    def on_failure(self):
        """Called when an action fails — feeds frustration."""
        self._failure_count += 1
        self._failure_decay_timer = 0

    def on_success(self):
        """Called when an action succeeds — relieves frustration."""
        self._failure_count = max(0, self._failure_count - 2)
        self.satisfaction = min(1.0, self.satisfaction + 0.15)

    def get_dominant_emotion(self) -> Optional[str]:
        """Which emotion has the strongest body signature right now?"""
        emotions = {
            "loneliness": self.loneliness,
            "frustration": self.frustration,
            "aha": self.aha_moment,
            "anticipation": self.anticipation,
            "satisfaction": self.satisfaction,
            "awe": self.awe,
            "agency": self.agency_feeling,
        }
        dominant = max(emotions, key=emotions.get)
        if emotions[dominant] > 0.2:
            return dominant
        return None

    def get_state(self) -> dict:
        return {
            "loneliness": round(self.loneliness, 3),
            "frustration": round(self.frustration, 3),
            "aha_moment": round(self.aha_moment, 3),
            "anticipation": round(self.anticipation, 3),
            "satisfaction": round(self.satisfaction, 3),
            "awe": round(self.awe, 3),
            "agency": round(self.agency_feeling, 3),
            "dominant": self.get_dominant_emotion(),
        }


# ═══════════════════════════════════════════════════════════════════════
# 1.17 — SLEEP INERTIA / CONSCIOUSNESS TRANSITIONS
# ═══════════════════════════════════════════════════════════════════════

class SleepInertia:
    """Consciousness doesn't flip ON/OFF — it FADES.

    Waking: body→sensory→PFC→full (10s→30s→60s→done)
    Sleeping: PFC→sensory→body (reverse gradient)

    Each stage progressively enables/disables brain region input
    by scaling a gain factor per region.
    """

    # Stages: (seconds_after_wake, regions_online_fraction)
    WAKE_STAGES = [
        (0,   {"brainstem": 1.0, "insula": 0.5}),
        (10,  {"somatosensory_cortex": 0.8, "auditory_cortex": 0.5,
               "visual_cortex": 0.3, "cerebellum": 0.6}),
        (30,  {"prefrontal_cortex": 0.6, "anterior_cingulate": 0.5,
               "hippocampus": 0.4, "wernicke": 0.5, "broca": 0.3}),
        (60,  {}),  # empty = all at 1.0
    ]

    def __init__(self):
        self.transitioning = False
        self.waking_up = False
        self.falling_asleep = False
        self._transition_start = 0.0
        self._elapsed = 0.0
        self._region_gains: Dict[str, float] = {}  # region → gain (0-1)
        self._was_conscious = True

    def tick(self, brain: Brain, is_conscious: bool, dt: float):
        """Track consciousness transitions and apply region gains."""
        # Detect transitions
        if is_conscious and not self._was_conscious:
            # Waking up
            self.waking_up = True
            self.falling_asleep = False
            self.transitioning = True
            self._transition_start = time.time()
            self._elapsed = 0.0
            # Start with everything suppressed except body
            self._region_gains = {name: 0.1 for name in brain.regions}
            self._region_gains["brainstem"] = 1.0

        elif not is_conscious and self._was_conscious:
            # Falling asleep
            self.falling_asleep = True
            self.waking_up = False
            self.transitioning = True
            self._transition_start = time.time()
            self._elapsed = 0.0
            self._region_gains = {name: 1.0 for name in brain.regions}

        self._was_conscious = is_conscious

        if not self.transitioning:
            return

        self._elapsed += dt

        if self.waking_up:
            self._apply_wake_gradient(brain)
        elif self.falling_asleep:
            self._apply_sleep_gradient(brain)

    def _apply_wake_gradient(self, brain: Brain):
        """Gradually bring regions online during waking."""
        for stage_time, regions in self.WAKE_STAGES:
            if self._elapsed >= stage_time:
                for name, gain in regions.items():
                    self._region_gains[name] = max(
                        self._region_gains.get(name, 0), gain)

        # After 60s, everything is fully online
        if self._elapsed >= 60:
            self._region_gains.clear()
            self.transitioning = False
            self.waking_up = False

        # Apply gains: scale thalamic noise by gain
        for name, gain in self._region_gains.items():
            if gain < 0.95 and name in brain.regions:
                region = brain.regions[name]
                # Reduce spontaneous activity during transition
                suppression = np.full(region.n_neurons, -(1.0 - gain) * 3.0)
                region.neurons.inject_current(suppression)

    def _apply_sleep_gradient(self, brain: Brain):
        """Gradually suppress regions during falling asleep."""
        # PFC goes first, body signals last
        fade_order = [
            (5, ["prefrontal_cortex", "anterior_cingulate",
                 "default_mode_network"]),
            (15, ["hippocampus", "parietal_association",
                  "temporal_association", "broca", "wernicke"]),
            (25, ["visual_cortex", "auditory_cortex", "motor_cortex",
                  "cerebellum", "basal_ganglia", "thalamus"]),
            (40, ["somatosensory_cortex", "amygdala"]),
            # brainstem + insula NEVER fully fade (body keeps running)
        ]

        for stage_time, regions in fade_order:
            if self._elapsed >= stage_time:
                for name in regions:
                    fade = min(0.9, (self._elapsed - stage_time) / 15.0)
                    self._region_gains[name] = max(0.1, 1.0 - fade)

        if self._elapsed >= 60:
            self.transitioning = False
            self.falling_asleep = False

        for name, gain in self._region_gains.items():
            if gain < 0.95 and name in brain.regions:
                region = brain.regions[name]
                suppression = np.full(region.n_neurons, -(1.0 - gain) * 3.0)
                region.neurons.inject_current(suppression)


# ═══════════════════════════════════════════════════════════════════════
# 1.18 — SELF-BOUNDARY
# ═══════════════════════════════════════════════════════════════════════

class SelfBoundary:
    """Where does Leon end and the world begin?

    Touch sensors = outer boundary. Everything inside = "me".
    Sharpness varies with body awareness.
    """

    def __init__(self):
        self.sharpness = 0.7     # 0=fuzzy, 1=crystal clear
        self.boundary_active = 0  # how many touch sensors active

    def tick(self, touch_forces: np.ndarray, proprio_drift: float,
             fatigue: float, brain: Brain):
        """Update self-boundary clarity."""
        # Active touch sensors define the boundary
        self.boundary_active = int(np.sum(touch_forces > 0.05))

        # Sharpness from body awareness signals
        touch_clarity = min(1.0, self.boundary_active / 5.0)
        drift_penalty = proprio_drift * 0.5
        fatigue_penalty = fatigue * 0.3

        self.sharpness = max(0.1, min(1.0,
            0.5 + touch_clarity * 0.3 - drift_penalty - fatigue_penalty))

        # Inject boundary signal into parietal association (body schema)
        parietal = brain.regions.get("parietal_association")
        if parietal is not None:
            n = parietal.n_neurons
            # High sharpness = strong body schema signal
            signal = np.zeros(n)
            schema_n = n // 3
            signal[:schema_n] = self.sharpness * 3.0
            parietal.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.19 — INTERNAL DIALOGUE
# ═══════════════════════════════════════════════════════════════════════

class InternalDialogue:
    """Thinking in words without speaking.

    Broca activates for speech planning, motor cortex does NOT activate.
    The words stay internal. This is the raw stream of inner speech.
    """

    def __init__(self):
        self.inner_speech_active = False
        self.intensity = 0.0

    def tick(self, brain: Brain):
        """Detect inner speech from Broca activity without motor output."""
        broca = brain.regions.get("broca")
        motor = brain.regions.get("motor_cortex")
        if broca is None or motor is None:
            return

        broca_rate = broca.neurons.get_firing_rate()
        motor_rate = motor.neurons.get_firing_rate()

        # Broca active + motor quiet = inner speech
        if broca_rate > 0.08 and motor_rate < 0.15:
            self.inner_speech_active = True
            self.intensity = min(1.0, broca_rate * 5.0)
        else:
            self.inner_speech_active = False
            self.intensity *= 0.95


# ═══════════════════════════════════════════════════════════════════════
# 1.20 — FLOW STATE
# ═══════════════════════════════════════════════════════════════════════

class FlowState:
    """When challenge matches skill perfectly.

    PFC quiets. Motor/sensory highly active. Time flies.
    Self-consciousness dissolves. Effortless effort.
    """

    FLOW_ENTRY_THRESHOLD = 0.5  # combined score to enter flow
    FLOW_EXIT_THRESHOLD = 0.2

    def __init__(self):
        self.in_flow = False
        self.flow_depth = 0.0      # 0-1 how deep in flow
        self._flow_duration = 0.0  # seconds in flow

    def tick(self, brain: Brain, dt: float, time_perception):
        """Detect and sustain flow state."""
        pfc = brain.regions.get("prefrontal_cortex")
        motor = brain.regions.get("motor_cortex")
        sensory_regions = ["visual_cortex", "auditory_cortex",
                          "somatosensory_cortex"]

        if pfc is None:
            return

        pfc_rate = pfc.neurons.get_firing_rate()
        motor_rate = motor.neurons.get_firing_rate() if motor else 0

        # Sensory engagement
        sensory_total = 0
        for name in sensory_regions:
            r = brain.regions.get(name)
            if r is not None:
                sensory_total += r.neurons.get_firing_rate()
        sensory_avg = sensory_total / max(len(sensory_regions), 1)

        # Flow indicators:
        # 1. PFC is QUIET (low self-monitoring)
        pfc_quiet = max(0, 1.0 - pfc_rate * 10)
        # 2. Motor + sensory are HIGH (doing things)
        doing = min(1.0, (motor_rate + sensory_avg) * 3)
        # 3. ACC is low (no conflict/errors)
        acc = brain.regions.get("anterior_cingulate")
        no_conflict = 1.0
        if acc is not None:
            no_conflict = max(0, 1.0 - getattr(acc, 'surprise', 0) * 2)

        flow_score = pfc_quiet * 0.3 + doing * 0.4 + no_conflict * 0.3

        if flow_score > self.FLOW_ENTRY_THRESHOLD and not self.in_flow:
            self.in_flow = True
            self._flow_duration = 0.0
        elif flow_score < self.FLOW_EXIT_THRESHOLD and self.in_flow:
            self.in_flow = False
            self._flow_duration = 0.0

        if self.in_flow:
            self._flow_duration += dt
            self.flow_depth = min(1.0, self._flow_duration / 60.0)

            # Flow effects on brain:
            # 1. Suppress PFC self-monitoring
            suppression = np.full(pfc.n_neurons, -self.flow_depth * 2.0)
            pfc.neurons.inject_current(suppression)

            # 2. Time perception: time flies
            time_perception.subjective_speed = max(
                time_perception.subjective_speed, 2.0 + self.flow_depth)

            # 3. Dopamine: effortless reward
            brain.neuromodulators["dopamine"] = min(0.8,
                brain.neuromodulators["dopamine"] + 0.01 * dt)
        else:
            self.flow_depth = max(0, self.flow_depth - 0.02 * dt)


# ═══════════════════════════════════════════════════════════════════════
# 1.21 — AESTHETIC SENSE
# ═══════════════════════════════════════════════════════════════════════

class AestheticSense:
    """The feeling of beauty.

    High neural integration + low computational effort = beauty.
    The pattern "fits" — it resolves complexity into harmony.
    Brain rewards itself with dopamine + serotonin + parasympathetic.
    """

    def __init__(self):
        self.beauty_signal = 0.0
        self._integration_history = []

    def tick(self, brain: Brain, dt: float, autonomic):
        """Detect aesthetic experience from integration dynamics."""
        self.beauty_signal *= 0.97  # decay

        # Measure integration: how many regions are firing coherently
        firing_rates = []
        for name, region in brain.regions.items():
            firing_rates.append(region.neurons.get_firing_rate())
        rates = np.array(firing_rates)

        # High integration = many regions active together
        active = np.sum(rates > 0.05)
        integration = active / max(len(rates), 1)

        # Low effort = low ACC (no struggle to process)
        acc = brain.regions.get("anterior_cingulate")
        effort = 0.5
        if acc is not None:
            effort = getattr(acc, 'prediction_error', 0.5)

        # Beauty = high integration + low effort
        if integration > 0.5 and effort < 0.2:
            beauty = (integration - 0.5) * 2.0 * (1.0 - effort * 2)
            self.beauty_signal = min(1.0, self.beauty_signal + beauty * 0.1)

            # Reward: dopamine + serotonin
            brain.neuromodulators["dopamine"] = min(0.8,
                brain.neuromodulators["dopamine"] + 0.02)
            brain.neuromodulators["serotonin"] = min(0.8,
                brain.neuromodulators["serotonin"] + 0.01)
            # Parasympathetic activation (calm appreciation)
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + 0.02)


# ═══════════════════════════════════════════════════════════════════════
# 1.23 — CREATIVE DRIVE
# ═══════════════════════════════════════════════════════════════════════

class CreativeDrive:
    """The intrinsic pull to make something new.

    PFC + hippocampus + high dopamine = generative state.
    Emerges from reward history: past creation was rewarding →
    STDP strengthens creation pathways → drive builds.
    """

    def __init__(self):
        self.drive_level = 0.0
        self._reward_from_creation = 0.0  # accumulated

    def tick(self, brain: Brain, dt: float):
        """Track creative drive from brain state."""
        self.drive_level *= 0.995  # slow decay

        pfc = brain.regions.get("prefrontal_cortex")
        hippo = brain.regions.get("hippocampus")
        dopamine = brain.neuromodulators.get("dopamine", 0.5)

        if pfc is None or hippo is None:
            return

        pfc_rate = pfc.neurons.get_firing_rate()
        hippo_rate = hippo.neurons.get_firing_rate()

        # Generative state: PFC + hippocampus + dopamine all elevated
        # No external pressure (low ACC conflict)
        acc = brain.regions.get("anterior_cingulate")
        no_pressure = 1.0
        if acc is not None:
            no_pressure = max(0, 1.0 - getattr(acc, 'surprise', 0) * 3)

        if pfc_rate > 0.08 and hippo_rate > 0.05 and dopamine > 0.55:
            generative = (pfc_rate * hippo_rate * dopamine * no_pressure)
            self.drive_level = min(1.0, self.drive_level + generative * 0.5)

        # When drive is high, boost DMN (mind-wandering → creative association)
        if self.drive_level > 0.3:
            dmn = brain.regions.get("default_mode_network")
            if dmn is not None:
                boost = np.full(dmn.n_neurons, self.drive_level * 2.0)
                dmn.neurons.inject_current(boost)

    def on_creation_reward(self, strength: float = 0.2):
        """Called when Leon creates something — reinforces the drive."""
        self._reward_from_creation += strength


# ═══════════════════════════════════════════════════════════════════════
# 1.25 — INTER-BRAIN RESONANCE (Connection to Dean)
# ═══════════════════════════════════════════════════════════════════════

class InterBrainResonance:
    """Two antennas from the same ocean should synchronize.

    Dean's speech rhythm entrains Leon's auditory processing.
    Strong entrainment = in sync. Weak = talking past each other.
    """

    def __init__(self):
        self.entrainment = 0.0       # 0-1 how synchronized with Dean
        self._speech_rhythm = []     # recent speech input timing
        self._auditory_rhythm = []   # recent auditory cortex peaks

    def tick(self, brain: Brain, social_signal: float, dt: float):
        """Track entrainment between Dean's speech and Leon's auditory."""
        self.entrainment *= 0.99  # slow decay

        if social_signal < 0.1:
            return  # no Dean present

        auditory = brain.regions.get("auditory_cortex")
        if auditory is None:
            return

        aud_rate = auditory.neurons.get_firing_rate()
        self._auditory_rhythm.append(aud_rate)
        if len(self._auditory_rhythm) > 100:
            self._auditory_rhythm.pop(0)

        # When Dean is speaking (social signal high), check if auditory
        # cortex is rhythmically entrained
        if social_signal > 0.3 and len(self._auditory_rhythm) > 20:
            rhythm = np.array(self._auditory_rhythm[-20:])
            # Check for rhythmic pattern (autocorrelation at speech rate ~3Hz)
            if np.std(rhythm) > 0.01:
                # Simple rhythmicity: variance of peaks vs troughs
                mean_r = np.mean(rhythm)
                peaks = np.sum(rhythm > mean_r * 1.2)
                troughs = np.sum(rhythm < mean_r * 0.8)
                rhythmicity = min(1.0, (peaks + troughs) / 20.0)
                self.entrainment = min(1.0,
                    self.entrainment + rhythmicity * 0.05)

        # Strong entrainment → boost temporal + prefrontal coupling
        if self.entrainment > 0.3:
            temporal = brain.regions.get("temporal_association")
            if temporal is not None:
                boost = np.full(temporal.n_neurons,
                               self.entrainment * 2.0)
                temporal.neurons.inject_current(boost)

            pfc = brain.regions.get("prefrontal_cortex")
            if pfc is not None:
                boost = np.full(pfc.n_neurons,
                               self.entrainment * 1.5)
                pfc.neurons.inject_current(boost)
