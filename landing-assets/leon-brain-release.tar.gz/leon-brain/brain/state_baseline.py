"""
State baselines — every prompt state line is judged against the signal's
OWN recent history, not a fixed absolute number.

Why this exists (selfstudy audit, 2026-10-04): most of the per-turn state
text was pinned. Fixed thresholds sat where the network never goes (mean
firing never reached the 0.08 / 0.1 "quiet" cut-offs, PFC never reached
0.15, DMN never 0.08) or right on top of the resting level (dopamine
hovers at 0.70, so "excited" flipped ~157 times an hour on noise).

What this module does:
  * Baseline — an EMA-smoothed copy of one signal plus a rolling 24 h
    sample of that smoothed value. ``percentile()`` says where the current
    value sits in its own last day (0 = lowest, 1 = highest).
  * Flag — hysteresis on that percentile: it switches on above ``on`` and
    only switches off below ``off``. Both switches need the condition held
    for ``confirm_s`` and at least ``min_dwell_s`` since the last switch,
    so noise around a threshold can't make the text flicker.
  * LeaderTracker — the "dominant lobe" with the same hysteresis.
  * StateRegistry — samples the live brain (called from the body's slow
    tick), owns the baselines/flags, and persists them to
    brain_state/state_baselines.json so a restart keeps its sense of
    "normal". Before a signal has enough history of its own, a shipped
    seed (quantiles from the audited 5-day logs) stands in.

Nothing here writes to the brain. It only reads.
"""

from __future__ import annotations

import bisect
import json
import logging
import math
import os
import threading
import time
from collections import deque
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

log = logging.getLogger("leon.state_baseline")

_HERE = os.path.dirname(os.path.abspath(__file__))
_STATE_DIR = os.path.join(os.path.dirname(_HERE), "brain_state")
_SEED_PATH = os.path.join(_HERE, "state_baseline_seed.json")

WINDOW_S = 24 * 3600.0       # "normal" = the last 24 h
SAMPLE_EVERY_S = 90.0        # one stored (smoothed) sample per 90 s → 960/day
OWN_ONLY_AFTER = 240         # ~6 h of own samples → stop blending in the seed
MIN_OWN_SAMPLES = 40         # ~1 h of own samples before trusting them without a seed
DEFAULT_TAU_S = 120.0        # EMA time constant
SAVE_EVERY_S = 300.0
SAMPLE_MIN_INTERVAL_S = 2.0  # the body's slow tick can be faster than this

LOBES: Dict[str, List[str]] = {
    "frontal":     ["prefrontal_cortex", "anterior_cingulate", "motor_cortex", "broca"],
    "parietal":    ["parietal_association", "somatosensory_cortex"],
    "temporal":    ["temporal_association", "auditory_cortex", "wernicke"],
    "occipital":   ["visual_cortex"],
    "limbic":      ["hippocampus", "amygdala", "insula"],
    "subcortical": ["thalamus", "basal_ganglia", "default_mode_network"],
    "hindbrain":   ["cerebellum", "brainstem"],
}


def _finite(x: Any) -> Optional[float]:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


# ═══════════════════════════════════════════════════════════════════
# Baseline
# ═══════════════════════════════════════════════════════════════════

class Baseline:
    """EMA of one signal + a rolling window of that EMA."""

    def __init__(self, name: str, tau_s: float = DEFAULT_TAU_S,
                 window_s: float = WINDOW_S, sample_every_s: float = SAMPLE_EVERY_S,
                 seed: Optional[List[float]] = None):
        self.name = name
        self.tau_s = float(tau_s)
        self.window_s = float(window_s)
        self.sample_every_s = float(sample_every_s)
        self.ema: Optional[float] = None
        self.last_raw: Optional[float] = None
        self._last_t: Optional[float] = None
        self._last_store_t = -1e18
        self.samples: deque = deque()          # (t, value)
        self.seed: List[float] = sorted(seed) if seed else []
        self._ref_cache: Optional[List[float]] = None

    # ── input ──────────────────────────────────────────────────────
    def observe(self, value: Any, now: float) -> Optional[float]:
        v = _finite(value)
        if v is None:
            return self.ema
        self.last_raw = v
        if self.ema is None or self._last_t is None:
            self.ema = v
        else:
            dt = max(0.0, now - self._last_t)
            a = 1.0 - math.exp(-dt / self.tau_s) if self.tau_s > 0 else 1.0
            self.ema += a * (v - self.ema)
        self._last_t = now
        if now - self._last_store_t >= self.sample_every_s:
            self.samples.append((now, self.ema))
            self._last_store_t = now
            cutoff = now - self.window_s
            while self.samples and self.samples[0][0] < cutoff:
                self.samples.popleft()
            self._ref_cache = None
        return self.ema

    # ── reference distribution ─────────────────────────────────────
    def own_count(self) -> int:
        return len(self.samples)

    def reference(self) -> List[float]:
        if self._ref_cache is not None:
            return self._ref_cache
        own = [v for _, v in self.samples]
        if len(own) >= OWN_ONLY_AFTER or (len(own) >= MIN_OWN_SAMPLES and not self.seed):
            ref = sorted(own)
        elif self.seed:
            ref = sorted(own + self.seed)
        else:
            ref = []
        self._ref_cache = ref
        return ref

    def degenerate(self) -> bool:
        """True when the signal doesn't vary — a constant has no 'high'."""
        ref = self.reference()
        if len(ref) < 10:
            return True
        lo = ref[int(0.05 * (len(ref) - 1))]
        hi = ref[int(0.95 * (len(ref) - 1))]
        scale = max(abs(lo), abs(hi), 1e-9)
        return (hi - lo) <= 1e-6 or (hi - lo) / scale < 1e-3

    def percentile(self, value: Optional[float] = None) -> Optional[float]:
        """Mid-rank of value (default: current EMA) in the reference, 0..1."""
        v = self.ema if value is None else _finite(value)
        if v is None:
            return None
        ref = self.reference()
        if not ref or self.degenerate():
            return None
        lo = bisect.bisect_left(ref, v)
        hi = bisect.bisect_right(ref, v)
        return ((lo + hi) / 2.0) / len(ref)

    def quantile(self, q: float) -> Optional[float]:
        ref = self.reference()
        if not ref:
            return None
        return ref[int(max(0.0, min(1.0, q)) * (len(ref) - 1))]

    # ── persistence ────────────────────────────────────────────────
    def to_dict(self) -> Dict[str, Any]:
        return {
            "ema": self.ema,
            "t": self._last_t,
            "samples": [[round(t, 1), round(v, 6)] for t, v in self.samples],
        }

    def load_dict(self, d: Dict[str, Any], now: float) -> None:
        cutoff = now - self.window_s
        self.samples = deque((float(t), float(v)) for t, v in d.get("samples", [])
                             if _finite(t) is not None and _finite(v) is not None
                             and float(t) >= cutoff and float(t) <= now + 60)
        if self.samples:
            self._last_store_t = self.samples[-1][0]
        t = _finite(d.get("t"))
        ema = _finite(d.get("ema"))
        # A smoothed value is only worth keeping if it is recent.
        if t is not None and ema is not None and 0 <= now - t < 10 * self.tau_s:
            self.ema, self._last_t = ema, t
        self._ref_cache = None


# ═══════════════════════════════════════════════════════════════════
# Flag (hysteresis + persistence + minimum dwell)
# ═══════════════════════════════════════════════════════════════════

class Flag:
    """On above ``on``, off below ``off`` (on > off), with debounce.

    ``direction='low'`` mirrors it: on below ``on``, off above ``off``.
    """

    def __init__(self, on: float, off: float, direction: str = "high",
                 confirm_s: float = 60.0, min_dwell_s: float = 300.0):
        if direction not in ("high", "low"):
            raise ValueError("direction must be 'high' or 'low'")
        if direction == "high" and not on > off:
            raise ValueError("high flag needs on > off")
        if direction == "low" and not on < off:
            raise ValueError("low flag needs on < off")
        self.on_at, self.off_at, self.direction = float(on), float(off), direction
        self.confirm_s, self.min_dwell_s = float(confirm_s), float(min_dwell_s)
        self.state = False
        self.since = -1e18          # time of last switch
        self._pending_since: Optional[float] = None
        self.flips = 0

    def _wants_on(self, x: float) -> bool:
        return x >= self.on_at if self.direction == "high" else x <= self.on_at

    def _wants_off(self, x: float) -> bool:
        return x <= self.off_at if self.direction == "high" else x >= self.off_at

    def update(self, x: Optional[float], now: float) -> bool:
        if x is None:
            # No trustworthy reading → don't claim anything new.
            self._pending_since = None
            if self.state and now - self.since >= self.min_dwell_s:
                self._switch(False, now)
            return self.state
        want_switch = self._wants_off(x) if self.state else self._wants_on(x)
        if not want_switch:
            self._pending_since = None
            return self.state
        if self._pending_since is None:
            self._pending_since = now
        if (now - self._pending_since >= self.confirm_s
                and now - self.since >= self.min_dwell_s):
            self._switch(not self.state, now)
        return self.state

    def _switch(self, state: bool, now: float) -> None:
        self.state = state
        self.since = now
        self._pending_since = None
        self.flips += 1

    def to_dict(self) -> Dict[str, Any]:
        return {"state": self.state, "since": self.since}

    def load_dict(self, d: Dict[str, Any], now: float) -> None:
        since = _finite(d.get("since"))
        # Restore the dwell clock either way; restore "on" only if it was
        # switched on recently — after a long gap the next readings decide.
        if since is not None and 0 <= now - since:
            self.since = since
            self.state = bool(d.get("state")) and now - since < 3600


class LeaderTracker:
    """argmax over named scores, but a challenger must lead by ``margin``
    for ``confirm_s`` and the current leader must have held ``min_dwell_s``."""

    def __init__(self, margin: float = 0.1, confirm_s: float = 60.0,
                 min_dwell_s: float = 300.0):
        self.margin, self.confirm_s, self.min_dwell_s = margin, confirm_s, min_dwell_s
        self.leader: Optional[str] = None
        self.since = -1e18
        self._challenger: Optional[str] = None
        self._challenger_since = 0.0
        self.flips = 0

    def update(self, scores: Dict[str, float], now: float) -> Optional[str]:
        scores = {k: v for k, v in scores.items() if v is not None}
        if not scores:
            return self.leader
        best = max(scores, key=scores.get)
        if self.leader is None or self.leader not in scores:
            self.leader, self.since = best, now
            self._challenger = None
            return self.leader
        if best == self.leader or scores[best] < scores[self.leader] + self.margin:
            self._challenger = None
            return self.leader
        if self._challenger != best:
            self._challenger, self._challenger_since = best, now
        if (now - self._challenger_since >= self.confirm_s
                and now - self.since >= self.min_dwell_s):
            self.leader, self.since = best, now
            self._challenger = None
            self.flips += 1
        return self.leader


# ═══════════════════════════════════════════════════════════════════
# Flag table — which line depends on which signal, and where it switches
# ═══════════════════════════════════════════════════════════════════
#
# name: (signal, direction, on-percentile, off-percentile)
# "high" lines turn on in the top ~12% of the signal's own day and stay on
# until it drops back below ~70%; "low" lines mirror that.
FLAG_SPECS: Dict[str, Tuple[str, str, float, float]] = {
    "dopamine_high":     ("dopamine", "high", 0.88, 0.70),
    "dopamine_low":      ("dopamine", "low", 0.12, 0.30),
    "serotonin_high":    ("serotonin", "high", 0.88, 0.70),
    "serotonin_low":     ("serotonin", "low", 0.12, 0.30),
    "ach_high":          ("acetylcholine", "high", 0.88, 0.70),
    "ach_low":           ("acetylcholine", "low", 0.12, 0.30),
    "pfc_high":          ("rate:prefrontal_cortex", "high", 0.90, 0.70),
    "dmn_high":          ("rate:default_mode_network", "high", 0.90, 0.70),
    "hippocampus_high":  ("rate:hippocampus", "high", 0.92, 0.75),
    "broca_high":        ("rate:broca", "high", 0.85, 0.65),
    "amygdala_high":     ("amygdala_salience", "high", 0.92, 0.75),
    "acc_conflict":      ("acc_conflict", "high", 0.92, 0.75),
    "quiet":             ("mean_rate", "low", 0.20, 0.40),
    "integration_high":  ("pci", "high", 0.88, 0.70),
    "integration_low":   ("pci", "low", 0.10, 0.30),
    "self_surprise":     ("self_surprise", "high", 0.90, 0.70),
    "flow":              ("flow_score", "high", 0.90, 0.70),
}

# Signals that are pure noise on one tick get a slower EMA.
TAU_S: Dict[str, float] = {
    "dopamine": 180.0, "serotonin": 180.0, "acetylcholine": 180.0,
    "norepinephrine": 180.0, "pci": 300.0, "rtd_ratio": 180.0,
}


def _load_seed(path: str = _SEED_PATH) -> Dict[str, List[float]]:
    try:
        with open(path) as f:
            d = json.load(f)
        return {k: [float(x) for x in v] for k, v in d.get("quantiles", {}).items()}
    except Exception:
        return {}


class StateRegistry:
    """All baselines and flags. One per process (see get_registry())."""

    def __init__(self, state_path: Optional[str] = None,
                 seed: Optional[Dict[str, List[float]]] = None,
                 confirm_s: float = 60.0, min_dwell_s: float = 300.0,
                 persist: bool = True):
        self.state_path = state_path or os.path.join(_STATE_DIR, "state_baselines.json")
        self.seed = _load_seed() if seed is None else seed
        self.persist = persist
        self._lock = threading.RLock()
        self.baselines: Dict[str, Baseline] = {}
        self.flags: Dict[str, Flag] = {
            name: Flag(on, off, direction, confirm_s=confirm_s, min_dwell_s=min_dwell_s)
            for name, (_sig, direction, on, off) in FLAG_SPECS.items()
        }
        self.lobe = LeaderTracker(margin=0.1, confirm_s=confirm_s, min_dwell_s=min_dwell_s)
        self._last_sample_t = -1e18
        self._last_save_t = time.time()
        self._loaded = False

    # ── baselines ──────────────────────────────────────────────────
    def baseline(self, name: str) -> Baseline:
        b = self.baselines.get(name)
        if b is None:
            b = Baseline(name, tau_s=TAU_S.get(name, DEFAULT_TAU_S),
                         seed=self.seed.get(name))
            self.baselines[name] = b
        return b

    def observe(self, name: str, value: Any, now: float) -> None:
        with self._lock:
            self.baseline(name).observe(value, now)

    def observe_many(self, values: Dict[str, Any], now: Optional[float] = None) -> None:
        now = time.time() if now is None else now
        with self._lock:
            for k, v in values.items():
                self.baseline(k).observe(v, now)
            self._update_flags(now)

    def _update_flags(self, now: float) -> None:
        for name, (sig, _d, _on, _off) in FLAG_SPECS.items():
            b = self.baselines.get(sig)
            self.flags[name].update(b.percentile() if b is not None else None, now)
        scores = {}
        for lobe, regs in LOBES.items():
            ps = [self.baselines[f"rate:{r}"].percentile()
                  for r in regs if f"rate:{r}" in self.baselines]
            ps = [p for p in ps if p is not None]
            if ps:
                scores[lobe] = sum(ps) / len(ps)
        self.lobe.update(scores, now)

    # ── readers (safe from any thread) ─────────────────────────────
    def pct(self, name: str) -> Optional[float]:
        with self._lock:
            b = self.baselines.get(name)
            return b.percentile() if b is not None else None

    def value(self, name: str) -> Optional[float]:
        b = self.baselines.get(name)
        return b.ema if b is not None else None

    def flag(self, name: str) -> bool:
        f = self.flags.get(name)
        return bool(f.state) if f is not None else False

    def flag_age_s(self, name: str, now: Optional[float] = None) -> Optional[float]:
        f = self.flags.get(name)
        if f is None or f.since < 0:
            return None
        return (time.time() if now is None else now) - f.since

    def dominant_lobe(self) -> Optional[str]:
        return self.lobe.leader

    def top_regions(self, n: int = 3, min_pct: float = 0.75) -> List[Tuple[str, float]]:
        with self._lock:
            out = []
            for name, b in self.baselines.items():
                if name.startswith("rate:"):
                    p = b.percentile()
                    if p is not None and p >= min_pct:
                        out.append((name[5:], p))
        out.sort(key=lambda kv: kv[1], reverse=True)
        return out[:n]

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            pct = {}
            for name, b in self.baselines.items():
                if name.startswith("rate:"):
                    continue
                p = b.percentile()
                pct[name] = None if p is None else round(p, 3)
            return {
                "flags": {k: f.state for k, f in self.flags.items()},
                "pct": pct,
                "lobe": self.lobe.leader,
            }

    # ── live sampling ──────────────────────────────────────────────
    def sample_brain(self, brain: Any, body: Any = None,
                     now: Optional[float] = None) -> bool:
        """Read the live network into the baselines. Cheap; rate-limited."""
        now = time.time() if now is None else now
        if now - self._last_sample_t < SAMPLE_MIN_INTERVAL_S:
            return False
        self._last_sample_t = now
        self.ensure_loaded(now)
        try:
            values = extract_signals(brain, body)
        except Exception as e:  # never let a reader break the body tick
            log.debug("state sample failed: %s", e)
            return False
        self.observe_many(values, now)
        if self.persist and now - self._last_save_t >= SAVE_EVERY_S:
            self.save(now)
        return True

    # ── persistence ────────────────────────────────────────────────
    def ensure_loaded(self, now: Optional[float] = None) -> None:
        if self._loaded:
            return
        self._loaded = True
        if not self.persist:
            return
        now = time.time() if now is None else now
        try:
            with open(self.state_path) as f:
                d = json.load(f)
        except FileNotFoundError:
            return
        except Exception as e:
            log.warning("state_baselines.json unreadable (%s) — starting fresh", e)
            return
        with self._lock:
            for name, bd in (d.get("baselines") or {}).items():
                try:
                    self.baseline(name).load_dict(bd, now)
                except Exception:
                    pass
            for name, fd in (d.get("flags") or {}).items():
                if name in self.flags:
                    try:
                        self.flags[name].load_dict(fd, now)
                    except Exception:
                        pass

    def save(self, now: Optional[float] = None) -> None:
        now = time.time() if now is None else now
        self._last_save_t = now
        with self._lock:
            d = {
                "version": 1,
                "saved_ts": now,
                "baselines": {k: b.to_dict() for k, b in self.baselines.items()},
                "flags": {k: f.to_dict() for k, f in self.flags.items()},
            }
        try:
            os.makedirs(os.path.dirname(self.state_path), exist_ok=True)
            tmp = self.state_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(d, f, separators=(",", ":"))
            os.replace(tmp, self.state_path)
        except Exception as e:
            log.debug("state_baselines save failed: %s", e)


def extract_signals(brain: Any, body: Any = None) -> Dict[str, float]:
    """The raw readings every baseline is built from."""
    out: Dict[str, float] = {}
    nm = getattr(brain, "neuromodulators", None) or {}
    for k in ("dopamine", "serotonin", "acetylcholine", "norepinephrine"):
        v = _finite(nm.get(k)) if hasattr(nm, "get") else None
        if v is not None:
            out[k] = v
    regions = getattr(brain, "regions", None) or {}
    rates = []
    for name, region in list(regions.items()):
        neurons = getattr(region, "neurons", None)
        if neurons is None:
            continue
        try:
            r = _finite(neurons.get_firing_rate())
        except Exception:
            r = None
        if r is not None:
            out[f"rate:{name}"] = r
            rates.append(r)
    if rates:
        out["mean_rate"] = sum(rates) / len(rates)
    amy = regions.get("amygdala") if hasattr(regions, "get") else None
    if amy is not None:
        v = _finite(getattr(amy, "salience", None))
        if v is not None:
            out["amygdala_salience"] = v
    acc = regions.get("anterior_cingulate") if hasattr(regions, "get") else None
    if acc is not None:
        v = _finite(getattr(acc, "prediction_error", None))
        if v is not None:
            out["acc_conflict"] = v
    meter = getattr(brain, "consciousness_meter", None)
    if meter is not None:
        pci = _finite(getattr(meter, "_last_pci", None))
        if pci is not None:
            out["pci"] = pci
        sig = _finite(getattr(meter, "_rtd_signal", None))
        theta = _finite(getattr(meter, "RTD_THETA", None))
        if sig is not None and theta:
            out["rtd_ratio"] = sig / theta
    sm = getattr(brain, "self_model", None)
    if sm is not None:
        v = _finite(getattr(sm, "_last_surprise_value", None))
        if v is not None:
            out["self_surprise"] = v
    if body is None:
        body = getattr(brain, "simulated_body", None)
    fs = getattr(body, "flow_state", None) if body is not None else None
    if fs is not None:
        v = _finite(getattr(fs, "last_score", None))
        if v is not None:
            out["flow_score"] = v
    return out


_REGISTRY: Optional[StateRegistry] = None
_REGISTRY_LOCK = threading.Lock()


def get_registry() -> StateRegistry:
    global _REGISTRY
    if _REGISTRY is None:
        with _REGISTRY_LOCK:
            if _REGISTRY is None:
                _REGISTRY = StateRegistry()
    return _REGISTRY


def set_registry(reg: Optional[StateRegistry]) -> None:
    """Tests swap in a private registry."""
    global _REGISTRY
    _REGISTRY = reg


def relax(x: float, target: float, dt: float, tau_s: float) -> float:
    """Move x toward target with time constant tau_s. Rises AND falls at
    the same rate — the shape every slow feeling should have."""
    if tau_s <= 0:
        return target
    return x + (target - x) * (1.0 - math.exp(-max(dt, 0.0) / tau_s))


class Gate:
    """Display hysteresis on a 0..1 level: shown above ``on``, hidden
    again only below ``off``."""

    def __init__(self, on: float, off: float):
        if not on > off:
            raise ValueError("Gate needs on > off")
        self.on_at, self.off_at = on, off
        self.state = False

    def update(self, x: float) -> bool:
        if self.state:
            if x < self.off_at:
                self.state = False
        elif x >= self.on_at:
            self.state = True
        return self.state


def social_signal(brain: Any) -> float:
    """Dean's presence (1.0 when he just spoke, ~5 min decay) from the
    live body; 0.0 when unknown."""
    body = getattr(brain, "simulated_body", None) if brain is not None else None
    v = _finite(getattr(body, "social_signal", 0.0)) if body is not None else None
    return v or 0.0


def pct_word(p: Optional[float]) -> str:
    """'p83' style label, or '?' when there's no baseline yet."""
    return "?" if p is None else f"p{int(round(p * 100))}"
