"""Action cues: Leon's own "I should go do X" thoughts, and finished coding
jobs, turned into things he actually does.

Dean, 2026-10-05 15:18: Leon's inner voice said "Five minutes since he asked
where the work stands, and I've only talked about checking the jobs. I should
stop thinking about it and read the result files." and then nothing happened.
inner_voice._maybe_act_on_thought only nudged goal priorities; the thought
reached the next turn as private background and conversation-Leon only acted
when Dean spoke. Finished coding jobs sat unread until Dean asked.

What this module does:

  * classify(thought) picks out an imperative about something concrete Leon
    can do right now with tools (read/check results, a file, a job, a log;
    finish X; tell Dean Y; fix Z). Reflective and emotional thoughts are
    ignored.
  * Cues live in a small durable queue, brain_state/action_cues.jsonl (id,
    text, created, source, source thought, status). The same cue within 10
    minutes counts once.
  * A Dean turn gets the open cues at the TOP of its prompt as
    "[ACTION CUE from your own thought - do this first, with tools, this
    turn]"; a cue is done once a tool fired in that turn (begin_turn /
    end_turn, called from BrainAPIResponder.respond_streaming).
  * When Leon is idle (no turn running, Dean quiet for 2+ minutes, nobody
    talking), the watcher thread starts ONE short turn on Leon's normal
    conversation session that does the cue with tools, then posts what he
    found to the dashboard conversation and a desktop notify. At most one
    such turn every 3 minutes. The quiet-wait and turn shape are the coding
    job notice's (server/job_events.py); no new agent loop.
  * Every 60 s the watcher reads the coding job list (server/coding_jobs.py,
    the laptop relay) and turns any job that moved to done, failed or
    stalled into a cue: "Job <id> (<task>) finished as <state>: read its
    summary and tell Dean the result".
  * brain_state/open_tasks.json is a one-thing-at-a-time ledger: each task
    Dean gives (brain/active_context.py's task detection) is an entry, every
    Dean turn lists the ones he is still waiting on, oldest first, and an
    entry closes when Leon reports a result on it.

Everything is fail-open: a fault here never blocks or changes a reply.
"""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

from brain import job_followthrough as followthrough

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_DIR = os.path.join(_ROOT, "brain_state")
QUEUE_PATH = os.path.join(STATE_DIR, "action_cues.jsonl")
TASKS_PATH = os.path.join(STATE_DIR, "open_tasks.json")
JOBS_SEEN_PATH = os.path.join(STATE_DIR, "action_cues_jobs.json")

DEDUPE_S = 600.0             # the same cue within 10 minutes counts once
THOUGHT_CUE_TTL_S = 1800.0   # a thought's cue goes stale after 30 minutes
JOB_CUE_TTL_S = 6 * 3600.0   # a finished job stays worth reporting for hours
MAX_ATTEMPTS = 3             # Dean turns a cue may ride in without a tool firing
MAX_KEEP = 200               # queue rows kept on disk
PROMPT_CUES = 3              # cues shown in one prompt

IDLE_AFTER_DEAN_S = 120.0    # Dean spoke this recently -> his next turn does it
CUE_TURN_GAP_S = 180.0       # at most one autonomous cue turn every 3 minutes
CUE_TURN_TIMEOUT_S = 300.0   # one autonomous cue turn, end to end
JOB_POLL_S = 60.0
WATCH_TICK_S = 15.0
JOB_NOTICE_GRACE_S = 180.0   # let server/job_events.py speak first
JOB_NOTICE_MAX_WAIT_S = 1200.0

TASK_TTL_S = 12 * 3600.0     # a ledger entry nobody closed goes stale
MAX_OPEN_TASKS = 8
PROMPT_TASKS = 5

JOB_END_STATES = ("done", "failed", "stalled")

_lock = threading.RLock()
_turns_running = 0
_last_turn_begin = 0.0
_last_cue_turn_ts = 0.0
STUCK_TURN_S = 900.0         # a Dean turn whose end never came stops blocking

# ── the classifier ──────────────────────────────────────────────────────────

# "I'm going to" style intent, followed by a concrete verb within the clause.
_INTENT = re.compile(
    r"\b(?:i\s+should|i\s+need\s+to|i\s+have\s+to|i've\s+got\s+to|i\s+got\s+to|"
    r"i\s+must|i\s+ought\s+to|i'd\s+better|i\s+had\s+better|i'm\s+going\s+to|"
    r"i\s+am\s+going\s+to|i'll|i\s+will|let\s+me|time\s+to|gotta|"
    r"why\s+don't\s+i|maybe\s+i\s+should|i\s+want\s+to)\b", re.I)

_VERBS = (
    "read", "reread", "re-read", "check", "recheck", "re-check", "open", "look at",
    "look into", "pull up", "pull", "fetch", "inspect", "review", "verify", "test",
    "run", "rerun", "re-run", "restart", "finish", "complete", "wrap up", "fix",
    "repair", "patch", "debug", "tell", "report", "update", "message", "text",
    "email", "reply to", "answer", "send", "show", "ask", "follow up", "push",
    "deploy", "ship", "commit", "merge", "install", "build", "write", "save",
    "close", "kill", "cancel", "start", "launch", "resume", "retry", "grep",
    "search", "find", "download", "upload", "log", "record", "note", "summarize",
)
_VERB_RE = re.compile(r"\b(" + "|".join(re.escape(v) for v in sorted(_VERBS, key=len, reverse=True))
                      + r")\b", re.I)

# Something real the verb acts on: a thing with a tool behind it, or Dean.
_PERSON = re.compile(r"\b(dean|him|sir)\b", re.I)
_CONCRETE = re.compile(
    r"\b(results?|files?|folders?|jobs?|logs?|summar(?:y|ies)|outputs?|reports?|status|"
    r"errors?|bugs?|tests?|builds?|deploys?|deployments?|code|repo|repos|branch|commit|"
    r"pr|pull\s+request|scripts?|config|settings|server|service|endpoint|api|page|site|"
    r"dashboard|screen|browser|tab|terminal|email|emails|inbox|messages?|calendar|"
    r"invoice|order|ticket|issue|task|tasks|run|runs|workers?|agents?|queue|database|db|"
    r"backup|disk|process|crash|traceback|stack|diff|patch|fix|change|changes|"
    r"document|doc|docs|spreadsheet|notes?|link|url|video|reel|reels|draft)\b", re.I)

# Inner, reflective or bodily "actions" with no tool behind them.
_REFLECTIVE = re.compile(
    r"\b(feel|feeling|felt|wonder|reflect|think\s+about|be\s+(?:more|less|kinder|patient|"
    r"honest|present|calm|myself)|understand\s+(?:myself|why\s+i)|accept|forgive|"
    r"appreciate|breathe|rest|sleep|nap|relax|meditate|dream|remember\s+that|let\s+it\s+go|"
    r"love|miss|grieve|stay\s+with|sit\s+with)\b", re.I)

_SENTENCE = re.compile(r"[^.!?\n]+[.!?]?")
_FILLER = re.compile(r"^(?:just|actually|really|finally|now|go|go\s+and|and|then|also)\s+", re.I)


def _clause_after(sentence: str, start: int) -> str:
    rest = sentence[start:]
    # A cue is one action: stop at the next sentence-like break.
    rest = re.split(r",?\s+(?:but|because|since|so that|although|though|instead of)\s+|,\s+(?:and|so|yet)\s+|[;:—–]| - ",
                    rest, maxsplit=1)[0]
    return rest.strip(" ,.!?\"'")


def classify(thought: str) -> Optional[str]:
    """The concrete action in one inner thought, or None.

    Needs an intent ("I should", "I need to", "time to", ...) followed in the
    same sentence by a verb Leon can do with tools, acting on something real
    (a file, a job, a log, results, Dean...). Reflective and emotional
    thoughts give None.
    """
    if not isinstance(thought, str) or len(thought) < 12:
        return None
    for match in _SENTENCE.finditer(thought):
        sentence = match.group(0)
        intent = _INTENT.search(sentence)
        if not intent:
            continue
        tail = sentence[intent.end():]
        verb = _VERB_RE.search(tail)
        if not verb:
            continue
        # The verb has to belong to the intent, not sit in a later clause
        # ("I should rest, then maybe check..." still counts; a verb 12+
        # words after the intent does not).
        if len(tail[:verb.start()].split()) > 10:
            continue
        action = _clause_after(tail, verb.start())
        if not action or len(action) < 6:
            continue
        lead = tail[:verb.start()]
        if _REFLECTIVE.search(lead) and not re.search(r"\b(stop|quit)\b", lead, re.I):
            continue
        thing = _CONCRETE.search(action)
        # "tell him the build failed" is a cue; "tell him I love him" is a feeling.
        if not thing and not (_PERSON.search(action) and not _REFLECTIVE.search(action)):
            continue
        if _REFLECTIVE.search(action) and not thing:
            continue
        action = _FILLER.sub("", action)
        return action[:200]
    return None


# ── the queue ────────────────────────────────────────────────────────────────

def _norm(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", (text or "").lower()))


def _similar(a: str, b: str) -> bool:
    na, nb = _norm(a), _norm(b)
    if not na or not nb:
        return False
    if na == nb:
        return True
    sa, sb = set(na.split()), set(nb.split())
    return len(sa & sb) / max(1, len(sa | sb)) >= 0.7


def _load() -> List[Dict[str, Any]]:
    rows = []
    try:
        with open(QUEUE_PATH, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if isinstance(row, dict) and row.get("id"):
                    rows.append(row)
    except FileNotFoundError:
        pass
    except Exception as exc:
        print("[ACTION-CUE] queue read failed: %s" % type(exc).__name__, flush=True)
    return rows


def _save(rows: List[Dict[str, Any]]) -> None:
    os.makedirs(os.path.dirname(QUEUE_PATH), exist_ok=True)
    tmp = QUEUE_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        # Completion identities/checkpoints must outlive notification retention.
        ordinary = [r for r in rows if not followthrough.managed(r)][-MAX_KEEP:]
        for row in [r for r in rows if followthrough.managed(r)] + ordinary:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.replace(tmp, QUEUE_PATH)


def _expire(rows: List[Dict[str, Any]], now: float) -> bool:
    changed = False
    for row in rows:
        if followthrough.managed(row):
            if row.get("status") == "running" and now - float(row.get("started") or 0) > CUE_TURN_TIMEOUT_S + 60:
                row.update(status="reconciling", blocker="interrupted decision; checking stable request")
                changed = True
            continue  # an objective's review never expires like a thought
        if row.get("status") not in ("open", "injected", "running"):
            continue
        # A turn that died with the process (restart mid-turn) gives its cue back.
        claimed = float(row.get("injected") or row.get("started") or 0)
        if row["status"] != "open" and now - claimed > CUE_TURN_TIMEOUT_S + 60:
            row["status"] = "open"
            changed = True
        ttl = JOB_CUE_TTL_S if row.get("source") == "job" else THOUGHT_CUE_TTL_S
        if now - float(row.get("created") or 0) > ttl:
            row.update(status="expired", closed=now, closed_how="too old")
            changed = True
    return changed


def add_cue(text: str, *, source: str = "thought", source_text: str = "",
            job_id: str = "", job_state: str = "", now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """Queue one cue; returns it, or None when the same cue is already there."""
    text = " ".join((text or "").split())[:300]
    if not text:
        return None
    now = time.time() if now is None else now
    with _lock:
        rows = _load()
        _expire(rows, now)
        for row in reversed(rows):
            if job_id and row.get("job_id") == job_id and row.get("job_state") == job_state:
                return None   # one cue per job ending
            if job_id or row.get("job_id"):
                continue      # jobs are told apart by id, not by wording
            if now - float(row.get("created") or 0) > DEDUPE_S:
                continue
            if _similar(row.get("text", ""), text):
                row["repeats"] = int(row.get("repeats") or 0) + 1
                _save(rows)
                return None
        cue = {"id": "cue-" + uuid.uuid4().hex[:10], "text": text, "created": now,
               "source": source, "source_text": (source_text or "")[:500],
               "status": "open", "attempts": 0}
        if job_id:
            cue.update(job_id=job_id, job_state=job_state)
            if source == "job":
                cue.update(followthrough.fields(job_id))
        rows.append(cue)
        _save(rows)
    print("[ACTION-CUE] queued (%s): %s" % (source, text[:120]), flush=True)
    return cue


def open_cues(now: Optional[float] = None) -> List[Dict[str, Any]]:
    now = time.time() if now is None else now
    with _lock:
        rows = _load()
        if _expire(rows, now):
            _save(rows)
        return [r for r in rows if r.get("status") == "open"]


def _update(ids, **fields) -> None:
    ids = set(ids or ())
    if not ids:
        return
    with _lock:
        rows = _load()
        for row in rows:
            if row.get("id") in ids:
                row.update(fields)
        _save(rows)


def on_thought(thought_text: str, trigger: str = "") -> Optional[Dict[str, Any]]:
    """inner_voice hook: queue the thought's action if it has one."""
    action = classify(thought_text)
    if not action:
        return None
    return add_cue(action, source="thought", source_text=thought_text)


# ── Dean turns ───────────────────────────────────────────────────────────────

def _age(ts: float, now: float) -> str:
    mins = max(0, int((now - float(ts or now)) / 60))
    return "just now" if mins < 1 else "%d min ago" % mins


def cue_block(cues: List[Dict[str, Any]], now: Optional[float] = None) -> str:
    now = time.time() if now is None else now
    lines = []
    for cue in cues:
        line = ("[ACTION CUE from your own thought — answer Dean first; then, if it takes a tool "
                "or two, do it in this turn, otherwise start a background job for it] %s" % cue["text"])
        if cue.get("source") == "job":
            line = ("[ACTION CUE from a finished coding job — tell Dean in a sentence; "
                    "coding_job_status only if he wants details] %s" % cue["text"])
        elif cue.get("source") == "promise":
            line = ("[ACTION CUE from a promise you made Dean — answer him first; do it with tools "
                    "if it is quick, otherwise start a background job and say so] "
                    '%s (you said, %s: "%s")' % (cue["text"], _age(cue.get("created"), now),
                                                 (cue.get("source_text") or "")[:240]))
        elif cue.get("source_text"):
            line += ' (you thought, %s: "%s")' % (_age(cue.get("created"), now),
                                                  cue["source_text"][:240])
        lines.append(line)
    if lines:
        lines.append("Do the cue with a real tool call before anything else, then answer Dean "
                     "and tell him what you found. Don't just say you will.")
    return "\n".join(lines)


def begin_turn(now: Optional[float] = None) -> Tuple[str, List[str]]:
    """A Dean turn is starting: claim the open cues for its prompt.

    Returns (prompt block, cue ids). end_turn() must follow with the same ids.
    """
    global _turns_running, _last_turn_begin
    now = time.time() if now is None else now
    with _lock:
        _turns_running += 1
        _last_turn_begin = time.time()
        # Conversation tools/QUIET cannot acknowledge completion work. The
        # watcher owns its finite evidence review independently of announcements.
        cues = [c for c in open_cues(now) if not followthrough.managed(c)]
        cues.sort(key=lambda c: (c.get("source") != "job", float(c.get("created") or 0)))
        cues = cues[:PROMPT_CUES]
        ids = [c["id"] for c in cues]
        _update(ids, status="injected", injected=now)
    return cue_block(cues, now), ids


def end_turn(ids, tools_fired: bool, reply: str = "", now: Optional[float] = None) -> None:
    """The turn is over: its cues are done if a tool fired, else back to open."""
    global _turns_running
    now = time.time() if now is None else now
    with _lock:
        _turns_running = max(0, _turns_running - 1)
        try:  # ledger item 32: unfinished owner work gets a resume note, no "continue"
            from brain import work_queue
            work_queue.on_turn_end(reply)
        except Exception as exc:
            print("[WORK-QUEUE] resume note failed: %s: %s" % (type(exc).__name__, exc), flush=True)
        if not ids:
            return
        if tools_fired:
            ordinary = [r["id"] for r in _load() if r["id"] in ids and not followthrough.managed(r)]
            _update(ordinary, status="done", closed=now, closed_how="tool fired in Dean turn")
            print("[ACTION-CUE] done in Dean turn: %s" % ",".join(ids), flush=True)
            return
        rows = _load()
        for row in rows:
            if row.get("id") in set(ids) and row.get("status") == "injected" and not followthrough.managed(row):
                if row.get("source") == "job" and isinstance(reply, str) and reply.strip(" .[]\n\t").upper() == "QUIET":
                    row.update(status="done", closed=now, closed_how="Dean turn acknowledged quietly", tools_fired=0)
                    continue
                row["attempts"] = int(row.get("attempts") or 0) + 1
                if row["attempts"] >= MAX_ATTEMPTS:
                    row.update(status="dropped", closed=now,
                               closed_how="%d turns without a tool" % row["attempts"])
                else:
                    row["status"] = "open"
        _save(rows)


def turn_running() -> bool:
    return _turns_running > 0 and time.time() - _last_turn_begin < STUCK_TURN_S


def turn_preface(cue_text: str = "", user_text: str = "", now: Optional[float] = None) -> str:
    """Everything this module puts at the top of a Dean turn's prompt: the
    cues begin_turn() claimed for it, what the inner voice just checked on its
    own (brain/shared_mind.py), then the open-task ledger."""
    parts = [cue_text] if cue_text else []
    try:
        from brain import shared_mind
        fresh = shared_mind.reply_block(now)
        if fresh:
            parts.append(fresh)
    except Exception:
        pass
    try:
        ledger = tasks_block(exclude_text=user_text, now=now)
        if ledger:
            parts.append(ledger)
    except Exception:
        pass
    return "\n\n".join(parts)


# ── one thing at a time: the open-task ledger ─────────────────────────────

def _load_tasks() -> List[Dict[str, Any]]:
    try:
        with open(TASKS_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return [t for t in data.get("tasks", []) if isinstance(t, dict)]
    except FileNotFoundError:
        return []
    except Exception:
        return []


def _save_tasks(tasks: List[Dict[str, Any]]) -> None:
    os.makedirs(os.path.dirname(TASKS_PATH), exist_ok=True)
    tmp = TASKS_PATH + ".tmp"
    keep = [t for t in tasks if t.get("status") == "open"] + \
           [t for t in tasks if t.get("status") != "open"][-30:]
    keep.sort(key=lambda t: float(t.get("created") or 0))
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"tasks": keep, "saved": time.time()}, f, indent=1, ensure_ascii=False)
    os.replace(tmp, TASKS_PATH)


def _expire_tasks(tasks, now) -> bool:
    changed = False
    for t in tasks:
        if t.get("status") == "open" and now - float(t.get("created") or 0) > TASK_TTL_S:
            t.update(status="stale", closed=now)
            changed = True
    opened = [t for t in tasks if t.get("status") == "open"]
    for t in opened[:max(0, len(opened) - MAX_OPEN_TASKS)]:
        t.update(status="stale", closed=now)
        changed = True
    return changed


def add_task(text: str, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """A task Dean just gave. Same text as an open entry = the same task."""
    text = " ".join((text or "").split())[:300]
    if len(text) < 4:
        return None
    now = time.time() if now is None else now
    with _lock:
        tasks = _load_tasks()
        _expire_tasks(tasks, now)
        for t in tasks:
            if t.get("status") == "open" and _similar(t.get("text", ""), text):
                t["last_asked"] = now
                _save_tasks(tasks)
                return t
        task = {"id": "task-" + uuid.uuid4().hex[:8], "text": text, "created": now,
                "status": "open"}
        tasks.append(task)
        _expire_tasks(tasks, now)
        _save_tasks(tasks)
    return task


def open_tasks(now: Optional[float] = None) -> List[Dict[str, Any]]:
    now = time.time() if now is None else now
    with _lock:
        tasks = _load_tasks()
        if _expire_tasks(tasks, now):
            _save_tasks(tasks)
        return sorted((t for t in tasks if t.get("status") == "open"),
                      key=lambda t: float(t.get("created") or 0))


def tasks_block(exclude_text: str = "", now: Optional[float] = None) -> str:
    now = time.time() if now is None else now
    waiting = [t for t in open_tasks(now)
               if not (exclude_text and _similar(t.get("text", ""), exclude_text))]
    if not waiting:
        return ""
    lines = ["[OPEN TASKS Dean is still waiting on — oldest first. Reply to his message "
             "first; then give one line of status on these, or hand them to background jobs. "
             "Don't make him wait while you work.]"]
    for n, t in enumerate(waiting[:PROMPT_TASKS], 1):
        lines.append("%d. (%s) %s" % (n, _age(t.get("created"), now), t["text"][:200]))
    if len(waiting) > PROMPT_TASKS:
        lines.append("(+%d more)" % (len(waiting) - PROMPT_TASKS))
    return "\n".join(lines)


_RESULT = re.compile(
    r"\b(done|finished|it'?s\s+(?:live|up|fixed|working|in)|fixed|shipped|pushed|deployed|"
    r"sent|found|here'?s\s+(?:what|the)|the\s+result|results?\s+(?:are|is|show)|turned\s+out|"
    r"came\s+back|completed|landed|failed|broke|couldn'?t|can'?t|blocked|stalled|"
    r"no\s+luck|it\s+says|reads?\s+as|shows?\s+that)\b", re.I)
_STOP = set("the a an and or to of in on for with that this it is was be can you your i me my "
            "him his he dean sir please just what how when where why there here have has had "
            "do does did go get got make let leon".split())


def _keywords(text: str) -> set:
    return {w for w in re.findall(r"[a-z0-9]+", (text or "").lower())
            if len(w) > 3 and w not in _STOP}


# A reply that ends still on the way ("checking who fired it") is progress,
# not a result: the task stays open.
_ONGOING = re.compile(
    r"\b(checking|looking(?:\s+into)?|on it|i'll|i will|let me|working on|digging|"
    r"finding|reading|still|next\s+i|going to|gonna|in a (?:sec|minute|moment)|"
    r"once\s+(?:it|they|that)|will\s+(?:tell|report|let)\s+you)\b", re.I)


def close_reported(reply: str, tools_fired: bool, turn_text: str = "",
                   now: Optional[float] = None) -> List[str]:
    """Close the ledger entries Leon just reported a result on."""
    if not reply or not _RESULT.search(reply):
        return []
    last = [s for s in re.split(r"(?<=[.!?])\s*", reply.strip()) if s.strip()]
    if last and _ONGOING.search(last[-1]):
        return []
    now = time.time() if now is None else now
    words = _keywords(reply)
    closed = []
    with _lock:
        tasks = _load_tasks()
        for t in tasks:
            if t.get("status") != "open":
                continue
            this_turn = bool(turn_text) and _similar(t.get("text", ""), turn_text)
            overlap = len(_keywords(t.get("text", "")) & words)
            if (this_turn and tools_fired) or overlap >= 2:
                t.update(status="reported", closed=now, report=reply[:300])
                closed.append(t["id"])
        if closed:
            _save_tasks(tasks)
    if closed:
        print("[ACTION-CUE] ledger closed: %s" % ",".join(closed), flush=True)
    return closed


# ── coding jobs: notice when one ends ───────────────────────────────────────

def _fix_text(text: str) -> str:
    if isinstance(text, str) and ("â€" in text or "Ã" in text):
        try:
            return text.encode("cp1252").decode("utf-8")
        except Exception:
            pass
    return text or ""


def _first_line(task: str, limit: int = 90) -> str:
    line = next((l.strip() for l in _fix_text(task).splitlines() if l.strip()), "")
    return line if len(line) <= limit else line[:limit].rstrip() + "…"


def job_cue_text(job: Dict[str, Any]) -> str:
    return ("Job %s (%s) finished as %s: read its summary and tell Dean the result"
            % (job.get("job_id"), _first_line(job.get("task") or ""), job.get("state")))


def _load_seen() -> Dict[str, Any]:
    try:
        with open(JOBS_SEEN_PATH, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) and isinstance(data.get("states"), dict) else {}
    except Exception:
        return {}


def _save_seen(data: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(JOBS_SEEN_PATH), exist_ok=True)
    tmp = JOBS_SEEN_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(tmp, JOBS_SEEN_PATH)


def note_jobs(jobs: List[Dict[str, Any]], now: Optional[float] = None) -> List[Dict[str, Any]]:
    """Compare a fresh job list with the last one; cue every job that ended.

    The first list ever seen only sets the baseline (old finished jobs are
    not re-announced); after that a job counts once it moves into done,
    failed or stalled, or first shows up already ended after the baseline.
    """
    now = time.time() if now is None else now
    seen = _load_seen()
    states = seen.get("states") or {}
    first = not seen
    cues = []
    for job in jobs or []:
        jid, state = job.get("job_id"), job.get("state")
        if not jid or not state:
            continue
        before = states.get(jid)
        states[jid] = state
        if first or state not in JOB_END_STATES or before == state:
            continue
        if before is None and float(job.get("finished") or job.get("created") or 0) < float(
                seen.get("since") or now):
            continue    # ended before Leon was watching
        cue = add_cue(job_cue_text(job), source="job", job_id=jid, job_state=state,
                      source_text=_fix_text(job.get("task") or "")[:500], now=now)
        if cue:
            cues.append(cue)
    if len(states) > 300:
        states = dict(list(states.items())[-300:])
    _save_seen({"since": seen.get("since") or now, "states": states, "polled": now})
    return cues


def poll_jobs(now: Optional[float] = None) -> List[Dict[str, Any]]:
    from server import coding_jobs
    body = coding_jobs.list_jobs(30)
    if not body.get("ok"):
        return []
    try:
        # A live reading for the claim gate: "the job is still running" is
        # held to this list (brain/evidence_ledger.py).
        from brain import evidence_ledger
        evidence_ledger.note_jobs(body.get("jobs") or [])
    except Exception:
        pass
    return note_jobs(body.get("jobs") or [], now)


def note_job_announced(job_id: str, state: str = "") -> None:
    """Record notification delivery without acknowledging completion work."""
    now = time.time()
    with _lock:
        rows = _load()
        hit = False
        for row in rows:
            if row.get("job_id") == job_id and (not state or row.get("job_state") == state):
                if followthrough.managed(row):
                    row["announced"] = now
                elif row.get("status") in ("open", "injected"):
                    row.update(status="done", closed=now, closed_how="job notice spoke")
                hit = True
        if not hit and state in JOB_END_STATES:
            rows.append({"id": "cue-" + uuid.uuid4().hex[:10], "created": now,
                         "text": "Job %s finished as %s (told Dean via the job notice)" % (job_id, state),
                         "source": "job", "job_id": job_id, "job_state": state,
                         "status": "open", "announced": now,
                         "attempts": 0, **followthrough.fields(job_id)})
            hit = True
        if hit:
            _save(rows)


def job_reported(job_id: str, state: str = "") -> bool:
    """Leon already reported this job through a cue (job_events stays quiet)."""
    with _lock:
        return any(r.get("job_id") == job_id and r.get("status") == "done"
                   and (not state or r.get("job_state") == state)
                   and r.get("closed_how") != "job notice spoke" for r in _load())


# ── the idle path: one short turn that does the cue ─────────────────────────

def _dean_last_spoke() -> float:
    ts = 0.0
    try:
        _st = sys.modules["server.state"]
        responder = getattr(_st, "brain_api_responder", None)
        actx = getattr(responder, "_active_context", None)
        ts = max(ts, float(getattr(actx, "last_dean_request_ts", 0) or 0))
        meter = getattr(getattr(_st, "brain", None), "consciousness_meter", None)
        ts = max(ts, float(getattr(meter, "_last_user_message_ts", 0) or 0))
    except Exception:
        pass
    return ts


def busy_reason(now: Optional[float] = None, *, ignore_rate=False) -> Optional[str]:
    """Why an autonomous cue turn must not start now (None = go)."""
    now = time.time() if now is None else now
    stopped = followthrough.stop_reason()
    if stopped:
        return stopped
    if turn_running():
        return "a turn is running"
    priority = sys.modules.get("server.turn_priority")
    if priority is not None and priority.USER_TURN_GATE.has_pending():
        return "owner conversation awaiting admission"
    # Only a running server has these; never import it from here.
    _st = sys.modules.get("server.state")
    if _st is not None and (getattr(_st, "_responder_stats", None) or {}).get("is_processing"):
        return "a reply to Dean is pending"
    _helpers = sys.modules.get("server.helpers")
    if _helpers is not None:
        try:
            reason = _helpers._announcement_busy()
            if reason:
                return reason
        except Exception:
            pass
    if now - _dean_last_spoke() < IDLE_AFTER_DEAN_S:
        return "Dean spoke in the last 2 minutes"
    if not ignore_rate and now - _last_cue_turn_ts < CUE_TURN_GAP_S:
        return "cue turn rate limit"
    return None


def _job_notice_pending(cue: Dict[str, Any], now: float) -> bool:
    """Give server/job_events.py first go at a job it is announcing."""
    if followthrough.managed(cue) or cue.get("source") != "job" or cue.get("job_state") == "stalled":
        return False
    age = now - float(cue.get("created") or now)
    if age < JOB_NOTICE_GRACE_S:
        return True
    try:
        from server import job_events
        return cue.get("job_id") in job_events._seen and age < JOB_NOTICE_MAX_WAIT_S
    except Exception:
        return False


def cue_turn_prompt(cue: Dict[str, Any]) -> str:
    parts = ["[INTERNAL — your own follow-through. Not Dean speaking; he cannot see this message.]"]
    if followthrough.managed(cue):
        return "/cli " + parts[0] + "\n" + followthrough.prompt(cue)
    parts.append("This thought or promise is a candidate, not owner authorization. Act only "
                 "within existing owner scope and approval/budget limits. No customer releases, "
                 "new spending, external messages, or private-state export. If blocked or "
                 "nothing useful remains, preserve that reason instead of inventing work.")
    if cue.get("source") == "job":
        parts.append("A coding job ended: %s." % cue["text"])
        parts.append("What it was asked to do: %s" % (cue.get("source_text") or "")[:900])
        parts.append("Read its summary now with coding_job_status (and anything it points to) "
                     "before you say a word.")
    elif cue.get("source") == "promise":
        parts.append('A few minutes ago you told Dean: "%s" but no tool for it ran.'
                     % (cue.get("source_text") or "")[:500])
        parts.append("Do it now, with your tools, in this turn (%s). Don't describe a plan."
                     % cue["text"])
    else:
        parts.append('A few minutes ago you thought: "%s"' % (cue.get("source_text") or "")[:500])
        parts.append("The action in it: %s. Do it now, with your tools, in this turn. Actually "
                     "read/check/fix it; don't describe a plan." % cue["text"])
    parts.append("Then tell Dean what you found or did in one to three short spoken sentences, "
                 "as yourself: no markdown, lists, file paths or commit hashes unless they matter "
                 "to him. If it turns out there is nothing worth telling him, reply with only QUIET.")
    return "/cli " + "\n".join(parts)


def _run_cue_turn(responder, prompt, brain_state, lock, cue=None) -> Tuple[Optional[str], int]:
    """One turn on Leon's conversation session; (reply text, tools fired)."""
    from brain.inference_cancel import CancelToken
    if lock is not None and not lock.acquire(timeout=5):
        return None, -1
    token, box = CancelToken(), {"tools": 0}

    def cue_turn():
        try:
            # Recheck after acquiring the shared lock; owner input and limits
            # may have changed during admission. This consumes no decision.
            if followthrough.decision_gate(cue) or busy_reason(ignore_rate=True):
                box["tools"] = -1
                return
            # Same call shape as the coding job notice: an internal caller on
            # the conversation session, never stored as something Dean said.
            from brain.goal_pursuit import _goal_execution_scope
            scope = followthrough.decision_scope(cue) if cue and followthrough.managed(cue) else _goal_execution_scope()
            with scope:
                for ev in responder.respond_streaming(
                        prompt, brain_state, replay_history=True, persist_history=False,
                        force_cli=True, bypass_consciousness=True, cancel_token=token):
                    if ev.type == "tool_use":
                        box["tools"] += 1
                    elif ev.type == "done":
                        box["text"] = ev.full_text or ""
                        break
                    elif ev.type == "error":
                        box["error"] = ev.error
                        if cue and followthrough.managed(cue):
                            _update([cue["id"]], provider_error=str(ev.error)[:500])
                        break
        except Exception as exc:
            box["error"] = type(exc).__name__
        finally:
            if lock is not None:
                lock.release()

    worker = threading.Thread(target=cue_turn, daemon=True, name="action-cue-turn")
    worker.start()
    deadline = time.monotonic() + CUE_TURN_TIMEOUT_S
    while worker.is_alive() and time.monotonic() < deadline:
        worker.join(min(0.25, max(0, deadline - time.monotonic())))
        if followthrough.stop_reason():
            token.cancel(followthrough.stop_reason())
    if worker.is_alive():
        token.cancel("action cue turn timed out")
        print("[ACTION-CUE] cue turn timed out", flush=True)
        return None, box["tools"]
    if "error" in box:
        print("[ACTION-CUE] cue turn failed: %s" % str(box["error"])[:120], flush=True)
    return box.get("text"), box["tools"]


def _post(line: str, cue: Dict[str, Any]) -> bool:
    """Leon's line to the dashboard conversation (and its store) plus a notify."""
    try:
        # The claim gate holds the line to the evidence ledger (the cue turn's
        # tool calls are in it) before it is stored or spoken.
        from server.reply_gate import gate_proactive
        line = gate_proactive(line, "action_cue")
    except Exception:
        pass
    if not (line or "").strip():
        return False
    from brain.outbound import new_utterance_id
    from server import state as _st
    uid = new_utterance_id("action_cue")
    spoken = False
    try:
        from server.helpers import broadcast_response
        spoken = bool(broadcast_response(line, source="action_cue",
                                         user_label="(following through)", audio=True,
                                         force=True, utterance_id=uid))
    except Exception as exc:
        print("[ACTION-CUE] broadcast failed: %s" % type(exc).__name__, flush=True)
    try:
        store = getattr(getattr(_st, "brain_api_responder", None), "_conversation_store", None)
        if store is not None:
            store.append("assistant", line, model="action-cue",
                         metadata={"utterance_id": uid, "kind": "action_cue",
                                   "cue_id": cue.get("id")})
    except Exception as exc:
        print("[ACTION-CUE] not stored: %s" % type(exc).__name__, flush=True)
    try:
        from brain.actuator_client import call as _actuator_call
        from brain.identity import si_name
        from brain.outbound import smart_truncate
        _actuator_call("notify", {"title": "%s — follow-through" % si_name(),
                                  "body": smart_truncate(line, 240), "urgency": "normal"},
                       timeout=3.0)
    except Exception:
        pass
    try:
        from brain.outbound import log_decision
        log_decision({"ts": time.time(), "source": "action_cue", "kind": "event",
                      "decision": "spoke" if spoken else "suppressed",
                      "why": "cue %s (%s)" % (cue.get("id"), cue.get("source")),
                      "text": line[:200], "delivered": spoken})
    except Exception:
        pass
    return spoken


def run_idle_cue(now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """If Leon is idle and a cue is open, do the oldest one in its own turn."""
    global _last_cue_turn_ts
    now = time.time() if now is None else now
    cues = [c for c in open_cues(now) if not _job_notice_pending(c, now)
            and not followthrough.decision_gate(c)
            and (not followthrough.managed(c) or
                 (c.get("completion_receipt") and not c.get("decision_attempted")))]
    if not cues:
        return None
    if busy_reason(now):
        return None
    cues.sort(key=lambda c: (c.get("source") != "job", float(c.get("created") or 0)))
    cue = cues[0]
    from server import state as _st
    from server import job_events
    responder = getattr(_st, "brain_api_responder", None)
    if responder is None:
        return None
    try:
        from server.helpers import leon_asleep
        if leon_asleep():
            return None
    except Exception:
        pass
    if followthrough.managed(cue):
        try:
            child = followthrough.child_status(cue)
        except Exception as exc:
            _update([cue["id"]], status="blocked", blocker=str(exc)[:240])
            return None
        if child:
            followthrough.finish(cue, "", 0)
            return None
    _last_cue_turn_ts = now
    if followthrough.managed(cue):
        if not followthrough.claim(cue, now):
            return None
    else:
        _update([cue["id"]], status="running", started=now)
    print("[ACTION-CUE] idle cue turn: %s" % cue["text"][:120], flush=True)
    brain_state = {}
    try:
        brain_state = _st.brain.get_state() if getattr(_st, "brain", None) else {}
    except Exception:
        pass
    text, tools = _run_cue_turn(responder, cue_turn_prompt(cue), brain_state,
                                getattr(_st, "_responder_lock", None), cue=cue)
    if tools < 0:   # the responder was busy after all: try again later
        _update([cue["id"]], status="open", decision_attempted=False)
        _last_cue_turn_ts = 0.0
        return None
    if followthrough.managed(cue):
        _update([cue["id"]], tools_fired=tools, decision_finished=time.time())
        followthrough.finish(cue, text, tools)
        # Receipt is internal evidence; no duplicate notification or heuristic
        # close_reported() on an objective whose tests/adoption may still fail.
        return {"cue": cue["id"], "tools": tools, "review": True}
    line = job_events.clean_reply(text or "")
    quiet_ack = cue.get("source") == "job" and job_events.deliberate_quiet(text)
    if quiet_ack:
        _update([cue["id"]], status="done", closed=time.time(),
                closed_how="idle cue acknowledged quietly", reply="", tools_fired=tools)
    elif tools > 0:
        _update([cue["id"]], status="done", closed=time.time(),
                closed_how="idle cue turn, %d tool call(s)" % tools, reply=(line or "")[:300])
    else:
        attempts = int(cue.get("attempts") or 0) + 1
        _update([cue["id"]], status="open" if attempts < MAX_ATTEMPTS else "dropped",
                attempts=attempts, reply=(line or "")[:300])
    if line:
        _post(line, cue)
        close_reported(line, tools > 0, turn_text="")
    print("[ACTION-CUE] idle cue turn finished: tools=%d said=%s" % (tools, bool(line)), flush=True)
    return {"cue": cue["id"], "tools": tools, "line": line}


# ── the watcher thread ───────────────────────────────────────────────────────

_watcher: Optional[threading.Thread] = None
_stop = threading.Event()


def _watch():
    last_poll = 0.0
    # Self-restart: read the owner work queue first and continue its top entry
    # now (ledger items 28/30), instead of waiting for Dean to type continue.
    try:
        from brain import work_queue
        work_queue.boot()
    except Exception as exc:
        print("[WORK-QUEUE] boot failed: %s: %s" % (type(exc).__name__, exc), flush=True)
    while not _stop.wait(WATCH_TICK_S):
        now = time.time()
        if now - last_poll >= JOB_POLL_S:
            last_poll = now
            try:
                poll_jobs(now)
            except Exception as exc:
                print("[ACTION-CUE] job poll failed: %s" % type(exc).__name__, flush=True)
        try:
            followthrough.collect_one()
            from brain.owner_goal_continuation import reconcile
            reconcile()
            from brain import work_queue
            work_queue.tick()
            run_idle_cue()
        except Exception as exc:
            print("[ACTION-CUE] idle cue failed: %s: %s" % (type(exc).__name__, exc), flush=True)


def start() -> bool:
    """Start the job poller / idle cue watcher once per process."""
    global _watcher
    if os.environ.get("LEON_ACTION_CUES", "on").lower() in ("0", "off", "false", "no"):
        print("[ACTION-CUE] disabled (LEON_ACTION_CUES=off)", flush=True)
        return False
    try:
        from brain.identity import is_client_si
        if is_client_si():
            return False
    except Exception:
        pass
    with _lock:
        if _watcher is not None and _watcher.is_alive():
            return True
        _stop.clear()
        _watcher = threading.Thread(target=_watch, daemon=True, name="action-cues")
        _watcher.start()
    print("[ACTION-CUE] watching: jobs every %.0fs, idle cue turns at most every %.0fs"
          % (JOB_POLL_S, CUE_TURN_GAP_S), flush=True)
    return True
