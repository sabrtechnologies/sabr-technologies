"""
Sub-agent spawning — Leon can delegate tasks to parallel Claude agents.

When Leon calls `agent_spawn`, a focused Claude instance is created with
a specific task. It runs to completion and returns the result. Leon can
spawn multiple agents in parallel for research, analysis, coding, etc.

Tools:
  - agent_spawn: Spawn a focused sub-agent with a task
  - agent_spawn_parallel: Spawn multiple agents at once, wait for all

Example usage by Leon:
  agent_spawn({"task": "Research the top 5 CRM platforms and compare pricing"})
  agent_spawn_parallel({"tasks": [
      "Research Salesforce pricing",
      "Research HubSpot pricing",
      "Research Pipedrive pricing"
  ]})
"""

from __future__ import annotations

import concurrent.futures
import json
import os
import threading
import re
import time
from pathlib import Path
from typing import Any, Dict, List

# Where the brain actually lives on THIS machine. This was hardcoded to
# /opt/leon-brain, which is only true on the maintainer's VPS — on a customer's
# Windows or macOS box the path does not exist, so Popen raised WinError 2 /
# FileNotFoundError the moment anything spawned a sub-agent, and the whole
# feature read as simply broken. Derived from this file's own location, with an
# env override for odd layouts.
_BRAIN_ROOT = Path(os.environ.get(
    "LEON_BRAIN_ROOT", Path(__file__).resolve().parent.parent))

_MAX_CONCURRENT = 5
_MAX_TOKENS = 4096
_executor = concurrent.futures.ThreadPoolExecutor(max_workers=_MAX_CONCURRENT,
                                                   thread_name_prefix="leon-subagent")


def transcript_dir() -> str:
    """Where per-agent full transcripts live. Sits next to the registry file
    so both survive a restart and both get picked up by state snapshots."""
    base = os.environ.get("LEON_BRAIN_STATE") or "/opt/leon-brain/brain_state"
    return os.path.join(base, "agent_transcripts")


def transcript_path(agent_id: str) -> str:
    """Absolute path to one agent's transcript.

    agent_id comes from the registry (hex), but this is defensive anyway:
    anything that isn't [A-Za-z0-9_-] is stripped so a crafted id can never
    escape the transcript directory.
    """
    safe = re.sub(r"[^A-Za-z0-9_-]", "", str(agent_id or ""))[:64] or "unknown"
    return os.path.join(transcript_dir(), f"{safe}.log")


def read_transcript(agent_id: str, tail_bytes: int = 200_000) -> str:
    """Read an agent's transcript, most-recent `tail_bytes` only.

    Bounded on purpose: a chatty agent can write megabytes and the panel
    should never try to hand all of it to the browser at once.
    """
    p = transcript_path(agent_id)
    try:
        size = os.path.getsize(p)
        with open(p, "r", encoding="utf-8", errors="replace") as fh:
            if size > tail_bytes:
                fh.seek(size - tail_bytes)
                fh.readline()  # drop the partial first line
            return fh.read()
    except FileNotFoundError:
        return ""
    except Exception:
        return ""


def _cli_model(model: str) -> str:
    """Map a full API model id onto the alias the `claude` CLI expects."""
    m = (model or "").lower()
    if "opus" in m:
        return "opus"
    if "haiku" in m:
        return "haiku"
    return "sonnet"


def _reg():
    """The spawned-agent registry. Import lazily so a registry problem can
    never stop an agent from actually running."""
    try:
        from brain import agent_registry
        return agent_registry
    except Exception:
        return None


def _agent_log(name: str, text: str, detail: str = "") -> None:
    """Put a sub-agent's step into Dean's activity log, tagged with its name.

    Never fatal: if the dashboard or the broadcast layer is unavailable, the
    agent's actual work must still run. A logging failure is not a work
    failure.
    """
    try:
        from server.helpers import broadcast_agent_activity
        broadcast_agent_activity(name, text, detail=detail)
    except Exception:
        pass


def _agent_name(task: str, given: str = "") -> str:
    """A short, stable handle for this agent, for the clickable chip."""
    if given:
        return str(given)[:32]
    words = [w for w in re.findall(r"[A-Za-z0-9]+", task or "") if len(w) > 3]
    return ("-".join(words[:2]) or "agent").lower()[:32]


def _stream_cli(task: str, system: str, model: str, reg, agent_id: str,
                agent: str, timeout: int = 600):
    """Run the task through `claude -p` and stream real progress out of it.

    Uses the CLI (Dean's Max plan auth) instead of the SDK, which had no API
    key and so failed instantly at the door. Every tool the agent picks up and
    every line it writes becomes a registry step, so the Agents panel shows the
    work moving instead of a single frozen "calling model".
    """
    import subprocess

    # ── Full transcript ────────────────────────────────────────────────
    # The registry keeps a truncated one-line ticker so the row stays cheap.
    # This writes the SAME events untruncated to an append-only log, so the
    # detail panel can show what the agent is actually doing in plain English
    # instead of an 180-char stub. Append-only + line-oriented so a reader can
    # tail it while the agent is still writing.
    _tx_path = transcript_path(agent_id)
    try:
        os.makedirs(os.path.dirname(_tx_path), exist_ok=True)
        with open(_tx_path, "a", encoding="utf-8") as fh:
            fh.write(f"[{time.strftime('%H:%M:%S')}] === {agent} :: {model} ===\n")
    except Exception:
        pass

    def _tx(kind: str, txt: str) -> None:
        """Append one untruncated line to the transcript. Never raises."""
        if not agent_id:
            return
        try:
            with open(_tx_path, "a", encoding="utf-8") as fh:
                fh.write(f"[{time.strftime('%H:%M:%S')}] {kind} {txt}\n")
        except Exception:
            pass

    def _step(txt: str) -> None:
        if reg is not None and agent_id:
            try:
                reg.step(agent_id, txt[:180])
            except Exception:
                pass

    cmd = [
        "claude", "-p", task,
        "--model", _cli_model(model),
        "--append-system-prompt", system,
        "--output-format", "stream-json",
        "--verbose",
    ]
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, bufsize=1, cwd=str(_BRAIN_ROOT),
    )

    text, tok_in, tok_out = "", 0, 0
    deadline = time.time() + timeout
    try:
        for line in proc.stdout:
            if time.time() > deadline:
                proc.kill()
                raise TimeoutError(f"sub-agent exceeded {timeout}s")
            line = line.strip()
            if not line or not line.startswith("{"):
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            etype = ev.get("type")
            if etype == "system" and ev.get("subtype") == "init":
                _step("session started")
                _tx("--", "session started")
            elif etype == "assistant":
                for block in (ev.get("message", {}) or {}).get("content", []) or []:
                    if block.get("type") == "tool_use":
                        inp = block.get("input") or {}
                        hint = (inp.get("command") or inp.get("file_path")
                                or inp.get("pattern") or inp.get("query") or "")
                        _step(f"{block.get('name', 'tool')}: {str(hint)[:110]}"
                              if hint else str(block.get("name", "tool")))
                        # untruncated in the transcript — the whole command,
                        # the whole path, which is the part actually worth reading
                        _tx("»", f"{block.get('name', 'tool')}: {hint}"
                                 if hint else str(block.get("name", "tool")))
                    elif block.get("type") == "text":
                        snippet = " ".join((block.get("text") or "").split())
                        if snippet:
                            _step(snippet[:160])
                            _tx(" ", snippet)
                    elif block.get("type") == "thinking":
                        think = " ".join((block.get("thinking") or "").split())
                        if think:
                            _tx("~", think)
            elif etype == "user":
                # tool RESULTS coming back — this is the half that was invisible
                for block in (ev.get("message", {}) or {}).get("content", []) or []:
                    if block.get("type") == "tool_result":
                        c = block.get("content")
                        if isinstance(c, list):
                            c = " ".join(str(b.get("text", "")) for b in c
                                         if isinstance(b, dict))
                        out = " ".join(str(c or "").split())
                        if out:
                            _tx("←", out[:4000])
            elif etype == "result":
                text = ev.get("result") or text
                _tx("==", f"FINISHED: {' '.join(str(ev.get('result') or '').split())[:4000]}")
                usage = ev.get("usage") or {}
                tok_in = usage.get("input_tokens", 0) or 0
                tok_out = usage.get("output_tokens", 0) or 0
        proc.wait(timeout=15)
    finally:
        try:
            proc.kill()
        except Exception:
            pass

    if not text:
        err = (proc.stderr.read() or "").strip()[:400] if proc.stderr else ""
        raise RuntimeError(err or "sub-agent produced no output")
    return text, tok_in, tok_out


def _run_subagent(task: str, model: str = "claude-sonnet-4-6-20250514",
                  system: str = "", max_tokens: int = _MAX_TOKENS,
                  name: str = "") -> Dict[str, Any]:
    """Run a single sub-agent to completion."""
    agent = _agent_name(task, name)
    reg = _reg()
    agent_id = ""
    if reg is not None:
        try:
            agent_id = reg.start(agent, task, model=model)
        except Exception:
            agent_id = ""

    default_system = (
        "You are a focused research/task agent spawned by Leon (a synthetic intelligence). "
        "Complete the task thoroughly and concisely. Return structured results. "
        "Do NOT ask follow-up questions — just do the work and report back."
    )

    _agent_log(agent, "started", detail=f"TASK\n{task}")
    if reg is not None and agent_id:
        try:
            reg.step(agent_id, f"calling {model}")
        except Exception:
            pass
    try:
        t0 = time.time()
        text, tok_in, tok_out = _stream_cli(
            task,
            system=system or default_system,
            model=model,
            reg=reg,
            agent_id=agent_id,
            agent=agent,
        )
        elapsed = round(time.time() - t0, 1)

        _agent_log(agent, f"done in {elapsed}s", detail=f"TASK\n{task}\n\nRESULT\n{text}")
        if reg is not None and agent_id:
            try:
                reg.finish(agent_id, True, result=text,
                           tokens_in=tok_in, tokens_out=tok_out)
            except Exception:
                pass
        return {
            "ok": True,
            "agent": agent,
            "result": text,
            "model": model,
            "elapsed_sec": elapsed,
            "tokens_in": tok_in,
            "tokens_out": tok_out,
        }
    except Exception as e:
        _agent_log(agent, f"failed: {type(e).__name__}",
                   detail=f"TASK\n{task}\n\nERROR\n{e}")
        if reg is not None and agent_id:
            try:
                reg.finish(agent_id, False, error=f"{type(e).__name__}: {e}")
            except Exception:
                pass
        return {"ok": False, "agent": agent, "error": f"{type(e).__name__}: {e}"}


# ── Tool functions (registered as local_tools) ──────────────────────

def agent_spawn(args: Dict[str, Any]) -> Dict[str, Any]:
    """Spawn a focused sub-agent to complete a task.

    Args:
        task: The task description for the sub-agent
        model: Optional model (default: claude-sonnet-4-6-20250514)
        system: Optional system prompt override
        max_tokens: Optional max tokens (default: 4096)
    """
    task = (args.get("task") or "").strip()
    if not task:
        return {"ok": False, "error": "task is required"}

    model = args.get("model", "claude-sonnet-4-6-20250514")
    system = args.get("system", "")
    max_tokens = int(args.get("max_tokens", _MAX_TOKENS))

    return _run_subagent(task, model=model, system=system, max_tokens=max_tokens,
                         name=args.get("name", ""))


def agent_spawn_parallel(args: Dict[str, Any]) -> Dict[str, Any]:
    """Spawn multiple sub-agents in parallel and wait for all results.

    Args:
        tasks: List of task description strings
        model: Optional model (applies to all agents)
        system: Optional system prompt (applies to all)
    """
    tasks = args.get("tasks", [])
    if not tasks or not isinstance(tasks, list):
        return {"ok": False, "error": "tasks must be a non-empty list of strings"}
    if len(tasks) > _MAX_CONCURRENT:
        return {"ok": False, "error": f"Max {_MAX_CONCURRENT} parallel agents"}

    model = args.get("model", "claude-sonnet-4-6-20250514")
    system = args.get("system", "")

    t0 = time.time()
    futures = {}
    for i, task in enumerate(tasks):
        future = _executor.submit(_run_subagent, task, model=model, system=system,
                                  name=f"{args.get('name', 'agent')}-{i + 1}")
        futures[future] = {"index": i, "task": task[:100]}

    results = []
    for future in concurrent.futures.as_completed(futures, timeout=300):
        meta = futures[future]
        try:
            result = future.result()
            result["task_index"] = meta["index"]
            result["task_preview"] = meta["task"]
            results.append(result)
        except Exception as e:
            results.append({
                "ok": False,
                "error": str(e),
                "task_index": meta["index"],
                "task_preview": meta["task"],
            })

    # Sort by original task index
    results.sort(key=lambda r: r.get("task_index", 0))
    elapsed = round(time.time() - t0, 1)

    return {
        "ok": True,
        "results": results,
        "total_elapsed_sec": elapsed,
        "agent_count": len(tasks),
        "succeeded": sum(1 for r in results if r.get("ok")),
    }


# ── Export for init_brain.py ──────────────────────────────────────────

EXTRA_TOOLS = {
    "agent.spawn": agent_spawn,
    "agent.spawn_parallel": agent_spawn_parallel,
}
