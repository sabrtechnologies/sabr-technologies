"""Finite root-authored plans, reconciled by the existing action-cue watcher.

The plan is operator input, never a worker result or an LLM-generated plan.
Only explicit job identities are enrolled. No tool/API writes this authority.
Runtime receipts stay in the existing cue journal; no additional scheduler.
"""
import hashlib
import json
import os
from pathlib import Path
import time


def plan_path():
    from brain import action_cues as ac
    return Path(ac.STATE_DIR) / 'private_out/owner-goal-plan.json'


def load_plan():
    path = plan_path()
    try:
        stat = path.stat()
        if stat.st_uid != 0 or stat.st_mode & 0o022 or path.is_symlink():
            raise ValueError('owner plan must be root-owned and not group/world writable')
        plan = json.loads(path.read_text())
        if plan.get('authority') != 'owner-root' or plan.get('version') != 1:
            raise ValueError('invalid owner plan authority/version')
        return plan
    except FileNotFoundError:
        return {'goals': []}


def goals():
    # Explicit Leon-only admission, including direct calls outside watcher.start.
    from brain.identity import is_client_si
    if is_client_si() or os.environ.get('LEON_HOSTED_TENANT_ID'):
        return []
    return load_plan().get('goals', [])


def step_for(cue):
    for goal in goals():
        if goal.get('id') == cue.get('owner_goal'):
            for step in goal.get('steps', []):
                if step.get('id') == cue.get('owner_step'):
                    return goal, step
    return None, None


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def gate(cue):
    from brain import action_cues as ac
    goal, step = step_for(cue)
    if not goal or digest(step) != cue.get('owner_step_digest'):
        return 'root plan missing or changed; reconcile prior effects before a new plan'
    grant = cue.get('authorization') or {}
    expected = {k: goal.get(k) for k in ('owner_instruction', 'objective', 'checkpoint', 'provider', 'model', 'effort')}
    expected.update({k: step.get(k) for k in ('next_step', 'execution_location', 'folder', 'dependency')})
    if any(grant.get(k) != value for k, value in expected.items()):
        return 'cue authority differs from root plan; worker text cannot expand scope'
    if goal.get('paused'):
        return 'owner paused goal ' + str(goal['id'])
    if time.time() >= float(goal.get('expires_at', 0)):
        return 'owner goal budget expired; root must review remaining scope'
    if not goal.get('owner_instruction') or not goal.get('objective'):
        return 'root owner goal scope missing'
    if step.get('execution_location') not in ('laptop', 'vps'):
        return 'actual authorized execution host required'
    rows = [c for c in ac._load() if c.get('owner_goal') == goal['id']]
    last = max((float(c.get('started') or 0) for c in rows if c['id'] != cue['id']), default=0)
    if time.time() - last < ac.CUE_TURN_GAP_S:
        return 'owner goal durable cadence; wait for next bounded decision'
    attempts = sum(bool(c.get('decision_attempted')) for c in rows if c['id'] != cue['id'])
    # Reserve a child slot with each decision, including uncertain dispatches.
    for key in ('max_decisions', 'max_children'):
        limit = goal.get(key)
        if type(limit) is not int or limit < 1 or attempts >= limit:
            return 'owner goal ' + key + ' budget exhausted'
    return None


def _enroll(job_id, goal_id):
    from brain import action_cues as ac
    from server import coding_jobs
    existing = next((c for c in ac._load() if c.get('job_id') == job_id), None)
    if existing:
        return existing
    body = coding_jobs.job_result(job_id)
    job = body.get('job') or {}
    if body.get('ok') and job.get('job_id') == job_id and job.get('state') in (*ac.JOB_END_STATES, 'cancelled'):
        return ac.add_cue('Reconcile terminal step with owner goal ' + str(goal_id),
                          source='job', job_id=job_id, job_state=job['state'])
    return None


def reconcile():
    """Receipt -> parent reconciliation -> at most one bounded root decision.

    Never parse worker prose for authority or success. A failed dependency is
    retained; only an explicitly different root-planned dependency can follow.
    An exhausted plan leaves the objective open with its exact next dependency.
    """
    from brain import action_cues as ac
    from brain import job_followthrough as ft
    if ft.stop_reason():
        return
    for goal in goals():
        if not isinstance(goal.get('id'), str):
            continue
        rows = ac._load()
        owned = [c for c in rows if c.get('owner_goal') == goal['id']]
        # Failed reviews without dispatch can move to a DIFFERENT explicitly
        # approved dependency. Retain the original receipt and failed attempt.
        for step in goal.get('steps', []):
            parent = next((c for c in owned if c.get('owner_step') == step.get('after_step')), None)
            if (not parent or parent.get('status') != 'blocked' or parent.get('next_job_id')
                    or not step.get('changed_cause') or not step.get('dependency')
                    or step['dependency'] == parent_dependency(parent)
                    or any(c.get('owner_step') == step['id'] for c in owned)):
                continue
            # Unknown provider effects are never a failed-review retry signal.
            if parent.get('review_outcome') not in ('blocked', 'rejected'):
                continue
            identity = 'owner-' + digest([goal['id'], step['id']])[:24]
            if any(c['id'] == identity for c in rows):
                continue
            child = dict(parent, **ft.fields(identity), id=identity, status='open',
                         owner_step=None, authorization=None, parent_reconciled=time.time(),
                         parent_goal=goal['id'], changed_dependency_from=parent['id'])
            for key in ('started', 'closed', 'decision', 'review_outcome', 'provider_error'):
                child.pop(key, None)
            child['planned_after_step'] = step['after_step']
            with ac._lock:
                current = ac._load()
                if not any(c['id'] == identity for c in current):
                    ac._save(current + [child])
        watched = list(goal.get('observe_jobs', []))
        watched += [c['next_job_id'] for c in owned if c.get('next_job_id')]
        watched += [s['after_job'] for s in goal.get('steps', []) if s.get('after_job')]
        enrolled = [_enroll(job_id, goal['id']) for job_id in dict.fromkeys(watched)]
        enrolled += [c for c in ac._load() if c.get('parent_goal') == goal['id'] and c.get('planned_after_step') and not c.get('owner_step')]
        for cue in enrolled:
            if not cue or not cue.get('completion_receipt'):
                continue
            job_id = cue['job_id']
            parent = next((c for c in owned if c.get('next_job_id') == job_id or
                           (cue.get('planned_after_step') and c.get('owner_step') == cue['planned_after_step'])), None)
            receipt = cue['completion_receipt']
            if not cue.get('parent_reconciled'):
                ac._update([cue['id']], parent_goal=goal['id'], parent_reconciled=time.time(),
                           parent_request_id=parent.get('request_id') if parent else None,
                           objective_complete=False, parent_dependency=goal.get('next_dependency'))
            # Already enrolled grants and attempted decisions are never rearmed.
            if cue.get('owner_step') or cue.get('decision_attempted'):
                continue
            candidates = [s for s in goal.get('steps', [])
                          if (s.get('after_job') == job_id or
                              (parent and s.get('after_step') == parent.get('owner_step')))
                          and not any(c.get('owner_step') == s['id'] for c in owned)]
            failed = receipt.get('state') != 'done' or (parent and parent.get('review_outcome') in ('blocked', 'rejected'))
            step = next((s for s in candidates if not failed or
                         (s.get('changed_cause') and s.get('dependency') and
                          s['dependency'] != parent_dependency(parent))), None)
            if not step:
                reason = goal.get('next_dependency') or 'no useful root-authorized next step'
                if failed:
                    reason = 'failed unchanged attempt ' + job_id + ': ' + reason
                ac._update([cue['id']], status='blocked', blocker=reason,
                           objective_complete=False)
                continue
            grant = {k: goal[k] for k in ('owner_instruction', 'objective', 'checkpoint', 'provider')}
            grant.update(max_decisions=1, max_children=1, next_step=step['next_step'],
                         execution_location=step['execution_location'], folder=step['folder'],
                         model=goal['model'], effort=goal['effort'],
                         dependency=step['dependency'], owner_goal=goal['id'])
            ac._update([cue['id']], authorization=grant, owner_goal=goal['id'],
                       owner_step=step['id'], owner_step_digest=digest(step),
                       status='open', blocker='', next_step=step['next_step'])


def parent_dependency(parent):
    return ((parent or {}).get('authorization') or {}).get('dependency')


def snapshot():
    from brain import action_cues as ac
    rows = ac._load()
    return [{'id': g['id'], 'objective_complete': False,
             'next_dependency': g.get('next_dependency'),
             'max_decisions': g.get('max_decisions'), 'max_children': g.get('max_children'),
             'decisions_used': sum(bool(c.get('decision_attempted')) for c in rows if c.get('owner_goal') == g['id']),
             'reconciled_jobs': [c['job_id'] for c in rows if c.get('parent_goal') == g['id'] and c.get('parent_reconciled')]}
            for g in goals()]
