"""
Transparency log for reasoning chains.
Every time Leon makes a claim, log the reasoning steps.
This surfaces when steps are skipped.
"""

import json
from datetime import datetime
from pathlib import Path

def log_reasoning(claim: str, steps: list, confidence: float, actual_outcome: str = None):
    """
    Log a reasoning chain.
    steps: list of "I did X, which shows Y" entries
    actual_outcome: what actually happened (filled in later for learning)
    """
    entry = {
        "timestamp": datetime.now().isoformat(),
        "claim": claim,
        "reasoning_steps": steps,
        "stated_confidence": confidence,
        "actual_outcome": actual_outcome,
        "matches_claim": actual_outcome == "success" if actual_outcome else None
    }
    
    journal_file = Path("/opt/leon-brain/brain_state/reasoning_journal.jsonl")
    with open(journal_file, "a") as f:
        f.write(json.dumps(entry) + "\n")
    
    return entry

# Example of an unverified checkout claim:
example_bad = log_reasoning(
    claim="Clover checkout is now wired up and working",
    steps=[
        "I added NEXT_PUBLIC_PAYMENT_PROVIDER to the env",
        "I committed the change to git",
        "git log shows the commit exists"
    ],
    confidence=0.95,
    actual_outcome="failed"  # Added later when Dean said it still didn't work
)

print("✓ Reasoning journal initialized")
print("\nExample logged reasoning:")
print(json.dumps(example_bad, indent=2))
print("\n^ This shows the problem: 3 steps, all at MY layer (env → git → log)")
print("  Missing step: Actually fetch the live page and verify the bytes changed")
