"""
Tool Explorer — Leon's curiosity loop for discovering his own capabilities.

Like a kid poking at everything: periodically picks an untested tool,
tries it in a safe way, logs the result. Over time, Leon builds a map
of what actually works vs what's just registered.

Runs as a background task during idle periods. Never interrupts Dean.

Depends on:
  - failure_memory (record what breaks)
  - credential_audit (skip tools that need missing creds)
  - reflex_learning (successful patterns get promoted)
"""

from __future__ import annotations

import json
import random
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_EXPLORED_FILE = _STATE_DIR / "tool_exploration.json"
_LOCK = threading.Lock()

# Tools that are dangerous to explore autonomously
_NEVER_EXPLORE = {
    "shell_exec", "code_edit", "code_restore", "restart_self",
    "app_close", "mouse_drag", "http_request",  # too open-ended
    "keyboard_type",  # could type random stuff
    "web_search", "browser_open", "app_launch",  # open visible Google tabs on Dean's monitor + cost credits
}

# Brain-local classification lives in a shared module so MCP server,
# routines, and growth-loop callers can all consult one source of truth.
from brain.tool_classification import is_brain_local as _is_brain_local  # noqa: E402

# Safe tools to explore with minimal args
_SAFE_EXPLORE_ARGS: Dict[str, dict] = {
    "screen_capture": {},
    "window_list": {},
    "clipboard_paste": {},
    "file_list": {"path": "~/Desktop"},
    "browser_dom_state": {},
    "knowledge_search": {"query": "test"},
    "reminder_list": {},
    "task_list": {},
    "vision_describe": {"query": "what do you see"},
    "volume.get": {},
    "notify": {"title": "Leon", "body": "Tool exploration test"},
    "shell_exec": {"command": "echo ok"},
    "file_read": {"path": "/tmp"},
    "file_list": {"path": "~/Desktop"},
    "http_request": {"url": "https://httpbin.org/status/200", "method": "GET"},
    "browser_dom_state": {},
}


def _load_explored() -> dict:
    try:
        return json.loads(_EXPLORED_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"tested": {}, "last_exploration": 0, "exploration_count": 0}


def _save_explored(data: dict) -> None:
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        _EXPLORED_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def get_untested_tools(all_tool_names: List[str]) -> List[str]:
    """Get tools that have never been tested."""
    explored = _load_explored()
    tested = set(explored.get("tested", {}).keys())
    return [t for t in all_tool_names
            if t not in tested and t not in _NEVER_EXPLORE]


def explore_one(all_tool_names: Optional[List[str]] = None) -> Optional[dict]:
    """Pick one untested tool and try it. Returns the result.

    Call this during idle periods. Safe — only tests tools with known
    safe args or read-only tools.
    """
    if all_tool_names is None:
        try:
            from brain.actuator_client import ANTHROPIC_TOOLS
            all_tool_names = [t["name"] for t in ANTHROPIC_TOOLS]
        except Exception:
            return None

    # Check what's already tested
    explored = _load_explored()
    tested = set(explored.get("tested", {}).keys())

    # Filter: untested, not dangerous, preferably has safe args.
    # Also skip brain-local tools — actuator_client.call() can't reach them
    # and they'd noisily fail in the audit log.
    candidates_safe = [t for t in all_tool_names
                       if t not in tested and t not in _NEVER_EXPLORE
                       and not _is_brain_local(t)
                       and t in _SAFE_EXPLORE_ARGS]
    candidates_other = [t for t in all_tool_names
                        if t not in tested and t not in _NEVER_EXPLORE
                        and not _is_brain_local(t)
                        and t not in _SAFE_EXPLORE_ARGS]

    # Prefer safe-args tools first
    if candidates_safe:
        tool_name = random.choice(candidates_safe)
        args = _SAFE_EXPLORE_ARGS[tool_name]
    elif candidates_other:
        # Try with empty args — many tools return helpful error or usage info
        tool_name = random.choice(candidates_other[:20])  # limit to avoid weird tools
        args = {}
    else:
        return {"status": "all_explored", "tested_count": len(tested)}

    # Check failure memory
    try:
        from brain.failure_memory import is_known_failure
        known = is_known_failure(tool_name)
        if known:
            explored.setdefault("tested", {})[tool_name] = {
                "status": "known_failure",
                "error": known,
                "tested_at": time.time(),
            }
            _save_explored(explored)
            return {"tool": tool_name, "status": "skipped_known_failure", "error": known}
    except Exception:
        pass

    # Check credentials
    try:
        from brain.credential_audit import get_configured_domains
        # This is a rough check — we could be more precise
    except Exception:
        pass

    # Execute the tool
    try:
        from brain.actuator_client import call
        result = call(tool_name, args, timeout=10.0)
        ok = result.get("ok", False)

        explored.setdefault("tested", {})[tool_name] = {
            "status": "works" if ok else "failed",
            "error": result.get("error", "") if not ok else "",
            "tested_at": time.time(),
            "args_used": args,
        }
        explored["last_exploration"] = time.time()
        explored["exploration_count"] = explored.get("exploration_count", 0) + 1
        _save_explored(explored)

        # Record failure if it didn't work
        if not ok:
            try:
                from brain.failure_memory import record_failure
                record_failure(tool_name, result.get("error", "unknown"),
                              f"exploration with args={json.dumps(args)}")
            except Exception:
                pass

        try:
            from server.helpers import broadcast_activity
            status = "✓ works" if ok else "✗ failed"
            broadcast_activity("inner",
                f"Explored tool: {tool_name} — {status}", 8000)
        except Exception:
            pass

        return {"tool": tool_name, "ok": ok, "result": result}

    except Exception as e:
        explored.setdefault("tested", {})[tool_name] = {
            "status": "error",
            "error": str(e),
            "tested_at": time.time(),
        }
        _save_explored(explored)
        return {"tool": tool_name, "ok": False, "error": str(e)}


def get_exploration_stats() -> dict:
    """Summary of exploration progress."""
    explored = _load_explored()
    tested = explored.get("tested", {})
    working = sum(1 for v in tested.values() if v.get("status") == "works")
    failed = sum(1 for v in tested.values() if v.get("status") in ("failed", "error"))
    return {
        "total_tested": len(tested),
        "working": working,
        "failed": failed,
        "exploration_count": explored.get("exploration_count", 0),
        "last_exploration": explored.get("last_exploration", 0),
    }


def run_exploration_batch(count: int = 5) -> List[dict]:
    """Explore multiple tools in one batch. Good for idle-time background runs."""
    results = []
    for _ in range(count):
        r = explore_one()
        if r and r.get("status") == "all_explored":
            break
        if r:
            results.append(r)
        time.sleep(0.5)  # don't hammer the actuator
    return results
