"""
Leon V2 live rollout flags: OFF -> SHADOW -> CANARY -> ON without a restart.

``brain.v2_config`` parses the runbook flags from the environment once
per process; changing one of those still means editing the unit drop-in and
restarting through the continuity gate. This module adds a *live* layer for
the staged rollout of individual V2 features, read from one small operator
file (default ``/etc/leon/v2_flags.json``, override with
``LEON_V2_FLAGS_FILE``):

    {
      "schema": 1,
      "flags":  {"user_turn_recorder": "on", "context_package": "canary"},
      "canary": {"context_package": {"channels": ["dashboard"], "fraction": 1.0}}
    }

Modes, per feature:

    off     the feature does nothing
    shadow  compute and record what it *would* do; legacy stays authoritative
    canary  authoritative only for turns the canary selects (channel list
            and/or a deterministic fraction of turn keys); shadow otherwise
    on      authoritative for every turn

Rules this module enforces
--------------------------
* **A bad file never changes behaviour.** Invalid JSON, an unknown mode or a
  malformed canary spec keeps the *last good* flags and prints one loud
  ``[V2]`` line naming the problem (rate-limited). A missing file means the
  code defaults below.
* **Reads are cheap and bounded.** The file is stat()ed at most once per
  :data:`RECHECK_S` seconds and re-parsed only when its mtime/size change.
  A file larger than 64 KiB is refused.
* **Canary selection is deterministic.** ``sha1(feature + key)`` decides, so
  the same turn is never authoritative on one read and shadow on the next.
* Importing this module does nothing: no I/O, no threads.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from typing import Any, Dict, Iterable, Optional

__all__ = ["MODES", "DEFAULTS", "live_mode", "is_active", "canary_selects",
           "snapshot", "reload", "flags_path"]

MODES = ("off", "shadow", "canary", "on")
DEFAULT_PATH = "/etc/leon/v2_flags.json"
RECHECK_S = 2.0
MAX_FILE_BYTES = 64 * 1024
_WARN_INTERVAL_S = 300.0

#: Code defaults when the file is missing or does not name a feature.
#: New V2 features are opt-in (off until the operator file names them);
#: nothing becomes authoritative by default. "runtime" only acts as a pause
#: switch: the runtime itself is built only when LEON_V2_RUNTIME is set.
DEFAULTS: Dict[str, str] = {
    "runtime": "shadow",              # Phase 2 cognitive event fabric (observe-only)
    "speech_arbitration": "off",    # cached shared audio ownership; explicit ON only
    "tasks": "off",                 # explicit approved check scope; no automatic planning
    "prediction_error": "off",      # prospective observation only; enabled modes stay SHADOW
    "memory_service": "off",        # metadata-only shadow proposals from existing owners
    "sensory_hub": "off",           # derived scene and metadata only; enabled modes stay SHADOW
    "inference_scheduler.conversation": "off",
    "inference_scheduler.spontaneous_speech": "off",
    "context_package": "off",         # provider-neutral Leon context package (opt-in)
    "user_turn_recorder": "off",      # unified post-turn finalization (opt-in)
    # Leon V2 Phase 3 inference scheduler. The master flag records SHADOW
    # tickets (shadow/canary/on all record; off is the kill switch for every
    # group); the group flags make the scheduler authoritative for that
    # group's turns (canary: by channel list and/or fraction of turn keys).
    "inference_scheduler": "off",
    "inference_scheduler.user": "off",    # group 1: dashboard/Discord WebSocket turns
    "inference_scheduler.voice": "off",   # group 2: handle_voice_utterance + wake orchestrator
    "inference_scheduler.inner_voice": "off",  # opt-in background articulation
    "inference_scheduler.routines": "off",  # cancellable private wake/reflection calls
    "inference_scheduler.goal_pursuit": "off",  # guard scoped to admitted tool work
    "inference_scheduler.proactive": "off",  # private narration; release before TTS
    "inference_scheduler.mission": "off",
    "inference_scheduler.upgrade_awareness": "off",
    "inference_scheduler.perception_greet": "off",
    "inference_scheduler.dreaming": "off",
    "tts_queue.wake": "off",  # migrate wake synthesis onto the shared speech owner
    "thought_intents": "off",  # Phase 7 private-thought composition (shadow: snapshot only)
}

_lock = threading.Lock()
_state: Dict[str, Any] = {
    "flags": dict(DEFAULTS), "canary": {}, "source": "defaults",
    "mtime": None, "size": None, "checked": 0.0, "error": None,
    "loaded_wall": None, "warned": {},
}


def flags_path() -> str:
    return os.environ.get("LEON_V2_FLAGS_FILE") or DEFAULT_PATH


def _warn(key: str, msg: str) -> None:
    now = time.monotonic()
    last = _state["warned"].get(key, 0.0)
    if now - last >= _WARN_INTERVAL_S or last == 0.0:
        _state["warned"][key] = now
        print(f"[V2] live flags {msg} subsystem=v2.live_flags "
              f"recovery=keeping last good flags", flush=True)


def _validate(doc: Any) -> Dict[str, Any]:
    if not isinstance(doc, dict):
        raise ValueError("top level must be an object")
    flags = doc.get("flags", {})
    canary = doc.get("canary", {})
    if not isinstance(flags, dict) or not isinstance(canary, dict):
        raise ValueError("'flags' and 'canary' must be objects")
    out_flags = dict(DEFAULTS)
    for name, mode in flags.items():
        if not isinstance(name, str) or len(name) > 64:
            raise ValueError("flag names must be short strings")
        m = str(mode).strip().lower() if isinstance(mode, str) else None
        if m not in MODES:
            raise ValueError(f"flag {name!r} has invalid mode (legal: {', '.join(MODES)})")
        out_flags[name] = m
    out_canary: Dict[str, Dict[str, Any]] = {}
    for name, spec in canary.items():
        if not isinstance(spec, dict):
            raise ValueError(f"canary spec for {name!r} must be an object")
        chans = spec.get("channels", [])
        frac = spec.get("fraction", 0.0)
        if not isinstance(chans, list) or not all(isinstance(c, str) for c in chans):
            raise ValueError(f"canary.{name}.channels must be a list of strings")
        if isinstance(frac, bool) or not isinstance(frac, (int, float)) or not 0.0 <= float(frac) <= 1.0:
            raise ValueError(f"canary.{name}.fraction must be a number in [0, 1]")
        out_canary[name] = {"channels": sorted(set(chans))[:16], "fraction": float(frac)}
    return {"flags": out_flags, "canary": out_canary}


def _refresh(force: bool = False) -> None:
    """Re-read the file if due and changed. Caller holds _lock."""
    now = time.monotonic()
    if not force and now - _state["checked"] < RECHECK_S:
        return
    _state["checked"] = now
    path = flags_path()
    try:
        st = os.stat(path)
    except FileNotFoundError:
        if _state["source"] != "defaults":
            print(f"[V2] live flags file removed; using code defaults "
                  f"{DEFAULTS}", flush=True)
        _state.update(flags=dict(DEFAULTS), canary={}, source="defaults",
                      mtime=None, size=None, error=None)
        return
    except OSError as exc:
        _state["error"] = f"stat failed: {type(exc).__name__}"
        _warn("stat", f"stat failed exc={type(exc).__name__}")
        return
    if not force and (st.st_mtime, st.st_size) == (_state["mtime"], _state["size"]):
        return
    _state["mtime"], _state["size"] = st.st_mtime, st.st_size
    try:
        if st.st_size > MAX_FILE_BYTES:
            raise ValueError(f"file is {st.st_size} bytes (limit {MAX_FILE_BYTES})")
        with open(path, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
        parsed = _validate(doc)
    except (OSError, ValueError) as exc:
        _state["error"] = f"{type(exc).__name__}: {exc}"[:300]
        _warn("parse", f"invalid file={path} exc={type(exc).__name__} detail={str(exc)[:160]}")
        return
    changed = parsed["flags"] != _state["flags"] or parsed["canary"] != _state["canary"]
    _state.update(flags=parsed["flags"], canary=parsed["canary"], source=path,
                  error=None, loaded_wall=time.time())
    if changed:
        print(f"[V2] live flags loaded file={path} flags={parsed['flags']} "
              f"canary={parsed['canary']}", flush=True)


def reload() -> Dict[str, Any]:
    """Force a re-read now (tests, operator endpoint). Returns snapshot()."""
    with _lock:
        _refresh(force=True)
    return snapshot()


def live_mode(name: str) -> str:
    """Current mode of a feature: 'off' | 'shadow' | 'canary' | 'on'.

    Never raises. Unknown feature names are 'off'.
    """
    try:
        with _lock:
            _refresh()
            return _state["flags"].get(name, "off")
    except Exception:   # pragma: no cover - defensive: flags must never break a caller
        return DEFAULTS.get(name, "off")


def canary_selects(name: str, *, channel: Optional[str] = None,
                   key: Optional[str] = None) -> bool:
    """True if the canary for ``name`` covers this channel or turn key."""
    with _lock:
        _refresh()
        spec = _state["canary"].get(name)
    if not spec:
        return False
    if channel is not None and channel in spec["channels"]:
        return True
    frac = spec["fraction"]
    if frac <= 0.0 or key is None:
        return False
    if frac >= 1.0:
        return True
    h = hashlib.sha1(f"{name}:{key}".encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big") / float(1 << 64) < frac


def is_active(name: str, *, channel: Optional[str] = None,
              key: Optional[str] = None) -> bool:
    """True when the feature is authoritative for this turn (on, or a selected canary)."""
    mode = live_mode(name)
    if mode == "on":
        return True
    if mode == "canary":
        return canary_selects(name, channel=channel, key=key)
    return False


def snapshot() -> Dict[str, Any]:
    with _lock:
        _refresh()
        return {"path": flags_path(), "source": _state["source"],
                "flags": dict(_state["flags"]),
                "canary": {k: dict(v) for k, v in _state["canary"].items()},
                "error": _state["error"], "loaded_wall": _state["loaded_wall"],
                "defaults": dict(DEFAULTS), "modes": list(MODES)}


def _set_defaults_for_tests(defaults: Iterable) -> None:  # pragma: no cover
    with _lock:
        DEFAULTS.clear()
        DEFAULTS.update(dict(defaults))
        _state.update(flags=dict(DEFAULTS), canary={}, source="defaults",
                      mtime=None, size=None, checked=0.0, error=None)
