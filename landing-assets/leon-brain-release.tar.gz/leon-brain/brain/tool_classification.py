"""
Brain-local vs actuator tool classification — single source of truth.

A tool is *brain-local* when its implementation lives in the brain server
process (responder.local_tools) and there is no actuator-side equivalent.
Sending a brain-local tool to the PC actuator socket gets "unknown tool"
back — wasting a round-trip, polluting the audit log, and (for the
exploration loop) marking a perfectly good tool as broken in failure
memory.

Callers that may dispatch tools to the actuator should check
`is_brain_local(name)` first and route brain-local tools through the
brain server's `/api/leon/tool` path instead.

Implementation: at import time, scan every brain module that registers
an `EXTRA_TOOLS` dict and collect the leading dot-prefix of each tool
name. Convert to underscore form (e.g. "memory.mood_recent_trend" →
prefix "memory_"). Lookup is O(1) per name against a frozenset.

Auto-scan beats hand-maintained lists because new integration modules
are added often (today's audit log surfaced discord_, slack_, audio_record_,
docgen_, github_cicd_, … that a hand-list missed). Drift cost: zero.

Trade-off: some prefixes ambiguously cover actuator-side tools too
(task_, time_, file_, code_). A false positive means a tool gets
classified brain-local when it actually lives on the actuator —
callers will route it via the brain server, which in turn calls the
actuator and returns the same result. Slightly slower, never wrong.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import FrozenSet


def _scan_brain_local_prefixes() -> FrozenSet[str]:
    """Build the brain-local prefix set from EXTRA_TOOLS dicts in brain/
    modules. Called once at import time.

    Scans every `brain/*.py` file at root plus every `brain/integrations/*.py`.
    Picks up eager-loaded modules (memory_extras, introspection, …) AND
    lazy-loaded ones at the brain/ root (self_improve, macros, autopilot)
    AND every integration. Any future EXTRA_TOOLS dict gets included
    automatically as long as it lives somewhere in brain/."""
    prefixes: set[str] = set()
    here = Path(__file__).resolve().parent
    candidates: list[Path] = []
    # Every .py at brain/ root (eager + lazy + future).
    candidates.extend(sorted(here.glob("*.py")))
    # Plus every .py under brain/integrations/.
    integrations_dir = here / "integrations"
    if integrations_dir.is_dir():
        candidates.extend(sorted(integrations_dir.glob("*.py")))
    # LHS of EXTRA_TOOLS dict entries: "ns.tool_name":
    pat = re.compile(r'"([a-z][a-z0-9_]*)\.[a-z][a-z0-9_]*"\s*:')
    for f in candidates:
        # Skip this file itself — no risk of self-referential pollution
        if f.name == "tool_classification.py":
            continue
        try:
            content = f.read_text(encoding="utf-8")
        except Exception:
            continue
        # Only consider files that actually declare EXTRA_TOOLS to avoid
        # false positives from unrelated dotted-string literals.
        if "EXTRA_TOOLS" not in content:
            continue
        for match in pat.findall(content):
            prefixes.add(match + "_")
    return frozenset(prefixes)


BRAIN_LOCAL_PREFIXES: FrozenSet[str] = _scan_brain_local_prefixes()

# SELF-REVIEW FIND (2026-08-21): the self-mod tool set — shell_exec,
# http_request, code_edit, code_restore, restart_self — is registered in
# server/init_brain.py as BARE names (local_tools["shell_exec"] = ...), not
# under an "ns.tool_name" EXTRA_TOOLS entry. The regex-based prefix scan
# above only ever matches dotted names, so none of these five were ever in
# BRAIN_LOCAL_PREFIXES. Every call fell through to the actuator fast path
# first, got "unknown tool: shell_exec" back from the actuator (it never
# had these bound), and that got recorded as a tool_health FAILURE before
# falling through to the correct brain-local path on retry — logged live:
# shell_exec at 9,689 calls / 5,114 successes / status=broken, entirely
# from this false-positive path, even though the tool itself works fine.
# Hand-list them since there's no dotted prefix to auto-scan for.
_BARE_BRAIN_LOCAL_NAMES: FrozenSet[str] = frozenset({
    "shell_exec", "http_request", "code_edit", "code_restore", "restart_self",
})


def is_brain_local(tool_name: str) -> bool:
    """Return True if `tool_name` is dispatched by the brain server,
    not the PC actuator. Accepts both underscore form
    (`memory_mood_recent_trend`) and dot form (`memory.mood_recent_trend`)."""
    if not tool_name:
        return False
    if tool_name in _BARE_BRAIN_LOCAL_NAMES:
        return True
    # Dot form: convert to underscore prefix for the lookup
    normalized = tool_name.replace(".", "_")
    return any(normalized.startswith(p) for p in BRAIN_LOCAL_PREFIXES)
