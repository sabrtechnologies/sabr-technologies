"""
Leon V2 Phase 5 (runbook 9.1): the SensoryHub, in SHADOW.

One canonical, bounded record of what Leon's senses reported, built from the
drivers that already work: vision_daemon, audio_daemon, the PC sensor relay
routes, the dashboard webcam push and perception_floors. The hub never
captures anything and never holds media. An observation carries a short
reference (``content_ref``), a hash, a few JSON-safe features and at most a
caption-sized summary. Raw capture stays where the hardware integration
already works.

Live flag ``sensory_hub`` (``brain.v2_live_flags``), default ``off``:

    off     ingest() and request_focus() return at once; nothing is recorded.
    shadow  observations are deduplicated, kept in bounded rings and applied
            to the SceneModel, and meaningful scene changes are offered to the
            V2 event fabric (itself observe-only). Legacy perception stays
            authoritative for everything it does today.
    canary, on
            not implemented in Phase 5; they behave exactly like shadow.

Rules this module keeps
-----------------------
* ``ingest()`` is fail-open and non-blocking: it never raises, waits at most
  :data:`LOCK_TIMEOUT_S` for a lock, and does no file or network I/O. The
  SceneModel's disk writes happen on its own persister thread.
* Rings are bounded (:data:`RING_SIZES`). Dedupe state and publish gates are
  bounded too.
* Deduplication works on source ids, source timestamps and content hashes, and
  frame streams are coalesced per physical sensor. That way one physical
  frame or relay event becomes one observation however many dashboards
  forward it.
* No media: bytes, buffers, array-likes, data URIs and long base64-looking
  strings are refused (whole observation for summary or reference, and the
  single key for a feature). Adapters hash frames on their side.
* Legacy code reaches this module only through
  ``sys.modules.get("brain.sensory_hub")``. Until the hub is installed, an
  adapter costs one dict lookup.
* Importing this module does nothing: no I/O, no threads.
"""
from __future__ import annotations

import hashlib
import copy
import itertools
import logging
import math
import re
import threading
import time
from collections import OrderedDict, deque
from dataclasses import dataclass
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

log = logging.getLogger("leon.v2.sensory")

__all__ = ["SensorObservation", "SensoryHub", "FLAG", "SITE_ID", "MODALITIES",
           "RING_SIZES", "install", "uninstall", "get_hub", "enabled", "ingest",
           "request_focus", "note_adapter_failure", "install_default"]

FLAG = "sensory_hub"
#: The hub's publisher site id in brain.cognition.v2_publish.SITES.
SITE_ID = "sensory_hub.change"
MODES = ("off", "shadow", "canary", "on")
MODALITIES = ("screen", "webcam", "audio", "telemetry")
RING_SIZES: Dict[str, int] = {"screen": 120, "webcam": 120, "audio": 500, "telemetry": 500}

LOCK_TIMEOUT_S = 0.005
DEDUPE_ID_TTL_S = 600.0          # a source id / source timestamp is unique for 10 min
DEDUPE_HASH_TTL_S = 10.0         # identical content from one source within 10 s is a repeat
MAX_DEDUPE_KEYS = 4096
SUMMARY_MAX_CHARS = 240
FEATURE_STR_MAX = 160
FEATURE_LIST_MAX = 32
FEATURE_KEYS_MAX = 32
ID_MAX_CHARS = 96
REF_MAX_CHARS = 160
MEDIA_STR_MIN = 256              # longer base64-looking strings are media
PUBLISH_SALIENCE = 0.5
PUBLISH_MIN_INTERVAL_S = 5.0     # per (entity, field)
PUBLISH_REPEAT_HOLD_S = 300.0    # the same value is not republished within 5 min
MAX_PUBLISH_KEYS = 512
FOCUS_MAX = 64
FOCUS_TTL_MIN_S = 0.5
FOCUS_TTL_MAX_S = 120.0
FAIL_LOG_INTERVAL_S = 60.0

#: (modality, kind) -> (min_interval_s, heartbeat_s).
#: min_interval: a second observation on the stream sooner than this is folded
#: into the previous one, whatever it says. Frame streams are keyed per
#: physical sensor (modality), so N dashboards pushing the same camera do not
#: multiply observations.
#: heartbeat: an observation whose signature equals the stream's last one is
#: recorded at most this often (a stable scene is not re-recorded every tick).
STREAM_POLICY: Dict[Tuple[str, str], Tuple[float, float]] = {
    ("webcam", "frame"): (2.5, 2.5),
    ("screen", "frame"): (2.0, 30.0),
    ("webcam", "caption"): (0.0, 60.0),
    ("screen", "caption"): (0.0, 60.0),
    ("audio", "level"): (1.0, 30.0),
    ("audio", "scene"): (1.0, 30.0),
    ("telemetry", "floors"): (5.0, 60.0),
}
#: Default confidence per kind when the adapter gives none. Captions come from
#: a cheap local captioner that knowledge_store already treats as low-trust.
DEFAULT_CONFIDENCE = {"caption": 0.5, "transcript": 0.7, "scene": 0.6, "level": 0.8}
SOURCE_MAX_AGE_S = {"screen": 120.0, "webcam": 120.0, "audio": 60.0, "telemetry": 120.0}

_WS = re.compile(r"\s+")
_B64ISH = re.compile(r"[A-Za-z0-9+/=_\-\r\n]+")
_HEX = re.compile(r"[0-9a-fA-F]{6,64}")


class _Media(Exception):
    """A value that looks like raw media. Refused, never stored."""


_DROP = object()


# ----------------------------------------------------------------------
# the observation


@dataclass(frozen=True)
class SensorObservation:
    observation_id: str
    modality: str
    source: str
    created_wall: float
    created_mono: float
    content_ref: str | None
    features: dict
    summary: str
    confidence: float
    change_score: float

    def to_dict(self) -> Dict[str, Any]:
        return {"observation_id": self.observation_id, "modality": self.modality,
                "source": self.source, "created_wall": self.created_wall,
                "created_mono": self.created_mono, "content_ref": self.content_ref,
                "features": copy.deepcopy(self.features), "summary": self.summary,
                "confidence": self.confidence, "change_score": self.change_score}


# ----------------------------------------------------------------------
# value hygiene (pure)


def _is_media_obj(v: Any) -> bool:
    if isinstance(v, (bytes, bytearray, memoryview)):
        return True
    if isinstance(v, (str, int, float, bool)) or v is None:
        return False
    return (hasattr(v, "__array_interface__") or hasattr(v, "__array__")
            or hasattr(v, "tobytes") or hasattr(v, "getbuffer") or hasattr(v, "read"))


def _is_media_str(s: str) -> bool:
    if s[:5].lower() == "data:" and ";base64," in s[:80]:
        return True
    return len(s) >= MEDIA_STR_MIN and _B64ISH.fullmatch(s[:4096]) is not None


def _is_media(v: Any) -> bool:
    if isinstance(v, str):
        return _is_media_str(v)
    return _is_media_obj(v)


def _finite(x: Any, nd: int = 6) -> Optional[float]:
    if isinstance(x, bool) or x is None:
        return None
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return round(f, nd) if math.isfinite(f) else None


def _clamp01(x: Any, default: float) -> float:
    f = _finite(x)
    if f is None:
        return default
    return min(1.0, max(0.0, f))


def _clip_id(x: Any, n: int) -> Optional[str]:
    if x is None or isinstance(x, bool):
        return None
    if isinstance(x, float) and not math.isfinite(x):
        return None
    if _is_media(x):
        raise _Media("identifier")
    if not isinstance(x, (str, int, float)):
        return None
    s = _WS.sub(" ", str(x)[:max(256, n * 4)]).strip()
    return s[:n] or None


def _clean_summary(x: Any) -> str:
    if x is None:
        return ""
    if _is_media(x):
        raise _Media("summary")
    s = (x if isinstance(x, str) else str(x))[:4096]
    s = s.encode("utf-8", "replace").decode("utf-8")
    return _WS.sub(" ", s).strip()[:SUMMARY_MAX_CHARS]


def _clean_hash(x: Any) -> Optional[str]:
    if not isinstance(x, str):
        return None
    x = x.strip()
    return x.lower() if _HEX.fullmatch(x) else None


def _scalar(v: Any) -> Any:
    """JSON scalar or _DROP. Raises _Media for media-like values."""
    if v is None or isinstance(v, bool):
        return v
    if isinstance(v, int):
        return v if abs(v) < 2 ** 53 else None
    if isinstance(v, float):
        return round(v, 6) if math.isfinite(v) else None
    if isinstance(v, str):
        if _is_media_str(v):
            raise _Media("feature string")
        return v[:FEATURE_STR_MAX]
    # numpy-style scalars: shape () and .item(); an array has a real shape
    if getattr(v, "shape", None) == () and hasattr(v, "item"):
        try:
            return _scalar(v.item())
        except _Media:
            raise
        except Exception:
            return _DROP
    if _is_media_obj(v):
        raise _Media("feature object")
    return _DROP


def _clean_features(features: Any) -> Tuple[Dict[str, Any], int]:
    """Allow-list JSON: scalars, short lists of scalars, one level of dict.
    Returns (features, media_dropped)."""
    out: Dict[str, Any] = {}
    dropped = 0
    if not isinstance(features, dict):
        return out, 0
    for k, v in itertools.islice(features.items(), FEATURE_KEYS_MAX * 2):
        if len(out) >= FEATURE_KEYS_MAX:
            break
        if not isinstance(k, str) or not k:
            continue
        key = k[:32]
        try:
            if isinstance(v, (list, tuple, set, frozenset)):
                items = list(itertools.islice(iter(v), FEATURE_LIST_MAX))
                if isinstance(v, (set, frozenset)):
                    items.sort(key=str)
                vals = []
                for item in items[:FEATURE_LIST_MAX]:
                    c = _scalar(item)
                    if c is not _DROP:
                        vals.append(c)
                out[key] = vals
            elif isinstance(v, dict):
                sub = {}
                for sk, sv in itertools.islice(v.items(), 16):
                    if isinstance(sk, str):
                        c = _scalar(sv)
                        if c is not _DROP:
                            sub[sk[:32]] = c
                out[key] = sub
            else:
                c = _scalar(v)
                if c is not _DROP:
                    out[key] = c
        except _Media:
            dropped += 1
    return out, dropped


def rms_level(rms: Any) -> Optional[str]:
    """Coarse acoustic level from relayed mic RMS. Thresholds follow the legacy
    gates: 0.005 relay injection floor, 0.015 audio_daemon speech energy."""
    r = _finite(rms)
    if r is None:
        return None
    if r < 0.005:
        return "silence"
    if r < 0.015:
        return "quiet"
    if r < 0.1:
        return "active"
    return "loud"


def caption_turnover(prev: Optional[str], cur: str) -> float:
    """Word-set turnover between consecutive captions (same rule as io_routes)."""
    a = set((prev or "").lower().split())
    b = set((cur or "").lower().split())
    if not a:
        return 0.6 if b else 0.0
    if not b:
        return 0.0
    return 1.0 - len(a & b) / max(1, len(a | b))


def _sha(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", "surrogatepass")).hexdigest()[:16]


def _bucket(x: Any, edges: Tuple[float, ...]) -> Optional[int]:
    f = _finite(x)
    if f is None:
        return None
    return sum(1 for e in edges if f >= e)


def _floors_parts(f: Dict[str, Any]) -> Tuple[Any, ...]:
    b = _finite(f.get("ambient_brightness"))
    return (f.get("owner_present"), f.get("activity_mode"), f.get("active_app"),
            f.get("expression"), None if b is None else round(b, 1),
            tuple(sorted(str(o) for o in (f.get("room_objects") or []))),
            _bucket(f.get("cpu_percent"), (50.0, 80.0)),
            _bucket(f.get("memory_percent"), (80.0, 90.0)),
            f.get("net_connected"), f.get("vision_wired"), f.get("audio_wired"))


# ----------------------------------------------------------------------
# the hub


class SensoryHub:
    """Bounded, deduplicated observation store in front of a SceneModel.

    ``scene`` is any object with ``apply(observation) -> list[dict]`` (the
    SceneModel). ``mode_fn`` returns the live mode, normally
    ``v2_live_flags.live_mode("sensory_hub")``. ``wall`` and ``mono`` are
    injectable clocks for tests.
    """

    def __init__(self, scene: Any = None, *, mode_fn: Optional[Callable[[], str]] = None,
                 wall: Callable[[], float] = time.time,
                 mono: Callable[[], float] = time.monotonic,
                 ring_sizes: Optional[Dict[str, int]] = None,
                 source_confidence: Optional[Dict[Tuple[str, str], float]] = None,
                 publish: bool = True) -> None:
        sizes = dict(RING_SIZES)
        if ring_sizes:
            sizes.update({k: int(v) for k, v in ring_sizes.items() if k in sizes})
        self._scene = scene
        self._mode_fn = mode_fn or (lambda: "off")
        self._wall = wall
        self._mono = mono
        self._publish_enabled = bool(publish)
        self._source_confidence = dict(source_confidence or {})
        self._rings: Dict[str, Deque[SensorObservation]] = {
            m: deque(maxlen=max(1, n)) for m, n in sizes.items()}
        self._lock = threading.Lock()
        self._seq = itertools.count(1)
        self._seen: "OrderedDict[tuple, float]" = OrderedDict()
        self._stream_last: Dict[tuple, Tuple[float, Any, Any]] = {}
        self._prev_summary: Dict[Tuple[str, str], str] = {}
        self._pub_last: Dict[Tuple[str, str], Tuple[float, str]] = {}
        self._pub_pending: "OrderedDict[tuple, tuple]" = OrderedDict()
        self._source_watermarks: "OrderedDict[tuple, float]" = OrderedDict()
        self._published: Deque[Dict[str, Any]] = deque(maxlen=64)
        self._focus: Deque[Dict[str, Any]] = deque(maxlen=FOCUS_MAX)
        self._focus_seq = itertools.count(1)
        self._counters: Dict[str, int] = {}
        self._fail_last: Dict[str, float] = {}
        self._mode_seen: Optional[str] = None
        self._ingests = 0

    # -- plumbing --------------------------------------------------------

    @property
    def scene(self) -> Any:
        return self._scene

    def _count(self, name: str, n: int = 1) -> None:
        if len(self._counters) < 128 or name in self._counters:
            self._counters[name] = self._counters.get(name, 0) + n

    def _note_failure(self, where: str, exc: BaseException) -> None:
        self._count("failures")
        self._count("failures." + where[:40])
        now = self._mono()
        last = self._fail_last.get(where)
        if last is not None and now - last < FAIL_LOG_INTERVAL_S:
            return
        if len(self._fail_last) > 64:
            self._fail_last.clear()
        self._fail_last[where] = now
        log.warning("[V2] sensory hub %s failed trace_id=- subsystem=v2.sensory exc=%s "
                    "recovery=observation dropped; legacy perception unaffected",
                    where, type(exc).__name__)

    def mode(self) -> str:
        """Live mode. Never raises; anything unexpected reads as 'off'."""
        try:
            m = str(self._mode_fn() or "off").strip().lower()
        except Exception:
            return "off"
        if m not in MODES:
            m = "off"
        if m != self._mode_seen:
            self._mode_seen = m
            if m in ("canary", "on"):
                log.warning("[V2] sensory hub mode=%s is not implemented in Phase 5 "
                            "trace_id=- subsystem=v2.sensory exc=- recovery=running SHADOW "
                            "(legacy perception stays authoritative)", m)
            else:
                log.info("[V2] sensory hub mode=%s", m)
        return m

    def enabled(self) -> bool:
        return self.mode() != "off"

    # -- ingest ----------------------------------------------------------

    def ingest(self, modality: Any, source: Any, *, kind: Any = "observation",
               summary: Any = "", features: Any = None, confidence: Any = None,
               change_score: Any = None, content_ref: Any = None,
               content_hash: Any = None, source_ts: Any = None,
               source_id: Any = None) -> Optional[SensorObservation]:
        """Record one observation. Returns it, or None when it was dropped
        (off, duplicate, coalesced, refused or failed). Never raises."""
        mode = self.mode()
        if mode == "off":
            self._count("skipped_off")
            return None
        mode = "shadow"  # This candidate never grants perception authority.
        try:
            obs = self._ingest(modality, source, kind, summary, features, confidence,
                               change_score, content_ref, content_hash, source_ts, source_id)
        except _Media:
            self._count("media_rejected")
            return None
        except Exception as exc:
            self._note_failure("ingest", exc)
            return None
        if obs is None:
            return None
        changes: List[Dict[str, Any]] = []
        if self._scene is not None:
            try:
                changes = list(self._scene.apply(obs) or [])
                self._count("scene_applied")
            except Exception as exc:
                self._note_failure("scene_apply", exc)
                changes = []
        if changes and self._publish_enabled:
            try:
                self._maybe_publish(obs, changes, mode)
            except Exception as exc:
                self._note_failure("publish_gate", exc)
        self.flush_pending()
        return copy.deepcopy(obs)

    def ingest_batch(self, observations, *, limit=64):
        """Process a bounded metadata batch; never materialize an unbounded input."""
        result = []
        for fields in itertools.islice(observations, max(0, min(64, int(limit)))):
            if isinstance(fields, dict):
                obs = self.ingest(**fields)
                if obs is not None:
                    result.append(obs)
        return result

    def _ingest(self, modality, source, kind, summary, features, confidence,
                change_score, content_ref, content_hash, source_ts, source_id):
        m = str(modality or "").strip().lower()
        if m not in self._rings:
            self._count("rejected_modality")
            return None
        src = _clip_id(source, 48) or "unknown"
        k = _clip_id(kind, 24) or "observation"
        text = _clean_summary(summary)
        ref = _clip_id(content_ref, REF_MAX_CHARS)
        sid = _clip_id(source_id, ID_MAX_CHARS)
        if _is_media(content_hash):
            raise _Media("content_hash")
        chash = _clean_hash(content_hash)
        sts = _finite(source_ts, 3)
        feats, dropped = _clean_features(features)
        if dropped:
            self._count("media_dropped_features", dropped)
        cap = _clamp01(self._source_confidence.get((src, k)), DEFAULT_CONFIDENCE.get(k, 1.0))
        conf = min(cap, _clamp01(confidence, cap))

        parts: Any = None
        if m == "audio" and k == "level":
            feats["level"] = rms_level(feats.get("rms"))
            sig: Any = feats["level"]
        elif m == "audio" and k == "scene":
            sig = feats.get("scene") or text or None
        elif k == "frame":
            sig = chash
        elif k == "floors":
            parts = _floors_parts(feats)
            sig = parts
        elif text:
            sig = _sha(text.lower())
        else:
            sig = None

        content_key = chash or (_sha(text + "|" + str(feats.get("text_sha1") or ""))
                                if (text or feats.get("text_sha1")) else None)
        keys: List[Tuple[tuple, float, str]] = []
        if sid:
            keys.append((("id", m, k, sid), DEDUPE_ID_TTL_S, "dedup_id"))
        if sts is not None:
            keys.append((("ts", m, k, src, sts, content_key), DEDUPE_ID_TTL_S, "dedup_ts"))
        if content_key and k != "floors" and (k == "frame" or not (sid or sts is not None)):
            # Frames are identified by decoded bytes across dashboard/daemon
            # paths. A new timestamp/ID on an identical caption is new evidence.
            hash_source = "physical" if k == "frame" else src
            keys.append((("hash", m, k, hash_source, content_key), DEDUPE_HASH_TTL_S, "dedup_hash"))

        stream = (m, k) if k == "frame" else (m, k, src)
        min_iv, heartbeat = STREAM_POLICY.get((m, k), (0.0, 0.0))

        if not self._lock.acquire(timeout=LOCK_TIMEOUT_S):
            self._count("lock_timeout")
            return None
        try:
            now = self._mono()
            wall = self._wall()
            if sts is not None:
                watermark_key = (m, k, src)
                previous = self._source_watermarks.get(watermark_key)
                if wall - sts > SOURCE_MAX_AGE_S[m] or sts - wall > 5.0:
                    self._count("stale_source")
                    return None
                if previous is not None and sts < previous:
                    self._count("out_of_order")
                    return None
            self._ingests += 1
            self._purge(now)
            for key, _ttl, counter in keys:
                exp = self._seen.get(key)
                if exp is not None and exp > now:
                    self._count(counter)
                    return None
            last = self._stream_last.get(stream)
            retain = True
            if last is not None:
                dt = now - last[0]
                if min_iv > 0 and dt < min_iv:
                    self._count("coalesced")
                    retain = False
                if heartbeat > 0 and sig is not None and sig == last[1] and dt < heartbeat:
                    self._count("stable_suppressed")
                    retain = False

            cs = _finite(change_score)
            if cs is not None:
                cs = min(1.0, max(0.0, cs))
            elif k == "frame":
                cs = 0.0
            elif k == "caption":
                cs = round(caption_turnover(self._prev_summary.get((m, src)), text), 4)
            elif last is None:
                cs = 1.0
            elif parts is not None and isinstance(last[2], tuple) and len(last[2]) == len(parts):
                cs = round(sum(1 for a, b in zip(last[2], parts) if a != b) / len(parts), 4)
            else:
                cs = 0.0 if sig is not None and sig == last[1] else 1.0

            seq = next(self._seq)
            oid = f"{m}-{int(wall * 1000)}-{seq}"
            feats["kind"] = k
            if sts is not None:
                feats["source_ts"] = sts
            if sid:
                feats["source_id"] = sid
            if chash:
                feats["content_sha1"] = chash
            if ref is None and k == "frame":
                ref = f"{m}:{src}:" + (sid or (f"sha1={chash}" if chash else f"seq={seq}"))
            obs = SensorObservation(
                observation_id=oid, modality=m, source=src,
                created_wall=round(wall, 6), created_mono=round(now, 6),
                content_ref=ref, features=feats, summary=text,
                confidence=round(conf, 4), change_score=cs)
            if retain:
                self._rings[m].append(obs)
            else:
                self._count("scene_only")
            for key, ttl, _c in keys:
                self._seen[key] = now + ttl
                self._seen.move_to_end(key)
            while len(self._seen) > MAX_DEDUPE_KEYS:
                self._seen.popitem(last=False)
            if sts is not None:
                self._source_watermarks[watermark_key] = sts
                self._source_watermarks.move_to_end(watermark_key)
                while len(self._source_watermarks) > 256:
                    self._source_watermarks.popitem(last=False)
            if retain:
                self._stream_last[stream] = (now, sig, parts)
            if len(self._stream_last) > 256:
                self._stream_last.clear()
                self._stream_last[stream] = (now, sig, parts)
            if k == "caption":
                if len(self._prev_summary) > 256:
                    self._prev_summary.clear()
                self._prev_summary[(m, src)] = text
            self._count("ingested")
            self._count("ingested." + m)
            return obs
        finally:
            self._lock.release()

    def _purge(self, now: float) -> None:
        seen = self._seen
        if len(seen) <= MAX_DEDUPE_KEYS and self._ingests % 256:
            return
        for key in [k for k, exp in seen.items() if exp <= now]:
            del seen[key]
        while len(seen) > MAX_DEDUPE_KEYS:
            seen.popitem(last=False)

    # -- publishing -----------------------------------------------------

    def _maybe_publish(self, obs: SensorObservation, changes: List[Dict[str, Any]],
                       mode: str) -> bool:
        """A meaningful scene change is offered to the V2 fabric; a stable scene
        is not. Gated per (entity, field): at most one per PUBLISH_MIN_INTERVAL_S,
        and the same value is never republished within PUBLISH_REPEAT_HOLD_S."""
        salient = [c for c in changes if isinstance(c, dict)
                   and (_finite(c.get("salience")) or 0.0) >= PUBLISH_SALIENCE]
        if not salient:
            self._count("scene_silent")
            return False
        if not self._lock.acquire(timeout=LOCK_TIMEOUT_S):
            self._count("publish_lock_timeout")
            return False
        fresh: List[Dict[str, Any]] = []
        try:
            now = self._mono()
            for c in salient:
                key = (str(c.get("entity_id"))[:64], str(c.get("field"))[:32])
                new_r = repr(c.get("new"))[:80]
                last = self._pub_last.get(key)
                if last is not None:
                    if now - last[0] < PUBLISH_MIN_INTERVAL_S:
                        self._count("publish_rate")
                        self._pub_pending[key] = (obs, dict(c), mode)
                        self._pub_pending.move_to_end(key)
                        while len(self._pub_pending) > MAX_PUBLISH_KEYS:
                            self._pub_pending.popitem(last=False)
                        continue
                    if last[1] == new_r and now - last[0] < PUBLISH_REPEAT_HOLD_S:
                        self._count("publish_repeat")
                        self._pub_pending.pop(key, None)
                        continue
                if len(self._pub_last) >= MAX_PUBLISH_KEYS and key not in self._pub_last:
                    self._pub_last.clear()
                self._pub_last[key] = (now, new_r)
                self._pub_pending.pop(key, None)
                fresh.append(dict(c))
        finally:
            self._lock.release()
        if not fresh:
            return False
        self._published.append({"observation_id": obs.observation_id, "modality": obs.modality,
                                "source": obs.source, "wall": obs.created_wall, "mode": mode,
                                "changes": fresh})
        self._count("publish_decisions")
        return self._emit(obs, fresh, mode)

    def flush_pending(self) -> int:
        """Deliver latest debounced changes on the integration tick (no thread)."""
        if not self.enabled() or not self._lock.acquire(timeout=LOCK_TIMEOUT_S):
            return 0
        ready = []
        try:
            now = self._mono()
            for key, item in list(self._pub_pending.items()):
                last = self._pub_last.get(key)
                if last is None or now - last[0] >= PUBLISH_MIN_INTERVAL_S:
                    ready.append(item)
                    del self._pub_pending[key]
        finally:
            self._lock.release()
        count = 0
        for obs, change, mode in ready:
            count += int(self._maybe_publish(obs, [change], mode))
        return count

    def _emit(self, obs: SensorObservation, changes: List[Dict[str, Any]], mode: str) -> bool:
        try:  # Leon V2 Phase 5 publisher site (shadow fabric): observe-only, never affects perception
            import sys as _v2_sys
            _v2 = _v2_sys.modules.get("brain.cognition.v2_publish")
            if _v2 is None:
                self._count("publish_no_runtime")
                return False
            if SITE_ID not in getattr(_v2, "SITES", {}):
                self._count("publish_unwired")
                return False
            ok = _v2.emit("sensory_hub.change", observation=obs, changes=changes, mode=mode)
            self._count("publish_emitted" if ok else "publish_refused")
            return bool(ok)
        except Exception as _v2_exc:
            self._note_failure("publish", _v2_exc)
            return False

    # -- active vision (9.4), recorded only -------------------------------

    def request_focus(self, source: Any, region: Any = None, reason: Any = "",
                      ttl: Any = 10.0) -> Optional[Dict[str, Any]]:
        """Record that something wants a closer look. Phase 5 only records the
        request: nothing is captured, cropped or queried, and no provider is
        called. Returns the record (a copy) or None when the hub is off."""
        mode = self.mode()
        if mode == "off":
            self._count("focus_skipped_off")
            return None
        mode = "shadow"
        try:
            reg: Dict[str, Any] = {}
            if isinstance(region, dict):
                for key in ("x", "y", "w", "h"):
                    v = _finite(region.get(key), 4)
                    if v is not None and v >= 0:
                        reg[key] = v
                for key in ("monitor", "label", "entity_id"):
                    v = region.get(key)
                    if isinstance(v, (int, str)) and not isinstance(v, bool) and not _is_media(v):
                        reg[key] = v if isinstance(v, int) else str(v)[:64]
            t = _finite(ttl) or 10.0
            t = min(FOCUS_TTL_MAX_S, max(FOCUS_TTL_MIN_S, t))
            wall, now = self._wall(), self._mono()
            rec = {"focus_id": f"focus-{int(wall * 1000)}-{next(self._focus_seq)}",
                   "source": _clip_id(source, 48) or "unknown", "region": reg,
                   "reason": _clean_summary(reason)[:120], "ttl_s": round(t, 3),
                   "created_wall": round(wall, 6), "expires_wall": round(wall + t, 6),
                   "created_mono": round(now, 6), "mode": mode,
                   "status": "recorded_shadow", "acted": False}
            self._focus.append(rec)
            self._count("focus_recorded")
            return copy.deepcopy(rec)
        except _Media:
            self._count("media_rejected")
            return None
        except Exception as exc:
            self._note_failure("request_focus", exc)
            return None

    def focus_requests(self, active_only: bool = True) -> List[Dict[str, Any]]:
        now = self._mono()
        return [copy.deepcopy(r) for r in list(self._focus)
                if not active_only or r["created_mono"] + r["ttl_s"] > now]

    # -- read side ------------------------------------------------------

    def observations(self, modality: Optional[str] = None, *, limit: Optional[int] = None,
                     since_mono: Optional[float] = None) -> List[SensorObservation]:
        """Oldest first. Observations are frozen; the list is a copy."""
        mods = [modality] if modality else list(self._rings)
        out: List[SensorObservation] = []
        for m in mods:
            ring = self._rings.get(m)
            if ring is not None:
                out.extend(list(ring))
        if since_mono is not None:
            out = [o for o in out if o.created_mono > since_mono]
        if modality is None:
            out.sort(key=lambda o: o.created_mono)
        if limit is not None:
            count = max(0, int(limit))
            out = out[-count:] if count else []
        return copy.deepcopy(out)

    def latest(self, modality: str) -> Optional[SensorObservation]:
        ring = self._rings.get(modality)
        try:
            return copy.deepcopy(ring[-1]) if ring else None
        except IndexError:
            return None

    def stats(self) -> Dict[str, Any]:
        return {"mode": self.mode(), "counters": dict(self._counters),
                "effective_mode": "shadow" if self.enabled() else "off",
                "rings": {m: {"len": len(r), "max": r.maxlen} for m, r in self._rings.items()},
                "dedupe_keys": len(self._seen), "focus_requests": len(self._focus)}

    def snapshot(self) -> Dict[str, Any]:
        out = self.stats()
        out["latest"] = {m: (o.to_dict() if o is not None else None)
                         for m, o in ((m, self.latest(m)) for m in self._rings)}
        out["published"] = copy.deepcopy(list(self._published)[-10:])
        out["focus"] = self.focus_requests(active_only=False)[-10:]
        scene = self._scene
        if scene is not None and hasattr(scene, "snapshot"):
            try:
                out["scene"] = scene.snapshot()
            except Exception as exc:
                self._note_failure("scene_snapshot", exc)
                out["scene"] = None
        return out


# ----------------------------------------------------------------------
# module-level API used by the adapters (reached through sys.modules)

_hub: Optional[SensoryHub] = None
_install_lock = threading.RLock()
_orphan_failures: Dict[str, int] = {}


def install(hub: SensoryHub) -> SensoryHub:
    global _hub
    with _install_lock:
        if _hub is not None and _hub is not hub and not uninstall(flush=True):
            raise RuntimeError("previous scene persister is still running")
        _hub = hub
    return hub


def uninstall(flush: bool = True) -> bool:
    """Detach the installed hub and stop its scene persister (flushing it)."""
    global _hub
    with _install_lock:
        current = _hub
        scene = getattr(current, "scene", None)
        if scene is not None and hasattr(scene, "stop_persister"):
            try:
                if scene.stop_persister(flush=flush) is False:
                    return False
            except Exception as exc:
                log.warning("[V2] sensory hub persister stop failed trace_id=- subsystem=v2.sensory "
                            "exc=%s recovery=retaining hub for shutdown retry", type(exc).__name__)
                return False
        _hub = None
        return True


def get_hub() -> Optional[SensoryHub]:
    return _hub


def enabled() -> bool:
    hub = _hub
    return hub is not None and hub.enabled()


def ingest(modality: Any, source: Any, **fields: Any) -> Optional[SensorObservation]:
    hub = _hub
    if hub is None:
        return None
    try:
        return hub.ingest(modality, source, **fields)
    except Exception as exc:   # e.g. an unexpected keyword from an adapter
        hub._note_failure("ingest_call", exc)
        return None


def request_focus(source: Any, region: Any = None, reason: Any = "",
                  ttl: Any = 10.0) -> Optional[Dict[str, Any]]:
    hub = _hub
    if hub is None:
        return None
    return hub.request_focus(source, region, reason, ttl)


def note_adapter_failure(site: Any, exc: Any = None) -> None:
    """Adapters call this from their except clause. Never raises."""
    try:
        name = str(site)[:40]
        hub = _hub
        if hub is not None:
            hub._note_failure("adapter." + name,
                              exc if isinstance(exc, BaseException) else RuntimeError(str(exc)))
        elif len(_orphan_failures) < 64 or name in _orphan_failures:
            _orphan_failures[name] = _orphan_failures.get(name, 0) + 1
    except Exception:
        pass


def install_default(state_dir: Optional[str] = None, *, start_persister: bool = True,
                    mode_fn: Optional[Callable[[], str]] = None,
                    persist_interval_s: float = 5.0) -> SensoryHub:
    """Build the production hub + SceneModel and install it. Boot-time only
    (it reads the scene file). Replaces, and flushes, any previous hub."""
    with _install_lock:
        from brain.scene_model import SceneModel, default_path
        if mode_fn is None:
            from brain import v2_live_flags as _live

            def mode_fn() -> str:
                return _live.live_mode(FLAG)
        if _hub is not None:
            if not uninstall(flush=True):
                raise RuntimeError("previous scene persister is still running")
        scene = SceneModel(default_path(state_dir))
        hub = SensoryHub(scene=scene, mode_fn=mode_fn)
        if start_persister:
            scene.start_persister(interval_s=persist_interval_s)
        install(hub)
        log.info("[V2] sensory hub installed mode=%s scene=%s entities=%d",
                 hub.mode(), scene.path, len(scene.state().entities))
        return hub
