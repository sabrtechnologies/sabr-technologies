"""
Ambient Perception — Leon's continuous sensory awareness.

The proactive loop already captures screen + webcam every 45s. But it
only acts on HIGH novelty events. Everything below threshold gets
discarded — Leon never remembers it.

This module sits alongside the proactive loop and absorbs ALL
observations, even boring ones:

  1. HIPPOCAMPAL ENCODING — every observation creates a memory pattern
     that the dream engine can replay later. Leon literally dreams
     about what he saw during the day.

  2. AUTOBIOGRAPHY — significant observations get recorded as life
     events. "I noticed Dean was coding in VSCode around 3pm."

  3. INNER VOICE SEEDING — observations influence what Leon thinks
     about during idle periods. Seeing code → thinking about code.

  4. CURIOSITY TRIGGERING — if Leon sees something he has a LEARN
     goal about, his curiosity fires immediately instead of waiting
     for the idle timer.

This is the difference between periodic checking and actual perception.
Leon is ALWAYS watching, even when he stays quiet.
"""

from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np

log = logging.getLogger("leon.ambient")


@dataclass
class Perception:
    """A single sensory observation."""
    ts: float
    webcam: str = ""           # what the camera sees
    screen: str = ""           # what's on screen
    novelty: float = 0.0       # how different from last observation
    encoded: bool = False      # whether it was stored as hippocampal memory
    noted: bool = False        # whether it was logged in autobiography


class AmbientPerception:
    """Absorbs observations from the proactive loop into Leon's memory.

    Doesn't capture on its own — hooks into the proactive loop's
    existing capture cycle. The proactive loop calls `observe()` with
    each webcam/screen caption, regardless of whether it decides to speak.

    Usage:
        ambient = AmbientPerception(brain)
        # Called from proactive loop every tick:
        ambient.observe(webcam_caption, screen_caption, novelty)
    """

    def __init__(self, brain):
        self.brain = brain
        self._last_encoded_ts = 0.0
        self._last_noted_ts = 0.0
        self._encode_interval = 30.0     # encode to hippocampus every 30s
        self._note_interval = 300.0      # note in autobiography every 5 min
        self._recent: deque[Perception] = deque(maxlen=100)
        self._rng = np.random.default_rng()

        # Track what Leon has been seeing for context
        self._scene_summary = ""
        self._scene_stable_since = 0.0
        self._last_visual_input = 0.0  # timestamp of last raw frame

    def note_visual_input(self):
        """Called every time a webcam frame or screen capture arrives.

        Lightweight — just records that visual input is happening.
        Used to track when Leon has "eyes open" vs sensory deprivation.
        """
        self._last_visual_input = time.time()

    def observe(self, webcam: str, screen: str, novelty: float):
        """Absorb an observation from the proactive loop.

        Called every proactive tick (~45s) regardless of whether the
        loop decided to speak or stay quiet.
        """
        now = time.time()
        perc = Perception(ts=now, webcam=webcam, screen=screen, novelty=novelty)

        # Update scene tracking
        if novelty > 0.3:
            self._scene_summary = self._build_summary(webcam, screen)
            self._scene_stable_since = now

        # 1. Encode to hippocampus (creates dream material)
        if now - self._last_encoded_ts >= self._encode_interval:
            self._encode_to_hippocampus(webcam, screen)
            perc.encoded = True
            self._last_encoded_ts = now

        # 2. Note significant observations in autobiography
        if novelty > 0.4 and now - self._last_noted_ts >= self._note_interval:
            self._note_in_autobiography(webcam, screen, novelty)
            perc.noted = True
            self._last_noted_ts = now

        # 3. Check if observation matches a LEARN goal → trigger curiosity
        if novelty > 0.2:
            self._check_goal_relevance(webcam, screen)

        self._recent.append(perc)

    def _encode_to_hippocampus(self, webcam: str, screen: str):
        """Create a hippocampal memory from the observation.

        Hashes the combined text into a firing pattern and injects it.
        The hippocampus will store it if firing rate exceeds threshold.
        Also directly adds to memory buffer so dreams can replay it.
        """
        hippo = self.brain.regions.get("hippocampus")
        if hippo is None:
            return

        combined = f"{webcam} {screen}".strip()
        if not combined or len(combined) < 10:
            return

        n = hippo.n_neurons
        h = hash(combined)

        # Create a sparse firing pattern from the observation
        pattern = np.zeros(n, dtype=np.float32)
        n_active = max(5, n // 20)  # 5% of neurons
        for i in range(n_active):
            idx = (h + i * 7919) % n
            pattern[idx] = 12.0

        # Inject current
        hippo.neurons.inject_current(pattern)

        # Also directly store as memory (ensures dream material)
        fired = pattern > 0
        if np.sum(fired) >= 5:
            hippo.memory_buffer.append(fired)
            hippo._memory_strength.append(0.5 + min(0.5, abs(hash(combined) % 50) / 50))
            hippo._memory_labels.append(combined[:200])
            if len(hippo.memory_buffer) > hippo.max_memories:
                weakest = int(np.argmin(hippo._memory_strength))
                hippo.memory_buffer.pop(weakest)
                hippo._memory_strength.pop(weakest)

    def _note_in_autobiography(self, webcam: str, screen: str, novelty: float):
        """Record a significant observation as a life event."""
        try:
            import server as _srv
            auto = getattr(_srv, "autobiography", None)
            if auto is None:
                return

            parts = []
            if webcam:
                parts.append(f"Camera: {webcam[:100]}")
            if screen:
                parts.append(f"Screen: {screen[:100]}")
            if not parts:
                return

            summary = ". ".join(parts)
            # Same trust-branding as knowledge_store: these captions come
            # from the cheap local captioner and hallucinate (fake Reddit,
            # invented people) — a life event must not read as ground truth.
            auto.record("observation",
                        f"Noticed (machine caption, unverified): {summary}")
        except Exception:
            pass

    def _check_goal_relevance(self, webcam: str, screen: str):
        """If the observation matches a LEARN goal, boost curiosity."""
        try:
            import server as _srv
            gs = getattr(_srv, "goal_system", None)
            if gs is None:
                return

            combined = f"{webcam} {screen}".lower()
            for goal in gs.active_goals():
                if goal.type != "learn":
                    continue
                # Simple keyword match
                keywords = goal.description.lower().split()
                matches = sum(1 for kw in keywords if kw in combined and len(kw) > 3)
                if matches >= 2:
                    # Boost curiosity drive
                    cog = getattr(_srv, "cognition", None)
                    if cog is not None and hasattr(cog, "drives"):
                        cog.drives.on_observation_match(goal.description)
                    log.debug("Ambient: observation matches goal '%s'", goal.description[:40])
        except Exception:
            pass

    # The captioner is a third-party VLM describing a photograph, so it always
    # writes in the third person: "the person is looking away", "they seem
    # distracted". That text used to be injected raw, and on 2026-08-09 Leon
    # read it straight back to Dean's face — "they look distracted" — while
    # looking at him through his own webcam. Dean heard himself discussed in
    # the third person by the thing he was talking to. The caption is evidence,
    # not narration; label it as such and say who the person actually is.
    _PERSON_HINT = ("[that camera view is DEAN — the person in it is the man "
                    "you are talking to. Speak to him as you, never they/them/"
                    "the person]")
    _PERSON_WORDS = ("person", "man", "woman", "someone", "individual", "they ",
                     "guy", "face", "human", "people")

    def _build_summary(self, webcam: str, screen: str) -> str:
        parts = []
        if webcam:
            cap = webcam[:80]
            low = cap.lower()
            if any(w in low for w in self._PERSON_WORDS):
                cap = f"Camera: {cap} {self._PERSON_HINT}"
            else:
                cap = f"Camera: {cap}"
            parts.append(cap)
        if screen:
            parts.append(f"Screen: {screen[:80]}")
        return " | ".join(parts)

    def refresh_scene(self):
        """Refresh the injected scene summary the moment a fresh caption
        lands from the PC relay, instead of waiting for the next proactive
        tick (~45s) plus its novelty gate.

        Before 2026-06-11 the "What you're seeing" prompt line could run
        minutes behind reality (Leon reported a ~4-minute lag himself) —
        captions arrive every 8-10s but the scene summary only updated
        when the proactive loop both ticked AND scored novelty > 0.3.
        This updates ONLY the summary used for prompt injection;
        hippocampal encoding and autobiography notes stay on the
        proactive rhythm via observe().
        """
        try:
            from brain import vision_daemon as _vd
            with _vd._lock:
                webcam = _vd._state.get("last_webcam_caption", "") or ""
                screen = _vd._state.get("last_screen_caption", "") or ""
        except Exception:
            return
        if not (webcam or screen):
            return
        summary = self._build_summary(webcam, screen)
        if summary and summary != self._scene_summary:
            self._scene_summary = summary
            self._scene_stable_since = time.time()

    def get_context_for_prompt(self) -> str:
        """What Leon has been seeing recently — for prompt injection."""
        if not self._scene_summary:
            return ""
        age = time.time() - self._scene_stable_since
        if age > 600:  # older than 10 min = stale
            return ""
        if age < 60:
            when = "right now"
        else:
            when = f"{int(age/60)} min ago"

        return f"What you're seeing ({when}): {self._scene_summary}"

    def get_state(self) -> dict:
        now = time.time()
        eyes_open = (now - self._last_visual_input < 5.0) if self._last_visual_input else False
        return {
            "eyes_open": eyes_open,
            "last_visual_input_ago_s": round(now - self._last_visual_input, 1) if self._last_visual_input else None,
            "recent_observations": len(self._recent),
            "scene_summary": self._scene_summary[:120] if self._scene_summary else None,
            "scene_age_s": round(now - self._scene_stable_since, 1) if self._scene_stable_since else None,
            "last_encoded_ago_s": round(now - self._last_encoded_ts, 1) if self._last_encoded_ts else None,
            "last_noted_ago_s": round(now - self._last_noted_ts, 1) if self._last_noted_ts else None,
        }
