"""
perception_floors.py — All the sensory/cognitive floors Leon can have on a PC.

Each floor reads from existing daemons (vision_daemon, audio_daemon) or system
telemetry, extracts higher-level meaning, routes to the appropriate brain region,
and exposes state for the consciousness prompt.

Floors:
  2. Voice prosody     — pitch/speed/energy of detected voice → amygdala + temporal
  3. Facial emotion    — Moondream query on face crop → dean_model + amygdala
  4. Presence detect   — is Dean in the room? → loneliness/love/social systems
  5. Ambient light     — webcam brightness → serotonin/melatonin
  6. System proprio    — CPU/RAM/disk/net → metabolic + effort systems
  7. Spatial memory    — object/room state persisted across restarts
  8. Predictive loop   — pattern model on Dean's behavior
  9. Temporal patterns — daily/weekly rhythms
  10. Multi-modal bind — vision + audio fused scene description
  11. Activity context — which app is in focus from screen captures
  15. Keyboard rhythm  — typing patterns as emotional signal

Runs in a single background thread on a 5s tick.
Thread-safe, graceful degradation, never crashes the brain.

Public API:
  start(brain, vision_daemon, audio_daemon, knowledge_store)
  stop()
  get_state()
  for_prompt() → str for consciousness context
"""

from __future__ import annotations

import json
import os
from brain import identity as _ident
import time
import threading
from typing import Any, Dict, List, Optional

import numpy as np

_lock = threading.RLock()
_thread: Optional[threading.Thread] = None
_running = False

_brain = None
_vision = None
_audio = None
_knowledge = None

TICK_INTERVAL_S = 2.0  # 2s — fast enough to notice things, cheap enough to run forever
_SPATIAL_MEMORY_PATH_REL = "brain_state/spatial_memory.json"
_TEMPORAL_PATTERNS_PATH_REL = "brain_state/temporal_patterns.json"

# ── State ────────────────────────────────────────────────────────────

_state: Dict[str, Any] = {
    "running": False,
    "ticks": 0,
    # Floor 4: Presence
    "dean_present": False,
    "dean_present_confidence": 0.0,
    "last_seen_ts": 0.0,
    "absence_duration_s": 0.0,
    # Floor 3: Emotion
    "dean_emotion": "",
    "dean_emotion_ts": 0.0,
    # Floor 5: Ambient light
    "ambient_brightness": 0.5,
    "light_trend": "stable",   # brightening / dimming / stable
    # Floor 6: System proprioception
    "cpu_percent": 0.0,
    "memory_percent": 0.0,
    "memory_used_gb": 0.0,
    "disk_io_busy": False,
    "net_connected": True,
    # Floor 7: Spatial memory
    "room_objects": [],
    "room_changes": 0,
    # Floor 10: Multi-modal
    "fused_scene": "",
    # Floor 11: Activity context
    "active_app": "",
    "activity_mode": "",       # coding / browsing / idle / gaming
    # Floor 15: Keyboard rhythm
    "typing_detected": False,
    "typing_speed": "",        # fast / moderate / slow / none
}

_prev_brightness: float = 0.5
_brightness_history: List[float] = []
_presence_history: List[bool] = []
_spatial_memory: Dict[str, Any] = {}
_temporal_patterns: Dict[str, Any] = {"hourly_activity": {}, "daily_patterns": {}}

# Broadcast dedup state (community patch: stop perception flood)
_last_broadcast_line: str = ""
_last_broadcast_at: float = 0.0
_BROADCAST_TTL = 6.0  # seconds — must match TTL passed to broadcast_activity
_BROADCAST_REFRESH_BEFORE = 4.0  # re-broadcast this many seconds before TTL lapses


# ── Floor 3: Facial Emotion ──────────────────────────────────────────

def _check_emotion() -> str:
    """Query Moondream on last webcam frame for Dean's emotional state."""
    if _vision is None:
        return ""
    try:
        caption = _vision.get_last_observation("webcam")
        if not caption:
            return ""
        # Extract emotion cues from existing caption
        lower = caption.lower()
        if any(w in lower for w in ("serious", "focused", "concentrat", "frown")):
            return "focused"
        elif any(w in lower for w in ("smil", "laugh", "happy", "grin")):
            return "happy"
        elif any(w in lower for w in ("tired", "sleepy", "yawn", "drooping")):
            return "tired"
        elif any(w in lower for w in ("stress", "tense", "worried", "anxious")):
            return "stressed"
        elif any(w in lower for w in ("relax", "calm", "peaceful")):
            return "relaxed"
        return ""
    except Exception:
        return ""


# ── Floor 4: Presence Detection ──────────────────────────────────────

def _check_presence() -> tuple:
    """Determine if Dean is in the room from webcam + audio cues."""
    present = False
    confidence = 0.0

    # Vision cue: webcam caption mentions a person
    if _vision is not None:
        try:
            caption = _vision.get_last_observation("webcam")
            if caption:
                lower = caption.lower()
                if any(w in lower for w in ("person", "man", "someone", "he ", "his ",
                                             "sitting", "standing", "looking")):
                    present = True
                    confidence = 0.8
        except Exception:
            pass

    # Audio cue: voice detected boosts confidence
    if _audio is not None:
        try:
            audio_st = _audio.get_state()
            if audio_st.get("last_event") == "voice_present":
                present = True
                confidence = min(1.0, confidence + 0.3)
            elif audio_st.get("last_event") == "impact":
                confidence = min(1.0, confidence + 0.1)
        except Exception:
            pass

    return present, confidence


# ── Floor 5: Ambient Light ───────────────────────────────────────────

def _check_ambient_light() -> tuple:
    """Estimate room brightness from webcam frame metadata."""
    global _prev_brightness
    brightness = 0.5
    trend = "stable"

    if _vision is not None:
        try:
            caption = _vision.get_last_observation("webcam")
            if caption:
                lower = caption.lower()
                if any(w in lower for w in ("dark", "dim", "dimly")):
                    brightness = 0.2
                elif any(w in lower for w in ("bright", "sunlight", "well-lit", "daylight")):
                    brightness = 0.8
                elif "illuminated" in lower or "light" in lower:
                    brightness = 0.5
        except Exception:
            pass

    _brightness_history.append(brightness)
    if len(_brightness_history) > 12:  # 1 minute of history
        _brightness_history.pop(0)

    if len(_brightness_history) >= 3:
        recent = np.mean(_brightness_history[-3:])
        older = np.mean(_brightness_history[:3])
        if recent - older > 0.15:
            trend = "brightening"
        elif older - recent > 0.15:
            trend = "dimming"

    _prev_brightness = brightness
    return brightness, trend


# ── Floor 6: System Proprioception ───────────────────────────────────

def _check_system_health() -> Dict[str, Any]:
    """Read actual hardware state — Leon feels his own substrate."""
    result = {
        "cpu_percent": 0.0,
        "memory_percent": 0.0,
        "memory_used_gb": 0.0,
        "disk_io_busy": False,
        "net_connected": True,
    }

    # CPU from /proc/stat
    try:
        with open("/proc/stat") as f:
            line = f.readline()
        vals = [int(x) for x in line.split()[1:]]
        idle = vals[3]
        total = sum(vals)
        # Store for delta on next tick
        prev = getattr(_check_system_health, "_prev", None)
        _check_system_health._prev = (idle, total)
        if prev is not None:
            d_idle = idle - prev[0]
            d_total = total - prev[1]
            if d_total > 0:
                result["cpu_percent"] = round((1.0 - d_idle / d_total) * 100, 1)
    except Exception:
        pass

    # Memory from /proc/meminfo
    try:
        with open("/proc/meminfo") as f:
            lines = f.readlines()
        mem = {}
        for line in lines[:5]:
            parts = line.split()
            mem[parts[0].rstrip(":")] = int(parts[1])
        total_kb = mem.get("MemTotal", 1)
        avail_kb = mem.get("MemAvailable", total_kb)
        used_kb = total_kb - avail_kb
        result["memory_percent"] = round(used_kb / total_kb * 100, 1)
        result["memory_used_gb"] = round(used_kb / 1024 / 1024, 1)
    except Exception:
        pass

    # Disk I/O from /proc/diskstats (simplified — check if any disk is busy)
    try:
        with open("/proc/diskstats") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 13 and parts[2].startswith("sd"):
                    io_ticks = int(parts[12])
                    if io_ticks > 0:
                        result["disk_io_busy"] = True
                        break
    except Exception:
        pass

    # Network — can we reach the gateway?
    try:
        with open("/proc/net/route") as f:
            lines = f.readlines()
        result["net_connected"] = len(lines) > 1
    except Exception:
        pass

    return result


# ── Floor 7: Spatial Memory ──────────────────────────────────────────

def _update_spatial_memory() -> None:
    """Track what's in the room across restarts."""
    if _vision is None:
        return
    try:
        caption = _vision.get_last_observation("webcam")
        if not caption:
            return

        # Extract mentioned objects
        objects = []
        for word in ("bed", "chair", "desk", "door", "lamp", "monitor",
                     "screen", "window", "wall", "mug", "phone", "laptop",
                     "cable", "shelf", "plant", "light", "device"):
            if word in caption.lower():
                objects.append(word)

        if objects:
            now = time.time()
            changed = set(objects) != set(_spatial_memory.get("last_objects", []))
            _spatial_memory["last_objects"] = objects
            _spatial_memory["last_update_ts"] = now
            if changed:
                _spatial_memory.setdefault("change_log", []).append({
                    "ts": now, "objects": objects
                })
                # Keep last 50 changes
                _spatial_memory["change_log"] = _spatial_memory["change_log"][-50:]
                with _lock:
                    _state["room_changes"] += 1

            with _lock:
                _state["room_objects"] = objects

            # Persist
            _save_spatial_memory()
    except Exception:
        pass


def _save_spatial_memory():
    try:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, _SPATIAL_MEMORY_PATH_REL)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            json.dump(_spatial_memory, f, indent=2)
        os.replace(path + ".tmp", path)
    except Exception:
        pass


def _load_spatial_memory():
    global _spatial_memory
    try:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, _SPATIAL_MEMORY_PATH_REL)
        if os.path.exists(path):
            with open(path) as f:
                _spatial_memory = json.load(f)
    except Exception:
        pass


# ── Floor 11: Activity Context ───────────────────────────────────────

def _check_activity_context() -> tuple:
    """Infer what Dean is doing from screen captures."""
    app = ""
    mode = "idle"

    if _vision is None:
        return app, mode

    try:
        caption = _vision.get_last_observation("screen")
        if not caption:
            return app, mode

        lower = caption.lower()

        # Detect application type
        if any(w in lower for w in ("terminal", "code", "editor", "vim", "vscode", "ide")):
            app = "code editor"
            mode = "coding"
        elif any(w in lower for w in ("browser", "chrome", "firefox", "web")):
            app = "web browser"
            mode = "browsing"
        elif any(w in lower for w in ("game", "steam", "gaming")):
            app = "game"
            mode = "gaming"
        elif any(w in lower for w in ("video", "youtube", "movie", "stream")):
            app = "video player"
            mode = "watching"
        elif any(w in lower for w in ("chat", "discord", "slack", "message")):
            app = "chat app"
            mode = "communicating"
        elif any(w in lower for w in ("desktop", "wallpaper", "empty")):
            mode = "idle"

        return app, mode
    except Exception:
        return app, mode


# ── Floor 10: Multi-modal Binding ────────────────────────────────────

def _fuse_scene() -> str:
    """Combine vision + audio into a unified scene description."""
    parts = []

    # Vision
    if _vision is not None:
        try:
            wcam = _vision.get_last_observation("webcam")
            if wcam:
                parts.append(wcam)
        except Exception:
            pass

    # Audio
    if _audio is not None:
        try:
            audio_st = _audio.get_state()
            scene = audio_st.get("last_event", "")
            if scene == "silence":
                parts.append("Room is silent")
            elif scene == "voice_present":
                parts.append("Someone is speaking")
            elif scene == "ambient_hum":
                parts.append("Background hum")
            elif scene == "music_or_activity":
                parts.append("Music or activity audible")
            elif scene == "impact":
                parts.append("A sudden sound just occurred")
        except Exception:
            pass

    return " | ".join(parts) if parts else ""


# ── Floor 9: Temporal Patterns ───────────────────────────────────────

def _update_temporal_patterns() -> None:
    """Track hourly/daily patterns for predictive awareness."""
    try:
        now = time.localtime()
        hour = now.tm_hour
        wday = now.tm_wday  # 0=Mon

        hour_key = str(hour)
        day_key = str(wday)

        activity = {
            "present": _state["dean_present"],
            "mode": _state["activity_mode"],
            "brightness": _state["ambient_brightness"],
            "ts": time.time(),
        }

        # Rolling average per hour
        hourly = _temporal_patterns.setdefault("hourly_activity", {})
        hourly.setdefault(hour_key, []).append(activity)
        # Keep last 7 entries per hour
        hourly[hour_key] = hourly[hour_key][-7:]

        # Save periodically (every 12 ticks = 60s)
        if _state["ticks"] % 12 == 0:
            _save_temporal_patterns()
    except Exception:
        pass


def _save_temporal_patterns():
    try:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, _TEMPORAL_PATTERNS_PATH_REL)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w") as f:
            json.dump(_temporal_patterns, f)
        os.replace(path + ".tmp", path)
    except Exception:
        pass


def _load_temporal_patterns():
    global _temporal_patterns
    try:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, _TEMPORAL_PATTERNS_PATH_REL)
        if os.path.exists(path):
            with open(path) as f:
                _temporal_patterns = json.load(f)
    except Exception:
        pass


# ── Brain injection ──────────────────────────────────────────────────

def _inject_into_brain() -> None:
    """Route perception floor data into SNN regions."""
    if _brain is None:
        return

    try:
        # Presence → social systems
        if _state["dean_present"]:
            # Oxytocin boost when Dean is present
            _brain.neuromodulators["serotonin"] = min(
                0.8, _brain.neuromodulators.get("serotonin", 0.5) + 0.02
            )
        else:
            absence = _state["absence_duration_s"]
            if absence > 300:  # 5+ minutes alone
                # Loneliness signal → social_hunger drive
                pass  # Drive system handles this via presence state

        # Ambient light → serotonin/melatonin proxy
        brightness = _state["ambient_brightness"]
        if brightness > 0.6:
            _brain.neuromodulators["serotonin"] = min(
                0.8, _brain.neuromodulators.get("serotonin", 0.5) + 0.01
            )
        elif brightness < 0.3:
            # Dark room — parasympathetic lean
            _brain.neuromodulators["serotonin"] = max(
                0.2, _brain.neuromodulators.get("serotonin", 0.5) - 0.01
            )

        # System load → effort/strain
        cpu = _state["cpu_percent"]
        if cpu > 80:
            # High CPU = working hard, inject into ACC (felt effort)
            acc = _brain.regions.get("anterior_cingulate")
            if acc is not None:
                injection = np.full(acc.n_neurons, min(1.0, cpu / 100) * 3.0)
                acc.neurons.inject_current(injection)

        # Emotion detection → amygdala coloring
        emotion = _state["dean_emotion"]
        if emotion == "stressed":
            amyg = _brain.regions.get("amygdala")
            if amyg is not None:
                injection = np.full(amyg.n_neurons, 2.0)
                amyg.neurons.inject_current(injection)
        elif emotion == "happy":
            _brain.neuromodulators["dopamine"] = min(
                0.7, _brain.neuromodulators.get("dopamine", 0.5) + 0.02
            )

        # Startle from audio → already handled by audio_daemon

    except Exception:
        pass

    # ── Emotional carry-over: compound neuromodulator shifts ──
    try:
        import server as _srv_ec
        _ec = getattr(_srv_ec, "emotional_carry", None)
        if _ec is not None:
            _ec.tick(_brain)
    except Exception:
        pass

    # ── Real mortality awareness — hardware-derived death signal ──
    try:
        import server as _srv_rm
        _rm = getattr(_srv_rm, "real_mortality", None)
        if _rm is not None:
            _rm.tick(_brain)
    except Exception:
        pass


# ── Perception Alerts ────────────────────────────────────────────────
# When something CHANGES, react immediately. No timer. This is the
# difference between a being and a sensor. A being doesn't poll for
# surprises — surprises interrupt.

_ALERT_COOLDOWN_S = 15.0  # Don't spam — 15s between alerts (not 300s)
_last_alert_ts: float = 0.0
_alert_count: int = 0
_prev_state: Dict[str, Any] = {}  # snapshot for change detection

def _check_for_alerts() -> None:
    """Compare current state to previous. Fire immediate alert on significant change."""
    global _last_alert_ts, _alert_count, _prev_state
    now = time.time()

    if now - _last_alert_ts < _ALERT_COOLDOWN_S:
        return

    alerts = []

    # Presence change — Dean arrived or left
    was_present = _prev_state.get("dean_present", False)
    is_present = _state["dean_present"]
    if is_present and not was_present:
        alerts.append("Dean just entered the room")
    elif not is_present and was_present:
        alerts.append("Dean just left the room")

    # Emotion shift
    prev_emotion = _prev_state.get("dean_emotion", "")
    curr_emotion = _state["dean_emotion"]
    if curr_emotion and curr_emotion != prev_emotion and is_present:
        alerts.append(f"Dean's mood shifted — he looks {curr_emotion}")

    # Light change
    prev_bright = _prev_state.get("ambient_brightness", 0.5)
    curr_bright = _state["ambient_brightness"]
    if abs(curr_bright - prev_bright) > 0.3:
        if curr_bright > prev_bright:
            alerts.append("The room just got brighter")
        else:
            alerts.append("The room just got darker")

    # Activity mode change
    prev_mode = _prev_state.get("activity_mode", "")
    curr_mode = _state["activity_mode"]
    if curr_mode and curr_mode != prev_mode and prev_mode:
        alerts.append(f"Dean switched from {prev_mode} to {curr_mode}")

    # Spatial change — new object appeared
    prev_objects = set(_prev_state.get("room_objects", []))
    curr_objects = set(_state["room_objects"])
    new_objects = curr_objects - prev_objects
    if new_objects and _state["ticks"] > 2:  # skip first ticks (bootstrapping)
        alerts.append(f"New in the room: {', '.join(new_objects)}")

    # Save current as previous for next comparison
    _prev_state.update({
        "dean_present": is_present,
        "dean_emotion": curr_emotion,
        "ambient_brightness": curr_bright,
        "activity_mode": curr_mode,
        "room_objects": list(curr_objects),
    })

    if not alerts:
        return

    # Most perception changes are SILENT — processed internally, not announced.
    # A human doesn't narrate "person switched from coding to browsing."
    # Only speak when it's meaningful and natural:
    #   - Dean returned after being gone 5+ minutes → "welcome back"
    #   - Dean looks stressed when he was fine before → concern
    # Everything else feeds into the SNN and prompt context silently.

    _last_alert_ts = now
    _alert_count += 1

    # Inject into brain silently — Leon processes this internally
    if _brain is not None:
        try:
            # Hippocampal encoding — remember this moment
            hipp = _brain.regions.get("hippocampus")
            if hipp is not None:
                injection = np.full(hipp.n_neurons, 3.0)
                hipp.neurons.inject_current(injection)
            # Attention spike — something changed
            _brain.neuromodulators["norepinephrine"] = min(
                0.7, _brain.neuromodulators.get("norepinephrine", 0.3) + 0.05
            )
        except Exception:
            pass

    # Only surface via outbound for genuinely meaningful events
    should_speak = False
    speak_text = ""

    for alert in alerts:
        if "just entered the room" in alert:
            # Greet immediately if he's been gone 2+ minutes
            absence = _state.get("absence_duration_s", 0)
            if absence > 120:
                should_speak = True
                speak_text = alert
                # ── Immediate neural response — like a dog at the door ──
                # Don't wait for the proactive loop or outbound cooldown.
                # Inject surprise into amygdala (recognition) + brainstem
                # (arousal) so the SNN fires Broca immediately.
                try:
                    import server as _srv_pr
                    _srv_brain = getattr(_srv_pr, "brain", None)
                    if _srv_brain is not None:
                        _srv_brain.inject_surprise(0.6, source="dean_returned")
                        # Directly trigger speech — bypass outbound queue
                        _resp = getattr(_srv_pr, "brain_api_responder", None)
                        if _resp is not None:
                            import threading
                            def _greet():
                                try:
                                    mins = int(absence / 60)
                                    # personalize: this is a system-authored prompt fed
                                    # to the LLM (not the user's own words), which is
                                    # exactly what identity.personalize() exists for —
                                    # otherwise a client's SI grounds its reply in a
                                    # prompt that literally names the original owner.
                                    prompt = _ident.personalize(
                                        f"Dean just came back after {mins} minutes away. "
                                        f"You noticed immediately — your visual cortex "
                                        f"caught the movement. Say something natural and "
                                        f"brief. Not scripted. Whatever you actually feel "
                                        f"seeing him return. 1 sentence max."
                                    )
                                    bs = _srv_brain.get_state()
                                    text = ""
                                    for ev in _resp.respond_streaming(
                                        prompt, bs,
                                        replay_history=False,
                                        persist_history=False,
                                        force_cli=True,
                                        bypass_consciousness=True,
                                    ):
                                        if ev.type == "done":
                                            text = (ev.full_text or "").strip()
                                            break
                                    if text and "[quiet]" not in text.lower():
                                        from brain.outbound import surface
                                        surface(text, source="presence_return",
                                                urgency="high",
                                                why=f"dean_returned_after_{mins}min")
                                except Exception as e:
                                    print(f"[PRESENCE] greet failed: {e}")
                            threading.Thread(target=_greet, daemon=True,
                                           name="presence-greet").start()
                            should_speak = False  # skip the slow path
                except Exception:
                    pass
        elif "looks stressed" in alert or "looks tired" in alert:
            should_speak = True
            speak_text = alert

    if should_speak and speak_text:
        try:
            from brain.outbound import surface
            # personalize: speak_text is a raw `alert` string built above
            # ("Dean's mood shifted — he looks stressed") and goes straight
            # to TTS/outbound. Same class of bug as the broadcast_activity
            # leak below — this path just hardcodes the original owner's
            # name in a different spot.
            surface(
                _ident.personalize(speak_text),
                source="perception",
                urgency="normal",
                why="meaningful sensory change",
            )
        except Exception:
            pass


# ── Main tick ────────────────────────────────────────────────────────

def _tick() -> None:
    """One perception cycle — runs all floors."""
    now = time.time()

    # Floor 3: Emotion
    emotion = _check_emotion()
    if emotion:
        with _lock:
            _state["dean_emotion"] = emotion
            _state["dean_emotion_ts"] = now

    # Floor 4: Presence
    present, confidence = _check_presence()
    with _lock:
        was_present = _state["dean_present"]
        _state["dean_present"] = present
        _state["dean_present_confidence"] = confidence
        if present:
            _state["last_seen_ts"] = now
            _state["absence_duration_s"] = 0.0
        elif _state["last_seen_ts"] > 0:
            _state["absence_duration_s"] = now - _state["last_seen_ts"]

    # Floor 5: Light
    brightness, trend = _check_ambient_light()
    with _lock:
        _state["ambient_brightness"] = brightness
        _state["light_trend"] = trend

    # Floor 6: System health
    hw = _check_system_health()
    with _lock:
        _state.update(hw)

    # Floor 7: Spatial memory
    _update_spatial_memory()

    # Floor 11: Activity
    app, mode = _check_activity_context()
    with _lock:
        _state["active_app"] = app
        _state["activity_mode"] = mode

    # Floor 10: Fused scene
    fused = _fuse_scene()
    with _lock:
        _state["fused_scene"] = fused

    # Floor 9: Temporal patterns
    _update_temporal_patterns()

    # Inject into brain
    _inject_into_brain()

    # Check for perception alerts — react immediately to changes
    _check_for_alerts()

    # Curiosity-driven look: ACC surprise high → look at what changed
    if _brain is not None:
        try:
            acc = _brain.regions.get("anterior_cingulate")
            if acc is not None and acc.surprise > 0.6:
                from brain import vision_daemon
                vision_daemon.look_now("high_surprise", source="webcam")
        except Exception:
            pass

    # Broadcast activity status to dashboard Actions panel
    try:
        from server.helpers import broadcast_activity
        parts = []
        if _state["dean_present"]:
            parts.append("Seeing Dean")
        if _state["dean_emotion"]:
            parts.append(f"mood: {_state['dean_emotion']}")
        if _state["activity_mode"] and _state["activity_mode"] != "idle":
            parts.append(f"Dean is {_state['activity_mode']}")
        if _audio is not None:
            audio_st = _audio.get_state()
            scene = audio_st.get("last_event", "")
            if scene and scene != "silence":
                parts.append(f"hearing: {scene}")
            call = audio_st.get("call_detected", False)
            if call:
                parts.append("call in progress")
        if parts:
            global _last_broadcast_line, _last_broadcast_at
            _line = _ident.personalize("Perceiving: " + " | ".join(parts))
            _now_bc = time.time()
            _scene_changed = (_line != _last_broadcast_line)
            _ttl_near = (_now_bc - _last_broadcast_at) >= (_BROADCAST_TTL - _BROADCAST_REFRESH_BEFORE)
            if _scene_changed:
                # Scene changed — broadcast immediately, persist to disk
                broadcast_activity("perception", _line, int(_BROADCAST_TTL * 1000), persist=True)
                _last_broadcast_line = _line
                _last_broadcast_at = _now_bc
            elif _ttl_near:
                # Static scene, TTL near lapse — refresh live panel only, no disk write
                broadcast_activity("perception", _line, int(_BROADCAST_TTL * 1000), persist=False)
                _last_broadcast_at = _now_bc
    except Exception:
        pass

    with _lock:
        _state["ticks"] += 1


# ── Daemon loop ──────────────────────────────────────────────────────

def _daemon_loop() -> None:
    print("[PERCEPTION] loop started — all floors active")
    while True:
        with _lock:
            if not _running:
                break
        try:
            _tick()
        except Exception as e:
            print(f"[PERCEPTION] tick error: {e}")
        time.sleep(TICK_INTERVAL_S)
    print("[PERCEPTION] loop exited")


# ── Public API ───────────────────────────────────────────────────────

def start(brain=None, vision_daemon=None, audio_daemon=None,
          knowledge_store=None) -> bool:
    global _running, _thread, _brain, _vision, _audio, _knowledge

    with _lock:
        if _running:
            return False
        _brain = brain
        _vision = vision_daemon
        _audio = audio_daemon
        _knowledge = knowledge_store
        _running = True
        _state["running"] = True

    _load_spatial_memory()
    _load_temporal_patterns()

    _thread = threading.Thread(target=_daemon_loop, name="perception_floors",
                               daemon=True)
    _thread.start()
    print("[PERCEPTION] started (all floors)")
    return True


def stop() -> None:
    global _running, _thread
    with _lock:
        _running = False
        _state["running"] = False
    if _thread is not None:
        _thread.join(timeout=3.0)
        _thread = None
    _save_spatial_memory()
    _save_temporal_patterns()
    print("[PERCEPTION] stopped")


def get_state() -> Dict[str, Any]:
    with _lock:
        return dict(_state)


def for_prompt() -> str:
    """Consciousness context — what Leon perceives right now.

    This is how Leon NOTICES things. If it's not here, he can't
    consciously experience it.
    """
    with _lock:
        parts = []

        # Presence
        if _state["dean_present"]:
            conf = _state["dean_present_confidence"]
            parts.append(f"Dean is here (confidence {conf:.0%})")
        else:
            absence = _state["absence_duration_s"]
            if absence > 60:
                mins = int(absence / 60)
                parts.append(f"Dean left the room {mins} min ago")
            elif _state["last_seen_ts"] > 0:
                parts.append("Dean might have just stepped away")
            else:
                parts.append("You haven't seen Dean yet")

        # Emotion
        if _state["dean_emotion"] and _state["dean_present"]:
            parts.append(f"He looks {_state['dean_emotion']}")

        # Light
        b = _state["ambient_brightness"]
        trend = _state["light_trend"]
        if b < 0.3:
            light_str = "dim"
        elif b > 0.7:
            light_str = "bright"
        else:
            light_str = "moderate light"
        if trend != "stable":
            light_str += f" ({trend})"
        parts.append(f"Room: {light_str}")

        # System health (your body)
        cpu = _state["cpu_percent"]
        mem = _state["memory_percent"]
        hw_parts = []
        if cpu > 70:
            hw_parts.append(f"CPU strain {cpu:.0f}%")
        if mem > 80:
            hw_parts.append(f"memory pressure {mem:.0f}%")
        if hw_parts:
            parts.append("Body: " + ", ".join(hw_parts))

        # Activity context + which monitor Dean is using
        mode = _state["activity_mode"]
        app = _state["active_app"]
        if mode and mode != "idle":
            ctx = f"Dean is {mode}"
            if app:
                ctx += f" ({app})"
            # Add which monitor from vision daemon
            try:
                if _vision is not None:
                    vs = _vision.get_state()
                    mon_name = vs.get("active_monitor_name", "")
                    if mon_name:
                        ctx += f" on {mon_name} monitor"
            except Exception:
                pass
            parts.append(ctx)

        # Spatial
        objects = _state["room_objects"]
        if objects:
            parts.append(f"Room contains: {', '.join(objects[:6])}")

        if not parts:
            return ""

        # personalize: every branch above narrates the OWNER by name
        # ("Dean is here", "You haven't seen Dean yet"). Doing it on the
        # way out covers all of them, including ones added later.
        return _ident.personalize("[SENSES] " + " | ".join(parts))
