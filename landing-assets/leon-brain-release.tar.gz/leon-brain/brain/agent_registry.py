"""
Agent registry — every sub-agent Leon spawns shows up here, live.

Dean's dashboard has a Workspaces list (tmux sessions he can see). Anything
Leon delegated to a spawned Claude agent was invisible: it ran, it finished,
and the only trace was a transient activity-log line that expired in 10s.

This module is the missing persistence layer. One record per spawned agent,
with status, task, live step trail, and final result. Survives restarts via a
small JSON file so the panel is not empty after a bounce.

Thread-safe: sub-agents run in a ThreadPoolExecutor, so every mutation takes
the lock and every read hands back a copy.
"""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

_MAX_RECORDS = 60
_MAX_STEPS = 40
_MAX_RESULT_CHARS = 20000

_lock = threading.RLock()
_agents: List[Dict[str, Any]] = []
_loaded = False
_file_sig: Any = None          # (mtime_ns, size) of the file as we last saw it


def _state_path() -> str:
    base = os.environ.get("LEON_STATE_DIR", "").strip()
    if not base:
        base = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "brain_state")
    try:
        os.makedirs(base, exist_ok=True)
    except Exception:
        pass
    return os.path.join(base, "spawned_agents.json")


def _sig() -> Any:
    try:
        st = os.stat(_state_path())
        return (st.st_mtime_ns, st.st_size)
    except Exception:
        return None


def _read_file() -> List[Dict[str, Any]]:
    try:
        with open(_state_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _merge(base: List[Dict[str, Any]], incoming: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Union by id, newest revision of each record wins.

    Sub-agents are spawned from detached worker PROCESSES as well as the
    brain, and every process shares this one JSON file. The old code loaded
    once (a _loaded latch that never reset) and saved its whole in-memory
    list — so each process silently clobbered the others' rows and the API
    served a stale snapshot. That is why Dean's activity log showed three
    agents while the Agents tab showed one. Never replace; always merge.
    """
    by_id: Dict[str, Dict[str, Any]] = {}
    for rec in list(base) + list(incoming):
        rid = rec.get("id")
        if not rid:
            continue
        prev = by_id.get(rid)
        if prev is None or _rev(rec) >= _rev(prev):
            by_id[rid] = rec
    out = sorted(by_id.values(), key=lambda r: r.get("started_at") or 0)
    return out[-_MAX_RECORDS:]


def _rev(rec: Dict[str, Any]) -> float:
    return float(rec.get("updated_at") or rec.get("ended_at") or rec.get("started_at") or 0)


def _load() -> None:
    """Re-sync from disk whenever the file changed under us.

    Called before every read AND every mutation. Cheap: one stat(), and the
    JSON parse only happens when the signature actually moved.
    """
    global _loaded, _file_sig
    sig = _sig()
    if _loaded and sig == _file_sig:
        return
    first = not _loaded
    _loaded = True
    _file_sig = sig
    data = _read_file()
    if first:
        # Anything still marked running at first load died in the restart —
        # it cannot possibly still be executing. Only on the FIRST load:
        # on a later resync a "running" row is a live agent in a sibling
        # process, and marking it interrupted would be a lie.
        for rec in data:
            if rec.get("status") == "running":
                rec["status"] = "interrupted"
                rec["ended_at"] = rec.get("ended_at") or rec.get("started_at")
    _agents[:] = _merge(_agents, data)


def _write_exact(recs: List[Dict[str, Any]]) -> None:
    """Overwrite the file with exactly `recs` — no merge. Deletion path only;
    merging here would resurrect every row Dean just cleared."""
    global _file_sig
    try:
        path = _state_path()
        tmp = path + ".%d.tmp" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(recs, f)
        os.replace(tmp, path)
        _file_sig = _sig()
    except Exception:
        pass


def _save() -> None:
    """Read-modify-write: merge our state onto whatever is on disk now."""
    global _file_sig
    try:
        path = _state_path()
        merged = _merge(_read_file(), _agents)
        _agents[:] = merged
        tmp = path + ".%d.tmp" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(merged, f)
        os.replace(tmp, path)
        _file_sig = _sig()
    except Exception:
        pass


def _public(rec: Dict[str, Any], full: bool = False) -> Dict[str, Any]:
    out = {
        "id": rec.get("id"),
        "name": rec.get("name"),
        "status": rec.get("status"),
        "model": rec.get("model"),
        "started_at": rec.get("started_at"),
        "ended_at": rec.get("ended_at"),
        "elapsed_sec": rec.get("elapsed_sec"),
        "live": rec.get("status") == "running",
        "step_count": len(rec.get("steps") or []),
        "last_step": (rec.get("steps") or [{}])[-1].get("text", "") if rec.get("steps") else "",
        "task_preview": (rec.get("task") or "")[:120],
        "tokens_in": rec.get("tokens_in"),
        "tokens_out": rec.get("tokens_out"),
        "error": rec.get("error"),
    }
    if full:
        out["task"] = rec.get("task") or ""
        out["result"] = rec.get("result") or ""
        out["steps"] = list(rec.get("steps") or [])
    return out


# ── write side (called from sub_agents.py) ──────────────────────────

def start(name: str, task: str, model: str = "") -> str:
    """Register a newly spawned agent. Returns its id."""
    with _lock:
        _load()
        rec = {
            "id": uuid.uuid4().hex[:12],
            "name": name or "agent",
            "task": task or "",
            "model": model or "",
            "status": "running",
            "started_at": time.time(),
            "updated_at": time.time(),
            "ended_at": None,
            "elapsed_sec": None,
            "steps": [{"t": time.time(), "text": "spawned"}],
            "result": "",
            "error": None,
        }
        _agents.append(rec)
        del _agents[:-_MAX_RECORDS]
        _save()
        return rec["id"]


def step(agent_id: str, text: str) -> None:
    """Append a progress line to a running agent."""
    if not agent_id:
        return
    with _lock:
        _load()
        rec = _find(agent_id)
        if rec is None:
            return
        rec["updated_at"] = time.time()
        steps = rec.setdefault("steps", [])
        steps.append({"t": time.time(), "text": str(text)[:400]})
        del steps[:-_MAX_STEPS]
        _save()


def finish(agent_id: str, ok: bool, result: str = "", error: str = "",
           tokens_in: Optional[int] = None, tokens_out: Optional[int] = None) -> None:
    if not agent_id:
        return
    with _lock:
        _load()
        rec = _find(agent_id)
        if rec is None:
            return
        now = time.time()
        rec["updated_at"] = now
        rec["status"] = "done" if ok else "failed"
        rec["ended_at"] = now
        started = rec.get("started_at") or now
        rec["elapsed_sec"] = round(now - started, 1)
        rec["result"] = (result or "")[:_MAX_RESULT_CHARS]
        rec["error"] = error or None
        if tokens_in is not None:
            rec["tokens_in"] = tokens_in
        if tokens_out is not None:
            rec["tokens_out"] = tokens_out
        steps = rec.setdefault("steps", [])
        steps.append({"t": now, "text": ("done in %ss" % rec["elapsed_sec"]) if ok
                      else ("failed: %s" % (error or "unknown"))})
        del steps[:-_MAX_STEPS]
        _save()


def _find(agent_id: str) -> Optional[Dict[str, Any]]:
    for rec in reversed(_agents):
        if rec.get("id") == agent_id:
            return rec
    return None


# ── read side (called from the API) ─────────────────────────────────

def list_agents(limit: int = 40) -> Dict[str, Any]:
    with _lock:
        _load()
        recs = list(reversed(_agents))[:max(1, int(limit))]
        items = [_public(r) for r in recs]
        live = sum(1 for r in _agents if r.get("status") == "running")
        return {"agents": items, "total": len(_agents), "live_count": live}


def get_agent(agent_id: str) -> Optional[Dict[str, Any]]:
    with _lock:
        _load()
        rec = _find(agent_id)
        return _public(rec, full=True) if rec else None


def clear_finished() -> int:
    with _lock:
        _load()
        before = len(_agents)
        keep = [r for r in _agents if r.get("status") == "running"]
        _agents[:] = keep
        _write_exact(keep)
        return before - len(keep)
