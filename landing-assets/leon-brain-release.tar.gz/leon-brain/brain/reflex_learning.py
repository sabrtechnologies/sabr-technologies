"""
Reflex Learning — Leon's tool-use patterns become automatic reflexes.

How humans learn motor skills:
  1. Conscious effort (Claude figures out the right tool)
  2. Repetition (same pattern succeeds multiple times)
  3. Becomes reflex (automatic, no thinking needed)

This module:
  - Logs every successful tool call with the user message that triggered it
  - Detects repeated patterns (same intent → same tool → success)
  - After PROMOTION_THRESHOLD successes, promotes to a learned reflex
  - Learned reflexes are checked in reflexes.py before Claude is called

Storage: brain_state/tool_learning.jsonl (raw logs)
         brain_state/learned_reflexes.json (promoted patterns)
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_LOG_FILE = _STATE_DIR / "tool_learning.jsonl"
_REFLEX_FILE = _STATE_DIR / "learned_reflexes.json"
_LOCK = threading.Lock()

# How many times a pattern must succeed before becoming a reflex
PROMOTION_THRESHOLD = 3
# Max log entries to keep
MAX_LOG_ENTRIES = 5000


def log_tool_use(tool_name: str) -> None:
    """Lightweight usage log (NO pattern learning) for autonomous / CLI-path tool
    calls that have no originating user_text. Feeds skill-practice's tool_counts
    so it stops reporting "0/0 top tools". Writes a keyword-less entry, so
    _check_promotions (which keys on keywords) ignores it — no junk reflexes.
    """
    if not tool_name:
        return
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    entry = {
        "ts": time.time(),
        "tool": tool_name,
        "keywords": [],
        "success": True,
        "autonomous": True,
    }
    with _LOCK:
        try:
            with open(_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass


def log_success(user_text: str, tool_name: str, tool_args: dict, result_summary: str = "") -> None:
    """Log a successful tool call triggered by a user message."""
    if not user_text or not tool_name:
        return
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    entry = {
        "ts": time.time(),
        "user_text": user_text.strip()[:200],
        "keywords": _extract_keywords(user_text),
        "tool": tool_name,
        "args_template": _templatize_args(tool_args),
        "success": True,
    }
    with _LOCK:
        try:
            with open(_LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass
    # Check if any pattern should be promoted
    _check_promotions(entry)


def _extract_keywords(text: str) -> List[str]:
    """Pull meaningful keywords from a user message."""
    text = text.lower().strip()
    # Remove filler
    for filler in ["ok", "hey", "leon", "please", "can you", "could you",
                    "now", "just", "the", "my", "a", "an", "it", "is", "do"]:
        text = re.sub(r'\b' + filler + r'\b', '', text)
    words = re.findall(r'[a-z]+', text)
    # Dedupe, keep order
    seen = set()
    result = []
    for w in words:
        if w not in seen and len(w) > 1:
            seen.add(w)
            result.append(w)
    return result[:10]


def _templatize_args(args: dict) -> dict:
    """Convert concrete args to a template (replace specific values with types)."""
    template = {}
    for k, v in (args or {}).items():
        if isinstance(v, (int, float)):
            template[k] = "__NUMBER__"
        elif isinstance(v, str) and len(v) > 20:
            template[k] = "__STRING__"
        else:
            template[k] = v  # keep short strings as-is (they're the pattern)
    return template


def _pattern_key(keywords: List[str], tool: str, args_template: dict) -> str:
    """Create a hashable key for a tool-use pattern."""
    kw_part = ",".join(sorted(keywords[:5]))
    args_part = json.dumps(args_template, sort_keys=True)
    return f"{kw_part}|{tool}|{args_part}"


def _check_promotions(new_entry: dict) -> None:
    """Check if any pattern has reached the promotion threshold."""
    try:
        lines = _LOG_FILE.read_text(encoding="utf-8").splitlines()
    except Exception:
        return

    # Count pattern occurrences
    pattern_counts = defaultdict(lambda: {"count": 0, "entries": []})
    for line in lines[-1000:]:  # only check recent history
        try:
            entry = json.loads(line.strip())
            if not entry.get("success"):
                continue
            key = _pattern_key(
                entry.get("keywords", []),
                entry.get("tool", ""),
                entry.get("args_template", {}),
            )
            pattern_counts[key]["count"] += 1
            pattern_counts[key]["entries"].append(entry)
        except Exception:
            continue

    # Load existing learned reflexes
    learned = _load_learned()
    changed = False

    for key, data in pattern_counts.items():
        if data["count"] >= PROMOTION_THRESHOLD and key not in learned:
            # Promote this pattern!
            sample = data["entries"][-1]
            learned[key] = {
                "tool": sample["tool"],
                "args_template": sample.get("args_template", {}),
                "keywords": sample.get("keywords", []),
                "user_example": sample.get("user_text", ""),
                "promoted_at": time.time(),
                "success_count": data["count"],
            }
            changed = True
            try:
                from server.helpers import broadcast_activity
                broadcast_activity("inner",
                    f"Learned reflex: '{sample.get('user_text', '')[:40]}' → {sample['tool']}",
                    10000)
            except Exception:
                pass

    if changed:
        _save_learned(learned)


def _load_learned() -> dict:
    """Load learned reflexes from disk."""
    try:
        return json.loads(_REFLEX_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_learned(data: dict) -> None:
    """Save learned reflexes to disk."""
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        _REFLEX_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def try_learned_reflex(user_text: str) -> Optional[str]:
    """Check if a learned reflex matches this message. Returns response or None."""
    learned = _load_learned()
    if not learned:
        return None

    user_keywords = set(_extract_keywords(user_text))
    if not user_keywords:
        return None

    best_match = None
    best_overlap = 0

    for key, reflex in learned.items():
        reflex_keywords = set(reflex.get("keywords", []))
        overlap = len(user_keywords & reflex_keywords)
        # Need at least 2 keyword overlap and >50% match
        if overlap >= 2 and overlap > best_overlap:
            ratio = overlap / max(len(reflex_keywords), 1)
            if ratio >= 0.5:
                best_match = reflex
                best_overlap = overlap

    if best_match is None:
        return None

    # Execute the learned reflex
    tool = best_match["tool"]
    args_template = best_match.get("args_template", {})

    # Fill in number placeholders from user text (with bounds checking)
    args = {}
    numbers = re.findall(r'\d+', user_text)
    num_idx = 0
    for k, v in args_template.items():
        if v == "__NUMBER__" and num_idx < len(numbers):
            raw = int(numbers[num_idx])
            # Clamp to reasonable range for known parameter types
            if k in ("delta", "percent", "volume", "brightness"):
                raw = max(-100, min(100, raw))
            elif k in ("timeout", "seconds", "delay"):
                raw = max(1, min(300, raw))
            else:
                raw = max(-10000, min(10000, raw))
            args[k] = raw
            num_idx += 1
        elif v == "__STRING__":
            args[k] = user_text[:200]  # truncate to prevent overflow
        else:
            args[k] = v

    try:
        from brain.actuator_client import call
        result = call(tool, args)
        if result.get("ok"):
            try:
                from server.helpers import broadcast_activity
                broadcast_activity("tool",
                    f"✓ Learned reflex: {tool} (auto-learned from experience)", 5000)
            except Exception:
                pass
            return f"Done. (Used a pattern I learned from experience: {tool})"
        return None  # learned reflex failed, fall through to Claude
    except Exception:
        return None
