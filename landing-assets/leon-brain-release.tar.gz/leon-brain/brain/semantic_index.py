"""Rebuildable semantic references; never opens a canonical store for writing.

No model is imported or downloaded at module/import/index construction time.
Embedding inputs are canonical text, never the legacy 18-D neural fingerprint.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import math
import os
from pathlib import Path
import sqlite3
import struct
import threading
import time


def text_hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def unit_vector(values):
    vector = [float(x) for x in values]
    if not vector or not all(math.isfinite(x) for x in vector):
        raise ValueError("embedding must contain finite numbers")
    norm = math.sqrt(sum(x * x for x in vector))
    if norm <= 0:
        raise ValueError("embedding must be nonzero")
    return [x / norm for x in vector]


class LocalEmbedder:
    """Lazy CPU embedder restricted to models already in the local cache.

    Explicit model paths are supported. Changing models requires backfill;
    vectors from different model IDs/dimensions are never mixed.
    """

    def __init__(self, model_id=None):
        self.model_id = model_id or os.environ.get(
            "LEON_EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
        self.dim = None
        self._model = None
        self._attempted = False
        self.reason = "not_loaded"
        self._lock = threading.RLock()

    def embed(self, text):
        with self._lock:
            if not self._attempted:
                self._attempted = True
                try:
                    from sentence_transformers import SentenceTransformer
                    self._model = SentenceTransformer(
                        self.model_id, device="cpu", local_files_only=True,
                        trust_remote_code=False)
                    self.dim = int(self._model.get_sentence_embedding_dimension())
                    self.reason = "available"
                except Exception as exc:
                    # Old packages without local_files_only also fail closed.
                    self.reason = "unavailable:" + type(exc).__name__
            if self._model is None:
                return None
            try:
                return unit_vector(self._model.encode(
                    text, normalize_embeddings=True, show_progress_bar=False))
            except Exception as exc:
                self.reason = "encode_failed:" + type(exc).__name__
                return None


class SemanticIndex:
    SCHEMA_VERSION = "1"

    def __init__(self, path, *, embedder=None, enable_embeddings=False,
                 canonical_paths=(), max_vectors=250000):
        self.path = Path(path).resolve()
        if self.path in {Path(p).resolve() for p in canonical_paths}:
            raise ValueError("sidecar path must differ from every canonical store")
        self.embedder = embedder if embedder is not None else LocalEmbedder()
        self.enable_embeddings = bool(enable_embeddings)
        self.max_vectors = max(1, int(max_vectors))
        self.last_error = None
        self._lock = threading.RLock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as db:
            tables = {r[0] for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            if tables and not {"documents", "embeddings", "state_vectors", "meta"} <= tables:
                raise ValueError("refusing to modify an unrelated database")
            if tables:
                version = db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
                if version is None or version[0] != self.SCHEMA_VERSION:
                    raise ValueError("unsupported semantic sidecar schema")
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY, store TEXT NOT NULL, record_id TEXT NOT NULL,
                    text_hash TEXT NOT NULL, created_ts REAL NOT NULL, source TEXT NOT NULL,
                    authority REAL NOT NULL, memory_type TEXT NOT NULL,
                    UNIQUE(store, record_id));
                CREATE TABLE IF NOT EXISTS embeddings (
                    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
                    model_id TEXT NOT NULL, dim INTEGER NOT NULL, vector_blob BLOB NOT NULL,
                    PRIMARY KEY(document_id,model_id));
                CREATE TABLE IF NOT EXISTS state_vectors (
                    document_id INTEGER PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,
                    schema TEXT NOT NULL, vector_blob BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY,value TEXT NOT NULL);
            """)
            db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS lexical USING fts5(text)")
            db.execute("INSERT OR IGNORE INTO meta VALUES ('schema_version',?)",
                       (self.SCHEMA_VERSION,))

    @contextmanager
    def _connect(self):
        db = sqlite3.connect(str(self.path), timeout=2.0)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout=2000")
        db.execute("PRAGMA foreign_keys=ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def _embedding(self, text):
        if not self.enable_embeddings:
            return None
        try:
            vector = self.embedder.embed(text)
            if vector is None:
                return None
            vector = unit_vector(vector)
            declared = getattr(self.embedder, "dim", None)
            if declared is not None and len(vector) != declared:
                raise ValueError("embedding dimension changed")
            return vector
        except Exception as exc:
            self.last_error = "embedding:" + type(exc).__name__
            return None

    def upsert_source_ref(self, *, store, record_id, text, created_ts=0.0,
                          source="unknown", authority=0.0, memory_type="semantic",
                          state_vector=None, state_schema="legacy-neural-18"):
        """Index an authorized, rehydrated canonical record. Return change details.

        An unchanged text can acquire a missing/model-swapped embedding. Repeated
        identical sources are otherwise no-ops; provenance still refreshes.
        """
        digest = text_hash(text)
        model = str(self.embedder.model_id)
        with self._lock:
            with self._connect() as db:
                old = db.execute("SELECT * FROM documents WHERE store=? AND record_id=?",
                                 (store, str(record_id))).fetchone()
                present = old and db.execute(
                    "SELECT 1 FROM embeddings WHERE document_id=? AND model_id=?",
                    (old["id"], model)).fetchone()
            changed = old is None or old["text_hash"] != digest
            vector = self._embedding(text) if changed or not present else None
            # No main-store connection/lock is held during inference.
            with self._connect() as db:
                db.execute("""INSERT INTO documents
                    (store,record_id,text_hash,created_ts,source,authority,memory_type)
                    VALUES (?,?,?,?,?,?,?) ON CONFLICT(store,record_id) DO UPDATE SET
                    text_hash=excluded.text_hash,created_ts=excluded.created_ts,
                    source=excluded.source,authority=excluded.authority,
                    memory_type=excluded.memory_type""",
                           (store, str(record_id), digest, float(created_ts), source,
                            float(authority), str(memory_type)))
                doc_id = db.execute("SELECT id FROM documents WHERE store=? AND record_id=?",
                                    (store, str(record_id))).fetchone()[0]
                if changed:
                    db.execute("DELETE FROM embeddings WHERE document_id=?", (doc_id,))
                    db.execute("DELETE FROM lexical WHERE rowid=?", (doc_id,))
                    db.execute("INSERT INTO lexical(rowid,text) VALUES (?,?)", (doc_id, text))
                # State is an optional separate rerank feature, never meaning.
                db.execute("DELETE FROM state_vectors WHERE document_id=?", (doc_id,))
                if state_vector is not None:
                    try:
                        state = unit_vector(state_vector)
                    except (ValueError, TypeError):
                        state = None
                    if state:
                        db.execute("INSERT INTO state_vectors VALUES (?,?,?)",
                                   (doc_id, state_schema, struct.pack("<%sf" % len(state), *state)))
                if vector is not None:
                    db.execute("INSERT OR REPLACE INTO embeddings VALUES (?,?,?,?)",
                               (doc_id, model, len(vector), struct.pack("<%sf" % len(vector), *vector)))
                    db.execute("INSERT OR REPLACE INTO meta VALUES ('embedding_model',?)", (model,))
            return {"changed": changed, "embedded": vector is not None,
                    "record_id": str(record_id), "text_hash": digest}

    def search(self, query, *, limit=50):
        """Cosine candidates. Authorization and canonical rehydration belong above.

        Streams bounded pages; NumPy, when available, accelerates each page.
        No corpus-size tensor/cache survives the request. Capacity exhaustion
        returns no semantic candidates instead of silently searching a prefix.
        """
        vector = self._embedding(query)
        if vector is None:
            return []
        model, dim = str(self.embedder.model_id), len(vector)
        with self._connect() as db:
            count, ceiling = db.execute("SELECT count(*),max(document_id) FROM embeddings WHERE model_id=? AND dim=?",
                                       (model, dim)).fetchone()
        if count > self.max_vectors:
            self.last_error = "semantic_capacity_exceeded"
            return []
        try:
            import numpy as np
        except ImportError:
            np = None
        best, cursor = [], 0
        while True:
            with self._connect() as db:
                rows = db.execute("""SELECT d.*,e.vector_blob FROM embeddings e
                    JOIN documents d ON d.id=e.document_id
                    WHERE e.model_id=? AND e.dim=? AND d.id>? AND d.id<=? ORDER BY d.id LIMIT 512""",
                                  (model, dim, cursor, ceiling or 0)).fetchall()
            if not rows:
                break
            valid = [row for row in rows if len(row["vector_blob"]) == 4 * dim]
            if np is not None and valid:
                matrix = np.frombuffer(b"".join(row["vector_blob"] for row in valid),
                                       dtype="<f4").reshape(len(valid), dim)
                finite = np.isfinite(matrix).all(axis=1)
                valid = [row for row, keep in zip(valid, finite) if keep]
                scores = matrix[finite].dot(np.asarray(vector, dtype=np.float32))
            else:
                pairs = [(row, struct.unpack("<%sf" % dim, row["vector_blob"])) for row in valid]
                pairs = [(row, values) for row, values in pairs if all(math.isfinite(v) for v in values)]
                valid = [row for row, _ in pairs]
                scores = [sum(a*b for a, b in zip(values, vector)) for _, values in pairs]
            for row, score in zip(valid, scores):
                best.append({"store": row["store"], "record_id": row["record_id"],
                             "text_hash": row["text_hash"],
                             "score": max(0.0, min(1.0, float(score)))})
            best.sort(key=lambda r: (-r["score"], r["store"], r["record_id"]))
            del best[max(0, min(50, int(limit))):]
            cursor = rows[-1]["id"]
        return best

    def get_ref(self, store, record_id):
        with self._connect() as db:
            row = db.execute("SELECT * FROM documents WHERE store=? AND record_id=?",
                             (store, str(record_id))).fetchone()
        return dict(row) if row else None

    def search_lexical(self, query, *, limit=50):
        import re
        words = re.findall(r"\w+", query)[:16]
        if not words:
            return []
        match = " OR ".join('"' + word + '"*' for word in words)
        with self._connect() as db:
            rows = db.execute("""SELECT d.* FROM lexical f JOIN documents d ON d.id=f.rowid
                WHERE lexical MATCH ? ORDER BY rank LIMIT ?""", (match, min(50, max(1, int(limit))))).fetchall()
        return [dict(row) for row in rows]

    def forget_ref(self, store, record_id):
        """Delete derived data only; canonical records are never deleted."""
        with self._lock, self._connect() as db:
            db.execute("DELETE FROM lexical WHERE rowid IN (SELECT id FROM documents WHERE store=? AND record_id=?)",
                       (store, str(record_id)))
            db.execute("DELETE FROM documents WHERE store=? AND record_id=?", (store, str(record_id)))

    def cursor(self, store):
        with self._connect() as db:
            row = db.execute("SELECT value FROM meta WHERE key=?", ("backfill_cursor:" + store,)).fetchone()
        return json.loads(row[0]) if row else None

    def save_cursor(self, store, value):
        with self._lock, self._connect() as db:
            db.execute("INSERT OR REPLACE INTO meta VALUES (?,?)",
                       ("backfill_cursor:" + store, json.dumps(value, sort_keys=True)))

    def embed_backfill(self, records):
        """One caller-bounded batch; rate/cursor policy is in BackfillWorker."""
        return [self.upsert_source_ref(**record) for record in records]

    def rebuild(self):
        """Reset only this validated sidecar. Caller restarts canonical backfill."""
        with self._lock, self._connect() as db:
            db.execute("DELETE FROM lexical")
            db.execute("DELETE FROM documents")
            db.execute("DELETE FROM meta WHERE key!='schema_version'")

    def stats(self):
        with self._connect() as db:
            counts = {table: db.execute("SELECT count(*) FROM " + table).fetchone()[0]
                      for table in ("documents", "embeddings", "state_vectors")}
        return dict(counts, model_id=str(self.embedder.model_id),
                    embeddings_enabled=self.enable_embeddings,
                    embedder_status=getattr(self.embedder, "reason", "injected"),
                    last_error=self.last_error)
