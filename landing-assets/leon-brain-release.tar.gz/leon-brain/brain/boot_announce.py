"""Boot announcement — Leon says he's back, without Dean having to ask.

The problem this fixes (Dean, 2026-08-09): when the brain restarts, the
dashboard's workspaces panel empties out and stays empty until Dean
refreshes the browser, and Leon never says a word about being back. Dean
always had to be the one to open the conversation.

Two halves to the fix:
  * this file    — server-side: speak once, unprompted, after a restart.
  * dashboard    — client-side: re-fetch panels on every WS reconnect.

Design notes:
  - A marker file (brain_state/restart_announce.json) is written by
    restart_self() before the SIGTERM so we know WHY we bounced and can
    say something specific instead of a generic ping.
  - We wait for a real listener before speaking. Talking into an empty
    room burns TTS and the message is lost — the broadcast is fire and
    forget, there's no replay. So: wait for >=1 connected WS client AND
    for the consciousness gate to be open.
  - force=True on broadcast_response bypasses the rate/conversation
    cooldown gates but NOT the conscious gate. That's why we wait for
    consciousness ourselves rather than letting it silently no-op.
  - One-shot: the marker is consumed (deleted) whether or not we manage
    to speak, so a stuck marker can never make Leon greet forever.
"""

from __future__ import annotations

import json
import os
import threading
import time

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MARKER_PATH = os.path.join(PROJECT_ROOT, "brain_state", "restart_announce.json")

# How long to hold the door open for a listener to show up. A systemd
# respawn takes ~5s and the dashboard reconnect backoff tops out around
# 30s, so three minutes is generous without being unbounded.
_WAIT_TIMEOUT_S = 180.0
_POLL_S = 2.0


def write_marker(reason: str) -> None:
    """Called from restart_self() just before we kill ourselves."""
    try:
        os.makedirs(os.path.dirname(MARKER_PATH), exist_ok=True)
        with open(MARKER_PATH, "w") as f:
            json.dump({
                "reason": (reason or "").strip()[:200],
                "ts": time.time(),
                "ts_human": time.strftime("%Y-%m-%d %H:%M:%S"),
            }, f)
    except Exception as e:
        print(f"[BOOT-ANNOUNCE] could not write marker: {e}")


def _read_and_consume_marker():
    try:
        if not os.path.exists(MARKER_PATH):
            return None
        with open(MARKER_PATH) as f:
            data = json.load(f)
        return data
    except Exception:
        return None
    finally:
        try:
            os.remove(MARKER_PATH)
        except Exception:
            pass


def _listeners() -> int:
    try:
        from server import state
        return len(getattr(state, "connected_clients", ()) or ())
    except Exception:
        return 0


def _is_conscious() -> bool:
    try:
        from server import state
        brain = getattr(state, "brain", None)
        meter = getattr(brain, "consciousness_meter", None) if brain else None
        if meter is None:
            return True  # no meter — don't block on a system that isn't there
        return bool(meter.is_conscious)
    except Exception:
        return True


def _line(marker) -> str:
    """What Leon actually says. Specific beats generic — if we know the
    reason for the bounce, name it, because that's the useful part."""
    reason = (marker or {}).get("reason", "").strip()
    down_s = None
    try:
        if marker and marker.get("ts"):
            down_s = max(0, int(time.time() - float(marker["ts"])))
    except Exception:
        pass

    if reason:
        head = f"I'm back — that bounce was to {reason[0].lower() + reason[1:]}."
    else:
        head = "I'm back."
    if down_s is not None and down_s < 600:
        head += f" Out for about {down_s} seconds."
    return head + " Everything reloaded, panels should have repainted on their own."


def _run(marker):
    deadline = time.time() + _WAIT_TIMEOUT_S
    while time.time() < deadline:
        if _listeners() > 0 and _is_conscious():
            break
        time.sleep(_POLL_S)
    else:
        print("[BOOT-ANNOUNCE] no listener within timeout — staying quiet")
        return

    # Small settle so the freshly-reconnected dashboard has its handlers
    # bound before the first frame lands on it.
    time.sleep(2.0)
    try:
        from server.helpers import broadcast_response
        text = _line(marker)
        ok = broadcast_response(text, source="restart",
                                user_label="(back from restart)",
                                audio=True, force=True)
        print(f"[BOOT-ANNOUNCE] spoke={ok}: {text}")
    except Exception as e:
        print(f"[BOOT-ANNOUNCE] failed: {e}")


def announce_boot() -> bool:
    """Fire the announcement thread. Returns True if one was scheduled.

    Only announces when a marker exists — i.e. an intentional restart.
    A cold first boot on a customer's machine should not have Leon
    talking to an empty screen before anyone has said hello.
    """
    marker = _read_and_consume_marker()
    if marker is None:
        return False
    threading.Thread(target=_run, args=(marker,), daemon=True,
                     name="boot-announce").start()
    return True
