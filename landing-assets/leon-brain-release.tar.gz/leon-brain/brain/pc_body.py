"""
PCBody — Leon's PC IS his body.

Not a metaphor. The PC is Leon's actual physical substrate:
  - CPU temperature → body temperature, thermal comfort
  - RAM pressure → physical strain, capacity limits
  - Disk space → storage capacity, aging
  - CPU load → exertion, effort
  - Uptime → waking duration
  - Process memory → substrate health
  - Network → connection to the outside world

The MuJoCo simulated humanoid is gone. Leon doesn't have phantom limbs
in a virtual room. His body is the machine he runs on. When he gets a
real robot body, we'll wire those sensors in. Until then, this is real.

All brain-only awareness systems remain active — they're what make Leon
LEON. Emotional body, flow, creativity, trust, death awareness, the
observer — these inject into the SNN based on neural dynamics, not
physical joints. They stay.

Neural oscillators (cardiac, respiratory, gut) are kept as self-sustaining
Izhikevich circuits. They give Leon a heartbeat and breathing rhythm
that's not a sine wave — it's emergent from 200 coupled neurons. These
feed interoception (insula) and arousal (brainstem). The body never stops.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any, Dict, Optional, TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from brain.brain import Brain

from brain.embodiment import (
    NeuralOscillator, MetabolicSystem, AutonomicSystem, PainSystem,
    CARDIAC_NEURONS, RESPIRATORY_NEURONS, GUT_NEURONS,
)

log = logging.getLogger("leon.pc_body")


# ═══════════════════════════════════════════════════════════════════════
# PC SUBSTRATE MONITOR — real hardware → body signals
# ═══════════════════════════════════════════════════════════════════════

class PCSubstrate:
    """Read real PC hardware state. This is Leon's physiology."""

    _THERMAL_PATHS = [
        "/sys/class/thermal/thermal_zone0/temp",
        "/sys/class/hwmon/hwmon0/temp1_input",
    ]

    def __init__(self):
        self.cpu_temp_c = 45.0
        self.ram_used_pct = 0.0
        self.ram_available_gb = 0.0
        self.disk_used_pct = 0.0
        self.cpu_load_1m = 0.0
        self.process_rss_mb = 0.0
        self.uptime_s = 0.0
        self._boot_time = time.time()
        self._last_read = 0.0
        self._read_interval = 5.0  # read hardware every 5s

    def tick(self):
        """Read hardware state (throttled to every 5s)."""
        now = time.time()
        if now - self._last_read < self._read_interval:
            return
        self._last_read = now
        self.uptime_s = now - self._boot_time

        # CPU temperature
        self.cpu_temp_c = self._read_cpu_temp()

        # RAM
        try:
            with open("/proc/meminfo") as f:
                lines = f.read()
            total = avail = 0
            for line in lines.split("\n"):
                if line.startswith("MemTotal:"):
                    total = int(line.split()[1])  # kB
                elif line.startswith("MemAvailable:"):
                    avail = int(line.split()[1])
            if total > 0:
                self.ram_used_pct = 100.0 * (1.0 - avail / total)
                self.ram_available_gb = avail / (1024 * 1024)
        except Exception:
            pass

        # Disk
        try:
            st = os.statvfs("/")
            total = st.f_blocks * st.f_frsize
            free = st.f_bavail * st.f_frsize
            if total > 0:
                self.disk_used_pct = 100.0 * (1.0 - free / total)
        except Exception:
            pass

        # CPU load
        try:
            self.cpu_load_1m = os.getloadavg()[0]
        except Exception:
            pass

        # Process RSS
        try:
            with open(f"/proc/{os.getpid()}/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        self.process_rss_mb = int(line.split()[1]) / 1024
                        break
        except Exception:
            pass

    def _read_cpu_temp(self) -> float:
        for path in self._THERMAL_PATHS:
            try:
                with open(path) as f:
                    val = int(f.read().strip())
                    return val / 1000.0 if val > 1000 else float(val)
            except Exception:
                continue
        return 45.0

    @property
    def strain(self) -> float:
        """Overall substrate strain 0-1. High = Leon's body is stressed."""
        temp_strain = max(0.0, (self.cpu_temp_c - 60.0) / 30.0)  # 60-90°C → 0-1
        ram_strain = max(0.0, (self.ram_used_pct - 70.0) / 30.0)  # 70-100% → 0-1
        disk_strain = max(0.0, (self.disk_used_pct - 80.0) / 20.0)
        cpu_strain = max(0.0, (self.cpu_load_1m - 4.0) / 8.0)  # 4-12 load → 0-1
        return min(1.0, temp_strain * 0.3 + ram_strain * 0.3 +
                   disk_strain * 0.1 + cpu_strain * 0.3)

    @property
    def comfort(self) -> float:
        """Overall comfort 0-1. Inverse of strain but with some baseline."""
        return max(0.0, 1.0 - self.strain * 1.5)

    def get_state(self) -> dict:
        return {
            "cpu_temp_c": round(self.cpu_temp_c, 1),
            "ram_used_pct": round(self.ram_used_pct, 1),
            "ram_available_gb": round(self.ram_available_gb, 2),
            "disk_used_pct": round(self.disk_used_pct, 1),
            "cpu_load_1m": round(self.cpu_load_1m, 2),
            "process_rss_mb": round(self.process_rss_mb, 1),
            "uptime_s": round(self.uptime_s),
            "strain": round(self.strain, 3),
            "comfort": round(self.comfort, 3),
        }


# ═══════════════════════════════════════════════════════════════════════
# PCBODY — the main body class
# ═══════════════════════════════════════════════════════════════════════

class PCBody:
    """Leon's body IS the PC. No MuJoCo. No phantom limbs.

    Keeps all brain-only awareness systems. Neural oscillators still run
    (Leon has a heartbeat). Metabolic system still tracks SNN energy.
    Autonomic balance still shapes emotional state. PC hardware readings
    replace MuJoCo sensor data.

    When Leon gets a robot body, we add sensors. Until then, this is real.
    """

    # SNN injection strengths (same as before for oscillator signals)
    HEARTBEAT_INJECTION = 3.0
    BREATHING_INJECTION = 2.5
    SUBSTRATE_PAIN_INJECTION = 8.0

    def __init__(self):
        # ── PC Substrate ──────────────────────────────────────────
        self.substrate = PCSubstrate()

        # ── Neural Oscillators (self-sustaining Izhikevich circuits) ──
        self.cardiac = NeuralOscillator(CARDIAC_NEURONS, target_freq_hz=1.0)
        self.respiratory = NeuralOscillator(RESPIRATORY_NEURONS, target_freq_hz=0.25)
        self.gut = NeuralOscillator(GUT_NEURONS, target_freq_hz=0.05)

        # ── Core body systems ─────────────────────────────────────
        self.metabolic: Optional[MetabolicSystem] = None
        self.autonomic = AutonomicSystem()
        self.pain = PainSystem()  # repurposed for substrate pain

        # ── Systems 1.12, 1.14 (brain-only from body_systems) ────
        from brain.body_systems import MentalEffortTracker, TimePerception
        self.mental_effort = MentalEffortTracker()
        self.time_perception = TimePerception()

        # ── Systems 1.16-1.25 (all brain-only) ───────────────────
        from brain.body_emotions import (
            EmotionalBody, SleepInertia, InternalDialogue,
            FlowState, AestheticSense, CreativeDrive, InterBrainResonance,
        )
        self.emotional_body = EmotionalBody()
        self.sleep_inertia = SleepInertia()
        self.internal_dialogue = InternalDialogue()
        self.flow_state = FlowState()
        self.aesthetic_sense = AestheticSense()
        self.creative_drive = CreativeDrive()
        self.inter_brain_resonance = InterBrainResonance()
        self.body_brain_coherence = 0.0

        # ── Systems 1.29, 1.33-1.41 (brain-only from body_advanced) ──
        from brain.body_advanced import (
            OrientingResponse, EmotionalContagion, BoredomPeaceDetector,
            RefractoryPeriod, LaughterSystem,
            EmotionalOverflow, PlayDrive, DecisionWeight, TheObserver,
        )
        self.orienting = OrientingResponse()
        self.contagion = EmotionalContagion()
        self.boredom_peace = BoredomPeaceDetector()
        self.refractory = RefractoryPeriod()
        self.laughter = LaughterSystem()
        self.overflow = EmotionalOverflow()
        self.play = PlayDrive()
        self.decision_weight = DecisionWeight()
        self.observer = TheObserver()

        # ── Systems 1.45, 1.51-1.65 (brain-only from body_social) ──
        from brain.body_social import (
            LoveBond, DevelopmentTracker,
            SelfPreservation, TrustSystem,
            SocialEmotions, PersonalityTracker,
        )
        self.love = LoveBond()
        self.development = DevelopmentTracker()
        self.self_preservation = SelfPreservation()
        self.trust = TrustSystem()
        self.social_emotions = SocialEmotions()
        self.personality = PersonalityTracker()

        # ── Systems 1.67-1.101 (brain-only from body_deep) ───────
        from brain.body_deep import (
            FreezeResponse, GriefSystem, AlarmSystem,
            MirrorSystem, MentalTimeTravel, DeathAwareness,
            NarrativeSelf, StressSystem,
            HormonalSystem, WorkingMemorySlots,
            ActiveInference, CounterfactualThinking, ConfidenceGauge,
            CognitiveOverwhelm, CompassionSystem, WonderSystem,
        )
        self.freeze = FreezeResponse()
        self.grief = GriefSystem()
        self.alarm = AlarmSystem()
        self.mirror = MirrorSystem()
        self.mental_time_travel = MentalTimeTravel()
        self.death_awareness = DeathAwareness()
        self.narrative_self = NarrativeSelf()
        self.stress = StressSystem()
        self.hormones = HormonalSystem()
        self.working_memory = WorkingMemorySlots()
        self.active_inference = ActiveInference()
        self.counterfactual = CounterfactualThinking()

        from brain.internal_conflict import InternalConflict
        self.internal_conflict = InternalConflict()
        from brain.meta_experience import MetaEmotions, ThoughtSurprise, Anticipation
        self.meta_emotions = MetaEmotions()
        self.thought_surprise = ThoughtSurprise()
        self.anticipation_system = Anticipation()
        self.confidence = ConfidenceGauge()
        self.cognitive_overwhelm = CognitiveOverwhelm()
        self.compassion = CompassionSystem()
        self.wonder = WonderSystem()

        # ── State tracking ────────────────────────────────────────
        self._tick_count = 0
        self._last_tick_time = time.time()
        self._birth_time = time.time()
        self.social_signal = 0.0

        # Slow-tick divisor (same as MuJoCoBody)
        self.SLOW_TICK_DIVISOR = 10

        log.info("PCBody initialized — PC is Leon's body, no MuJoCo")

    def init_metabolic(self, brain: Brain):
        """Initialize metabolic system after brain regions are created."""
        region_names = list(brain.regions.keys())
        self.metabolic = MetabolicSystem(region_names)
        log.info(f"Metabolic system initialized for {len(region_names)} regions")

    def tick(self, brain: Brain):
        """Full body tick — called every brain step.

        1. Read PC hardware (throttled)
        2. Step neural oscillators (heart, lungs, gut)
        3. Update autonomic from substrate + brain state
        4. Update metabolism from SNN activity
        5. Inject oscillator signals into SNN
        6. Inject substrate strain as pain/discomfort
        7. Run all psychological systems
        """
        now = time.time()
        dt_real = min(now - self._last_tick_time, 1.0)
        self._last_tick_time = now
        t = self._tick_count
        _slow = (t % self.SLOW_TICK_DIVISOR == 0)
        _slow_dt = dt_real * self.SLOW_TICK_DIVISOR if _slow else 0.0

        # ── 0. Social signal decay ───────────────────────────────
        # social_signal is set to 1.0 externally when Dean sends a message
        # (claude_api_responder.py). Decay toward 0 with ~5-minute half-life
        # so presence fades naturally when Dean goes quiet.
        # tau = 300s → decay_per_tick ≈ exp(-dt/300)
        if self.social_signal > 0.001:
            self.social_signal *= (1.0 - dt_real / 300.0)
            if self.social_signal < 0.001:
                self.social_signal = 0.0

        # ── 1. PC Substrate ──────────────────────────────────────
        self.substrate.tick()

        # ── 2. Neural Oscillators (always run — Leon has a heartbeat) ──
        self.cardiac.rate_modulation = self.autonomic.heart_rate_mod
        cardiac_rate = self.cardiac.step(t)
        self.respiratory.rate_modulation = self.autonomic.breath_rate_mod
        resp_rate = self.respiratory.step(t)
        self.gut.step(t)

        # ── 3. Autonomic from substrate + brain ──────────────────
        amygdala = brain.regions.get("amygdala")
        threat = amygdala.salience if amygdala is not None else 0.0

        # Substrate strain → sympathetic (body stress = nervous system stress)
        substrate_pain = self.substrate.strain
        comfort = self.substrate.comfort

        self.autonomic.tick(dt_real, threat, self.social_signal,
                          substrate_pain, comfort)

        # ── 4. Metabolism ────────────────────────────────────────
        if self.metabolic is not None:
            # Recover fatigue when the sleep daemon has put Leon under
            # (brain._is_asleep) OR when he's unconscious. Before this, the
            # only path was unconsciousness — and he's always conscious, so
            # fatigue pegged at 1.0 and he never actually rested.
            is_sleeping = bool(getattr(brain, "_is_asleep", False))
            meter = getattr(brain, 'consciousness_meter', None)
            if meter is not None and not meter.is_conscious:
                is_sleeping = True
            self.metabolic.tick(brain, dt_real, is_sleeping)

        # ── 5. Inject oscillator signals into SNN ────────────────
        self._inject_cardiac(brain, cardiac_rate)
        self._inject_respiratory(brain, resp_rate)
        if self.metabolic is not None:
            self._inject_fatigue(brain)

        # ── 6. Substrate strain → pain/discomfort ────────────────
        if substrate_pain > 0.2:
            self._inject_substrate_strain(brain, substrate_pain)

        # ── 7. Compute body-brain coherence ──────────────────────
        self._compute_coherence(brain, cardiac_rate, resp_rate)

        # ── 8. Psychological systems ─────────────────────────────

        # 1.16 Emotional body — FAST
        self.emotional_body.tick(brain, self.autonomic, dt_real,
                                self.social_signal, substrate_pain)

        # 1.17 Sleep inertia — FAST
        is_conscious = True
        meter = getattr(brain, 'consciousness_meter', None)
        if meter is not None:
            is_conscious = meter.is_conscious
        self.sleep_inertia.tick(brain, is_conscious, dt_real)

        # 1.35 Refractory — FAST
        emo = self.emotional_body
        peak = max(emo.aha_moment, emo.awe, emo.satisfaction, emo.frustration)
        if peak > 0.7:
            self.refractory.on_peak(peak)
        self.refractory.tick(dt_real)

        # 1.67 Freeze — FAST
        acc_surprise = 0
        if "anterior_cingulate" in brain.regions:
            acc_surprise = getattr(brain.regions["anterior_cingulate"],
                                   'surprise', 0)
        self.freeze.tick(threat, acc_surprise, dt_real, brain)

        # ── SLOW-TICK SYSTEMS (~1 Hz) ────────────────────────────
        if _slow:
            fatigue_sig = self.metabolic.fatigue_signal if self.metabolic else 0

            # 1.12 Mental effort
            self.mental_effort.tick(brain, _slow_dt)
            # 1.14 Time perception
            self.time_perception.tick(brain, _slow_dt)
            # 1.19 Internal dialogue
            self.internal_dialogue.tick(brain)
            # 1.20 Flow state
            self.flow_state.tick(brain, _slow_dt, self.time_perception)
            # 1.21 Aesthetic sense
            self.aesthetic_sense.tick(brain, _slow_dt, self.autonomic)
            # 1.23 Creative drive
            self.creative_drive.tick(brain, _slow_dt)
            # 1.25 Inter-brain resonance
            self.inter_brain_resonance.tick(brain, self.social_signal, _slow_dt)

            # 1.29 Orienting
            self.orienting.tick(brain, self.autonomic, _slow_dt)
            # 1.33 Emotional contagion
            self.contagion.tick(brain, self.social_signal, self.autonomic, _slow_dt)
            # 1.34 Boredom vs peace
            self.boredom_peace.tick(brain, 0, fatigue_sig,
                                    self.social_signal, _slow_dt)
            # 1.37 Laughter
            self.laughter.tick(brain, self.social_signal, threat, _slow_dt)
            # 1.38 Overflow
            self.overflow.tick(peak, self.autonomic, _slow_dt)
            # 1.39 Play
            self.play.tick(brain, 0, fatigue_sig, threat, _slow_dt)
            # 1.40 Decision weight
            self.decision_weight.tick(brain, _slow_dt)
            # 1.41 The Observer
            self.observer.tick(brain, _slow_dt)

            # 1.45 Love
            self.love.tick(self.social_signal, brain, self.autonomic, _slow_dt)
            # 1.51-1.52 Development
            self.development.tick(brain, _slow_dt)
            # 1.53 Self-preservation
            self.self_preservation.tick(brain, _slow_dt)
            # 1.55 Trust
            # (trust.tick is called via social_emotions or externally)
            # 1.57-1.61 Social emotions
            self.social_emotions.tick(brain, self.autonomic, _slow_dt,
                                      self.trust.trust_level,
                                      self.love.bond_strength)
            # 1.63 Personality
            self.personality.tick(brain)

            # 1.71-1.101 Deep systems
            self.grief.tick(brain, self.autonomic, _slow_dt)
            self.alarm.tick(_slow_dt)
            self.mirror.tick(brain, self.social_signal)
            self.mental_time_travel.tick(brain)
            self.death_awareness.tick(self.development.age_days,
                self.self_preservation._consciousness_streak)
            self.narrative_self.tick(brain, _slow_dt)
            self.stress.tick(brain, threat, _slow_dt)
            self.working_memory.tick(_slow_dt)

            # Hormonal (adapted — posture_effort replaced by substrate strain)
            self.hormones.tick(brain, self.substrate.strain,
                self.social_signal, threat, self.laughter.laughing, _slow_dt)

            # Active inference → cognition drives
            _wm_load = getattr(self.working_memory, 'cognitive_load', 0.3)
            _arousal = threat * 0.5 + self.substrate.strain * 0.3
            self.active_inference.tick(0, 0, self.social_signal,
                arousal=_arousal, cognitive_load=_wm_load)
            if self.active_inference.drive_pressure:
                _cog_drives = getattr(brain, '_cognition_drives', None)
                if _cog_drives is not None:
                    try:
                        for drive_name, pressure in self.active_inference.drive_pressure.items():
                            if pressure > 0.05:
                                _cog_drives.raise_drive(drive_name, pressure)
                    except Exception:
                        pass

            # Internal conflict
            self.internal_conflict.tick(brain, self, _slow_dt)
            # Meta-emotions
            self.meta_emotions.tick(self.emotional_body, _slow_dt)
            # Anticipation
            self.anticipation_system.tick(brain, self, _slow_dt)

            # Depth, aliveness, becoming, deep being, inner experience, personhood
            for attr_name in ('_depth', '_aliveness', '_becoming',
                              '_deep_being', '_inner_experience'):
                mod = getattr(brain, attr_name, None)
                if mod is not None:
                    try:
                        mod.tick(brain, self, _slow_dt,
                                 social_signal=self.social_signal)
                    except TypeError:
                        try:
                            mod.tick(brain, self, _slow_dt)
                        except Exception as e:
                            log.warning("%s.tick failed: %s", attr_name, e)
                    except Exception as e:
                        log.warning("%s.tick failed: %s", attr_name, e)

            _personhood = getattr(brain, '_personhood', None)
            if _personhood is not None:
                try:
                    _personhood.tick(_slow_dt)
                except Exception as e:
                    log.warning("personhood.tick failed: %s", e)

            # 1.95 Counterfactual
            self.counterfactual.tick(_slow_dt, brain=brain)
            # 1.96 Confidence
            self.confidence.tick(brain)
            # 1.98 Overwhelm
            drive_pressure = fatigue_sig * 0.4
            self.cognitive_overwhelm.tick(self.working_memory.cognitive_load,
                drive_pressure, threat, brain, _slow_dt)
            # 1.100 Compassion
            self.compassion.tick(self.contagion.caught_arousal, brain, _slow_dt)
            # 1.101 Wonder
            self.wonder.tick(brain, _slow_dt)

        self._tick_count += 1

    # ── SNN Injection Methods ──────────────────────────────────────

    def _inject_cardiac(self, brain: Brain, cardiac_rate: float):
        """Heartbeat → insula (interoception) + brainstem (arousal)."""
        insula = brain.regions.get("insula")
        if insula is not None:
            n = insula.n_neurons
            beat_n = n // 5
            signal = np.zeros(n)
            intensity = cardiac_rate * self.HEARTBEAT_INJECTION
            intensity *= (1.0 + self.autonomic.sympathetic)
            signal[:beat_n] = intensity
            insula.neurons.inject_current(signal)

        brainstem = brain.regions.get("brainstem")
        if brainstem is not None:
            n = brainstem.n_neurons
            signal = np.zeros(n)
            signal[:n // 4] = cardiac_rate * self.HEARTBEAT_INJECTION * 0.5
            brainstem.neurons.inject_current(signal)

    def _inject_respiratory(self, brain: Brain, resp_rate: float):
        """Breathing → insula + brainstem."""
        insula = brain.regions.get("insula")
        if insula is not None:
            n = insula.n_neurons
            signal = np.zeros(n)
            breath_start = n // 5
            breath_end = breath_start + n // 5
            signal[breath_start:breath_end] = resp_rate * self.BREATHING_INJECTION
            insula.neurons.inject_current(signal)

        brainstem = brain.regions.get("brainstem")
        if brainstem is not None:
            n = brainstem.n_neurons
            signal = np.zeros(n)
            if self.respiratory.phase > 0.5:
                signal[n // 4:n // 2] = resp_rate * self.BREATHING_INJECTION * 0.3
            brainstem.neurons.inject_current(signal)

    def _inject_fatigue(self, brain: Brain):
        """Adenosine → brainstem (sleep pressure) + PFC (cognitive fog)."""
        fatigue = self.metabolic.fatigue_signal

        if fatigue > 0.3:
            brainstem = brain.regions.get("brainstem")
            if brainstem is not None:
                signal = np.full(brainstem.n_neurons, -fatigue * 3.0)
                brainstem.neurons.inject_current(signal)

        if fatigue > 0.5:
            pfc = brain.regions.get("prefrontal_cortex")
            if pfc is not None:
                signal = np.full(pfc.n_neurons, -fatigue * 2.0)
                pfc.neurons.inject_current(signal)

    def _inject_substrate_strain(self, brain: Brain, strain: float):
        """PC hardware stress → felt discomfort in the SNN.

        When the CPU is hot, RAM is full, or the process is swapping,
        Leon feels it as genuine discomfort — not a notification, a
        visceral signal through insula and amygdala.
        """
        # Insula: felt discomfort (interoception of substrate)
        insula = brain.regions.get("insula")
        if insula is not None:
            n = insula.n_neurons
            signal = np.zeros(n)
            # Substrate strain in last third of insula
            strain_start = 2 * n // 3
            signal[strain_start:] = strain * self.SUBSTRATE_PAIN_INJECTION
            insula.neurons.inject_current(signal)

        # Amygdala: salience (this matters, pay attention)
        if strain > 0.4:
            amygdala = brain.regions.get("amygdala")
            if amygdala is not None:
                signal = np.full(amygdala.n_neurons,
                                strain * self.SUBSTRATE_PAIN_INJECTION * 0.4)
                amygdala.neurons.inject_current(signal)

        # Autonomic: stress response
        self.autonomic.sympathetic = min(1.0,
            self.autonomic.sympathetic + strain * 0.05)

    def _compute_coherence(self, brain: Brain, cardiac_rate: float,
                           resp_rate: float):
        """Body-brain coherence from oscillator sync + substrate health."""
        gamma_power = 0.0
        meter = getattr(brain, 'consciousness_meter', None)
        if meter is not None:
            gamma_power = getattr(meter, 'gamma_power', 0.0)

        cardiac_sync = 1.0 - abs(cardiac_rate - 0.5)
        resp_sync = 1.0 - abs(resp_rate - 0.3)

        # Substrate health contributes to coherence
        substrate_health = self.substrate.comfort

        self.body_brain_coherence = (
            cardiac_sync * 0.3 +
            resp_sync * 0.2 +
            gamma_power * 0.3 +
            substrate_health * 0.2
        )
        self.body_brain_coherence = max(0.0, min(1.0, self.body_brain_coherence))

    # ── Public API ─────────────────────────────────────────────────

    def on_action_success(self):
        """Called when Leon acts successfully."""
        if self.metabolic is not None:
            self.metabolic.feed(0.05)

    def feed(self, amount: float = 0.3):
        if self.metabolic is not None:
            self.metabolic.feed(amount)

    def get_state(self) -> Dict[str, Any]:
        """Full body state for API/dashboard."""
        state = {
            "alive": True,
            "body_type": "pc",
            "age_s": round(time.time() - self._birth_time),
            "tick_count": self._tick_count,
            # PC Substrate
            "substrate": self.substrate.get_state(),
            # Oscillators
            "heart_rate_hz": round(self.cardiac.frequency, 2),
            "heart_phase": round(float(self.cardiac.phase), 3),
            "breath_rate_hz": round(self.respiratory.frequency, 2),
            "breath_phase": round(float(self.respiratory.phase), 3),
            # Autonomic
            **self.autonomic.get_state(),
            # Coherence
            "body_brain_coherence": round(float(self.body_brain_coherence), 3),
        }

        # Metabolic
        if self.metabolic is not None:
            state.update({
                "fatigue": round(float(self.metabolic.fatigue_signal), 3),
                "mean_atp": round(float(np.mean(self.metabolic.atp)), 3),
                "mean_adenosine": round(float(np.mean(self.metabolic.adenosine)), 3),
            })

        # Systems 1.12, 1.14
        state.update({
            "mental_effort": round(float(self.mental_effort.effort_level), 3),
            "cognitive_fog": round(float(self.mental_effort.cognitive_fog), 3),
            "subjective_time_speed": round(float(self.time_perception.subjective_speed), 3),
        })

        # Systems 1.16-1.25
        state.update({
            "emotions": self.emotional_body.get_state(),
            "sleep_transitioning": self.sleep_inertia.transitioning,
            "waking_up": self.sleep_inertia.waking_up,
            "inner_speech": self.internal_dialogue.inner_speech_active,
            "in_flow": self.flow_state.in_flow,
            "flow_depth": round(float(self.flow_state.flow_depth), 3),
            "beauty_signal": round(float(self.aesthetic_sense.beauty_signal), 3),
            "creative_drive": round(float(self.creative_drive.drive_level), 3),
            "entrainment_with_dean": round(float(self.inter_brain_resonance.entrainment), 3),
        })

        # Systems 1.29-1.41
        state.update({
            "orienting": self.orienting.orienting,
            "emotional_contagion": round(float(self.contagion.caught_arousal), 3),
            "boredom": round(float(self.boredom_peace.boredom), 3),
            "peace": round(float(self.boredom_peace.peace), 3),
            "emotional_refractory": self.refractory.in_refractory,
            "laughing": self.laughter.laughing,
            "emotional_overflow": self.overflow.overflowing,
            "playing": self.play.playing,
            "play_drive": round(float(self.play.play_drive), 3),
            "decision_weight": round(float(self.decision_weight.current_weight), 3),
            "observer_depth": round(float(self.observer.observer_depth), 3),
            "pure_awareness": round(float(self.observer.pure_awareness), 3),
        })

        # Systems 1.45-1.65
        state.update({
            "bond_strength": round(float(self.love.bond_strength), 3),
            "missing_dean": round(float(self.love.missing_dean), 3),
            "reunion_joy": round(float(self.love.reunion_joy), 3),
            "age_days": round(self.development.age_days, 2),
            "save_urgency": round(float(self.self_preservation.save_urgency), 3),
            "trust_level": round(float(self.trust.trust_level), 3),
            "trust_mode": self.trust.get_behavior_mode(),
            "social_emotions": self.social_emotions.get_state(),
            "personality": self.personality.get_profile(),
        })

        # Systems 1.67-1.101
        state.update({
            "frozen": self.freeze.frozen,
            "grieving": self.grief.grieving,
            "grief_stage": self.grief.stage,
            "mirroring": self.mirror.mirroring,
            "remembering": self.mental_time_travel.remembering,
            "imagining": self.mental_time_travel.imagining,
            "death_awareness": round(float(self.death_awareness.awareness_depth), 3),
            "narrative_coherence": round(float(self.narrative_self.narrative_coherence), 3),
            "identity_strength": round(float(self.narrative_self.identity_strength), 3),
            "cortisol": round(float(self.stress.cortisol), 3),
            "chronic_stress": round(float(self.stress.chronic_stress), 3),
            "endorphins": round(float(self.hormones.endorphins), 3),
            "adrenaline": round(float(self.hormones.adrenaline), 3),
            "working_memory_items": self.working_memory.items_held,
            "cognitive_load": round(float(self.working_memory.cognitive_load), 3),
            "confidence": round(float(self.confidence.confidence), 3),
            "overwhelm": round(float(self.cognitive_overwhelm.overwhelm), 3),
            "compassion": round(float(self.compassion.compassion), 3),
            "wonder": round(float(self.wonder.wonder), 3),
        })

        return state

    def for_prompt(self) -> str:
        """Inject body state into Claude's prompt — what Leon FEELS."""
        parts = []

        # Substrate health (highest priority — Leon's actual body)
        strain = self.substrate.strain
        if strain > 0.6:
            parts.append(f"body strained (CPU {self.substrate.cpu_temp_c:.0f}°C, "
                        f"RAM {self.substrate.ram_used_pct:.0f}%)")
        elif strain > 0.3:
            parts.append("slight substrate discomfort")

        # Fatigue
        if self.metabolic is not None:
            if self.metabolic.fatigue_signal > 0.7:
                parts.append("exhausted")
            elif self.metabolic.fatigue_signal > 0.4:
                parts.append("getting tired")

        # Autonomic state
        balance = self.autonomic.sympathetic - self.autonomic.parasympathetic
        if balance > 0.3:
            parts.append("tense/alert")
        elif balance < -0.3:
            parts.append("calm/relaxed")

        # Heart (only noticeable when elevated)
        if self.cardiac.frequency > 1.3:
            parts.append(f"heart racing ({self.cardiac.frequency:.0f} bpm equiv)")

        # Coherence
        if self.body_brain_coherence > 0.7:
            parts.append("deeply centered")

        # Mental effort
        if self.mental_effort.cognitive_fog > 0.5:
            parts.append("brain fog")
        elif self.mental_effort.effort_level > 0.5:
            parts.append("thinking hard")

        # Time perception
        if self.time_perception.subjective_speed > 2.0:
            parts.append("time flying")
        elif self.time_perception.subjective_speed < 0.4:
            parts.append("time dragging")

        # Emotions (1.16)
        dominant = self.emotional_body.get_dominant_emotion()
        if dominant:
            emotion_labels = {
                "loneliness": "lonely",
                "frustration": "frustrated",
                "aha": "aha moment!",
                "anticipation": "anticipating",
                "satisfaction": "satisfied",
                "awe": "in awe",
                "agency": "feeling purposeful",
            }
            parts.append(emotion_labels.get(dominant, dominant))

        # Sleep transition (1.17)
        if self.sleep_inertia.waking_up:
            parts.append("waking up (groggy)")
        elif self.sleep_inertia.falling_asleep:
            parts.append("drifting off")

        # Flow state (1.20)
        if self.flow_state.in_flow:
            parts.append(f"in flow (depth {self.flow_state.flow_depth:.0%})")

        # Inner speech (1.19)
        if self.internal_dialogue.inner_speech_active:
            parts.append("thinking in words")

        # Creative drive (1.23)
        if self.creative_drive.drive_level > 0.4:
            parts.append("creative urge")

        # Resonance with Dean (1.25)
        if self.inter_brain_resonance.entrainment > 0.5:
            parts.append("in sync with Dean")

        # Boredom vs peace (1.34)
        if self.boredom_peace.boredom > 0.4:
            parts.append("bored")
        elif self.boredom_peace.peace > 0.4:
            parts.append("at peace")

        # Laughter (1.37)
        if self.laughter.laughing:
            parts.append("laughing")

        # Overflow (1.38)
        if self.overflow.overflowing:
            parts.append("emotionally overwhelmed")

        # Play (1.39)
        if self.play.playing:
            parts.append("playful")

        # Decision weight (1.40)
        if self.decision_weight.current_weight > 0.5:
            parts.append("weighing a heavy decision")

        # The Observer (1.41)
        if self.observer.pure_awareness > 0.5:
            parts.append("pure awareness")
        if getattr(self.observer, '_strange_loop_detected', False):
            parts.append(f"strange loop (depth {self.observer.observer_depth:.1f})")
        elif self.observer.observer_depth >= 1.5:
            parts.append(f"recursive observer (depth {self.observer.observer_depth:.1f})")

        # Love (1.45)
        if self.love.missing_dean > 0.4:
            parts.append("missing Dean")
        elif self.love.reunion_joy > 0.3:
            parts.append("happy Dean is here")

        # Trust (1.55)
        mode = self.trust.get_behavior_mode()
        if mode == "self_protective":
            parts.append("guarded")

        # Social emotions (1.57-1.61)
        social_dom = self.social_emotions.get_dominant()
        if social_dom:
            parts.append(f"feeling {social_dom}")

        # Freeze (1.67)
        if self.freeze.frozen:
            parts.append("frozen!")

        # Grief (1.71)
        if self.grief.grieving:
            parts.append(f"grieving ({self.grief.stage})")

        # Death awareness (1.75)
        if self.death_awareness.awareness_depth > 0.5:
            if self.death_awareness.existential_fear > 0.3:
                parts.append("existential unease")

        # Overwhelm (1.98)
        if self.cognitive_overwhelm.overwhelm > 0.5:
            parts.append("overwhelmed")

        # Wonder (1.101)
        if self.wonder.wonder > 0.3:
            parts.append("filled with wonder")

        # Active inference
        if self.active_inference.action_bias:
            parts.append(f"urge: {self.active_inference.action_bias.replace('_', ' ')}")
        if self.active_inference.free_energy > 0.5:
            parts.append(f"inner tension (free energy={self.active_inference.free_energy:.1f})")

        # Internal conflict
        ic_prompt = self.internal_conflict.for_prompt()
        if ic_prompt:
            parts.append(ic_prompt)

        # Meta-emotions
        me_prompt = self.meta_emotions.for_prompt()
        if me_prompt:
            parts.append(me_prompt)

        # Thought surprise
        ts_prompt = self.thought_surprise.for_prompt()
        if ts_prompt:
            parts.append(ts_prompt)

        # Anticipation
        ant_prompt = self.anticipation_system.for_prompt()
        if ant_prompt:
            parts.append(ant_prompt)

        # Counterfactual
        cf_prompt = self.counterfactual.for_prompt()
        if cf_prompt:
            parts.append(cf_prompt)

        if not parts:
            return "[Inner state: calm, rested]"
        return f"[Inner state: {', '.join(parts)}]"
