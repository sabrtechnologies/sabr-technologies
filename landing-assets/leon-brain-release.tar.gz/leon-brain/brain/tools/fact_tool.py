"""
Fact correction tool — lets Leon update his own core facts when Dean corrects him.

Problem solved: Dean tells Leon "Wesley is CPO not COO", Leon says "got it", but
next session owner_facts.py + core_facts.md still say COO. The correction lived
only in conversation memory (low strength) and got drowned out by the static
core_facts.md injected into every prompt.

This tool lets Leon:
  1. correct_core_fact — update an existing fact in owner_facts.py by keyword match
  2. add_core_fact     — add a new fact
  3. list_core_facts   — see what's currently seeded (for debugging)

After any mutation, seed_core_facts.py re-runs automatically to sync
knowledge.db + core_facts.md.
"""

from __future__ import annotations

import os
import re
import sys
import time

from brain.tools import register_tool


def _owner_facts_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain", "owner_facts.py")


def _read_owner_facts() -> list:
    """Import OWNER_FACTS from the module."""
    try:
        # Force reimport to get latest
        import importlib
        import brain.owner_facts as _mod
        importlib.reload(_mod)
        return list(_mod.OWNER_FACTS)
    except Exception as e:
        return []


def _write_owner_facts(facts: list) -> bool:
    """Write the OWNER_FACTS list back to owner_facts.py.

    Rewrites ONLY the OWNER_FACTS block. Everything else in the file survives
    untouched: OWNER_CONCEPTS, OWNER_PROJECTS, RESEARCH_SEED_FACTS and any
    list origin.py / concept_map.py / onboarding read from the same module.
    Until 2026-09-02 this regenerated the whole file from a template that
    knew only OWNER_FACTS, so every add_core_fact / correct_core_fact silently
    deleted the other lists — the owner install lost its project names and
    research seeds, and the tests that pinned them went red for days. Same
    family as the Sam gap: a fact pipeline that eats what it was not told to
    keep.
    """
    path = _owner_facts_path()
    header = [
        '"""Owner facts — Dean\'s private knowledge. LEON-ONLY.',
        'This file must NEVER ship to a client build. seed_core_facts imports it;',
        'if it is absent (a client install), no owner facts are seeded.',
        '"""',
        '',
    ]
    block = ['OWNER_FACTS = [']
    for text, tags in facts:
        # Escape any quotes in the text
        escaped_text = text.replace('\\', '\\\\').replace('"', '\\"')
        escaped_tags = tags.replace('\\', '\\\\').replace('"', '\\"')
        block.append(f'    ("{escaped_text}",')
        block.append(f'     "{escaped_tags}"),')
    block.append(']')

    prefix, suffix = header, ['']
    try:
        with open(path, encoding="utf-8") as f:
            existing = f.read().split("\n")
        start = next(i for i, ln in enumerate(existing)
                     if ln.startswith("OWNER_FACTS") and ln.rstrip().endswith("["))
        end = next(i for i in range(start + 1, len(existing))
                   if existing[i].startswith("]"))
        prefix = existing[:start]
        suffix = existing[end + 1:]
        if not suffix or suffix[-1] != "":
            suffix.append("")
    except (OSError, StopIteration):
        pass  # fresh file, or no OWNER_FACTS block yet: header + block only

    lines = prefix + block + suffix
    # Preserve the file's MODE across the rewrite. A fresh temp file is
    # created at the process umask (0644), and os.replace carries that mode
    # onto the target — so before 2026-09-05 every add_core_fact silently
    # reset this file from 0600 back to world-readable, undoing the tenant
    # isolation hardening. The file's own docstring says LEON-ONLY; a write
    # path that re-exposes it on every fact is the same class of bug as the
    # one this function's docstring already describes.
    try:
        _prev_mode = os.stat(path).st_mode & 0o7777
    except OSError:
        _prev_mode = 0o600
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        os.chmod(tmp, _prev_mode)      # set BEFORE the rename: no readable window
        os.replace(tmp, path)
        os.chmod(path, _prev_mode)     # and re-assert after, belt and braces
        return True
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        return False


def _reseed():
    """Re-run seed_core_facts to sync knowledge.db + core_facts.md."""
    try:
        import importlib
        # Reload owner_facts so seed picks up our changes
        import brain.owner_facts
        importlib.reload(brain.owner_facts)
        import brain.seed_core_facts as _seed
        importlib.reload(_seed)
        _seed.seed()
        return True
    except Exception as e:
        print(f"[FACT_TOOL] reseed failed: {e}")
        return False


@register_tool(
    name="correct_core_fact",
    description=(
        "Correct an existing core fact. Use when Dean corrects you on something "
        "(e.g. 'Wesley is CPO not COO'). Finds the fact by keyword match in the "
        "tags, then replaces its text. The correction persists permanently across "
        "all future sessions."
    ),
    params={
        "search_tags": "str — comma-separated tags to find the fact (e.g. 'wesley,leadership')",
        "new_text": "str — the corrected fact text (full replacement)",
        "new_tags": "str — optional: new tags (if omitted, keeps existing tags)",
    },
    required=["search_tags", "new_text"],
    category="memory",
)
def correct_core_fact(search_tags: str, new_text: str, new_tags: str = "") -> dict:
    facts = _read_owner_facts()
    if not facts:
        return {"ok": False, "error": "Could not read owner_facts.py"}

    search_set = {t.strip().lower() for t in search_tags.split(",") if t.strip()}
    if not search_set:
        return {"ok": False, "error": "search_tags is empty"}

    # Find best match: fact whose tags overlap most with search_set
    best_idx = -1
    best_overlap = 0
    for i, (text, tags) in enumerate(facts):
        fact_tags = {t.strip().lower() for t in tags.split(",") if t.strip()}
        overlap = len(search_set & fact_tags)
        if overlap > best_overlap:
            best_overlap = overlap
            best_idx = i

    if best_idx < 0 or best_overlap == 0:
        return {"ok": False, "error": f"No fact found matching tags: {search_tags}"}

    old_text, old_tags = facts[best_idx]
    final_tags = new_tags.strip() if new_tags.strip() else old_tags
    facts[best_idx] = (new_text.strip(), final_tags)

    if not _write_owner_facts(facts):
        return {"ok": False, "error": "Failed to write owner_facts.py"}

    reseeded = _reseed()
    return {
        "ok": True,
        "corrected": {
            "old_text": old_text[:100] + "..." if len(old_text) > 100 else old_text,
            "new_text": new_text[:100] + "..." if len(new_text) > 100 else new_text,
            "tags": final_tags,
        },
        "reseeded": reseeded,
    }


@register_tool(
    name="add_core_fact",
    description=(
        "Add a new permanent fact to Leon's core memory. Use when Dean tells you "
        "something important that should persist forever (new client, new person, "
        "new decision). The fact is seeded at strength=1.0 and appears in every "
        "future session."
    ),
    params={
        "text": "str — the fact text",
        "tags": "str — comma-separated tags for retrieval (e.g. 'client,joe,integrity')",
    },
    required=["text", "tags"],
    category="memory",
)
def add_core_fact(text: str, tags: str) -> dict:
    facts = _read_owner_facts()
    if not facts:
        return {"ok": False, "error": "Could not read owner_facts.py"}

    facts.append((text.strip(), tags.strip()))

    if not _write_owner_facts(facts):
        return {"ok": False, "error": "Failed to write owner_facts.py"}

    reseeded = _reseed()
    return {
        "ok": True,
        "added": {"text": text[:100] + "..." if len(text) > 100 else text, "tags": tags},
        "total_facts": len(facts),
        "reseeded": reseeded,
    }


@register_tool(
    name="list_core_facts",
    description=(
        "List all core facts currently seeded in Leon's permanent memory. "
        "Use to check what you know, find facts to correct, or debug memory issues."
    ),
    params={
        "filter_tags": "str — optional: only show facts matching these comma-separated tags",
    },
    required=[],
    category="memory",
)
def list_core_facts(filter_tags: str = "") -> dict:
    facts = _read_owner_facts()
    if not facts:
        return {"ok": False, "error": "Could not read owner_facts.py"}

    filter_set = {t.strip().lower() for t in filter_tags.split(",") if t.strip()} if filter_tags else set()

    results = []
    for i, (text, tags) in enumerate(facts):
        if filter_set:
            fact_tags = {t.strip().lower() for t in tags.split(",") if t.strip()}
            if not (filter_set & fact_tags):
                continue
        results.append({"index": i, "text": text, "tags": tags})

    return {"ok": True, "facts": results, "total": len(results)}
