#!/usr/bin/env python3
"""
mempack — Leon's memory archiver.

Keep EVERYTHING alive, but pack it into one dense binary container instead of
letting loose text/logs sprawl across disk and RAM. Nothing is deleted.
Every source stays individually accessible by name via an index — you can pull
one record back out without unpacking the whole thing.

Container layout (.mpk = one portable binary):
  [8]   magic  b"LEONMPK1"
  [...]  blob_0 | blob_1 | ... | blob_N     (each lzma-compressed)
  [...]  index  (utf-8 json)                 : [{name, off, csize, osize, sha256, codec}]
  [8]   index_offset  (uint64 little-endian)
  [8]   index_length  (uint64 little-endian)

CLI:
  mempack pack   <out.mpk> <file-or-glob> [more...]   build a container
  mempack list   <out.mpk>                            show contents + ratios
  mempack get    <out.mpk> <name> [dest]              extract one entry
  mempack verify <out.mpk>                            re-hash every blob
"""
import sys, os, io, json, glob, lzma, hashlib, struct, time

MAGIC = b"LEONMPK1"
FOOTER = struct.Struct("<QQ")  # index_offset, index_length


def _sha(b): return hashlib.sha256(b).hexdigest()


def pack(out_path, patterns):
    files = []
    for p in patterns:
        hits = glob.glob(p, recursive=True)
        files.extend(hits if hits else ([p] if os.path.isfile(p) else []))
    files = sorted(set(os.path.abspath(f) for f in files if os.path.isfile(f)))
    if not files:
        print("mempack: no input files matched", file=sys.stderr); return 2

    index, t0 = [], time.time()
    total_o = total_c = 0
    with open(out_path, "wb") as out:
        out.write(MAGIC)
        for f in files:
            raw = open(f, "rb").read()
            comp = lzma.compress(raw, preset=6)
            off = out.tell()
            out.write(comp)
            index.append({
                "name": os.path.basename(f), "src": f, "off": off,
                "csize": len(comp), "osize": len(raw),
                "sha256": _sha(raw), "codec": "lzma",
            })
            total_o += len(raw); total_c += len(comp)
        idx_bytes = json.dumps(index).encode("utf-8")
        idx_off = out.tell()
        out.write(idx_bytes)
        out.write(FOOTER.pack(idx_off, len(idx_bytes)))

    ratio = (total_o / total_c) if total_c else 0
    print(f"packed {len(files)} files  {time.time()-t0:.1f}s")
    print(f"  original   {total_o/1e6:9.1f} MB")
    print(f"  packed     {total_c/1e6:9.1f} MB")
    print(f"  ratio      {ratio:8.1f}x   ({100*(1-total_c/max(total_o,1)):.1f}% smaller)")
    print(f"  container  {out_path}")
    return 0


def _read_index(path):
    with open(path, "rb") as fh:
        assert fh.read(8) == MAGIC, "not a mempack container"
        fh.seek(-FOOTER.size, os.SEEK_END)
        idx_off, idx_len = FOOTER.unpack(fh.read(FOOTER.size))
        fh.seek(idx_off)
        return json.loads(fh.read(idx_len).decode("utf-8"))


def list_(path):
    idx = _read_index(path)
    print(f"{'NAME':40} {'ORIG':>10} {'PACKED':>10} {'RATIO':>7}")
    to = tc = 0
    for e in idx:
        r = e["osize"]/max(e["csize"],1)
        print(f"{e['name'][:40]:40} {e['osize']/1e3:9.1f}K {e['csize']/1e3:9.1f}K {r:6.1f}x")
        to += e["osize"]; tc += e["csize"]
    print("-"*72)
    print(f"{'TOTAL':40} {to/1e6:9.1f}M {tc/1e6:9.1f}M {to/max(tc,1):6.1f}x")


def get(path, name, dest=None):
    idx = _read_index(path)
    e = next((x for x in idx if x["name"] == name), None)
    if not e: print(f"mempack: {name} not in container", file=sys.stderr); return 2
    with open(path, "rb") as fh:
        fh.seek(e["off"]); raw = lzma.decompress(fh.read(e["csize"]))
    if _sha(raw) != e["sha256"]:
        print("mempack: CHECKSUM MISMATCH", file=sys.stderr); return 3
    if dest:
        open(dest, "wb").write(raw); print(f"wrote {dest} ({len(raw)} bytes, verified)")
    else:
        sys.stdout.buffer.write(raw)
    return 0


def verify(path):
    idx = _read_index(path); bad = 0
    with open(path, "rb") as fh:
        for e in idx:
            fh.seek(e["off"]); raw = lzma.decompress(fh.read(e["csize"]))
            ok = _sha(raw) == e["sha256"]
            bad += not ok
            print(f"  {'OK ' if ok else 'BAD'}  {e['name']}")
    print(f"verify: {len(idx)-bad}/{len(idx)} intact")
    return 1 if bad else 0


def main(a):
    if len(a) < 2: print(__doc__); return 1
    cmd = a[0]
    if cmd == "pack":   return pack(a[1], a[2:])
    if cmd == "list":   return list_(a[1])
    if cmd == "get":    return get(a[1], a[2], a[3] if len(a) > 3 else None)
    if cmd == "verify": return verify(a[1])
    print(__doc__); return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
