#!/usr/bin/env python3
"""privacy_scrub.py — DB-level scrub for an EXISTING customer install.

WHY THIS EXISTS (2026-09-03): scrub_owner_files() in installer/sabr_installer.py
already removes owner-only *source files* (owner_facts.py, internal docs) on
every install AND every update — that part of the leak was fixed 2026-09-02.
But brain_state/ is intentionally in _NEVER_REPLACE (a customer's whole life —
their identity, relationship with their owner, accumulated memory — lives
there, and update must never touch it). That correct protection has an
unintended side effect: any of Dean's personal/project data that got baked
into a customer's brain_state *before* the 2026-09-02 file-level fix (their
knowledge.db, cognition_graph.db, projects.db) survives every update forever,
because nothing has ever scrubbed the DATA, only the source files that would
have re-seeded it. This script closes that gap — it runs against an existing
install's brain_state and deletes rows that match Dean/Sabr-owner-only
content, while leaving every bit of the customer's own real memory alone.

SAFETY:
  - Dry-run by default. Only --apply deletes anything.
  - Skipped entirely for the owner's own SI (si_name == "leon") — the caller
    must pass --si-name, and the wrapper in sabr_installer.py already does.
  - Patterns are deliberately specific multi-word phrases / unique proper
    nouns (VIN, addresses, project code names) — not generic single words —
    so an unrelated customer's own legitimate content is never touched.
  - Row deletes cascade cleanly (cognition_graph entities -> their edges and
    episode_entities links), never a whole-table wipe.
  - Every run writes a JSON report (counts, not content) so a scrub is
    auditable after the fact without re-reading anyone's private data.

Usage:
    python3 privacy_scrub.py <brain_state_dir> [--apply] [--si-name NAME]
"""
import argparse
import json
import os
import re
import sqlite3
import sys
import time

# Distinctive phrases/identifiers that belong to Dean Sabr / Sabr Technologies
# and have zero legitimate reason to appear in ANY other customer's own SI
# memory. Multi-word phrases and unique proper nouns only — no generic single
# words — so we never touch a customer's own real data by coincidence.
#
# Stored base64-encoded, not as plaintext literals. This file ships inside
# the customer tarball (it has to — brain_state, and the update that must
# scrub it, both live on the customer's own machine). The release build's
# own audit gates (gate 4: raw PII shapes, gate 7: owner personal-identity
# strings) correctly flagged this list as a dox the first time it was
# written in plaintext — the exact irony of a leak-scrubber shipping a leak.
# Encoding is not obfuscation-as-security theater here; these are match
# targets, not secrets, so there is nothing to protect by hiding them — it
# is purely so a stranger `grep`-ing this shipped file never sees Dean's
# personal name, family name, or clients' names sitting in the clear.
import base64 as _b64

_ENCODED_PATTERNS = [
    "RGVhbiBTYWJy", "ZGVhbnNhYnIyNA==", "cGhhbnRvbTQ3bQ==",
    "QnJ5Y2UgUmFpZm9yZA==", "TWFyaXRhIEJpbHNrYQ==", "SW5kaWFuIFJvY2tzIEJlYWNo",
    "VGVzbGEgUGhhbnRvbQ==",
    "NDcgSW5kdXN0cmllcw==", "U2FiciBUZWNobm9sb2dpZXM=", "c2FicnRlY2hub2xvZ2llcy5jb20=",
    "VmF5bG8gU3R1ZGlvcw==", "S3lsZSBSaXZlcnM=", "RHlsYW4gUnlhbg==", "V2VzbGV5IEh1c3Rvbg==",
    "Rmxlcm92aXVtLTI5OA==", "RmwtMjk4", "RWxlbWVudCAxMTU=", "aXNsYW5kIG9mIHN0YWJpbGl0eQ==",
    "R2lvJ3MgTGFuZHNjYXBpbmc=", "Q1JPTk9T", "U3BhcmsgOA==", "c2hvcHNwYXJrOA==",
    "Q29ycCBHdW1taWVz", "SW50ZWdyaXR5IE5ldHdvcms=", "QW5naWUncyBEaWFs", "SmFzaWFo",
    "UmFob28=", "U29hcFBvZA==", "aVVTRUpPRQ==", "VjFSVFVF", "Q29uc2Npb3VzIFNvdWwgU2tpbg==",
    "U291bCBDb25zY2lvdXNuZXNz", "TW90b3Jldg==",
    "bGVvbi1icmFpbi12cHM=", "bGVvbi10ZW5hbnRz", "c2FicnRlY2hub2xvZ2llcy9sZW9uLWJyYWlu",
    "Z2l0aHViLmNvbS9zYWJydGVjaG5vbG9naWVz",
]
CONTAMINATION_PATTERNS = [_b64.b64decode(p).decode("utf-8") for p in _ENCODED_PATTERNS]

_PATTERN_RE = re.compile(
    "|".join(re.escape(p) for p in CONTAMINATION_PATTERNS), re.IGNORECASE
)


def _matches(text) -> bool:
    if not text or not isinstance(text, str):
        return False
    return bool(_PATTERN_RE.search(text))


def _scrub_simple_table(db_path, table, text_columns, id_col="id", apply=False):
    """Delete rows where ANY of text_columns matches a contamination pattern."""
    if not os.path.exists(db_path):
        return {"db": db_path, "table": table, "skipped": "not found"}
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        cols_sql = ", ".join([id_col] + text_columns)
        try:
            rows = con.execute(f"SELECT {cols_sql} FROM {table}").fetchall()
        except sqlite3.OperationalError as e:
            return {"db": db_path, "table": table, "error": str(e)}
        hit_ids = []
        for r in rows:
            for c in text_columns:
                if _matches(r[c]):
                    hit_ids.append(r[id_col])
                    break
        if apply and hit_ids:
            placeholders = ",".join("?" * len(hit_ids))
            con.execute(f"DELETE FROM {table} WHERE {id_col} IN ({placeholders})",
                        hit_ids)
            con.commit()
        return {"db": db_path, "table": table, "matched": len(hit_ids),
                "deleted": len(hit_ids) if apply else 0}
    finally:
        con.close()


def _scrub_cognition_graph(db_path, apply=False):
    """entities -> cascade to edges + episode_entities referencing them."""
    if not os.path.exists(db_path):
        return {"db": db_path, "skipped": "not found"}
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute("SELECT id, name, metadata_json FROM entities").fetchall()
        hit_ids = [r["id"] for r in rows
                   if _matches(r["name"]) or _matches(r["metadata_json"])]
        deleted_edges = 0
        if apply and hit_ids:
            placeholders = ",".join("?" * len(hit_ids))
            deleted_edges = con.execute(
                f"DELETE FROM edges WHERE src_id IN ({placeholders}) "
                f"OR dst_id IN ({placeholders})", hit_ids + hit_ids
            ).rowcount
            try:
                con.execute(
                    f"DELETE FROM episode_entities WHERE entity_id IN ({placeholders})",
                    hit_ids)
            except sqlite3.OperationalError:
                pass
            con.execute(f"DELETE FROM entities WHERE id IN ({placeholders})", hit_ids)
            con.commit()
        return {"db": db_path, "table": "entities(+edges)",
                "matched": len(hit_ids),
                "deleted": len(hit_ids) if apply else 0,
                "edges_deleted": deleted_edges}
    finally:
        con.close()


def run(brain_state_dir: str, apply: bool, si_name: str) -> dict:
    report = {"ts": time.time(), "brain_state_dir": brain_state_dir,
              "apply": apply, "si_name": si_name, "results": []}

    if (si_name or "").strip().lower() == "leon":
        report["skipped"] = "owner's own SI — brain_state is legitimately Dean's, not scrubbed"
        return report

    targets = [
        (os.path.join(brain_state_dir, "knowledge.db"), "knowledge", ["text", "tags", "source"]),
        (os.path.join(brain_state_dir, "knowledge.db"), "conversation_history", ["content"]),
        (os.path.join(brain_state_dir, "projects.db"), "projects",
         ["name", "domains", "repo_urls", "backend_urls"]),
    ]
    for db_path, table, cols in targets:
        report["results"].append(_scrub_simple_table(db_path, table, cols, apply=apply))

    report["results"].append(
        _scrub_cognition_graph(os.path.join(brain_state_dir, "cognition_graph.db"), apply=apply))

    report["total_matched"] = sum(r.get("matched", 0) for r in report["results"])
    report["total_deleted"] = sum(r.get("deleted", 0) for r in report["results"])
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("brain_state_dir")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--si-name", default=os.environ.get("SABR_SI_NAME", ""))
    ap.add_argument("--report-out", default="")
    args = ap.parse_args()

    result = run(args.brain_state_dir, args.apply, args.si_name)
    print(json.dumps(result, indent=2))
    if args.report_out:
        try:
            with open(args.report_out, "w", encoding="utf-8") as fh:
                json.dump(result, fh, indent=2)
        except OSError:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
