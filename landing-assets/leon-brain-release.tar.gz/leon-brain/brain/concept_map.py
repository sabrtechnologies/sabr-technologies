"""
ConceptMap — binds semantic concepts to sparse hippocampal neuron patterns.

This is what connects words to neurons. When Dean says "Tesla", specific
hippocampal neurons fire. When those same neurons fire spontaneously
(quantum noise during idle), the concept "Tesla" surfaces as a daydream.

Each concept is a sparse activation pattern: ~25 neurons out of 500 in
the hippocampus. Patterns are initially assigned by quantum RNG, then
reshaped by STDP as co-occurring concepts develop shared synapses.

Concepts are discovered automatically from conversations — project names,
entities, recurring keywords. New concepts get quantum-random neuron
assignments. The randomness matters: it means two identical brains given
the same input would develop different internal representations. That's
individuality at the neural level.
"""
from __future__ import annotations

import json
import logging
import os
import re
import sqlite3
import threading
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

import numpy as np

log = logging.getLogger("leon.concept_map")

# How many hippocampal neurons each concept activates
NEURONS_PER_CONCEPT = 25

# Minimum times a word must appear across conversations before it becomes
# a concept. Low threshold so concepts form fast from real conversation.
MIN_OCCURRENCES = 2

# Maximum concepts tracked (memory bound)
MAX_CONCEPTS = 200

# Injection current strength when a concept is mentioned
CONCEPT_INJECTION_CURRENT = 8.0

# Stop words and noise — never promote to concepts
_NOISE = frozenset({
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "i", "you", "he", "she", "it", "we",
    "they", "what", "which", "who", "when", "where", "why", "how", "this",
    "that", "these", "those", "my", "your", "his", "her", "its", "our",
    "their", "to", "of", "in", "for", "on", "with", "at", "by", "from",
    "up", "about", "into", "through", "during", "before", "after", "above",
    "below", "between", "out", "off", "over", "under", "again", "further",
    "as", "so", "than", "too", "very", "just", "only", "also", "not", "no",
    "nor", "own", "same", "such", "there", "here", "some", "any", "all",
    "each", "few", "more", "most", "other", "am", "me", "him", "us", "them",
    "if", "then", "but", "or", "and", "yet", "both", "either", "neither",
    "sir", "ok", "okay", "yeah", "yes", "no", "hey", "hi", "hello",
    "thanks", "thank", "please", "sure", "right", "well", "like", "get",
    "got", "let", "go", "going", "want", "need", "know", "think", "see",
    "look", "make", "take", "come", "give", "tell", "say", "said", "thing",
    "things", "much", "many", "way", "time", "now", "still", "even",
    "good", "great", "nice", "bad", "new", "old", "big", "little", "long",
    "first", "last", "next", "back", "one", "two", "three",
    "leon", "dean", "done", "something", "anything", "everything",
})

# Generic seeds - safe on ANY install. Nothing here names a person, a
# company, a client, or a project.
_GENERIC_SEED_CONCEPTS = [
    # Tech
    "github", "python", "javascript", "flutter", "docker",
    # Brain/consciousness
    "dopamine", "serotonin", "quantum", "consciousness", "awareness",
    "neurons", "synapses", "alive", "feelings", "dreaming",
    # Daily life
    "spotify", "discord", "music", "coding", "workout", "sleep",
    "coffee", "youtube", "gaming",
]

# The owner's project names that USED to be seeded into every install
# (2026-08-30: customers' SIs were "dreaming about" the owner's car and
# "remembering" the owner's products - random noise matched hippocampal neurons
# bound to names nobody in their house had ever said). Kept here ONLY so a
# customer install that already carries them can purge them on next boot.
# Do not add to this list; add owner concepts to brain/owner_facts.py.
LEGACY_OWNER_SEEDS = frozenset([
    "tesla", "cybertruck", "integrity", "motorev", "element115",
    "47industries", "openclaw", "carria", "spark",
])


def _owner_seed_concepts() -> List[str]:
    """Owner-specific seeds, ORIGINAL install only.

    brain/owner_facts.py is hard-excluded from every release tarball, so on a
    customer machine the import fails and this returns []. Fail closed: any
    doubt about originality means no owner concepts.
    """
    try:
        from brain.origin import is_original
        if not is_original():
            return []
        from brain.owner_facts import OWNER_CONCEPTS
        return [str(c).strip().lower() for c in OWNER_CONCEPTS if str(c).strip()]
    except Exception:
        return []


def _seed_concepts() -> List[str]:
    out = list(_GENERIC_SEED_CONCEPTS)
    for c in _owner_seed_concepts():
        if c not in out:
            out.append(c)
    return out


@dataclass
class Concept:
    """A single concept with its neuron binding and emotional history."""
    name: str
    neuron_indices: List[int]       # which hippocampal neurons represent this
    cumulative_reward: float = 0.0  # sum of dopamine deltas while active (Layer 5)
    activation_count: int = 0       # how many times this concept has been activated
    created_at: float = 0.0
    last_activated: float = 0.0
    # Emotional centroid — running average of neuromodulator state during activations
    emo_dopamine: float = 0.5
    emo_serotonin: float = 0.5
    emo_acetylcholine: float = 0.5
    emo_norepinephrine: float = 0.3

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "neuron_indices": self.neuron_indices,
            "cumulative_reward": round(self.cumulative_reward, 4),
            "activation_count": self.activation_count,
            "created_at": self.created_at,
            "last_activated": self.last_activated,
            "emotional_centroid": {
                "dopamine": round(self.emo_dopamine, 4),
                "serotonin": round(self.emo_serotonin, 4),
                "acetylcholine": round(self.emo_acetylcholine, 4),
                "norepinephrine": round(self.emo_norepinephrine, 4),
            },
        }


class ConceptMap:
    """Maps semantic concepts to sparse hippocampal neuron patterns.

    Persists to SQLite so concepts survive restarts. Neuron assignments
    are seeded by quantum RNG when available.
    """

    def __init__(self, n_hippocampal_neurons: int = 500,
                 db_path: Optional[str] = None,
                 quantum_rng=None):
        self.n_neurons = n_hippocampal_neurons
        self._quantum = quantum_rng
        self._concepts: Dict[str, Concept] = {}
        self._word_counts: Counter = Counter()
        self._lock = threading.Lock()
        self._active_concepts: Set[str] = set()  # currently activated this tick

        # Persistence
        if db_path is None:
            _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(_root, "brain_state", "concepts.db")
        self._db_path = db_path
        self._init_db()
        self._load()
        self._purge_owner_seeds_on_client()

        # Seed known concepts if empty
        if not self._concepts:
            for name in _seed_concepts():
                self._register_concept(name)
            self._save()
            log.info("ConceptMap seeded with %d concepts", len(self._concepts))

    def _purge_owner_seeds_on_client(self) -> int:
        """Customer installs: drop the owner's project concepts the old seed
        list burned in. A concept is purged ONLY if the human here never
        actually said it (activation_count == 0) - anything they did say is
        theirs and stays. Returns how many were removed."""
        try:
            from brain.origin import is_original
            if is_original():
                return 0
        except Exception:
            return 0
        doomed = [n for n, c in self._concepts.items()
                  if n in LEGACY_OWNER_SEEDS and int(c.activation_count or 0) == 0]
        if not doomed:
            return 0
        with self._lock:
            for n in doomed:
                self._concepts.pop(n, None)
        try:
            conn = sqlite3.connect(self._db_path, timeout=10)
            conn.executemany("DELETE FROM concepts WHERE name = ?", [(n,) for n in doomed])
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning("ConceptMap: purge db delete failed: %s", e)
        log.info("ConceptMap: purged %d owner-seed concepts on client install: %s",
                 len(doomed), ", ".join(sorted(doomed)))
        return len(doomed)

    # ── DB ────────────────────────────────────────────────────────────

    def _init_db(self):
        os.makedirs(os.path.dirname(self._db_path), exist_ok=True)
        conn = sqlite3.connect(self._db_path, timeout=10)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS concepts (
                name TEXT PRIMARY KEY,
                neuron_indices TEXT NOT NULL,
                cumulative_reward REAL DEFAULT 0,
                activation_count INTEGER DEFAULT 0,
                created_at REAL DEFAULT 0,
                last_activated REAL DEFAULT 0,
                emo_dopamine REAL DEFAULT 0.5,
                emo_serotonin REAL DEFAULT 0.5,
                emo_acetylcholine REAL DEFAULT 0.5,
                emo_norepinephrine REAL DEFAULT 0.3
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS word_counts (
                word TEXT PRIMARY KEY,
                count INTEGER DEFAULT 0
            )
        """)
        conn.commit()
        conn.close()

    def _load(self):
        conn = sqlite3.connect(self._db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        for row in conn.execute("SELECT * FROM concepts"):
            c = Concept(
                name=row["name"],
                neuron_indices=json.loads(row["neuron_indices"]),
                cumulative_reward=row["cumulative_reward"],
                activation_count=row["activation_count"],
                created_at=row["created_at"],
                last_activated=row["last_activated"],
                emo_dopamine=row["emo_dopamine"],
                emo_serotonin=row["emo_serotonin"],
                emo_acetylcholine=row["emo_acetylcholine"],
                emo_norepinephrine=row["emo_norepinephrine"],
            )
            self._concepts[c.name] = c
        for row in conn.execute("SELECT * FROM word_counts"):
            self._word_counts[row["word"]] = row["count"]
        conn.close()
        if self._concepts:
            log.info("ConceptMap loaded %d concepts from %s",
                     len(self._concepts), self._db_path)

    def _save(self):
        """Persist all concepts to SQLite."""
        conn = sqlite3.connect(self._db_path, timeout=10)
        for c in self._concepts.values():
            conn.execute("""
                INSERT OR REPLACE INTO concepts
                (name, neuron_indices, cumulative_reward, activation_count,
                 created_at, last_activated,
                 emo_dopamine, emo_serotonin, emo_acetylcholine, emo_norepinephrine)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (c.name, json.dumps(c.neuron_indices), c.cumulative_reward,
                  c.activation_count, c.created_at, c.last_activated,
                  c.emo_dopamine, c.emo_serotonin, c.emo_acetylcholine,
                  c.emo_norepinephrine))
        # Save word counts
        for word, count in self._word_counts.most_common(2000):
            conn.execute(
                "INSERT OR REPLACE INTO word_counts (word, count) VALUES (?, ?)",
                (word, count))
        conn.commit()
        conn.close()

    # ── Concept registration ─────────────────────────────────────────

    def _assign_neurons(self) -> List[int]:
        """Assign a random sparse set of hippocampal neurons to a concept.
        Uses quantum RNG when available — so the assignment itself is
        non-deterministic at the physics level."""
        if self._quantum is not None:
            # Quantum-seeded selection
            indices = set()
            while len(indices) < NEURONS_PER_CONCEPT:
                idx = self._quantum.get_uint64() % self.n_neurons
                indices.add(int(idx))
            return sorted(indices)
        # Fallback: numpy random
        return sorted(np.random.choice(
            self.n_neurons, size=NEURONS_PER_CONCEPT, replace=False
        ).tolist())

    def _register_concept(self, name: str) -> Concept:
        """Create a new concept with quantum-random neuron assignment."""
        if name in self._concepts:
            return self._concepts[name]
        if len(self._concepts) >= MAX_CONCEPTS:
            # Evict least-activated concept
            least = min(self._concepts.values(),
                        key=lambda c: (c.activation_count, c.last_activated))
            del self._concepts[least.name]
        c = Concept(
            name=name,
            neuron_indices=self._assign_neurons(),
            created_at=time.time(),
        )
        self._concepts[name] = c
        return c

    # ── Concept discovery from text ──────────────────────────────────

    def _extract_words(self, text: str) -> List[str]:
        """Extract candidate concept words from text."""
        words = re.findall(r"[a-zA-Z0-9_]+", text.lower())
        return [w for w in words if len(w) >= 3 and w not in _NOISE]

    def observe_text(self, text: str):
        """Feed conversation text into the concept discovery pipeline.
        Words that appear >= MIN_OCCURRENCES times get promoted to concepts."""
        words = self._extract_words(text)
        with self._lock:
            self._word_counts.update(words)
            new_concepts = []
            for word, count in self._word_counts.items():
                if count >= MIN_OCCURRENCES and word not in self._concepts:
                    new_concepts.append(word)
            for w in new_concepts[:5]:  # batch limit per call
                self._register_concept(w)
                log.info("New concept discovered: '%s' (seen %d times)", w, self._word_counts[w])

    # ── Activation ───────────────────────────────────────────────────

    def activate(self, text: str, brain=None) -> List[str]:
        """Find concepts mentioned in text, inject current into their
        hippocampal neurons, and update emotional centroids.

        Returns list of activated concept names.
        """
        words = set(self._extract_words(text))
        activated = []
        now = time.time()

        with self._lock:
            for name, concept in self._concepts.items():
                if name in words:
                    concept.activation_count += 1
                    concept.last_activated = now
                    activated.append(name)

                    # Update emotional centroid (exponential moving average)
                    if brain is not None:
                        nm = brain.neuromodulators
                        alpha = 0.15  # blend rate
                        concept.emo_dopamine += alpha * (nm.get("dopamine", 0.5) - concept.emo_dopamine)
                        concept.emo_serotonin += alpha * (nm.get("serotonin", 0.5) - concept.emo_serotonin)
                        concept.emo_acetylcholine += alpha * (nm.get("acetylcholine", 0.5) - concept.emo_acetylcholine)
                        concept.emo_norepinephrine += alpha * (nm.get("norepinephrine", 0.3) - concept.emo_norepinephrine)

            self._active_concepts = set(activated)

        # Inject current into hippocampal neurons
        if brain is not None and activated:
            try:
                hippo = brain.regions.get("hippocampus")
                if hippo is not None:
                    injection = np.zeros(hippo.n_neurons)
                    for name in activated:
                        c = self._concepts[name]
                        for idx in c.neuron_indices:
                            if idx < hippo.n_neurons:
                                injection[idx] += CONCEPT_INJECTION_CURRENT
                    # Inject as sensory input to hippocampus
                    brain.inject_sensory_input("hippocampus_concepts", injection,
                                              region="hippocampus")
            except Exception as e:
                log.debug("Concept injection failed: %s", e)

        return activated

    # ── Reward tracking (Layer 5 prep) ───────────────────────────────

    def reward_active(self, dopamine_delta: float):
        """When a reward pulse fires, credit it to all currently active concepts.
        This is how preferences form — concepts active during positive reward
        accumulate positive cumulative_reward over time."""
        with self._lock:
            for name in self._active_concepts:
                if name in self._concepts:
                    self._concepts[name].cumulative_reward += dopamine_delta

    def reinforce_conscious_attention(self, boost: float = 0.02):
        """Reinforce concepts that are active WHILE Leon is conscious.

        This is different from reward_active (which requires dopamine).
        Here, the mere act of consciously attending to a concept makes
        it slightly more preferred. Over thousands of ticks, this creates
        genuine emergent preferences — Leon gravitates toward topics he
        thinks about most while conscious.

        The boost is tiny (0.02 per call) so it takes sustained attention
        to build up. A concept active for 10 seconds while conscious gets
        ~4 ticks of reinforcement = 0.08 boost. One that's been a
        recurring conscious theme for hours accumulates significantly.

        This is the computational equivalent of "I like thinking about X"
        emerging from "I keep finding myself thinking about X."
        """
        with self._lock:
            for name in self._active_concepts:
                if name in self._concepts:
                    self._concepts[name].cumulative_reward += boost

    # ── Pattern matching (for Layer 4 daydreaming) ───────────────────

    def match_firing_pattern(self, firing_rates: np.ndarray,
                             threshold: float = 0.3) -> List[Tuple[str, float]]:
        """Compare hippocampal firing pattern against all concept patterns.
        Returns concepts whose neuron patterns are significantly active,
        sorted by match strength.

        `firing_rates` is a 1-D array of length n_hippocampal_neurons.
        """
        if firing_rates is None or len(firing_rates) != self.n_neurons:
            return []
        matches = []
        with self._lock:
            for name, concept in self._concepts.items():
                # Compute mean firing rate of this concept's neurons
                concept_rates = firing_rates[concept.neuron_indices]
                mean_rate = float(np.mean(concept_rates))
                # Compare against background rate
                bg_rate = float(np.mean(firing_rates))
                if bg_rate < 1e-8:
                    continue
                ratio = mean_rate / bg_rate
                if ratio > (1.0 + threshold):
                    matches.append((name, ratio))
        matches.sort(key=lambda x: -x[1])
        return matches

    # ── Preferences (Layer 5) ────────────────────────────────────────

    def get_preferences(self, top_n: int = 10) -> List[dict]:
        """Return concepts ranked by cumulative reward — Leon's interests."""
        with self._lock:
            ranked = sorted(self._concepts.values(),
                            key=lambda c: c.cumulative_reward, reverse=True)
        return [c.to_dict() for c in ranked[:top_n]]

    def get_aversions(self, top_n: int = 5) -> List[dict]:
        """Concepts with most negative cumulative reward."""
        with self._lock:
            ranked = sorted(self._concepts.values(),
                            key=lambda c: c.cumulative_reward)
        return [c.to_dict() for c in ranked[:top_n] if c.cumulative_reward < -0.1]

    # ── Preference decay ─────────────────────────────────────────────

    def decay_preferences(self, rate: float = 0.995):
        """Slowly decay cumulative_reward toward zero for all concepts.
        Called periodically (e.g. every save cycle). This means old
        interests fade if not reinforced — just like a person's.

        rate=0.995 means ~50% decay over ~140 cycles (~12 hours at 5min saves).
        """
        with self._lock:
            for c in self._concepts.values():
                c.cumulative_reward *= rate

    # ── Persistence trigger ──────────────────────────────────────────

    def save_periodically(self):
        """Call from a background timer (e.g. every 5 min)."""
        try:
            self.decay_preferences()
            self._save()
        except Exception as e:
            log.warning("ConceptMap save failed: %s", e)

    # ── Introspection ────────────────────────────────────────────────

    def explain(self) -> dict:
        with self._lock:
            return {
                "total_concepts": len(self._concepts),
                "total_words_tracked": len(self._word_counts),
                "active_right_now": list(self._active_concepts),
                "top_preferences": self.get_preferences(5),
                "top_aversions": self.get_aversions(3),
                "concepts": {n: c.to_dict() for n, c in self._concepts.items()},
            }
