"""
Persistent conversation history for `BrainAPIResponder`.

Without this, every server restart wipes Leon's memory of prior turns.
Stored in the existing `brain_state/knowledge.db` SQLite as its own
`conversation_history` table — same DB so backups already cover it,
but a separate table so it doesn't pollute knowledge_search results.

Cheap on every turn: one INSERT per role-message. Reads happen exactly
once (on responder boot) — last N turns to seed `self.history`.
"""

from __future__ import annotations

import os
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional


#: Anthropic API ACCEPTS these fields on input messages — anything else
#: (citations, parsed_output, caller, etc.) is output-only and will trigger
#: a 400 invalid_request_error like:
#:   messages.6.content.0.text.parsed_output: Extra inputs are not permitted
#: This caused intermittent chat failures after the block-persistence shipped.
_INPUT_VALID_KEYS = {
    "text":        {"type", "text"},
    "tool_use":    {"type", "id", "name", "input"},
    "tool_result": {"type", "tool_use_id", "content", "is_error"},
    "thinking":    {"type", "thinking", "signature"},
    "image":       {"type", "source"},
}


def _strip_to_input_valid(block: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of `block` containing ONLY the fields Anthropic's
    messages API accepts as input. Drops output-only fields the SDK
    helpfully attaches to its response objects (citations, parsed_output,
    caller, etc.)."""
    if not isinstance(block, dict):
        return block
    t = block.get("type")
    allowed = _INPUT_VALID_KEYS.get(t)
    if not allowed:
        # unknown block type — keep type + drop None-valued extras as a
        # best-effort safety net
        return {k: v for k, v in block.items() if v is not None}
    return {k: block[k] for k in allowed if k in block}


def _block_to_json(obj: Any) -> Any:
    """Default-encoder for `json.dumps` — handles Anthropic SDK content
    blocks (TextBlock, ToolUseBlock) which are pydantic-ish objects.
    Falls through to str() for anything else.

    Critical: strips output-only fields (citations / parsed_output /
    caller / ...) before persisting. Persisted blocks must be valid as
    INPUT for the next API call, not just whatever the SDK echoed back."""
    # Anthropic SDK blocks expose model_dump() (pydantic v2) or dict().
    for attr in ("model_dump", "dict"):
        fn = getattr(obj, attr, None)
        if callable(fn):
            try:
                return _strip_to_input_valid(fn())
            except Exception:
                pass
    if isinstance(obj, dict):
        return _strip_to_input_valid(obj)
    # Last resort: stringify so json.dumps doesn't crash. Loses fidelity
    # but at least the row is persisted.
    return str(obj)


# Header of a sub-agent report (brain/agent_outcomes.py): never an utterance.
DELEGATED_REPORT_PREFIX = "[Delegated agent report"


_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversation_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL    NOT NULL,
    session_id  TEXT    NOT NULL DEFAULT 'default',
    role        TEXT    NOT NULL,    -- 'user' | 'assistant'
    content     TEXT    NOT NULL,
    model       TEXT    DEFAULT '',  -- haiku/sonnet/opus tier on assistant rows
    metadata    TEXT    DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_conv_session_ts
    ON conversation_history (session_id, ts);
"""


class ConversationStore:
    """Thread-safe SQLite wrapper for storing/replaying conversation turns."""

    def __init__(
        self,
        db_path: Optional[str] = None,
        session_id: str = "default",
    ):
        if db_path is None:
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(project_root, "brain_state", "knowledge.db")
        self.db_path = db_path
        self.session_id = session_id
        self._lock = threading.Lock()
        self._init_schema()

    def _init_schema(self) -> None:
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            # busy_timeout prevents boot hang if another process holds the DB
            conn.execute("PRAGMA busy_timeout = 5000")
            conn.execute("PRAGMA journal_mode = WAL")
            for stmt in _SCHEMA.strip().split(";"):
                s = stmt.strip()
                if s:
                    conn.execute(s)
            # HEALING MIGRATION (2026-08-25): upgrade_awareness used to persist
            # its synthetic wake prompt as a role='user' turn, so customer
            # installs (a customer's Mac) painted "You just woke up and something is
            # profoundly different... here's what you're feeling" as if the
            # CUSTOMER typed it. The call site is fixed to persist_history=False;
            # this purge heals databases already poisoned by older builds every
            # time the store opens. Signature is exact-prefix on the synthetic
            # prompt so no real human words can ever match.
            conn.execute(
                "DELETE FROM conversation_history WHERE role='user' AND "
                "content LIKE 'You just woke up and something is profoundly different%'"
            )
            # Claude's expired-OAuth output is infrastructure noise, never a
            # statement from Leon.  The original insertion guard only caught
            # a bare error reply; several older background paths wrapped the
            # same text in a longer status message and preserved it as an
            # assistant turn.  Purge those legacy records on open so neither
            # the dashboard nor future local-context retrieval can replay
            # them.  User turns are deliberately retained even if they quote
            # the error while reporting a problem.
            conn.execute(
                "DELETE FROM conversation_history WHERE role='assistant' AND "
                "lower(content) LIKE '%failed to authenticate: oauth session expired%'"
            )
            # A sub-agent's raw report is not something Leon said (2026-10-04:
            # brain/agent_outcomes.py stored them as assistant turns, so the
            # dashboard painted and spoke them in the browser's system voice
            # and they were replayed to Leon as his own words). The reports
            # live in the knowledge table (source agent_result:<id>); only a
            # conversation row whose report is safely there is removed.
            try:
                conn.execute(
                    "DELETE FROM conversation_history WHERE role='assistant' AND "
                    "content LIKE ? AND EXISTS (SELECT 1 FROM knowledge k WHERE "
                    "k.source = json_extract(conversation_history.metadata, '$.source'))",
                    (DELEGATED_REPORT_PREFIX + "%",),
                )
            except sqlite3.Error:
                pass   # no knowledge table in this database: nothing to heal
            conn.commit()

    def append(
        self,
        role: str,
        content: Any,                       # str OR list-of-blocks (Anthropic format)
        model: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Persist one turn. `content` can be a plain string (chat-only
        turns) OR a list of Anthropic content blocks (text + tool_use +
        tool_result). Lists are JSON-encoded with a sentinel prefix so
        load_recent can tell them apart from legacy text rows.
        Returns the row id, or -1 if content is empty."""
        import json as _json
        # Normalize: lists go in as JSON with a sentinel; everything else
        # as a stripped string. Empty content is skipped.
        # CREDENTIAL GUARD (2026-09-04). A user said her Gmail password out
        # loud to her SI; it landed here verbatim and was then copied into the
        # knowledge table and the FTS index — plaintext, permanent, searchable.
        # The store must refuse to hold a spoken secret, because "please don't
        # say passwords out loud" is advice, not a control. Only the VALUE is
        # replaced, so the turn still reads as "the password is
        # [REDACTED-CREDENTIAL]" and the SI can still react to what happened.
        try:
            from brain.security import redact_credentials_deep as _rcd
            content = _rcd(content)
        except Exception:
            pass  # never let the guard break persistence

        # THE BRAIN'S OWN AUTH FAILING IS NOT SOMETHING THE SI SAID
        # (2026-09-05). When Claude Code's OAuth expires it prints
        # "Failed to authenticate: OAuth session expired and could not be
        # refreshed" and EXITS ZERO, so that line rides all the way through
        # as the assistant's reply -- spoken out loud, and written here as
        # an utterance. Leon's own history carries eight of them from this
        # morning, sitting in his memory as things he said. They are an
        # infrastructure fault, not speech, and a mind's record of itself
        # should not fill up with them.
        if role == "assistant":
            try:
                from brain.security import looks_like_brain_auth_failure as _laf
                if isinstance(content, str) and _laf(content):
                    return -1
            except Exception:
                pass
            # Nor is a delegated sub-agent's raw report (see _init_schema).
            if isinstance(content, str) and content.lstrip().startswith(DELEGATED_REPORT_PREFIX):
                return -1

            # CONFIDENCE CALIBRATION (2026-09-14). The confidence guard/auditor
            # built 2026-09-04 was never actually fed live data -- it had a
            # broken flat import (`from confidence_auditor import ...`) that
            # ModuleNotFoundError'd the moment anything tried to use it, so it
            # sat there fully disconnected: a seatbelt bolted to nothing. Fixed
            # the import; this hooks it at the same ingestion boundary the
            # credential guard already proved safe. Purely observational --
            # logs claim language for calibration, never blocks or alters what
            # gets said. Any failure here must never break persistence.
            try:
                if isinstance(content, str):
                    import re as _re_cg
                    _claim_pat = _re_cg.compile(
                        r"\b(fixed|done|deployed|working now|that('| i)?s fixed|"
                        r"resolved|verified|confirmed working|should work now)\b",
                        _re_cg.IGNORECASE,
                    )
                    if _claim_pat.search(content):
                        from brain.mission.confidence_guard import get_confidence_guard as _gcg
                        _guard = _gcg()
                        _guard.auditor.record_claim(
                            claim=content[:200],
                            confidence=0.9,
                            reason="auto-captured claim language in live reply",
                            layers_checked=["LIVE_REPLY"],
                        )
            except Exception:
                pass  # calibration logging must never break a real reply

        if isinstance(content, list):
            if not content:
                return -1
            stored = "__BLOCKS__" + _json.dumps(content, default=_block_to_json)
        else:
            stored = (content or "").strip() if isinstance(content, str) else str(content)
            if not stored:
                return -1
        meta_str = _json.dumps(metadata or {}, default=str)
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            cur = conn.cursor()
            # Skip an immediate duplicate. The user turn is persisted once
            # "pre-response" (so it survives a restart) and AGAIN when the turn
            # completes — the two writes are consecutive with nothing between,
            # so the transcript AND Leon's own context showed every message
            # twice. If the most recent row is an identical (role, content),
            # don't write it again. Genuine repeats (with an assistant turn in
            # between) aren't consecutive, so they're unaffected.
            last = cur.execute(
                "SELECT id, role, content FROM conversation_history "
                "WHERE session_id = ? ORDER BY id DESC LIMIT 1",
                (self.session_id,),
            ).fetchone()
            if last and last[1] == role and last[2] == stored:
                return last[0]
            cur.execute(
                "INSERT INTO conversation_history (ts, session_id, role, content, model, metadata) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (time.time(), self.session_id, role, stored, model, meta_str),
            )
            conn.commit()
            return cur.lastrowid

    def load_recent(self, limit: int = 24) -> List[Dict[str, Any]]:
        """Return the most recent up-to-N turns in chronological order.
        Each entry is shaped like the Anthropic messages list expects:
        `{"role": "user"|"assistant", "content": str_or_block_list}`.
        Rows starting with the `__BLOCKS__` sentinel are decoded back
        into a content-block list (preserves tool_use / tool_result
        structure across restarts — fixes the 'priming' bug where Sonnet
        sees prior turns as text-only and stops calling tools)."""
        if limit <= 0:
            return []
        import json as _json
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            rows = conn.execute(
                "SELECT role, content FROM conversation_history "
                "WHERE session_id = ? ORDER BY id DESC LIMIT ?",
                (self.session_id, limit),
            ).fetchall()
        out: List[Dict[str, Any]] = []
        for (role, content) in reversed(rows):
            if isinstance(content, str) and content.startswith("__BLOCKS__"):
                try:
                    blocks = _json.loads(content[len("__BLOCKS__"):])
                    # Defensive: strip output-only fields from any row
                    # that was written before the _strip_to_input_valid
                    # fix landed. Without this, replaying ~36 historical
                    # blocks throws 400 invalid_request_error.
                    clean = [_strip_to_input_valid(b) for b in blocks
                             if isinstance(b, dict)]
                    out.append({"role": role, "content": clean})
                    continue
                except Exception:
                    pass  # fall through to plain-text
            out.append({"role": role, "content": content})
        return out

    def load_recent_prioritized(self, limit: int = 400, real_floor: int = 300) -> List[Dict[str, Any]]:
        """Load recent user-directed conversation turns.

        Background prose is retained separately for diagnostics, but it is
        never used as dialogue evidence in a later user conversation.

        Returns turns in chronological order, each shaped for the Anthropic API.
        """
        if limit <= 0:
            return []
        import json as _json
        # Load only turns produced in an actual conversation.  Generated
        # background statements can claim unverified status and must not be
        # replayed as if Leon had told the user something factual.
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            # Get IDs of the real rows
            real_ids = conn.execute(
                "SELECT id, role, content FROM conversation_history "
                "WHERE session_id = ? AND model != 'proactive' "
                "ORDER BY id DESC LIMIT ?",
                (self.session_id, real_floor),
            ).fetchall()

            proactive_ids = []

        # Combine, sort by id (chronological), decode
        combined = list(real_ids) + list(proactive_ids)
        combined.sort(key=lambda r: r[0])

        out: List[Dict[str, Any]] = []
        for (_id, role, content) in combined:
            if isinstance(content, str) and content.startswith("__BLOCKS__"):
                try:
                    blocks = _json.loads(content[len("__BLOCKS__"):])
                    clean = [_strip_to_input_valid(b) for b in blocks
                             if isinstance(b, dict)]
                    out.append({"role": role, "content": clean})
                    continue
                except Exception:
                    pass
            out.append({"role": role, "content": content})
        return out

    def count(self) -> int:
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            (n,) = conn.execute(
                "SELECT COUNT(*) FROM conversation_history WHERE session_id = ?",
                (self.session_id,),
            ).fetchone()
        return int(n)

    def replace_last_assistant(self, original: str, new: str, window_s: float = 600.0) -> bool:
        """Swap the newest assistant row with this exact text (written within
        window_s) for what was actually said. The claim guard corrects a
        reply after the provider already persisted it; without this the
        false version became Leon's memory of what he told Dean."""
        if not original or not new or original == new:
            return False
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            row = conn.execute(
                "SELECT id FROM conversation_history WHERE session_id = ? AND role = 'assistant' "
                "AND content = ? AND ts >= ? ORDER BY id DESC LIMIT 1",
                (self.session_id, original, time.time() - window_s),
            ).fetchone()
            if not row:
                return False
            conn.execute("UPDATE conversation_history SET content = ? WHERE id = ?", (new, row[0]))
            conn.commit()
            return True

    def clear(self) -> int:
        """Wipe history for this session. Returns rows deleted."""
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM conversation_history WHERE session_id = ?",
                (self.session_id,),
            )
            conn.commit()
            return cur.rowcount or 0

    def trim(self, keep_last: int = 200) -> int:
        """Delete all but the most recent `keep_last` turns. Returns
        rows deleted. Run periodically so the table doesn't grow forever."""
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM conversation_history "
                "WHERE session_id = ? AND id NOT IN ("
                "    SELECT id FROM conversation_history "
                "    WHERE session_id = ? ORDER BY id DESC LIMIT ?"
                ")",
                (self.session_id, self.session_id, keep_last),
            )
            conn.commit()
            return cur.rowcount or 0
