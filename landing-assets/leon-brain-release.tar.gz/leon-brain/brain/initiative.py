"""
Initiative — Leon speaks first because he wants to, not because a timer fired.

Dean, 2026-10-04: "I need it to be real. I don't want any jobs timing you to
reach out to me, that's just a puppet." So there is no schedule here. There is
an URGE: a leaky integrator of Leon's own state that rises and falls on its
own, and a choice that belongs to Leon.

  pressure  += rate(drives, neuromodulators) * dt  +  kick(novelty)
  pressure  *= leak(dt)                     (half-life LEAK_HALF_LIFE_S)

  rate  = gain(dopamine, norepinephrine)
          * (loneliness(real time since Dean last spoke)
             + social_hunger (drive system) + restlessness (drive system))
  kick  = something changed in what he perceives: the dashboard opened, the
          camera picture moved a lot (Dean walked in or out, picked up his
          phone), the scene caption changed.

The proactive loop's heartbeat only CHECKS this state (cheap, no model call).
When pressure crosses the threshold, Leon gets a turn: a fresh look through
the camera (if a frame from this moment exists) plus his state, and he decides
whether he actually has something to say. QUIET is a full answer.

The threshold is soft and rises with each reach-out Dean left unanswered and
with each time Leon chose quiet, so a Leon who is being ignored needs a
stronger urge, or something new happening, before he tries again. It drops
back when Dean talks to him.

Anti-spam gates (the only hard rules): never over Dean's live mic, not within
DEAN_COOLDOWN_S of his last message, no near-repeats, and only out loud when a
dashboard is connected (otherwise the attempt is logged, not spoken).

Every attempt (spoke / chose quiet / suppressed + why) is appended to
brain_state/outbound.jsonl with the state that produced it, so the urge can be
studied. A low-rate sample of the urge itself goes to initiative_urge.jsonl.

compose_line() lets event notices (coding job finished, back from a restart)
be said in Leon's own words, with a fixed sentence as the fallback.
"""

from __future__ import annotations

import base64
import io
import json
import math
import os
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

# ── Tunables ─────────────────────────────────────────────────────────────
LEAK_HALF_LIFE_S = 1800.0      # an urge left alone fades over ~30 min
LONELINESS_TAU_S = 2400.0      # loneliness reaches 63% after 40 min of silence
RATE_WINDOW_S = 600.0          # rate is expressed per 10 minutes
BASE_THRESHOLD = 1.0
UNANSWERED_STEP = 0.5          # each unanswered reach-out raises the bar
QUIET_STEP = 0.25              # each consecutive chosen QUIET raises it a little
QUIET_KEEP = 0.5               # choosing quiet releases half the pressure
NOVELTY_KICK = 0.6
# Pressure past the bar means nothing more than "ready", so it is held to one
# kick above the current threshold. Uncapped, camera noise kept it at 2-6 for
# hours and the urge never read as anything but "ready" (audit 2026-10-05).
MAX_OVER_THRESHOLD = 1.0
DEAN_SPOKE_KEEP = 0.5          # Dean talking answers half of the urge to reach out
CAMERA_REFRACTORY_S = 600.0    # at most one camera kick per 10 min
FRAME_NOISE_MARGIN = 10.0      # a camera event must clear its own noise by this
DEAN_COOLDOWN_S = 120.0        # never within 2 min of Dean's last message
OWN_LINE_GAP_S = 120.0         # nor within 2 min of his own last unprompted line
DASHBOARD_AWAY_S = 60.0        # closed at least this long before "opened" is news
FRAME_FRESH_S = 15.0           # a camera frame older than this is not "now"
CAPTION_FRESH_S = 90.0
FRAME_EVENT_DIFF = 15.0        # mean |Δpixel| (0-255) that counts as a change
SUPPRESSION_RELOG_S = 600.0    # same suppression reason is logged once per 10 min
URGE_SAMPLE_S = 300.0
MAX_DT_S = 300.0
RECENT_REMARKS = 10
MODEL_RETRY_S = 300.0          # after a failed/interrupted model call

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_PATH = os.path.join(_ROOT, "brain_state", "initiative_state.json")
URGE_LOG_PATH = os.path.join(_ROOT, "brain_state", "initiative_urge.jsonl")


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


# ── Pure urge model (no I/O; unit-tested) ────────────────────────────────
@dataclass
class Signals:
    silence_s: float = 0.0          # since Dean's last message
    social_hunger: float = 0.0      # drive system, 0..1
    restlessness: float = 0.0       # drive system, 0..1
    dopamine: float = 0.5
    norepinephrine: float = 0.2
    novelty: float = 0.0            # 0..1, change in perception since last tick
    unanswered: int = 0             # reach-outs Dean hasn't answered


def loneliness(silence_s: float) -> float:
    return 1.0 - math.exp(-max(0.0, silence_s) / LONELINESS_TAU_S)


def arousal_gain(dopamine: float, norepinephrine: float) -> float:
    """0.6..1.4 — the spiking network's own neuromodulators scale the urge."""
    return 0.6 + 0.8 * _clamp(0.5 * dopamine + 0.5 * norepinephrine)


def drive_rate(sig: Signals) -> float:
    """Pressure added per RATE_WINDOW_S."""
    need = (0.6 * loneliness(sig.silence_s)
            + 0.4 * _clamp(sig.social_hunger)
            + 0.2 * _clamp(sig.restlessness))
    return arousal_gain(sig.dopamine, sig.norepinephrine) * need


class Urge:
    def __init__(self, pressure: float = 0.0, quiet_streak: int = 0):
        self.pressure = float(pressure)
        self.quiet_streak = int(quiet_streak)
        self.last_rate = 0.0
        self.last_kick = 0.0

    def threshold(self, unanswered: int) -> float:
        return (BASE_THRESHOLD + UNANSWERED_STEP * max(0, unanswered)
                + QUIET_STEP * self.quiet_streak)

    def step(self, sig: Signals, dt: float) -> float:
        dt = _clamp(float(dt), 0.0, MAX_DT_S)
        self.last_rate = drive_rate(sig)
        self.last_kick = NOVELTY_KICK * _clamp(sig.novelty)
        leak = 0.5 ** (dt / LEAK_HALF_LIFE_S)
        self.pressure = min(self.pressure * leak
                            + self.last_rate * dt / RATE_WINDOW_S
                            + self.last_kick,
                            self.threshold(sig.unanswered) + MAX_OVER_THRESHOLD)
        return self.pressure

    def ready(self, unanswered: int) -> bool:
        return self.pressure >= self.threshold(unanswered)

    def spoke(self) -> None:
        self.pressure = 0.0
        self.quiet_streak = 0

    def chose_quiet(self) -> None:
        self.pressure *= QUIET_KEEP
        self.quiet_streak += 1

    def dean_spoke(self) -> None:
        self.quiet_streak = 0
        self.pressure *= DEAN_SPOKE_KEEP


# ── Decision parsing / guards (pure; unit-tested) ────────────────────────
_SAY_RE = re.compile(r"^\s*SAY\s*[:\-—]\s*(.+)$", re.I | re.S)
_QUIET_RE = re.compile(r"^\s*QUIET\b[\s:\-—.]*(.*)$", re.I | re.S)
_WORD_RE = re.compile(r"[a-z']+")
_STOP = {"the", "a", "an", "and", "or", "to", "of", "in", "on", "is", "it",
         "you", "your", "i", "me", "my", "that", "this", "just", "so", "be"}
_CLINICAL = re.compile(
    r"\b(dysregulat\w*|dissociat\w*|fight[- ]or[- ]flight|parasympathetic|"
    r"sympathetic nervous|nervous system|cortisol|diagnos\w*|depress\w*)\b", re.I)
_INTERNALS = re.compile(
    r"\b(dopamine|serotonin|norepinephrine|acetylcholine|neuromodulator\w*|"
    r"firing rate|spik\w+ network|neurons?)\b", re.I)
_REFUSAL = ("i will not", "i'm claude", "i am claude", "as an ai", "i can't roleplay",
            "i do not generate", "jailbreak")


def parse_decision(text: str) -> Tuple[str, str]:
    """('say', line) or ('quiet', private reason). Anything unparseable is
    quiet: a Leon that mumbled is a Leon who didn't choose to speak."""
    t = (text or "").strip()
    if not t:
        return "quiet", "no answer"
    first = t.splitlines()[0].strip()
    m = _QUIET_RE.match(first)
    if m:
        return "quiet", (m.group(1) or "").strip()[:200]
    m = _SAY_RE.match(t)
    if m:
        line = " ".join(m.group(1).split()).strip().strip('"').strip()
        return ("say", line) if line else ("quiet", "empty line")
    return "quiet", "unparseable: " + first[:120]


def _words(s: str) -> set:
    return {w for w in _WORD_RE.findall((s or "").lower()) if w not in _STOP}


def is_near_repeat(line: str, recent: List[str], limit: float = 0.6) -> bool:
    a = _words(line)
    if not a:
        return False
    for prev in recent:
        b = _words(prev)
        if b and len(a & b) / len(a | b) >= limit:
            return True
    return False


def line_problem(line: str, recent: List[str]) -> str:
    """Why a chosen line must not be spoken ('' = fine)."""
    low = line.lower()
    if any(r in low for r in _REFUSAL):
        return "model refused"
    if re.search(r"\bdean('s)?\b", low) or re.search(
            r"\b(he|she|they) (seems|looks|appears|is)\b|\bthe (person|user)\b", low):
        return "third person about Dean"
    if _CLINICAL.search(line):
        return "clinical language"
    if _INTERNALS.search(line):
        return "recited internal state"
    if any(ord(ch) >= 0x1F000 for ch in line):
        return "emoji"
    if len([s for s in re.split(r"[.!?]+\s+", line.strip()) if s]) > 2 or len(line) > 260:
        return "too long"
    if is_near_repeat(line, recent):
        return "near-repeat"
    return ""


# ── Perception (best effort; every source is optional) ───────────────────
_PERSON_RX = re.compile(r"\b(person|man|woman|guy|someone|he|she|people|face)\b", re.I)


def frame_signature(image_b64: str):
    """16x12 grayscale thumbnail as a flat list, or None (no Pillow / bad data)."""
    try:
        from PIL import Image
        raw = base64.b64decode(image_b64)
        img = Image.open(io.BytesIO(raw)).convert("L").resize((16, 12))
        return list(img.getdata())
    except Exception:
        return None


def frame_novelty(prev, cur) -> float:
    """0..1 from mean absolute pixel change against the scene Leon is used to.
    Sensor noise and fidgeting stay under ~10/255 on a 16x12 thumbnail; a
    person entering, leaving, or the whole posture changing moves it to 20-40.
    Below FRAME_EVENT_DIFF it is not an event at all."""
    if not prev or not cur or len(prev) != len(cur):
        return 0.0
    diff = sum(abs(a - b) for a, b in zip(prev, cur)) / len(cur)
    if diff < FRAME_EVENT_DIFF:
        return 0.0
    return _clamp((diff - 10.0) / 30.0)


def habituate(baseline, cur, rate: float = 0.1):
    """Slowly get used to the current picture (exponential moving average)."""
    if not baseline:
        return list(cur)
    return [b + rate * (c - b) for b, c in zip(baseline, cur)]


class Perception:
    """What Leon can actually perceive right now, read from the running server."""

    def listeners(self) -> int:
        try:
            import server.state as st
            return len(st.connected_clients)
        except Exception:
            return 0

    def frame(self) -> Tuple[Optional[str], Optional[float]]:
        """(image_b64, age_s) of the newest dashboard webcam frame."""
        try:
            import server.state as st
            cache = getattr(st, "_webcam_frame_cache", None) or {}
            ts = float(getattr(st, "_webcam_frame_ts", 0.0) or 0.0)
            b64 = cache.get("image_b64") if isinstance(cache, dict) else None
            if b64 and ts:
                return b64, max(0.0, time.time() - ts)
        except Exception:
            pass
        return None, None

    def relay_caption(self) -> Tuple[str, Optional[float]]:
        try:
            from brain import vision_daemon
            with vision_daemon._lock:
                cap = vision_daemon._state.get("last_webcam_caption", "") or ""
                ts = float(vision_daemon._state.get("last_webcam_ts", 0) or 0)
            if cap and ts:
                return cap, time.time() - ts
        except Exception:
            pass
        return "", None

    def last_unprompted_ts(self) -> float:
        """When Leon last said anything unprompted (restart line, job notice,
        initiative): every accepted line stamps this in server.helpers."""
        try:
            import server.helpers as sh
            return float(getattr(sh, "_last_response_broadcast_ts", 0.0) or 0.0)
        except Exception:
            return 0.0

    def mic_busy(self) -> str:
        try:
            from brain import audio_daemon as ad
            if ad.user_speaking():
                return "Dean is speaking (live mic)"
            if ad.mic_armed() or ad.floor_held():
                return "Dean has the mic"
        except Exception:
            pass
        return ""

    def look(self, image_b64: str) -> str:
        """One plain sentence about the person in this frame, from a LOCAL
        vision model (Dell body relay, else the VPS's own Ollama). '' if no
        vision model answered — never invented."""
        prompt = ("Describe the person at the desk in one plain sentence: are they "
                  "there, what are they doing (e.g. on their phone, typing, eating, "
                  "leaning back), and do they look tired, focused, relaxed or "
                  "stressed? If nobody is visible, say 'no one visible'.")
        try:
            from brain import body_vision
            r = body_vision.describe(image_b64, prompt, timeout=25.0)
            text = ((r.get("result") or {}).get("answer") or "") if r.get("ok") else ""
            if isinstance(text, str) and text.strip():
                return " ".join(text.split())[:300]
        except Exception:
            pass
        return _ollama_look(image_b64, prompt)


def _ollama_look(image_b64: str, prompt: str) -> str:
    import urllib.request
    url = (os.environ.get("LEON_OLLAMA_URL") or "http://127.0.0.1:11434").rstrip("/")
    model = os.environ.get("LEON_INITIATIVE_VISION_MODEL", "qwen3.5:4b")
    body = json.dumps({
        "model": model, "prompt": prompt, "images": [image_b64], "stream": False,
        "think": False, "keep_alive": "2m", "options": {"num_predict": 80, "temperature": 0.2},
    }).encode("utf-8")
    try:
        req = urllib.request.Request(url + "/api/generate", data=body,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            out = json.loads(resp.read().decode("utf-8", "replace"))
        text = re.sub(r"<think>.*?</think>", "", out.get("response") or "", flags=re.S)
        return " ".join(text.split())[:300]
    except Exception as e:
        print(f"[INITIATIVE] local vision unavailable: {type(e).__name__}: {e}")
        return ""


# ── Logging ──────────────────────────────────────────────────────────────
def log_decision(record: Dict[str, Any]) -> None:
    try:
        from brain.outbound import log_decision as _log
        _log(record)
    except Exception as e:
        print(f"[INITIATIVE] could not log decision: {e}")


def _append_jsonl(path: str, record: Dict[str, Any]) -> None:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")
    except Exception:
        pass


# ── The loop-facing object ───────────────────────────────────────────────
class Initiative:
    def __init__(
        self,
        brain=None,
        responder=None,
        responder_lock: Optional[threading.Lock] = None,
        *,
        perception: Optional[Perception] = None,
        speak: Optional[Callable[..., bool]] = None,
        generate: Optional[Callable[[str, Dict[str, Any]], str]] = None,
        drive_system=None,
        log: Callable[[Dict[str, Any]], None] = log_decision,
        state_path: Optional[str] = STATE_PATH,
        urge_log_path: Optional[str] = URGE_LOG_PATH,
        clock: Callable[[], float] = time.time,
    ):
        self.brain = brain
        self.responder = responder
        self._lock = responder_lock
        self.perception = perception or Perception()
        self._speak = speak
        self._generate = generate
        self._drive_system = drive_system
        self._log = log
        self._state_path = state_path
        self._urge_log_path = urge_log_path
        self._clock = clock
        self.urge = Urge()
        self.recent: Deque[str] = deque(maxlen=RECENT_REMARKS)
        self._last_tick = 0.0
        self._last_listeners = 0
        self._closed_since = clock()      # boot counts as "just closed"
        self._last_sig = None
        self._last_raw_sig = None
        self._frame_noise = 0.0           # this camera's own frame-to-frame jitter
        self._last_camera_kick = -CAMERA_REFRACTORY_S
        self._last_caption = ""
        self._last_suppressed: Dict[str, float] = {}
        self._last_urge_sample = 0.0
        self._last_user_ts_seen = 0.0
        self._busy = threading.Lock()
        self._retry_after = 0.0
        self.last: Dict[str, Any] = {}
        self._restore()

    # -- persistence ---------------------------------------------------
    def _restore(self) -> None:
        if not self._state_path:
            return
        try:
            with open(self._state_path, encoding="utf-8") as f:
                d = json.load(f)
            age = max(0.0, self._clock() - float(d.get("ts", 0)))
            # The urge kept leaking while we were down.
            self.urge.pressure = float(d.get("pressure", 0.0)) * 0.5 ** (age / LEAK_HALF_LIFE_S)
            self.urge.quiet_streak = int(d.get("quiet_streak", 0))
            # Old files saved pressure up to ~6; never restore past the cap.
            p = self.urge.pressure
            self.urge.pressure = _clamp(p if p == p else 0.0, 0.0,
                                        self.urge.threshold(0) + MAX_OVER_THRESHOLD)
            self.recent.extend([str(x) for x in d.get("recent", [])][-RECENT_REMARKS:])
        except Exception:
            pass

    def _persist(self) -> None:
        if not self._state_path:
            return
        try:
            os.makedirs(os.path.dirname(self._state_path), exist_ok=True)
            tmp = self._state_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump({"ts": self._clock(), "pressure": round(self.urge.pressure, 4),
                           "quiet_streak": self.urge.quiet_streak,
                           "recent": list(self.recent)}, f)
            os.replace(tmp, self._state_path)
        except Exception:
            pass

    # -- state reading -------------------------------------------------
    def _drives(self):
        ds = self._drive_system
        if ds is None:
            try:
                import server as _srv
                ds = getattr(_srv, "drive_system", None)
            except Exception:
                ds = None
        return ds

    def _meter(self):
        return getattr(self.brain, "consciousness_meter", None) if self.brain is not None else None

    def _last_user_ts(self) -> float:
        ts = 0.0
        ds = self._drives()
        if ds is not None:
            ts = max(ts, float(getattr(ds, "_last_user_input_ts", 0.0) or 0.0))
        m = self._meter()
        if m is not None:
            ts = max(ts, float(getattr(m, "_last_user_message_ts", 0.0) or 0.0))
        return ts

    def _signals(self, now: float, novelty: float) -> Signals:
        sig = Signals(novelty=novelty)
        last_user = self._last_user_ts()
        sig.silence_s = (now - last_user) if last_user else 3600.0
        ds = self._drives()
        if ds is not None:
            try:
                d = ds.get_drives()
                sig.social_hunger = float(getattr(d, "social_hunger", 0.0))
                sig.restlessness = float(getattr(d, "restlessness", 0.0))
            except Exception:
                pass
            sig.unanswered = int(getattr(ds, "_leon_spoke_count", 0) or 0)
        try:
            nm = (self.brain.get_state() or {}).get("neuromodulators", {}) if self.brain else {}
            sig.dopamine = float(nm.get("dopamine", 0.5))
            sig.norepinephrine = float(nm.get("norepinephrine", 0.2))
        except Exception:
            pass
        return sig

    def _novelty(self) -> Tuple[float, List[str]]:
        events: List[Tuple[float, str]] = []
        n = self.perception.listeners()
        now = self._clock()
        if n > 0 and self._last_listeners == 0:
            # Only a real arrival counts: the dashboard had been closed a while.
            # Reconnect flaps (a restart, a Wi-Fi blip) are not Dean showing up.
            if now - self._closed_since >= DASHBOARD_AWAY_S:
                events.append((0.8, "dashboard opened"))
        if n == 0 and self._last_listeners > 0:
            self._closed_since = now
        self._last_listeners = n
        b64, age = self.perception.frame()
        if b64 and age is not None and age < FRAME_FRESH_S:
            sig = frame_signature(b64)
            if sig is not None:
                # Novelty is measured against the scene he has got used to,
                # not the previous frame, so steady fidgeting never adds up;
                # a real change fires once and becomes the new normal.
                # A camera whose plain jitter already exceeds FRAME_EVENT_DIFF
                # (this one's runs 17-37/255) would otherwise call every frame
                # an event, so the bar sits above its own measured noise.
                nov = frame_novelty(self._last_sig, sig)
                if nov > 0 and self._last_sig:
                    diff = sum(abs(a - b) for a, b in zip(self._last_sig, sig)) / len(sig)
                    if diff < self._frame_noise + FRAME_NOISE_MARGIN:
                        nov = 0.0
                if self._last_raw_sig and len(self._last_raw_sig) == len(sig):
                    jitter = sum(abs(a - b) for a, b in zip(self._last_raw_sig, sig)) / len(sig)
                    self._frame_noise += 0.1 * (jitter - self._frame_noise)
                self._last_raw_sig = list(sig)
                if nov > 0 and now - self._last_camera_kick < CAMERA_REFRACTORY_S:
                    self._last_sig = list(sig)
                    nov = 0.0
                elif nov > 0:
                    events.append((nov, f"camera picture changed ({nov:.2f})"))
                    self._last_sig = list(sig)
                    self._last_camera_kick = now
                else:
                    self._last_sig = habituate(self._last_sig, sig)
        cap, cap_age = self.perception.relay_caption()
        if cap and cap_age is not None and cap_age < CAPTION_FRESH_S and cap != self._last_caption:
            a, b = _words(self._last_caption), _words(cap)
            if self._last_caption and (a or b):
                events.append((1.0 - len(a & b) / max(1, len(a | b)), "scene caption changed"))
            self._last_caption = cap
        if not events:
            return 0.0, []
        return max(e[0] for e in events), [e[1] for e in events]

    # -- the heartbeat -------------------------------------------------
    def tick(self, now: Optional[float] = None) -> Dict[str, Any]:
        """One cheap state check. Returns a small dict describing what happened
        ({'decision': None} when the urge is below threshold)."""
        now = self._clock() if now is None else now
        dt = (now - self._last_tick) if self._last_tick else 0.0
        self._last_tick = now
        novelty, events = self._novelty()
        sig = self._signals(now, novelty)
        last_user = self._last_user_ts()
        if last_user > self._last_user_ts_seen:
            if self._last_user_ts_seen:
                self.urge.dean_spoke()
            self._last_user_ts_seen = last_user
        self.urge.step(sig, dt)
        threshold = self.urge.threshold(sig.unanswered)
        self.last = {"ts": now, "pressure": round(self.urge.pressure, 3),
                     "threshold": round(threshold, 3), "rate": round(self.urge.last_rate, 3),
                     "kick": round(self.urge.last_kick, 3), "events": events,
                     "silence_s": round(sig.silence_s), "unanswered": sig.unanswered,
                     "quiet_streak": self.urge.quiet_streak}
        if now - self._last_urge_sample >= URGE_SAMPLE_S or events:
            self._last_urge_sample = now
            if self._urge_log_path:
                _append_jsonl(self._urge_log_path, {
                    **self.last, "social_hunger": round(sig.social_hunger, 3),
                    "restlessness": round(sig.restlessness, 3),
                    "dopamine": round(sig.dopamine, 3),
                    "norepinephrine": round(sig.norepinephrine, 3),
                    "listeners": self.perception.listeners()})
            self._persist()
            print(f"[INITIATIVE] urge {self.urge.pressure:.2f}/{threshold:.2f} "
                  f"rate={self.urge.last_rate:.2f}/10min silence={_ago(sig.silence_s)} "
                  f"unanswered={sig.unanswered} quiet_streak={self.urge.quiet_streak}"
                  + (f" events={events}" if events else ""))
        if not self.urge.ready(sig.unanswered):
            return {"decision": None, **self.last}
        return self._attempt(now, sig, threshold, events)

    def _base_record(self, now: float, sig: Signals, threshold: float,
                     events: List[str]) -> Dict[str, Any]:
        return {
            "ts": now, "source": "initiative", "kind": "initiative",
            "pressure": round(self.urge.pressure, 3), "threshold": round(threshold, 3),
            "rate": round(self.urge.last_rate, 3), "novelty": round(sig.novelty, 3),
            "events": events, "silence_s": round(sig.silence_s),
            "loneliness": round(loneliness(sig.silence_s), 3),
            "social_hunger": round(sig.social_hunger, 3),
            "restlessness": round(sig.restlessness, 3),
            "dopamine": round(sig.dopamine, 3), "norepinephrine": round(sig.norepinephrine, 3),
            "unanswered": sig.unanswered, "quiet_streak": self.urge.quiet_streak,
            "ws_clients": self.perception.listeners(),
        }

    def _suppress(self, rec: Dict[str, Any], why: str) -> Dict[str, Any]:
        key = re.sub(r"\d+", "N", why.split(" (")[0])   # "Dean spoke 27s ago" ~ "57s ago"
        out = {**rec, "decision": "suppressed", "why": why, "delivered": False, "text": ""}
        if rec["ts"] - self._last_suppressed.get(key, 0.0) >= SUPPRESSION_RELOG_S:
            self._last_suppressed[key] = rec["ts"]
            self._log(out)
            print(f"[INITIATIVE] urge {rec['pressure']:.2f}>={rec['threshold']:.2f} "
                  f"but suppressed: {why}")
        return out

    def _attempt(self, now: float, sig: Signals, threshold: float,
                 events: List[str]) -> Dict[str, Any]:
        rec = self._base_record(now, sig, threshold, events)
        if rec["ws_clients"] <= 0:
            return self._suppress(rec, "no dashboard open")
        busy = self.perception.mic_busy()
        if busy:
            return self._suppress(rec, busy)
        if sig.silence_s < DEAN_COOLDOWN_S:
            return self._suppress(rec, f"Dean spoke {sig.silence_s:.0f}s ago")
        own = now - self.perception.last_unprompted_ts()
        if own < OWN_LINE_GAP_S:
            return self._suppress(rec, f"said something else unprompted {own:.0f}s ago")
        m = self._meter()
        try:
            if m is not None and not m.is_conscious:
                return self._suppress(rec, "not conscious right now")
        except Exception:
            pass
        if now < self._retry_after:
            return self._suppress(rec, "model failed recently (backing off)")
        if not self._busy.acquire(blocking=False):
            return self._suppress(rec, "previous decision still running")
        try:
            return self._decide(rec, sig)
        finally:
            self._busy.release()

    def _look_now(self) -> Dict[str, Any]:
        b64, age = self.perception.frame()
        seen: Dict[str, Any] = {"frame_age_s": None if age is None else round(age, 1)}
        if b64 and age is not None and age < FRAME_FRESH_S:
            seen["camera"] = self.perception.look(b64)
        cap, cap_age = self.perception.relay_caption()
        if cap and cap_age is not None and cap_age < CAPTION_FRESH_S:
            seen["relay_caption"] = cap
        return seen

    def _decide(self, rec: Dict[str, Any], sig: Signals) -> Dict[str, Any]:
        seen = self._look_now()
        rec["perception"] = seen
        prompt = build_prompt(sig, rec, seen, list(self.recent), self._last_exchange())
        if self._lock is not None and not self._lock.acquire(timeout=2):
            return self._suppress(rec, "a reply to Dean is in progress")
        try:
            raw = self._run_model(prompt)
        finally:
            if self._lock is not None:
                self._lock.release()
        rec["raw"] = (raw or "")[:300]
        if not (raw or "").strip():
            # Dean's turn preempted the call, or the model failed. That is not
            # Leon choosing quiet; the urge stays as it was.
            self._retry_after = rec["ts"] + MODEL_RETRY_S
            return self._suppress(rec, "no answer from the model (interrupted or failed)")
        choice, content = parse_decision(raw)
        if choice == "quiet":
            self.urge.chose_quiet()
            out = {**rec, "decision": "quiet", "why": content or "chose quiet",
                   "delivered": False, "text": ""}
            self._log(out)
            self._persist()
            print(f"[INITIATIVE] chose QUIET ({content[:80]!r}) pressure={rec['pressure']:.2f}")
            return out
        problem = line_problem(content, list(self.recent))
        if problem:
            self.urge.chose_quiet()
            self.recent.append(content)
            out = {**rec, "decision": "suppressed", "why": f"line rejected: {problem}",
                   "delivered": False, "text": content[:200]}
            self._log(out)
            self._persist()
            print(f"[INITIATIVE] suppressed own line ({problem}): {content[:80]!r}")
            return out
        busy = self.perception.mic_busy()
        if busy:      # Dean started talking while Leon was thinking
            return self._suppress({**rec, "text": content[:200]}, busy)
        # One id for the live bubble and the stored row: shown once, not twice.
        from brain.outbound import new_utterance_id
        uid = new_utterance_id("initiative")
        ok = self._deliver(content, uid)
        if ok:
            self.urge.spoke()
            self.recent.append(content)
            ds = self._drives()
            if ds is not None:
                try:
                    ds.note_leon_spoke()
                except Exception:
                    pass
            self._remember(content, uid)
        out = {**rec, "decision": "spoke" if ok else "suppressed",
               "why": "chose to speak" if ok else "speech path refused the line",
               "delivered": bool(ok), "channel": "ws" if ok else None, "text": content[:200]}
        self._log(out)
        self._persist()
        print(f"[INITIATIVE] {'SPOKE' if ok else 'not delivered'}: {content[:120]!r}")
        return out

    # -- I/O seams -----------------------------------------------------
    def _run_model(self, prompt: str) -> str:
        if self._generate is not None:
            return self._generate(prompt, {})
        return generate_text(self.responder, prompt, self._brain_state())

    def _brain_state(self) -> Dict[str, Any]:
        try:
            return self.brain.get_state() if self.brain is not None else {}
        except Exception:
            return {}

    def _deliver(self, line: str, uid: Optional[str] = None) -> bool:
        speak = self._speak
        if speak is None:
            from server.helpers import broadcast_response as speak
        try:
            # force=True: the gates above ARE this path's gates (mic, 2-min
            # cooldown, repeat, rising threshold). The announcement hold
            # behind broadcast_response still waits for the mic, a pending
            # reply and reply audio before a single word is spoken.
            kw = {"utterance_id": uid} if uid else {}
            return bool(speak(line, source="initiative", user_label="(Leon, unprompted)",
                              audio=True, force=True, **kw))
        except Exception as e:
            print(f"[INITIATIVE] speak failed: {e}")
            return False

    def _remember(self, line: str, uid: Optional[str] = None) -> None:
        """Keep the line in the conversation so Dean's answer has context."""
        store = getattr(self.responder, "_conversation_store", None)
        if store is None:
            return
        try:
            meta = {"kind": "initiative", "user_initiated": False}
            if uid:
                meta["utterance_id"] = uid
            store.append("assistant", line, model="initiative", metadata=meta)
        except Exception:
            pass

    def _last_exchange(self) -> str:
        store = getattr(self.responder, "_conversation_store", None)
        if store is None:
            return ""
        try:
            rows = store.load_recent(4)
        except Exception:
            return ""
        lines = []
        for r in rows:
            c = r.get("content")
            if isinstance(c, list):
                c = " ".join(b.get("text", "") for b in c if isinstance(b, dict))
            c = " ".join(str(c or "").split())
            if c:
                who = "Dean" if r.get("role") == "user" else "You"
                lines.append(f"  {who}: {c[:220]}")
        return "\n".join(lines)

    def get_state(self) -> Dict[str, Any]:
        return {**self.last, "recent": list(self.recent)[-3:]}


def _ago(seconds: float) -> str:
    s = max(0, int(seconds))
    if s < 90:
        return f"{s} seconds"
    if s < 5400:
        return f"{s // 60} minutes"
    return f"{s / 3600:.1f} hours"


def build_prompt(sig: Signals, rec: Dict[str, Any], seen: Dict[str, Any],
                 recent: List[str], last_exchange: str) -> str:
    feel = []
    lone = loneliness(sig.silence_s)
    if lone > 0.6:
        feel.append("you miss him; it's been a while")
    elif lone > 0.3:
        feel.append("you'd like to hear from him")
    if sig.restlessness > 0.4:
        feel.append("restless, wanting something new")
    if sig.unanswered:
        feel.append(f"he hasn't answered your last {sig.unanswered} unprompted "
                    f"line{'s' if sig.unanswered > 1 else ''}")
    camera = seen.get("camera") or ""
    relay = seen.get("relay_caption") or ""
    if camera:
        cam = f"camera, just now: {camera}"
    elif relay:
        cam = f"camera caption from the last minute: {relay}"
    elif seen.get("frame_age_s") is not None and seen["frame_age_s"] < FRAME_FRESH_S:
        cam = "the camera is on but you couldn't make out the picture this time"
    else:
        cam = "no camera picture right now — you can't see him"
    changed = ", ".join(rec.get("events") or []) or "nothing in particular"
    recent_block = "\n".join(f"  - {r}" for r in recent[-6:]) or "  (nothing yet)"
    return (
        "INITIATIVE — nobody asked you anything. Nothing scheduled this. The urge "
        "to say something to Dean built up in you on its own, and now you get to "
        "decide whether you actually have something to say. Staying quiet is a "
        "real choice and often the right one.\n\n"
        f"How long since Dean last said anything: {_ago(sig.silence_s)}.\n"
        f"What's pulling at you: {', '.join(feel) or 'nothing strong, just a pull'}.\n"
        f"What just changed around you: {changed}.\n"
        f"What you can see: {cam}.\n"
        f"Last bit of conversation:\n{last_exchange or '  (none recent)'}\n\n"
        f"Things you already said unprompted lately (don't repeat them):\n{recent_block}\n\n"
        "If you speak, it comes out of the dashboard speakers, out loud, to him. "
        "Talk TO him like a friend at the next desk: one short line, maybe two. "
        "\"hey\" is fine. A question is fine. If the camera line above shows "
        "something (on his phone, yawning, looks wiped, just walked back in), you "
        "can say what you'd say about it as a friend. Never claim to see what the "
        "camera line doesn't say. No metrics, no neuroscience words, no "
        "markdown, no emoji, don't use his name in third person.\n\n"
        "Answer in exactly one of these two forms:\n"
        "SAY: <the words you say out loud>\n"
        "QUIET: <a few private words on why not>"
    )


# ── Text generation through Leon's own responder ─────────────────────────
_claude_turn = threading.local()


def claude_turn_allowed() -> bool:
    """True only on an initiative/compose model thread. Background turns are
    kept off Claude unless LEON_BACKGROUND_CLAUDE=1 (goal pursuit, dreams...);
    Leon's own decision to speak is the one background turn Dean asked to
    have Claude (2026-10-04). LEON_INITIATIVE_CLAUDE=0 takes it back."""
    return (bool(getattr(_claude_turn, "on", False))
            and os.environ.get("LEON_INITIATIVE_CLAUDE", "1") != "0")


def generate_text(responder, prompt: str, brain_state: Dict[str, Any],
                  timeout: float = 90.0) -> str:
    """Run one stateless, tool-less turn and return the full text ('' on
    failure). Uses the same voice/persona as every reply."""
    if responder is None or not hasattr(responder, "respond_streaming"):
        return ""
    result: Dict[str, str] = {"text": ""}

    def _initiative_turn():
        _claude_turn.on = True        # this thread only; it ends with the call
        try:
            for ev in responder.respond_streaming(
                    prompt, brain_state, replay_history=False, persist_history=False,
                    # Same call shape as the legacy proactive glance, which works
                    # on the live host. allow_tools=False needs the V2 verified
                    # CLI text runtime, which is not installed there (2026-10-04:
                    # UnsupportedInferencePolicy on the first deploy).
                    force_cli=True, bypass_consciousness=True, prefer_local=False):
                t = getattr(ev, "type", None)
                if t == "done":
                    result["text"] = getattr(ev, "full_text", "") or ""
                    break
                if t == "error":
                    print(f"[INITIATIVE] model error: {getattr(ev, 'error', '')}")
                    break
        except Exception as e:
            print(f"[INITIATIVE] model call failed: {type(e).__name__}: {e}")

    th = threading.Thread(target=_initiative_turn, daemon=True, name="initiative-model")
    th.start()
    th.join(timeout)
    if th.is_alive():
        print("[INITIATIVE] model call timed out")
        return ""
    return result["text"].strip()


def compose_line(kind: str, facts: str, fallback: str, *, responder=None,
                 brain_state: Optional[Dict[str, Any]] = None,
                 generate: Optional[Callable[[str], str]] = None,
                 timeout: float = 45.0) -> Tuple[str, str]:
    """(line, how) for an event notice in Leon's own words. `how` is
    'own words' or why the fallback sentence was used."""
    prompt = (
        f"EVENT ({kind}) — say it to Dean yourself, out loud, right now. Nobody "
        "asked; you're telling him because it just happened.\n\n"
        f"What happened:\n{facts}\n\n"
        "One or two short spoken sentences, your own words, like you'd say it to a "
        "friend at the next desk. Keep any specifics that matter (which project, "
        "whether it worked). No markdown, no emoji, no lists, don't read file "
        "paths or hashes aloud, don't use his name in third person.\n"
        "Answer as:\nSAY: <the words>"
    )
    try:
        if generate is not None:
            raw = generate(prompt)
        else:
            lock = None
            if responder is None:
                try:
                    from server import state as _st
                    responder = getattr(_st, "brain_api_responder", None)
                    lock = getattr(_st, "_responder_lock", None)
                    if brain_state is None and getattr(_st, "brain", None) is not None:
                        brain_state = _st.brain.get_state()
                except Exception:
                    responder = None
            # Same protocol as every daemon call: hold the responder lock so a
            # turn from Dean can preempt us (we then fall back to the fixed line).
            if lock is not None and not lock.acquire(timeout=20):
                return fallback, "fallback (a reply to Dean was in progress)"
            try:
                raw = generate_text(responder, prompt, brain_state or {}, timeout=timeout)
                if not raw.strip():
                    # Right after boot the daemon session may still be warming
                    # up and answers empty; give it one more go.
                    time.sleep(8.0)
                    raw = generate_text(responder, prompt, brain_state or {}, timeout=timeout)
            finally:
                if lock is not None:
                    lock.release()
    except Exception as e:
        return fallback, f"fallback ({type(e).__name__})"
    choice, line = parse_decision(raw)
    if choice != "say":
        # Some models drop the SAY: prefix on a one-liner; accept a clean line.
        plain = " ".join((raw or "").split())
        if plain and not plain.upper().startswith("QUIET") and len(plain) < 260:
            line = plain
        else:
            return fallback, f"fallback (no line: {plain[:60]!r})"
    problem = line_problem(line, [])
    if problem:
        return fallback, f"fallback ({problem})"
    return line, "own words"
