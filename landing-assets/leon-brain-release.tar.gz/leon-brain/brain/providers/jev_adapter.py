"""Opt-in Jev typed decisions; never treated as language or tool execution.

Protocol verified 2026-09-29 from the primary provider documentation:
https://docs.aimlapi.com/api-references/decision-models/typesafe/jev
No availability, accuracy, calibration or latency claim substitutes for a
live evaluation. This adapter has only fixture verification until configured.
"""
import json
import math
from .base import Capability, ProviderSpec, ProviderEvent, Usage, ProtocolError, Unavailable, check_cancel, check_policy
from .http_transport import JsonTransport


def validate_questions(questions):
    # Round-trip detaches nested caller-owned mutable containers.
    try:
        questions = json.loads(json.dumps(questions, allow_nan=False))
    except (TypeError, ValueError):
        raise ProtocolError("questions must be JSON data") from None
    if not isinstance(questions, dict) or not 1 <= len(questions) <= 64:
        raise ProtocolError("expected 1..64 named questions")
    for name, question in questions.items():
        if not name or not isinstance(question, dict) or not question.get("instructions"):
            raise ProtocolError("question name and instructions required")
        kind, criteria = question.get("type"), question.get("criteria")
        if kind == "noul":
            if criteria is not None and (not isinstance(criteria, dict) or set(criteria) - {"true", "false"}
                                         or any(not isinstance(v, str) for v in criteria.values())):
                raise ProtocolError("invalid noul criteria")
        elif kind == "choice":
            if (not isinstance(criteria, dict) or not 1 <= len(criteria) <= 255
                    or any(not k or not isinstance(v, str) for k, v in criteria.items())):
                raise ProtocolError("choice requires 1..255 named criteria")
        elif kind == "score":
            if not isinstance(criteria, list) or not 2 <= len(criteria) <= 255 or not all(isinstance(v, str) for v in criteria):
                raise ProtocolError("score requires 2..255 ordered descriptions")
        else:
            raise ProtocolError("unsupported decision question type")
    return questions


def number(value, low=0, high=1):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
        raise ProtocolError("decision number outside permitted range")
    return value


def validate_answers(questions, answers):
    if not isinstance(answers, dict) or set(answers) != set(questions):
        raise ProtocolError("decision answer keys do not match questions")
    for name, question in questions.items():
        answer = answers[name]
        if not isinstance(answer, dict) or answer.get("type") != question["type"]:
            raise ProtocolError("decision answer type mismatch")
        if question["type"] == "noul":
            number(answer.get("noul"))
            continue
        number(answer.get("confidence"))
        criteria = question["criteria"]
        keys = set(criteria) if question["type"] == "choice" else {str(i) for i in range(len(criteria))}
        probabilities = answer.get("probabilities")
        if not isinstance(probabilities, dict) or set(probabilities) != keys:
            raise ProtocolError("decision distribution keys do not match criteria")
        if abs(sum(number(v) for v in probabilities.values()) - 1) > .00001:
            raise ProtocolError("decision distribution does not sum to one")
        if question["type"] == "choice":
            if answer.get("choice") not in keys:
                raise ProtocolError("decision choice outside criteria")
        else:
            number(answer.get("score"), high=len(criteria)-1)
            if answer.get("legend") != {str(i): value for i, value in enumerate(criteria)}:
                raise ProtocolError("decision score legend does not match criteria")
    return answers


class JevAdapter:
    def __init__(self, *, api_key=None, enabled=False, transport=None, output_token_bound=None,
                 input_usd_per_million=None, output_usd_per_million=None):
        self.spec = ProviderSpec("jev", "typesafe/jev", frozenset({Capability.DECISION}),
                                input_usd_per_million=input_usd_per_million,
                                output_usd_per_million=output_usd_per_million)
        self._key, self.configured = api_key or "", bool(enabled and api_key)
        self._transport = transport or JsonTransport("api.aimlapi.com")
        if output_token_bound is not None and (type(output_token_bound) is not int or output_token_bound <= 0):
            raise ValueError("full-call output-token bound must be a positive integer")
        self._output_token_bound = output_token_bound

    def input_bound(self, request):
        return request.input_bound()

    def output_bound(self, request):
        # The documented decision protocol has no max_output_tokens parameter.
        # Do not invent one or mistake the request's text limit for a cap.
        return self._output_token_bound

    def stream(self, request, cancel_token=None):
        if not self.configured:
            raise Unavailable("Jev adapter disabled or unconfigured")
        check_policy(self.spec, request)
        check_cancel(cancel_token, request.deadline_mono)
        questions = validate_questions(request.questions)
        state = request.prompt if not request.context else request.context + "\n\n" + request.prompt
        data = self._transport.post("/v1/decisions", {"model": self.spec.model, "state": state, "questions": questions},
                                    self._key, cancel_token=cancel_token, deadline=request.deadline_mono)
        check_cancel(cancel_token, request.deadline_mono)
        answers = validate_answers(questions, data.get("answers"))
        usage = data.get("usage") or {}
        if not isinstance(usage, dict):
            raise ProtocolError("invalid decision usage object")
        counts = Usage(usage.get("input_tokens"), usage.get("output_tokens"))
        model = data.get("model")
        if not isinstance(model, str) or not model:
            raise ProtocolError("resolved decision model missing")
        check_cancel(cancel_token, request.deadline_mono)
        yield ProviderEvent("usage", usage=counts, usage_final=True, provider="jev", model=model)
        check_cancel(cancel_token, request.deadline_mono)
        yield ProviderEvent("decision", payload=answers, provider="jev", model=model)
        check_cancel(cancel_token, request.deadline_mono)
        yield ProviderEvent("done", provider="jev", model=model)
