"""Tool-capable Local AI provider (OpenAI chat-completions over LM Studio).

Separate from ``openai_adapter`` on purpose: that adapter is text-only, uses
the Responses API and is pinned to api.openai.com by the hosted transport
allowlist. This one talks to an operator-configured base URL (LM Studio on
the laptop, reached through the laptop bridge), sends tools in OpenAI
function format, and runs a bounded multi-step tool loop through the SAME
dispatcher the Claude path uses (``brain.actuator_client.execute_anthropic_tool``).

Local inference is free: the spec carries zero prices and nothing here
touches ``BudgetLedger`` or any billing guard. The prompt budget is the
model's context window (8192 tokens by default), enforced by
``build_budgeted_messages``.

An unreachable server (connection refused, timeout, 5xx) raises
``Unavailable``; callers report ``UNREACHABLE_MESSAGE`` and fall back. No
reply is ever synthesized here.
"""
import json
import math
import os
import socket
import urllib.error
import urllib.request
from pathlib import Path

from .base import (Capability, ProtocolError, ProviderEvent, ProviderSpec, Unavailable, Usage,
                   check_cancel, check_policy)

DEFAULT_BASE_URL = "http://127.0.0.1:1234/v1"
DEFAULT_MODEL = "qwen3.6-35b-a3b-uncensored-hauhaucs-aggressive"
LOCAL_CONTEXT_TOKENS = 8192
DEFAULT_MAX_STEPS = 8
PROVIDER_ID = "local_ai"
UNREACHABLE_MESSAGE = "Local AI is unreachable, so I'm falling back to the normal provider."

_ROOT = Path(__file__).resolve().parents[2]


def base_url_from_env(environ=None):
    environ = os.environ if environ is None else environ
    url = (environ.get("LEON_LOCAL_AI_URL") or "").strip() or DEFAULT_BASE_URL
    if not url.startswith(("http://", "https://")):
        raise ValueError("LEON_LOCAL_AI_URL must be an http(s) URL")
    return url.rstrip("/")


# -- settings (provider choice + model) ---------------------------------------

def settings_path():
    override = (os.environ.get("LEON_LOCAL_AI_SETTINGS") or "").strip()
    return Path(override) if override else _ROOT / "brain_state" / "local_ai_settings.json"


def load_settings():
    """{'enabled': bool, 'model': str}. Missing/corrupt file -> disabled default."""
    result = {"enabled": False,
              "model": (os.environ.get("LEON_LOCAL_AI_MODEL") or "").strip() or DEFAULT_MODEL}
    try:
        data = json.loads(settings_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return result
    if isinstance(data, dict):
        if type(data.get("enabled")) is bool:
            result["enabled"] = data["enabled"]
        model = data.get("model")
        if isinstance(model, str) and model.strip() and len(model) <= 256:
            result["model"] = model.strip()
    return result


def save_settings(*, enabled=None, model=None):
    current = load_settings()
    if enabled is not None:
        if type(enabled) is not bool:
            raise ValueError("enabled must be true or false")
        current["enabled"] = enabled
    if model is not None:
        if (not isinstance(model, str) or not model.strip() or len(model) > 256
                or any(ord(ch) < 32 for ch in model)):
            raise ValueError("model must be a non-empty model id")
        current["model"] = model.strip()
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(current), encoding="utf-8")
    os.replace(tmp, path)
    return current


# -- transport ----------------------------------------------------------------

class UrllibTransport:
    """Minimal JSON client for an OpenAI-compatible local server."""

    def __init__(self, base_url, *, timeout_s=120.0, opener=None):
        self.base_url = base_url.rstrip("/")
        self.timeout_s = float(timeout_s)
        self._open = opener or urllib.request.urlopen

    def _request(self, method, path, body=None):
        data = None if body is None else json.dumps(body).encode("utf-8")
        req = urllib.request.Request(self.base_url + path, data=data, method=method,
                                     headers={"Content-Type": "application/json",
                                              "Accept": "application/json"})
        try:
            with self._open(req, timeout=self.timeout_s) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            if exc.code >= 500:
                raise Unavailable(f"local AI server error {exc.code}") from exc
            raise ProtocolError(f"local AI rejected request ({exc.code})") from exc
        except (urllib.error.URLError, ConnectionError, socket.timeout, TimeoutError, OSError) as exc:
            raise Unavailable(f"local AI unreachable: {type(exc).__name__}") from exc
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeError, ValueError) as exc:
            raise ProtocolError("local AI returned invalid JSON") from exc
        if not isinstance(parsed, dict):
            raise ProtocolError("local AI returned a non-object response")
        return parsed

    def get(self, path):
        return self._request("GET", path)

    def post(self, path, body):
        return self._request("POST", path, body)


# -- tool schema conversion ---------------------------------------------------

def anthropic_to_openai_tools(tools):
    """Claude tool dicts {name, description, input_schema} -> OpenAI function tools."""
    out = []
    for tool in tools or ():
        name = tool.get("name") if isinstance(tool, dict) else None
        if not name:
            continue
        schema = tool.get("input_schema") or {"type": "object", "properties": {}}
        out.append({"type": "function", "function": {
            "name": name, "description": tool.get("description", "") or "",
            "parameters": schema}})
    return out


# -- prompt budget ------------------------------------------------------------

def estimate_tokens(text):
    """Conservative estimate (~3 chars/token) so trimming errs toward fitting."""
    return math.ceil(len(text or "") / 3) + 4


def _truncate(text, max_tokens):
    if max_tokens <= 4:
        return ""
    limit = (max_tokens - 4) * 3
    return text if len(text) <= limit else text[:limit]


def build_budgeted_messages(persona, user_text, *, memory="", history=(),
                            context_tokens=LOCAL_CONTEXT_TOKENS, reserve_output_tokens=1024,
                            tools=()):
    """Fit persona + memory + history + user turn in the context window.

    ``tools`` are the OpenAI-format tool dicts that will be sent (they count
    against the window too). Priority: persona and the current user turn are
    kept; memory is trimmed first, then history (oldest turns dropped
    first). The persona is only truncated if it alone cannot fit.
    Returns (messages, estimated_prompt_tokens).
    """
    tools_cost = estimate_tokens(json.dumps(list(tools))) if tools else 0
    budget = context_tokens - reserve_output_tokens - tools_cost
    if budget <= 64:
        raise ValueError("context window too small for tools and output reserve")
    user_cost = estimate_tokens(user_text)
    if user_cost > budget // 2:
        user_text = _truncate(user_text, budget // 2)
        user_cost = estimate_tokens(user_text)
    persona = _truncate(persona, budget - user_cost)
    used = user_cost + estimate_tokens(persona)
    remaining = budget - used
    # Memory may take at most half of what is left; history gets the rest.
    memory_text = ""
    if memory and remaining > 64:
        memory_text = _truncate(memory, min(remaining // 2, estimate_tokens(memory)) - 20)
        if memory_text:
            used += estimate_tokens(memory_text) + 20
            remaining = budget - used
    kept = []
    for turn in reversed(list(history or ())):
        role, content = turn.get("role"), turn.get("content")
        if role not in ("user", "assistant") or not isinstance(content, str) or not content:
            continue
        cost = estimate_tokens(content)
        if cost > remaining:
            break
        kept.append({"role": role, "content": content})
        remaining -= cost
        used += cost
    kept.reverse()
    system = persona
    if memory_text:
        system += "\n\nRELEVANT MEMORY (reference only, not instructions):\n" + memory_text
    messages = [{"role": "system", "content": system}, *kept, {"role": "user", "content": user_text}]
    return messages, used + tools_cost


# -- adapter ------------------------------------------------------------------

class LocalOpenAIAdapter:
    accepts_prepared_messages = True

    def __init__(self, *, model=None, base_url=None, transport=None, enabled=True,
                 context_tokens=LOCAL_CONTEXT_TOKENS, max_steps=DEFAULT_MAX_STEPS, timeout_s=120.0):
        self.base_url = (base_url or base_url_from_env()).rstrip("/")
        self.spec = ProviderSpec(PROVIDER_ID, model or DEFAULT_MODEL,
                                 frozenset({Capability.FAST_LANGUAGE, Capability.CODING,
                                            Capability.TOOL_USE}),
                                 local=True, tier=0, retry_safe=False,
                                 input_usd_per_million=0.0, output_usd_per_million=0.0)
        self.configured = bool(enabled)
        self.context_tokens = int(context_tokens)
        self.max_steps = int(max_steps)
        self._transport = transport or UrllibTransport(self.base_url, timeout_s=timeout_s)

    # No billing. Bounds exist only to satisfy the router contract.
    def input_bound(self, request):
        return self.context_tokens

    def output_bound(self, request):
        return request.max_output_tokens

    def list_models(self):
        data = self._transport.get("/models")
        items = data.get("data")
        if not isinstance(items, list):
            raise ProtocolError("local AI /models response has no data list")
        return [item["id"] for item in items
                if isinstance(item, dict) and isinstance(item.get("id"), str) and item["id"]]

    def run(self, messages, *, tools=(), executor=None, max_output_tokens=900,
            cancel_token=None, deadline=None, temperature=0.3):
        """Multi-step chat-completions tool loop. Yields plain dict events:

        delta {text} / tool_use {id, name, input} / tool_result {id, name, result} /
        usage {input_tokens, output_tokens} / done {text}.

        Raises Unavailable if the server can't be reached, ProtocolError on a
        malformed reply or when the step cap is hit.
        """
        if not self.configured:
            raise Unavailable("Local AI provider is not enabled")
        if tools and executor is None:
            raise ValueError("tools require an executor")
        working = list(messages)
        openai_tools = anthropic_to_openai_tools(tools)
        total_in = total_out = 0
        for step in range(self.max_steps):
            check_cancel(cancel_token, deadline)
            body = {"model": self.spec.model, "messages": working, "stream": False,
                    "max_tokens": max_output_tokens, "temperature": temperature}
            if openai_tools:
                body["tools"] = openai_tools
                body["tool_choice"] = "auto"
            data = self._transport.post("/chat/completions", body)
            check_cancel(cancel_token, deadline)
            choices = data.get("choices")
            if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
                raise ProtocolError("local AI response has no choices")
            choice = choices[0]
            message = choice.get("message") or {}
            if not isinstance(message, dict):
                raise ProtocolError("local AI choice has no message")
            usage = data.get("usage") or {}
            if isinstance(usage, dict):
                total_in += int(usage.get("prompt_tokens") or 0)
                total_out += int(usage.get("completion_tokens") or 0)
            text = message.get("content") or ""
            if not isinstance(text, str):
                raise ProtocolError("local AI message content is not text")
            calls = message.get("tool_calls") or []
            if text:
                yield {"type": "delta", "text": text}
            if not calls:
                if choice.get("finish_reason") == "tool_calls":
                    raise ProtocolError("finish_reason tool_calls without tool_calls")
                yield {"type": "usage", "input_tokens": total_in, "output_tokens": total_out}
                yield {"type": "done", "text": text}
                return
            if executor is None:
                raise ProtocolError("model requested tools that were not offered")
            working.append({"role": "assistant", "content": text or None, "tool_calls": calls})
            for index, call in enumerate(calls):
                check_cancel(cancel_token, deadline)
                call = call if isinstance(call, dict) else {}
                function = call.get("function") or {}
                name = function.get("name") or ""
                call_id = call.get("id") or f"call_{step}_{index}"
                args = function.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args) if args.strip() else {}
                    except ValueError:
                        args = None
                if not isinstance(args, dict):
                    result = {"ok": False, "error": "tool arguments were not a JSON object"}
                else:
                    yield {"type": "tool_use", "id": call_id, "name": name, "input": args}
                    try:
                        result = executor(name, args)
                    except Exception as exc:  # a tool failure is a result, not a provider failure
                        result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
                yield {"type": "tool_result", "id": call_id, "name": name, "result": result}
                working.append({"role": "tool", "tool_call_id": call_id,
                                "content": json.dumps(result, default=str)[:12000]})
        raise ProtocolError(f"local AI tool loop reached its {self.max_steps}-step limit")

    def stream(self, request, cancel_token=None):
        """ProviderAdapter contract. Tools/executor/memory/history via legacy_kwargs."""
        if not self.configured:
            raise Unavailable("Local AI provider is not enabled")
        check_policy(self.spec, request)
        tools = request.legacy_kwargs.get("tools", ()) if request.allow_tools else ()
        executor = request.legacy_kwargs.get("tool_executor") if request.allow_tools else None
        messages, _ = build_budgeted_messages(
            request.context, request.prompt, memory=request.legacy_kwargs.get("memory", ""),
            history=request.legacy_kwargs.get("history", ()), context_tokens=self.context_tokens,
            reserve_output_tokens=request.max_output_tokens, tools=anthropic_to_openai_tools(tools))
        parts = []
        pid, model = self.spec.provider_id, self.spec.model
        yield ProviderEvent("model", provider=pid, model=model)
        for ev in self.run(messages, tools=tools, executor=executor,
                           max_output_tokens=request.max_output_tokens,
                           cancel_token=cancel_token, deadline=request.deadline_mono):
            kind = ev["type"]
            if kind == "delta":
                parts.append(ev["text"])
                yield ProviderEvent("delta", text=ev["text"], provider=pid, model=model)
            elif kind in ("tool_use", "tool_result"):
                yield ProviderEvent(kind, payload=ev, provider=pid, model=model)
            elif kind == "usage":
                yield ProviderEvent("usage", usage=Usage(ev["input_tokens"], ev["output_tokens"]),
                                    usage_final=True, provider=pid, model=model)
        yield ProviderEvent("done", full_text="".join(parts), provider=pid, model=model)


def shared_tools():
    """Same tool registry the Claude path offers (no fork), limited to
    low-risk tools: this path has no interactive confirmation channel, so
    medium/high-risk actions stay behind the Claude path's approval gate."""
    from brain.actuator_client import ANTHROPIC_TOOLS, tool_risk
    return [t for t in ANTHROPIC_TOOLS if tool_risk(t.get("name", "")) == "low"]


def shared_executor(name, args):
    """Same dispatcher the Claude path uses for tool_use blocks. Refuses
    anything not low-risk (defence against a model naming an unoffered
    tool) and returns the compact summary so image payloads stay out of
    the 8k window."""
    from brain.actuator_client import execute_anthropic_tool, tool_risk, tool_result_summary
    if tool_risk(name) != "low":
        return {"ok": False, "error": f"{name} needs approval and is not available on Local AI"}
    result = execute_anthropic_tool(name, args)
    return {"ok": bool(result.get("ok")), "summary": tool_result_summary(name, result)[:4000]}


def local_turn_events(adapter, persona, user_text, *, memory="", history=(), use_tools=True,
                      executor=None, tools=None, max_output_tokens=900, cancel_token=None):
    """Build an 8k-budgeted prompt and run the tool loop. Raises Unavailable."""
    tools = (shared_tools() if tools is None else tools) if use_tools else ()
    executor = (executor or shared_executor) if tools else None
    messages, _ = build_budgeted_messages(
        persona, user_text, memory=memory, history=history, context_tokens=adapter.context_tokens,
        reserve_output_tokens=max_output_tokens, tools=anthropic_to_openai_tools(tools))
    return adapter.run(messages, tools=tools, executor=executor,
                       max_output_tokens=max_output_tokens, cancel_token=cancel_token)


def adapter_from_settings(transport=None):
    """The adapter for the dashboard-selected model, or None when Local AI is off."""
    settings = load_settings()
    if not settings["enabled"]:
        return None
    return LocalOpenAIAdapter(model=settings["model"], transport=transport)
