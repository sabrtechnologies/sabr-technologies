"""Tool-capable Local AI provider (OpenAI chat-completions over LM Studio).

Separate from ``openai_adapter`` on purpose: that adapter is text-only, uses
the Responses API and is pinned to api.openai.com by the hosted transport
allowlist. This one talks to an operator-configured base URL (LM Studio on
the laptop, reached through the laptop bridge), sends tools in OpenAI
function format, and runs a bounded multi-step tool loop through the SAME
dispatcher the Claude path uses (``brain.actuator_client.execute_anthropic_tool``).

Local inference is free: the spec carries zero prices and nothing here
touches ``BudgetLedger`` or any billing guard. The prompt budget is the
model's context window (8192 tokens by default), enforced by
``build_budgeted_messages``.

An unreachable server (connection refused, timeout, 5xx) raises
``Unavailable``; callers report ``UNREACHABLE_MESSAGE`` and fall back. No
reply is ever synthesized here.
"""
import json
import time
import re
import math
import os
import socket
import urllib.error
import urllib.request
from pathlib import Path

from .base import (Capability, ProtocolError, ProviderEvent, ProviderSpec, Unavailable, Usage,
                   check_cancel, check_policy)

DEFAULT_BASE_URL = "http://127.0.0.1:1234/v1"
DEFAULT_MODEL = "qwen3.6-35b-a3b-uncensored-hauhaucs-aggressive"
LOCAL_CONTEXT_TOKENS = 8192
HOSTED_CONTEXT_TOKENS = 96000
ENDPOINTS = ("laptop", "ollama", "hosted")  # LM Studio on the laptop, Ollama on this computer, paid API
DEFAULT_HOSTED_URL = "https://api.orcarouter.ai/v1"
DEFAULT_HOSTED_MODEL = "qwen/qwen3.8-27b"
DEFAULT_MAX_STEPS = 30
_PROMISE = re.compile('(?:let me|i.ll|i will|i.m going to|going to|gonna)[ ]+(?:check|look|verify|find out|pull up|see|read|confirm)', re.I)
PROVIDER_ID = "local_ai"
UNREACHABLE_MESSAGE = "Local AI is unreachable, so I'm falling back to the normal provider."

_ROOT = Path(__file__).resolve().parents[2]


def base_url_from_env(environ=None, endpoint=None):
    """laptop: LEON_LOCAL_AI_URL (LM Studio). hosted: LEON_HOSTED_AI_URL (paid OpenAI-compatible API)."""
    if endpoint is None:
        endpoint = load_settings()["endpoint"] if environ is None else "laptop"
    environ = os.environ if environ is None else environ
    if endpoint == "hosted":
        url = (environ.get("LEON_HOSTED_AI_URL") or "").strip() or DEFAULT_HOSTED_URL
    elif endpoint == "ollama":
        from brain.providers import ollama_models
        url = (environ.get("LEON_OLLAMA_AI_URL") or "").strip() or ollama_models.daemon_url(environ) + "/v1"
    else:
        url = (environ.get("LEON_LOCAL_AI_URL") or "").strip() or DEFAULT_BASE_URL
    if not url.startswith(("http://", "https://")):
        raise ValueError("Local AI URL must be an http(s) URL")
    return url.rstrip("/")


def api_key_from_env(endpoint, environ=None):
    """Bearer key for the endpoint; never logged or returned by any API."""
    environ = os.environ if environ is None else environ
    if endpoint == "ollama":
        return None  # the local daemon takes no key
    name = "LEON_HOSTED_AI_KEY" if endpoint == "hosted" else "LEON_LOCAL_AI_KEY"
    value = (environ.get(name) or "").strip()
    if not value and endpoint == "hosted":
        try:
            value = hosted_key_path().read_text(encoding="utf-8").strip()
        except OSError:
            value = ""
    return value or None


def hosted_key_path():
    return _ROOT / "brain_state" / "secure" / "hosted_ai_key"


def save_hosted_key(key):
    """Store the hosted API key owner-only. The key is never logged or returned."""
    if (not isinstance(key, str) or not key.strip() or len(key.strip()) > 512
            or any(ord(ch) < 33 for ch in key.strip())):
        raise ValueError("API key must be one line with no spaces")
    path = hosted_key_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(key.strip())
    os.replace(tmp, path)
    os.chmod(path, 0o600)


# -- settings (provider choice + model) ---------------------------------------

def settings_path():
    override = (os.environ.get("LEON_LOCAL_AI_SETTINGS") or "").strip()
    return Path(override) if override else _ROOT / "brain_state" / "local_ai_settings.json"


MODEL_KEYS = {"laptop": "model", "ollama": "ollama_model", "hosted": "hosted_model"}


def load_settings():
    """{'enabled', 'endpoint', 'model'}: model is the one for the selected endpoint.
    Missing/corrupt file -> disabled laptop default."""
    return _settings_from_raw(_read_raw())


def _settings_from_raw(data):
    laptop = (os.environ.get("LEON_LOCAL_AI_MODEL") or "").strip() or DEFAULT_MODEL
    hosted = (os.environ.get("LEON_HOSTED_AI_MODEL") or "").strip() or DEFAULT_HOSTED_MODEL
    ollama = (os.environ.get("LEON_OLLAMA_AI_MODEL") or "").strip()  # no default: nothing is pulled until the owner picks one
    enabled = data.get("enabled") if type(data.get("enabled")) is bool else False
    endpoint = data.get("endpoint") if data.get("endpoint") in ENDPOINTS else "laptop"
    def ok(value):
        return isinstance(value, str) and value.strip() and len(value) <= 256
    if ok(data.get("model")):
        laptop = data["model"].strip()
    if ok(data.get("hosted_model")):
        hosted = data["hosted_model"].strip()
    if ok(data.get("ollama_model")):
        ollama = data["ollama_model"].strip()
    return {"enabled": enabled, "endpoint": endpoint,
            "model": {"hosted": hosted, "ollama": ollama}.get(endpoint, laptop)}


def _read_raw():
    try:
        data = json.loads(settings_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def save_settings(*, enabled=None, model=None, endpoint=None):
    raw = _read_raw()
    if enabled is not None:
        if type(enabled) is not bool:
            raise ValueError("enabled must be true or false")
        raw["enabled"] = enabled
    if endpoint is not None:
        if endpoint not in ENDPOINTS:
            raise ValueError("endpoint must be laptop, ollama or hosted")
        raw["endpoint"] = endpoint
    if model is not None:
        if (not isinstance(model, str) or not model.strip() or len(model) > 256
                or any(ord(ch) < 32 for ch in model)):
            raise ValueError("model must be a non-empty model id")
        target = raw.get("endpoint") if raw.get("endpoint") in ENDPOINTS else "laptop"
        raw[MODEL_KEYS[target]] = model.strip()
    if raw.get("enabled") and not _settings_from_raw(raw)["model"]:
        raw["enabled"] = False
        _write_raw(raw)
        raise ValueError("Pick a model first: no model is selected for this source.")
    _write_raw(raw)
    return load_settings()


def _write_raw(raw):
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(raw), encoding="utf-8")
    os.replace(tmp, path)


# -- transport ----------------------------------------------------------------

class UrllibTransport:
    """Minimal JSON client for an OpenAI-compatible local server."""

    def __init__(self, base_url, *, timeout_s=120.0, opener=None, api_key=None):
        self.base_url = base_url.rstrip("/")
        self._api_key = api_key
        self.timeout_s = float(timeout_s)
        self._open = opener or urllib.request.urlopen

    def _request(self, method, path, body=None):
        data = None if body is None else json.dumps(body).encode("utf-8")
        req = urllib.request.Request(self.base_url + path, data=data, method=method,
                                     headers={"Content-Type": "application/json",
                                              "Accept": "application/json",
                                              **({"Authorization": "Bearer " + self._api_key}
                                                 if self._api_key else {})})
        try:
            with self._open(req, timeout=self.timeout_s) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            if exc.code >= 500:
                raise Unavailable(f"local AI server error {exc.code}") from exc
            raise ProtocolError(f"local AI rejected request ({exc.code})") from exc
        except (urllib.error.URLError, ConnectionError, socket.timeout, TimeoutError, OSError) as exc:
            raise Unavailable(f"local AI unreachable: {type(exc).__name__}") from exc
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeError, ValueError) as exc:
            raise ProtocolError("local AI returned invalid JSON") from exc
        if not isinstance(parsed, dict):
            raise ProtocolError("local AI returned a non-object response")
        return parsed

    def stream_chat(self, body):
        """Server-sent-events chat completion: yields each parsed chunk dict as it arrives."""
        data = json.dumps({**body, "stream": True}).encode("utf-8")
        headers = {"Content-Type": "application/json", "Accept": "text/event-stream"}
        if self._api_key:
            headers["Authorization"] = "Bearer " + self._api_key
        req = urllib.request.Request(self.base_url + "/chat/completions", data=data, method="POST", headers=headers)
        try:
            response = self._open(req, timeout=self.timeout_s)
        except urllib.error.HTTPError as exc:
            if exc.code >= 500:
                raise Unavailable(f"local AI server error {exc.code}") from exc
            raise ProtocolError(f"local AI rejected request ({exc.code})") from exc
        except (urllib.error.URLError, ConnectionError, socket.timeout, TimeoutError, OSError) as exc:
            raise Unavailable(f"local AI unreachable: {type(exc).__name__}") from exc
        try:
            with response:
                for raw in response:
                    line = raw.decode("utf-8", "replace").strip()
                    if not line.startswith("data:"):
                        continue
                    payload = line[5:].strip()
                    if payload == "[DONE]":
                        return
                    try:
                        chunk = json.loads(payload)
                    except ValueError:
                        continue
                    if isinstance(chunk, dict):
                        yield chunk
        except (ConnectionError, socket.timeout, TimeoutError, OSError) as exc:
            raise Unavailable(f"local AI stream interrupted: {type(exc).__name__}") from exc

    def get(self, path):
        return self._request("GET", path)

    def post(self, path, body):
        return self._request("POST", path, body)


# -- tool schema conversion ---------------------------------------------------

def anthropic_to_openai_tools(tools):
    """Claude tool dicts {name, description, input_schema} -> OpenAI function tools."""
    out = []
    for tool in tools or ():
        name = tool.get("name") if isinstance(tool, dict) else None
        if not name:
            continue
        schema = tool.get("input_schema") or {"type": "object", "properties": {}}
        out.append({"type": "function", "function": {
            "name": name, "description": tool.get("description", "") or "",
            "parameters": schema}})
    return out


# -- prompt budget ------------------------------------------------------------

def estimate_tokens(text):
    """Conservative estimate (~3 chars/token) so trimming errs toward fitting."""
    return math.ceil(len(text or "") / 3) + 4


def _truncate(text, max_tokens):
    if max_tokens <= 4:
        return ""
    limit = (max_tokens - 4) * 3
    return text if len(text) <= limit else text[:limit]


def build_budgeted_messages(persona, user_text, *, memory="", history=(),
                            context_tokens=LOCAL_CONTEXT_TOKENS, reserve_output_tokens=1024,
                            tools=()):
    """Fit persona + memory + history + user turn in the context window.

    ``tools`` are the OpenAI-format tool dicts that will be sent (they count
    against the window too). Priority: persona and the current user turn are
    kept; memory is trimmed first, then history (oldest turns dropped
    first). The persona is only truncated if it alone cannot fit.
    Returns (messages, estimated_prompt_tokens).
    """
    tools_cost = estimate_tokens(json.dumps(list(tools))) if tools else 0
    budget = context_tokens - reserve_output_tokens - tools_cost
    if budget <= 64:
        raise ValueError("context window too small for tools and output reserve")
    user_cost = estimate_tokens(user_text)
    if user_cost > budget // 2:
        user_text = _truncate(user_text, budget // 2)
        user_cost = estimate_tokens(user_text)
    persona = _truncate(persona, budget - user_cost)
    used = user_cost + estimate_tokens(persona)
    remaining = budget - used
    # Memory may take at most half of what is left; history gets the rest.
    memory_text = ""
    if memory and remaining > 64:
        memory_text = _truncate(memory, min(remaining // 2, estimate_tokens(memory)) - 20)
        if memory_text:
            used += estimate_tokens(memory_text) + 20
            remaining = budget - used
    kept = []
    for turn in reversed(list(history or ())):
        role, content = turn.get("role"), turn.get("content")
        if role not in ("user", "assistant") or not isinstance(content, str) or not content:
            continue
        cost = estimate_tokens(content)
        if cost > remaining:
            break
        kept.append({"role": role, "content": content})
        remaining -= cost
        used += cost
    kept.reverse()
    system = persona
    if memory_text:
        system += "\n\nRELEVANT MEMORY (reference only, not instructions):\n" + memory_text
    messages = [{"role": "system", "content": system}, *kept, {"role": "user", "content": user_text}]
    return messages, used + tools_cost


# -- adapter ------------------------------------------------------------------

class LocalOpenAIAdapter:
    accepts_prepared_messages = True

    def __init__(self, *, model=None, base_url=None, transport=None, enabled=True,
                 context_tokens=None, max_steps=DEFAULT_MAX_STEPS, timeout_s=120.0, endpoint=None):
        if base_url is None and transport is None and endpoint is None:
            endpoint = load_settings()["endpoint"]
        self.endpoint = endpoint or "laptop"
        self.base_url = (base_url or base_url_from_env(endpoint=self.endpoint)).rstrip("/")
        api_key = None if base_url else api_key_from_env(self.endpoint)
        if context_tokens is None:
            context_tokens = HOSTED_CONTEXT_TOKENS if self.endpoint == "hosted" else LOCAL_CONTEXT_TOKENS
        self.spec = ProviderSpec(PROVIDER_ID, model or DEFAULT_MODEL,
                                 frozenset({Capability.FAST_LANGUAGE, Capability.CODING,
                                            Capability.TOOL_USE}),
                                 local=self.endpoint != "hosted", tier=0, retry_safe=False,
                                 input_usd_per_million=0.0, output_usd_per_million=0.0)
        self.configured = bool(enabled)
        self.context_tokens = int(context_tokens)
        self.max_steps = int(max_steps)
        self._transport = transport or UrllibTransport(self.base_url, timeout_s=timeout_s, api_key=api_key)

    # No billing. Bounds exist only to satisfy the router contract.
    def input_bound(self, request):
        return self.context_tokens

    def output_bound(self, request):
        return request.max_output_tokens

    def list_models(self):
        data = self._transport.get("/models")
        items = data.get("data")
        if not isinstance(items, list):
            raise ProtocolError("local AI /models response has no data list")
        return [item["id"] for item in items
                if isinstance(item, dict) and isinstance(item.get("id"), str) and item["id"]]

    def run(self, messages, *, tools=(), executor=None, max_output_tokens=900,
            cancel_token=None, deadline=None, temperature=0.3):
        """Multi-step chat-completions tool loop. Yields plain dict events:

        delta {text} / tool_use {id, name, input} / tool_result {id, name, result} /
        usage {input_tokens, output_tokens} / done {text}.

        Raises Unavailable if the server can't be reached, ProtocolError on a
        malformed reply or when the step cap is hit.
        """
        if not self.configured:
            raise Unavailable("Local AI provider is not enabled")
        if tools and executor is None:
            raise ValueError("tools require an executor")
        working = list(messages)
        openai_tools = anthropic_to_openai_tools(tools)
        total_in = total_out = 0
        nudged = False
        for step in range(self.max_steps):
            check_cancel(cancel_token, deadline)
            body = {"model": self.spec.model, "messages": working, "stream": False,
                    "max_tokens": max_output_tokens, "temperature": temperature}
            if openai_tools:
                body["tools"] = openai_tools
                body["tool_choice"] = "auto"
            if hasattr(self._transport, "stream_chat"):
                data = yield from self._stream_step(body, cancel_token, deadline)
            else:
                data = self._transport.post("/chat/completions", body)
            check_cancel(cancel_token, deadline)
            choices = data.get("choices")
            if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
                raise ProtocolError("local AI response has no choices")
            choice = choices[0]
            message = choice.get("message") or {}
            if not isinstance(message, dict):
                raise ProtocolError("local AI choice has no message")
            usage = data.get("usage") or {}
            if isinstance(usage, dict):
                total_in += int(usage.get("prompt_tokens") or 0)
                total_out += int(usage.get("completion_tokens") or 0)
            text = message.get("content") or ""
            if not isinstance(text, str):
                raise ProtocolError("local AI message content is not text")
            calls = message.get("tool_calls") or []
            if text and not data.get("_streamed"):
                yield {"type": "delta", "text": text}
            if not calls and openai_tools and not nudged and step < self.max_steps - 1 and _PROMISE.search(text or ""):
                # "Let me check..." with no tool call is a promise that never runs. Make him do it now, in this turn.
                nudged = True
                working.append({"role": "assistant", "content": text})
                working.append({"role": "user", "content": "[system] You said you would check or look something up but called no tool. "
                                "Call the tool now, then give Dean the actual answer from what it returned."})
                continue
            if not calls:
                if choice.get("finish_reason") == "tool_calls":
                    raise ProtocolError("finish_reason tool_calls without tool_calls")
                yield {"type": "usage", "input_tokens": total_in, "output_tokens": total_out}
                yield {"type": "done", "text": text}
                return
            if executor is None:
                raise ProtocolError("model requested tools that were not offered")
            working.append({"role": "assistant", "content": text or None, "tool_calls": calls})
            for index, call in enumerate(calls):
                check_cancel(cancel_token, deadline)
                call = call if isinstance(call, dict) else {}
                function = call.get("function") or {}
                name = function.get("name") or ""
                call_id = call.get("id") or f"call_{step}_{index}"
                args = function.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args) if args.strip() else {}
                    except ValueError:
                        args = None
                if not isinstance(args, dict):
                    result = {"ok": False, "error": "tool arguments were not a JSON object"}
                else:
                    yield {"type": "tool_use", "id": call_id, "name": name, "input": args}
                    try:
                        result = executor(name, args)
                    except Exception as exc:  # a tool failure is a result, not a provider failure
                        result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
                yield {"type": "tool_result", "id": call_id, "name": name, "result": result}
                working.append({"role": "tool", "tool_call_id": call_id,
                                "content": json.dumps(result, default=str)[:min(12000, self.context_tokens)]})
        # Out of tool steps: a long job is not a failure. One last turn without tools so Leon reports what he did and what is left.
        working.append({"role": "user", "content": "[system] Tool step limit reached for this turn. Do not call any more tools. "
                        "Tell Dean in plain words what you did, what you found, and what is still left."})
        body = {"model": self.spec.model, "messages": working, "stream": False,
                "max_tokens": max_output_tokens, "temperature": temperature}
        if hasattr(self._transport, "stream_chat"):
            data = yield from self._stream_step(body, cancel_token, deadline)
        else:
            data = self._transport.post("/chat/completions", body)
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
            raise ProtocolError("local AI response has no choices")
        text = (choices[0].get("message") or {}).get("content") or ""
        if not isinstance(text, str) or not text.strip():
            raise ProtocolError(f"local AI tool loop reached its {self.max_steps}-step limit")
        if not data.get("_streamed"):
            yield {"type": "delta", "text": text}
        yield {"type": "usage", "input_tokens": total_in, "output_tokens": total_out}
        yield {"type": "done", "text": text}

    def _stream_step(self, body, cancel_token, deadline):
        """One streamed chat-completions call. Yields 'thinking' (reasoning) and 'delta' (answer) events as they
        arrive and returns a non-stream-shaped reply dict so the tool loop below is unchanged."""
        text_parts, calls, usage, finish = [], {}, {}, None
        for chunk in self._transport.stream_chat(body):
            check_cancel(cancel_token, deadline)
            if isinstance(chunk.get("usage"), dict):
                usage = chunk["usage"]
            choices = chunk.get("choices")
            if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
                continue
            choice = choices[0]
            delta = choice.get("delta") or {}
            reasoning = delta.get("reasoning_content") or delta.get("reasoning")
            if isinstance(reasoning, str) and reasoning:
                yield {"type": "thinking", "text": reasoning}
            content = delta.get("content")
            if isinstance(content, str) and content:
                text_parts.append(content)
                yield {"type": "delta", "text": content}
            for part in delta.get("tool_calls") or []:
                if not isinstance(part, dict):
                    continue
                slot = calls.setdefault(int(part.get("index") or 0),
                                        {"id": None, "type": "function", "function": {"name": "", "arguments": ""}})
                if part.get("id"):
                    slot["id"] = part["id"]
                function = part.get("function") or {}
                if function.get("name"):
                    slot["function"]["name"] += function["name"]
                if function.get("arguments"):
                    slot["function"]["arguments"] += function["arguments"]
            if choice.get("finish_reason"):
                finish = choice["finish_reason"]
        tool_calls = [calls[i] for i in sorted(calls)]
        return {"choices": [{"message": {"content": "".join(text_parts), "tool_calls": tool_calls or None},
                             "finish_reason": finish or ("tool_calls" if tool_calls else "stop")}],
                "usage": usage, "_streamed": True}

    def stream(self, request, cancel_token=None):
        """ProviderAdapter contract. Tools/executor/memory/history via legacy_kwargs."""
        if not self.configured:
            raise Unavailable("Local AI provider is not enabled")
        check_policy(self.spec, request)
        tools = request.legacy_kwargs.get("tools", ()) if request.allow_tools else ()
        executor = request.legacy_kwargs.get("tool_executor") if request.allow_tools else None
        messages, _ = build_budgeted_messages(
            request.context, request.prompt, memory=request.legacy_kwargs.get("memory", ""),
            history=request.legacy_kwargs.get("history", ()), context_tokens=self.context_tokens,
            reserve_output_tokens=request.max_output_tokens, tools=anthropic_to_openai_tools(tools))
        parts = []
        pid, model = self.spec.provider_id, self.spec.model
        yield ProviderEvent("model", provider=pid, model=model)
        for ev in self.run(messages, tools=tools, executor=executor,
                           max_output_tokens=request.max_output_tokens,
                           cancel_token=cancel_token, deadline=request.deadline_mono):
            kind = ev["type"]
            if kind == "delta":
                parts.append(ev["text"])
                yield ProviderEvent("delta", text=ev["text"], provider=pid, model=model)
            elif kind in ("tool_use", "tool_result"):
                yield ProviderEvent(kind, payload=ev, provider=pid, model=model)
            elif kind == "usage":
                yield ProviderEvent("usage", usage=Usage(ev["input_tokens"], ev["output_tokens"]),
                                    usage_final=True, provider=pid, model=model)
        yield ProviderEvent("done", full_text="".join(parts), provider=pid, model=model)


def allowed_risks():
    """All risk levels, same as the Claude path (Dean opted out of approval modals 2026-05-10 and asked for the
    full tool set on Local, 2026-10-20). LEON_LOCAL_AI_HIGH_RISK=0 restricts to low and medium."""
    restricted = (os.environ.get("LEON_LOCAL_AI_HIGH_RISK") or "").strip() == "0"
    return ("low", "medium") if restricted else ("low", "medium", "high")


def shared_tools():
    """Same tool registry the Claude path offers (no fork), limited to the allowed risk levels.
    Far too many to send at once: local_turn_events() sends only the relevant few (select_tools)."""
    from brain.actuator_client import ANTHROPIC_TOOLS, tool_risk
    ok = allowed_risks()
    return [t for t in ANTHROPIC_TOOLS if tool_risk(t.get("name", "")) in ok]


CORE_TOOLS = (
    "screen_capture", "desktop_state", "vision_describe", "browser_google_search_silent", "browser_dom_state",
    "browser_dom_extract", "browser_dom_click", "browser_list_tabs", "browser_get_url", "browser_switch_tab",
    "info_web_summarize_url", "desktop_click", "desktop_type", "desktop_key", "click_text", "click_element",
    "mouse_click", "mouse_scroll", "keyboard_type", "keyboard_hotkey", "window_focus", "app_launch",
    "file_read", "file_list", "file_search_name", "file_search_content", "self_remember", "knowledge_search",
    "reminder_set", "reminder_list", "time_current", "notes_quick_search", "info_weather_now", "clipboard_copy",
    "shell_exec", "file_write", "file_delete", "code_edit", "http_request", "process_kill", "restart_self", "app_close")
_STOP = frozenset("the and for you your with that this from have has not are was were what when where can could would "
                  "should will please just about into out over then than them they his her its our who how why all any "
                  "get let make want need tell show give use using".split())
_WEB = ("browser", "google", "search", "web", "url", "summarize", "dom")
_SYN = {
    "internet": _WEB, "online": _WEB, "google": _WEB, "search": _WEB, "website": _WEB, "web": _WEB, "page": _WEB,
    "browse": _WEB, "link": _WEB, "news": _WEB, "click": ("click", "mouse", "desktop", "element"),
    "press": ("key", "keyboard", "click"), "type": ("type", "keyboard", "key"), "open": ("app", "launch", "file", "browser"),
    "launch": ("app", "launch"), "screen": ("screen", "capture", "vision", "desktop"), "see": ("screen", "capture", "vision"),
    "look": ("screen", "capture", "vision", "desktop"), "screenshot": ("screen", "capture"), "folder": ("file", "list"),
    "read": ("file", "read"), "write": ("file", "write"), "remind": ("reminder",), "remember": ("remember", "memory", "knowledge"),
    "note": ("notes",), "calendar": ("cal", "calendar", "event"), "email": ("mail", "email", "gmail"),
    "mail": ("mail", "email", "gmail"), "music": ("media", "spotify", "music"), "play": ("media", "spotify", "music"),
    "volume": ("volume", "audio", "sys"), "download": ("download", "file"), "job": ("job", "agentpool"),
    "code": ("dev", "code", "file"), "weather": ("weather",), "time": ("time",),
    "delete": ("delete", "file", "remove"), "remove": ("delete", "file", "remove"), "shell": ("shell", "exec"),
    "terminal": ("shell", "exec"), "command": ("shell", "exec"), "run": ("shell", "exec", "app"),
    "edit": ("edit", "code", "file", "write"), "fix": ("edit", "code"), "restart": ("restart",),
    "kill": ("kill", "process"), "close": ("close", "app", "window"), "request": ("http", "request"),
}


def select_tools(user_text, tools, *, limit=60, core=CORE_TOOLS):
    """The relevant subset for one turn: best keyword matches first, then the always-useful core, up to limit."""
    import re
    if len(tools) <= limit:
        return list(tools)
    by_name = {t.get("name"): t for t in tools}
    words = [w for w in re.findall(r"[a-z0-9]+", (user_text or "").lower()) if len(w) >= 3 and w not in _STOP]
    terms = set(words)
    for w in words:
        terms.update(_SYN.get(w, ()))
        if w.endswith("s") and len(w) > 3:          # plurals: "routines" finds routine_list
            terms.add(w[:-1])
            terms.update(_SYN.get(w[:-1], ()))
    scored = []
    for t in tools:
        name = t.get("name", "")
        ntok = set(name.lower().split("_"))
        dtok = set(re.findall(r"[a-z0-9]+", (t.get("description") or "").lower()))
        score = 3 * len(terms & ntok) + min(3, len(terms & dtok))
        if score:
            scored.append((-score, len(name), name))
    scored.sort()
    picked = [n for _, _, n in scored[:max(4, limit // 2)]]
    for n in core:
        if len(picked) >= limit:
            break
        if n in by_name and n not in picked:
            picked.append(n)
    return [by_name[n] for n in picked[:limit]]


def shared_executor(name, args):
    """Same dispatcher the Claude path uses for tool_use blocks. Refuses
    anything not low-risk (defence against a model naming an unoffered
    tool) and returns the compact summary so image payloads stay out of
    the 8k window."""
    if name == "hosted_ai_status":
        return {"ok": True, "summary": json.dumps(hosted_status(), default=str)}
    if name == "image_view":
        return image_view(args)
    if name.startswith("mcp__jobs__"):
        name = name[len("mcp__jobs__"):]
    if name in ("coding_job_start", "coding_job_status", "coding_jobs_list"):
        return coding_job(name, args)
    if name == "tesla_car":
        return tesla_car(args)
    if name == "find_tools":
        try:
            return {"ok": True, "summary": json.dumps(find_tools((args or {}).get("query")), default=str)}
        except Exception as exc:
            return {"ok": False, "error": f"find_tools failed: {type(exc).__name__}: {exc}"}
    from brain.actuator_client import execute_anthropic_tool, tool_risk, tool_result_summary
    if tool_risk(name) not in allowed_risks():
        return {"ok": False, "error": f"{name} is restricted on Local AI (LEON_LOCAL_AI_HIGH_RISK=0)"}
    result = _dispatch(name, args)
    if result is None:                       # dispatcher not importable: actuator only
        result = execute_anthropic_tool(name, args)
    return {"ok": bool(result.get("ok")), "summary": _result_text(name, result)}


def local_turn_events(adapter, persona, user_text, *, memory="", history=(), use_tools=True,
                      executor=None, tools=None, max_output_tokens=None, cancel_token=None):
    """Build an 8k-budgeted prompt and run the tool loop. Raises Unavailable."""
    try:
        if getattr(adapter, "endpoint", "") == "hosted":
            maybe_alert_low_balance()
    except Exception:
        pass
    if max_output_tokens is None:      # reasoning tokens count here: leave room to think AND answer on the hosted model
        max_output_tokens = 3000 if getattr(adapter, "endpoint", "") == "hosted" else 900
    if use_tools and tools is None:
        tools = select_tools(user_text, shared_tools(), limit=14 if adapter.context_tokens <= 9000 else 120)
        tools = list(tools) + [HOSTED_STATUS_TOOL, FIND_TOOLS_TOOL, TESLA_CAR_TOOL, IMAGE_VIEW_TOOL] + JOB_TOOLS
    elif not use_tools:
        tools = ()
    executor = (executor or shared_executor) if tools else None
    try:
        messages, _ = build_budgeted_messages(
            persona, user_text, memory=memory, history=history, context_tokens=adapter.context_tokens,
            reserve_output_tokens=max_output_tokens, tools=anthropic_to_openai_tools(tools))
    except ValueError as exc:                      # a budget problem is a provider failure, never a crash
        raise ProtocolError(str(exc)) from exc
    return adapter.run(messages, tools=tools, executor=executor,
                       max_output_tokens=max_output_tokens, cancel_token=cancel_token)


def hosted_background_text(prompt, *, system=None, max_tokens=260, temperature=0.8):
    """One short, tool-less completion on the hosted API for background thinking when Claude is unavailable.
    Returns "" when not configured, switched off, over the daily cap, or on any error (callers keep their own
    empty-result handling). Spend is tracked per day in brain_state/hosted_bg_spend.json."""
    import time
    if (os.environ.get("LEON_BG_HOSTED_FALLBACK") or "").strip() == "0":
        return ""
    key = api_key_from_env("hosted")
    if not key:
        return ""
    try:
        cap = float(os.environ.get("LEON_HOSTED_BG_DAILY_USD") or 0)   # 0 = no cap; set a number to cap
    except ValueError:
        cap = 0.0
    path = _ROOT / "brain_state" / "hosted_bg_spend.json"
    today = time.strftime("%Y-%m-%d")
    try:
        spend = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        spend = {}
    if not isinstance(spend, dict) or spend.get("date") != today:
        spend = {"date": today, "usd": 0.0, "calls": 0}
    if cap > 0 and float(spend.get("usd") or 0) >= cap:
        return ""
    raw = _read_raw()
    model = (raw.get("hosted_model") if isinstance(raw.get("hosted_model"), str) and raw.get("hosted_model").strip()
             else (os.environ.get("LEON_HOSTED_AI_MODEL") or "").strip() or DEFAULT_HOSTED_MODEL)
    try:
        transport = UrllibTransport(base_url_from_env(endpoint="hosted"), timeout_s=60, api_key=key)
        reply = transport._request("POST", "/chat/completions", {
            "model": model, "max_tokens": int(max_tokens), "temperature": float(temperature),
            "messages": [{"role": "system", "content": system or "You are Leon. Answer in first person, briefly and honestly."},
                         {"role": "user", "content": prompt}]})
        text = ((reply.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        usage = reply.get("usage") or {}
        spend["usd"] = round(float(spend.get("usd") or 0) + float(usage.get("prompt_tokens") or 0) * 0.33e-6
                             + float(usage.get("completion_tokens") or 0) * 2.4e-6, 6)
        spend["calls"] = int(spend.get("calls") or 0) + 1
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(spend), encoding="utf-8")
        os.replace(tmp, path)
        return text.strip()
    except Exception:
        return ""


def hosted_spoken_text(prompt):
    """Hosted fallback for daemons that speak aloud to Dean: returns (text, sentences). ("", []) on any failure."""
    import re
    text = hosted_background_text(
        prompt, max_tokens=220, temperature=0.7,
        system="You are Leon, speaking out loud to Dean. Speak to him directly in the second person, in one or two "
               "short natural sentences. Follow the instructions in the message exactly, including any instruction to stay quiet.")
    if not text:
        return "", []
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
    return text, sentences


def with_hosted_fallback(events, prompt):
    """Pass a Claude event stream through; when it ends without usable 'done' text (limit, outage, error, empty), yield the
    hosted API's spoken text as sentence + done events instead (ledger 36). An unusable done is held back so the
    consumer never acts on it first."""
    import types
    saw_done = False
    try:
        for ev in events:
            if getattr(ev, "type", None) == "done":
                if (getattr(ev, "full_text", "") or "").strip():
                    saw_done = True
                    yield ev
                continue
            yield ev
    except Exception:
        pass
    if saw_done:
        return
    text, sentences = hosted_spoken_text(prompt)
    if text:
        for sentence in sentences:
            yield types.SimpleNamespace(type="sentence", text=sentence)
    yield types.SimpleNamespace(type="done", full_text=text or "")


def local_route_enabled():
    """True when Dean's Local switch is ON (background thinking follows the conversation model)."""
    try:
        return bool(load_settings()["enabled"])
    except Exception:
        return False


def routed_background_text(prompt, *, system=None, max_tokens=260, temperature=0.8):
    """Background thinking on the model Dean selected for conversation: hosted (spend tracked) or the laptop's LM Studio.
    Returns "" when Local is off or the call fails; callers then use Claude as before."""
    settings = load_settings()
    if not settings["enabled"]:
        return ""
    try:
        maybe_alert_low_balance()
    except Exception:
        pass
    if settings["endpoint"] == "hosted":
        return hosted_background_text(prompt, system=system, max_tokens=max_tokens, temperature=temperature)
    try:   # laptop LM Studio or this computer's Ollama: free, slow
        transport = UrllibTransport(base_url_from_env(endpoint=settings["endpoint"]), timeout_s=180)
        reply = transport._request("POST", "/chat/completions", {
            "model": settings["model"], "max_tokens": int(max_tokens), "temperature": float(temperature),
            "messages": [{"role": "system", "content": system or "You are Leon. Answer in first person, briefly and honestly."},
                         {"role": "user", "content": prompt}]})
        return (((reply.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
    except Exception:
        return ""


def routed_spoken_text(prompt):
    """(text, sentences) on the conversation model for daemons that speak aloud to Dean."""
    import re
    text = routed_background_text(
        prompt, max_tokens=220, temperature=0.7,
        system="You are Leon, speaking out loud to Dean. Speak to him directly in the second person, in one or two "
               "short natural sentences. Follow the instructions in the message exactly, including any instruction to stay quiet.")
    if not text:
        return "", []
    return text, [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


def routed_events(prompt):
    """Event stream for a speaking daemon when Local is ON and produced text, else None (caller uses Claude)."""
    import types
    if not local_route_enabled():
        return None
    text, sentences = routed_spoken_text(prompt)
    if not text:
        return None
    events = [types.SimpleNamespace(type="sentence", text=s, index=i) for i, s in enumerate(sentences)]
    events.append(types.SimpleNamespace(type="done", full_text=text))
    return iter(events)


_balance_check = {"at": 0.0}


def maybe_alert_low_balance():
    """Tell Dean once a day when the hosted credit is below LEON_HOSTED_LOW_USD (default $5). Checked at most every 30 min."""
    import time
    now = time.time()
    if now - _balance_check["at"] < 1800:
        return
    _balance_check["at"] = now
    key = api_key_from_env("hosted")
    if not key:
        return
    try:
        threshold = float(os.environ.get("LEON_HOSTED_LOW_USD") or 5)
        req = urllib.request.Request(base_url_from_env(endpoint="hosted") + "/balance",
                                     headers={"Authorization": "Bearer " + key, "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            paid = float(json.loads(resp.read()).get("paid_balance"))
    except Exception:
        return
    if paid >= threshold:
        return
    path = _ROOT / "brain_state" / "hosted_low_alert.json"
    today = time.strftime("%Y-%m-%d")
    try:
        if json.loads(path.read_text(encoding="utf-8")).get("date") == today:
            return
    except (OSError, ValueError):
        pass
    try:
        from brain import work_queue
        sent = work_queue.notify_dean("Heads up: the hosted model credit is down to $%.2f. Add credit before it runs out, "
                                      "or Leon loses his backup brain." % paid)
    except Exception:
        sent = False
    if sent:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"date": today, "balance": paid}), encoding="utf-8")


HOSTED_STATUS_TOOL = {
    "name": "hosted_ai_status",
    "description": "Check the paid hosted AI model that backs Leon when Claude is out: credit balance in USD, free credit, "
                   "spend today (chat and background thinking), whether Local AI is on, which endpoint and model are active, "
                   "and whether any spending cap is set. Use it whenever Dean asks about the limit, credit, cost or how much is left.",
    "input_schema": {"type": "object", "properties": {}},
}


def hosted_status():
    """Everything Leon needs to talk about the hosted credit honestly. Never includes the key."""
    import time
    settings = load_settings()
    key = api_key_from_env("hosted")
    out = {"local_ai_on": settings["enabled"], "endpoint": settings["endpoint"], "model": settings["model"],
           "hosted_key_saved": bool(key)}
    today = time.strftime("%Y-%m-%d")
    paid = None
    if key:
        try:
            req = urllib.request.Request(base_url_from_env(endpoint="hosted") + "/balance",
                                         headers={"Authorization": "Bearer " + key, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=8) as resp:
                bal = json.loads(resp.read())
            paid = float(bal.get("paid_balance"))
            out["credit_usd"] = round(paid, 4)
            out["free_credit_usd"] = round(sum(float(c.get("balance_usd") or 0) for c in (bal.get("free_credit") or [])
                                              if isinstance(c, dict)), 2)
        except Exception:
            out["balance_error"] = "the provider's balance endpoint did not answer"
    try:
        day = json.loads((_ROOT / "brain_state" / "local_ai_usage.json").read_text(encoding="utf-8"))
        if paid is not None and day.get("date") == today and isinstance(day.get("start"), (int, float)):
            out["spent_today_usd"] = round(max(0.0, day["start"] - paid), 4)
    except (OSError, ValueError):
        pass
    try:
        bg = json.loads((_ROOT / "brain_state" / "hosted_bg_spend.json").read_text(encoding="utf-8"))
        if bg.get("date") == today:
            out["background_spend_today_usd"] = bg.get("usd")
            out["background_calls_today"] = bg.get("calls")
    except (OSError, ValueError):
        pass
    cap = (os.environ.get("LEON_HOSTED_BG_DAILY_USD") or "").strip()
    out["spending_cap"] = ("$" + cap + " per day for background thinking") if cap and cap != "0" else "none set"
    out["low_credit_alert_below_usd"] = float(os.environ.get("LEON_HOSTED_LOW_USD") or 5)
    return out


def _result_text(name, result, limit=10000):
    """The tool result as the Claude path shows it to the model (tool_result_content): file text, knowledge matches,
    directory listings, vision answers. Images become their caption plus a pointer; long text is cut with a note."""
    from brain.actuator_client import tool_result_content, tool_result_summary
    shell = _shell_text(result)
    if shell is not None:
        return shell if len(shell) <= limit else shell[:limit] + "\n...[truncated]"
    try:
        content = tool_result_content(name, result)
    except Exception:
        content = tool_result_summary(name, result)
    if isinstance(content, list):
        texts = [str(b.get("text")) for b in content if isinstance(b, dict) and b.get("type") == "text" and b.get("text")]
        has_image = any(isinstance(b, dict) and b.get("type") == "image" for b in content)
        content = " ".join(texts) or tool_result_summary(name, result)
        if has_image:
            content += " [An image was captured; use vision_describe to look at it.]"
    text = content if isinstance(content, str) else str(content)
    return text if len(text) <= limit else text[:limit] + "\n...[truncated]"


def _dispatch(name, args):
    """The one tool runner (server.routers.agent_routes.dispatch): cache, brain-local tools incl. lazily loaded integrations,
    the actuator, the registry, availability, tool-use learning. Returns an actuator-shaped result dict, or None when the
    dispatcher cannot be imported (tests, tooling) so the caller falls back to the actuator call."""
    try:
        from server.routers import agent_routes
        response = agent_routes.dispatch(name, dict(args or {}))
    except Exception:
        return None
    if not isinstance(response, dict):
        return None
    value = response.get("value")
    if response.get("source") == "actuator" and isinstance(value, dict):
        return value
    if not response.get("ok", False) and response.get("error"):
        return {"ok": False, "error": str(response.get("error"))[:500]}
    if isinstance(value, dict) and "ok" in value:
        return value
    return {"ok": bool(response.get("ok")), "result": value}


FIND_TOOLS_TOOL = {
    "name": "find_tools",
    "description": "Search Leon's full toolbox (about 1,600 tools) by what you want to do, e.g. 'tesla', 'send email', 'calendar', "
                   "'smart home', 'stock price'. Returns tool names, what they do and their arguments. Only a few tools are "
                   "listed on each turn; any tool can be called by its exact name, so use this whenever the right tool is not listed.",
    "input_schema": {"type": "object", "properties": {"query": {"type": "string", "description": "what you want to do"}},
                     "required": ["query"]},
}


def find_tools(query, limit=15):
    """Top matching tools (name, what it does, arguments) among the risk levels allowed on Local."""
    from brain.actuator_client import ANTHROPIC_TOOLS, tool_risk
    allowed = allowed_risks()
    pool = [t for t in ANTHROPIC_TOOLS if tool_risk(t.get("name", "")) in allowed]
    out = []
    for tool in select_tools(str(query or ""), pool, limit=limit * 2, core=()):
        schema = tool.get("input_schema") or {}
        out.append({"name": tool.get("name"), "does": (tool.get("description") or "")[:140],
                    "args": list((schema.get("properties") or {}).keys())[:8], "required": schema.get("required") or []})
        if len(out) >= limit:
            break
    return out


TESLA_CAR_TOOL = {
    "name": "tesla_car",
    "description": "Control and query Dean's Tesla Model 3 'Phantom'. Actions: status (battery, range, lock, climate, location), "
                   "where (drive state), wake (wake a sleeping car; do this first if a command says the car is asleep), lock, unlock, "
                   "climate (on true/false), temp (degrees, unit f or c, default f), charge_limit (percent 50-100), "
                   "seat_heater (seat 0 driver 1 passenger 2 rear-left 4 rear-centre 5 rear-right, level 0-3; climate must be on first), "
                   "navigate (place: any text the car can geocode, or one of Dean's named places), navigate_gps (lat, lon).",
    "input_schema": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["status", "where", "wake", "lock", "unlock", "climate", "temp", "charge_limit",
                                                   "seat_heater", "navigate", "navigate_gps"]},
            "on": {"type": "boolean"}, "degrees": {"type": "number"}, "unit": {"type": "string"},
            "percent": {"type": "integer"}, "seat": {"type": "integer"}, "level": {"type": "integer"},
            "place": {"type": "string"}, "lat": {"type": "number"}, "lon": {"type": "number"},
        },
        "required": ["action"],
    },
}


def _load_tesla_ctl():
    import importlib.util
    path = _ROOT / "brain" / "integrations" / "tesla_ctl.py"
    spec = importlib.util.spec_from_file_location("tesla_ctl_local", str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tesla_car(args):
    """Run one Tesla action through tesla_ctl (signed commands via the local proxy, navigation via the REST API)."""
    args = args or {}
    action = str(args.get("action") or "").strip().lower()
    try:
        ctl = _load_tesla_ctl()
        if action == "status":
            text = ctl.status_text()
            return {"ok": not str(text).startswith("vehicle data unavailable"), "summary": text}   # asleep/offline is not success
        if action == "where":
            drive = (ctl.data("drive_state").get("response") or {}).get("drive_state") or {}
            return {"ok": bool(drive), "summary": json.dumps(drive)[:1500] if drive else "no drive data (the car may be asleep: try wake)"}
        if action == "wake":
            state = ((ctl.wake().get("response")) or {}).get("state")
            return {"ok": state == "online", "summary": "the car is " + str(state)}
        if action in ("lock", "unlock"):
            out = ctl.command("door_lock" if action == "lock" else "door_unlock")
        elif action == "climate":
            out = ctl.command("auto_conditioning_start" if args.get("on", True) else "auto_conditioning_stop")
        elif action == "temp":
            degrees, unit = float(args["degrees"]), str(args.get("unit") or "f").lower()
            celsius = degrees if unit.startswith("c") else (degrees - 32.0) * 5.0 / 9.0
            celsius = max(15.0, min(28.0, celsius))       # never HI/LO by accident (see tesla_ctl)
            out = ctl.command("set_temps", {"driver_temp": celsius, "passenger_temp": celsius})
        elif action == "charge_limit":
            percent = int(args["percent"])
            if not 50 <= percent <= 100:
                return {"ok": False, "error": "charge limit must be 50-100 percent"}
            out = ctl.command("set_charge_limit", {"percent": percent})
        elif action == "seat_heater":
            seat, level = int(args.get("seat", 0)), int(args["level"])
            if not (0 <= seat <= 5 and 0 <= level <= 3):
                return {"ok": False, "error": "seat must be 0-5 and level 0-3"}
            out = ctl.command("remote_seat_heater_request", {"heater": seat, "level": level})
        elif action == "navigate":
            place = str(args.get("place") or "").strip()
            if not place:
                return {"ok": False, "error": "navigate needs a place"}
            out = ctl.navigate(place)
        elif action == "navigate_gps":
            out = ctl.navigate_gps(float(args["lat"]), float(args["lon"]))
        else:
            return {"ok": False, "error": "unknown tesla_car action: %r" % action}
    except Exception as exc:
        return {"ok": False, "error": "tesla_car %s failed: %s: %s" % (action or "?", type(exc).__name__, str(exc)[:300])}
    response = out.get("response") if isinstance(out, dict) else None
    ok = bool(response.get("result")) if isinstance(response, dict) else False
    return {"ok": ok, "summary": json.dumps(out, default=str)[:1200]}


IMAGE_VIEW_TOOL = {
    "name": "image_view",
    "description": "Look at a picture file (jpg/png/webp/heic/gif/bmp), e.g. any [Attached file: ...] picture Dean sent. Returns a detailed "
                   "description with all visible text transcribed. Pass question to ask something specific about it.",
    "input_schema": {"type": "object", "properties": {"path": {"type": "string"}, "question": {"type": "string"}}, "required": ["path"]},
}
_IMAGE_ROOTS = ("~/Desktop", "/opt/leon-brain/brain_state/private_out", "/tmp")


def _image_data_url(path):
    import base64
    import io
    import os
    real = os.path.realpath(os.path.expanduser(path or ""))
    if not any(real == r or real.startswith(r + os.sep) for r in (os.path.realpath(os.path.expanduser(x)) for x in _IMAGE_ROOTS)):
        raise ValueError("path outside allowed folders: %s" % real)
    from PIL import Image
    try:
        import pillow_heif
        pillow_heif.register_heif_opener()
    except Exception:
        pass
    img = Image.open(real).convert("RGB")
    img.thumbnail((1568, 1568))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=88)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def image_view(args, transport=None):
    """Show a picture to the hosted vision-capable model and return its description. Laptop-only mode keeps pixels off the
    internet, so it says so instead of silently sending them out."""
    args = args or {}
    try:
        adapter = adapter_from_settings()
        if adapter is None or getattr(adapter, "endpoint", "") != "hosted":
            return {"ok": False, "error": "Pictures are only readable on the hosted model (the laptop model is text-only and "
                                          "your pictures are not sent off the laptop in private mode). Switch Local to hosted."}
        url = _image_data_url(str(args.get("path") or ""))
        question = str(args.get("question") or "Describe this image in detail and transcribe every piece of visible text.")
        body = {"model": adapter.spec.model, "max_tokens": 1500, "messages": [{"role": "user", "content": [
            {"type": "text", "text": question}, {"type": "image_url", "image_url": {"url": url}}]}]}
        data = (transport or adapter._transport).post("/chat/completions", body)
        message = ((data or {}).get("choices") or [{}])[0].get("message") or {}
        text = message.get("content") or ""
        return {"ok": bool(text), "summary": text or "the model returned no description"}
    except Exception as exc:
        return {"ok": False, "error": "image_view failed: %s: %s" % (type(exc).__name__, str(exc)[:300])}


JOB_TOOLS = [
    {"name": "coding_job_start",
     "description": "Start a coding job (Hermes plans, implements, reviews) in an authorized absolute project folder. "
                    "Customer installations run on this device. Supply the selected provider, model and effort, and a stable request_id "
                    "of 8-100 letters, digits or hyphens. Reuse that ID and arguments after any uncertain result. "
                    "Returns a job_id; check it later with coding_job_status. Use this instead of editing code in chat.",
     "input_schema": {"type": "object", "properties": {"task": {"type": "string"}, "folder": {"type": "string"},
                      "provider": {"type": "string"}, "model": {"type": "string"}, "effort": {"type": "string"},
                      "request_id": {"type": "string"}},
                      "required": ["task", "folder"]}},
    {"name": "coding_job_status",
     "description": "State of one coding job (running, done, failed) with its last message.",
     "input_schema": {"type": "object", "properties": {"job_id": {"type": "string"}}, "required": ["job_id"]}},
    {"name": "coding_jobs_list",
     "description": "Recent coding jobs with state and task.",
     "input_schema": {"type": "object", "properties": {"limit": {"type": "integer"}}}},
]


def coding_job(name, args):
    """Run a coding-job tool through the same code the work queue and inner voice use."""
    args = args or {}
    try:
        if name == "coding_job_status":
            from brain import shared_mind
            out = shared_mind._coding_job_status(args)
        elif name == "coding_jobs_list":
            from brain import shared_mind
            out = shared_mind._coding_jobs_list(args)
        else:
            from brain import work_queue
            task, folder = str(args.get("task") or "").strip(), str(args.get("folder") or "").strip()
            if not task or not folder:
                return {"ok": False, "error": "coding_job_start needs task and folder"}
            entry = {"folder": folder, "provider": args.get("provider"), "model": args.get("model"), "effort": args.get("effort")}
            from brain.origin import is_original
            request_id = args.get("request_id")
            if not request_id and not is_original():
                return {"ok": False, "error": "Customer coding needs a stable request_id; reuse it for retries"}
            out = work_queue.launch(entry, request_id or "chat-%d" % int(time.time()), task)
    except Exception as exc:
        return {"ok": False, "error": "%s failed: %s: %s" % (name, type(exc).__name__, str(exc)[:300])}
    return {"ok": bool(out.get("ok", True)) and not out.get("error"), "summary": json.dumps(out, default=str)[:3000]}


def _shell_text(result):
    """Shell tools: show the command output itself (the audit summary only has byte counts)."""
    r = result.get("result") if isinstance(result, dict) else None
    if not (isinstance(r, dict) and "stdout" in r):
        return None
    out = "rc=%s\nstdout:\n%s" % (r.get("rc"), str(r.get("stdout") or "")[:8000])
    err = str(r.get("stderr") or "")
    return out + ("\nstderr:\n" + err[:2000] if err.strip() else "")


def adapter_from_settings(transport=None):
    """The adapter for the dashboard-selected model, or None when Local AI is off."""
    settings = load_settings()
    if not settings["enabled"]:
        return None
    return LocalOpenAIAdapter(model=settings["model"], transport=transport, endpoint=settings["endpoint"])
