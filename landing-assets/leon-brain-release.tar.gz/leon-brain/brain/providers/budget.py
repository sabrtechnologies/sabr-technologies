"""Atomic daily/monthly reservations, independent of Leon's durable state.

Pass an explicit SQLite path for restart-persistent ceilings. ':memory:' is
for fixtures or intentionally process-local accounting. Unknown final usage
keeps the full reservation charged, including failed/abandoned calls.
"""
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import math
import sqlite3
import threading
import uuid

from .base import ProviderError


class BudgetExceeded(ProviderError):
    pass


@dataclass(frozen=True)
class Limits:
    daily_tokens: int
    monthly_tokens: int
    daily_micro_usd: int
    monthly_micro_usd: int

    def __post_init__(self):
        if any(type(v) is not int or v < 0 for v in vars(self).values()):
            raise ValueError("budget limits must be nonnegative integers")


def price_micro_usd(spec, inputs, outputs):
    if spec.input_usd_per_million is None or spec.output_usd_per_million is None:
        raise BudgetExceeded("provider pricing is not configured")
    return math.ceil(inputs * spec.input_usd_per_million + outputs * spec.output_usd_per_million)


class BudgetLedger:
    def __init__(self, limits, *, per_capability=None, path=":memory:", now=None):
        self.limits, self.per_capability = limits, dict(per_capability or {})
        self._now = now or (lambda: datetime.now(timezone.utc))
        self._lock = threading.Lock()
        self._db = sqlite3.connect(path, timeout=5, isolation_level=None, check_same_thread=False)
        self._db.execute("CREATE TABLE IF NOT EXISTS usage (period TEXT, scope TEXT, tokens INTEGER, cost INTEGER, PRIMARY KEY(period,scope))")
        self._db.execute("CREATE TABLE IF NOT EXISTS reservations (id TEXT PRIMARY KEY, periods TEXT, scopes TEXT, tokens INTEGER, cost INTEGER)")

    def reserve(self, capabilities, tokens, micro_usd):
        if any(type(n) is not int or n < 0 for n in (tokens, micro_usd)):
            raise ValueError("invalid reservation")
        now = self._now().astimezone(timezone.utc)
        periods = ("D:" + now.strftime("%Y-%m-%d"), "M:" + now.strftime("%Y-%m"))
        scopes = ["*"] + sorted({str(getattr(c, "value", c)) for c in capabilities} & self.per_capability.keys())
        ticket = uuid.uuid4().hex
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                for scope in scopes:
                    limits = self.limits if scope == "*" else self.per_capability[scope]
                    for period, token_limit, cost_limit in zip(periods,
                            (limits.daily_tokens, limits.monthly_tokens),
                            (limits.daily_micro_usd, limits.monthly_micro_usd)):
                        used = self._db.execute("SELECT tokens,cost FROM usage WHERE period=? AND scope=?", (period, scope)).fetchone() or (0, 0)
                        if used[0] + tokens > token_limit or used[1] + micro_usd > cost_limit:
                            raise BudgetExceeded("budget ceiling reached for " + scope)
                for scope in scopes:
                    for period in periods:
                        self._db.execute("INSERT INTO usage VALUES(?,?,?,?) ON CONFLICT(period,scope) DO UPDATE SET tokens=tokens+excluded.tokens,cost=cost+excluded.cost", (period, scope, tokens, micro_usd))
                self._db.execute("INSERT INTO reservations VALUES(?,?,?,?,?)", (ticket, json.dumps(periods), json.dumps(scopes), tokens, micro_usd))
                self._db.execute("COMMIT")
            except BaseException:
                self._db.execute("ROLLBACK")
                raise
        return ticket

    def would_admit(self, capabilities, tokens, micro_usd):
        """Read-only preview of reserve(): True when it fits every ceiling now.

        Nothing is reserved or written. reserve() remains the only authority;
        this lets a caller choose its baseline before selecting a provider.
        """
        if any(type(n) is not int or n < 0 for n in (tokens, micro_usd)):
            raise ValueError("invalid reservation")
        now = self._now().astimezone(timezone.utc)
        periods = ("D:" + now.strftime("%Y-%m-%d"), "M:" + now.strftime("%Y-%m"))
        scopes = ["*"] + sorted({str(getattr(c, "value", c)) for c in capabilities} & self.per_capability.keys())
        with self._lock:
            for scope in scopes:
                limits = self.limits if scope == "*" else self.per_capability[scope]
                for period, token_limit, cost_limit in zip(periods,
                        (limits.daily_tokens, limits.monthly_tokens),
                        (limits.daily_micro_usd, limits.monthly_micro_usd)):
                    used = self._db.execute("SELECT tokens,cost FROM usage WHERE period=? AND scope=?", (period, scope)).fetchone() or (0, 0)
                    if used[0] + tokens > token_limit or used[1] + micro_usd > cost_limit:
                        return False
        return True

    def settle(self, ticket, *, tokens=None, micro_usd=None):
        if (tokens is None) != (micro_usd is None):
            raise ValueError("provide both final usage values or neither")
        if tokens is not None and any(type(n) is not int or n < 0 for n in (tokens, micro_usd)):
            raise ValueError("invalid settlement")
        with self._lock:
            self._db.execute("BEGIN IMMEDIATE")
            try:
                row = self._db.execute("SELECT periods,scopes,tokens,cost FROM reservations WHERE id=?", (ticket,)).fetchone()
                if row is not None:
                    if tokens is not None:
                        for period in json.loads(row[0]):
                            for scope in json.loads(row[1]):
                                self._db.execute("UPDATE usage SET tokens=tokens+?,cost=cost+? WHERE period=? AND scope=?", (tokens-row[2], micro_usd-row[3], period, scope))
                    self._db.execute("DELETE FROM reservations WHERE id=?", (ticket,))
                self._db.execute("COMMIT")
                return row is not None
            except BaseException:
                self._db.execute("ROLLBACK")
                raise

    def snapshot(self):
        with self._lock:
            return [dict(period=p, scope=s, tokens=t, micro_usd=c) for p, s, t, c in self._db.execute("SELECT * FROM usage ORDER BY period,scope")]

    def close(self):
        with self._lock:
            self._db.close()
