"""Provider contracts. Identity, memory, goals and tool authorization stay outside.

Adapters never acquire the global inference slot. The InferenceScheduler owns
that slot; router locks additionally serialize each non-concurrent resource.
"""
from dataclasses import dataclass, field
from enum import Enum
import json
import math
import time
import uuid
from typing import Any, FrozenSet, Iterator, Mapping, Optional, Protocol


class Capability(str, Enum):
    FAST_LANGUAGE = "fast_language"
    DEEP_REASONING = "deep_reasoning"
    CODING = "coding"
    TOOL_USE = "tool_use"
    VISION = "vision"
    EMBEDDING = "embedding"
    SPEECH_TO_TEXT = "speech_to_text"
    TEXT_TO_SPEECH = "text_to_speech"
    DECISION = "decision"


class ProviderError(RuntimeError):
    pass


class Unavailable(ProviderError):
    pass


class UnsupportedPolicy(ProviderError):
    pass


class Cancelled(ProviderError):
    pass


class ProtocolError(ProviderError):
    pass


class CancelSignal(Protocol):
    def is_set(self) -> bool: ...
    def add_callback(self, callback): ...


@dataclass(frozen=True)
class ProviderSpec:
    provider_id: str
    model: str
    capabilities: FrozenSet[Capability]
    local: bool = False
    tier: int = 1  # 0 local/simple, 1 normal hosted, 2 explicit deep escalation
    no_tools_enforced: bool = True
    retry_safe: bool = True
    input_usd_per_million: Optional[float] = None
    output_usd_per_million: Optional[float] = None

    def __post_init__(self):
        if not self.provider_id or not self.model or self.tier not in (0, 1, 2):
            raise ValueError("provider id, configured model and supported tier required")
        object.__setattr__(self, "capabilities", frozenset(Capability(c) for c in self.capabilities))
        for value in (self.input_usd_per_million, self.output_usd_per_million):
            if value is not None and (not math.isfinite(value) or value < 0):
                raise ValueError("prices must be finite nonnegative USD per million tokens")


@dataclass(frozen=True)
class ProviderRequest:
    prompt: str = field(repr=False)
    context: str = field(default="", repr=False)
    capabilities: FrozenSet[Capability] = field(default_factory=lambda: frozenset({Capability.FAST_LANGUAGE}))
    allow_tools: bool = False
    persist_history: bool = False
    background: bool = False
    deep: bool = False
    max_output_tokens: int = 512
    deadline_mono: Optional[float] = None
    questions: Mapping[str, Any] = field(default_factory=dict, repr=False)
    legacy_kwargs: Mapping[str, Any] = field(default_factory=dict, repr=False)
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex)

    def __post_init__(self):
        if not isinstance(self.prompt, str) or not isinstance(self.context, str):
            raise ValueError("prompt and rendered context must be strings")
        if not isinstance(self.trace_id, str) or not self.trace_id or len(self.trace_id) > 128:
            raise ValueError("trace_id must be a nonempty string of at most 128 characters")
        if type(self.max_output_tokens) is not int or not 16 <= self.max_output_tokens <= 32768:
            raise ValueError("max_output_tokens must be 16..32768")
        if self.deadline_mono is not None and not math.isfinite(self.deadline_mono):
            raise ValueError("deadline must be finite")
        object.__setattr__(self, "capabilities", frozenset(Capability(c) for c in self.capabilities))
        if not self.capabilities:
            raise ValueError("at least one required capability is necessary")
        if Capability.TOOL_USE in self.capabilities and not self.allow_tools:
            raise UnsupportedPolicy("tool_use capability conflicts with allow_tools=False")

    def input_bound(self):
        # A conservative byte bound for text tokenizers, plus request framing.
        # Legacy wrappers can add opaque prompt material; their adapter must
        # supply a larger explicit bound or remain unavailable to this router.
        return len((self.prompt + self.context).encode("utf-8")) + len(
            json.dumps(self.questions, ensure_ascii=False).encode("utf-8")) + 1024


@dataclass(frozen=True)
class Usage:
    input_tokens: int
    output_tokens: int

    def __post_init__(self):
        if any(type(n) is not int or n < 0 for n in (self.input_tokens, self.output_tokens)):
            raise ProtocolError("invalid usage counts")


@dataclass(frozen=True)
class ProviderEvent:
    type: str
    text: str = field(default="", repr=False)
    full_text: str = field(default="", repr=False)
    payload: Any = field(default=None, repr=False)
    usage: Optional[Usage] = None
    usage_final: bool = False  # Adapter attests these counts cover the whole call.
    provider: str = ""
    model: str = ""
    raw: Any = field(default=None, repr=False)


class ProviderAdapter(Protocol):
    spec: ProviderSpec
    configured: bool
    def stream(self, request: ProviderRequest, cancel_token: Optional[CancelSignal] = None) -> Iterator[ProviderEvent]: ...
    def input_bound(self, request: ProviderRequest) -> int: ...
    def output_bound(self, request: ProviderRequest) -> int: ...


def check_cancel(token=None, deadline=None):
    if token is not None and token.is_set():
        raise Cancelled("inference cancelled")
    if deadline is not None and time.monotonic() >= deadline:
        raise Cancelled("inference deadline expired")


def check_policy(spec, request):
    if not request.capabilities <= spec.capabilities:
        raise UnsupportedPolicy("provider lacks required capabilities")
    if not request.allow_tools and not spec.no_tools_enforced:
        raise UnsupportedPolicy("provider cannot enforce no-tools policy")
    if spec.tier == 2 and not (request.deep or Capability.DEEP_REASONING in request.capabilities):
        raise UnsupportedPolicy("strongest model requires an explicit deep request")
