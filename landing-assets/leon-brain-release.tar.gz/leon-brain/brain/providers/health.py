"""Passive content-free health; no startup probes or background threads."""
from dataclasses import dataclass, asdict
import threading
import time


#: One failed dispatched call on an operator-routed scope keeps that provider
#: out of selection for this long. Only trusted code may construct a registry
#: with another value; no operator file or request field carries it.
ROUTE_BREAKER_COOLDOWN_S = 120.0


@dataclass
class Health:
    failures: int = 0
    successes: int = 0
    latency_ms: float = 0.0
    retry_after: float = 0.0


class HealthRegistry:
    def __init__(self, *, threshold=3, cooldown_s=60, clock=time.monotonic):
        if threshold < 1 or cooldown_s <= 0:
            raise ValueError("invalid circuit settings")
        self.threshold, self.cooldown_s, self.clock = threshold, cooldown_s, clock
        self._lock, self._states = threading.Lock(), {}

    def available(self, provider):
        with self._lock:
            return self.clock() >= self._states.get(provider, Health()).retry_after

    def success(self, provider, latency_ms):
        with self._lock:
            state = self._states.setdefault(provider, Health())
            state.successes += 1
            state.failures, state.retry_after = 0, 0
            state.latency_ms = latency_ms if not state.latency_ms else state.latency_ms * .8 + latency_ms * .2

    def failure(self, provider):
        with self._lock:
            state = self._states.setdefault(provider, Health())
            state.failures += 1
            if state.failures >= self.threshold:
                state.retry_after = self.clock() + self.cooldown_s

    def snapshot(self):
        with self._lock:
            return {name: asdict(state) for name, state in self._states.items()}


def route_breaker(*, cooldown_s=ROUTE_BREAKER_COOLDOWN_S, clock=time.monotonic):
    """Breaker for explicitly routed scopes: one failure opens it for the cooldown."""
    if type(cooldown_s) not in (int, float) or not 1 <= cooldown_s <= 3600:
        raise ValueError("invalid route breaker cooldown")
    return HealthRegistry(threshold=1, cooldown_s=float(cooldown_s), clock=clock)
