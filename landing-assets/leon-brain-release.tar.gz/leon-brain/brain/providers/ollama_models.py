"""Ollama models for the dashboard's Local provider: what is installed, a short catalog, a name lookup, and pulls.

The daemon is the one brain/local_llm.py calls TRUE local (LEON_TRUE_LOCAL_URL, default 127.0.0.1:11434).
Its OpenAI-compatible endpoint (daemon + /v1) is what local_openai_adapter uses when the source is "ollama".
Nothing here touches credentials; every network call is bounded by a timeout and a byte cap.
"""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

DEFAULT_DAEMON_URL = "http://127.0.0.1:11434"
LIBRARY_URL = "https://ollama.com"
REGISTRY_URL = "https://registry.ollama.ai"
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}(/[a-z0-9][a-z0-9._-]{0,63})?(:[A-Za-z0-9][A-Za-z0-9._-]{0,63})?$")
MAX_BODY = 4 * 1024 * 1024

# Known-good small instruct models. Sizes are the published download sizes, rounded; "~" in the UI.
CATALOG = (
    {"name": "llama3.2:1b", "size_gb": 1.3, "note": "Fastest. Fine for quick replies on a CPU."},
    {"name": "llama3.2:3b", "size_gb": 2.0, "note": "The installer's default offline brain."},
    {"name": "qwen2.5:3b-instruct-q4_K_M", "size_gb": 1.9, "note": "Small, good at instructions and tools."},
    {"name": "phi3.5:3.8b", "size_gb": 2.2, "note": "Compact Microsoft model, strong reasoning for its size."},
    {"name": "qwen2.5:7b-instruct-q4_K_M", "size_gb": 4.7, "note": "Better answers; wants 8 GB of RAM or VRAM."},
    {"name": "gemma3:4b", "size_gb": 3.3, "note": "Google's small multimodal model."},
    {"name": "qwen3.6:35b-a3b", "size_gb": 23.0, "note": "Big MoE: 30B-class quality, small-model speed. Needs ~24 GB."},
)


def daemon_url(environ=None):
    environ = os.environ if environ is None else environ
    url = (environ.get("LEON_TRUE_LOCAL_URL") or "").strip() or DEFAULT_DAEMON_URL
    if not url.startswith(("http://", "https://")):
        raise ValueError("Ollama URL must be an http(s) URL")
    return url.rstrip("/")


def valid_name(name):
    return isinstance(name, str) and bool(NAME_RE.match(name))


def _get_json(url, timeout, opener=None, headers=None):
    req = urllib.request.Request(url, headers={"Accept": "application/json", **(headers or {})})
    with (opener or urllib.request.urlopen)(req, timeout=timeout) as resp:
        data = json.loads(resp.read(MAX_BODY).decode("utf-8", "replace"))
    if not isinstance(data, dict):
        raise ValueError("unexpected response shape")
    return data


def status(timeout=3.0, opener=None, environ=None):
    """{'reachable', 'url', 'models': [{'name','size_gb','family','parameters','quantization'}], 'error'}."""
    url = daemon_url(environ)
    try:
        data = _get_json(url + "/api/tags", timeout, opener)
    except Exception as exc:  # network or JSON; the reason is for the owner, never a traceback
        return {"reachable": False, "url": url, "models": [],
                "error": "Ollama is not answering at " + url + " (" + type(exc).__name__ + ")."}
    models = []
    for item in data.get("models") or []:
        if not isinstance(item, dict) or not isinstance(item.get("name"), str):
            continue
        details = item.get("details") if isinstance(item.get("details"), dict) else {}
        size = item.get("size") if isinstance(item.get("size"), (int, float)) else 0
        models.append({"name": item["name"], "size_gb": round(size / 1e9, 1) if size else None,
                       "family": details.get("family"), "parameters": details.get("parameter_size"),
                       "quantization": details.get("quantization_level")})
    return {"reachable": True, "url": url, "models": models, "error": None}


def catalog(installed=()):
    names = set(installed)
    return [{**entry, "installed": entry["name"] in names} for entry in CATALOG]


def lookup(name, timeout=8.0, opener=None):
    """Look a model up in the public Ollama library.

    "llama3.2" -> {'found', 'name', 'tags': [...]}; "llama3.2:3b" additionally reports the download size from the
    registry manifest. Never pulls anything.
    """
    if not valid_name(name):
        raise ValueError("Model names look like llama3.2 or llama3.2:3b (lowercase, optional user/ prefix).")
    repo, _, tag = name.partition(":")
    path = repo if "/" in repo else "library/" + repo
    out = {"found": False, "name": repo, "tag": tag or None, "tags": [], "size_gb": None}
    try:
        data = _get_json(LIBRARY_URL + "/" + path + "/tags", timeout, opener)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return out
        raise
    tags = [t for t in (data.get("tags") or []) if isinstance(t, str)]
    out.update(found=True, tags=tags[:200])
    if tag:
        out["found"] = tag in tags
        if out["found"]:
            try:
                manifest = _get_json(REGISTRY_URL + "/v2/" + path + "/manifests/" + urllib.parse.quote(tag), timeout, opener,
                                     headers={"Accept": "application/vnd.docker.distribution.manifest.v2+json"})
                layers = manifest.get("layers") or []
                total = sum(int(layer.get("size") or 0) for layer in layers if isinstance(layer, dict))
                out["size_gb"] = round(total / 1e9, 1) if total else None
            except Exception:
                out["size_gb"] = None
    return out


class PullManager:
    """One download at a time, progress readable at any moment. Pulls run in the daemon; we only watch the stream."""

    def __init__(self, opener=None, environ=None, clock=time.time):
        self._opener = opener or urllib.request.urlopen
        self._environ = environ
        self._clock = clock
        self._lock = threading.Lock()
        self._pulls = {}
        self._thread = None

    def snapshot(self):
        with self._lock:
            return {name: dict(value) for name, value in self._pulls.items()}

    def active(self):
        with self._lock:
            return next((name for name, value in self._pulls.items() if not value["done"]), None)

    def start(self, name):
        if not valid_name(name):
            raise ValueError("Model names look like llama3.2 or llama3.2:3b (lowercase, optional user/ prefix).")
        with self._lock:
            busy = next((n for n, v in self._pulls.items() if not v["done"]), None)
            if busy:
                raise RuntimeError("Already downloading " + busy + ". One download at a time.")
            self._pulls[name] = {"status": "starting", "completed": 0, "total": 0, "done": False,
                                 "error": None, "started": self._clock(), "finished": None}
            self._thread = threading.Thread(target=self._run, args=(name,), name="ollama-pull", daemon=True)
            self._thread.start()
        return self.snapshot()[name]

    def wait(self, timeout=None):
        thread = self._thread
        if thread:
            thread.join(timeout)

    def _update(self, name, **fields):
        with self._lock:
            self._pulls[name].update(fields)

    def _run(self, name):
        url = daemon_url(self._environ) + "/api/pull"
        body = json.dumps({"name": name, "stream": True}).encode()
        req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
        layers = {}
        try:
            with self._opener(req, timeout=24 * 3600) as resp:
                for raw in resp:
                    line = raw.decode("utf-8", "replace").strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                    except ValueError:
                        continue
                    if not isinstance(event, dict):
                        continue
                    if event.get("error"):
                        raise RuntimeError(str(event["error"])[:300])
                    digest = event.get("digest")
                    if digest and isinstance(event.get("total"), (int, float)):
                        layers[digest] = (int(event.get("completed") or 0), int(event["total"]))
                    completed = sum(c for c, _ in layers.values())
                    total = sum(t for _, t in layers.values())
                    self._update(name, status=str(event.get("status") or "downloading")[:80], completed=completed, total=total)
            self._update(name, status="installed", done=True, finished=self._clock())
        except Exception as exc:
            message = str(exc)[:300] if isinstance(exc, RuntimeError) else "Download failed (" + type(exc).__name__ + ")."
            self._update(name, status="failed", done=True, error=message, finished=self._clock())


pulls = PullManager()
