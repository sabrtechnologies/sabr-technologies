"""Optional stateless text adapter for an explicitly configured OpenAI model.

No SDK/import-time key lookup, provider identity prompt, conversations or tool
execution. No tools are sent. Responses are requested with store=False.
"""
from .base import Capability, ProviderSpec, ProviderEvent, Usage, ProtocolError, Unavailable, check_cancel, check_policy
from .http_transport import JsonTransport
import json


class OpenAIAdapter:
    accepts_prepared_messages = True
    def __init__(self, *, model, api_key=None, enabled=False, transport=None,
                 capabilities=(Capability.FAST_LANGUAGE,), tier=1,
                 input_usd_per_million=None, output_usd_per_million=None):
        if Capability.TOOL_USE in capabilities:
            raise ValueError("this adapter does not execute tools")
        if not set(capabilities) <= {Capability.FAST_LANGUAGE, Capability.CODING, Capability.DEEP_REASONING}:
            raise ValueError("text adapter cannot advertise unsupported modalities")
        self.spec = ProviderSpec("openai", model, frozenset(capabilities), tier=tier,
                                input_usd_per_million=input_usd_per_million,
                                output_usd_per_million=output_usd_per_million)
        self._key = api_key or ""
        self.configured = bool(enabled and self._key)
        self._transport = transport or JsonTransport("api.openai.com")

    def input_bound(self, request):
        if "prepared_messages" in request.legacy_kwargs:
            messages = self._messages(request)
            return max(request.input_bound(), len(json.dumps(messages, ensure_ascii=False).encode("utf-8"))
                       + len(request.context.encode("utf-8")) + 1024)
        return request.input_bound()

    @staticmethod
    def _messages(request):
        messages = request.legacy_kwargs.get("prepared_messages")
        if (type(messages) is not list or not messages or len(messages) > 256
                or any(type(message) is not dict or set(message) != {"role", "content"}
                       or type(message["role"]) is not str or message["role"] not in {"user", "assistant"}
                       or type(message["content"]) is not str for message in messages)):
            raise ProtocolError("prepared messages require supported text-only roles/content")
        return messages

    def output_bound(self, request):
        return request.max_output_tokens

    def stream(self, request, cancel_token=None):
        if not self.configured:
            raise Unavailable("OpenAI adapter disabled or unconfigured")
        check_policy(self.spec, request)
        check_cancel(cancel_token, request.deadline_mono)
        body = {"model": self.spec.model, "input": request.prompt, "instructions": request.context,
                "store": False, "stream": False, "tools": [], "max_output_tokens": request.max_output_tokens}
        if "prepared_messages" in request.legacy_kwargs:
            body["input"] = self._messages(request)
        data = self._transport.post("/v1/responses", body, self._key,
                                    cancel_token=cancel_token, deadline=request.deadline_mono)
        check_cancel(cancel_token, request.deadline_mono)
        if data.get("status") != "completed" or not isinstance(data.get("output"), list):
            raise ProtocolError("OpenAI response was not completed")
        parts = []
        for item in data["output"]:
            if not isinstance(item, dict):
                raise ProtocolError("invalid output item")
            if item.get("type") == "reasoning":
                continue
            if item.get("type") != "message":
                raise ProtocolError("unexpected non-message output from no-tools adapter")
            if not isinstance(item.get("content"), list):
                raise ProtocolError("invalid message content")
            for part in item["content"]:
                if not isinstance(part, dict):
                    raise ProtocolError("invalid content item")
                if part.get("type") == "refusal":
                    raise ProtocolError("provider refused request")
                if part.get("type") == "output_text" and isinstance(part.get("text"), str):
                    parts.append(part["text"])
        usage = data.get("usage") or {}
        if not isinstance(usage, dict):
            raise ProtocolError("invalid usage object")
        counts = Usage(usage.get("input_tokens"), usage.get("output_tokens"))
        text = "".join(parts)
        if not text:
            raise ProtocolError("provider returned no text")
        model = data.get("model", self.spec.model)
        if not isinstance(model, str) or not model:
            raise ProtocolError("invalid resolved model")
        check_cancel(cancel_token, request.deadline_mono)
        yield ProviderEvent("usage", usage=counts, usage_final=True, provider=self.spec.provider_id, model=model)
        check_cancel(cancel_token, request.deadline_mono)
        yield ProviderEvent("delta", text=text, provider=self.spec.provider_id, model=model)
        check_cancel(cancel_token, request.deadline_mono)
        yield ProviderEvent("done", full_text=text, provider=self.spec.provider_id, model=model)
