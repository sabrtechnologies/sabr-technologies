"""Capability/health/budget/latency routing, opt-in at the scheduler boundary.

No failover after observable output, any tool event, or an unsafe legacy call.
This prevents duplicate tool effects or repeated partial replies.
"""
import threading
import time
import logging
from .base import Capability, Cancelled, ProviderError, Unavailable, UnsupportedPolicy, check_cancel, check_policy
from .budget import BudgetExceeded, price_micro_usd
from .health import HealthRegistry

_log = logging.getLogger(__name__)


class ProviderRouter:
    def __init__(self, adapters, budget, *, health=None):
        self.adapters = tuple(adapters)
        ids = [a.spec.provider_id for a in self.adapters]
        if len(set(ids)) != len(ids):
            raise ValueError("provider ids must be unique per serialized resource")
        self.budget, self.health = budget, health or HealthRegistry()
        self._locks = {name: threading.Lock() for name in ids}

    def candidates(self, request):
        candidates = []
        states = self.health.snapshot()
        deep = request.deep or Capability.DEEP_REASONING in request.capabilities
        for adapter in self.adapters:
            spec = adapter.spec
            if not adapter.configured or not self.health.available(spec.provider_id):
                continue
            try:
                check_policy(spec, request)
            except UnsupportedPolicy:
                continue
            preferred = (spec.tier == 2 if deep else spec.local if request.background else spec.tier == 1)
            latency = states.get(spec.provider_id, {}).get("latency_ms", 0)
            candidates.append(((not preferred, latency, spec.provider_id), adapter))
        return [adapter for _, adapter in sorted(candidates, key=lambda item: item[0])]

    def select(self, request):
        """Inspect selection only. stream() atomically reserves the actual budget."""
        selected = self.candidates(request)
        if not selected:
            raise Unavailable("no configured healthy provider meets request policy")
        return selected[0]

    def stream(self, request, cancel_token=None):
        check_cancel(cancel_token, request.deadline_mono)
        for adapter in self.candidates(request):
            spec, lock = adapter.spec, self._locks[adapter.spec.provider_id]
            while not lock.acquire(timeout=.05):
                check_cancel(cancel_token, request.deadline_mono)
            ticket, stream, usage, emitted, dispatched, completed = None, None, None, False, False, False
            cancellation = None
            accounting_complete = False
            usage_final = False
            started = time.monotonic()
            try:
                check_cancel(cancel_token, request.deadline_mono)
                inputs = adapter.input_bound(request)
                outputs = adapter.output_bound(request)
                if any(type(n) is not int or n < 0 for n in (inputs, outputs)):
                    raise BudgetExceeded("full-call token bounds are not configured")
                cost = price_micro_usd(spec, inputs, outputs)
                ticket = self.budget.reserve(request.capabilities, inputs + outputs, cost)
                check_cancel(cancel_token, request.deadline_mono)
                dispatched = True
                stream = iter(adapter.stream(request, cancel_token=cancel_token))
                for event in stream:
                    try:
                        check_cancel(cancel_token, request.deadline_mono)
                    except Cancelled as exc:
                        cancellation = exc
                    if event.usage is not None:
                        usage = event.usage
                        usage_final = event.usage_final is True
                    # Cancellation is a drain state once a producer has been
                    # invoked. Status/text between committed results must not
                    # close that producer or release the serialized slot.
                    if cancellation is not None and event.type != "tool_result":
                        continue
                    if not request.allow_tools and event.type in ("tool_use", "tool_confirm_request", "tool_result"):
                        emitted = True  # A broken adapter must never trigger replay.
                        raise UnsupportedPolicy("no-tools adapter emitted a tool event")
                    if event.type == "error":
                        raise ProviderError("provider reported an error")
                    if event.type not in ("model", "usage"):
                        emitted = True
                    if event.type == "done":
                        completed = True
                    yield event
                if cancellation is not None:
                    raise cancellation
                check_cancel(cancel_token, request.deadline_mono)
                if not completed:
                    raise ProviderError("provider ended without completion")
                accounting_complete = True
                self.health.success(spec.provider_id, (time.monotonic() - started) * 1000)
                return
            except Cancelled:
                raise
            except BudgetExceeded as exc:
                if cancellation is not None:
                    raise cancellation from None
                check_cancel(cancel_token, request.deadline_mono)
                if dispatched:
                    # A nested producer's budget failure is not admission
                    # failure: it may already have performed external actions.
                    self.health.failure(spec.provider_id)
                    _log.warning("provider failed after admission", extra={"trace_id": request.trace_id,
                                 "subsystem": "provider_router", "exception_type": type(exc).__name__,
                                 "recovery_action": "stop", "provider_id": spec.provider_id})
                    raise
                _log.info("provider admission denied", extra={"trace_id": request.trace_id,
                          "subsystem": "provider_router", "exception_type": type(exc).__name__,
                          "recovery_action": "try_next_candidate", "provider_id": spec.provider_id})
                continue
            except (ProviderError, OSError) as exc:
                if cancellation is not None:
                    raise cancellation from None
                check_cancel(cancel_token, request.deadline_mono)
                self.health.failure(spec.provider_id)
                _log.warning("provider request failed", extra={"trace_id": request.trace_id,
                             "subsystem": "provider_router", "exception_type": type(exc).__name__,
                             "recovery_action": "stop" if emitted or not spec.retry_safe else "try_next_candidate",
                             "provider_id": spec.provider_id})
                if emitted or not spec.retry_safe:
                    raise
                # Retain the conservative reservation for failed dispatched
                # calls; a connection failure is not proof of zero billing.
            finally:
                try:
                    if stream is not None:
                        close = getattr(stream, "close", None)
                        if close is not None:
                            close()
                finally:
                    try:
                        if ticket is not None:
                            if not dispatched:
                                self.budget.settle(ticket, tokens=0, micro_usd=0)
                            elif accounting_complete and usage_final and usage is not None:
                                self.budget.settle(ticket, tokens=usage.input_tokens + usage.output_tokens,
                                                   micro_usd=price_micro_usd(spec, usage.input_tokens, usage.output_tokens))
                            else:
                                self.budget.settle(ticket)
                    finally:
                        lock.release()
        raise Unavailable("no provider completed within configured capabilities, health and budget")
