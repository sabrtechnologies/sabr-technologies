"""Wrap local_llm through injected shims, with truthful optional tool support."""
from .base import Capability, ProviderSpec
from .legacy_adapter import LegacyAdapter


class OllamaAdapter(LegacyAdapter):
    def __init__(self, plain_stream, *, model, input_token_bound, output_token_bound=None, tool_stream=None, configured=True):
        caps = {Capability.FAST_LANGUAGE}
        if tool_stream is not None:
            caps.add(Capability.TOOL_USE)
        spec = ProviderSpec("ollama", model, frozenset(caps), local=True, tier=0,
                            retry_safe=False, input_usd_per_million=0, output_usd_per_million=0)
        super().__init__(spec, tool_stream or plain_stream, input_token_bound=input_token_bound,
                         output_token_bound=output_token_bound, no_tools_fn=plain_stream, configured=configured)
