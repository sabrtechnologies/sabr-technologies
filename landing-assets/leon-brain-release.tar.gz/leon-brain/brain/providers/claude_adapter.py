"""Wrap the existing Claude façade via an explicit injected shim.

No-tools is unavailable until integration supplies a verified no-tools shim;
legacy force_cli does not guarantee it. Existing tool/session policy is kept.
"""
from .base import Capability, ProviderSpec
from .legacy_adapter import LegacyAdapter


class ClaudeAdapter(LegacyAdapter):
    def __init__(self, stream_fn, *, model, input_token_bound, output_token_bound=None, no_tools_fn=None,
                 input_usd_per_million=None, output_usd_per_million=None, tier=1, configured=True):
        spec = ProviderSpec("claude", model, frozenset({Capability.FAST_LANGUAGE, Capability.CODING,
                            Capability.DEEP_REASONING, Capability.TOOL_USE}), tier=tier,
                            no_tools_enforced=no_tools_fn is not None, retry_safe=False,
                            input_usd_per_million=input_usd_per_million,
                            output_usd_per_million=output_usd_per_million)
        super().__init__(spec, stream_fn, input_token_bound=input_token_bound,
                         output_token_bound=output_token_bound, no_tools_fn=no_tools_fn, configured=configured)
