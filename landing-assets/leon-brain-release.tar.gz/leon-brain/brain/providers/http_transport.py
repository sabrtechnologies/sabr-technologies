"""Bounded JSON envelope over the integrator's shared cancellable HTTP owner.

No independent socket lifecycle. Importing does not load the HTTP owner or
make requests. Tests inject an opener; production requires Phase 3's helper.
"""
import json
import time
import urllib.request
from .base import ProviderError, ProtocolError, Unavailable, check_cancel


class JsonTransport:
    def __init__(self, host, *, timeout_s=30, max_response_bytes=2 * 1024 * 1024, opener=None):
        if host not in ("api.openai.com", "api.aimlapi.com"):
            raise ValueError("unsupported provider host")
        if not 0 < timeout_s <= 120 or not 0 < max_response_bytes <= 8 * 1024 * 1024:
            raise ValueError("invalid transport bounds")
        self.host, self.timeout_s, self.max_response_bytes = host, timeout_s, max_response_bytes
        self._opener = opener

    def post(self, path, body, api_key, *, cancel_token=None, deadline=None):
        check_cancel(cancel_token, deadline)
        opener = self._opener
        if opener is None:
            try:
                from brain.inference_http import open_cancellable
            except ImportError:
                raise Unavailable("Phase 3 cancellable HTTP transport is not installed") from None
            opener = open_cancellable
        if path not in ("/v1/responses", "/v1/decisions"):
            raise ValueError("unsupported provider endpoint")
        timeout = self.timeout_s if deadline is None else min(self.timeout_s, deadline-time.monotonic())
        request = urllib.request.Request("https://" + self.host + path,
                    data=json.dumps(body, allow_nan=False).encode("utf-8"), method="POST",
                    headers={"Authorization": "Bearer " + api_key, "Content-Type": "application/json",
                             "User-Agent": "Leon-ProviderAdapter/1"})
        response, unhook = None, None
        try:
            response, unhook = opener(request, timeout=max(.01, timeout), cancel_token=cancel_token)
            check_cancel(cancel_token, deadline)
            if response.status != 200:
                raise ProviderError("provider HTTP status " + str(response.status))
            raw = response.read(self.max_response_bytes + 1)
            check_cancel(cancel_token, deadline)
            if len(raw) > self.max_response_bytes:
                raise ProtocolError("provider response exceeds size limit")
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise ProtocolError("provider response must be an object")
            return value
        except (OSError, ValueError) as exc:
            check_cancel(cancel_token, deadline)
            raise ProviderError("provider transport failure: " + type(exc).__name__) from None
        finally:
            try:
                if unhook is not None:
                    unhook()
            finally:
                if response is not None:
                    response.close()
