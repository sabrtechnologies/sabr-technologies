"""Dependency-injected wrappers; never import/build a brain or replace sessions."""
import inspect
from .base import Cancelled, ProviderEvent, Unavailable, UnsupportedPolicy, check_cancel, check_policy


class LegacyAdapter:
    def __init__(self, spec, stream_fn, *, input_token_bound, output_token_bound=None, no_tools_fn=None, configured=True):
        self.spec, self._stream_fn, self._no_tools_fn = spec, stream_fn, no_tools_fn
        if type(input_token_bound) is not int or input_token_bound <= 0:
            raise ValueError("opaque legacy prompts require a configured full input-token bound")
        self._input_token_bound = input_token_bound
        if output_token_bound is not None and (type(output_token_bound) is not int or output_token_bound <= 0):
            raise ValueError("full-call output-token bound must be a positive integer")
        self._output_token_bound = output_token_bound
        self.configured = bool(configured and callable(stream_fn))

    def input_bound(self, request):
        return max(request.input_bound(), self._input_token_bound)

    def output_bound(self, request):
        # Legacy providers may have multiple model rounds and hidden reasoning.
        # A requested text length is not an enforced full-call billing bound.
        return self._output_token_bound

    def stream(self, request, cancel_token=None):
        if not self.configured:
            raise Unavailable("legacy provider not configured")
        check_policy(self.spec, request)
        check_cancel(cancel_token, request.deadline_mono)
        fn = self._stream_fn if request.allow_tools else self._no_tools_fn
        if fn is None:
            raise UnsupportedPolicy("a verified no-tools entry point is required")
        kwargs = dict(request.legacy_kwargs)
        kwargs["persist_history"] = request.persist_history
        kwargs["cancel_token"] = cancel_token
        # The injected shim owns translating rendered context and preserving
        # existing per-channel sessions; no provider object owns identity.
        signature = inspect.signature(fn)
        signature.bind(request.prompt, request.context, **kwargs)
        events = iter(fn(request.prompt, request.context, **kwargs))
        cancellation = None
        try:
            for event in events:
                kind = getattr(event, "type", None)
                try:
                    check_cancel(cancel_token, request.deadline_mono)
                except Cancelled as exc:
                    cancellation = exc
                if cancellation is not None and kind != "tool_result":
                    continue
                if not request.allow_tools and kind in ("tool_use", "tool_confirm_request", "tool_result"):
                    raise UnsupportedPolicy("no-tools entry point emitted a tool event")
                yield ProviderEvent(kind, getattr(event, "text", ""), getattr(event, "full_text", ""),
                                    provider=self.spec.provider_id, model=self.spec.model, raw=event)
            if cancellation is not None:
                raise cancellation
            check_cancel(cancel_token, request.deadline_mono)
        except (OSError, Cancelled):
            if cancellation is not None:
                raise cancellation from None
            check_cancel(cancel_token, request.deadline_mono)
            raise
        finally:
            close = getattr(events, "close", None)
            if close is not None:
                close()
