"""
Evidence ledger: what actually happened in the last half hour, for the claim
gate (brain/claim_guard.py) to check Leon's words against.

Why (Dean, 2026-10-05 15:40: "with the right structure and architecture you
can never say something false ever again"): the per-turn guard only saw the
tools of the turn it was gating. Leon said "restarting the bridge now" with
no tool call, "it's live" from an earlier turn's memory, and "the job is
still running" from recap text. The gate needs a record that outlives one
turn, and live readings, so a claim can be held to them.

Two kinds of entries, both in memory only (a rolling ~30 min window; nothing
is written to brain_state):
  * tool  — every tool call any responder turn made: name, args summary,
            ok/error, a result snippet, the channel it ran on. Recorded from
            BrainAPIResponder.respond_streaming, so Dean turns, idle action-cue
            turns and job-notice turns all land here.
  * reading — a live observation: coding job states (the action-cue job poll
            and the job runner's own events), and on demand the brain repo's
            git HEAD / dirty count and whether the running process started
            after the newest source file changed (is the new code loaded).

Readings that cost anything (git, file mtimes) are taken lazily, only when a
claim needs them, and cached, so the gate stays under its latency budget.
Everything here is fail-open: a fault never blocks or changes a reply.
"""
from __future__ import annotations

import os
import re
import subprocess
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, Iterable, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

WINDOW_S = 30 * 60          # how long an entry stays evidence
MAX_ENTRIES = 600
GIT_CACHE_S = 30.0
CODE_CACHE_S = 60.0

_ERRORISH = re.compile(r"\b(?:error|failed|failure|unauthori[sz]ed|forbidden|denied|not found|"
                       r"traceback|exception|refused|timed out|timeout|401|403|404|500|502|503)\b"
                       r"|\"ok\"\s*:\s*false", re.I)


def _process_start() -> float:
    """Wall-clock start of this process (Linux /proc; import time elsewhere)."""
    try:
        with open("/proc/self/stat", encoding="utf-8") as fh:
            ticks = float(fh.read().rsplit(")", 1)[1].split()[19])
        with open("/proc/uptime", encoding="utf-8") as fh:
            uptime = float(fh.read().split()[0])
        hz = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
        return time.time() - (uptime - ticks / hz)
    except Exception:
        return time.time()


PROCESS_START = _process_start()


@dataclass
class Entry:
    ts: float
    kind: str                       # tool | reading
    name: str                       # tool name, or reading key ("job", "git", "code")
    summary: str = ""               # args summary / reading value in words
    ok: bool = True
    result: str = ""                # result snippet
    source: str = ""                # channel / producer
    tool_id: str = ""
    data: Dict[str, Any] = field(default_factory=dict)

    def text(self) -> str:
        return f"{self.name} {self.summary} {self.result}"

    def brief(self, now: Optional[float] = None) -> Dict[str, Any]:
        now = time.time() if now is None else now
        return {"age_s": round(now - self.ts, 1), "kind": self.kind, "name": self.name,
                "summary": self.summary[:160], "ok": self.ok, "result": self.result[:160],
                "source": self.source}


_lock = threading.Lock()
_entries: Deque[Entry] = deque(maxlen=MAX_ENTRIES)
_cache: Dict[str, Any] = {}


def _prune(now: float) -> None:
    while _entries and now - _entries[0].ts > WINDOW_S:
        _entries.popleft()


def _ok_from_result(result: Optional[str]) -> bool:
    from brain.tool_evidence import result_ok
    return result_ok(result)


def record_tool(name: str, summary: str = "", *, ok: Optional[bool] = None,
                result: Optional[str] = None, source: str = "", tool_id: str = "",
                ts: Optional[float] = None) -> Entry:
    now = time.time() if ts is None else ts
    e = Entry(ts=now, kind="tool", name=(name or "tool")[:80],
              summary=" ".join((summary or "").split())[:400],
              ok=_ok_from_result(result) if ok is None else bool(ok),
              result=" ".join((result or "").split())[:400], source=source, tool_id=tool_id)
    with _lock:
        _prune(now)
        _entries.append(e)
    return e


def _attach_result(tool_id: str, result: str, name: str = "", source: str = "") -> None:
    now = time.time()
    snippet = " ".join((result or "").split())[:400]
    with _lock:
        for e in reversed(_entries):
            if e.kind != "tool":
                continue
            if (tool_id and e.tool_id == tool_id) or (not tool_id and not e.result
                                                      and (not name or e.name == name)):
                e.result = snippet
                e.ok = _ok_from_result(result)
                e.ts = now        # evidence time is when the result came back
                return
    record_tool(name or "tool", "", result=result, source=source, tool_id=tool_id)


def record_reading(name: str, summary: str, *, ok: bool = True, source: str = "",
                   data: Optional[Dict[str, Any]] = None, ts: Optional[float] = None) -> Entry:
    now = time.time() if ts is None else ts
    e = Entry(ts=now, kind="reading", name=name, summary=" ".join((summary or "").split())[:400],
              ok=ok, source=source, data=dict(data or {}))
    with _lock:
        _prune(now)
        _entries.append(e)
    return e


def recent(window_s: float = WINDOW_S, *, kind: Optional[str] = None,
           before: Optional[float] = None, now: Optional[float] = None) -> List[Entry]:
    now = time.time() if now is None else now
    with _lock:
        _prune(now)
        out = [e for e in _entries if now - e.ts <= window_s
               and (kind is None or e.kind == kind) and (before is None or e.ts < before)]
    return out


def clear() -> None:
    with _lock:
        _entries.clear()
        _cache.clear()


class StreamRecorder:
    """Watches a responder's event stream and records its tool calls."""

    def __init__(self, source: str = ""):
        self.source = source or ""

    def observe(self, ev: Any) -> None:
        try:
            et = getattr(ev, "type", None)
            if et == "tool_use":
                record_tool(getattr(ev, "text", "") or "tool",
                            getattr(ev, "full_text", "") or "", ok=True,
                            source=self.source, tool_id=getattr(ev, "tool_id", "") or "")
            elif et == "tool_result":
                _attach_result(getattr(ev, "tool_id", "") or "",
                               getattr(ev, "full_text", "") or getattr(ev, "text", "") or "",
                               name=getattr(ev, "text", "") or "", source=self.source)
        except Exception:
            pass


# ── job readings ─────────────────────────────────────────────────────────

def note_jobs(jobs: Iterable[Dict[str, Any]], source: str = "job_poll") -> None:
    """The coding job list as just read (brain/action_cues.py's 60 s poll)."""
    rows = []
    for j in jobs or ():
        try:
            jid = str(j.get("job_id") or j.get("id") or "")
            st = str(j.get("state") or j.get("status") or "")
            if jid and st:
                rows.append({"job_id": jid, "state": st,
                             "task": " ".join(str(j.get("task") or "").split())[:120]})
        except Exception:
            continue
    if not rows:
        return
    counts: Dict[str, int] = {}
    for r in rows:
        counts[r["state"]] = counts.get(r["state"], 0) + 1
    summary = ", ".join(f"{n} {s}" for s, n in sorted(counts.items()))
    record_reading("jobs", f"coding jobs: {summary}", source=source, data={"jobs": rows[:40]})


def note_job_event(event: Dict[str, Any], source: str = "job_runner") -> None:
    """One job's end, reported by the job runner (server/job_events.py)."""
    try:
        jid = str(event.get("job_id") or "")
        st = str(event.get("state") or "")
        if not jid or not st:
            return
        summ = " ".join(str(event.get("summary") or event.get("error") or "").split())
        record_reading("job", f"job {jid} ended {st}: {summ[:300]}", source=source,
                       data={"job_id": jid, "state": st, "summary": summ[:1200]})
    except Exception:
        pass


def job_states(window_s: float = 10 * 60) -> List[Dict[str, Any]]:
    """Freshest known state per job id from readings in the window."""
    best: Dict[str, Dict[str, Any]] = {}
    for e in recent(window_s, kind="reading"):
        if e.name == "jobs":
            for r in e.data.get("jobs") or []:
                best[r["job_id"]] = {**r, "ts": e.ts}
        elif e.name == "job":
            jid = e.data.get("job_id")
            if jid:
                best[jid] = {"job_id": jid, "state": e.data.get("state"),
                             "summary": e.data.get("summary", ""), "ts": e.ts}
    return list(best.values())


# ── lazy live readings (cached) ──────────────────────────────────────────

def _cached(key: str, ttl: float, fn):
    now = time.time()
    hit = _cache.get(key)
    if hit and now - hit[0] < ttl:
        return hit[1]
    try:
        val = fn()
    except Exception as exc:
        val = {"error": type(exc).__name__}
    _cache[key] = (now, val)
    return val


def git_state(root: str = _ROOT) -> Dict[str, Any]:
    """HEAD, branch and dirty-file count of the brain repo (cached 30 s)."""
    def read():
        def git(*args):
            return subprocess.run(["git", "-C", root, *args], capture_output=True, text=True,
                                  timeout=1.5).stdout.strip()
        head = git("rev-parse", "--short", "HEAD")
        branch = git("rev-parse", "--abbrev-ref", "HEAD")
        dirty = [l for l in git("status", "--porcelain", "--untracked-files=no").splitlines() if l]
        return {"head": head, "branch": branch, "dirty": len(dirty)}
    val = _cached("git:" + root, GIT_CACHE_S, read)
    return val


def code_loaded(root: str = _ROOT) -> Dict[str, Any]:
    """Did this process start after the newest brain/ or server/ .py changed?"""
    def read():
        newest, newest_path = 0.0, ""
        for sub in ("brain", "server"):
            base = os.path.join(root, sub)
            for dirpath, dirnames, filenames in os.walk(base):
                dirnames[:] = [d for d in dirnames if not d.startswith((".", "__pycache__"))]
                for fn in filenames:
                    if fn.endswith(".py"):
                        p = os.path.join(dirpath, fn)
                        try:
                            m = os.path.getmtime(p)
                        except OSError:
                            continue
                        if m > newest:
                            newest, newest_path = m, p
        return {"process_start": PROCESS_START, "newest_source": newest,
                "newest_path": os.path.relpath(newest_path, root) if newest_path else "",
                "loaded": PROCESS_START >= newest}
    return _cached("code:" + root, CODE_CACHE_S, read)


def drive_readings() -> Dict[str, float]:
    """Leon's persistent drive accumulators as they are right now (0..1), from
    the running server; {} outside it. In-memory attribute reads, no I/O."""
    out: Dict[str, float] = {}
    try:
        import sys
        st = sys.modules.get("server.state")
        ps = getattr(st, "persistent_state", None) if st is not None else None
        if ps is None:
            return out
        for name in ("loneliness", "restlessness"):
            v = getattr(ps, f"_accumulated_{name}", None)
            if isinstance(v, (int, float)):
                out[name] = max(0.0, min(1.0, float(v)))
    except Exception:
        pass
    return out


def snapshot(now: Optional[float] = None) -> Dict[str, Any]:
    now = time.time() if now is None else now
    return {"window_s": WINDOW_S, "process_start": PROCESS_START,
            "entries": [e.brief(now) for e in recent(WINDOW_S, now=now)][-60:],
            "jobs": job_states()}
