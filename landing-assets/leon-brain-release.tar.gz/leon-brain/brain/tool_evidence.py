"""Keep tool receipt identity and status ahead of display truncation.

Only receipt control fields are interpreted. Command stdout, previews and
other payload strings are data, never a source of another tool's identity.
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional

_ERRORISH = re.compile(
    r'\b(?:error|failed|failure|unauthori[sz]ed|forbidden|denied|not found|'
    r'traceback|exception|refused|timed out|timeout|401|403|404|500|502|503)\b'
    r'|"ok"\s*:\s*false', re.I)


def _decode(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except (ValueError, TypeError):
            return value
    return value


def _status(value: Any, depth: int = 0) -> Optional[bool]:
    if depth > 8:
        return False
    value = _decode(value)
    if isinstance(value, list):
        states = []
        for block in value:
            if isinstance(block, dict) and block.get('type') == 'text':
                state = _status(block.get('text'), depth + 1)
                if state is not None:
                    states.append(state)
        return all(states) if states else None
    if not isinstance(value, dict):
        return None
    states = []
    if isinstance(value.get('ok'), bool):
        states.append(value['ok'])
    if value.get('isError') is True:
        states.append(False)
    for key in ('rc', 'exit_code', 'returncode'):
        if type(value.get(key)) is int:
            states.append(value[key] == 0)
    if ('ok' in value or 'isError' in value or 'tool' in value) and value.get('error'):
        states.append(False)
    # Unwrap only known receipt/container positions, never stdout or previews.
    for key in ('value', 'result'):
        child = value.get(key)
        if isinstance(child, dict):
            state = _status(child, depth + 1)
            if state is not None:
                states.append(state)
    if isinstance(value.get('content'), list):
        state = _status(value['content'], depth + 1)
        if state is not None:
            states.append(state)
    return all(states) if states else None


def result_ok(result: Any) -> bool:
    state = _status(result)
    decoded = _decode(result)
    # A bare batch/report is not a transport receipt. Its outer ok may only
    # mean reporting finished, not that the actions described inside worked.
    if state is True and isinstance(decoded, dict) and isinstance(decoded.get('results'), list) \
            and not _receipt_name(decoded):
        state = None
    if state is not None:
        return state
    return not _ERRORISH.search(str(result or ''))


def _receipt_name(value: Any, depth: int = 0) -> str:
    if depth > 8:
        return ''
    value = _decode(value)
    if isinstance(value, dict):
        name = value.get('tool')
        if isinstance(name, str) and isinstance(value.get('ok'), bool) and (
                'value' in value or 'source' in value):
            return name[:80]
        if isinstance(value.get('content'), list):
            return _receipt_name(value['content'], depth + 1)
    if isinstance(value, list):
        names = {_receipt_name(block.get('text'), depth + 1)
                 for block in value if isinstance(block, dict) and block.get('type') == 'text'}
        names.discard('')
        if len(names) == 1:
            return names.pop()
    return ''


def normalize_result(content: Any, *, fallback_name: str = 'tool',
                     is_error: bool = False) -> tuple[str, str]:
    """Return bounded, valid JSON with status before potentially huge payloads."""
    name = _receipt_name(content) or fallback_name or 'tool'
    if name.startswith('mcp__leon__'):
        name = name[len('mcp__leon__'):]
    if isinstance(content, list):
        raw = '\n'.join(str(c.get('text') or '') for c in content
                        if isinstance(c, dict) and c.get('type') == 'text')
    else:
        raw = content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)
    preview = ' '.join(raw.split())[:160]
    value = {'ok': not is_error and result_ok(content), 'tool': name[:80], 'preview': preview}
    rendered = json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    while len(rendered) > 280 and value['preview']:
        value['preview'] = value['preview'][:-8]
        rendered = json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    return name, rendered
