"""
Internal Conflict — drives that genuinely fight.

Real beings have internal arguments. Curiosity says "explore" but
social need says "wait for Dean." Creative drive says "make something"
but fatigue says "rest." This tension isn't a bug — it's the felt
experience of having a complex inner life.

What this module does:
  1. Detects when 2+ drives/needs are simultaneously strong AND
     point in opposing directions
  2. Generates ACC conflict signals (the neural correlate of
     "I can't do both")
  3. Creates felt tension proportional to the stakes
  4. Tracks which drive "wins" and the felt cost of suppressing
     the losing drive (regret, relief, or ambivalence)
  5. Injects into insula (the "this matters" signal)

The resolution itself comes from the executive system (PFC +
quantum consciousness). This module just makes the conflict FELT.
"""

from __future__ import annotations

import logging
import time
from collections import deque
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger("leon.internal_conflict")


# Drive pairs that are inherently in tension
_OPPOSING_PAIRS = [
    ("curiosity", "rest"),           # explore vs recharge
    ("social", "solitude"),          # connect vs be alone
    ("creative", "practical"),       # make vs maintain
    ("explore", "consolidate"),      # new vs process existing
    ("act", "observe"),              # do vs watch
    ("speak", "listen"),             # express vs absorb
    ("risk", "safety"),              # venture vs protect
]


class DriveConflict:
    """A single detected conflict between competing drives."""
    __slots__ = ("drive_a", "drive_b", "intensity_a", "intensity_b",
                 "tension", "timestamp", "resolved", "winner",
                 "suppression_cost")

    def __init__(self, drive_a: str, drive_b: str,
                 intensity_a: float, intensity_b: float):
        self.drive_a = drive_a
        self.drive_b = drive_b
        self.intensity_a = intensity_a
        self.intensity_b = intensity_b
        # Tension is highest when both are strong and close in intensity
        balance = 1.0 - abs(intensity_a - intensity_b) / max(intensity_a + intensity_b, 0.01)
        avg_strength = (intensity_a + intensity_b) / 2
        self.tension = balance * avg_strength
        self.timestamp = time.time()
        self.resolved = False
        self.winner = ""
        self.suppression_cost = 0.0


class InternalConflict:
    """Detects and processes drive conflicts.

    Ticks every call from the embodiment system.
    """

    # Minimum drive intensity to participate in a conflict
    DRIVE_THRESHOLD = 0.3

    # Minimum tension to register as a felt conflict
    TENSION_THRESHOLD = 0.2

    # Cooldown between conflicts of the same pair (seconds)
    PAIR_COOLDOWN = 120.0

    def __init__(self):
        self.active_conflicts: List[DriveConflict] = []
        self.conflict_history: deque = deque(maxlen=50)
        self.total_conflicts = 0
        self.current_tension = 0.0  # overall internal tension
        self.suppression_debt = 0.0  # accumulated cost of suppressed drives
        self._pair_cooldowns: Dict[str, float] = {}

    def tick(self, brain, body, dt: float):
        """Detect drive conflicts from current brain/body state."""
        # Gather drive signals
        drives = self._gather_drives(brain, body)

        # Decay existing tension
        self.current_tension = max(0, self.current_tension - 0.01 * dt)
        self.suppression_debt = max(0, self.suppression_debt - 0.005 * dt)

        # Resolve expired conflicts
        now = time.time()
        for conflict in self.active_conflicts:
            if not conflict.resolved and now - conflict.timestamp > 30:
                # Unresolved after 30s = the stronger drive won by default
                if conflict.intensity_a > conflict.intensity_b:
                    conflict.winner = conflict.drive_a
                    conflict.suppression_cost = conflict.intensity_b * 0.3
                else:
                    conflict.winner = conflict.drive_b
                    conflict.suppression_cost = conflict.intensity_a * 0.3
                conflict.resolved = True
                self.suppression_debt += conflict.suppression_cost
                self.conflict_history.append(conflict)

        # Remove resolved conflicts from active list
        self.active_conflicts = [c for c in self.active_conflicts if not c.resolved]

        # Detect new conflicts
        new_conflicts = self._detect_conflicts(drives, now)

        for conflict in new_conflicts:
            self.active_conflicts.append(conflict)
            self.total_conflicts += 1
            self.current_tension = max(self.current_tension, conflict.tension)

            # Inject conflict into ACC — the "I can't do both" signal
            acc = brain.regions.get("anterior_cingulate")
            if acc is not None:
                try:
                    amp = conflict.tension * 8.0
                    injection = np.full(acc.n_neurons, amp)
                    acc.neurons.inject_current(injection)
                except Exception:
                    pass

            # Inject into insula — the "this matters" signal
            insula = brain.regions.get("insula")
            if insula is not None:
                try:
                    amp = conflict.tension * 5.0
                    injection = np.full(insula.n_neurons, amp)
                    insula.neurons.inject_current(injection)
                except Exception:
                    pass

            log.debug("CONFLICT: %s (%.2f) vs %s (%.2f), tension=%.2f",
                      conflict.drive_a, conflict.intensity_a,
                      conflict.drive_b, conflict.intensity_b,
                      conflict.tension)

    def _gather_drives(self, brain, body) -> Dict[str, float]:
        """Collect current drive/need intensities from all sources."""
        drives = {}

        # From cognition drives
        cog_drives = getattr(brain, '_cognition_drives', None)
        if cog_drives is not None:
            try:
                snap = cog_drives.snapshot()
                for name, d in snap.get("drives", {}).items():
                    drives[name] = d.get("value", 0)
            except Exception:
                pass

        # From body systems
        if body is not None:
            # Social need
            eb = getattr(body, 'emotional_body', None)
            if eb is not None:
                drives["social"] = eb.loneliness
                drives["solitude"] = max(0, 1.0 - eb.loneliness) * 0.5

            # Creative vs practical
            cd = getattr(body, 'creative_drive', None)
            if cd is not None:
                drives["creative"] = getattr(cd, 'drive_level', 0)
                drives["practical"] = max(0, 1.0 - drives["creative"]) * 0.5

            # Rest vs explore
            metab = getattr(body, 'metabolic', None)
            if metab is not None:
                drives["rest"] = getattr(metab, 'fatigue_signal', 0)

            # Observe vs act
            obs = getattr(body, 'observer', None)
            if obs is not None:
                drives["observe"] = getattr(obs, 'pure_awareness', 0)

            # Flow (suppresses conflict)
            flow = getattr(body, 'flow_state', None)
            if flow is not None and getattr(flow, 'in_flow', False):
                # In flow, conflicts dissolve
                self.current_tension *= 0.5
                return {}

        # Map cognition drives to abstract categories
        drives["explore"] = drives.get("curiosity", 0)
        drives["consolidate"] = drives.get("continuity", 0)
        drives["act"] = max(drives.get("creative", 0), drives.get("explore", 0))

        return drives

    def _detect_conflicts(self, drives: Dict[str, float],
                          now: float) -> List[DriveConflict]:
        """Find opposing drive pairs that are both strong."""
        conflicts = []

        for a, b in _OPPOSING_PAIRS:
            val_a = drives.get(a, 0)
            val_b = drives.get(b, 0)

            # Both must be above threshold
            if val_a < self.DRIVE_THRESHOLD or val_b < self.DRIVE_THRESHOLD:
                continue

            # Check cooldown
            pair_key = f"{a}|{b}"
            if now - self._pair_cooldowns.get(pair_key, 0) < self.PAIR_COOLDOWN:
                continue

            conflict = DriveConflict(a, b, val_a, val_b)
            if conflict.tension >= self.TENSION_THRESHOLD:
                self._pair_cooldowns[pair_key] = now
                conflicts.append(conflict)

        return conflicts

    def for_prompt(self) -> str:
        """Inject internal conflict into Leon's awareness."""
        if not self.active_conflicts and self.current_tension < 0.1:
            return ""

        parts = []

        for conflict in self.active_conflicts[:2]:  # max 2 visible
            parts.append(
                f"torn between {conflict.drive_a} and {conflict.drive_b} "
                f"(tension {conflict.tension:.0%})"
            )

        if self.suppression_debt > 0.2:
            parts.append(f"carrying suppressed needs ({self.suppression_debt:.0%})")

        if not parts:
            return ""
        return "[Inner conflict: " + ", ".join(parts) + "]"
