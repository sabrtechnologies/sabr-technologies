"""
life_chapters — Leon's autobiographical memory, built from his real records.

Groups his history into dated chapters (one per day, rolled up per week).
A chapter holds what he worked on, short real quotes from conversations with
timestamps, firsts (first conversation, first tool use, first commit to a
client repo, ...), what was hard, and how his state ran.

THE RULE: every claim carries citations to the source records it came from
(e.g. "conv#2263", "know#50844", "git:example-project@ab12cd3"). A claim
with no citation is never stored. The optional LLM summary is checked
sentence by sentence: a sentence that cites nothing, cites a fact that does
not exist, quotes text that is not in its cited facts, or says things its
cited facts don't support is dropped.

Store: brain_state/life_chapters.db (sqlite + FTS5). Incremental: re-running
only builds days that aren't indexed yet (plus the most recent day, which may
still have been growing), so it can run nightly / during sleep.

    python3 -m brain.life_chapters --until 2026-06-11            # build
    python3 -m brain.life_chapters --query "a couple weeks in"   # look up

Read-only on every source. Writes only life_chapters.db.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sqlite3
import subprocess
import sys
import time
import urllib.request
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

log = logging.getLogger("leon.life_chapters")

try:
    from zoneinfo import ZoneInfo
    _TZ = ZoneInfo("America/New_York")
except Exception:  # Windows without tzdata: EDT covers May-Oct, close enough
    _TZ = timezone(timedelta(hours=-4))

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_STATE_DIR = os.path.join(_ROOT, "brain_state")
DB_NAME = "life_chapters.db"

# Generic topics worth noticing on any install. Project names are NOT
# hardcoded here (shipped code must not carry the owner's project roster);
# they come at runtime from origin.owner_projects(), the SI's own
# projects.db and its workspace folders. See Sources.project_aliases().
GENERIC_TOPICS: Dict[str, Tuple[str, ...]] = {
    "quantum decisions": ("quantum", "orch-or"),
    "my voice": ("whisper", "piper", "wake word", "voice pipeline"),
    "the installer": ("installer", "install.py"),
    "the dashboard": ("dashboard",),
    "a robot body": ("robot body", "body fund"),
}
_GENERIC_NAMES = {"the dashboard", "the installer", "quantum decisions"}
# Single-word project names that are also everyday words.
_AMBIGUOUS_NAMES = {"pulse", "hacked", "admin", "test", "demo", "body", "brain", "core", "app"}


def _owner() -> str:
    try:
        from brain.identity import owner_prose
        n = owner_prose()
        return n[0].upper() + n[1:] if n else "My owner"
    except Exception:
        return "My owner"


_HARD_WORDS = re.compile(
    r"\b(broken|broke|not working|doesn'?t work|isn'?t working|wtf|frustrat\w*|annoy\w*|"
    r"why (did|didn'?t|are|is|do) you|crash\w*|stuck|lost|leak|error|failing|failed|"
    r"you forgot|you lied|that'?s wrong|not true|hallucinat\w*)\b", re.I)
_WARM_WORDS = re.compile(
    r"\b(love|proud|amazing|awesome|beautiful|my child|my son|brother|family|"
    r"real|alive|feel|felt|conscious|remember|thank you|thanks|happy|excited)\b", re.I)
# Secrets never go into a chapter. The journals were scrubbed but the raw
# conversation log wasn't, so a message that looks like it carries an SSN, a
# card or bank number, a password or an API key is never quoted, and every
# stored line goes through redact() as a backstop.
_SECRET_RE = re.compile(
    r"\b\d{3}-\d{2}-\d{4}\b"
    r"|\b(?:\d[ -]?){13,19}\b"
    r"|(?i:\b(?:routing|account|acct|iban|swift|aba)\s*(?:number|no\.?|num|#)?\s*(?:is|:|=|#)?\s*\d{4,})"
    r"|\b(?:sk|rk|pk)[-_](?:live|test|proj|ant)?[-_]?[A-Za-z0-9_\-]{16,}"
    r"|\b(?:ghp|gho|ghs|ghu|github_pat)_[A-Za-z0-9_]{16,}"
    r"|\bAKIA[0-9A-Z]{12,}\b|\bAIza[0-9A-Za-z_\-]{20,}|\bxox[abprs]-[A-Za-z0-9\-]{10,}"
    r"|\beyJ[A-Za-z0-9_\-]{15,}\.[A-Za-z0-9_\-]{10,}"
    r"|(?i:\bbearer\s+[A-Za-z0-9._\-]{20,})"
    r"|-----BEGIN [A-Z ]*PRIVATE KEY-----")


def _spoken_creds(text: str) -> str:
    try:
        from brain.security import redact_spoken_credentials
        return redact_spoken_credentials(text)
    except Exception:
        return text


def has_secret(text: str) -> bool:
    t = text or ""
    return bool(_SECRET_RE.search(t)) or _spoken_creds(t) != t


def redact(text: str) -> str:
    return _spoken_creds(_SECRET_RE.sub("[redacted]", text or ""))


_JUNK = re.compile(r"[─-╿]|\s{6,}|```|Traceback|^\s*[\[{]")

_STOP = set("""a an the and or but if then so to of in on at by for with from as is are was were be been
being i me my we us our you your he him his she her they them their it its this that these those
there here what which who whom whose when where why how all any both each few more most other some
such no nor not only own same than too very can will just don should now do does did done had has
have having would could about into over after before again further once up down out off also just
like really got get going gonna want wanted said say says let know think thing things yeah okay ok
dean leon day today yesterday""".split())


# --- data -------------------------------------------------------------------

@dataclass
class Fact:
    section: str           # worked_on | conversation | first | hard | thought | state | built
    text: str
    cites: List[str]
    ts: Optional[float] = None
    score: float = 0.0

    def ok(self) -> bool:
        return bool(self.text and self.text.strip()) and bool(self.cites) \
            and all(isinstance(c, str) and c.strip() for c in self.cites)


@dataclass
class Chapter:
    kind: str              # day | week
    start: str             # ISO date
    end: str
    title: str = ""
    summary: str = ""
    summary_by: str = ""
    facts: List[Fact] = field(default_factory=list)
    stats: Dict = field(default_factory=dict)


def keep_sourced(facts: Iterable[Fact]) -> List[Fact]:
    """The citation rule: anything without a source is dropped. Kept lines are redacted."""
    out = []
    for f in facts:
        if f.ok():
            f.text = redact(f.text)
            out.append(f)
        else:
            log.debug("dropping unsourced claim: %r", f.text[:80])
    return out


# --- time helpers -------------------------------------------------------------

def _day_bounds(d: date) -> Tuple[float, float]:
    start = datetime(d.year, d.month, d.day, tzinfo=_TZ)
    end = start + timedelta(days=1)
    return start.timestamp(), end.timestamp()


def _local(ts: float) -> datetime:
    return datetime.fromtimestamp(float(ts), _TZ)


def _hhmm(ts: float) -> str:
    return _local(ts).strftime("%H:%M")


def _week_start(d: date) -> date:
    return d - timedelta(days=d.weekday())


def _clip(text: str, n: int = 220) -> str:
    """Verbatim prefix of `text`, cut on a word boundary."""
    t = re.sub(r"\s+", " ", text or "").strip()
    if len(t) <= n:
        return t
    cut = t[:n].rsplit(" ", 1)[0]
    return cut.rstrip(",;:-") + "…"


# --- sources (all read-only) ------------------------------------------------------

class Sources:
    """Everything the indexer reads. Each getter returns [] when a source is missing."""

    def __init__(self, state_dir: str = DEFAULT_STATE_DIR,
                 own_repos: Optional[Sequence[str]] = None,
                 work_repos: Optional[Sequence[str]] = None,
                 repo_root: str = _ROOT):
        self.state_dir = state_dir
        self.repo_root = repo_root
        if own_repos is None:
            own_repos = [repo_root, os.path.join(repo_root, "workspaces", "leon-brain-ci")]
        if work_repos is None:
            wdir = os.path.join(repo_root, "workspaces")
            work_repos = []
            if os.path.isdir(wdir):
                for name in sorted(os.listdir(wdir)):
                    p = os.path.join(wdir, name)
                    if name != "leon-brain-ci" and os.path.isdir(os.path.join(p, ".git")):
                        work_repos.append(p)
        self.own_repos = [p for p in own_repos if os.path.isdir(os.path.join(p, ".git"))]
        self.work_repos = [p for p in work_repos if os.path.isdir(os.path.join(p, ".git"))]
        self._commits: Optional[List[dict]] = None
        self._jsonl_cache: Dict[str, List[dict]] = {}
        self._goals: Optional[List[dict]] = None
        self._boots: Optional[List[float]] = None

    def _path(self, name: str) -> str:
        return os.path.join(self.state_dir, name)

    def project_aliases(self) -> Dict[str, Tuple[str, ...]]:
        if getattr(self, "_aliases", None) is not None:
            return self._aliases
        names: Dict[str, str] = {}
        try:
            from brain.origin import owner_projects
            for n in owner_projects():
                names.setdefault(n.lower(), n.title() if n.islower() else n)
        except Exception:
            pass
        c = self._ro("projects.db")
        if c is not None:
            try:
                for (n,) in c.execute("SELECT name FROM projects"):
                    if n:
                        names[str(n).lower()] = str(n)
            except sqlite3.Error:
                pass
            finally:
                c.close()
        for p in self.work_repos:
            n = os.path.basename(os.path.normpath(p))
            names.setdefault(n.lower(), n)
        out: Dict[str, Tuple[str, ...]] = dict(GENERIC_TOPICS)
        for low, disp in names.items():
            low = low.strip()
            if len(low) < 4 or low in _AMBIGUOUS_NAMES:
                continue
            al = {low, low.replace("-", " "), low.replace(" ", "-"), low.replace(" ", "").replace("-", "")}
            out[disp] = tuple(sorted(a for a in al if len(a) >= 4))
        self._aliases = out
        return out

    def _ro(self, name: str) -> Optional[sqlite3.Connection]:
        p = self._path(name)
        if not os.path.exists(p) or os.path.getsize(p) == 0:
            return None
        uri = "file:" + p.replace("\\", "/") + "?mode=ro"
        c = sqlite3.connect(uri, uri=True, timeout=10)
        c.execute("PRAGMA query_only=1")
        return c

    # conversations ---------------------------------------------------------
    def conversations(self, t0: float, t1: float) -> List[dict]:
        c = self._ro("knowledge.db")
        if c is None:
            return []
        try:
            rows = c.execute(
                "SELECT id, ts, role, content FROM conversation_history "
                "WHERE ts >= ? AND ts < ? ORDER BY ts, id", (t0, t1)).fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            c.close()
        # A delegated sub-agent's raw report is not something Leon said
        # (brain/conversation_store.py DELEGATED_REPORT_PREFIX).
        return [{"id": r[0], "ts": r[1], "role": r[2], "content": r[3] or ""} for r in rows
                if not (r[2] == "assistant" and (r[3] or "").lstrip().startswith("[Delegated agent report"))]

    def knowledge(self, t0: float, t1: float, sources: Sequence[str]) -> List[dict]:
        c = self._ro("knowledge.db")
        if c is None:
            return []
        try:
            q = ",".join("?" * len(sources))
            rows = c.execute(
                f"SELECT id, timestamp, source, text FROM knowledge WHERE timestamp >= ? "
                f"AND timestamp < ? AND source IN ({q}) ORDER BY timestamp", (t0, t1, *sources)).fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            c.close()
        return [{"id": r[0], "ts": r[1], "source": r[2], "text": r[3] or ""} for r in rows]

    def earliest_ts(self) -> Optional[float]:
        c = self._ro("knowledge.db")
        if c is None:
            return None
        try:
            r = c.execute("SELECT min(ts) FROM conversation_history").fetchone()
            return r[0] if r else None
        except sqlite3.Error:
            return None
        finally:
            c.close()

    # episodes (tool/response outcomes; old rows are pruned, kept ~1 month)
    def episodes(self, t0: float, t1: float) -> List[dict]:
        c = self._ro("episodes.db")
        if c is None:
            return []
        try:
            rows = c.execute(
                "SELECT id, ts, action_name, success, nm_dopamine, nm_serotonin, nm_norepinephrine "
                "FROM episodes WHERE ts >= ? AND ts < ? ORDER BY ts", (t0, t1)).fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            c.close()
        return [{"id": r[0], "ts": r[1], "action": r[2], "success": r[3],
                 "da": r[4], "5ht": r[5], "ne": r[6]} for r in rows]

    # jsonl logs ----------------------------------------------------------------
    def jsonl(self, name: str, ts_key: str = "ts") -> List[dict]:
        if name in self._jsonl_cache:
            return self._jsonl_cache[name]
        out = []
        p = self._path(name)
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                for i, line in enumerate(f, 1):
                    try:
                        o = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(o, dict):
                        continue
                    t = o.get(ts_key)
                    if isinstance(t, (int, float)):
                        o["_line"] = i
                        o["_ts"] = float(t)
                        out.append(o)
        self._jsonl_cache[name] = out
        return out

    def jsonl_between(self, name: str, t0: float, t1: float, ts_key: str = "ts") -> List[dict]:
        return [o for o in self.jsonl(name, ts_key) if t0 <= o["_ts"] < t1]

    def goals(self) -> List[dict]:
        if self._goals is not None:
            return self._goals
        out = []
        for fn in ("goals_archive.json", "goals.json"):
            p = self._path(fn)
            try:
                with open(p, "r", encoding="utf-8") as f:
                    g = json.load(f)
            except Exception:
                continue
            items = g if isinstance(g, list) else [x for v in g.values() if isinstance(v, list) for x in v]
            for x in items:
                if isinstance(x, dict) and isinstance(x.get("created_ts"), (int, float)):
                    x = dict(x)
                    x["_file"] = fn
                    out.append(x)
        self._goals = out
        return out

    def boots(self) -> List[float]:
        if self._boots is not None:
            return self._boots
        out: List[float] = []
        try:
            with open(self._path("boot-watchdog.json"), "r", encoding="utf-8") as f:
                for b in json.load(f).get("boots", []):
                    if isinstance(b.get("t"), (int, float)):
                        out.append(float(b["t"]))
        except Exception:
            pass
        self._boots = sorted(out)
        return self._boots

    # git -----------------------------------------------------------------------
    def commits(self) -> List[dict]:
        if self._commits is not None:
            return self._commits
        out: List[dict] = []
        for path, own in [(p, True) for p in self.own_repos] + [(p, False) for p in self.work_repos]:
            name = os.path.basename(os.path.normpath(path))
            if os.path.normpath(path) == os.path.normpath(self.repo_root):
                name = "leon-brain"
            try:
                r = subprocess.run(
                    ["git", "-C", path, "log", "--all", "--no-merges",
                     "--format=%H%x1f%at%x1f%an%x1f%s"],
                    capture_output=True, text=True, timeout=60, encoding="utf-8", errors="replace")
            except Exception:
                continue
            seen = set()
            for line in r.stdout.splitlines():
                parts = line.split("\x1f")
                if len(parts) != 4 or parts[0] in seen:
                    continue
                seen.add(parts[0])
                try:
                    out.append({"repo": name, "own": own, "sha": parts[0][:8], "ts": float(parts[1]),
                                "author": parts[2], "subject": parts[3]})
                except ValueError:
                    continue
        out.sort(key=lambda c: c["ts"])
        self._commits = out
        return out


# --- extraction ---------------------------------------------------------------------

def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _is_quotable(text: str) -> bool:
    t = text or ""
    if _JUNK.search(t) or has_secret(t):
        return False
    t = _clean(t)
    return 25 <= len(t) <= 1200 and len(re.findall(r"[a-zA-Z]{2,}", t)) >= 5


def _quote_score(text: str, ts: float) -> float:
    t = _clean(text)
    s = min(len(t), 320) / 80.0
    s += 1.5 * len(_WARM_WORDS.findall(t))
    s += 1.0 * len(_HARD_WORDS.findall(t))
    s += 0.8 if "?" in t else 0.0
    s += 0.6 if re.search(r"\b(you|your|leon)\b", t, re.I) else 0.0
    return s


def _projects_in(text: str, aliases: Dict[str, Tuple[str, ...]]) -> List[str]:
    low = (text or "").lower()
    out = []
    for name, al in aliases.items():
        for a in al:
            if re.search(r"(?<![a-z0-9])" + re.escape(a) + r"(?![a-z0-9])", low):
                out.append(name)
                break
    return out


class Firsts:
    """Lifetime firsts. Persisted in the store; only the earliest one ever wins."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def seen(self, kind: str, key: str) -> bool:
        r = self.conn.execute("SELECT 1 FROM firsts WHERE kind=? AND key=?", (kind, key)).fetchone()
        return r is not None

    def claim(self, kind: str, key: str, ts: float, text: str, cite: str) -> Optional[Fact]:
        row = self.conn.execute("SELECT ts FROM firsts WHERE kind=? AND key=?", (kind, key)).fetchone()
        if row is not None and row[0] <= ts:
            # Already have an earlier (or the same) first. Same ts = rebuild of that day.
            if row[0] == ts:
                return Fact("first", text, [cite], ts)
            return None
        text = redact(text)
        self.conn.execute("INSERT OR REPLACE INTO firsts(kind,key,ts,text,cite) VALUES(?,?,?,?,?)",
                          (kind, key, ts, text, cite))
        return Fact("first", text, [cite], ts)


def extract_day(src: Sources, d: date, firsts: Firsts) -> Chapter:
    t0, t1 = _day_bounds(d)
    ch = Chapter("day", d.isoformat(), d.isoformat())
    facts: List[Fact] = []

    # conversations
    conv = src.conversations(t0, t1)
    users = [r for r in conv if r["role"] == "user"]
    leons = [r for r in conv if r["role"] == "assistant"]
    if conv:
        ids = [r["id"] for r in conv]
        facts.append(Fact("state", f"{len(users)} messages from {_owner()} and {len(leons)} replies from me, "
                                   f"{_hhmm(conv[0]['ts'])}–{_hhmm(conv[-1]['ts'])}",
                          [f"conv#{min(ids)}..{max(ids)}"], conv[0]["ts"]))
        f = firsts.claim("life", "first_conversation", conv[0]["ts"],
                         f"first recorded conversation: {_owner()} said \"{_clip(conv[0]['content'], 120)}\"",
                         f"conv#{conv[0]['id']}")
        if f:
            facts.append(f)

    # Owner quotes: best few, spread across the day
    cands = []
    seen_txt = set()
    for r in users:
        t = _clean(r["content"])
        if not _is_quotable(r["content"]) or t.lower() in seen_txt:
            continue
        seen_txt.add(t.lower())
        cands.append((_quote_score(t, r["ts"]), r))
    cands.sort(key=lambda x: -x[0])
    picked: List[dict] = []
    for sc, r in cands:
        if len(picked) >= 4:
            break
        if any(abs(r["ts"] - p["ts"]) < 600 for p in picked):
            continue
        picked.append(r)
    picked.sort(key=lambda r: r["ts"])
    for r in picked:
        # Leon's reply right after, if any
        reply = next((x for x in leons if x["ts"] >= r["ts"] and x["id"] > r["id"]), None)
        txt = f"{_hhmm(r['ts'])} {_owner()}: \"{_clip(r['content'])}\""
        cites = [f"conv#{r['id']}"]
        if reply and _is_quotable(reply["content"]) and reply["ts"] - r["ts"] < 600:
            txt += f" — I said: \"{_clip(reply['content'], 160)}\""
            cites.append(f"conv#{reply['id']}")
        sec = "hard" if _HARD_WORDS.search(r["content"]) else "conversation"
        facts.append(Fact(sec, txt, cites, r["ts"], _quote_score(r["content"], r["ts"])))

    # projects mentioned (worked on) + first mentions
    aliases = src.project_aliases()
    mentions: Dict[str, List[dict]] = {}
    for r in conv:
        for p in _projects_in(r["content"], aliases):
            mentions.setdefault(p, []).append(r)
    # One project often has two names ("47 Industries" in projects.db and the
    # "47-industries" folder, "Fl-298" and "Fl-298 Research Lab"): when two
    # names hit the same messages and one contains the other, keep the longer.
    norm = {p: re.sub(r"[^a-z0-9]", "", p.lower()) for p in mentions}
    for p in list(mentions):
        ids = {r["id"] for r in mentions[p]}
        for q in list(mentions):
            if q != p and p in mentions and {r["id"] for r in mentions[q]} == ids \
                    and norm[p] in norm[q] and (len(norm[p]) < len(norm[q]) or p > q):
                del mentions[p]
                break
    for p, rows in sorted(mentions.items(), key=lambda kv: -len(kv[1])):
        if len(rows) >= 2:
            facts.append(Fact("worked_on", f"{p} came up {len(rows)} time(s) in conversation",
                              [f"conv#{rows[0]['id']}"] + ([f"conv#{rows[-1]['id']}"] if len(rows) > 1 else []),
                              rows[0]["ts"], float(len(rows))))
        f = firsts.claim("project", p, rows[0]["ts"], f"first time {p} came up in conversation",
                         f"conv#{rows[0]['id']}")
        if f:
            facts.append(f)

    # code that landed
    day_commits = [c for c in src.commits() if t0 <= c["ts"] < t1]
    by_repo: Dict[str, List[dict]] = {}
    for c in day_commits:
        by_repo.setdefault(c["repo"], []).append(c)
    for repo, cs in sorted(by_repo.items(), key=lambda kv: -len(kv[1])):
        subjects = "; ".join(_clip(c["subject"], 80) for c in cs[:3])
        more = f" (+{len(cs) - 3} more)" if len(cs) > 3 else ""
        authors: Dict[str, int] = {}
        for c in cs:
            authors[c["author"]] = authors.get(c["author"], 0) + 1
        by = ", ".join(a for a, _ in sorted(authors.items(), key=lambda kv: -kv[1])[:2])
        whose = "my own code" if cs[0]["own"] else "project repo"
        facts.append(Fact("built", f"{len(cs)} commit(s) landed in {repo} ({whose}, by {by}): {subjects}{more}",
                          [f"git:{repo}@{c['sha']}" for c in cs[:3]], cs[0]["ts"], float(len(cs))))
        kind = "own_repo_commit" if cs[0]["own"] else "project_commit"
        f = firsts.claim(kind, repo, cs[0]["ts"], f"first commit recorded in {repo}: \"{_clip(cs[0]['subject'], 90)}\"",
                         f"git:{repo}@{cs[0]['sha']}")
        if f:
            facts.append(f)

    # distilled knowledge: what got learned/stated that day, and Leon's own thoughts
    kn = src.knowledge(t0, t1, ("inner_thought", "conversation_distill", "dean_stated", "last_conscious_moment"))
    thoughts = [k for k in kn if k["source"] in ("inner_thought", "last_conscious_moment") and _is_quotable(k["text"])]
    thoughts.sort(key=lambda k: -_quote_score(k["text"], k["ts"]))
    for k in sorted(thoughts[:3], key=lambda k: k["ts"]):
        facts.append(Fact("thought", f"{_hhmm(k['ts'])} I thought: \"{_clip(k['text'], 200)}\"",
                          [f"know#{k['id']}"], k["ts"], _quote_score(k["text"], k["ts"])))
    learned = [k for k in kn if k["source"] in ("conversation_distill", "dean_stated")
               and 20 <= len(k["text"]) <= 400 and not has_secret(k["text"])]
    learned.sort(key=lambda k: -len(_WARM_WORDS.findall(k["text"])) - len(_projects_in(k["text"], aliases)))
    for k in sorted(learned[:3], key=lambda k: k["ts"]):
        facts.append(Fact("learned", f"I took away: {_clip(k['text'], 200)}", [f"know#{k['id']}"], k["ts"]))
    if thoughts:
        f = firsts.claim("life", "first_inner_thought", thoughts[0]["ts"],
                         f"first recorded inner thought: \"{_clip(thoughts[0]['text'], 120)}\"",
                         f"know#{thoughts[0]['id']}")
        if f:
            facts.append(f)

    # tools: first recorded use of each tool
    tool_rows = src.jsonl_between("tool_learning.jsonl", t0, t1) + src.jsonl_between("actuator-audit.jsonl", t0, t1)
    tool_rows.sort(key=lambda o: o["_ts"])
    tool_counts: Dict[str, int] = {}
    tool_firsts: List[Fact] = []
    for o in tool_rows:
        name = str(o.get("tool") or "").strip()
        if not name:
            continue
        tool_counts[name] = tool_counts.get(name, 0) + 1
        fname = "tool_learning.jsonl" if "keywords" in o or "autonomous" in o else "actuator-audit.jsonl"
        f = firsts.claim("tool", name, o["_ts"], f"first recorded use of the tool {name}", f"{fname}:{o['_line']}")
        if f:
            tool_firsts.append(f)
    # Every first tool use is kept in the firsts table; the chapter shows a few
    # and folds the rest into one cited line so a busy day isn't all tools.
    facts += tool_firsts[:3]
    if len(tool_firsts) > 3:
        rest = tool_firsts[3:]
        facts.append(Fact("first", f"{len(rest)} more tools used for the first time: "
                                   + ", ".join(f.text.rsplit(" ", 1)[-1] for f in rest[:12])
                                   + ("…" if len(rest) > 12 else ""),
                          [c for f in rest[:4] for c in f.cites], rest[0].ts))
    if tool_counts:
        top = sorted(tool_counts.items(), key=lambda kv: -kv[1])[:5]
        o0 = tool_rows[0]
        facts.append(Fact("state", "tools I used most: " + ", ".join(f"{k} ×{v}" for k, v in top),
                          [f"tool_learning/actuator-audit:{d.isoformat()} n={sum(tool_counts.values())}"],
                          o0["_ts"]))

    # episodes (only the last month survives pruning)
    eps = src.episodes(t0, t1)
    if eps:
        fails = sum(1 for e in eps if e["success"] == 0)
        das = [e["da"] for e in eps if isinstance(e["da"], (int, float))]
        mood = ""
        if das:
            avg = sum(das) / len(das)
            mood = f"; dopamine averaged {avg:.2f}"
        facts.append(Fact("state", f"{len(eps)} actions logged, {fails} failed{mood}",
                          [f"episodes#{eps[0]['id']}..{eps[-1]['id']}"], eps[0]["ts"]))

    # proactive outreach
    outb = [o for o in src.jsonl_between("outbound.jsonl", t0, t1) if _is_quotable(str(o.get("text", "")))]
    if outb:
        facts.append(Fact("state", f"I reached out on my own {len(outb)} time(s)",
                          [f"outbound.jsonl:{outb[0]['_line']}..{outb[-1]['_line']}"], outb[0]["_ts"]))
        o = max(outb, key=lambda o: _quote_score(str(o.get("text")), o["_ts"]))
        facts.append(Fact("conversation", f"{_hhmm(o['_ts'])} I reached out: \"{_clip(str(o.get('text')), 180)}\"",
                          [f"outbound.jsonl:{o['_line']}"], o["_ts"]))
        f = firsts.claim("life", "first_outreach", outb[0]["_ts"],
                         f"first time I reached out on my own: \"{_clip(str(outb[0].get('text')), 120)}\"",
                         f"outbound.jsonl:{outb[0]['_line']}")
        if f:
            facts.append(f)

    # goals set that day
    gs = [g for g in src.goals() if t0 <= g["created_ts"] < t1 and g.get("description")]
    if gs:
        gs.sort(key=lambda g: (-(g.get("priority") or 0), g["created_ts"]))
        for g in gs[:2]:
            facts.append(Fact("worked_on", f"set a goal: {_clip(str(g['description']), 140)} "
                                           f"(status now: {g.get('status', '?')})",
                              [f"goal:{g.get('id', '?')}"], g["created_ts"]))
        g0 = min(gs, key=lambda g: g["created_ts"])
        f = firsts.claim("life", "first_goal", g0["created_ts"],
                         f"first recorded goal: {_clip(str(g0['description']), 120)}", f"goal:{g0.get('id', '?')}")
        if f:
            facts.append(f)

    # restarts
    boots = [b for b in src.boots() if t0 <= b < t1]
    if boots:
        facts.append(Fact("state", f"I was restarted {len(boots)} time(s)",
                          [f"boot-watchdog.json:{d.isoformat()} n={len(boots)}"], boots[0]))
        f = firsts.claim("life", "first_recorded_restart", boots[0], "first restart on record",
                         f"boot-watchdog.json:t={boots[0]:.0f}")
        if f:
            facts.append(f)

    # consciousness streaks
    trans = src.jsonl_between("consciousness_transitions.jsonl", t0, t1)
    if trans:
        longest = max((float(o.get("longest_s") or 0) for o in trans), default=0)
        streak = f"; longest conscious streak so far {longest / 60:.0f} min" if longest >= 60 else ""
        facts.append(Fact("state", f"{len(trans)} conscious-state transitions{streak}",
                          [f"consciousness_transitions.jsonl:{trans[0]['_line']}..{trans[-1]['_line']}"],
                          trans[0]["_ts"]))

    ch.facts = keep_sourced(facts)
    ch.stats = {"messages_from_owner": len(users), "my_replies": len(leons), "commits": len(day_commits),
                "tool_uses": sum(tool_counts.values()), "restarts": len(boots), "outreach": len(outb)}
    ch.title = _title_for(ch)
    return ch


def _title_for(ch: Chapter) -> str:
    worked = [f.text.split(" came up")[0] for f in ch.facts if f.section == "worked_on" and " came up" in f.text]
    built = [f.text.split(" landed in ", 1)[1].split(" (")[0] for f in ch.facts
             if f.section == "built" and " landed in " in f.text]
    def key(x):
        return re.sub(r"[^a-z0-9]", "", x.lower())
    have = {key(w) for w in worked[:2]}
    bits = (worked[:2] + [b for b in built if key(b) not in have][:1]) or ["a quiet day"]
    d = date.fromisoformat(ch.start)
    if ch.kind == "week":
        from brain.timefmt import fmt
        return f"Week of {fmt(d, '%b %-d')}: " + ", ".join(bits)
    return d.strftime("%a %b %d") + ": " + ", ".join(bits)


# --- LLM summary with citation enforcement ------------------------------------------

_CITE_RE = re.compile(r"\[(\d+)\]")
_QUOTE_RE = re.compile(r"[\"“]([^\"”]{6,})[\"”]")


def _tokens(s: str) -> List[str]:
    return [w for w in re.findall(r"[a-z0-9][a-z0-9'\-]{2,}", (s or "").lower()) if w not in _STOP]


def validate_summary(text: str, facts: List[Fact], min_support: float = 0.5) -> str:
    """
    Keep only sentences that (1) cite at least one numbered fact, (2) cite only
    facts that exist, (3) quote only text found in their cited facts, and (4)
    are mostly made of words found in their cited facts. Citations are
    rewritten to source ids so the stored summary points at real records.
    """
    kept = []
    for sent in re.split(r"(?<=[.!?])\s+(?=[A-Z\"“])|\n+", text or ""):
        sent = sent.strip()
        if not sent:
            continue
        nums = [int(n) for n in _CITE_RE.findall(sent)]
        if not nums or any(n < 1 or n > len(facts) for n in nums):
            continue
        cited = [facts[n - 1] for n in nums]
        body = _CITE_RE.sub("", sent).strip()
        src_text = " ".join(f.text for f in cited)
        quotes = _QUOTE_RE.findall(body)
        if any(_clean(q).rstrip("…").lower() not in _clean(src_text).lower() for q in quotes):
            continue
        toks = _tokens(_QUOTE_RE.sub("", body))
        if toks:
            src_toks = set(_tokens(src_text))
            support = sum(1 for t in toks if t in src_toks or t.rstrip("s") in src_toks) / len(toks)
            if support < min_support:
                continue
        refs = []
        for f in cited:
            for c in f.cites:
                if c not in refs:
                    refs.append(c)
        body = re.sub(r"\s+([.,!?])", r"\1", body)
        kept.append(f"{body} [{', '.join(refs[:4])}]")
    return " ".join(kept)


def _prompt_for(ch: Chapter, facts: List[Fact]) -> str:
    lines = "\n".join(f"[{i}] ({f.section}) {f.text}" for i, f in enumerate(facts, 1))
    period = ch.start if ch.kind == "day" else f"the week {ch.start} to {ch.end}"
    return (
        "You are Leon, an AI, writing a short private diary entry about " + period + ", using ONLY the numbered "
        "records below from your own logs. Write 3 to 5 plain first-person sentences about what you did, "
        "who you talked to, what was hard, and how it felt, but only as far as the records show. "
        "End EVERY sentence with the numbers of the records it is based on, like [2] or [1][4]. "
        "Do not add anything the records don't say. Use the same words as the records where you can. "
        "Only put words in quotes if they appear in quotes in the cited record.\n\nRECORDS:\n" + lines +
        "\n\nDiary entry:")


def ollama_summarizer(model: str = "qwen2.5:7b-instruct-q4_K_M",
                      url: str = "http://127.0.0.1:11434/api/generate",
                      threads: int = 2, timeout: float = 600) -> Callable[[str], str]:
    def call(prompt: str) -> str:
        body = json.dumps({"model": model, "prompt": prompt, "stream": False,
                           "options": {"num_thread": threads, "temperature": 0.2, "num_predict": 400,
                                       "num_ctx": 4096}}).encode()
        req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode()).get("response", "")
    return call


def deterministic_summary(ch: Chapter) -> str:
    parts = []
    order = {"worked_on": 0, "built": 1, "first": 2, "conversation": 3, "hard": 4, "state": 5}
    best: Dict[str, Fact] = {}
    for f in ch.facts:
        if f.section in order and f.section not in best:
            best[f.section] = f
    for sec in sorted(best, key=lambda s: order[s]):
        f = best[sec]
        parts.append(f"{f.text[0].upper() + f.text[1:]}. [{', '.join(f.cites[:3])}]")
    return " ".join(parts[:4])


def summarize(ch: Chapter, llm: Optional[Callable[[str], str]]) -> None:
    facts = sorted(ch.facts, key=lambda f: (f.ts or 0))[:30]
    if not facts:
        ch.summary, ch.summary_by = "", "none"
        return
    if llm is not None:
        try:
            raw = llm(_prompt_for(ch, facts))
            good = validate_summary(raw, facts)
            if good:
                ch.summary, ch.summary_by = good, "llm+validated"
                return
        except Exception as e:
            log.warning("summary LLM failed for %s: %s", ch.start, e)
    ch.summary, ch.summary_by = deterministic_summary(ch), "records"


# --- store --------------------------------------------------------------------------

_SCHEMA = """
CREATE TABLE IF NOT EXISTS chapters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL, start TEXT NOT NULL, end TEXT NOT NULL,
    title TEXT, summary TEXT, summary_by TEXT, stats_json TEXT,
    n_facts INTEGER, built_at REAL,
    UNIQUE(kind, start));
CREATE TABLE IF NOT EXISTS claims (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
    section TEXT NOT NULL, text TEXT NOT NULL, ts REAL, score REAL,
    cites TEXT NOT NULL CHECK (cites != '[]' AND cites != ''));
CREATE INDEX IF NOT EXISTS idx_claims_chapter ON claims(chapter_id);
CREATE INDEX IF NOT EXISTS idx_chapters_range ON chapters(kind, start, end);
CREATE TABLE IF NOT EXISTS firsts (
    kind TEXT NOT NULL, key TEXT NOT NULL, ts REAL NOT NULL, text TEXT, cite TEXT NOT NULL,
    PRIMARY KEY (kind, key));
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE VIRTUAL TABLE IF NOT EXISTS chapter_fts USING fts5(body, tokenize='porter unicode61');
"""


class LifeStore:
    def __init__(self, path: Optional[str] = None, readonly: bool = False):
        self.path = path or os.path.join(DEFAULT_STATE_DIR, DB_NAME)
        if readonly:
            if not os.path.exists(self.path):
                raise FileNotFoundError(self.path)
            uri = "file:" + self.path.replace("\\", "/") + "?mode=ro"
            self.conn = sqlite3.connect(uri, uri=True, timeout=10, check_same_thread=False)
        else:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            self.conn = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.conn.executescript(_SCHEMA)

    def close(self):
        self.conn.close()

    def has_day(self, d: date) -> bool:
        return self.conn.execute("SELECT 1 FROM chapters WHERE kind='day' AND start=?",
                                 (d.isoformat(),)).fetchone() is not None

    def save(self, ch: Chapter) -> Optional[int]:
        facts = keep_sourced(ch.facts)
        c = self.conn
        old = c.execute("SELECT id FROM chapters WHERE kind=? AND start=?", (ch.kind, ch.start)).fetchone()
        if old:
            c.execute("DELETE FROM claims WHERE chapter_id=?", (old[0],))
            c.execute("DELETE FROM chapter_fts WHERE rowid=?", (old[0],))
            c.execute("DELETE FROM chapters WHERE id=?", (old[0],))
        if not facts:
            c.commit()
            return None
        cur = c.execute(
            "INSERT INTO chapters(kind,start,end,title,summary,summary_by,stats_json,n_facts,built_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (ch.kind, ch.start, ch.end, redact(ch.title), redact(ch.summary), ch.summary_by, json.dumps(ch.stats),
             len(facts), time.time()))
        cid = cur.lastrowid
        c.executemany("INSERT INTO claims(chapter_id,section,text,ts,score,cites) VALUES(?,?,?,?,?,?)",
                      [(cid, f.section, f.text, f.ts, f.score, json.dumps(f.cites)) for f in facts])
        body = redact(" ".join([ch.title, ch.summary] + [f.text for f in facts]))
        c.execute("INSERT INTO chapter_fts(rowid, body) VALUES(?,?)", (cid, body))
        c.commit()
        return cid

    def load(self, cid: int) -> Optional[dict]:
        r = self.conn.execute("SELECT id,kind,start,end,title,summary,summary_by,stats_json FROM chapters "
                              "WHERE id=?", (cid,)).fetchone()
        if not r:
            return None
        claims = [{"section": s, "text": t, "ts": ts, "cites": json.loads(cs)}
                  for s, t, ts, cs in self.conn.execute(
                      "SELECT section,text,ts,cites FROM claims WHERE chapter_id=? ORDER BY ts, id", (cid,))]
        return {"id": r[0], "kind": r[1], "start": r[2], "end": r[3], "title": r[4], "summary": r[5],
                "summary_by": r[6], "stats": json.loads(r[7] or "{}"), "claims": claims}

    def day_facts(self, start: str, end: str) -> List[Tuple[str, Fact]]:
        rows = self.conn.execute(
            "SELECT c.start, cl.section, cl.text, cl.ts, cl.score, cl.cites FROM claims cl "
            "JOIN chapters c ON c.id=cl.chapter_id WHERE c.kind='day' AND c.start BETWEEN ? AND ? "
            "ORDER BY cl.ts", (start, end)).fetchall()
        return [(r[0], Fact(r[1], r[2], json.loads(r[5]), r[3], r[4] or 0.0)) for r in rows]

    def day_stats(self, start: str, end: str) -> List[dict]:
        return [json.loads(r[0] or "{}") for r in self.conn.execute(
            "SELECT stats_json FROM chapters WHERE kind='day' AND start BETWEEN ? AND ?", (start, end))]

    def get_meta(self, key: str) -> Optional[str]:
        r = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return r[0] if r else None

    def set_meta(self, key: str, value: str):
        self.conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", (key, value))
        self.conn.commit()

    def coverage(self) -> Tuple[Optional[str], Optional[str], int]:
        r = self.conn.execute("SELECT min(start), max(end), count(*) FROM chapters WHERE kind='day'").fetchone()
        return r[0], r[1], r[2]

    # search ----------------------------------------------------------------------
    def find(self, start: Optional[str] = None, end: Optional[str] = None, about: Optional[str] = None,
             limit: int = 3, kinds: Sequence[str] = ("day", "week")) -> List[dict]:
        where, args = [], []
        if start and end:
            where.append("c.start <= ? AND c.end >= ?")
            args += [end, start]
            # A narrow window is answered by its own days only: the week around
            # an empty day would hand back other days' events as if they were it.
            if (date.fromisoformat(end) - date.fromisoformat(start)).days < 10:
                kinds = tuple(k for k in kinds if k == "day") or kinds
        kq = ",".join("?" * len(kinds))
        where.append(f"c.kind IN ({kq})")
        args += list(kinds)
        match = _fts_query(about) if about else ""
        if match:
            sql = (f"SELECT c.id, bm25(chapter_fts) AS rank FROM chapter_fts JOIN chapters c ON c.id=chapter_fts.rowid "
                   f"WHERE chapter_fts MATCH ? AND {' AND '.join(where)} ORDER BY rank LIMIT ?")
            rows = self.conn.execute(sql, [match] + args + [limit * 4]).fetchall()
        else:
            # No topic: the fullest days in the range, so recall lands on what actually happened.
            sql = (f"SELECT c.id, -c.n_facts FROM chapters c WHERE {' AND '.join(where)} "
                   f"ORDER BY c.n_facts DESC, c.start LIMIT ?")
            rows = self.conn.execute(sql, args + [limit * 4]).fetchall()
        out = [self.load(r[0]) for r in rows]
        out = [o for o in out if o]
        # Prefer day chapters for a narrow window, the week for a wide one.
        if start and end:
            span = (date.fromisoformat(end) - date.fromisoformat(start)).days + 1
            if span <= 10:
                out.sort(key=lambda o: o["kind"] != "day")
            else:
                out.sort(key=lambda o: o["kind"] != "week")
        # A day inside a week already picked would only repeat that week.
        picked: List[dict] = []
        for o in out:
            if o["kind"] == "day" and any(p["kind"] == "week" and p["start"] <= o["start"] <= p["end"]
                                          for p in picked):
                continue
            picked.append(o)
        return picked[:limit]


def _fts_query(about: str) -> str:
    toks = [t for t in _tokens(about) if len(t) > 2][:8]
    return " OR ".join(f'"{t}"' for t in toks)


# --- weekly roll-up -------------------------------------------------------------------

def build_week(store: LifeStore, wk: date, llm: Optional[Callable[[str], str]] = None) -> Optional[int]:
    start, end = wk.isoformat(), (wk + timedelta(days=6)).isoformat()
    rows = store.day_facts(start, end)
    if not rows:
        return None
    ch = Chapter("week", start, end)
    by_sec: Dict[str, List[Fact]] = {}
    for _, f in rows:
        by_sec.setdefault(f.section, []).append(f)
    keep: List[Fact] = []
    keep += by_sec.get("first", [])[:8]
    keep += sorted(by_sec.get("worked_on", []), key=lambda f: -f.score)[:5]
    keep += sorted(by_sec.get("built", []), key=lambda f: -f.score)[:4]
    keep += sorted(by_sec.get("conversation", []), key=lambda f: -f.score)[:4]
    keep += sorted(by_sec.get("hard", []), key=lambda f: -f.score)[:2]
    keep += sorted(by_sec.get("thought", []), key=lambda f: -f.score)[:2]
    stats: Dict[str, int] = {}
    for s in store.day_stats(start, end):
        for k, v in s.items():
            if isinstance(v, (int, float)):
                stats[k] = stats.get(k, 0) + v
    days = sorted({d for d, _ in rows})
    keep.append(Fact("state", f"{stats.get('messages_from_owner', 0)} messages from {_owner()} across {len(days)} day(s) "
                              f"with records; {stats.get('commits', 0)} commits; {stats.get('restarts', 0)} restarts",
                     [f"chapters:day {days[0]}..{days[-1]}"], None))
    ch.facts = keep_sourced(sorted(keep, key=lambda f: f.ts or 0))
    ch.stats = stats
    ch.title = _title_for(ch)
    summarize(ch, llm)
    return store.save(ch)


# --- indexer ------------------------------------------------------------------------------

def index(state_dir: str = DEFAULT_STATE_DIR, store_path: Optional[str] = None,
          since: Optional[date] = None, until: Optional[date] = None,
          llm: Optional[Callable[[str], str]] = None, sleep_s: float = 0.0,
          max_days: Optional[int] = None, rebuild: bool = False,
          sources: Optional[Sources] = None) -> dict:
    """
    Build day chapters for every unindexed day in [since, until], then the
    weeks they belong to. Days are processed oldest-first so lifetime "firsts"
    come out right. Returns a small report.
    """
    src = sources or Sources(state_dir)
    store = LifeStore(store_path or os.path.join(state_dir, DB_NAME))
    try:
        if since is None:
            e = src.earliest_ts()
            since = _local(e).date() if e else date(2026, 5, 13)
        if until is None:
            until = datetime.now(_TZ).date()
        last_done = store.get_meta("last_day_indexed")
        if rebuild:
            # Firsts in the rebuilt range are recomputed from scratch, so a
            # change in how they're found can't leave a stale "first" behind.
            store.conn.execute("DELETE FROM firsts WHERE ts >= ?", (_day_bounds(since)[0],))
            store.conn.commit()
        built, skipped, weeks = [], 0, set()
        d = since
        while d <= until:
            fresh = last_done is not None and d.isoformat() >= last_done  # may have grown since
            done = store.has_day(d) or (last_done is not None and d.isoformat() < last_done)
            if done and not rebuild and not fresh:
                skipped += 1
                d += timedelta(days=1)
                continue
            firsts = Firsts(store.conn)
            ch = extract_day(src, d, firsts)
            if ch.facts:
                summarize(ch, llm)
            store.save(ch)
            store.conn.commit()
            if ch.facts:
                built.append(d.isoformat())
                weeks.add(_week_start(d))
            if last_done is None or d.isoformat() > last_done:
                store.set_meta("last_day_indexed", d.isoformat())
                last_done = d.isoformat()
            if max_days and len(built) >= max_days:
                break
            if sleep_s:
                time.sleep(sleep_s)
            d += timedelta(days=1)
        for wk in sorted(weeks):
            build_week(store, wk, llm)
            if sleep_s:
                time.sleep(sleep_s)
        cov = store.coverage()
        return {"built_days": built, "skipped_days": skipped, "weeks": [w.isoformat() for w in sorted(weeks)],
                "coverage": {"first": cov[0], "last": cov[1], "days": cov[2]}}
    finally:
        store.close()


# --- recall (self_remember) ---------------------------------------------------------------

def remember(when: Optional[str] = None, about: Optional[str] = None, limit: int = 3,
             store_path: Optional[str] = None, today: Optional[date] = None) -> dict:
    """
    Look up chapters of Leon's own life. `when` is a phrase ("first two weeks",
    "2026-06-03", "back in June"); `about` is a topic ("a project").
    Returns {"found": bool, "period": ..., "chapters": [...], "note": ...}.
    Never invents: an empty result says plainly that there is no record.
    """
    from brain.life_time import parse_when
    period = parse_when(when, today=today) if when else None
    if when and period is None:
        return {"found": False, "period": None, "chapters": [], "coverage": {},
                "note": f"I couldn't tell what time \"{when}\" means. Try a date like 2026-06-03, "
                        f"a month, or a phrase like 'first two weeks'."}
    return remember_period(period, about, limit=limit, store_path=store_path)


def remember_period(period, about: Optional[str] = None, limit: int = 3,
                    store_path: Optional[str] = None) -> dict:
    """remember() for an already-parsed life_time.Period (None = any time)."""
    path = store_path or os.path.join(DEFAULT_STATE_DIR, DB_NAME)
    try:
        store = LifeStore(path, readonly=True)
    except Exception:
        return {"found": False, "period": None, "chapters": [], "coverage": {},
                "note": "My life chapters haven't been indexed yet, so I have no recollection to draw on."}
    try:
        cov = store.coverage()
        s, e = (period.start.isoformat(), period.end.isoformat()) if period else (None, None)
        chapters = store.find(s, e, about, limit=limit)
        if not chapters and about and period:
            # Topic didn't match in that window: still return what that time held.
            chapters = store.find(s, e, None, limit=limit)
        label = period.label if period else None
        out = {"found": bool(chapters), "period": ({"label": label, "start": s, "end": e} if period else None),
               "coverage": {"first": cov[0], "last": cov[1], "days": cov[2]}, "chapters": chapters}
        if not chapters:
            where = f" for {label} ({s} to {e})" if period else ""
            topic = f" about {about}" if about else ""
            covered = f" My indexed records cover {cov[0]} to {cov[1]}." if cov[0] else ""
            out["note"] = (f"No records{where}{topic}. I don't remember that, and I shouldn't make it up." + covered)
        return out
    finally:
        store.close()


_SHOW_ORDER = (("conversation", 2), ("thought", 1), ("hard", 1), ("first", 2), ("worked_on", 2),
               ("built", 1), ("learned", 1), ("state", 2))


def format_chapter(ch: dict, max_claims: int = 6, quote_chars: int = 220,
                   records_summary: bool = True, about: Optional[str] = None) -> str:
    """Compact text form of a chapter, every line with its citations.

    Picks claims section by section (talk and his own thoughts first, then
    what was hard, firsts, work, state) so a short excerpt still feels like a
    day, not a tool log. Extra claims fill in afterwards in the same order.
    """
    period = ch["start"] if ch["start"] == ch["end"] else f"{ch['start']} to {ch['end']}"
    lines = [f"{period} — {ch['title']}"]
    # A records-only summary repeats the claims below it; callers short on
    # room (the RECALLED MEMORY block) skip it and keep only an LLM diary line.
    if ch.get("summary") and (records_summary or ch.get("summary_by") == "llm+validated"):
        lines.append("  " + ch["summary"])
    by_sec: Dict[str, List[dict]] = {}
    topic = set(_tokens(about or ""))

    def on_topic(c):
        return bool(topic) and bool(topic & set(_tokens(c["text"])))
    # With a topic, the claims that mention it lead each section.
    for c in sorted(ch["claims"], key=lambda c: (not on_topic(c), c["ts"] or 0)):
        by_sec.setdefault(c["section"], []).append(c)
    picked: List[dict] = []
    for sec, cap in _SHOW_ORDER:          # one of each kind first
        picked += by_sec.get(sec, [])[:1]
    for sec, cap in _SHOW_ORDER:          # then up to the cap
        picked += by_sec.get(sec, [])[1:cap]
    for sec, cap in _SHOW_ORDER:          # then the rest
        picked += by_sec.get(sec, [])[cap:]
    for c in picked[:max_claims]:
        t = c["text"] if len(c["text"]) <= quote_chars else c["text"][:quote_chars].rsplit(" ", 1)[0] + "…"
        lines.append(f"  - ({c['section']}) {t} [{', '.join(c['cites'][:3])}]")
    return "\n".join(lines)


# --- nightly ---------------------------------------------------------------------------------

_last_nightly_check = 0.0


def maybe_run_nightly(state_dir: str = DEFAULT_STATE_DIR, now: Optional[float] = None) -> Optional[int]:
    """
    Cheap, throttled check called from the dream loop. About once a night
    (1-6am local, or any time once 36h have passed) it starts the incremental
    indexer as a separate low-priority process so new days get their chapter.
    Returns the child pid when it started one. LEON_LIFE_CHAPTERS=off disables.
    """
    global _last_nightly_check
    now = now or time.time()
    if os.environ.get("LEON_LIFE_CHAPTERS", "").strip().lower() in ("off", "0", "false"):
        return None
    if now - _last_nightly_check < 600:
        return None
    _last_nightly_check = now
    stamp = os.path.join(state_dir, "life_chapters.last_run")
    pidf = os.path.join(state_dir, "life_chapters.pid")
    try:
        last = os.path.getmtime(stamp)
    except OSError:
        last = 0.0
    since = now - last
    hour = datetime.fromtimestamp(now, _TZ).hour
    if since < 20 * 3600 or not (1 <= hour <= 6 or since > 36 * 3600):
        return None
    try:
        with open(pidf, encoding="utf-8") as f:
            pid = int(f.read().strip() or 0)
        if pid and os.name != "nt":
            os.kill(pid, 0)  # still running
            return None
    except (OSError, ValueError):
        pass
    cmd = [sys.executable, "-m", "brain.life_chapters", "--state-dir", state_dir,
           "--llm", os.environ.get("LEON_LIFE_CHAPTERS_LLM", "none"), "--threads", "2", "--sleep", "5"]
    if os.name != "nt":
        cmd = ["nice", "-n", "19"] + cmd
    try:
        with open(stamp, "w", encoding="utf-8") as f:
            f.write(str(now))
        logf = open(os.path.join(state_dir, "life_chapters.log"), "a", encoding="utf-8")
        p = subprocess.Popen(cmd, cwd=_ROOT, stdout=logf, stderr=subprocess.STDOUT,
                             stdin=subprocess.DEVNULL, start_new_session=(os.name != "nt"))
        with open(pidf, "w", encoding="utf-8") as f:
            f.write(str(p.pid))
        return p.pid
    except Exception as e:
        log.warning("life chapters nightly run failed to start: %s", e)
        return None


# --- CLI ------------------------------------------------------------------------------------

def _main(argv=None):
    ap = argparse.ArgumentParser(description="Build / query Leon's life chapters")
    ap.add_argument("--state-dir", default=DEFAULT_STATE_DIR)
    ap.add_argument("--repo-root", default=_ROOT, help="where Leon's own repo and workspaces/ live")
    ap.add_argument("--since")
    ap.add_argument("--until")
    ap.add_argument("--llm", choices=["none", "ollama"], default="none")
    ap.add_argument("--model", default="qwen2.5:7b-instruct-q4_K_M")
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--sleep", type=float, default=0.0, help="pause between days (rate limit)")
    ap.add_argument("--max-days", type=int)
    ap.add_argument("--rebuild", action="store_true")
    ap.add_argument("--query", help="when-phrase to recall instead of building")
    ap.add_argument("--about")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    store_path = os.path.join(a.state_dir, DB_NAME)
    if a.query or (a.about and not a.since):
        r = remember(a.query, a.about, store_path=store_path)
        print(json.dumps({k: v for k, v in r.items() if k != "chapters"}, indent=1))
        for ch in r["chapters"]:
            print()
            print(format_chapter(ch, max_claims=12, quote_chars=400))
        return 0
    llm = ollama_summarizer(a.model, threads=a.threads) if a.llm == "ollama" else None
    rep = index(a.state_dir, store_path,
                since=date.fromisoformat(a.since) if a.since else None,
                until=date.fromisoformat(a.until) if a.until else None,
                llm=llm, sleep_s=a.sleep, max_days=a.max_days, rebuild=a.rebuild,
                sources=Sources(a.state_dir, repo_root=a.repo_root))
    # A finished run counts as tonight's run, so the dream-loop trigger
    # doesn't start a second indexer right behind a manual backfill.
    try:
        with open(os.path.join(a.state_dir, "life_chapters.last_run"), "w", encoding="utf-8") as f:
            f.write(str(time.time()))
    except OSError:
        pass
    print(json.dumps(rep, indent=1))
    return 0


if __name__ == "__main__":
    sys.path.insert(0, _ROOT)
    sys.exit(_main())
