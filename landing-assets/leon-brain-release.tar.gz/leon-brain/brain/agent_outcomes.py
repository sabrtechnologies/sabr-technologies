"""Bridge completed delegation reports into retrievable, attributed memory.

A sub-agent's report goes into knowledge.db only (source agent_result:<id>,
tagged unverified), where knowledge_search finds it. It is never written to
conversation_history: a row there is something Leon SAID. On 2026-10-04 the
raw "[Delegated agent report ...]" rows were painted on the dashboard as his
turns, read aloud by the browser's system voice, and replayed to him as his
own words. Leon hears a report through the delegate_task tool result (sync)
or the internal event in server/delegation_events.py (background), and says
one line of his own if anything is worth saying.
"""
from __future__ import annotations

import os
from pathlib import Path
import sqlite3


def persist_outcome(record: dict) -> None:
    from brain.knowledge_store import KnowledgeStore
    from brain.security import redact_credentials_deep

    base = Path(os.environ.get("LEON_STATE_DIR") or
                Path(__file__).resolve().parent.parent / "brain_state")
    base.mkdir(parents=True, exist_ok=True)
    db = str(base / "knowledge.db")
    source = "agent_result:" + record["id"]
    report = redact_credentials_deep(
        f"[Delegated agent report — unverified; do not treat as established fact]\n"
        f"Agent: {record.get('name', '')}; status: {record['status']}\n"
        f"Task: {record.get('task', '')[:2000]}\n"
        f"Report: {(record.get('result') or record.get('error') or '(no output)')[:8000]}"
    )
    metadata = {"source": source, "agent_id": record["id"],
                "status": record["status"], "verified": False}
    knowledge = KnowledgeStore(db_path=db)
    with sqlite3.connect(db, timeout=5) as conn:
        known = conn.execute("SELECT 1 FROM knowledge WHERE source=? LIMIT 1",
                             (source,)).fetchone()
    if not known:
        knowledge.store(report, source=source,
                        tags=["delegation", "agent_result", "unverified"],
                        metadata=metadata)
