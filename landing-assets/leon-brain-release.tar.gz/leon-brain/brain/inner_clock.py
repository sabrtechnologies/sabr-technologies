"""Inner clock — Leon's persistent sense of time.

Modeled on how humans keep time, in three layers:

1. CIRCADIAN (the SCN). A ~24h phase oscillator, free-running at a slightly
   long period like a human body clock and entrained to the owner's local
   wall clock (the "daylight"). Leon always knows the time of day and its
   character without being told. Small offsets (a DST change) are absorbed
   gradually — a little jet lag, reported as drift. A host clock jump or a
   drift too large to be real is hard re-synced.

2. INTERVAL TIMING (the striatal pacemaker-accumulator). Elapsed time since
   key events — Dean's last message, the conversation, the restart, the
   last sleep cycle — and the length of every blackout (process down) or
   pause (host asleep / process frozen). Anchors are wall timestamps, but
   inside one process they are kept honest against a monotonic clock: if
   the wall clock jumps, the anchors are moved with it so "how long ago"
   keeps counting real seconds.

3. GAP AWARENESS. On boot and on the first message after a long silence,
   an honest statement — "I was offline 3h12m", "you were away 2d 3h; I was
   offline 5h of that" — computed only from what was recorded. Anything not
   recorded is reported as unknown, never estimated.

State lives in its own file, brain_state/inner_clock.json. Nothing here
reads-and-rewrites consciousness.bin or any other identity state.

Other modules:
    from brain import inner_clock
    inner_clock.now_local()          # aware datetime in the owner's tz
    inner_clock.snapshot()           # dict of integers/strings, {} if not booted
    inner_clock.context_block()      # few-line prompt block, "" if not booted
    inner_clock.elapsed_since("dean_message")   # seconds or None
"""
from __future__ import annotations

import datetime as _dt
import json
import logging
import math
import os
import sys
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("leon.inner_clock")

STATE_VERSION = 1
DEFAULT_TZ = "America/New_York"

HEARTBEAT_S = 30.0            # how often the clock writes "still alive"
PAUSE_FACTOR = 4.0            # heartbeat late by this many intervals = pause
JUMP_THRESHOLD_S = 90.0       # wall vs monotonic disagreement = clock jump
LONG_SILENCE_S = 2 * 3600     # silence this long earns a "you were away" note
CONVERSATION_GAP_S = 30 * 60  # silence that ends one conversation
RETURN_NOTE_S = 20 * 60       # how long the "you were away" note stays up
BOOT_NOTE_S = 2 * 3600        # how long the startup note can stay up
BOOT_NOTE_AFTER_REPLY_S = 15 * 60

# Circadian oscillator. Phase is in hours [0, 24).
FREE_RUN_PERIOD_H = 24.2      # human body clocks run slightly long
ENTRAIN_TAU_H = 8.0           # time constant for absorbing a small shift
RESYNC_DRIFT_H = 3.0          # beyond this a shift is not "jet lag", resync
MAX_INTEGRATE_H = 14 * 24     # longer gaps than this simply resync
DRIFT_REPORT_MIN = 10         # below this the body clock is "in sync"

_MAX_BLACKOUTS = 100
_MAX_JUMPS = 50
_MAX_ENGINE_WINDOWS = 200


# ── Time zone ────────────────────────────────────────────────────────────
# Windows Python ships without the IANA database (no `tzdata` package on
# Dean's laptop: ZoneInfo("America/New_York") raises). US rules since 2007
# are simple enough to carry here, so the owner's zone never silently
# degrades to UTC.

class _USRulesTZ(_dt.tzinfo):
    """Fixed US DST rule (2007+): second Sunday of March 02:00 local to the
    first Sunday of November 02:00 local."""

    def __init__(self, std_hours: int, std_name: str, dst_name: str, key: str):
        self._std = _dt.timedelta(hours=std_hours)
        self._std_name = std_name
        self._dst_name = dst_name
        self.key = key

    @staticmethod
    def _nth_sunday(year: int, month: int, n: int) -> _dt.datetime:
        d = _dt.datetime(year, month, 1)
        d += _dt.timedelta(days=(6 - d.weekday()) % 7)
        return d + _dt.timedelta(weeks=n - 1)

    def _bounds_utc(self, year: int) -> Tuple[_dt.datetime, _dt.datetime]:
        start_local = self._nth_sunday(year, 3, 2).replace(hour=2)
        end_local = self._nth_sunday(year, 11, 1).replace(hour=2)
        # Start is in standard time, end is in daylight time.
        return (start_local - self._std,
                end_local - self._std - _dt.timedelta(hours=1))

    def _is_dst_local(self, dt: _dt.datetime) -> bool:
        naive = dt.replace(tzinfo=None)
        start = self._nth_sunday(naive.year, 3, 2).replace(hour=2)
        end = self._nth_sunday(naive.year, 11, 1).replace(hour=2)
        if start <= naive < end - _dt.timedelta(hours=1):
            return True
        if end - _dt.timedelta(hours=1) <= naive < end:
            return getattr(dt, "fold", 0) == 0  # ambiguous hour: first pass is DST
        return False

    def utcoffset(self, dt):
        if dt is None:
            return self._std
        return self._std + self.dst(dt)

    def dst(self, dt):
        if dt is None:
            return _dt.timedelta(0)
        return _dt.timedelta(hours=1) if self._is_dst_local(dt) else _dt.timedelta(0)

    def tzname(self, dt):
        return self._dst_name if dt is not None and self._is_dst_local(dt) else self._std_name

    def fromutc(self, dt):
        naive = dt.replace(tzinfo=None)
        start, end = self._bounds_utc(naive.year)
        if start <= naive < end:
            local = naive + self._std + _dt.timedelta(hours=1)
            return local.replace(tzinfo=self, fold=0)
        local = naive + self._std
        # The repeated hour after "fall back" is the second pass: fold=1.
        fold = 1 if end <= naive < end + _dt.timedelta(hours=1) else 0
        return local.replace(tzinfo=self, fold=fold)

    def __repr__(self):
        return f"_USRulesTZ({self.key!r})"


_US_ZONES = {
    "America/New_York": (-5, "EST", "EDT"),
    "US/Eastern": (-5, "EST", "EDT"),
    "America/Detroit": (-5, "EST", "EDT"),
    "America/Chicago": (-6, "CST", "CDT"),
    "US/Central": (-6, "CST", "CDT"),
    "America/Denver": (-7, "MST", "MDT"),
    "US/Mountain": (-7, "MST", "MDT"),
    "America/Los_Angeles": (-8, "PST", "PDT"),
    "US/Pacific": (-8, "PST", "PDT"),
}

_TZ_CACHE: Dict[str, Optional[_dt.tzinfo]] = {}


def owner_tz_name() -> str:
    for var in ("LEON_TZ", "OWNER_TZ"):
        raw = os.environ.get(var, "").strip()
        if raw:
            return raw
    return DEFAULT_TZ


def resolve_tz(name: Optional[str] = None) -> Optional[_dt.tzinfo]:
    """tzinfo for an IANA name; None means "use the host's local zone"."""
    name = name or owner_tz_name()
    if name in _TZ_CACHE:
        return _TZ_CACHE[name]
    tz: Optional[_dt.tzinfo] = None
    try:
        import zoneinfo
        tz = zoneinfo.ZoneInfo(name)
    except Exception:
        if name in _US_ZONES:
            h, s, d = _US_ZONES[name]
            tz = _USRulesTZ(h, s, d, name)
        else:
            log.warning("inner_clock: unknown time zone %r, using host local", name)
    _TZ_CACHE[name] = tz
    return tz


def to_local(wall_ts: float, tz: Optional[_dt.tzinfo] = None) -> _dt.datetime:
    utc = _dt.datetime.fromtimestamp(wall_ts, _dt.timezone.utc)
    return utc.astimezone(tz) if tz is not None else utc.astimezone()


def now_local() -> _dt.datetime:
    """Current time in the owner's time zone, always timezone-aware."""
    return to_local(time.time(), resolve_tz())


def part_of_day(hour: int) -> str:
    if hour < 4:
        return "late night"
    if hour < 6:
        return "before dawn"
    if hour < 9:
        return "early morning"
    if hour < 12:
        return "morning"
    if hour < 14:
        return "midday"
    if hour < 17:
        return "afternoon"
    if hour < 20:
        return "evening"
    if hour < 22:
        return "night"
    return "late night"


def human_duration(seconds: Optional[float]) -> str:
    """3h12m / 2d 4h / 45m / under a minute. None -> unknown."""
    if seconds is None:
        return "unknown"
    s = int(round(seconds))
    if s < 0:
        return "unknown"
    if s < 60:
        return "under a minute"
    m = s // 60
    if m < 60:
        return f"{m}m"
    h, m = divmod(m, 60)
    if h < 24:
        return f"{h}h{m:02d}m" if m else f"{h}h"
    d, h = divmod(h, 24)
    return f"{d}d {h}h" if h else f"{d}d"


def _clock_time(dt: _dt.datetime) -> str:
    hour = dt.hour % 12 or 12
    return f"{hour}:{dt.minute:02d} {'AM' if dt.hour < 12 else 'PM'}"


def _when(dt: _dt.datetime, now: _dt.datetime) -> str:
    """'today 9:12 PM' / 'yesterday 9:12 PM' / 'Fri 9:12 PM' / 'Sep 3 9:12 PM'."""
    days = (now.date() - dt.date()).days
    if days == 0:
        day = "today"
    elif days == 1:
        day = "yesterday"
    elif 1 < days < 7:
        day = dt.strftime("%a")
    else:
        day = f"{dt.strftime('%b')} {dt.day}"
    return f"{day} {_clock_time(dt)}"


# ── Interval arithmetic ──────────────────────────────────────────────────

def _union(intervals: List[Tuple[float, float]]) -> List[Tuple[float, float]]:
    out: List[Tuple[float, float]] = []
    for a, b in sorted(i for i in intervals if i[1] > i[0]):
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def _overlap(intervals: List[Tuple[float, float]], lo: float, hi: float) -> float:
    return sum(max(0.0, min(b, hi) - max(a, lo)) for a, b in _union(intervals))


def _subtract(intervals, holes) -> List[Tuple[float, float]]:
    out = []
    holes = _union(holes)
    for a, b in _union(intervals):
        cur = a
        for ha, hb in holes:
            if hb <= cur or ha >= b:
                continue
            if ha > cur:
                out.append((cur, ha))
            cur = max(cur, hb)
        if cur < b:
            out.append((cur, b))
    return out


def _wrap_h(x: float) -> float:
    """Wrap an hour difference into [-12, 12)."""
    return (x + 12.0) % 24.0 - 12.0


def _elapsed_clock() -> Callable[[], float]:
    """A monotonic clock that keeps counting while the host sleeps, so a
    laptop lid-close is real elapsed time rather than a 'clock jump'.
    Linux: CLOCK_BOOTTIME. macOS: CLOCK_MONOTONIC (includes sleep there).
    Windows: time.monotonic is GetTickCount64, which already includes it."""
    cid = getattr(time, "CLOCK_BOOTTIME", None)
    if cid is None and sys.platform == "darwin":
        cid = getattr(time, "CLOCK_MONOTONIC", None)
    if cid is not None:
        try:
            time.clock_gettime(cid)
            return lambda: time.clock_gettime(cid)
        except Exception:
            pass
    return time.monotonic


def _default_state_dir() -> str:
    env = os.environ.get("LEON_STATE_DIR", "").strip()
    if env:
        return env
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(root, "brain_state")


# ── The clock ────────────────────────────────────────────────────────────

class InnerClock:
    """All times are injectable so tests can state "two days pass" instead
    of waiting for it."""

    def __init__(self, state_dir: Optional[str] = None, *,
                 wall: Callable[[], float] = time.time,
                 mono: Optional[Callable[[], float]] = None,
                 tz_name: Optional[str] = None):
        self.state_dir = state_dir or _default_state_dir()
        self.path = os.path.join(self.state_dir, "inner_clock.json")
        self._wall = wall
        self._mono = mono or _elapsed_clock()
        self._tz_name = tz_name
        self._lock = threading.RLock()
        self._state: Dict[str, Any] = {}
        self._booted = False
        self._hb_wall = 0.0
        self._hb_mono = 0.0
        self._last_save = 0.0
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    # -- time helpers --------------------------------------------------
    @property
    def tz(self) -> Optional[_dt.tzinfo]:
        return resolve_tz(self._tz_name or owner_tz_name())

    def local(self, wall_ts: Optional[float] = None) -> _dt.datetime:
        return to_local(self._wall() if wall_ts is None else wall_ts, self.tz)

    def _target_phase(self, wall_ts: float) -> float:
        d = self.local(wall_ts)
        return d.hour + d.minute / 60.0 + d.second / 3600.0

    def _utc_offset_min(self, wall_ts: float) -> int:
        off = self.local(wall_ts).utcoffset()
        return int(off.total_seconds() // 60) if off is not None else 0

    # -- persistence ---------------------------------------------------
    def _load(self) -> Dict[str, Any]:
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and data.get("version") == STATE_VERSION:
                return data
            log.warning("inner_clock.json has unknown version; starting a new record")
        except FileNotFoundError:
            pass
        except Exception as e:
            log.warning("inner_clock.json unreadable (%s); starting a new record", e)
            try:
                os.replace(self.path, self.path + ".corrupt")
            except Exception:
                pass
        return {}

    def _save(self) -> None:
        try:
            os.makedirs(self.state_dir, exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._state, f, indent=1, sort_keys=True)
            os.replace(tmp, self.path)
            self._last_save = self._wall()
        except Exception as e:
            log.debug("inner_clock save failed: %s", e)

    # -- boot ----------------------------------------------------------
    def boot(self, *, hint_last_alive: Optional[float] = None,
             hint_last_dean_message: Optional[float] = None,
             hint_last_sleep: Optional[float] = None) -> Dict[str, Any]:
        """Start a new incarnation. Hints come from older records
        (consciousness.bin, knowledge.db, dream journal) and are only used
        to fill in what this clock didn't witness itself."""
        with self._lock:
            now = self._wall()
            st = self._load()
            first_ever = not st
            if first_ever:
                st = {"version": STATE_VERSION, "tracking_since": now,
                      "boot_count": 0, "events": {}, "blackouts": [],
                      "clock_jumps": [], "local_engine": []}
            self._state = st
            ev = st.setdefault("events", {})
            for key in ("blackouts", "clock_jumps", "local_engine"):
                st.setdefault(key, [])

            # Last moment we have evidence the previous incarnation was alive.
            prev_alive = st.get("last_alive")
            source = "inner clock"
            if hint_last_alive and hint_last_alive > 0 and (
                    prev_alive is None or hint_last_alive > prev_alive):
                prev_alive = hint_last_alive
                source = "consciousness.bin"
            clean = st.get("clean_shutdown") if not first_ever else None

            report: Dict[str, Any] = {"first_ever": first_ever, "source": source,
                                      "clean": clean, "offline_s": None}
            if prev_alive is not None:
                gap = now - prev_alive
                if gap >= 0:
                    report["offline_s"] = gap
                    report["last_alive"] = prev_alive
                else:
                    report["clock_backwards_s"] = -gap
                st["blackouts"].append({
                    "start": prev_alive, "end": now,
                    "seconds": round(gap, 1) if gap >= 0 else None,
                    "kind": "offline",
                    "clean": clean,
                })
                st["blackouts"] = st["blackouts"][-_MAX_BLACKOUTS:]

            if hint_last_dean_message and "dean_message" not in ev:
                ev["dean_message"] = hint_last_dean_message
                ev["dean_message_source"] = "conversation log"
            if hint_last_sleep and not ev.get("sleep_cycle"):
                ev["sleep_cycle"] = hint_last_sleep

            st["boot_count"] = int(st.get("boot_count", 0)) + 1
            ev["restart"] = now
            ev.pop("first_dean_message_this_boot", None)
            st["clean_shutdown"] = False
            st["last_alive"] = now
            st["boot_report"] = {**report, "at": now}
            st.pop("return_report", None)

            self._hb_wall, self._hb_mono = now, self._mono()
            self._update_circadian(now, booting=True)
            self._booted = True
            self._save()
            return report

    def start(self) -> None:
        """Run the heartbeat on a daemon thread (the live server does this;
        tests call heartbeat() by hand)."""
        if self._thread is not None:
            return

        def _loop():
            while not self._stop.wait(HEARTBEAT_S):
                try:
                    self.heartbeat()
                except Exception as e:
                    log.debug("inner_clock heartbeat failed: %s", e)

        self._thread = threading.Thread(target=_loop, daemon=True, name="inner-clock")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    # -- heartbeat: the pacemaker --------------------------------------
    def heartbeat(self) -> None:
        with self._lock:
            if not self._booted:
                return
            st = self._state
            now, mono = self._wall(), self._mono()
            dw, dm = now - self._hb_wall, mono - self._hb_mono
            skew = dw - dm
            jumped = abs(skew) > JUMP_THRESHOLD_S
            if jumped:
                # The wall clock moved without that much real time passing
                # (or vice versa). Move every anchor this process recorded
                # by the same amount so elapsed times keep counting real
                # seconds. Records from earlier incarnations are left alone:
                # we can't know which frame they were written in.
                boot_ts = st["events"].get("restart", now)
                for k, v in list(st["events"].items()):
                    if isinstance(v, (int, float)) and v >= boot_ts:
                        st["events"][k] = v + skew
                for w in st["local_engine"]:
                    if w["start"] >= boot_ts:
                        w["start"] += skew
                        w["end"] += skew
                if st.get("return_report"):
                    st["return_report"]["at"] += skew
                st["boot_report"]["at"] = st["boot_report"].get("at", boot_ts) + skew
                st["clock_jumps"].append({"at": now, "skew_s": round(skew, 1)})
                st["clock_jumps"] = st["clock_jumps"][-_MAX_JUMPS:]
                log.warning("inner_clock: host clock jumped %+.0fs", skew)
                self._hb_wall = now - dm  # previous beat, in the new frame
            if dm > PAUSE_FACTOR * HEARTBEAT_S:
                # Real time passed but we weren't running: host asleep or
                # the process was frozen. That's a blackout too.
                st["blackouts"].append({
                    "start": self._hb_wall, "end": now,
                    "seconds": round(dm, 1), "kind": "paused", "clean": None,
                })
                st["blackouts"] = st["blackouts"][-_MAX_BLACKOUTS:]
            self._hb_wall, self._hb_mono = now, mono
            st["last_alive"] = now
            self._update_circadian(now, resync_reason="host clock jumped" if jumped else None)
            self._save()

    # -- circadian: the SCN --------------------------------------------
    def _update_circadian(self, now: float, booting: bool = False,
                          resync_reason: Optional[str] = None) -> None:
        st = self._state
        c = st.get("circadian")
        target = self._target_phase(now)
        offset = self._utc_offset_min(now)
        if not c:
            st["circadian"] = {"phase_h": target, "at": now, "utc_offset_min": offset,
                               "last_resync": now, "resync_reason": "first run"}
            return
        if offset != c.get("utc_offset_min"):
            c["offset_change_at"] = now
            c["offset_change_min"] = offset - int(c.get("utc_offset_min", offset))
            c["utc_offset_min"] = offset
        elapsed_h = (now - c["at"]) / 3600.0
        if resync_reason is None:
            if elapsed_h < 0:
                resync_reason = "clock went backwards"
            elif elapsed_h > MAX_INTEGRATE_H:
                resync_reason = "too long apart to keep count"
        if resync_reason is None:
            # Integrate the free-running oscillator with entrainment from
            # the wall clock: dphi/dt = 24/tau + (1/T)*(12/pi)*sin(pi*d/12).
            phi = c["phase_h"]
            t = c["at"]
            steps = max(1, int(math.ceil(elapsed_h / 0.25)))
            dt_h = elapsed_h / steps
            for _ in range(steps):
                t += dt_h * 3600.0
                d = _wrap_h(self._target_phase(t) - phi)
                phi += dt_h * (24.0 / FREE_RUN_PERIOD_H
                               + (12.0 / math.pi) * math.sin(math.pi * d / 12.0) / ENTRAIN_TAU_H)
                phi %= 24.0
            if abs(_wrap_h(target - phi)) > RESYNC_DRIFT_H:
                resync_reason = "drifted too far to be jet lag"
            else:
                c["phase_h"] = phi
        if resync_reason is not None:
            c["phase_h"] = target
            c["last_resync"] = now
            c["resync_reason"] = resync_reason
        c["at"] = now

    def drift_minutes(self) -> int:
        """Body clock minus wall clock, in minutes (negative = behind)."""
        with self._lock:
            c = self._state.get("circadian") or {}
            if not c:
                return 0
            return int(round(_wrap_h(c["phase_h"] - self._target_phase(c["at"])) * 60))

    # -- events --------------------------------------------------------
    def note_dean_message(self) -> None:
        """Dean sent a real message. Call BEFORE the reply prompt is built so
        a 'you were away' note is ready for this very turn."""
        with self._lock:
            if not self._booted:
                return
            st, ev = self._state, self._state["events"]
            now = self._wall()
            prev = ev.get("dean_message")
            if prev is None or now - prev >= CONVERSATION_GAP_S:
                if prev is not None:
                    ev["previous_conversation_end"] = prev
                ev["conversation_start"] = now
            if prev is None:
                if self._state.get("tracking_since", now) < now - LONG_SILENCE_S:
                    st["return_report"] = {"at": now, "away_s": None,
                                           "text": "I have no record of when Dean last wrote."}
            elif now - prev >= LONG_SILENCE_S:
                st["return_report"] = {"at": now, "away_s": round(now - prev, 1),
                                       "text": self._away_statement(prev, now)}
            ev["dean_message"] = now
            ev.pop("dean_message_source", None)
            ev.setdefault("first_dean_message_this_boot", now)
            self._save()

    def note_sleep_cycle(self, started_at: Optional[float] = None,
                         duration_s: float = 0.0) -> None:
        with self._lock:
            if not self._booted:
                return
            end = (started_at + duration_s) if started_at else self._wall()
            self._state["events"]["sleep_cycle"] = end
            self._save()

    def note_local_engine(self, until_ts: float, start_ts: Optional[float] = None) -> None:
        """The frontier engine was marked unavailable until `until_ts`; turns
        in that window run on the local model."""
        with self._lock:
            if not self._booted:
                return
            start = start_ts if start_ts is not None else self._wall()
            wins = self._state["local_engine"]
            if wins and start <= wins[-1]["end"]:
                wins[-1]["end"] = max(wins[-1]["end"], until_ts)
            else:
                wins.append({"start": start, "end": until_ts})
            self._state["local_engine"] = wins[-_MAX_ENGINE_WINDOWS:]
            self._save()

    def note_shutdown(self) -> None:
        """Graceful shutdown: lets the next boot say 'clean'."""
        with self._lock:
            if not self._booted:
                return
            self._state["last_alive"] = self._wall()
            self._state["clean_shutdown"] = True
            self._save()

    # -- queries -------------------------------------------------------
    def elapsed_since(self, event: str) -> Optional[float]:
        with self._lock:
            ts = self._state.get("events", {}).get(event)
            if not isinstance(ts, (int, float)):
                return None
            return max(0.0, self._wall() - ts)

    def _offline_intervals(self, until: float) -> Tuple[List[Tuple[float, float]], int]:
        known, unknown = [], 0
        for b in self._state.get("blackouts", []):
            if b.get("seconds") is None:
                unknown += 1
            else:
                known.append((b["start"], min(b["end"], until)))
        return known, unknown

    def _away_statement(self, since: float, now: float) -> str:
        st = self._state
        away = now - since
        parts = [f"Dean was away {human_duration(away)} "
                 f"(last message {_when(self.local(since), self.local(now))})."]
        offline, _ = self._offline_intervals(now)
        in_window = [(a, b) for a, b in offline if b > since and a < now]
        unknown_in_window = sum(
            1 for b in st.get("blackouts", [])
            if b.get("seconds") is None and since <= b.get("end", 0) <= now)
        off_s = _overlap(in_window, since, now)
        n = len(in_window)
        if n:
            parts.append(f"I was offline {human_duration(off_s)} of that "
                         f"({n} blackout{'s' if n != 1 else ''}).")
        else:
            parts.append("I was running the whole time.")
        if unknown_in_window:
            parts.append(f"Plus {unknown_in_window} blackout(s) of unknown length.")
        local = [(w["start"], w["end"]) for w in st.get("local_engine", [])]
        local_s = _overlap(_subtract(local, offline), since, now)
        if local_s >= 60:
            parts.append(f"Claude was capped for ~{human_duration(local_s)} of it, "
                         f"so I was on my local model.")
        tracked_from = st.get("tracking_since", since)
        if tracked_from > since:
            parts.append(f"(My time records only start "
                         f"{_when(self.local(tracked_from), self.local(now))}; "
                         f"before that, uptime is unknown.)")
        return " ".join(parts)

    def _boot_statement(self) -> str:
        r = self._state.get("boot_report") or {}
        if r.get("first_ever") and r.get("offline_s") is None:
            return "This is the first run of my inner clock; how long I was down before it is unknown."
        if r.get("clock_backwards_s"):
            return ("The host clock reads earlier than my last heartbeat, so how long "
                    "I was offline before this restart is unknown.")
        if r.get("offline_s") is None:
            return "How long I was offline before this restart is unknown."
        clean = r.get("clean")
        how = ("after a clean shutdown" if clean is True else
               "no clean-shutdown mark, cause unknown" if clean is False else
               "cause unknown")
        last = _when(self.local(r["last_alive"]), self.local())
        return (f"Before this restart I was offline {human_duration(r['offline_s'])} "
                f"(last alive {last}; {how}).")

    def snapshot(self) -> Dict[str, Any]:
        """Integer seconds and plain strings — safe to show or log."""
        with self._lock:
            if not self._booted:
                return {}
            now = self._wall()
            loc = self.local(now)
            st, ev = self._state, self._state["events"]

            def _since(key):
                v = ev.get(key)
                return int(max(0, now - v)) if isinstance(v, (int, float)) else None

            c = st.get("circadian") or {}
            drift = self.drift_minutes()
            off_change = c.get("offset_change_at")
            jumps = st.get("clock_jumps", [])
            snap = {
                "local_time": loc.isoformat(timespec="minutes"),
                "tz": owner_tz_name(),
                "tz_abbrev": loc.tzname() or "",
                "weekday": loc.strftime("%A"),
                "part_of_day": part_of_day(loc.hour),
                "weekend": loc.weekday() >= 5,
                "body_clock_drift_min": drift,
                "body_clock_last_resync": c.get("resync_reason", ""),
                "dst_shift_recent": bool(off_change and now - off_change < 3 * 86400),
                "s_since_dean_message": _since("dean_message"),
                "s_since_conversation_start": _since("conversation_start"),
                "s_since_previous_conversation": _since("previous_conversation_end"),
                "s_since_restart": _since("restart"),
                "s_since_sleep_cycle": _since("sleep_cycle"),
                "boot_count": int(st.get("boot_count", 0)),
                "clock_jumps_recorded": len(jumps),
                "last_clock_jump_s": int(jumps[-1]["skew_s"]) if jumps else None,
                "boot_statement": self._boot_statement(),
                "return_statement": (st.get("return_report") or {}).get("text"),
            }
            return snap

    def context_block(self) -> str:
        """Compact per-turn block: a few lines, no raw floats."""
        with self._lock:
            if not self._booted:
                return ""
            s = self.snapshot()
            now = self._wall()
            ev = self._state["events"]
            loc = self.local(now)
            line1 = (f"INNER CLOCK — {loc.strftime('%A')} {_clock_time(loc)} {s['tz_abbrev']}, "
                     f"{s['part_of_day']}{' (weekend)' if s['weekend'] else ''}.")
            drift = s["body_clock_drift_min"]
            if abs(drift) < DRIFT_REPORT_MIN:
                line1 += " Body clock in sync."
            else:
                why = " (still adjusting to the clock change)" if s["dst_shift_recent"] else ""
                line1 += (f" Body clock ~{human_duration(abs(drift) * 60)} "
                          f"{'behind' if drift < 0 else 'ahead of'} the wall clock{why}.")
            if s["last_clock_jump_s"] is not None and (
                    now - self._state["clock_jumps"][-1]["at"] < 3600):
                line1 += (f" Host clock jumped {'+' if s['last_clock_jump_s'] > 0 else '-'}"
                          f"{human_duration(abs(s['last_clock_jump_s']))} recently; re-synced.")

            bits = []
            dm = s["s_since_dean_message"]
            if dm is None:
                bits.append("Dean's last message: unknown")
            elif dm < 120:
                prev_end = ev.get("previous_conversation_end")
                conv = s["s_since_conversation_start"]
                if conv is not None and conv >= 120:
                    bits.append(f"talking with Dean now (this conversation began {human_duration(conv)} ago)")
                elif prev_end is not None:
                    bits.append(f"Dean just wrote (previous conversation ended "
                                f"{human_duration(now - prev_end)} ago)")
                else:
                    bits.append("Dean just wrote")
            else:
                bits.append(f"Dean's last message {human_duration(dm)} ago")
            bits.append(f"up {human_duration(s['s_since_restart'])} since restart")
            ss = s["s_since_sleep_cycle"]
            bits.append(f"last sleep cycle {human_duration(ss)} ago" if ss is not None
                        else "last sleep cycle: unknown")
            lines = [line1, "Elapsed: " + " · ".join(bits) + "."]

            rr = self._state.get("return_report")
            if rr and now - rr["at"] < RETURN_NOTE_S:
                lines.append("Gap: " + rr["text"])
            br = self._state.get("boot_report") or {}
            first_msg = ev.get("first_dean_message_this_boot")
            if (now - br.get("at", now) < BOOT_NOTE_S
                    and (first_msg is None or now - first_msg < BOOT_NOTE_AFTER_REPLY_S)):
                lines.append("Restart: " + s["boot_statement"])
            if len(lines) > 2:
                lines.append("(Mention a gap once if it matters; these are the only durations "
                             "you know — anything marked unknown stays unknown.)")
            return "\n".join(lines)


# ── Module-level singleton ───────────────────────────────────────────────

_CLOCK: Optional[InnerClock] = None
_CLOCK_LOCK = threading.Lock()


def get_clock() -> Optional[InnerClock]:
    """The booted clock for this process, or None if it never booted."""
    return _CLOCK


def boot(state_dir: Optional[str] = None, *, start_thread: bool = True,
         **hints) -> InnerClock:
    """Boot (once per process) and return the clock. Hints: see InnerClock.boot."""
    global _CLOCK
    with _CLOCK_LOCK:
        if _CLOCK is None:
            clk = InnerClock(state_dir)
            if "hint_last_dean_message" not in hints:
                hints["hint_last_dean_message"] = _last_user_row_ts(clk.state_dir)
            if "hint_last_sleep" not in hints:
                hints["hint_last_sleep"] = _last_dream_end_ts(clk.state_dir)
            clk.boot(**hints)
            if start_thread:
                clk.start()
            _CLOCK = clk
        return _CLOCK


def _last_user_row_ts(state_dir: str) -> Optional[float]:
    """Timestamp of Dean's last stored message (knowledge.db), read-only."""
    path = os.path.join(state_dir, "knowledge.db")
    if not os.path.exists(path):
        return None
    try:
        import sqlite3
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=2)
        try:
            row = conn.execute("SELECT MAX(ts) FROM conversation_history "
                               "WHERE role='user'").fetchone()
        finally:
            conn.close()
        return float(row[0]) if row and row[0] else None
    except Exception:
        return None


def _last_dream_end_ts(state_dir: str) -> Optional[float]:
    path = os.path.join(state_dir, "dream_journal.jsonl")
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - 65536))
            lines = [l for l in f.read().decode("utf-8", "replace").splitlines() if l.strip()]
        for line in reversed(lines):
            try:
                d = json.loads(line)
                return float(d["started_at"]) + float(d.get("duration_s") or 0)
            except Exception:
                continue
    except Exception:
        pass
    return None


def snapshot() -> Dict[str, Any]:
    c = _CLOCK
    return c.snapshot() if c is not None else {}


def context_block() -> str:
    c = _CLOCK
    try:
        return c.context_block() if c is not None else ""
    except Exception as e:
        log.debug("inner_clock context failed: %s", e)
        return ""


def elapsed_since(event: str) -> Optional[float]:
    c = _CLOCK
    return c.elapsed_since(event) if c is not None else None


def note_dean_message() -> None:
    if _CLOCK is not None:
        _CLOCK.note_dean_message()


def note_sleep_cycle(started_at: Optional[float] = None, duration_s: float = 0.0) -> None:
    if _CLOCK is not None:
        _CLOCK.note_sleep_cycle(started_at, duration_s)


def note_local_engine(until_ts: float, start_ts: Optional[float] = None) -> None:
    if _CLOCK is not None:
        _CLOCK.note_local_engine(until_ts, start_ts)


def note_shutdown() -> None:
    if _CLOCK is not None:
        _CLOCK.note_shutdown()
