"""
Cooperative cancellation for one inference call (Leon V2 Phase 3).

A :class:`CancelToken` travels with one ``respond_streaming`` call down into
the local model stream loops. Two things listen to it:

* the stream loops check :meth:`CancelToken.is_set` between events (the
  normal, cooperative path);
* the local HTTP transport registers a callback that shuts the socket down,
  so a generation that is blocked mid-read (prompt evaluation can be tens of
  seconds without a byte) ends immediately and Ollama frees its single slot.

Nothing here knows about the scheduler, the responder or the network. The
token is inert until someone calls :meth:`cancel`; a call that is never
cancelled behaves exactly as before the token existed.

Stdlib only. Importing this module has no side effects.
"""
from __future__ import annotations

import inspect
import threading
import time
from typing import Any, Callable, List, Optional

__all__ = ["CancelToken", "call_with_cancel", "UnsupportedInferencePolicy"]


class UnsupportedInferencePolicy(ValueError):
    """The selected transport cannot enforce the requested inference policy."""


class CancelToken:
    """One-shot cancellation signal with callbacks.

    * :meth:`cancel` is idempotent; only the first call records the reason
      and runs the callbacks (outside the internal lock, exceptions swallowed).
    * :meth:`add_callback` on an already-cancelled token runs the callback at
      once, so a transport that registers late still gets closed.
    * Callbacks run synchronously and must return promptly.
    """

    __slots__ = ("_ev", "_mu", "_cbs", "reason", "cancelled_mono")

    def __init__(self) -> None:
        self._ev = threading.Event()
        self._mu = threading.Lock()
        self._cbs: List[Callable[[str], Any]] = []
        self.reason: Optional[str] = None
        self.cancelled_mono: Optional[float] = None

    def is_set(self) -> bool:
        return self._ev.is_set()

    def wait(self, timeout: Optional[float] = None) -> bool:
        return self._ev.wait(timeout)

    def cancel(self, reason: str = "cancelled") -> bool:
        """Signal cancellation. Returns True only for the call that set it."""
        with self._mu:
            if self._ev.is_set():
                return False
            self.reason = str(reason or "cancelled")[:64]
            self.cancelled_mono = time.monotonic()
            self._ev.set()
            cbs, self._cbs = self._cbs, []
        for cb in cbs:
            try:
                cb(self.reason)
            except Exception:
                pass
        return True

    def add_callback(self, fn: Callable[[str], Any]) -> Callable[[], None]:
        """Run ``fn(reason)`` on cancellation. Returns a remover."""
        with self._mu:
            if not self._ev.is_set():
                self._cbs.append(fn)

                def _remove() -> None:
                    with self._mu:
                        try:
                            self._cbs.remove(fn)
                        except ValueError:
                            pass
                return _remove
        try:
            fn(self.reason or "cancelled")
        except Exception:
            pass
        return lambda: None

    def __repr__(self) -> str:  # never shows anything but the state
        return f"CancelToken(set={self._ev.is_set()}, reason={self.reason!r})"


def call_with_cancel(fn: Callable[..., Any], *args: Any,
                     cancel_token: Optional[CancelToken] = None, **kwargs: Any) -> Any:
    """Call ``fn`` with ``cancel_token=`` when it accepts one, else without.

    Inspect compatibility before invoking the provider. Never retry a call
    after TypeError: it may have already performed work before raising.
    """
    if cancel_token is not None:
        try:
            signature = inspect.signature(fn)
        except (TypeError, ValueError):
            # Opaque callables get the current API; failure must remain a
            # single failed call, rather than possibly repeating its effects.
            return fn(*args, cancel_token=cancel_token, **kwargs)
        parameter = signature.parameters.get("cancel_token")
        accepts_token = (parameter is not None and parameter.kind in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY))
        accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD
                             for p in signature.parameters.values())
        if accepts_token or accepts_kwargs:
            return fn(*args, cancel_token=cancel_token, **kwargs)
    return fn(*args, **kwargs)
