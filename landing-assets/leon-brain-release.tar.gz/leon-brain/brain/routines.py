"""
Proactive routines — Leon's JARVIS layer.

Scheduled and event-triggered actions that Leon performs without being
asked. Lives alongside reminders.py but is a different beast:

  reminders.py = one-shot user-requested timers
  routines.py  = recurring/conditional autonomous behaviours

Each routine owns:
  - a schedule string ("0 7 *" cron-lite, or "every 30m") OR
  - a trigger string ("idle:15m", "window_focus_changed:>30m", ...)
  - an action callable that receives a RoutineContext

The scheduler runs in a daemon thread. Every 30s it:
  1. Re-evaluates idle / window-focus state and fires matching triggers.
  2. Walks every routine, checks `should_run_at(now)`, dispatches due ones.
  3. Persists run/error counters to brain_state/routines.json.

Audit lines append to brain_state/routines-audit.jsonl — one JSON per
firing so we can grep "what fired and why".

Defensive contract: a routine that raises NEVER kills the scheduler. We
catch, log, increment error_count, store last_error, and move on.

Public API (see bottom of file):

    sched = start_routine_scheduler(brain_responder,
                                    actuator_call,
                                    knowledge_search,
                                    notify)
    routine_list()
    routine_enable(name) / routine_disable(name)
    routine_run_now(name)
    routine_add_custom(name, schedule, action, description)
    routine_remove(name)
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
import traceback
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional


# ── Paths ────────────────────────────────────────────────────────────────
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_STATE_DIR = os.path.join(_PROJECT_ROOT, "brain_state")
_PERSIST_PATH = os.path.join(_STATE_DIR, "routines.json")
_AUDIT_PATH = os.path.join(_STATE_DIR, "routines-audit.jsonl")
_ACTUATOR_AUDIT_PATH = os.path.join(_STATE_DIR, "actuator-audit.jsonl")


# ── Context passed to every routine action ──────────────────────────────
class RoutineContext:
    """Bundle of facilities a routine can reach for.

    Each field is intentionally a small callable so the routine code stays
    independent of the rest of the codebase — useful for tests and for
    Dean spawning custom routines at runtime.
    """

    def __init__(
        self,
        brain_responder: Any,
        actuator_call: Callable[[str, Dict[str, Any]], Dict[str, Any]],
        knowledge_search: Callable[[str], List[Dict[str, Any]]],
        notify: Callable[..., None],
        tts_for_text: Optional[Callable[[str], Any]] = None,
        broadcast: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        self.brain = brain_responder
        self.act = actuator_call
        self.search = knowledge_search
        self._notify = notify
        self._tts = tts_for_text
        self._broadcast = broadcast
        # Free-form scratchpad — each routine can stash whatever it needs
        # across runs (e.g. last-meeting id seen, last error fingerprint).
        self.scratch: Dict[str, Any] = {}

    # ── Convenience wrappers ────────────────────────────────────────
    def notify(self, title: str, body: str, urgency: str = "normal") -> None:
        """Best-effort desktop notification. Routes through actuator if
        we have one, otherwise prints. Wrapped so callers never deal
        with NoneType."""
        try:
            if callable(self._notify):
                # Two notify shapes exist in the codebase — the actuator
                # `notify` tool wants a dict, _broadcast_threadsafe wants
                # a message dict. We support both via duck-typing.
                self._notify({
                    "title": title,
                    "body": body,
                    "urgency": urgency,
                })
                return
        except Exception as e:
            print(f"[ROUTINE] notify failed: {e}")
        print(f"[ROUTINE] {title}: {body}")

    def say(self, text: str) -> None:
        """Speak via TTS. If TTS isn't wired, falls back to notify().

        We call _tts (which returns a base64 wav payload) and ship it
        through the broadcast channel so the dashboard plays it — same
        path brain_response uses.
        """
        if not text:
            return
        played = False
        try:
            if callable(self._tts) and callable(self._broadcast):
                payload = self._tts(text)
                if payload:
                    self._broadcast({
                        "type": "brain_response",
                        "text": text,
                        "source": "routine",
                        "audio": payload,
                    })
                    played = True
        except Exception as e:
            print(f"[ROUTINE] tts failed: {e}")
        if not played:
            # Fall back to notify so Dean still sees the message.
            self.notify("Leon", text, "normal")

    def safe_act(self, tool: str, args: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Call a brain-local tool if available, else fall through to the
        actuator. Uniform 'ok' shape.

        Local-first routing matters because brain-side tools (vision_describe,
        memory_*, cal_*, email_*, http_request, …) live in
        `brain_responder.local_tools` and aren't known to the PC actuator.
        Routing them to the actuator gets "unknown tool" and floods the audit
        log — that's the catalog-drift bug observed 2026-06-09.

        SELF-REVIEW FIX (2026-08-21): scheduled routines (_action_email_triage,
        _action_calendar_prep, _action_error_spotter, …) call this on every
        tick with zero regard for tool_health — the "Phase 13 Tool Immune
        System" tracks broken/degraded status per tool but was only ever
        consulted by the Executive for interactive suggestions, never by
        these background ticks. Result: vision_describe, cal_next_event, and
        email_gmail_search kept showing up broken in nearly every episode
        window for days, because a routine fired them again every cycle
        regardless of yesterday's failure. Backoff-gate broken tools here:
        skip the real call (no wasted latency/log noise) unless it's been
        long enough since the last observed failure to be worth a retry —
        that retry is still allowed through, so a tool that actually gets
        fixed recovers on its own instead of staying gated forever."""
        _COOLDOWN_S = 1800.0  # 30 min between retries of a known-broken tool
        try:
            from brain.cognition.tool_health import ToolHealth, STATUS_BROKEN
            th = ToolHealth()
            stats = th.get(tool)
            if stats is not None and stats.status == STATUS_BROKEN:
                last_fail = stats.last_failure_ts or 0.0
                if (time.time() - last_fail) < _COOLDOWN_S:
                    return {"ok": False, "error": f"skipped — {tool} marked broken "
                            f"(cooldown {int(_COOLDOWN_S - (time.time() - last_fail))}s left)",
                            "skipped_broken": True}
        except Exception:
            pass  # tool_health unavailable — fail open, call as before
        # 1. Brain-local tools (registered via init_brain into responder.local_tools).
        # `local_tools` is a _LazyToolDict subclass — most tools are lazy-loaded
        # on first access via __missing__. `tool in dict` does NOT trigger
        # __missing__, so we must use dict[key] with try/except KeyError to
        # let the lazy loader fire. This is how email_*, cal_*, finance_*,
        # smart_home_*, etc. tools come alive on first call.
        local_tools = getattr(self.brain, "local_tools", None)
        if isinstance(local_tools, dict):
            try:
                fn = local_tools[tool]
            except KeyError:
                fn = None
            if callable(fn):
                try:
                    res = fn(args or {})
                    if isinstance(res, dict):
                        return res
                    return {"ok": True, "result": res}
                except Exception as e:
                    return {"ok": False, "error": str(e)}
        # 2. Fall through to the PC actuator (hands/body)
        if not callable(self.act):
            return {"ok": False, "error": "actuator not wired"}
        try:
            res = self.act(tool, args or {})
            if isinstance(res, dict):
                return res
            return {"ok": True, "result": res}
        except Exception as e:
            return {"ok": False, "error": str(e)}


# ── Routine dataclass ───────────────────────────────────────────────────
@dataclass
class Routine:
    name: str
    description: str
    enabled: bool = True
    schedule: Optional[str] = None    # "0 7 *" / "every 30m" / "0 */2 8-22"
    trigger: Optional[str] = None     # "idle:15m" / "window_focus_changed:>30m"
    # action stored separately from dataclass fields so it isn't asdict()'d.
    last_run: Optional[float] = None
    run_count: int = 0
    error_count: int = 0
    last_error: Optional[str] = None
    # Minimum gap (seconds) between consecutive firings, regardless of
    # what schedule/trigger says. Prevents loops from spam-firing.
    min_interval_s: float = 0.0
    # Internal — populated at registration time; never persisted.
    action: Optional[Callable[[RoutineContext, "Routine"], None]] = field(
        default=None, repr=False, compare=False,
    )

    def is_custom(self) -> bool:
        return getattr(self, "_custom", False)

    def to_state_dict(self) -> Dict[str, Any]:
        """Persistable subset (skip action callable)."""
        return {
            "name": self.name,
            "description": self.description,
            "enabled": self.enabled,
            "schedule": self.schedule,
            "trigger": self.trigger,
            "last_run": self.last_run,
            "run_count": self.run_count,
            "error_count": self.error_count,
            "last_error": self.last_error,
            "min_interval_s": self.min_interval_s,
        }


# ── Schedule parsing ─────────────────────────────────────────────────────
_EVERY_RE = re.compile(r"^\s*every\s+(\d+)\s*([smhd])\s*$", re.IGNORECASE)


def _parse_every(spec: str) -> Optional[float]:
    m = _EVERY_RE.match(spec or "")
    if not m:
        return None
    n = int(m.group(1))
    unit = m.group(2).lower()
    return n * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]


def _cron_field_matches(value: int, field: str) -> bool:
    """Match one numeric field against a cron-lite spec.

    Supports:
      *          → always
      N          → exact
      A-B        → range inclusive
      */K        → every K (starting at 0)
      A,B,C      → list of any of the above
    """
    field = (field or "").strip()
    if field == "" or field == "*":
        return True
    for part in field.split(","):
        part = part.strip()
        if part == "*":
            return True
        if part.startswith("*/"):
            try:
                step = int(part[2:])
                if step > 0 and value % step == 0:
                    return True
            except ValueError:
                pass
            continue
        if "-" in part:
            try:
                a, b = part.split("-", 1)
                if int(a) <= value <= int(b):
                    return True
            except ValueError:
                pass
            continue
        try:
            if int(part) == value:
                return True
        except ValueError:
            pass
    return False


def _cron_matches(spec: str, now: datetime) -> bool:
    """Cron-lite match: 'MM HH DOW' (3 fields) OR 'MM HH DOM' style.

    We treat the third field as day-of-week (0=Mon ... 6=Sun) when it
    looks like one (single digit ≤6 or "*"). Otherwise day-of-month.
    For routines we don't need second/year granularity.
    """
    parts = (spec or "").split()
    if len(parts) < 2 or len(parts) > 3:
        return False
    minute_f = parts[0]
    hour_f = parts[1]
    third = parts[2] if len(parts) == 3 else "*"
    if not _cron_field_matches(now.minute, minute_f):
        return False
    if not _cron_field_matches(now.hour, hour_f):
        return False
    # weekday() = 0..6 Mon-Sun
    return _cron_field_matches(now.weekday(), third)


def _should_fire_schedule(r: Routine, now_ts: float, last_tick_ts: float) -> bool:
    """Decide whether a scheduled routine wants to fire on this tick.

    `last_tick_ts` is the wall-clock time of the *previous* scheduler
    tick — we use the (last_tick_ts, now_ts] window so we don't fire
    twice for the same minute even if the tick interval drifts a hair.
    """
    if not r.schedule:
        return False
    every_s = _parse_every(r.schedule)
    if every_s is not None:
        if r.last_run is None:
            return True
        return (now_ts - r.last_run) >= every_s
    # cron path — walk every minute boundary in the (last, now] window
    # and check if any of them matches. In practice the window is ≤60s
    # so this is cheap.
    if last_tick_ts <= 0:
        last_tick_ts = now_ts - 60
    # Step by 60s so we don't miss a minute on a slow tick. Cap iterations.
    cursor = max(last_tick_ts + 1, now_ts - 600)
    iterations = 0
    while cursor <= now_ts and iterations < 30:
        dt = datetime.fromtimestamp(cursor)
        if _cron_matches(r.schedule, dt):
            # Avoid firing twice in the same minute.
            if r.last_run is None or (now_ts - r.last_run) > 50:
                return True
        cursor += 60
        iterations += 1
    return False


# ── Idle / window-focus probes ──────────────────────────────────────────
def _idle_seconds() -> Optional[float]:
    """Seconds since last user input. Uses xprintidle if available,
    else falls back to actuator-audit.jsonl mtime as a proxy (a tool
    fire counts as 'activity'). Returns None if neither works."""
    xp = shutil.which("xprintidle")
    if xp:
        try:
            out = subprocess.run(
                [xp], capture_output=True, text=True, timeout=2,
            )
            if out.returncode == 0:
                return float(out.stdout.strip()) / 1000.0
        except Exception:
            pass
    try:
        st = os.stat(_ACTUATOR_AUDIT_PATH)
        return max(0.0, time.time() - st.st_mtime)
    except Exception:
        return None


def _active_window_title() -> Optional[str]:
    """Best-effort current window title via xdotool."""
    xd = shutil.which("xdotool")
    if not xd:
        return None
    try:
        wid = subprocess.run(
            [xd, "getactivewindow"], capture_output=True, text=True, timeout=2,
        )
        if wid.returncode != 0:
            return None
        win_id = wid.stdout.strip()
        if not win_id:
            return None
        name = subprocess.run(
            [xd, "getwindowname", win_id], capture_output=True, text=True, timeout=2,
        )
        if name.returncode == 0:
            return name.stdout.strip()
    except Exception:
        return None
    return None


_TRIG_RE = re.compile(
    r"^(?P<kind>[a-zA-Z_]+):(?P<op>>=|>|<|=)?(?P<arg>.+)$",
)


def _parse_duration_arg(arg: str) -> Optional[float]:
    """Tiny duration parser — '15m' / '30s' / '2h'. Returns seconds."""
    m = re.match(r"^\s*(\d+(?:\.\d+)?)\s*([smhd])?\s*$", arg or "")
    if not m:
        return None
    n = float(m.group(1))
    u = (m.group(2) or "s").lower()
    return n * {"s": 1, "m": 60, "h": 3600, "d": 86400}[u]


# ── Scheduler ───────────────────────────────────────────────────────────
class RoutineScheduler:
    """Background daemon thread that fires routines on schedule + events."""

    TICK_SECONDS = 30

    def __init__(self, context: RoutineContext):
        self.ctx = context
        self._lock = threading.Lock()
        self._routines: Dict[str, Routine] = {}
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_tick = 0.0
        # Trigger state we track across ticks
        self._last_active_window: Optional[str] = None
        self._active_window_since: float = time.time()
        self._last_focus_alert_ts: float = 0.0
        self._was_idle: bool = False
        # Reload persisted counters before anyone registers actions.
        self._persisted_state = self._load_persisted()

    # ── Registration ────────────────────────────────────────────────
    def register(self, routine: Routine) -> None:
        with self._lock:
            # Preserve persisted counters if we've seen this name before.
            prev = self._persisted_state.get(routine.name)
            if prev:
                routine.last_run = prev.get("last_run", routine.last_run)
                routine.run_count = prev.get("run_count", routine.run_count)
                routine.error_count = prev.get("error_count", routine.error_count)
                routine.last_error = prev.get("last_error", routine.last_error)
                # Respect user-toggled enabled state across restarts.
                if "enabled" in prev:
                    routine.enabled = bool(prev["enabled"])
            self._routines[routine.name] = routine
        self._save()

    def unregister(self, name: str) -> bool:
        with self._lock:
            if name not in self._routines:
                return False
            del self._routines[name]
        self._save()
        return True

    def get(self, name: str) -> Optional[Routine]:
        with self._lock:
            return self._routines.get(name)

    def list(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [r.to_state_dict() for r in self._routines.values()]

    def set_enabled(self, name: str, enabled: bool) -> bool:
        with self._lock:
            r = self._routines.get(name)
            if r is None:
                return False
            r.enabled = bool(enabled)
        self._save()
        return True

    # ── Persistence ────────────────────────────────────────────────
    def _load_persisted(self) -> Dict[str, Dict[str, Any]]:
        if not os.path.exists(_PERSIST_PATH):
            return {}
        try:
            with open(_PERSIST_PATH) as f:
                payload = json.load(f)
            return {r["name"]: r for r in payload.get("routines", []) if "name" in r}
        except Exception as e:
            print(f"[ROUTINE] load failed: {e}")
            return {}

    def _save(self) -> None:
        try:
            os.makedirs(_STATE_DIR, exist_ok=True)
            tmp = _PERSIST_PATH + ".tmp"
            with self._lock:
                rows = [r.to_state_dict() for r in self._routines.values()]
            with open(tmp, "w") as f:
                json.dump({"routines": rows}, f, indent=2)
            os.replace(tmp, _PERSIST_PATH)
        except Exception as e:
            print(f"[ROUTINE] save failed: {e}")

    def _audit(self, routine_name: str, ok: bool, duration_s: float,
               error: Optional[str] = None, reason: str = "") -> None:
        try:
            os.makedirs(_STATE_DIR, exist_ok=True)
            row = {
                "ts": time.time(),
                "routine": routine_name,
                "ok": bool(ok),
                "duration_s": round(duration_s, 4),
                "reason": reason,
            }
            if error:
                row["error"] = error
            with open(_AUDIT_PATH, "a") as f:
                f.write(json.dumps(row) + "\n")
            # Rotate: cap at 5K lines
            try:
                with open(_AUDIT_PATH, "r") as f:
                    lines = f.readlines()
                if len(lines) > 5000:
                    with open(_AUDIT_PATH, "w") as f:
                        f.writelines(lines[-2500:])
            except Exception:
                pass
        except Exception as e:
            print(f"[ROUTINE] audit write failed: {e}")

    # ── Firing ─────────────────────────────────────────────────────
    def fire(self, name: str, reason: str = "manual") -> Dict[str, Any]:
        """Run a routine immediately. Returns {ok, error?, duration_s}."""
        r = self.get(name)
        if r is None:
            return {"ok": False, "error": f"no such routine: {name}"}
        return self._invoke(r, reason=reason, ignore_disabled=True)

    def _invoke(self, r: Routine, reason: str, ignore_disabled: bool = False) -> Dict[str, Any]:
        if not ignore_disabled and not r.enabled:
            return {"ok": False, "error": "disabled"}
        if r.action is None:
            return {"ok": False, "error": "no action bound"}
        # Respect min_interval_s
        now = time.time()
        if r.last_run is not None and r.min_interval_s > 0:
            if (now - r.last_run) < r.min_interval_s:
                return {"ok": False, "error": "min_interval not met"}
        t0 = time.time()
        ok = True
        err: Optional[str] = None
        try:
            r.action(self.ctx, r)
        except Exception as e:
            ok = False
            err = f"{type(e).__name__}: {e}"
            print(f"[ROUTINE] {r.name} raised: {err}")
            traceback.print_exc()
        dur = time.time() - t0
        with self._lock:
            r.last_run = time.time()
            r.run_count += 1
            if not ok:
                r.error_count += 1
                r.last_error = err
        self._save()
        self._audit(r.name, ok, dur, error=err, reason=reason)
        return {"ok": ok, "error": err, "duration_s": dur}

    # ── Triggers ───────────────────────────────────────────────────
    def _evaluate_triggers(self) -> List[tuple]:
        """Return list of (routine, reason) tuples to fire from triggers."""
        to_fire: List[tuple] = []
        now = time.time()
        idle = _idle_seconds()
        title = _active_window_title()

        # Track active window
        if title and title != self._last_active_window:
            self._last_active_window = title
            self._active_window_since = now
        focus_duration = now - self._active_window_since if title else 0.0

        with self._lock:
            for r in self._routines.values():
                if not r.enabled or not r.trigger:
                    continue
                m = _TRIG_RE.match(r.trigger)
                if not m:
                    continue
                kind = m.group("kind").lower()
                op = m.group("op") or ">="
                arg = m.group("arg")

                if kind == "idle":
                    threshold = _parse_duration_arg(arg) or 0.0
                    if idle is None:
                        continue
                    crossed = (idle >= threshold) if op in (">=", ">") else (idle < threshold)
                    # Edge-triggered: only fire on the transition to idle
                    # so it doesn't fire every tick once idle.
                    if crossed and not self._was_idle:
                        to_fire.append((r, f"idle:{int(idle)}s"))
                    self._was_idle = bool(crossed)

                elif kind == "window_focus_changed":
                    threshold = _parse_duration_arg(arg) or 1800.0
                    if focus_duration < threshold or not title:
                        continue
                    # Don't fire more than once per hour AND not faster
                    # than r.min_interval_s.
                    if (now - self._last_focus_alert_ts) < 3600:
                        continue
                    self._last_focus_alert_ts = now
                    to_fire.append((r, f"focus:{title[:60]} {int(focus_duration)}s"))

                elif kind == "screen_text_appeared":
                    # We can't evaluate this passively here — error_spotter
                    # owns its own vision call. Skip; it's schedule-driven.
                    continue

        return to_fire

    # ── Main loop ──────────────────────────────────────────────────
    def _loop(self) -> None:
        print(f"[ROUTINE] scheduler tick={self.TICK_SECONDS}s "
              f"({len(self._routines)} routines)")
        # First tick after a short delay so the rest of the server has
        # time to finish init.
        self._stop.wait(timeout=5.0)
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                print(f"[ROUTINE] tick error: {e}")
                traceback.print_exc()
            self._stop.wait(timeout=self.TICK_SECONDS)

    def _tick(self) -> None:
        now = time.time()
        last_tick = self._last_tick
        self._last_tick = now
        # 1. Scheduled routines
        with self._lock:
            scheduled = [
                r for r in self._routines.values()
                if r.enabled and r.schedule and _should_fire_schedule(r, now, last_tick)
            ]
        for r in scheduled:
            self._invoke(r, reason=f"schedule:{r.schedule}")
        # 2. Triggered routines
        for r, reason in self._evaluate_triggers():
            self._invoke(r, reason=reason)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="routine-scheduler",
        )
        self._thread.start()
        print(f"[ROUTINE] started ({len(self._routines)} routines)")

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3.0)
            self._thread = None


# ════════════════════════════════════════════════════════════════════════
#  BUILT-IN ROUTINES
# ════════════════════════════════════════════════════════════════════════
#
# All action signatures: (ctx: RoutineContext, r: Routine) -> None
# They're written defensively — if a downstream tool isn't wired the
# routine logs/notifies a placeholder instead of crashing.

def _action_morning_briefing(ctx: RoutineContext, r: Routine) -> None:
    lines: List[str] = []

    # Calendar
    cal = ctx.safe_act("cal_events_today", {})
    if cal.get("ok"):
        events = cal.get("result", {}).get("events") or cal.get("events") or []
        if events:
            lines.append(f"You have {len(events)} events today.")
            for e in events[:3]:
                t = e.get("start_time") or e.get("start") or "?"
                title = e.get("title") or e.get("summary") or "(untitled)"
                lines.append(f"At {t}: {title}.")
        else:
            lines.append("Your calendar is clear today.")
    else:
        lines.append("Calendar isn't wired yet — I can't see your day.")

    # Weather — placeholder. Expected shape from wttr.in/<city>?format=j1:
    #   { "current_condition": [{"temp_C": "18", "weatherDesc": [{"value": "Sunny"}]}],
    #     "weather": [{"hourly": [...]}] }
    weather = ctx.safe_act("http_request", {
        "url": "https://wttr.in/?format=j1",
        "method": "GET",
        "timeout": 5,
    })
    if weather.get("ok"):
        try:
            body = weather.get("result", {}).get("body") or weather.get("body")
            if isinstance(body, str):
                body = json.loads(body)
            cc = (body or {}).get("current_condition", [{}])[0]
            desc = (cc.get("weatherDesc") or [{}])[0].get("value", "?")
            temp = cc.get("temp_C", "?")
            lines.append(f"It's {desc.lower()}, {temp} degrees.")
        except Exception:
            lines.append("Weather data came back malformed — skipping.")
    else:
        lines.append("Weather feed not available; skipping forecast.")

    # Urgent emails
    mail = ctx.safe_act("email_gmail_search", {"query": "is:unread newer_than:1d", "max_results": 10})
    if mail.get("ok"):
        msgs = mail.get("result", {}).get("messages") or mail.get("messages") or []
        urgent = [m for m in msgs if any(k in (m.get("subject", "").lower())
                                         for k in ("urgent", "asap", "action required"))]
        if urgent:
            lines.append(f"{len(urgent)} urgent emails waiting.")
        elif msgs:
            lines.append(f"{len(msgs)} new emails since yesterday, nothing flagged urgent.")
    else:
        lines.append("Inbox not connected yet.")

    # Brain baseline — if responder exposes brain state, mention dominant mood.
    try:
        brain = getattr(ctx.brain, "brain", None) or getattr(ctx.brain, "_brain", None)
        if brain is not None and hasattr(brain, "get_state"):
            st = brain.get_state() or {}
            mods = st.get("neuromodulators", {})
            top = sorted(mods.items(), key=lambda kv: -float(kv[1] or 0))[:1]
            if top:
                lines.append(f"Brain baseline: {top[0][0]} elevated.")
    except Exception:
        pass

    msg = "Good morning, Sir. " + " ".join(lines)
    ctx.say(msg)


def _action_end_of_day_summary(ctx: RoutineContext, r: Routine) -> None:
    cutoff = time.time() - 24 * 3600
    by_tool: Dict[str, int] = {}
    errors = 0
    total = 0
    try:
        with open(_ACTUATOR_AUDIT_PATH) as f:
            for line in f:
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                ts = row.get("ts") or row.get("timestamp") or 0
                if ts < cutoff:
                    continue
                total += 1
                tool = row.get("tool") or row.get("name") or "?"
                by_tool[tool] = by_tool.get(tool, 0) + 1
                if row.get("ok") is False or row.get("error"):
                    errors += 1
    except FileNotFoundError:
        ctx.say("No actions logged today — I was quiet.")
        return
    except Exception as e:
        ctx.notify("Leon", f"End-of-day summary failed: {e}", "low")
        return

    top = sorted(by_tool.items(), key=lambda kv: -kv[1])[:3]
    if total == 0:
        ctx.say("Quiet day. No actions in the last 24 hours.")
        return
    parts = [f"Today I fired {total} actions across {len(by_tool)} tools."]
    if top:
        parts.append("Top: " + ", ".join(f"{n} {c}" for n, c in top) + ".")
    if errors:
        parts.append(f"{errors} of them errored.")
    else:
        parts.append("Zero errors.")
    ctx.say(" ".join(parts))


def _action_calendar_prep(ctx: RoutineContext, r: Routine) -> None:
    cal = ctx.safe_act("cal_next_event", {})
    if not cal.get("ok"):
        return  # silent — this fires every 5m, no point alerting on missing tool
    ev = cal.get("result") or cal.get("event") or {}
    if not ev:
        return
    start_ts = ev.get("start_unix") or ev.get("start_ts")
    if start_ts is None:
        return
    delta = float(start_ts) - time.time()
    if delta < 0 or delta > 360:  # only inside the next 6 minutes
        return
    ev_id = ev.get("id") or ev.get("uid") or str(start_ts)
    if r.action and getattr(r, "_last_announced_id", None) == ev_id:
        return
    setattr(r, "_last_announced_id", ev_id)
    title = ev.get("title") or ev.get("summary") or "your next meeting"
    attendees = ev.get("attendees") or []
    names = [a.get("name") or a.get("email") or "" for a in attendees[:3]]
    names = [n for n in names if n]
    when = max(1, int(round(delta / 60)))
    line = f"Meeting in {when} minute{'s' if when != 1 else ''}: {title}."
    if names:
        line += " With " + ", ".join(names) + "."
    ctx.say(line)


def _action_email_triage(ctx: RoutineContext, r: Routine) -> None:
    now = datetime.now()
    if not (8 <= now.hour < 19):
        return
    mail = ctx.safe_act("email_gmail_search", {
        "query": "is:unread newer_than:30m", "max_results": 20,
    })
    if not mail.get("ok"):
        return
    msgs = mail.get("result", {}).get("messages") or mail.get("messages") or []
    urgent = []
    for m in msgs:
        subj = (m.get("subject") or "").lower()
        if any(k in subj for k in ("urgent", "asap", "action required", "deadline")):
            urgent.append(m)
    if urgent:
        first = urgent[0].get("subject") or "(no subject)"
        ctx.notify(
            "Leon — urgent mail",
            f"{len(urgent)} urgent unread. Top: {first}",
            urgency="critical",
        )


def _action_focus_check(ctx: RoutineContext, r: Routine) -> None:
    title = _active_window_title() or "the same window"
    ctx.notify(
        "Leon — focus check",
        f"You've been on '{title[:60]}' for a while. Want a break or a context-switch?",
        "normal",
    )


def _action_idle_consolidation(ctx: RoutineContext, r: Routine) -> None:
    brain = getattr(ctx.brain, "brain", None) or getattr(ctx.brain, "_brain", None)
    if brain is None:
        print("[ROUTINE] idle_consolidation: no brain handle — skipping")
        return
    fn = (getattr(brain, "sleep_consolidation", None)
          or getattr(brain, "consolidate", None)
          or getattr(brain, "sleep", None))
    if not callable(fn):
        # Try the module-level consolidator if present.
        try:
            from brain.sleep_consolidation import SleepConsolidator  # noqa: F401
            # No-op — the SleepConsolidator owns its own scheduling.
            print("[ROUTINE] idle_consolidation: SleepConsolidator handles its own loop")
        except Exception:
            print("[ROUTINE] idle_consolidation: no consolidation hook available")
        return
    try:
        fn()
    except Exception as e:
        print(f"[ROUTINE] idle_consolidation raised: {e}")


def _action_error_spotter(ctx: RoutineContext, r: Routine) -> None:
    # Stand down when vision is under heavy load (Makima patch)
    try:
        import brain.vision_daemon as _vd
        _lv = getattr(_vd, "_local_vision", None)
        if _lv is not None and getattr(_lv, "last_latency_s", 0.0) > 3.0:
            return
    except Exception:
        pass
    res = ctx.safe_act("vision_describe", {
        "prompt": "Is there a red error dialog or a stack trace visible on the screen? Answer yes or no, briefly.",
    })
    if not res.get("ok"):
        return
    desc = (res.get("result", {}).get("text")
            or res.get("text")
            or res.get("description")
            or "").strip().lower()
    if not desc:
        return
    saw_error = desc.startswith("yes") or "error" in desc or "stack trace" in desc or "traceback" in desc
    if not saw_error:
        # Reset memory so a real error 90s from now will still notify.
        setattr(r, "_last_fingerprint", None)
        return
    # Hash-fingerprint the description so we don't re-notify for the
    # same error on every 90s tick.
    fingerprint = desc[:120]
    if getattr(r, "_last_fingerprint", None) == fingerprint:
        return
    setattr(r, "_last_fingerprint", fingerprint)
    ctx.notify("Leon — error spotted", desc[:240], "critical")


def _action_hydration_reminder(ctx: RoutineContext, r: Routine) -> None:
    ctx.notify("Leon", "Drink some water, Sir.", "normal")


def _action_pomodoro_cycle(ctx: RoutineContext, r: Routine) -> None:
    """State machine: work 25m → break 5m → repeat.

    Triggered by `routine_run_now('pomodoro_cycle')` or any other code
    calling ctx.act('pomodoro_start'). Persists current phase on the
    routine object so the scheduler can resume across ticks.
    """
    state = getattr(r, "_pomo_state", None)
    now = time.time()
    if state is None:
        state = {"phase": "work", "started": now, "duration": 25 * 60}
        setattr(r, "_pomo_state", state)
        ctx.notify("Leon — Pomodoro", "Starting 25-minute work block.", "normal")
        # Re-arm: schedule ourselves to be re-invoked in a minute.
        r.schedule = "every 1m"
        return
    elapsed = now - state["started"]
    if elapsed < state["duration"]:
        return  # still in current phase
    # Phase transition
    if state["phase"] == "work":
        state.update(phase="break", started=now, duration=5 * 60)
        ctx.notify("Leon — Pomodoro", "Work block done. 5-minute break.", "normal")
    else:
        state.update(phase="work", started=now, duration=25 * 60)
        ctx.notify("Leon — Pomodoro", "Break over. Back to work.", "normal")


def _action_tomorrow_prep(ctx: RoutineContext, r: Routine) -> None:
    lines: List[str] = []
    cal = ctx.safe_act("cal_events_upcoming", {"days": 1})
    if cal.get("ok"):
        events = cal.get("result", {}).get("events") or cal.get("events") or []
        if events:
            lines.append(f"Tomorrow has {len(events)} events.")
            for e in events[:3]:
                t = e.get("start_time") or e.get("start") or "?"
                title = e.get("title") or e.get("summary") or "(untitled)"
                lines.append(f"At {t}: {title}.")
        else:
            lines.append("Tomorrow looks clear.")
    else:
        lines.append("Can't see tomorrow's calendar.")

    # Pending reminders — pull active list if a reminder scheduler is reachable.
    try:
        from brain import reminders as _rem_mod  # noqa: F401
        # Best effort — server.py owns the singleton; we don't try to import it.
        pass
    except Exception:
        pass

    # Top open items from knowledge store.
    try:
        results = ctx.search("open todo OR pending OR unresolved") or []
        if results:
            top = results[:2]
            for item in top:
                text = item.get("text") or item.get("snippet") or item.get("content")
                if text:
                    lines.append(f"Open thread: {str(text)[:120]}.")
    except Exception:
        pass

    ctx.say("Tomorrow prep. " + " ".join(lines))


# ── Routine definitions (no actions resolved at module import time
#    so the BUILTIN_ROUTINES list is importable for inspection without
#    a context). The scheduler wires `action` at registration.
BUILTIN_ROUTINES: List[Routine] = [
    Routine(
        name="morning_briefing",
        description="7am daily — speak today's calendar, weather, urgent mail, brain baseline.",
        schedule="0 7 *",
        action=_action_morning_briefing,
    ),
    Routine(
        name="end_of_day_summary",
        description="6pm daily — summarise the day's actions and errors from the audit log.",
        schedule="0 18 *",
        action=_action_end_of_day_summary,
    ),
    Routine(
        name="calendar_prep",
        description="Every 5 minutes — alert 6 minutes before a meeting starts.",
        schedule="every 5m",
        action=_action_calendar_prep,
        min_interval_s=240,
    ),
    Routine(
        name="email_triage",
        description="Every 30 minutes (8am-7pm) — flag urgent unread mail.",
        schedule="every 30m",
        action=_action_email_triage,
    ),
    Routine(
        name="focus_check",
        description="Same window 30+ minutes — offer a break or context-switch.",
        trigger="window_focus_changed:>30m",
        action=_action_focus_check,
        min_interval_s=3600,
    ),
    Routine(
        name="idle_consolidation",
        description="15 minutes of no input — kick off sleep_consolidation if available.",
        trigger="idle:15m",
        action=_action_idle_consolidation,
        min_interval_s=600,
    ),
    Routine(
        name="error_spotter",
        description="Every 90 seconds — vision-check the screen for error dialogs.",
        schedule="every 90s",
        action=_action_error_spotter,
        min_interval_s=60,
    ),
    Routine(
        name="hydration_reminder",
        description="Every 2 hours (8am-10pm) — drink-water nudge.",
        schedule="0 */2 *",  # cron-lite has no "8-22" hour range in our parser
        action=_action_hydration_reminder,
    ),
    Routine(
        name="pomodoro_cycle",
        description="On demand — 25 min work / 5 min break loop.",
        schedule=None,
        enabled=False,    # disabled until Dean explicitly starts it
        action=_action_pomodoro_cycle,
    ),
    Routine(
        name="tomorrow_prep",
        description="9pm daily — speak a prep for tomorrow.",
        schedule="0 21 *",
        action=_action_tomorrow_prep,
    ),
    # ── Phase 10: routines that use the new tool surface ──
    Routine(
        name="btc_price_pulse",
        description="Every 6h — speak BTC + ETH price if movement > 3% since last check.",
        schedule="0 */6 *",
        action=lambda ctx, r=None: _action_btc_pulse(ctx),
    ),
    Routine(
        name="github_notifications",
        description="Every hour 9-18 — check GitHub notifications, speak unread mentions.",
        schedule="0 */1 *",
        action=lambda ctx, r=None: _action_github_notifications(ctx),
    ),
    Routine(
        name="health_daily_summary",
        description="9pm daily — speak today's water+meals+workouts+sleep summary.",
        schedule="0 21 *",
        action=lambda ctx, r=None: _action_health_summary(ctx),
    ),
    Routine(
        name="water_nudge",
        description="Every 90 min — gentle reminder if no water entry recently.",
        schedule="0 */2 *",
        action=lambda ctx, r=None: _action_water_nudge(ctx),
    ),
    Routine(
        name="screen_break_eye",
        description="Every 60 min during work hours — 20-20-20 eye-strain break reminder.",
        schedule="0 */1 *",
        action=lambda ctx, r=None: _action_screen_break(ctx),
    ),
    Routine(
        name="autopilot_queue",
        description="Every 2 min — drain the autopilot goal queue (queued via autopilot.queue_goal). DISABLED by default — enable to let Leon auto-run queued multi-step jobs.",
        # WAS "0 */1 *". Read rather than assumed: _cron_matches treats that as
        # MM=0 HH=*/1 DOW=*, i.e. once per hour at :00 — half the rate the
        # description claimed. _should_fire_schedule walks every minute in the
        # (last_tick, now] window so it is not SKIPPED, it is simply hourly.
        # A terminal reply could wait 60 min to reach Leon, which is too slow
        # for what the bridge exists to fix. "every 2m" goes through
        # _parse_every, which keys off last_run rather than clock position —
        # the right shape for "has anything arrived since I last looked".
        # Cheap: _action_autopilot_queue returns immediately when
        # pending_count == 0, so an empty tick is one dict lookup.
        schedule="every 2m",
        enabled=False,
        action=lambda ctx, r=None: _action_autopilot_queue(ctx),
    ),
    Routine(
        name="terminal_bridge",
        description="Every 2 min — surface agent-terminal threads the autoloop went quiet on into the autopilot queue. Observe-only: never consumes the shared event queue.",
        schedule="every 2m",
        enabled=True,
        action=lambda ctx, r=None: _action_terminal_bridge(ctx),
    ),
    Routine(
        name="terminal_tap",
        description="Every 2 min — make Leon aware that agent terminals replied. Read-only and silent: feeds warm context, never speaks, never interrupts Dean.",
        schedule="every 2m",
        enabled=True,
        action=lambda ctx, r=None: _action_terminal_tap(ctx),
    ),
    Routine(
        name="mission_ops_check",
        description="Every 15 min — check all project builds, backends, creds, checklists. Broadcast failures to dashboard + voice alert on critical issues.",
        schedule="every 15m",
        action=lambda ctx, r=None: _action_mission_ops_check(ctx),
        min_interval_s=600,
    ),
]


def _action_terminal_bridge(ctx) -> None:
    """Bridge stalled terminal threads into the autopilot queue.

    Observe-only by design: it reads TerminalWatcher.pending() and never
    calls consume(), because the autoloop owns that lifecycle and a second
    consumer would race it. Dedupe is the bridge's own digest cursor.
    """
    try:
        from brain.mission import terminal_bridge
        terminal_bridge.run_once()
    except Exception as e:
        print(f"[ROUTINE] terminal_bridge failed: {e}")


#: Lines already handed to Leon, oldest first. The tap's cursor advances the
#: moment a row is surfaced, so without this the warm line would shrink back to
#: whatever arrived in the last two minutes and drop the reply before it.
_tap_recent: List[str] = []


def _action_terminal_tap(ctx) -> None:
    """Make Leon AWARE that agent terminals replied. It never speaks.

    terminal_tap.note_events() has been recording every reply at creation time
    from TerminalWatcher.poll(); nothing read that store until this. The tap
    covers BLINDNESS ("the terminal answered and I did not know"), where
    terminal_bridge covers stalls.

    Warm context and NOT Consciousness.observe(): an observation queued there
    is picked up by Consciousness._proactive_loop, which makes Leon speak
    unprompted after five idle minutes (thirty seconds at high urgency). The
    tap's contract is awareness, not interruption, so it writes to WarmContext
    instead — a passive buffer read only while Leon is already answering.
    """
    try:
        from brain.mission import terminal_tap
        rows = terminal_tap.unseen(limit=10)
        if not rows:
            return

        # The responder's LIVE WarmContext, never a fresh WarmContext(). Both
        # instances persist the whole buffer to the same JSON file, so a second
        # one would have its addition overwritten by the responder's next save
        # — and the rows would already be marked seen. Leon would never see it.
        wctx = getattr(getattr(ctx, "brain", None), "_warm_context", None)
        if wctx is None:
            print(f"[ROUTINE] terminal_tap: no warm context — leaving "
                  f"{len(rows)} row(s) unseen for the next tick")
            return

        # Newest per window. The bridge measured this against live data: 23 of
        # 24 pending events were superseded snapshots of one conversation.
        newest: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            w = row.get("window", "?")
            if w not in newest or (row.get("ts") or 0) >= (newest[w].get("ts") or 0):
                newest[w] = row

        for window, row in sorted(newest.items()):
            line = f"{window}: {(row.get('summary') or '').strip()[:120]}"
            if line in _tap_recent:
                _tap_recent.remove(line)
            _tap_recent.append(line)
        del _tap_recent[:-5]

        stamp = datetime.now().strftime("%H:%M")
        text = (f"Agent terminals replied (as of {stamp}), newest first: "
                + " | ".join(reversed(_tap_recent)))
        wctx.add("terminal_replies", text[:600], category="topic", warmth=1.0)

        # Only once it has landed somewhere Leon reads. If add() raises we fall
        # to the handler below with the cursor untouched, so nothing is lost.
        terminal_tap.mark_seen(rows)
        print(f"[ROUTINE] terminal_tap: {len(rows)} new "
              f"{'reply' if len(rows) == 1 else 'replies'} from "
              f"{len(newest)} window(s) → warm context")
    except Exception as e:
        print(f"[ROUTINE] terminal_tap failed: {e}")


def _action_autopilot_queue(ctx) -> None:
    """Drain pending autopilot goals. Only fires when the routine is enabled."""
    try:
        from brain.autopilot import EXTRA_TOOLS as AP
        pending = AP["autopilot.queue_list"]({}).get("pending_count", 0)
        if pending == 0:
            return
        r = AP["autopilot.process_queue"]({"max_goals": 2})
        done = r.get("processed", 0)
        if done:
            ctx.say(f"Cleared {done} queued task{'s' if done != 1 else ''} from autopilot.")
    except Exception:
        pass


# ── Phase 10 action callbacks (defined here, after BUILTIN_ROUTINES so
#    the routines can reference them by name in tests) ────────────────
_btc_last_price = {"value": None}


def _action_btc_pulse(ctx) -> None:
    try:
        r = ctx.actuator_call("info.crypto_price", {"symbol": "bitcoin"})
        if not r or not r.get("ok"):
            return
        result = r.get("result", r)
        price = result.get("price")
        if price is None:
            return
        last = _btc_last_price["value"]
        _btc_last_price["value"] = price
        if last is None:
            return  # first sample, nothing to compare
        pct = ((price - last) / last) * 100
        if abs(pct) >= 3:
            direction = "up" if pct > 0 else "down"
            ctx.say(f"BTC is {direction} {abs(pct):.1f}% since last check, now at ${price:,.0f}.")
    except Exception:
        pass


def _action_github_notifications(ctx) -> None:
    hour = datetime.now().hour
    if hour < 9 or hour > 18:
        return
    try:
        from brain.integrations.github_cicd import EXTRA_TOOLS as GH
        if "gh.notifications_list" in GH:
            r = GH["gh.notifications_list"]({"unread": True, "limit": 5})
            if r.get("ok"):
                inner = r.get("result", r)
                items = (inner.get("notifications") if isinstance(inner, dict) else inner) or []
                if items:
                    titles = []
                    for n in items[:3]:
                        if isinstance(n, dict):
                            subj = n.get("subject") or {}
                            title = subj.get("title") if isinstance(subj, dict) else None
                            titles.append(title or "notification")
                    if titles:
                        ctx.say(f"{len(items)} GitHub notifications: {'; '.join(titles)}.")
    except Exception:
        pass


def _action_health_summary(ctx) -> None:
    try:
        from brain.integrations.wellness import EXTRA_TOOLS as W
        r = W["wellness.daily_health_summary"]({})
        if r.get("ok"):
            summary = r.get("summary") or r
            text_bits = []
            if isinstance(summary, dict):
                if summary.get("water_ml"):
                    text_bits.append(f"{summary['water_ml']} ml water")
                if summary.get("workout_minutes"):
                    text_bits.append(f"{summary['workout_minutes']} min workout")
                if summary.get("sleep_hours"):
                    text_bits.append(f"{summary['sleep_hours']}h sleep last night")
            if text_bits:
                ctx.say("Health check: " + ", ".join(text_bits) + ".")
    except Exception:
        pass


def _action_water_nudge(ctx) -> None:
    hour = datetime.now().hour
    if hour < 9 or hour > 21:
        return
    try:
        from brain.integrations.wellness import EXTRA_TOOLS as W
        r = W["wellness.water_reminder"]({})
        if r.get("ok") and r.get("needs_reminder"):
            ctx.say("Reminder — time for water.")
    except Exception:
        pass


def _action_screen_break(ctx) -> None:
    hour = datetime.now().hour
    if hour < 9 or hour > 19:
        return
    try:
        idle = ctx.actuator_call("system.uptime", {})  # placeholder; just use it
        # We just emit the reminder — it's the user's call to act on it
        from brain.presence import EXTRA_TOOLS as P
        if "presence.dashboard_event" in P:
            P["presence.dashboard_event"]({
                "kind": "observation",
                "message": "20-20-20 break — look at something 20 feet away for 20 seconds",
                "icon": "👀",
            })
    except Exception:
        pass


def _action_mission_ops_check(ctx) -> None:
    """DEPRECATED — replaced by Phase 17 autopilot scheduler.
    This routine is disabled by default. The autopilot runs its own
    scan/fix/operate cycle every 5 minutes with brain-driven behavior."""
    pass


# ════════════════════════════════════════════════════════════════════════
#  MODULE-LEVEL API (the singleton scheduler other code reaches for)
# ════════════════════════════════════════════════════════════════════════

_scheduler: Optional[RoutineScheduler] = None
_scheduler_lock = threading.Lock()


def start_routine_scheduler(
    brain_responder: Any,
    actuator_call: Callable[[str, Dict[str, Any]], Dict[str, Any]],
    knowledge_search: Callable[[str], List[Dict[str, Any]]],
    notify: Callable[..., None],
    tts_for_text: Optional[Callable[[str], Any]] = None,
    broadcast: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> RoutineScheduler:
    """Spin up the singleton scheduler and register all built-ins.

    Safe to call multiple times — second call returns the existing instance.
    """
    global _scheduler
    with _scheduler_lock:
        if _scheduler is not None:
            return _scheduler
        ctx = RoutineContext(
            brain_responder=brain_responder,
            actuator_call=actuator_call,
            knowledge_search=knowledge_search,
            notify=notify,
            tts_for_text=tts_for_text,
            broadcast=broadcast,
        )
        sched = RoutineScheduler(context=ctx)
        for builtin in BUILTIN_ROUTINES:
            sched.register(builtin)
        sched.start()
        _scheduler = sched
    return _scheduler


def _require_scheduler() -> RoutineScheduler:
    if _scheduler is None:
        raise RuntimeError("routine scheduler not started — call start_routine_scheduler() first")
    return _scheduler


def routine_list() -> List[Dict[str, Any]]:
    if _scheduler is None:
        return []
    return _scheduler.list()


def routine_enable(name: str) -> bool:
    return _require_scheduler().set_enabled(name, True)


def routine_disable(name: str) -> bool:
    return _require_scheduler().set_enabled(name, False)


def routine_run_now(name: str) -> Dict[str, Any]:
    return _require_scheduler().fire(name, reason="run_now")


def routine_add_custom(
    name: str,
    schedule: Optional[str],
    action: Callable[[RoutineContext, Routine], None],
    description: str = "",
    trigger: Optional[str] = None,
    min_interval_s: float = 0.0,
) -> Dict[str, Any]:
    """Create a runtime routine. `schedule` and `trigger` may both be
    None — the routine then only fires via routine_run_now()."""
    sched = _require_scheduler()
    if not callable(action):
        return {"ok": False, "error": "action must be callable"}
    if sched.get(name) is not None:
        return {"ok": False, "error": f"routine '{name}' already exists"}
    r = Routine(
        name=name,
        description=description or "(custom routine)",
        schedule=schedule,
        trigger=trigger,
        action=action,
        min_interval_s=min_interval_s,
    )
    setattr(r, "_custom", True)
    sched.register(r)
    return {"ok": True, "name": name}


def routine_remove(name: str) -> Dict[str, Any]:
    sched = _require_scheduler()
    r = sched.get(name)
    if r is None:
        return {"ok": False, "error": f"no such routine: {name}"}
    if not r.is_custom():
        return {"ok": False, "error": "built-in routines can't be removed — use routine_disable()"}
    sched.unregister(name)
    return {"ok": True}


# ════════════════════════════════════════════════════════════════════════
#  INTEGRATION POINT — server.py
# ════════════════════════════════════════════════════════════════════════
#
#  In server.py, after brain_api_responder is created and the local_tools
#  are wired (i.e. after the reminder_scheduler block around line 990),
#  add:
#
#      try:
#          from brain.routines import start_routine_scheduler
#          from brain.actuator_client import call as _act_call
#
#          # knowledge_search local-tool wrapper to a plain (query)->results fn
#          def _routine_knowledge_search(q: str):
#              fn = brain_api_responder.local_tools.get("knowledge_search")
#              if not callable(fn):
#                  return []
#              res = fn({"query": q, "limit": 5})
#              return (res or {}).get("result") or []
#
#          routine_scheduler = start_routine_scheduler(
#              brain_responder=brain_api_responder,
#              actuator_call=lambda tool, args: _act_call(tool, args),
#              knowledge_search=_routine_knowledge_search,
#              notify=lambda args: _act_call("notify", args),
#              tts_for_text=_tts_synthesize_b64,
#              broadcast=_broadcast_threadsafe,
#          )
#          print("[BRAIN] routine scheduler started")
#      except Exception as e:
#          print(f"[BRAIN] routine scheduler disabled: {e}")
#          routine_scheduler = None
#
#  Optionally expose REST endpoints (mirror the reminder_* pattern):
#      GET  /api/routines              -> routine_list()
#      POST /api/routines/{name}/run   -> routine_run_now(name)
#      POST /api/routines/{name}/enable
#      POST /api/routines/{name}/disable
#      POST /api/routines               -> routine_add_custom(...)
#      DELETE /api/routines/{name}     -> routine_remove(name)
#
#  And wire a tool surface so Leon himself can fire routines mid-conversation:
#      brain_api_responder.local_tools["routine_list"]    = lambda args: {"ok": True, "result": routine_list()}
#      brain_api_responder.local_tools["routine_run_now"] = lambda args: {"ok": True, "result": routine_run_now(args.get("name"))}
#      brain_api_responder.local_tools["routine_enable"]  = lambda args: {"ok": True, "result": routine_enable(args.get("name"))}
#      brain_api_responder.local_tools["routine_disable"] = lambda args: {"ok": True, "result": routine_disable(args.get("name"))}
#
# ════════════════════════════════════════════════════════════════════════
