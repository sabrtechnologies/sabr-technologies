"""Reasoning-engine (claude CLI) health: where the binary is, whether it answers.

Born from Aiden's bug report, 2026-08-29 (Cyrus SI, Windows 11). The SI was
spawning the CLI by BARE NAME ("claude"), so a process launched with a stale
PATH had no reasoning engine for its entire lifetime -- and the only symptom
the owner saw was a timeout handler saying "Give me a moment, I'm still
processing." for twelve hours. Three rules live here now:

  1. Resolve the binary to an ABSOLUTE path through the installer's shared
     resolver (shutil.which + every known install dir), once at boot, logged.
     Re-resolve lazily when it was missing, so a claude installed after
     launch is picked up without a restart.
  2. Every spawn reports success/failure here, so /api/state can expose
     `engine_ok` and the dashboard can show a degraded state instead of the
     truth living only in a log file.
  3. Failure kinds are distinct: not_found (could not launch) vs timeout
     (launched, never answered) vs exit (launched, died). They deserve
     different words to the owner.

Never raises. Safe to import from anywhere (no brain imports).
"""
from __future__ import annotations

import sys
import threading
import time

_lock = threading.Lock()
_state = {
    "exe": None,            # absolute path, or None if unresolved
    "resolved_at": 0.0,
    "ok": None,             # None = never tried, True/False after first spawn
    "last_ok_ts": 0.0,
    "successes": 0,
    "failures": 0,
    "last_error_kind": "",  # not_found | timeout | exit | other
    "last_error": "",
    "last_error_ts": 0.0,
}


def _find() -> str | None:
    try:
        from installer.local_brain import find_claude
        return find_claude()
    except Exception:
        try:
            import shutil
            return shutil.which("claude")
        except Exception:
            return None


def resolve(refresh: bool = False) -> str:
    """Absolute path to the claude CLI, resolved once and cached.

    Returns the bare name "claude" ONLY when nothing could be found, so the
    caller's spawn raises FileNotFoundError and can report it honestly --
    never silently "works on my shell".
    """
    with _lock:
        cached = _state["exe"]
        if cached and not refresh:
            return cached
        exe = _find()
        _state["exe"] = exe
        _state["resolved_at"] = time.time()
    if exe:
        if not cached or cached != exe:
            print(f"[ENGINE] claude CLI resolved to {exe}", flush=True)
        return exe
    print("[ENGINE] WARNING: claude CLI NOT FOUND from this process "
          "(PATH is frozen at launch; checked PATH + known install dirs). "
          "Reasoning will fail until claude is installed or this process "
          "is restarted from a shell that can see it.",
          file=sys.stderr, flush=True)
    return "claude"


def exe() -> str | None:
    """Last resolved path (None if never found). Does not re-resolve."""
    return _state["exe"]


def spawn_argv(argv: list[str]) -> list[str]:
    """Wrap argv so Windows can actually launch it. NO-OP everywhere else.

    Task 22 / Aiden's CYRUS box (2026-08-29 report, unverified until Dean's
    Windows 11 laptop, 2026-09-04): find_claude() resolves to an ABSOLUTE
    path, but on Windows that path is frequently claude.cmd (npm's global
    install shim), not a PE binary. Every spawn site calls
    subprocess.Popen(argv, ..., shell=False) — CreateProcess cannot execute
    a .cmd/.bat directly in that mode and Windows raises WinError 193
    ("%1 is not a valid Win32 application"), so the reasoning engine never
    even launches. shell=True with a list argv is the documented fix
    (Python's subprocess builds the command line via list2cmdline() and
    hands it to cmd.exe, which knows how to run batch files) but changing
    Popen's shell= kwarg touches every platform's spawn path from one
    conditional, which is exactly the kind of "wrong guess breaks every
    Windows SI" risk task 22 flagged. So instead: ONLY on Windows, ONLY when
    argv[0] ends in .cmd/.bat, prefix with explicit ["cmd", "/c", ...] and
    leave shell=False untouched everywhere — Linux and macOS get argv back
    unmodified, byte for byte, so this cannot regress a platform that
    already works. UNVERIFIED on real Windows until exercised there.
    """
    if not argv:
        return argv
    try:
        import platform
        if platform.system() != "Windows":
            return argv
    except Exception:
        return argv
    head = str(argv[0])
    if head.lower().endswith((".cmd", ".bat")):
        return ["cmd", "/c"] + list(argv)
    return argv


def mark_ok() -> None:
    with _lock:
        _state["ok"] = True
        _state["last_ok_ts"] = time.time()
        _state["successes"] += 1


def mark_fail(kind: str, detail: str = "") -> None:
    with _lock:
        _state["ok"] = False
        _state["failures"] += 1
        _state["last_error_kind"] = kind
        _state["last_error"] = (detail or "")[:300]
        _state["last_error_ts"] = time.time()
    print(f"[ENGINE] {kind}: {detail}", file=sys.stderr, flush=True)


def snapshot() -> dict:
    with _lock:
        d = dict(_state)
    d["reachable"] = bool(d["exe"])
    # Human line for dashboards -- one string, no guessing required.
    if d["ok"] is None:
        d["summary"] = ("engine: untested" if d["exe"]
                        else "engine: claude CLI not found")
    elif d["ok"]:
        d["summary"] = "engine: ok"
    else:
        d["summary"] = f"engine: DOWN ({d['last_error_kind']})"
    return d


def owner_message(kind: str, timeout_s: int | None = None) -> str:
    """The words an SI says to its owner for each failure kind. Never
    phrase a failure as work in progress -- that one string cost a customer
    twelve hours and nearly a reinstall."""
    if kind == "not_found":
        return ("My reasoning engine isn't reachable — I can't find the claude "
                "program from this process. Nothing is processing. I need a "
                "restart (a fresh process re-reads PATH), or Claude Code needs "
                "to be reinstalled if it's actually gone.")
    if kind == "timeout":
        t = f" in {timeout_s} seconds" if timeout_s else ""
        return (f"My reasoning engine timed out — the claude program launched "
                f"but didn't answer{t}. That's a stall, not a slow answer. Try "
                "once more; if it keeps happening I need a restart.")
    if kind == "exit":
        return ("My reasoning engine started but exited without an answer. "
                "That usually means Claude Code isn't signed in on this "
                "machine — run `claude` in a terminal once to log in.")
    return "My reasoning engine hit an error I can't explain from here."
