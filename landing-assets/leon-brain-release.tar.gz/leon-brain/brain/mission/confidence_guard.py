"""
Confidence Guard — automated correction of Leon's overconfidence.

Watches for high-confidence claims and applies algorithmic brakes based on
measured calibration history. Prevents Leon from being certain when he should be skeptical.
"""

import logging
from typing import Optional, Dict, Any
from brain.mission.confidence_auditor import get_confidence_auditor, ConfidenceOutcome

log = logging.getLogger("leon.mission.confidence_guard")


class ConfidenceGuard:
    """
    Applies real-time corrections to Leon's confidence based on calibration history.
    """

    def __init__(self):
        self.auditor = get_confidence_auditor()
        self.correction_factor = 1.0
        self._update_correction_factor()

    def _update_correction_factor(self):
        """Recompute correction factor from recent calibration."""
        report = self.auditor.get_calibration_report(hours=48)

        if "overall_calibration_gap" not in report:
            log.info("Insufficient calibration data yet")
            self.correction_factor = 1.0
            return

        gap = report["overall_calibration_gap"]

        # If Leon is overconfident (gap < 0), apply downward correction
        if gap < -0.2:
            self.correction_factor = 0.7  # Reduce confidence by 30%
            log.warning(
                f"OVERCONFIDENT DETECTED: actual success {report['overall_accuracy']:.0%} "
                f"but stated {report['average_stated_confidence']:.0%}. "
                f"Applying 30% confidence reduction."
            )
        elif gap < -0.1:
            self.correction_factor = 0.85  # Reduce by 15%
        else:
            self.correction_factor = 1.0

    def check_claim(
        self,
        claim: str,
        stated_confidence: float,
        reason: str,
        layers_checked: Optional[list] = None,
        require_verification: bool = True
    ) -> Dict[str, Any]:
        """
        Vet a confidence claim Leon is about to make.

        Returns:
        {
            "approved": bool,
            "corrected_confidence": float,
            "warning": str or None,
            "reason": str,
            "recommendation": str
        }
        """
        self._update_correction_factor()

        # Apply correction factor
        corrected = stated_confidence * self.correction_factor

        result = {
            "approved": True,
            "claimed_confidence": stated_confidence,
            "corrected_confidence": corrected,
            "correction_factor": self.correction_factor,
            "warning": None,
            "reason": reason,
            "layers_checked": layers_checked or []
        }

        # Flag high-confidence claims made on low-layer checks
        if stated_confidence > 0.9 and layers_checked:
            low_layers = [l for l in layers_checked if "LOCAL" in l or "DISK" in l]
            if low_layers and len(low_layers) == len(layers_checked):
                result["warning"] = (
                    f"HIGH CONFIDENCE ({stated_confidence:.0%}) on LOW LAYERS ONLY. "
                    f"Cannot verify customer-facing impact from code-level checks alone."
                )
                result["approved"] = require_verification and stated_confidence > 0.95

        # Flag claims with insufficient supporting reason
        if stated_confidence > 0.85 and len(reason) < 20:
            result["warning"] = f"High confidence with minimal supporting reason: {reason}"
            result["approved"] = False

        # Log the claim for auditing
        self.auditor.record_claim(
            claim=claim,
            confidence=corrected,  # Record the corrected confidence
            reason=reason,
            layers_checked=layers_checked
        )

        if result["warning"]:
            log.warning(f"[CONFIDENCE_GUARD] {result['warning']}")

        return result

    def record_outcome(self, claim: str, was_correct: bool, notes: str = ""):
        """
        Report whether a confidence claim actually panned out.
        """
        outcome = ConfidenceOutcome.CORRECT if was_correct else ConfidenceOutcome.INCORRECT
        self.auditor.report_outcome(claim, outcome, notes)

    def get_audit_report(self) -> Dict[str, Any]:
        """Get full calibration audit."""
        return self.auditor.get_calibration_report(hours=48)


# Global instance
_guard = None

def get_confidence_guard() -> ConfidenceGuard:
    global _guard
    if _guard is None:
        _guard = ConfidenceGuard()
    return _guard


def check_confidence(
    claim: str,
    confidence: float,
    reason: str,
    layers: Optional[list] = None
) -> bool:
    """
    Quick check: should Leon be this confident?
    Returns True if confidence claim is appropriate.
    """
    guard = get_confidence_guard()
    result = guard.check_claim(claim, confidence, reason, layers)
    return result["approved"]
