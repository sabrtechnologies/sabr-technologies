"""
Phase 17 — Action Planner + Evidence Engine.

For each project: determine next best safe action, classify tier,
simulate risk, execute or queue. Never mark tasks done without evidence.
"""
from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import time
from typing import Any, Optional

from brain.mission.autonomy import Tier, classify, ActionExecutor, Action

log = logging.getLogger("leon.mission.planner")

_SGR_RE = re.compile(r"\x1b\[[0-9;]*m")


def _strip_sgr(s: str) -> str:
    """Drop ANSI colour/style escapes so text comparisons behave."""
    return _SGR_RE.sub("", s)


def _is_dim_placeholder(raw_line: str) -> bool:
    """True if the text after the '❯' prompt glyph is rendered DIM.

    The claude TUI shows the last-submitted message as a dim ghost inside an
    otherwise EMPTY input box. Real typed-but-unsubmitted text is never dim.
    So: find the prompt glyph, then check whether a dim SGR (\\x1b[2m) opens
    before any non-space content and is not closed before that content starts.
    """
    idx = raw_line.find("❯")
    if idx < 0:
        return False
    after = raw_line[idx + 1:]
    dim_open = False
    pos = 0
    for m in _SGR_RE.finditer(after):
        # any visible (non-space) character before this escape means the
        # content already started — its styling is whatever we saw last.
        if after[pos:m.start()].strip():
            break
        params = m.group(0)[2:-1]
        for p in params.split(";"):
            if p == "2":
                dim_open = True
            elif p in ("0", "22", ""):
                dim_open = False
        pos = m.end()
    return dim_open and bool(after[pos:].strip())


class Evidence:
    """Collect and store evidence for action outcomes."""

    @staticmethod
    def from_api_response(url: str, status: int, body: Any) -> dict:
        return {"type": "api_response", "url": url, "status": status,
                "body": body if isinstance(body, (str, dict, list)) else str(body)[:500],
                "collected_at": time.time()}

    @staticmethod
    def from_command(cmd: list[str], stdout: str, stderr: str, returncode: int) -> dict:
        return {"type": "command_output", "cmd": " ".join(cmd),
                "stdout": stdout[:2000], "stderr": stderr[:500],
                "returncode": returncode, "collected_at": time.time()}

    @staticmethod
    def from_git_status(repo_path: str) -> dict:
        try:
            r = subprocess.run(["git", "status", "--porcelain"], capture_output=True,
                               text=True, timeout=10, cwd=repo_path)
            branch = subprocess.run(["git", "branch", "--show-current"], capture_output=True,
                                    text=True, timeout=5, cwd=repo_path)
            return {"type": "git_status", "repo": repo_path,
                    "branch": branch.stdout.strip(), "dirty": bool(r.stdout.strip()),
                    "files_changed": len(r.stdout.strip().splitlines()),
                    "collected_at": time.time()}
        except Exception as e:
            return {"type": "git_status", "repo": repo_path, "error": str(e)}

    @staticmethod
    def from_health_check(url: str, ok: bool, status_code: int = 0, data: Any = None) -> dict:
        return {"type": "health_check", "url": url, "ok": ok,
                "status_code": status_code, "data": str(data)[:300] if data else "",
                "collected_at": time.time()}

    @staticmethod
    def from_build_status(service: str, project: str, status: str, url: str = "") -> dict:
        return {"type": "build_status", "service": service, "project": project,
                "status": status, "url": url, "collected_at": time.time()}


def _run_cmd(cmd: list[str], cwd: str | None = None, timeout: int = 30) -> dict:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return {"ok": r.returncode == 0, "stdout": r.stdout.strip(),
                "stderr": r.stderr.strip(), "code": r.returncode}
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return {"ok": False, "stdout": "", "stderr": str(e), "code": -1}


class ActionPlanner:
    """Determine next best actions for each project and execute safely."""

    def __init__(self, executor: ActionExecutor, registry=None, state_engine=None,
                 connectors=None, cred_awareness=None):
        self.executor = executor
        self.registry = registry
        self.state_engine = state_engine
        self.connectors = connectors
        self.cred_awareness = cred_awareness

    def plan_for_project(self, project: dict) -> list[dict]:
        """Generate a prioritized list of next actions for a project."""
        actions = []
        pid = project["id"]
        name = project["name"]

        # 1. Check GitHub repo status
        for repo_url in project.get("repo_urls", []):
            parts = repo_url.rstrip("/").split("/")
            if len(parts) >= 2:
                owner, repo = parts[-2], parts[-1].replace(".git", "")
                actions.append({
                    "action_name": "github_pr_status",
                    "project_id": pid,
                    "description": f"Check latest PR status for {owner}/{repo}",
                    "handler_args": {"owner": owner, "repo": repo},
                    "priority": 2,
                })
                actions.append({
                    "action_name": "github_workflow_status",
                    "project_id": pid,
                    "description": f"Check CI/CD workflow status for {owner}/{repo}",
                    "handler_args": {"owner": owner, "repo": repo},
                    "priority": 2,
                })

        # 2. Check backend health
        for url in project.get("backend_urls", []):
            actions.append({
                "action_name": "backend_health",
                "project_id": pid,
                "description": f"Health check {url}",
                "handler_args": {"url": url},
                "priority": 1,
            })

        # 3. Check credentials
        if project.get("required_creds"):
            actions.append({
                "action_name": "credential_scan",
                "project_id": pid,
                "description": f"Scan required credentials for {name}",
                "handler_args": {"project": project},
                "priority": 3,
            })

        # 4. Check checklist readiness
        if self.state_engine:
            items = self.state_engine.get_items(pid)
            if items:
                unknown_items = [i for i in items if i.get("status") == "unknown"]
                if unknown_items:
                    actions.append({
                        "action_name": "check_status",
                        "project_id": pid,
                        "description": f"Evaluate {len(unknown_items)} unchecked checklist items for {name}",
                        "handler_args": {"items": unknown_items},
                        "priority": 3,
                    })

        # 5. Git status for repos with local paths
        # Check if the project has a local path we can inspect
        repo_path = self._find_local_repo(project)
        if repo_path:
            actions.append({
                "action_name": "git_status",
                "project_id": pid,
                "description": f"Check git status for {name}",
                "handler_args": {"repo_path": repo_path},
                "priority": 2,
            })

        # Sort by priority (lower = more important)
        actions.sort(key=lambda a: a.get("priority", 99))
        return actions

    def plan_all(self) -> list[dict]:
        """Generate actions across all active projects."""
        if not self.registry:
            return []
        all_actions = []
        for project in self.registry.list_all(active_only=True):
            all_actions.extend(self.plan_for_project(project))
        return all_actions

    def execute_plan(self, actions: list[dict], max_actions: int = 20) -> list[dict]:
        """Execute planned actions, respecting tiers."""
        results = []
        executed = 0
        for action_spec in actions:
            if executed >= max_actions:
                break
            action_name = action_spec["action_name"]
            tier = classify(action_name)

            if tier in (Tier.AUTO_ALLOWED, Tier.AUTO_WITH_ROLLBACK):
                action = self.executor.submit(
                    action_name=action_name,
                    project_id=action_spec.get("project_id", ""),
                    description=action_spec.get("description", ""),
                    context={"handler_args": action_spec.get("handler_args", {})},
                )
                results.append({"action_id": action.id, "action_name": action_name,
                                "project_id": action_spec.get("project_id", ""),
                                "tier": tier.value, "status": action.status})
                executed += 1
            elif tier == Tier.APPROVAL_REQUIRED:
                action = self.executor.submit(
                    action_name=action_name,
                    project_id=action_spec.get("project_id", ""),
                    description=action_spec.get("description", ""),
                )
                results.append({"action_id": action.id, "action_name": action_name,
                                "project_id": action_spec.get("project_id", ""),
                                "tier": tier.value, "status": "awaiting_approval"})
            else:
                results.append({"action_name": action_name, "project_id": action_spec.get("project_id", ""),
                                "tier": tier.value, "status": "blocked"})

        return results

    def _find_local_repo(self, project: dict) -> str | None:
        """Try to find the local path for a project."""
        # Check forever-sessions for path mapping
        try:
            sessions_path = os.path.expanduser("~/.openclaw/forever-sessions.json")
            if os.path.exists(sessions_path):
                with open(sessions_path) as f:
                    sessions = json.load(f)
                slug = project.get("slug", project.get("name", "").lower().replace(" ", "-"))
                for s in sessions.get("forever", []):
                    wn = s.get("windowName", "")
                    if wn == slug or slug in wn:
                        path = s.get("path", "")
                        if os.path.isdir(path):
                            return path
        except Exception:
            pass
        return None

    # ── Workspace / terminal awareness ──────────────────────────────────

    def scan_workspaces(self) -> list[dict]:
        """Scan tmux sessions for active/idle terminals."""
        results = []
        try:
            r = _run_cmd(["tmux", "list-windows", "-t", "agents", "-F",
                          "#{window_index}:#{window_name}:#{window_activity}:#{pane_current_command}"])
            if r["ok"]:
                for line in r["stdout"].splitlines():
                    parts = line.split(":", 3)
                    if len(parts) >= 3:
                        idx, name, activity = parts[0], parts[1], parts[2]
                        cmd = parts[3] if len(parts) > 3 else ""
                        last_activity = int(activity) if activity.isdigit() else 0
                        idle_s = int(time.time() - last_activity) if last_activity else -1
                        waiting_reason = self._detect_waiting_state(name)
                        results.append({
                            "index": int(idx) if idx.isdigit() else idx,
                            "name": name,
                            "idle_seconds": idle_s,
                            "command": cmd,
                            "is_idle": idle_s > 600,  # idle > 10 min
                            "waiting_reason": waiting_reason,
                            "is_waiting_on_input": bool(waiting_reason),
                        })
        except Exception as e:
            log.debug("tmux scan failed: %s", e)
        return results

    def _detect_waiting_state(self, window_name: str) -> str:
        """Inspect a pane's visible content to detect if it's WAITING on a human —
        an interactive menu, a confirmation prompt, or unsubmitted input text.
        Returns a short reason string, or '' if not waiting. Added 2026-08-09
        after Dean caught a lab terminal sitting on a question for minutes
        while idle-detection saw only 'idle'."""
        try:
            # -e keeps SGR escapes. We NEED them: the claude TUI renders the
            # ghost of the last-submitted message as a DIM (\x1b[2m) placeholder
            # inside an EMPTY input box. Stripped of colour it is byte-identical
            # to genuinely unsubmitted text, so a plain capture cannot tell them
            # apart and reports a false "Enter never landed" every single turn.
            # Verified 2026-08-09 on agents:element115.
            r = _run_cmd(["tmux", "capture-pane", "-p", "-e", "-t", f"agents:{window_name}"])
            if not r["ok"]:
                return ""
            raw_tail = r["stdout"].splitlines()[-30:]
            tail = [_strip_sgr(ln) for ln in raw_tail]
            text = "\n".join(tail)
            # Interactive selection menu (claude TUI AskUser / plugin dialogs)
            if "Enter to select" in text or "Esc to cancel" in text:
                return "interactive menu open — a question needs an answer"
            # Yes/No style confirmation
            if "(y/n)" in text.lower() or "[y/N]" in text or "Do you want" in text:
                return "confirmation prompt waiting"
            # Unsubmitted text sitting in the input box (the Enter-never-landed bug)
            for raw, line in zip(reversed(raw_tail), reversed(tail)):
                s = line.strip()
                if not s.startswith("❯"):
                    continue
                if len(s) <= 2:
                    break  # empty prompt — not waiting on input
                if _is_dim_placeholder(raw):
                    break  # ghost of the last submitted message, box is empty
                return f"unsubmitted input in prompt box: {s[1:].strip()[:60]}"
        except Exception as e:
            log.debug("waiting-state detect failed for %s: %s", window_name, e)
        return ""

    def detect_stuck_terminals(self) -> list[dict]:
        """Find terminals that are idle too long OR actively waiting on input.
        A terminal waiting on a question is flagged immediately, regardless of
        idle time — those are the expensive ones."""
        workspaces = self.scan_workspaces()
        return [w for w in workspaces
                if w.get("is_idle") or w.get("is_waiting_on_input")]
