"""Ambush the residue instead of forcing it.

Ten deliberate attempts to reproduce residue produced zero. So stop trying to
trigger it and instead be sampling continuously when it next happens on its
own, with enough history that the row shows a TIMELINE rather than a single
frame. One frame tells you the box disagreed with the cursor; it cannot tell
you what the box looked like ten seconds earlier, which is the only thing
that identifies a precursor.

Two tmux round-trips per pane per poll, nothing parsed beyond one row. Cheap
enough to run at 5s for hours, which is the point — residue has only ever
appeared on panes left alone, never on a pane being actively driven.

The ring is per pane and bounded, so a soak that runs all night costs a fixed
amount of memory and writes NOTHING until something actually disagrees. A
sampler that logs every poll would produce a file nobody reads, which is how
instrumentation becomes decorative.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from collections import deque
from typing import Optional

SESSION = os.environ.get("LEON_AGENT_TMUX_SESSION", "agents")
RING = int(os.environ.get("LEON_RESIDUE_RING", "40"))       # ~3.5 min at 5s
AFTER_SAMPLES = 12                                          # ~1 min of after
_PROMPT_RX = re.compile(r"^\s*[❯>]\s?")
_PLACEHOLDER = ('Try "', "Try '")


def _tmux(args) -> str:
    try:
        p = subprocess.run(["tmux"] + args, capture_output=True, text=True, timeout=8)
        return p.stdout if p.returncode == 0 else ""
    except Exception:
        return ""


def probe(window: str) -> Optional[dict]:
    """One geometry read plus one screen read, with the same stability check
    the specimen capturer uses — geometry, screen, geometry. An unstable
    sample is dropped rather than recorded, because a row that pairs a cursor
    with a different frame's screen is indistinguishable from a real finding.
    """
    t = f"{SESSION}:{window}"
    fields = "#{cursor_y}\t#{cursor_x}\t#{pane_in_mode}\t#{pane_pid}\t#{pane_current_command}"
    a = _tmux(["display-message", "-p", "-t", t, fields]).strip()
    screen = _tmux(["capture-pane", "-p", "-t", t])
    b = _tmux(["display-message", "-p", "-t", t, fields]).strip()
    if not a or a != b or not screen:
        return None
    p = a.split("\t")
    if len(p) != 5 or not p[0].isdigit():
        return None
    cy, cx = int(p[0]), int(p[1])
    lines = screen.splitlines()
    row = lines[cy] if cy < len(lines) else ""
    m = _PROMPT_RX.match(row)
    prefix = m.end() if m else None
    painted = row[prefix:].strip() if prefix is not None else None
    return {
        "ts": time.time(), "window": window,
        "cursor_y": cy, "cursor_x": cx, "in_mode": p[2] == "1",
        "pane_pid": int(p[3]) if p[3].isdigit() else None,
        "pane_command": p[4],
        "row": row, "prompt_prefix_width": prefix,
        "painted": painted,
        "cursor_cells": (cx - prefix) if prefix is not None else None,
        # The disagreement, computed once and stored, so a later reader never
        # has to re-derive it from fields that may have changed meaning.
        "disagrees": bool(
            prefix is not None and painted
            and not painted.startswith(_PLACEHOLDER)
            and (cx - prefix) <= 0 and not (p[2] == "1")),
        "screen_tail": "\n".join(lines[-6:]),
    }


class ResidueSampler:
    def __init__(self, recorder=None):
        self._ring: dict = {}
        self._pending_after: dict = {}
        self._latched: dict = {}
        if recorder is None:
            from brain.mission import read_mismatch
            recorder = read_mismatch.record
        self._record = recorder

    def _slim(self, s: dict) -> dict:
        return {k: s[k] for k in ("ts", "cursor_x", "cursor_cells", "row",
                                  "painted", "disagrees", "pane_command")}

    def poll(self, window: str) -> Optional[dict]:
        s = probe(window)
        if s is None:
            return None
        ring = self._ring.setdefault(window, deque(maxlen=RING))

        # Finish an in-flight capture first: an occurrence is only useful with
        # what came AFTER it, and that has to be collected live.
        pend = self._pending_after.get(window)
        if pend is not None:
            pend["after"].append(self._slim(s))
            if len(pend["after"]) >= AFTER_SAMPLES:
                self._record(
                    window, pend["occurrence"]["painted"], ("empty", ""),
                    {"cursor_x": pend["occurrence"]["cursor_x"],
                     "cursor_y": pend["occurrence"]["cursor_y"],
                     "in_mode": pend["occurrence"]["in_mode"]},
                    pend["occurrence"]["screen_tail"],
                    note=("AMBUSHED residue, caught by the soak sampler. "
                          f"before={len(pend['before'])} samples, "
                          f"after={len(pend['after'])} samples. "
                          "Timeline in this note's companion fields is what a "
                          "single frame could never show: "
                          f"BEFORE={pend['before']!r} AFTER={pend['after']!r}"))
                self._pending_after.pop(window, None)

        if s["disagrees"] and self._latched.get(window) != s["painted"]:
            self._latched[window] = s["painted"]
            self._pending_after[window] = {
                "occurrence": s,
                "before": [self._slim(x) for x in ring],
                "after": [],
            }
        elif not s["disagrees"]:
            self._latched.pop(window, None)

        ring.append(s)
        return s

    def windows(self) -> list:
        out = []
        for line in _tmux(["list-panes", "-a", "-F",
                           "#{session_name}\t#{window_name}"]).splitlines():
            p = line.split("\t")
            if len(p) == 2 and p[0] == SESSION and p[1] not in out:
                out.append(p[1])
        return out
