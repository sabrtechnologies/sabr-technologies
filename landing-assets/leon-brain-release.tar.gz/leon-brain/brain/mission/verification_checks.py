"""
Verification Checks — concrete implementations for common verification tasks.

These check specific claims at the layers Dean actually experiences.
"""

import logging
import subprocess
import json
import requests
import time
from typing import Optional, Dict, Any
from verification_gate import VerificationLayer, VerificationGate, get_verification_gate

log = logging.getLogger("leon.mission.verification_checks")


class WebsiteVerificationChecks:
    """Verify website deployment and functionality."""

    @staticmethod
    def check_live_page_renders(url: str, expected_text: Optional[str] = None) -> Dict[str, Any]:
        """Check if a URL renders and optionally contains expected text."""
        try:
            resp = requests.get(url, timeout=10)
            passed = resp.status_code == 200

            if passed and expected_text:
                passed = expected_text.lower() in resp.text.lower()

            return {
                "passed": passed,
                "status_code": resp.status_code,
                "content_length": len(resp.text),
                "has_expected_text": expected_text in resp.text if expected_text else None,
                "url": url,
            }
        except Exception as e:
            return {"passed": False, "error": str(e), "url": url}

    @staticmethod
    def check_live_api_endpoint(url: str, expected_fields: Optional[list] = None) -> Dict[str, Any]:
        """Check if an API endpoint responds with valid JSON and expected fields."""
        try:
            resp = requests.get(url, timeout=10)
            data = resp.json()

            passed = resp.status_code == 200
            if passed and expected_fields:
                passed = all(field in data for field in expected_fields)

            return {
                "passed": passed,
                "status_code": resp.status_code,
                "response_keys": list(data.keys()) if isinstance(data, dict) else None,
                "expected_fields_present": expected_fields if not passed else None,
                "url": url,
            }
        except Exception as e:
            return {"passed": False, "error": str(e), "url": url}

    @staticmethod
    def check_live_database_value(
        table: str,
        column: str,
        where_clause: str,
        expected_value: Any,
        db_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """Check a live database value. Requires db_url or detection from env."""
        try:
            import psycopg2

            if not db_url:
                # Try to read from env or Railway database URL
                db_url = subprocess.check_output(
                    "railway env | grep DATABASE_URL || echo ''",
                    shell=True,
                    text=True
                ).strip()

            if not db_url:
                return {"passed": False, "error": "No database URL found"}

            conn = psycopg2.connect(db_url)
            cursor = conn.cursor()

            query = f"SELECT {column} FROM {table} WHERE {where_clause}"
            cursor.execute(query)
            result = cursor.fetchone()

            conn.close()

            if not result:
                return {"passed": False, "error": f"No row found for {where_clause}"}

            actual_value = result[0]
            passed = actual_value == expected_value

            return {
                "passed": passed,
                "table": table,
                "column": column,
                "where_clause": where_clause,
                "expected": expected_value,
                "actual": actual_value,
            }
        except Exception as e:
            return {"passed": False, "error": str(e)}


class CodeVerificationChecks:
    """Verify code-level claims (use as fallback only)."""

    @staticmethod
    def check_file_contains(file_path: str, text: str) -> Dict[str, Any]:
        """Check if a file on disk contains specific text."""
        try:
            with open(file_path) as f:
                content = f.read()

            passed = text in content
            return {
                "passed": passed,
                "file": file_path,
                "found": passed,
                "file_size": len(content),
            }
        except Exception as e:
            return {"passed": False, "error": str(e), "file": file_path}

    @staticmethod
    def check_git_commit_exists(repo_path: str, commit_msg: str) -> Dict[str, Any]:
        """Check if a commit with a message exists."""
        try:
            result = subprocess.run(
                ["git", "-C", repo_path, "log", "--grep", commit_msg, "--oneline"],
                capture_output=True,
                text=True,
                timeout=5
            )
            passed = bool(result.stdout.strip())
            return {
                "passed": passed,
                "repo": repo_path,
                "commit_found": passed,
                "matches": result.stdout.strip().split("\n") if passed else [],
            }
        except Exception as e:
            return {"passed": False, "error": str(e), "repo": repo_path}


def verify_payment_integration(*, checkout_url, status_url, expected_text,
                               expected_fields, table, column, where_clause,
                               expected_value, claim):
    """Verify explicitly configured checkout, API and database evidence."""
    gate = get_verification_gate()
    checks = {
        VerificationLayer.LIVE_CUSTOMER_FACING: lambda: WebsiteVerificationChecks.check_live_page_renders(
            checkout_url, expected_text=expected_text),
        VerificationLayer.LIVE_API_ENDPOINT: lambda: WebsiteVerificationChecks.check_live_api_endpoint(
            status_url, expected_fields=expected_fields),
        VerificationLayer.LIVE_DATABASE: lambda: WebsiteVerificationChecks.check_live_database_value(
            table=table, column=column, where_clause=where_clause,
            expected_value=expected_value),
    }
    return gate.verify_claim(
        claim=claim, check_functions=checks,
        required_layers=[VerificationLayer.LIVE_CUSTOMER_FACING])


def __getattr__(name):
    """Preserve original-only named checks without shipping their configuration."""
    from functools import partial
    from brain.origin import owner_runtime_config
    config = owner_runtime_config("payment_verifications", {}).get(name)
    if config is None:
        raise AttributeError(name)
    return partial(verify_payment_integration, **config)


def verify_webpage_deployed(url: str, expected_text: str):
    """
    Generic verification that a webpage has been deployed and contains expected content.
    """
    gate = get_verification_gate()

    checks = {
        VerificationLayer.LIVE_CUSTOMER_FACING: lambda: WebsiteVerificationChecks.check_live_page_renders(
            url, expected_text=expected_text
        ),
    }

    attempt = gate.verify_claim(
        claim=f"Webpage {url} is deployed with content '{expected_text}'",
        check_functions=checks,
        required_layers=[VerificationLayer.LIVE_CUSTOMER_FACING]
    )

    return attempt


def verify_api_returns_data(endpoint: str, expected_fields: list):
    """
    Generic verification that an API endpoint returns expected JSON.
    """
    gate = get_verification_gate()

    checks = {
        VerificationLayer.LIVE_API_ENDPOINT: lambda: WebsiteVerificationChecks.check_live_api_endpoint(
            endpoint, expected_fields=expected_fields
        ),
    }

    attempt = gate.verify_claim(
        claim=f"API endpoint {endpoint} returns data with fields {expected_fields}",
        check_functions=checks,
        required_layers=[VerificationLayer.LIVE_API_ENDPOINT]
    )

    return attempt
