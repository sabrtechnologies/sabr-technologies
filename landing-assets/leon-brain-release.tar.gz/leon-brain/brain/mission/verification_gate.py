"""
Verification Gate — Leon's enforcement layer for the DEBUGGING RULE.

Every claim of "fixed" or "done" must pass through a verification gate that checks
from the layer Dean experiences, not the layer Leon built from.

This is a hard guard. It fails closed. No exceptions.
"""

import json
import logging
import os
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from enum import Enum
from typing import Optional, Callable, Any

log = logging.getLogger("leon.mission.verification_gate")

AUDIT_DIR = Path(__file__).resolve().parents[2] / "brain_state" / "verification_audits"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


class VerificationLayer(Enum):
    """Layers at which verification can happen. Ranked by closeness to Dean's experience."""
    LIVE_CUSTOMER_FACING = 1  # What Dean (or a customer) actually sees in a browser
    LIVE_API_ENDPOINT = 2     # What the deployed API returns when queried
    LIVE_DATABASE = 3         # The actual database on the live server
    STAGING = 4               # Pre-production mirror (NOT the same as live)
    LOCAL_DISK = 5            # Code on disk, git commit, etc. (WORST layer)


class VerificationOutcome(Enum):
    PASSED = "passed"
    FAILED = "failed"
    INCONCLUSIVE = "inconclusive"
    BLOCKED = "blocked"


@dataclass
class VerificationAttempt:
    """A single attempt to verify a claim."""
    claim: str                              # "Example checkout integration is complete"
    required_layers: list[VerificationLayer]  # Min layers needed to verify
    layers_checked: dict[VerificationLayer, dict]  # {layer: {status, result, timestamp}}
    outcome: VerificationOutcome
    confidence: float                       # 0.0 to 1.0; how sure are we
    evidence: dict[str, Any]                # Raw data supporting the claim
    checked_at: float

    def to_json(self):
        return {
            "claim": self.claim,
            "required_layers": [l.name for l in self.required_layers],
            "layers_checked": {
                layer.name: {
                    "status": info.get("status"),
                    "result": info.get("result"),
                    "timestamp": info.get("timestamp"),
                    "error": info.get("error"),
                }
                for layer, info in self.layers_checked.items()
            },
            "outcome": self.outcome.value,
            "confidence": self.confidence,
            "evidence": self.evidence,
            "checked_at": self.checked_at,
        }


class VerificationGate:
    """
    Enforcer for verification. Every claim must be backed by evidence from
    the layers Dean actually experiences.
    """

    def __init__(self):
        self.audit_log = AUDIT_DIR / f"verifications_{datetime.now().strftime('%Y%m%d')}.jsonl"
        self.failed_claims = []

    def verify_claim(
        self,
        claim: str,
        check_functions: dict[VerificationLayer, Callable],
        required_layers: Optional[list[VerificationLayer]] = None,
        allow_lower_layers_only: bool = False
    ) -> VerificationAttempt:
        """
        Verify a claim by running checks at specified layers.

        Args:
            claim: Human description of what we're verifying
            check_functions: {layer: callable_that_returns_bool_or_dict}
            required_layers: Which layers MUST pass (default: [LIVE_CUSTOMER_FACING])
            allow_lower_layers_only: If True, only lower-layer checks allowed (debug mode)

        Returns:
            VerificationAttempt with full audit trail
        """
        if required_layers is None:
            required_layers = [VerificationLayer.LIVE_CUSTOMER_FACING]

        # Fail closed: if only lower layers are checked and we claim success,
        # that's a verification failure even if the lower layers pass.
        attempt = VerificationAttempt(
            claim=claim,
            required_layers=required_layers,
            layers_checked={},
            outcome=VerificationOutcome.BLOCKED,
            confidence=0.0,
            evidence={},
            checked_at=time.time(),
        )

        layers_passed = set()
        layers_failed = set()

        for layer, check_fn in sorted(check_functions.items(), key=lambda x: x[0].value):
            try:
                result = check_fn()
                passed = bool(result) if isinstance(result, bool) else result.get("passed", False)

                attempt.layers_checked[layer] = {
                    "status": "passed" if passed else "failed",
                    "result": result if isinstance(result, dict) else {"value": result},
                    "timestamp": time.time(),
                    "error": None,
                }

                if passed:
                    layers_passed.add(layer)
                else:
                    layers_failed.add(layer)

            except Exception as e:
                attempt.layers_checked[layer] = {
                    "status": "error",
                    "result": None,
                    "timestamp": time.time(),
                    "error": str(e),
                }
                layers_failed.add(layer)

        # Determine outcome
        highest_passing_layer = min(layers_passed) if layers_passed else None
        highest_required_layer = min(required_layers)

        if allow_lower_layers_only:
            # Debug mode: only lower (worse) layers can be checked
            if highest_passing_layer and highest_passing_layer.value >= highest_required_layer.value:
                attempt.outcome = VerificationOutcome.FAILED
                attempt.confidence = 0.0
                log.error(
                    f"VERIFICATION FAIL [debug mode violated]: {claim} "
                    f"passed {highest_passing_layer.name} but debug mode doesn't allow it"
                )
            else:
                # Lower layers passed, that's fine for debug
                attempt.outcome = VerificationOutcome.PASSED
                attempt.confidence = 0.5
        else:
            # Normal mode: required layers must pass
            if highest_passing_layer and highest_passing_layer.value <= highest_required_layer.value:
                # We passed a required layer
                attempt.outcome = VerificationOutcome.PASSED
                attempt.confidence = 1.0
            elif highest_passing_layer:
                # We passed a layer, but not a required one
                attempt.outcome = VerificationOutcome.INCONCLUSIVE
                attempt.confidence = 0.5
                log.warning(
                    f"VERIFICATION INCONCLUSIVE: {claim} "
                    f"passed {highest_passing_layer.name} but requires {highest_required_layer.name}"
                )
            else:
                # Nothing passed
                attempt.outcome = VerificationOutcome.FAILED
                attempt.confidence = 0.0
                log.error(f"VERIFICATION FAIL: {claim} — no layers passed")

        # Write to audit log
        self._log_attempt(attempt)

        if attempt.outcome == VerificationOutcome.FAILED:
            self.failed_claims.append(attempt)

        return attempt

    def _log_attempt(self, attempt: VerificationAttempt):
        """Persist verification attempt to audit log."""
        with open(self.audit_log, "a") as f:
            f.write(json.dumps(attempt.to_json()) + "\n")

    def assert_verified(self, attempt: VerificationAttempt, message: str = ""):
        """
        Raise an exception if verification did not pass.
        Use this to enforce verification before claiming success to Dean.
        """
        if attempt.outcome != VerificationOutcome.PASSED:
            error_msg = (
                f"VERIFICATION REQUIRED: {attempt.claim}\n"
                f"Outcome: {attempt.outcome.value}\n"
                f"Confidence: {attempt.confidence}\n"
            )
            if message:
                error_msg += f"Context: {message}\n"
            error_msg += f"Layers checked:\n"
            for layer, info in attempt.layers_checked.items():
                error_msg += f"  {layer.name}: {info['status']}\n"

            log.error(error_msg)
            raise AssertionError(error_msg)

    def get_audit_report(self, hours: int = 24) -> dict:
        """Generate an audit report of recent verification attempts."""
        cutoff = time.time() - (hours * 3600)
        attempts = []

        if self.audit_log.exists():
            with open(self.audit_log) as f:
                for line in f:
                    try:
                        data = json.loads(line)
                        if data.get("checked_at", 0) > cutoff:
                            attempts.append(data)
                    except json.JSONDecodeError:
                        pass

        passed = sum(1 for a in attempts if a.get("outcome") == "passed")
        failed = sum(1 for a in attempts if a.get("outcome") == "failed")
        inconclusive = sum(1 for a in attempts if a.get("outcome") == "inconclusive")

        return {
            "period_hours": hours,
            "total_attempts": len(attempts),
            "passed": passed,
            "failed": failed,
            "inconclusive": inconclusive,
            "success_rate": passed / len(attempts) if attempts else 0.0,
            "recent_failures": [a for a in attempts if a.get("outcome") == "failed"][-5:],
        }


# Global instance
_gate = None

def get_verification_gate() -> VerificationGate:
    global _gate
    if _gate is None:
        _gate = VerificationGate()
    return _gate
