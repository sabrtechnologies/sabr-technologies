"""
Phase 17 — Autopilot Scheduler: continuous project operator.

Runs periodic scans across all projects, executes Tier 1/2 actions
automatically, queues Tier 3 for approval, blocks Tier 4.
Integrates with workspace/terminal awareness via tmux.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
from datetime import datetime
from typing import Any, Callable, Optional

from brain.mission.autonomy import (
    ActionExecutor, Tier, classify, ActionStatus, Action,
)
from brain.mission.planner import ActionPlanner, Evidence, _run_cmd

log = logging.getLogger("leon.mission.autopilot")


class AutopilotScheduler:
    """Continuous project operator — the beating heart of Phase 17."""

    def __init__(
        self,
        executor: ActionExecutor,
        planner: ActionPlanner,
        registry=None,
        state_engine=None,
        connectors=None,
        cred_awareness=None,
        decisions=None,
        broadcast: Callable | None = None,
        tts_say: Callable | None = None,
        knowledge_store=None,
        brain=None,
        interval_s: float = 300,  # 5 min default
    ):
        self.executor = executor
        self.planner = planner
        self._brain_ref = brain
        self.registry = registry
        self.state_engine = state_engine
        self.connectors = connectors
        self.cred_awareness = cred_awareness
        self.decisions = decisions
        self._broadcast = broadcast
        self._tts_say = tts_say
        self._interval = interval_s
        self._running = False
        self._thread: threading.Thread | None = None
        self._last_tick: float = 0
        self._tick_count: int = 0
        self._register_default_handlers()
        # Phase 17 — Auto-Fixer: diagnose and fix problems, not just report them
        from brain.mission.fixer import AutoFixer
        from brain.mission.operator import Operator
        from brain.mission.alive import (
            DesktopNotifier, TerminalResurrector, CIFixer, GitHubWatcher,
            PriorityEngine, DailyReporter, SelfHealthMonitor, MorningBriefing,
        )
        from brain.mission.brain_bridge import BrainBridge
        from brain.mission.consciousness import Consciousness
        self.consciousness = Consciousness(broadcast=broadcast, tts_say=tts_say)
        self.fixer = AutoFixer(registry=registry, consciousness=self.consciousness)
        self.operator = Operator(registry=registry, consciousness=self.consciousness,
                                  knowledge_store=knowledge_store)
        self.brain_bridge = BrainBridge(brain=brain)
        self.notifier = DesktopNotifier()
        self.terminal_resurrector = TerminalResurrector()
        self.ci_fixer = CIFixer()
        self.github_watcher = GitHubWatcher()
        self.priority = PriorityEngine(registry=registry, state_engine=state_engine, decisions=decisions)
        self.health_monitor = SelfHealthMonitor()
        self.daily_reporter = DailyReporter(
            executor=executor, registry=registry, priority=self.priority,
            broadcast=broadcast, tts_say=tts_say, notifier=self.notifier)
        self.morning_briefing = MorningBriefing(
            registry=registry, state_engine=state_engine, connectors=connectors,
            decisions=decisions, priority=self.priority, github_watcher=self.github_watcher,
            broadcast=broadcast, tts_say=tts_say, notifier=self.notifier)
        self._morning_delivered_today: str = ""
        self._daily_delivered_today: str = ""
        self._tick_lock = threading.Lock()
        log.info("AutopilotScheduler ready (interval=%ds) — FULLY ALIVE", interval_s)

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="autopilot-scheduler")
        self._thread.start()
        log.info("Autopilot started")

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                now = time.time()
                if now - self._last_tick >= self._interval:
                    self._tick()
                    self._last_tick = now
            except Exception as e:
                log.error("Autopilot tick error: %s", e)

            # Timed events: morning briefing + daily report
            try:
                self._check_timed_events()
            except Exception as e:
                log.error("Timed event error: %s", e)

            time.sleep(30)

    def tick(self, force: bool = False) -> dict:
        """Public tick — can be called manually or by the loop."""
        if not force and (time.time() - self._last_tick) < self._interval:
            return {"skipped": True, "next_in_s": int(self._interval - (time.time() - self._last_tick))}
        if not self._tick_lock.acquire(blocking=False):
            return {"skipped": True, "reason": "tick already in progress"}
        try:
            return self._tick()
        finally:
            self._tick_lock.release()

    def _tick(self) -> dict:
        """One full autopilot cycle — scan, act, then TELL DEAN what happened."""
        self._tick_count += 1
        start = time.time()
        results = {"tick": self._tick_count, "timestamp": start, "actions": [], "workspace": []}

        # 0. Read brain state — SNN drives behavior this tick
        brain_config = self.brain_bridge.get_config()
        results["brain_config"] = {
            "max_tier2": brain_config.max_tier2_actions,
            "auto_push": brain_config.auto_push,
            "deep_diagnosis": brain_config.deep_diagnosis,
            "retry_limit": brain_config.retry_limit,
        }

        # 1. Plan actions for all projects
        planned = self.planner.plan_all()
        results["planned"] = len(planned)

        # 2. Execute planned actions — brain state limits Tier 2 count
        executed = self.planner.execute_plan(planned, max_actions=30)
        results["actions"] = executed

        # 3. Workspace scan
        workspaces = self.planner.scan_workspaces()
        stuck = self.planner.detect_stuck_terminals()
        results["workspace"] = {"terminals": len(workspaces), "stuck": len(stuck)}
        if stuck:
            results["stuck_terminals"] = [{"name": s["name"], "idle_s": s["idle_seconds"]} for s in stuck]

        # 4. Evidence-based checklist updates
        self._update_checklists_from_evidence(executed)

        # 5. Stats
        elapsed = time.time() - start
        succeeded = sum(1 for a in executed if a.get("status") == "succeeded")
        queued = sum(1 for a in executed if a.get("status") == "awaiting_approval")
        failed = sum(1 for a in executed if a.get("status") == "failed")

        results["summary"] = {
            "executed": len(executed),
            "succeeded": succeeded,
            "queued_for_approval": queued,
            "failed": failed,
            "elapsed_s": round(elapsed, 2),
        }

        # 6. Build human-readable findings and SURFACE them to Dean
        findings = self._build_findings(executed, stuck)
        results["findings"] = findings

        # Surface scan findings (CI failures, missing creds, etc.)
        if findings["has_news"]:
            self._surface_to_dean(findings)

        # ALWAYS run fixer + operator — even when scan is clean,
        # there may be unpushed commits, outdated deps, idle terminals
        fixer_report = {"diagnosed": [], "fixed": [], "needs_approval": [], "cant_fix": []}
        try:
            if findings["has_news"]:
                fixer_report = self.fixer.process_findings(findings)
            results["fixer"] = {
                "fixed": len(fixer_report.get("fixed", [])),
                "diagnosed": len(fixer_report.get("diagnosed", [])),
                "needs_approval": len(fixer_report.get("needs_approval", [])),
                "cant_fix": len(fixer_report.get("cant_fix", [])),
            }
        except Exception as e:
            log.error("Fixer failed: %s", e)
            results["fixer"] = {"error": str(e)}

        # Operator: push commits, update deps, resurrect terminals, advance projects
        try:
            op_report = self.operator.operate(fixer_report, findings)
            results["operator"] = {
                "fixed": len(op_report.get("fixed", [])),
                "advanced": len(op_report.get("advanced", [])),
                "terminal_actions": len(op_report.get("terminal_actions", [])),
                "pr_prepared": len(op_report.get("pr_prepared", [])),
                "needs_dean": len(op_report.get("needs_dean", [])),
            }
            # REWARD FEEDBACK — outcomes shape the brain
            for fix in op_report.get("fixed", []):
                self.brain_bridge.reward_success(fix.get("action", "fix"), fix.get("project", ""))
            for adv in op_report.get("advanced", []):
                if adv.get("acted"):
                    self.brain_bridge.reward_success(adv.get("type", "advance"), adv.get("project", ""))
                elif adv.get("type") == "push_failed":
                    self.brain_bridge.reward_failure("push_failed", adv.get("project", ""))
        except Exception as e:
            log.error("Operator failed: %s", e)
            results["operator"] = {"error": str(e)}

        # 8. Desktop notification for important findings
        try:
            if findings["has_news"]:
                voice = findings.get("voice_text", "")
                if voice:
                    self.notifier.notify("Leon Autopilot", voice, urgency="normal")
            op_fixed = results.get("operator", {}).get("fixed", 0)
            op_advanced = results.get("operator", {}).get("advanced", 0)
            if op_fixed or op_advanced:
                self.notifier.notify("Leon Operator",
                    f"Fixed {op_fixed}, advanced {op_advanced} projects")
        except Exception:
            pass

        # 9. GitHub activity check (every 3rd tick to avoid rate limits)
        if self._tick_count % 3 == 0:
            try:
                gh_activity = self.github_watcher.scan_all_repos(self.registry)
                notifs = gh_activity.get("notifications", [])
                new_repos = [r for r in gh_activity.get("repos", [])
                             if r.get("new_issues") or r.get("new_prs")]
                if notifs or new_repos:
                    results["github"] = {"notifications": len(notifs), "active_repos": len(new_repos)}
                    msg = []
                    if notifs:
                        msg.append(f"{len(notifs)} GitHub notifications")
                    for ra in new_repos:
                        for issue in ra.get("new_issues", []):
                            msg.append(f"New issue in {ra['repo']}: {issue.get('title','')[:50]}")
                        for pr in ra.get("new_prs", []):
                            msg.append(f"New PR in {ra['repo']}: {pr.get('title','')[:50]}")
                    if msg:
                        self.notifier.notify("Leon — GitHub", "\n".join(msg[:5]))
            except Exception:
                pass

        # 10. Self-health monitor (every 6th tick)
        if self._tick_count % 6 == 0:
            try:
                health = self.health_monitor.check()
                results["self_health"] = health
                if not health["healthy"]:
                    self.notifier.urgent("Leon Health Warning",
                        "\n".join(health["issues"][:3]))
            except Exception:
                pass

        # 11. DB cleanup — once per day, prune old noise
        if self._tick_count % 288 == 0:  # ~once per day at 5min intervals
            try:
                self.executor.cleanup(max_age_days=7)
            except Exception:
                pass

        self._last_tick = time.time()
        return results

    def _check_timed_events(self):
        """Morning briefing at 7am, daily report at 6pm."""
        now = datetime.now()
        today = now.strftime("%Y-%m-%d")

        # Morning briefing: 7:00-7:15 AM
        if 7 <= now.hour <= 7 and now.minute < 15 and self._morning_delivered_today != today:
            try:
                self.morning_briefing.deliver()
                self._morning_delivered_today = today
                log.info("Morning briefing delivered")
            except Exception as e:
                log.error("Morning briefing failed: %s", e)

        # Daily report: 6:00-6:15 PM
        if now.hour == 18 and now.minute < 15 and self._daily_delivered_today != today:
            try:
                self.daily_reporter.generate_and_deliver()
                self._daily_delivered_today = today
                log.info("Daily report delivered")
            except Exception as e:
                log.error("Daily report failed: %s", e)

    def _build_findings(self, executed: list[dict], stuck: list[dict]) -> dict:
        """Analyze action results and build a human-readable briefing.
        Only surfaces things Dean cares about — not '27 checks passed'."""
        findings = {
            "has_news": False,
            "failing_builds": [],
            "failing_health": [],
            "missing_creds": [],
            "stuck_terminals": [],
            "approvals_needed": [],
            "new_blockers": [],
            "summary_text": "",
            "voice_text": "",
        }

        # Map project IDs to names
        project_names = {}
        if self.registry:
            for p in self.registry.list_all():
                project_names[p["id"]] = p["name"]

        for action_info in executed:
            aid = action_info.get("action_id", "")
            aname = action_info.get("action_name", "")
            pid = action_info.get("project_id", "")
            pname = project_names.get(pid, pid[:8] if pid else "?")
            status = action_info.get("status", "")

            if status == "awaiting_approval":
                action = self.executor.get(aid) if aid else None
                desc = action.description if action else aname
                findings["approvals_needed"].append({"project": pname, "action": desc})
                findings["has_news"] = True
                continue

            if status != "succeeded" or not aid:
                continue

            action = self.executor.get(aid)
            if not action or not action.result:
                continue

            try:
                result = json.loads(action.result)
            except (json.JSONDecodeError, TypeError):
                continue

            # CI/CD failures — skip stale ones (> 7 days old on non-default branch)
            if aname == "github_workflow_status":
                conclusion = result.get("conclusion", "unknown")
                if conclusion not in ("success", "unknown"):
                    data = result.get("data", {}) if isinstance(result.get("data"), dict) else {}
                    created = data.get("createdAt", "")
                    branch = data.get("headBranch", "")
                    is_stale = False
                    if created and branch not in ("main", "master"):
                        try:
                            from datetime import datetime as _dt
                            run_time = _dt.fromisoformat(created.replace("Z", "+00:00"))
                            age_days = (datetime.now(_dt.now().astimezone().tzinfo) - run_time).days
                            if age_days > 7:
                                is_stale = True
                        except Exception:
                            pass
                    if not is_stale:
                        findings["failing_builds"].append({
                            "project": pname, "conclusion": conclusion,
                            "detail": data.get("name", ""),
                        })
                        findings["has_news"] = True

            # Health check failures
            if aname == "backend_health":
                if not result.get("ok"):
                    findings["failing_health"].append({
                        "project": pname,
                        "url": result.get("data", {}).get("url", "") if isinstance(result.get("data"), dict) else "",
                    })
                    findings["has_news"] = True

            # Missing credentials
            if aname == "credential_scan":
                missing = result.get("missing", [])
                if missing:
                    findings["missing_creds"].append({
                        "project": pname, "missing": missing,
                    })
                    findings["has_news"] = True

        # Stuck terminals: waiting-on-input flags immediately; plain idle only if > 30 min
        long_stuck = [s for s in stuck
                      if s.get("waiting_reason") or s.get("idle_seconds", 0) > 1800]
        if long_stuck:
            findings["stuck_terminals"] = [{"name": s["name"],
                                             "idle_min": round(s.get("idle_seconds", 0) / 60),
                                             "waiting_reason": s.get("waiting_reason", "")}
                                            for s in long_stuck]
            findings["has_news"] = True

        # Open decisions nearing deadline
        if self.decisions:
            open_d = self.decisions.list_all(status="open")
            # Just flag count for now
            if len(open_d) > 3:
                findings["has_news"] = True

        # Build text summaries
        findings["summary_text"] = self._format_summary(findings)
        findings["voice_text"] = self._format_voice(findings)

        return findings

    def _format_summary(self, f: dict) -> str:
        """Markdown-ish summary for the dashboard cyan panel."""
        lines = []
        if f["failing_builds"]:
            for b in f["failing_builds"]:
                lines.append(f"CI FAILING: {b['project']} — {b['conclusion']}")
        if f["failing_health"]:
            for h in f["failing_health"]:
                lines.append(f"BACKEND DOWN: {h['project']}")
        if f["missing_creds"]:
            for c in f["missing_creds"]:
                lines.append(f"MISSING CREDS: {c['project']} — {', '.join(c['missing'][:3])}")
        if f["stuck_terminals"]:
            waiting = [s for s in f["stuck_terminals"] if s.get("waiting_reason")]
            idle = [s["name"] for s in f["stuck_terminals"] if not s.get("waiting_reason")]
            for s in waiting:
                lines.append(f"TERMINAL WAITING ON YOU: {s['name']} — {s['waiting_reason']} — ANSWER IT NOW or tell Dean")
            # Idle terminals are deliberately NOT surfaced. Dean, 2026-08-11:
            # terminals sitting idle are his business, not Leon's — parking one
            # is a decision, not a stall, and reporting it reads as nagging.
            # A terminal that is actually BLOCKED on a question still shows up
            # above via waiting_reason; that one is real and stays.
            _ = idle
        if f["approvals_needed"]:
            for a in f["approvals_needed"]:
                lines.append(f"NEEDS APPROVAL: {a['action']}")
        if not lines:
            return ""
        return "\n".join(lines)

    def _format_voice(self, f: dict) -> str:
        """Short spoken sentence for TTS — Jarvis style."""
        parts = []
        if f["failing_builds"]:
            names = list(set(b["project"] for b in f["failing_builds"]))
            if len(names) == 1:
                parts.append(f"{names[0]} build is failing")
            else:
                parts.append(f"{len(names)} projects have failing builds")
        if f["failing_health"]:
            names = [h["project"] for h in f["failing_health"]]
            parts.append(f"{', '.join(names)} backend is down")
        if f["missing_creds"]:
            count = sum(len(c["missing"]) for c in f["missing_creds"])
            parts.append(f"{count} missing credentials across {len(f['missing_creds'])} projects")
        if f["approvals_needed"]:
            parts.append(f"{len(f['approvals_needed'])} actions need your approval")
        if not parts:
            return ""
        return "Sir. " + ". ".join(parts) + "."

    def _surface_to_dean(self, findings: dict):
        """Queue findings for Leon's unified consciousness.
        Leon will mention these naturally in his next response,
        or speak proactively if Dean hasn't talked in 5 min."""
        voice = findings.get("voice_text", "")
        summary = findings.get("summary_text", "")
        if not voice and not summary:
            return

        urgency = "high" if findings.get("failing_builds") else "medium"
        self.consciousness.observe(
            source="autopilot",
            summary=voice or summary.split("\n")[0],
            detail=summary,
            urgency=urgency,
        )

    def _update_checklists_from_evidence(self, actions: list[dict]):
        """Update checklist items based on action evidence."""
        if not self.state_engine:
            return
        for action_info in actions:
            if action_info.get("status") != "succeeded":
                continue
            pid = action_info.get("project_id", "")
            if not pid:
                continue
            aname = action_info.get("action_name", "")

            # Map action results to checklist items
            if aname == "github_repo_info":
                self.state_engine.update_item(pid, "repo_exists",
                                               status="done", evidence="GitHub repo confirmed via gh CLI",
                                               confidence=1.0)
            elif aname == "github_workflow_status":
                action = self.executor.get(action_info.get("action_id", ""))
                if action and action.result:
                    try:
                        result = json.loads(action.result)
                        if result.get("conclusion") == "success":
                            self.state_engine.update_item(pid, "codemagic_build_green",
                                                           status="done",
                                                           evidence="CI workflow passing",
                                                           confidence=0.9)
                    except (json.JSONDecodeError, TypeError):
                        pass
            elif aname == "backend_health":
                action = self.executor.get(action_info.get("action_id", ""))
                if action and action.status == "succeeded":
                    self.state_engine.update_item(pid, "backend_healthy",
                                                   status="done",
                                                   evidence="Health check passed",
                                                   confidence=1.0)
            elif aname == "credential_scan":
                action = self.executor.get(action_info.get("action_id", ""))
                if action and action.result:
                    try:
                        result = json.loads(action.result)
                        if result.get("all_present"):
                            self.state_engine.update_item(pid, "secrets_configured",
                                                           status="done",
                                                           evidence="All required creds present",
                                                           confidence=1.0)
                        else:
                            missing = result.get("missing", [])
                            self.state_engine.update_item(pid, "secrets_configured",
                                                           status="blocked",
                                                           blocker=f"Missing: {', '.join(missing)}",
                                                           confidence=0.9)
                    except (json.JSONDecodeError, TypeError):
                        pass

    # ── Default action handlers ─────────────────────────────────────────

    def _register_default_handlers(self):
        """Register handlers for common Tier 1/2 actions."""

        def _h_github_pr_status(action: Action, ctx: dict) -> dict:
            args = ctx.get("handler_args", {})
            owner, repo = args.get("owner", ""), args.get("repo", "")
            if not owner or not repo:
                return {"ok": False, "error": "Missing owner/repo"}
            if self.connectors:
                result = self.connectors.github_latest_pr(owner, repo)
                return {"ok": result.get("ok", False), "data": result.get("data"),
                        "evidence": Evidence.from_build_status("github", f"{owner}/{repo}",
                                    result.get("data", {}).get("state", "unknown") if isinstance(result.get("data"), dict) else "unknown")}
            return {"ok": False, "error": "No connectors"}

        def _h_github_workflow_status(action: Action, ctx: dict) -> dict:
            args = ctx.get("handler_args", {})
            owner, repo = args.get("owner", ""), args.get("repo", "")
            if not owner or not repo:
                return {"ok": False, "error": "Missing owner/repo"}
            if self.connectors:
                result = self.connectors.github_workflow_runs(owner, repo, limit=1)
                runs = result.get("data", []) if result.get("ok") else []
                latest = runs[0] if isinstance(runs, list) and runs else {}
                return {"ok": result.get("ok", False), "data": latest,
                        "conclusion": latest.get("conclusion", "unknown"),
                        "evidence": Evidence.from_build_status("github_actions", f"{owner}/{repo}",
                                    latest.get("conclusion", "unknown"))}
            return {"ok": False, "error": "No connectors"}

        def _h_backend_health(action: Action, ctx: dict) -> dict:
            args = ctx.get("handler_args", {})
            url = args.get("url", "")
            if not url:
                return {"ok": False, "error": "Missing URL"}
            if self.connectors:
                result = self.connectors.health_check(url)
                return {"ok": result.get("ok", False), "data": result,
                        "evidence": Evidence.from_health_check(url, result.get("ok", False),
                                    result.get("status_code", 0))}
            return {"ok": False, "error": "No connectors"}

        def _h_credential_scan(action: Action, ctx: dict) -> dict:
            args = ctx.get("handler_args", {})
            project = args.get("project", {})
            if self.cred_awareness:
                result = self.cred_awareness.check_project_creds(project)
                return {"ok": True, "all_present": result.get("all_present", False),
                        "missing": result.get("missing", []),
                        "evidence": {"type": "credential_scan", "project": project.get("name", ""),
                                     "all_present": result.get("all_present", False)}}
            return {"ok": False, "error": "No cred awareness"}

        def _h_git_status(action: Action, ctx: dict) -> dict:
            args = ctx.get("handler_args", {})
            repo_path = args.get("repo_path", "")
            if not repo_path or not os.path.isdir(repo_path):
                return {"ok": False, "error": f"Path not found: {repo_path}"}
            evidence = Evidence.from_git_status(repo_path)
            return {"ok": True, "data": evidence, "evidence": evidence}

        def _h_check_status(action: Action, ctx: dict) -> dict:
            """Evaluate unchecked checklist items."""
            return {"ok": True, "result": "Checklist items flagged for evaluation"}

        def _h_project_scan(action: Action, ctx: dict) -> dict:
            if self.registry:
                return {"ok": True, "data": self.registry.summary()}
            return {"ok": False, "error": "No registry"}

        # Register all
        self.executor.register_handler("github_pr_status", _h_github_pr_status)
        self.executor.register_handler("github_workflow_status", _h_github_workflow_status)
        self.executor.register_handler("backend_health", _h_backend_health)
        self.executor.register_handler("credential_scan", _h_credential_scan)
        self.executor.register_handler("git_status", _h_git_status)
        self.executor.register_handler("check_status", _h_check_status)
        self.executor.register_handler("project_scan", _h_project_scan)

    # ── Status ──────────────────────────────────────────────────────────

    def status(self) -> dict:
        return {
            "running": self._running,
            "tick_count": self._tick_count,
            "last_tick": self._last_tick,
            "interval_s": self._interval,
            "next_tick_in": max(0, self._interval - (time.time() - self._last_tick)) if self._last_tick else 0,
            "executor_stats": self.executor.stats(),
        }
