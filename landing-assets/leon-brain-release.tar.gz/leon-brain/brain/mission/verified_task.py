"""
Verified Task — decorator that wraps Leon's task execution with mandatory verification.

When Leon takes an action, this decorator ensures verification happens BEFORE
he reports success to Dean.

Usage:
    @verified_task(
        claim="Example checkout is wired up",
        verification_fn=verify_checkout,
        required_outcome="PASSED"
    )
    def wire_up_clover():
        # Do the work
        return "Clover wired"

    result = wire_up_clover()  # Decorator verifies before returning
"""

import functools
import logging
from typing import Callable, Optional, Any
from verification_gate import get_verification_gate, VerificationOutcome

log = logging.getLogger("leon.mission.verified_task")


def verified_task(
    claim: str,
    verification_fn: Callable[[], Any],
    required_outcome: str = "PASSED",
    allow_inconclusive: bool = False,
):
    """
    Decorator that enforces verification before a task is considered done.

    Args:
        claim: What we're verifying ("X is deployed and working")
        verification_fn: Callable that returns a VerificationAttempt
        required_outcome: "PASSED", "INCONCLUSIVE", etc. (default: "PASSED")
        allow_inconclusive: If True, INCONCLUSIVE outcome doesn't block
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            # Execute the task
            log.info(f"[VERIFIED_TASK] Starting: {claim}")
            try:
                result = fn(*args, **kwargs)
            except Exception as e:
                log.error(f"[VERIFIED_TASK] Task failed: {claim}")
                log.error(f"  Error: {e}")
                raise

            # Now verify
            log.info(f"[VERIFIED_TASK] Verifying: {claim}")
            gate = get_verification_gate()
            attempt = verification_fn()

            # Check outcome
            outcome_name = attempt.outcome.name if hasattr(attempt.outcome, 'name') else str(attempt.outcome)
            log.info(f"[VERIFIED_TASK] Verification outcome: {outcome_name} (confidence: {attempt.confidence})")

            if allow_inconclusive and outcome_name == "INCONCLUSIVE":
                log.warning(f"[VERIFIED_TASK] Inconclusive result allowed for: {claim}")
                return result

            if outcome_name != required_outcome:
                error_msg = (
                    f"VERIFICATION FAILED for: {claim}\n"
                    f"Expected: {required_outcome}\n"
                    f"Got: {outcome_name}\n"
                    f"Confidence: {attempt.confidence}\n"
                )
                log.error(error_msg)
                raise AssertionError(error_msg)

            log.info(f"[VERIFIED_TASK] ✓ VERIFIED: {claim}")
            return result

        return wrapper
    return decorator


def task_with_verification(
    claim: str,
    verification_checks: dict,
    required_layers: list,
):
    """
    Alternative: decorator that takes verification checks inline.

    Usage:
        @task_with_verification(
            claim="Homepage updated",
            verification_checks={
                VerificationLayer.LIVE_CUSTOMER_FACING: check_homepage_fn,
            },
            required_layers=[VerificationLayer.LIVE_CUSTOMER_FACING]
        )
        def update_homepage():
            # ...
            pass
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            # Execute task
            result = fn(*args, **kwargs)

            # Verify using the gate
            gate = get_verification_gate()
            attempt = gate.verify_claim(
                claim=claim,
                check_functions=verification_checks,
                required_layers=required_layers
            )

            # Fail if not verified
            gate.assert_verified(attempt, f"Task: {fn.__name__}")

            return result

        return wrapper
    return decorator


class VerificationContext:
    """Context manager for grouping related verifications."""

    def __init__(self, task_name: str):
        self.task_name = task_name
        self.attempts = []
        self.gate = get_verification_gate()

    def verify(self, claim: str, check_fn: Callable, required_layers: list):
        """Run a verification check within this context."""
        attempt = self.gate.verify_claim(
            claim=claim,
            check_functions={layer: check_fn for layer in required_layers},
            required_layers=required_layers
        )
        self.attempts.append(attempt)
        return attempt

    def require_all_passed(self):
        """Raise if any verification in this context failed."""
        failed = [a for a in self.attempts if a.outcome.name != "PASSED"]
        if failed:
            errors = "\n".join(
                f"  - {a.claim}: {a.outcome.name}" for a in failed
            )
            raise AssertionError(
                f"Verification failed for task '{self.task_name}':\n{errors}"
            )

    def __enter__(self):
        log.info(f"[VERIFICATION] Starting verification context: {self.task_name}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            # Task completed without exception, verify everything
            self.require_all_passed()
            log.info(f"[VERIFICATION] ✓ All checks passed for: {self.task_name}")
        else:
            log.error(f"[VERIFICATION] Task failed with exception: {exc_type.__name__}")
