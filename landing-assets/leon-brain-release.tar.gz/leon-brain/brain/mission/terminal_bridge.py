"""Terminal → autopilot queue bridge. Surfaces STALLED agent threads only.

THE PROBLEM IT SOLVES, precisely: the autoloop threads a pane, then goes quiet
on it — max rounds spent, refusal cutoff hit, min-gap not elapsed. The agent's
reply sits in the pending file and nobody is coming. Dean notices before Leon
does, and has to relay by hand.

WHAT IT DOES NOT DO, deliberately:
  * It NEVER calls consume(). The autoloop owns the event lifecycle; a second
    consumer would race it and each side would silently see half the events.
    Idempotency comes from our OWN digest cursor, not from mutating shared
    state another process depends on.
  * It does not surface replies the autoloop handled. That is the noise Dean
    is escaping. Those are logged as skips, never queued. (Awareness of every
    reply is a separate mechanism — the notification tap — which also does
    not touch pending().)

TWO FILTERS THAT ARE NOT OPTIONAL — measured, not guessed:
  1. NEWEST PER WINDOW. terminal_autoloop.py:337-339 processes only the newest
     event per window per pass and skips the rest, which are then never
     consumed. Live sample 2026-08-05: 24 pending events, ALL from one window,
     oldest 28 HOURS. 23 of 24 were superseded snapshots of the same
     conversation. Queuing them all would have flooded the queue with a day of
     dead replies.
  2. AGE FLOOR above GEN_TIMEOUT_S (300s). An event can legitimately sit
     unconsumed for five minutes while the autoloop is mid-generation ON it.
     Below the floor, "still pending" means "in flight", not "declined".
     Queuing there wakes Dean for work already underway.
"""
from __future__ import annotations

import json
import os
import time
from typing import Optional

STATE_DIR = os.environ.get("LEON_BRAIN_STATE") or os.path.join(
    __import__("pathlib").Path(__file__).resolve().parents[2], "brain_state")
CURSOR_PATH = os.path.join(STATE_DIR, "terminal_bridge_cursor.json")
LOG_PATH = os.path.join(STATE_DIR, "terminal_bridge.jsonl")

#: Above terminal_autoloop.GEN_TIMEOUT_S (300) with margin. Below this an
#: event may still be in flight.
MIN_AGE_S = float(os.environ.get("LEON_BRIDGE_MIN_AGE_S", "360"))
#: A burst of replies must not flood the queue.
MAX_PER_TICK = int(os.environ.get("LEON_BRIDGE_MAX_PER_TICK", "2"))
#: Cursor entries older than this are forgotten so the file cannot grow forever.
CURSOR_TTL_S = 7 * 24 * 3600


def _log(rec: dict) -> None:
    """Every queue-or-skip decision, with its reason. A bridge that silently
    drops events is worse than no bridge."""
    rec["ts"] = time.time()
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(LOG_PATH, "a") as fh:
            fh.write(json.dumps(rec) + "\n")
    except Exception:
        pass


def _cursor_load() -> dict:
    try:
        with open(CURSOR_PATH) as fh:
            return json.load(fh)
    except Exception:
        return {}


def _cursor_save(c: dict) -> None:
    cutoff = time.time() - CURSOR_TTL_S
    c = {d: t for d, t in c.items() if t >= cutoff}
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        tmp = CURSOR_PATH + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(c, fh)
        os.replace(tmp, CURSOR_PATH)
    except Exception:
        pass


def _summarise(text: str, limit: int = 400) -> str:
    """Last few non-empty lines — what the agent actually said last."""
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    tail = " / ".join(lines[-4:])
    return tail[:limit] + ("…" if len(tail) > limit else "")


def run_once(watcher=None, queue_goal=None, now: Optional[float] = None) -> dict:
    """One tick. Returns a summary dict; every decision is also logged."""
    now = time.time() if now is None else now
    if watcher is None:
        from brain.mission.terminal_loop import TerminalWatcher
        watcher = TerminalWatcher()
    if queue_goal is None:
        from brain.autopilot import EXTRA_TOOLS
        queue_goal = EXTRA_TOOLS["autopilot.queue_goal"]

    from brain.mission import terminal_loop as tl

    cursor = _cursor_load()
    stats = {"seen": 0, "queued": 0, "skipped": 0}

    events = list(watcher.pending())
    stats["seen"] = len(events)

    # FILTER 1 — newest per window. Everything else is a superseded snapshot.
    newest: dict = {}
    for ev in events:
        cur = newest.get(ev.window)
        if cur is None or ev.detected_at > cur.detected_at:
            if cur is not None:
                _log({"window": cur.window, "digest": cur.digest[:12],
                      "action": "skip", "reason": "superseded_by_newer"})
                stats["skipped"] += 1
            newest[ev.window] = ev
        else:
            _log({"window": ev.window, "digest": ev.digest[:12],
                  "action": "skip", "reason": "superseded_by_newer"})
            stats["skipped"] += 1

    for window, ev in sorted(newest.items()):
        d = ev.digest

        if d in cursor:
            _log({"window": window, "digest": d[:12], "action": "skip",
                  "reason": "already_queued_by_this_bridge"})
            stats["skipped"] += 1
            continue

        age = now - ev.detected_at
        if age < MIN_AGE_S:
            _log({"window": window, "digest": d[:12], "action": "skip",
                  "reason": "too_fresh_may_be_in_flight",
                  "age_s": round(age, 1), "floor_s": MIN_AGE_S})
            stats["skipped"] += 1
            continue

        if tl.is_busy(ev.text):
            _log({"window": window, "digest": d[:12], "action": "skip",
                  "reason": "pane_busy"})
            stats["skipped"] += 1
            continue

        summary = _summarise(ev.text)
        if not summary or tl.banner_present(ev.text) and len(summary) < 40:
            _log({"window": window, "digest": d[:12], "action": "skip",
                  "reason": "banner_or_empty_noise"})
            stats["skipped"] += 1
            continue

        if stats["queued"] >= MAX_PER_TICK:
            _log({"window": window, "digest": d[:12], "action": "skip",
                  "reason": "per_tick_cap", "cap": MAX_PER_TICK})
            stats["skipped"] += 1
            continue

        goal = (f"Terminal '{window}' replied and the autoloop went quiet on it "
                f"({int(age // 60)} min ago). Read the pane and continue the "
                f"thread, or close it out. Last from that pane: {summary}")
        try:
            res = queue_goal({"goal": goal, "priority": "high"})
        except Exception as e:
            _log({"window": window, "digest": d[:12], "action": "error",
                  "reason": f"queue_goal raised: {e!r}"})
            continue
        if not (isinstance(res, dict) and res.get("ok", True)):
            _log({"window": window, "digest": d[:12], "action": "error",
                  "reason": f"queue_goal refused: {res}"})
            continue

        cursor[d] = now
        stats["queued"] += 1
        _log({"window": window, "digest": d[:12], "action": "queued",
              "reason": "autoloop_quiet_on_threaded_pane",
              "age_s": round(age, 1), "goal_preview": goal[:120]})

    _cursor_save(cursor)
    return stats
