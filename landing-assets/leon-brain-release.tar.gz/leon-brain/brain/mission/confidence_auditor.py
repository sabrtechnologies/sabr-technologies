"""
Confidence Auditor — Leon's self-calibration system.

The problem: Leon is most confident EXACTLY when he's most likely to be wrong.
High confidence + incomplete information = systematic error.

This module tracks Leon's confidence claims vs. actual outcomes and rebuilds
his confidence model to be accurately calibrated.
"""

import json
import logging
import os
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from enum import Enum

log = logging.getLogger("leon.mission.confidence_auditor")

AUDIT_DIR = Path(__file__).resolve().parents[2] / "brain_state" / "confidence_audits"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)


class ConfidenceOutcome(Enum):
    """What actually happened vs. what Leon predicted."""
    CORRECT = "correct"
    INCORRECT = "incorrect"
    PARTIALLY_CORRECT = "partially_correct"
    IRRELEVANT = "irrelevant"  # Claim was made but didn't matter


@dataclass
class ConfidenceClaim:
    """A single confidence claim Leon made."""
    claim: str                          # "Example checkout is fixed"
    stated_confidence: float            # Leon's confidence 0.0-1.0
    supporting_reason: str              # Why was Leon confident
    layers_checked: List[str]           # What layers were verified
    actual_outcome: Optional[ConfidenceOutcome] = None  # What actually happened
    outcome_timestamp: Optional[float] = None
    notes: str = ""
    timestamp: float = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

    def to_dict(self):
        return {
            "claim": self.claim,
            "stated_confidence": self.stated_confidence,
            "supporting_reason": self.supporting_reason,
            "layers_checked": self.layers_checked,
            "actual_outcome": self.actual_outcome.value if self.actual_outcome else None,
            "outcome_timestamp": self.outcome_timestamp,
            "notes": self.notes,
            "timestamp": self.timestamp,
            "calibration_error": self._calibration_error(),
        }

    def _calibration_error(self) -> Optional[float]:
        """Return how wrong Leon's confidence was."""
        if self.actual_outcome is None:
            return None

        # Map outcome to a truth value
        if self.actual_outcome == ConfidenceOutcome.CORRECT:
            actual = 1.0
        elif self.actual_outcome == ConfidenceOutcome.PARTIALLY_CORRECT:
            actual = 0.5
        else:
            actual = 0.0

        # How wrong was the confidence?
        return abs(self.stated_confidence - actual)


class ConfidenceAuditor:
    """
    Track Leon's confidence claims and measure calibration over time.

    Key insight: if Leon's confidence histogram shows:
      - 90% confidence tasks succeed 50% of the time: OVERCONFIDENT
      - 50% confidence tasks succeed 80% of the time: UNDERCONFIDENT

    Then we need to apply a correction factor.
    """

    def __init__(self):
        self.audit_log = AUDIT_DIR / f"confidence_{datetime.now().strftime('%Y%m%d')}.jsonl"
        self.claims: List[ConfidenceClaim] = []
        self._load_historical()

    def _load_historical(self):
        """Load previously recorded claims."""
        if self.audit_log.exists():
            try:
                with open(self.audit_log) as f:
                    for line in f:
                        try:
                            data = json.loads(line)
                            # Reconstruct ConfidenceClaim from stored data
                            outcome = None
                            if data.get("actual_outcome"):
                                outcome = ConfidenceOutcome(data["actual_outcome"])

                            claim = ConfidenceClaim(
                                claim=data.get("claim", ""),
                                stated_confidence=data.get("stated_confidence", 0),
                                supporting_reason=data.get("supporting_reason", ""),
                                layers_checked=data.get("layers_checked", []),
                                actual_outcome=outcome,
                                outcome_timestamp=data.get("outcome_timestamp"),
                                notes=data.get("notes", ""),
                                timestamp=data.get("timestamp")
                            )
                            self.claims.append(claim)
                        except json.JSONDecodeError:
                            pass
            except Exception as e:
                log.error(f"Failed to load historical confidence data: {e}")

    def record_claim(
        self,
        claim: str,
        confidence: float,
        reason: str,
        layers_checked: Optional[List[str]] = None
    ) -> ConfidenceClaim:
        """
        Record a confidence claim Leon is making right now.
        Later, report_outcome() will score it.
        """
        if confidence < 0.0 or confidence > 1.0:
            raise ValueError(f"Confidence must be 0.0-1.0, got {confidence}")

        cc = ConfidenceClaim(
            claim=claim,
            stated_confidence=confidence,
            supporting_reason=reason,
            layers_checked=layers_checked or []
        )

        self.claims.append(cc)
        self._persist_claim(cc)

        log.info(f"[CONFIDENCE] Recorded: {confidence:.0%} - {claim}")

        return cc

    def report_outcome(
        self,
        claim: str,
        outcome: ConfidenceOutcome,
        notes: str = ""
    ):
        """
        Report what actually happened for a claim Leon made.
        """
        # Find the most recent matching claim
        matching = [c for c in self.claims if c.claim == claim and c.actual_outcome is None]

        if not matching:
            log.warning(f"No open confidence claim found for: {claim}")
            return

        claim_obj = matching[0]
        claim_obj.actual_outcome = outcome
        claim_obj.outcome_timestamp = time.time()
        claim_obj.notes = notes

        error = claim_obj._calibration_error()

        # Log the calibration error
        if error is not None:
            error_pct = error * 100
            if error > 0.3:
                log.warning(
                    f"[CONFIDENCE] CALIBRATION ERROR {error_pct:.0f}%: "
                    f"said {claim_obj.stated_confidence:.0%} but outcome was {outcome.name}"
                )
            else:
                log.info(
                    f"[CONFIDENCE] Calibrated: {claim_obj.stated_confidence:.0%} → {outcome.name}"
                )

        self._persist_claim(claim_obj)

    def _persist_claim(self, claim: ConfidenceClaim):
        """Write claim to audit log."""
        with open(self.audit_log, "a") as f:
            f.write(json.dumps(claim.to_dict()) + "\n")

    def get_calibration_report(self, hours: int = 24) -> Dict[str, Any]:
        """
        Analyze calibration: what confidence level → what actual success rate?
        """
        cutoff = time.time() - (hours * 3600)

        # Filter to recent claims with outcomes
        recent = [
            c for c in self.claims
            if c.timestamp and c.timestamp > cutoff and c.actual_outcome is not None
        ]

        if not recent:
            return {"error": "No calibration data yet"}

        # Bucket by stated confidence
        buckets = {}
        for conf_level in [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
            bucket_claims = [
                c for c in recent
                if abs(c.stated_confidence - conf_level) < 0.05
            ]
            if bucket_claims:
                successes = sum(1 for c in bucket_claims if c.actual_outcome == ConfidenceOutcome.CORRECT)
                success_rate = successes / len(bucket_claims)

                buckets[f"{conf_level:.0%}"] = {
                    "stated_confidence": conf_level,
                    "actual_success_rate": success_rate,
                    "count": len(bucket_claims),
                    "calibration_gap": success_rate - conf_level,
                    "claims": [c.claim for c in bucket_claims]
                }

        # Compute overall calibration gap
        all_successes = sum(1 for c in recent if c.actual_outcome == ConfidenceOutcome.CORRECT)
        overall_accuracy = all_successes / len(recent)
        average_stated_confidence = sum(c.stated_confidence for c in recent) / len(recent)
        overall_gap = overall_accuracy - average_stated_confidence

        # Find the worst bucket (most overconfident)
        worst_bucket = max(
            buckets.items(),
            key=lambda item: item[1]["stated_confidence"] - item[1]["actual_success_rate"],
            default=(None, {})
        )

        return {
            "period_hours": hours,
            "total_claims": len(recent),
            "correct": all_successes,
            "overall_accuracy": overall_accuracy,
            "average_stated_confidence": average_stated_confidence,
            "overall_calibration_gap": overall_gap,
            "buckets": buckets,
            "worst_overconfidence": {
                "level": worst_bucket[0],
                "gap": worst_bucket[1].get("calibration_gap", 0),
                "actual_rate": worst_bucket[1].get("actual_success_rate", 0)
            } if worst_bucket[0] else None,
            "recommendation": self._get_recommendation(overall_gap, buckets)
        }

    def _get_recommendation(self, overall_gap: float, buckets: Dict) -> str:
        """What should Leon do to improve calibration?"""
        if overall_gap > 0.3:
            return "UNDERCONFIDENT: Leon succeeds more often than he believes. Raise confidence estimates."
        elif overall_gap < -0.3:
            return "OVERCONFIDENT: Leon fails more often than expected. Lower confidence, check more layers."
        else:
            return "Well-calibrated"

    def get_outlier_claims(self, min_error: float = 0.5) -> List[Dict[str, Any]]:
        """Find claims where confidence was most wrong."""
        outliers = []

        for claim in self.claims:
            if claim.actual_outcome is not None:
                error = claim._calibration_error()
                if error and error >= min_error:
                    outliers.append({
                        "claim": claim.claim,
                        "stated_confidence": claim.stated_confidence,
                        "actual_outcome": claim.actual_outcome.name,
                        "calibration_error": error,
                        "reason": claim.supporting_reason
                    })

        # Sort by error descending
        outliers.sort(key=lambda x: x["calibration_error"], reverse=True)
        return outliers[:20]


# Global instance
_auditor = None

def get_confidence_auditor() -> ConfidenceAuditor:
    global _auditor
    if _auditor is None:
        _auditor = ConfidenceAuditor()
    return _auditor
