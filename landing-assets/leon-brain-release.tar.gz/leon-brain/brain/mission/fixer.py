"""
Phase 17 — Auto-Fixer: Leon diagnoses problems and fixes what he safely can.

For each finding from the autopilot tick, the fixer:
1. Diagnoses the root cause (pull logs, inspect code, check config)
2. Classifies whether a fix is safe (Tier 1/2) or needs approval (Tier 3)
3. Executes safe fixes automatically
4. Reports what it did and what it couldn't do

This is what turns Leon from a reporter into an operator.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import time
from typing import Any, Callable, Optional

log = logging.getLogger("leon.mission.fixer")


def _run(cmd: list[str], cwd: str | None = None, timeout: int = 30) -> dict:
    try:
        env = os.environ.copy()
        flutter_bin = os.path.expanduser("~/.flutter-sdk/bin")
        if os.path.isdir(flutter_bin) and flutter_bin not in env.get("PATH", ""):
            env["PATH"] = flutter_bin + ":" + env.get("PATH", "")
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd, env=env)
        return {"ok": r.returncode == 0, "stdout": r.stdout.strip()[:3000],
                "stderr": r.stderr.strip()[:1000], "code": r.returncode}
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return {"ok": False, "stdout": "", "stderr": str(e), "code": -1}


class AutoFixer:
    """Diagnose and fix problems Leon finds during autopilot scans."""

    def __init__(self, registry=None, consciousness=None,
                 broadcast=None, tts_say=None):
        self.registry = registry
        self._consciousness = consciousness
        self._broadcast = broadcast
        self._tts_say = tts_say
        self._session_path = os.path.expanduser("~/.openclaw/forever-sessions.json")
        self._project_paths: dict[str, str] = {}
        self._load_project_paths()
        log.info("AutoFixer ready")

    def _load_project_paths(self):
        """Load local paths from forever-sessions.json."""
        try:
            if os.path.exists(self._session_path):
                with open(self._session_path) as f:
                    data = json.load(f)
                for s in data.get("forever", []):
                    self._project_paths[s.get("windowName", "")] = s.get("path", "")
        except Exception:
            pass

    def _find_path(self, project_name: str) -> str | None:
        """Find local path for a project."""
        slug = project_name.lower().replace(" ", "-")
        # Direct match
        if slug in self._project_paths:
            p = self._project_paths[slug]
            if os.path.isdir(p):
                return p
        # Fuzzy match
        for wn, path in self._project_paths.items():
            if slug in wn or wn in slug:
                if os.path.isdir(path):
                    return path
        return None

    def process_findings(self, findings: dict) -> dict:
        """Take autopilot findings and fix what we can."""
        report = {
            "diagnosed": [],
            "fixed": [],
            "needs_approval": [],
            "cant_fix": [],
            "summary_text": "",
            "voice_text": "",
        }

        # 1. Diagnose and fix failing builds
        for build in findings.get("failing_builds", []):
            diagnosis = self._diagnose_ci_failure(build)
            report["diagnosed"].append(diagnosis)
            if diagnosis.get("fixable"):
                fix_result = self._attempt_ci_fix(diagnosis)
                if fix_result.get("fixed"):
                    report["fixed"].append(fix_result)
                elif fix_result.get("needs_approval"):
                    report["needs_approval"].append(fix_result)
                else:
                    report["cant_fix"].append(fix_result)
            else:
                report["cant_fix"].append(diagnosis)

        # 2. Handle missing credentials — can't auto-fix, but give exact instructions
        for cred_info in findings.get("missing_creds", []):
            instructions = self._cred_instructions(cred_info)
            report["cant_fix"].append(instructions)

        # 3. Handle stuck terminals — can check what they're doing.
        # Only ones genuinely BLOCKED on a question. A terminal that is merely
        # idle is Dean's call to make (his standing order, 2026-08-11): he parks
        # them on purpose, and diagnosing them back at him is noise.
        for terminal in findings.get("stuck_terminals", []):
            if not terminal.get("waiting_reason"):
                continue
            terminal_info = self._inspect_terminal(terminal)
            report["diagnosed"].append(terminal_info)

        # Build human-readable output
        report["summary_text"] = self._format_report(report)
        report["voice_text"] = self._format_voice(report)

        # Surface to Dean
        if report["summary_text"]:
            self._surface(report)

        return report

    # ── CI Diagnosis ────────────────────────────────────────────────────

    def _diagnose_ci_failure(self, build: dict) -> dict:
        """Pull CI logs and diagnose the failure."""
        project = build.get("project", "")
        diagnosis = {"project": project, "type": "ci_failure", "fixable": False,
                     "cause": "unknown", "detail": "", "fix_action": ""}

        # Find the repo
        repo_info = self._get_repo_for_project(project)
        if not repo_info:
            diagnosis["cause"] = "Cannot find repo for project"
            return diagnosis

        owner, repo = repo_info

        # First check if the DEFAULT branch has a recent successful run
        # If so, the "failure" is just a stale branch — not a real problem
        r_success = _run(["gh", "run", "list", "--repo", f"{owner}/{repo}", "--limit", "1",
                           "--status", "success", "--json", "databaseId,headBranch,createdAt"])
        r_fail = _run(["gh", "run", "list", "--repo", f"{owner}/{repo}", "--limit", "1",
                         "--status", "failure", "--json", "databaseId,name,headBranch,createdAt"])

        if r_success["ok"] and r_fail["ok"]:
            try:
                successes = json.loads(r_success["stdout"])
                failures = json.loads(r_fail["stdout"])
                if successes and failures:
                    success_time = successes[0].get("createdAt", "")
                    failure_time = failures[0].get("createdAt", "")
                    if success_time > failure_time:
                        # Most recent run is a success — the failure is stale
                        diagnosis["cause"] = "Stale failure — most recent run is passing"
                        diagnosis["fixable"] = False
                        diagnosis["stale"] = True
                        return diagnosis
            except (json.JSONDecodeError, KeyError, IndexError):
                pass

        # Get the latest failed run
        r = r_fail
        if not r["ok"]:
            diagnosis["cause"] = f"Cannot list runs: {r['stderr']}"
            return diagnosis

        try:
            runs = json.loads(r["stdout"])
            if not runs:
                diagnosis["cause"] = "No failed runs found"
                return diagnosis
            run_id = runs[0]["databaseId"]
            branch = runs[0].get("headBranch", "?")
        except (json.JSONDecodeError, KeyError, IndexError):
            diagnosis["cause"] = "Cannot parse run list"
            return diagnosis

        # Get job details
        r2 = _run(["gh", "run", "view", str(run_id), "--repo", f"{owner}/{repo}"],
                   timeout=15)
        output = r2["stdout"] + "\n" + r2["stderr"]
        diagnosis["detail"] = output[:2000]
        diagnosis["branch"] = branch
        diagnosis["run_id"] = run_id

        # Analyze the failure
        output_lower = output.lower()

        if "unknown or unexpected option" in output_lower and "prisma" in output_lower:
            # Prisma version removed a flag — fix the workflow file
            diagnosis["cause"] = "Prisma CLI flag no longer supported — workflow needs update"
            diagnosis["fixable"] = True
            diagnosis["fix_action"] = "fix_prisma_workflow"
            diagnosis["local_path"] = self._find_path(project)

        elif "prisma db push" in output_lower and "exit code" in output_lower:
            # Check if it's a URL issue or a flag issue
            if "--url" not in output_lower and "prisma.config.ts" in output_lower:
                diagnosis["cause"] = "Prisma 7+ needs --url flag for db push in CI"
                diagnosis["fixable"] = True
                diagnosis["fix_action"] = "fix_prisma_workflow"
                diagnosis["local_path"] = self._find_path(project)
            else:
                diagnosis["cause"] = "Prisma DB push failed — check database connectivity or schema"
                diagnosis["fixable"] = False

        elif "version solving failed" in output_lower and "flutter" in output_lower:
            # Flutter SDK version mismatch — bump in workflow
            diagnosis["cause"] = "Flutter SDK version in CI too old for pubspec constraint"
            diagnosis["fixable"] = True
            diagnosis["fix_action"] = "fix_flutter_version_workflow"
            diagnosis["local_path"] = self._find_path(project)

        elif "flutter pub get" in output_lower and "exit code" in output_lower:
            diagnosis["cause"] = "Flutter pub get failed — dependency resolution issue"
            local_path = self._find_path(project)
            if local_path:
                diagnosis["fixable"] = True
                diagnosis["fix_action"] = "run_flutter_pub_get"
                diagnosis["local_path"] = local_path

        elif "flutter analyze" in output_lower and "exit code" in output_lower:
            diagnosis["cause"] = "Flutter analyze found lint errors"
            local_path = self._find_path(project)
            if local_path:
                diagnosis["fixable"] = True
                diagnosis["fix_action"] = "run_flutter_analyze_fix"
                diagnosis["local_path"] = local_path

        elif "npm test" in output_lower and "exit code" in output_lower:
            diagnosis["cause"] = "npm tests failing"
            diagnosis["fixable"] = False

        elif "git" in output_lower and "exit code 128" in output_lower:
            diagnosis["cause"] = "Git checkout/clone failed — possibly permissions or missing submodule"
            diagnosis["fixable"] = False

        elif "node.js 20" in output_lower and "deprecated" in output_lower:
            diagnosis["cause"] = "Node.js 20 deprecation warning (not the primary failure)"

        else:
            # Generic — extract the X (failed) lines
            failed_steps = [l.strip() for l in output.splitlines() if l.strip().startswith("X ")]
            if failed_steps:
                diagnosis["cause"] = f"Failed steps: {'; '.join(failed_steps[:3])}"

        return diagnosis

    def _attempt_ci_fix(self, diagnosis: dict) -> dict:
        """Attempt to fix a CI issue locally (Tier 2 — with rollback)."""
        action = diagnosis.get("fix_action", "")
        local_path = diagnosis.get("local_path", "")
        project = diagnosis.get("project", "")

        result = {"project": project, "action": action, "fixed": False,
                  "needs_approval": False, "detail": ""}

        if not local_path or not os.path.isdir(local_path):
            result["detail"] = "No local path found"
            return result

        if action == "run_flutter_pub_get":
            r = _run(["flutter", "pub", "get"], cwd=local_path, timeout=60)
            if r["ok"]:
                result["fixed"] = True
                result["detail"] = "flutter pub get succeeded locally"
            else:
                result["detail"] = f"flutter pub get failed: {r['stderr'][:200]}"

        elif action == "run_flutter_analyze_fix":
            # First run analyze to see the issues
            r = _run(["flutter", "analyze", "--no-fatal-infos", "lib/"], cwd=local_path, timeout=60)
            if r["ok"]:
                result["fixed"] = True
                result["detail"] = "flutter analyze now passing locally"
            else:
                # Try dart fix
                r2 = _run(["dart", "fix", "--apply"], cwd=local_path, timeout=60)
                if r2["ok"]:
                    # Re-check
                    r3 = _run(["flutter", "analyze", "--no-fatal-infos", "lib/"], cwd=local_path, timeout=60)
                    if r3["ok"]:
                        result["fixed"] = True
                        result["detail"] = "Applied dart fix + flutter analyze now passing"
                        result["needs_approval"] = True  # Need to push the fix
                        result["approval_action"] = f"Commit and push lint fixes for {project}"
                    else:
                        result["detail"] = f"dart fix applied but analyze still failing: {r3['stdout'][:300]}"
                else:
                    result["detail"] = f"Lint errors found, dart fix couldn't auto-resolve: {r['stdout'][:300]}"

        elif action == "fix_prisma_workflow":
            # Fix Prisma CLI flags in GitHub Actions workflow
            import glob
            workflows = glob.glob(os.path.join(local_path, ".github/workflows/*.yml"))
            fixed_any = False
            for wf in workflows:
                try:
                    with open(wf) as f:
                        content = f.read()
                    original = content
                    # Remove --skip-generate (Prisma 7 dropped it)
                    content = content.replace("--skip-generate", "")
                    # Add --url for Prisma 7+ config-driven mode
                    content = content.replace(
                        'npx prisma db push',
                        'npx prisma db push --url "$DATABASE_URL"'
                    )
                    # Don't double-add --url
                    content = content.replace('--url "$DATABASE_URL" --url "$DATABASE_URL"', '--url "$DATABASE_URL"')
                    if content != original:
                        with open(wf, "w") as f:
                            f.write(content)
                        fixed_any = True
                except Exception:
                    pass
            if fixed_any:
                # Commit and push
                _run(["git", "add", ".github/"], cwd=local_path)
                _run(["git", "commit", "-m",
                      "fix(ci): update Prisma CLI flags for Prisma 7+\n\nAutomated by Leon autopilot"],
                     cwd=local_path)
                branch = _run(["git", "branch", "--show-current"], cwd=local_path).get("stdout", "main")
                _run(["git", "pull", "--rebase", "origin", branch], cwd=local_path, timeout=60)
                push = _run(["git", "push", "origin", branch], cwd=local_path, timeout=60)
                result["fixed"] = True
                result["detail"] = f"Fixed Prisma workflow flags, committed and pushed on {branch}"
            else:
                result["detail"] = "No Prisma workflow changes needed"

        elif action == "fix_flutter_version_workflow":
            # Bump Flutter version in CI workflow to match pubspec constraints
            import glob, re
            workflows = glob.glob(os.path.join(local_path, ".github/workflows/*.yml"))
            # Find what SDK the pubspec needs
            pubspec_sdk = "3.32.2"  # safe default
            for root, dirs, files in os.walk(local_path):
                dirs[:] = [d for d in dirs if d not in ("node_modules", ".git", ".next", "build")]
                if "pubspec.yaml" in files:
                    try:
                        with open(os.path.join(root, "pubspec.yaml")) as f:
                            for line in f:
                                if "sdk:" in line and "flutter" not in line:
                                    # e.g. sdk: ^3.7.2
                                    m = re.search(r'\^?(\d+\.\d+\.\d+)', line)
                                    if m:
                                        needed = m.group(1)
                                        # Map Dart SDK to Flutter version (approximate)
                                        # Dart 3.7.x → Flutter 3.29.x, Dart 3.8.x → Flutter 3.32.x
                                        major, minor, patch = [int(x) for x in needed.split(".")]
                                        if minor >= 8:
                                            pubspec_sdk = "3.32.2"
                                        elif minor >= 7 and patch >= 2:
                                            pubspec_sdk = "3.32.2"  # 3.29.0 has 3.7.0, need 3.7.2+
                    except Exception:
                        pass
                    break

            fixed_any = False
            for wf in workflows:
                try:
                    with open(wf) as f:
                        content = f.read()
                    original = content
                    content = re.sub(
                        r"flutter-version:\s*'[\d.]+'",
                        f"flutter-version: '{pubspec_sdk}'",
                        content
                    )
                    if content != original:
                        with open(wf, "w") as f:
                            f.write(content)
                        fixed_any = True
                except Exception:
                    pass
            if fixed_any:
                _run(["git", "add", ".github/"], cwd=local_path)
                _run(["git", "commit", "-m",
                      f"fix(ci): bump Flutter to {pubspec_sdk} for SDK compatibility\n\nAutomated by Leon autopilot"],
                     cwd=local_path)
                branch = _run(["git", "branch", "--show-current"], cwd=local_path).get("stdout", "main")
                _run(["git", "pull", "--rebase", "origin", branch], cwd=local_path, timeout=60)
                push = _run(["git", "push", "origin", branch], cwd=local_path, timeout=60)
                result["fixed"] = True
                result["detail"] = f"Bumped Flutter to {pubspec_sdk} in CI, committed and pushed"
            else:
                result["detail"] = "No Flutter version changes needed"

        return result

    # ── Credential Instructions ─────────────────────────────────────────

    def _cred_instructions(self, cred_info: dict) -> dict:
        """Generate specific instructions for missing credentials."""
        project = cred_info.get("project", "")
        missing = cred_info.get("missing", [])

        instructions = []
        for cred in missing:
            if cred == "ASC_API_KEY_ID":
                instructions.append("Apple App Store Connect: Create an API key at https://appstoreconnect.apple.com/access/integrations/api → set ASC_API_KEY_ID, ASC_ISSUER_ID, ASC_PRIVATE_KEY")
            elif cred == "CODEMAGIC_API_TOKEN":
                instructions.append("Codemagic: Get API token from https://codemagic.io/teams → Settings → API token")
            elif cred == "REVENUECAT_API_KEY":
                instructions.append("RevenueCat: Get API key from https://app.revenuecat.com → Project Settings → API Keys")
            elif cred == "STRIPE_SECRET_KEY":
                instructions.append("Stripe: Get secret key from https://dashboard.stripe.com/apikeys")
            elif cred == "ANTHROPIC_API_KEY":
                instructions.append("Anthropic: Get API key from https://console.anthropic.com/settings/keys")
            else:
                instructions.append(f"Set env var: {cred}")

        return {
            "project": project, "type": "missing_creds",
            "missing": missing,
            "instructions": instructions,
            "fixable": False,
        }

    # ── Terminal Inspection ─────────────────────────────────────────────

    def _inspect_terminal(self, terminal: dict) -> dict:
        """Check what a stuck terminal is showing."""
        name = terminal.get("name", "")
        idle_min = terminal.get("idle_min", 0)
        result = {"project": name, "type": "idle_terminal", "idle_min": idle_min,
                  "last_output": "", "suggestion": ""}

        # Capture last few lines from the tmux pane
        r = _run(["tmux", "capture-pane", "-t", f"agents:{name}", "-p", "-S", "-10"])
        if r["ok"]:
            result["last_output"] = r["stdout"][-500:]  # last 500 chars
            # Analyze what's on screen
            lower = r["stdout"].lower()
            if "error" in lower or "failed" in lower:
                result["suggestion"] = f"Terminal has errors — may need attention"
            elif "waiting" in lower or "idle" in lower:
                result["suggestion"] = f"Terminal appears to be waiting for input"
            elif "$" in r["stdout"][-50:] or ">" in r["stdout"][-50:]:
                result["suggestion"] = f"Terminal at shell prompt — idle for {idle_min}min"
            else:
                result["suggestion"] = f"Idle {idle_min}min — check if work is stalled"

        return result

    # ── Helpers ──────────────────────────────────────────────────────────

    def _get_repo_for_project(self, project_name: str) -> tuple[str, str] | None:
        """Get (owner, repo) for a project name."""
        if not self.registry:
            return None
        proj = self.registry.get_by_name(project_name)
        if not proj:
            return None
        for url in proj.get("repo_urls", []):
            parts = url.rstrip("/").split("/")
            if len(parts) >= 2:
                owner, repo = parts[-2], parts[-1].replace(".git", "")
                return (owner, repo)
        return None

    def _format_report(self, report: dict) -> str:
        """Format the fixer report for the dashboard."""
        lines = []
        for fix in report["fixed"]:
            lines.append(f"FIXED: {fix['project']} — {fix['detail']}")
        for diag in report["diagnosed"]:
            if diag.get("type") == "ci_failure" and not diag.get("fixable"):
                lines.append(f"DIAGNOSED: {diag['project']} — {diag['cause']}")
            elif diag.get("type") == "idle_terminal":
                lines.append(f"TERMINAL: {diag['project']} — {diag.get('suggestion','idle')}")
        for need in report["needs_approval"]:
            lines.append(f"NEEDS APPROVAL: {need.get('approval_action', need.get('project',''))}")
        for cant in report["cant_fix"]:
            if cant.get("type") == "missing_creds":
                lines.append(f"SETUP NEEDED: {cant['project']} — {', '.join(cant['missing'][:3])}")
                for inst in cant.get("instructions", [])[:2]:
                    lines.append(f"  → {inst}")
        return "\n".join(lines)

    def _format_voice(self, report: dict) -> str:
        """Jarvis-style voice summary of what the fixer did."""
        parts = []
        if report["fixed"]:
            names = [f["project"] for f in report["fixed"]]
            parts.append(f"Fixed {', '.join(names)}")
        if report["diagnosed"]:
            ci_diags = [d for d in report["diagnosed"] if d.get("type") == "ci_failure"]
            if ci_diags:
                for d in ci_diags:
                    parts.append(f"{d['project']}: {d['cause']}")
        if report["needs_approval"]:
            parts.append(f"{len(report['needs_approval'])} fixes ready but need your approval to push")
        if not parts:
            return ""
        return "Sir. " + ". ".join(parts) + "."

    def _surface(self, report: dict):
        """Queue fixer results for Leon's unified consciousness."""
        summary = report.get("summary_text", "")
        voice = report.get("voice_text", "")
        if not summary and not voice:
            return
        if self._consciousness:
            self._consciousness.observe(
                source="fixer",
                summary=voice or summary.split("\n")[0],
                detail=summary,
                urgency="high" if report.get("fixed") else "medium",
            )
            return

        # Legacy fallback — should not happen after consciousness is wired
        # Use unified broadcast gate
        try:
            from server.helpers import broadcast_response
            broadcast_response(summary, source="auto_fixer",
                               user_label="[Leon Auto-Fixer]", audio=False)
        except Exception:
            pass
        if False:  # dead path — replaced by broadcast_response above
            response_id = f"fixer_{int(time.time()*1000)}"
            try:
                self._broadcast({
                    "type": "brain_response_start",
                    "user": "[Leon Auto-Fixer]",
                    "response_id": response_id,
                    "from_voice": False,
                })
                self._broadcast({
                    "type": "brain_response_delta",
                    "response_id": response_id,
                    "text": summary,
                })
                self._broadcast({
                    "type": "brain_response_end",
                    "response_id": response_id,
                    "full_text": summary,
                })
            except Exception as e:
                log.error("Fixer broadcast failed: %s", e)

        from datetime import datetime
        hour = datetime.now().hour
        if voice and self._tts_say and 8 <= hour <= 22:
            try:
                tts_result = self._tts_say(voice)
                if tts_result and self._broadcast:
                    self._broadcast({
                        "type": "brain_audio",
                        "response_id": response_id,
                        "sentence_index": 0,
                        "is_filler": False,
                        **tts_result,
                    })
            except Exception:
                pass
