"""
Credential Awareness — track which credentials exist, which systems are
authenticated, which projects are missing creds, expiration states.

NEVER exposes raw secret values in prompts, logs, or API responses.
Only reports existence, validity, and freshness.
"""
from __future__ import annotations

import logging
import os
import subprocess
import time
from typing import Any

log = logging.getLogger("leon.mission.credentials")

# Known credential keys and their purposes
KNOWN_CREDS = {
    # Apple
    "ASC_API_KEY_ID": {"service": "Apple App Store Connect", "required_for": ["asc"]},
    "ASC_ISSUER_ID": {"service": "Apple App Store Connect", "required_for": ["asc"]},
    "ASC_PRIVATE_KEY": {"service": "Apple App Store Connect", "required_for": ["asc"]},
    # RevenueCat
    "REVENUECAT_API_KEY": {"service": "RevenueCat", "required_for": ["revenuecat"]},
    "REVENUECAT_V2_SECRET": {"service": "RevenueCat v2 API", "required_for": ["revenuecat"]},
    # Codemagic
    "CODEMAGIC_API_TOKEN": {"service": "Codemagic CI/CD", "required_for": ["codemagic"]},
    # GitHub
    "GITHUB_TOKEN": {"service": "GitHub API", "required_for": ["github"]},
    "GH_TOKEN": {"service": "GitHub CLI", "required_for": ["github"]},
    # Cloud
    "AWS_ACCESS_KEY_ID": {"service": "AWS", "required_for": ["aws"]},
    "AWS_SECRET_ACCESS_KEY": {"service": "AWS", "required_for": ["aws"]},
    "GOOGLE_APPLICATION_CREDENTIALS": {"service": "Google Cloud", "required_for": ["gcp"]},
    # Payments
    "STRIPE_SECRET_KEY": {"service": "Stripe", "required_for": ["stripe"]},
    "STRIPE_PUBLISHABLE_KEY": {"service": "Stripe (public)", "required_for": ["stripe"]},
    # Communication
    "DISCORD_BOT_TOKEN": {"service": "Discord", "required_for": ["discord"]},
    "SLACK_BOT_TOKEN": {"service": "Slack", "required_for": ["slack"]},
    "TWILIO_ACCOUNT_SID": {"service": "Twilio", "required_for": ["twilio"]},
    "TWILIO_AUTH_TOKEN": {"service": "Twilio", "required_for": ["twilio"]},
    # AI
    "ANTHROPIC_API_KEY": {"service": "Anthropic API", "required_for": ["anthropic"]},
    "OPENAI_API_KEY": {"service": "OpenAI API", "required_for": ["openai"]},
    "ELEVENLABS_API_KEY": {"service": "ElevenLabs TTS", "required_for": ["elevenlabs"]},
    # Leon-specific
    "LEON_TTS_PREFER": {"service": "Leon TTS preference", "required_for": ["leon_tts"]},
}


class CredentialAwareness:
    def __init__(self):
        self._last_scan: float = 0
        self._scan_cache: dict | None = None
        self._scan_ttl = 300  # 5 minutes
        log.info("CredentialAwareness ready")

    def scan(self, force: bool = False) -> dict:
        """Scan environment for known credentials. Returns presence info, NEVER values."""
        if not force and self._scan_cache and (time.time() - self._last_scan < self._scan_ttl):
            return self._scan_cache

        results = {}
        for key, meta in KNOWN_CREDS.items():
            val = os.environ.get(key, "")
            exists = bool(val)
            results[key] = {
                "service": meta["service"],
                "required_for": meta["required_for"],
                "exists": exists,
                "length": len(val) if exists else 0,
                "looks_valid": self._validate_format(key, val) if exists else False,
            }

        # Check gh CLI auth
        results["gh_cli_auth"] = self._check_gh_auth()
        # Check Google OAuth tokens
        results["google_oauth"] = self._check_google_oauth()

        self._scan_cache = results
        self._last_scan = time.time()
        return results

    def _validate_format(self, key: str, value: str) -> bool:
        """Basic format validation — does NOT test the credential."""
        if not value:
            return False
        if key.endswith("_API_KEY") and len(value) < 10:
            return False
        if key == "ASC_PRIVATE_KEY" and "BEGIN" not in value and not os.path.isfile(value):
            return False
        if "TOKEN" in key and len(value) < 10:
            return False
        return True

    def _check_gh_auth(self) -> dict:
        try:
            r = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True, timeout=10)
            authenticated = r.returncode == 0
            account = ""
            for line in r.stdout.splitlines() + r.stderr.splitlines():
                if "Logged in to" in line:
                    account = line.strip()
                    break
            return {"exists": authenticated, "account": account, "service": "GitHub CLI"}
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return {"exists": False, "account": "", "service": "GitHub CLI"}

    def _check_google_oauth(self) -> dict:
        token_path = os.path.expanduser("~/.openclaw/google-oauth/tokens.json")
        exists = os.path.isfile(token_path)
        stale = False
        if exists:
            age_days = (time.time() - os.path.getmtime(token_path)) / 86400
            stale = age_days > 7
        return {"exists": exists, "path": token_path, "stale": stale, "service": "Google OAuth"}

    def check_project_creds(self, project: dict) -> dict:
        """Check which required creds a project has vs missing."""
        required = project.get("required_creds", [])
        scan = self.scan()
        present = []
        missing = []
        for cred in required:
            info = scan.get(cred, {})
            if info.get("exists"):
                present.append(cred)
            else:
                missing.append(cred)
        return {
            "project": project.get("name", "unknown"),
            "required": required,
            "present": present,
            "missing": missing,
            "all_present": len(missing) == 0,
        }

    def summary(self) -> dict:
        scan = self.scan()
        total = len(scan)
        present = sum(1 for v in scan.values() if isinstance(v, dict) and v.get("exists"))
        services = {}
        for key, info in scan.items():
            if isinstance(info, dict) and "service" in info:
                svc = info["service"]
                if svc not in services:
                    services[svc] = {"authenticated": False, "keys": []}
                services[svc]["keys"].append(key)
                if info.get("exists"):
                    services[svc]["authenticated"] = True
        return {
            "total_known": total,
            "present": present,
            "missing": total - present,
            "services": services,
        }
