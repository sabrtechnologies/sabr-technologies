"""
Leon Mission Control — Phase 15 + Phase 17.

Phase 15: Project Mission Control + External Operational Awareness
Phase 17: Full Autopilot Operations with Guarded Autonomy

Modules:
  - project_registry: persistent project records (projects.db)
  - mission_state: operational checklist engine
  - connectors: external system integrations (GitHub, Codemagic, RevenueCat, ASC, health)
  - credentials: credential-state awareness (never exposes raw secrets)
  - decisions: product/engineering decision tracking
  - ops_loop: operational awareness loop (periodic checks, summaries, next-best-actions)
  - action_tiers: safe action classification (legacy)
  - autonomy: 4-tier guarded autonomy (Phase 17)
  - planner: action planner + evidence engine (Phase 17)
  - autopilot: continuous project operator (Phase 17)
"""

from brain.mission.project_registry import ProjectRegistry
from brain.mission.mission_state import MissionStateEngine
from brain.mission.connectors import ExternalConnectors
from brain.mission.credentials import CredentialAwareness
from brain.mission.decisions import DecisionRegistry
from brain.mission.ops_loop import OpsLoop
from brain.mission.action_tiers import ActionTier, classify_action
# Phase 17
from brain.mission.autonomy import Tier, ActionExecutor, classify as classify_tier, ActionStatus
from brain.mission.planner import ActionPlanner, Evidence
from brain.mission.autopilot import AutopilotScheduler

__all__ = [
    "ProjectRegistry", "MissionStateEngine", "ExternalConnectors",
    "CredentialAwareness", "DecisionRegistry", "OpsLoop",
    "ActionTier", "classify_action",
    # Phase 17
    "Tier", "ActionExecutor", "classify_tier", "ActionStatus",
    "ActionPlanner", "Evidence", "AutopilotScheduler",
]
