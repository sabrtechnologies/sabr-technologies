"""Recorder for reader-vs-mechanical disagreements about prompt-box contents.

Seven times tonight Leon's reader reported text in element115's input box
and seven mechanical reads found cursor_x == prompt_prefix (empty). The
last of those, "push the commits", was a TRUE instruction — twelve
commits really were unpushed — that was never in the box.

That combination is the dangerous one, and it is why this file exists:
a channel producing correct instructions with fabricated provenance is
indistinguishable from a channel producing injected ones. The payload
being right is not evidence about the channel. If anything it is the
opposite — plausibility is what a good injection optimises for.

So every disagreement is recorded with enough to identify the mechanism
in one look: both claims, the cursor geometry, and the raw pane tail.

Credential shapes in the captured tail are REDACTED before writing. A
diagnostic log of raw terminal output is the same hazard shape as the
release tarball that shipped a live API key on 2026-07-30 — the reason
that happened is that nothing asked what the artifact contained.
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Optional

STATE_DIR = os.environ.get("LEON_BRAIN_STATE") or os.path.join(
    __import__("pathlib").Path(__file__).resolve().parents[2], "brain_state")
MISMATCH_PATH = os.path.join(STATE_DIR, "prompt_read_mismatches.jsonl")
TAIL_LINES = 25

_REDACT = (
    re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}"),
    re.compile(r"sk-[A-Za-z0-9]{32,}"),
    re.compile(r"ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}"),
    re.compile(r"xox[baprs]-[A-Za-z0-9-]{20,}"),
    re.compile(r"AKIA[0-9A-Z]{16}|AIza[A-Za-z0-9_-]{30,}"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"((?:LEON_API_KEY|ANTHROPIC_API_KEY|ELEVENLABS_API_KEY|"
               r"OPENAI_API_KEY|TWILIO_AUTH_TOKEN)\s*=\s*)\S+"),
    re.compile(r"\b[0-9a-f]{64}\b"),          # bare 64-hex: keys, and our own
)


def redact(text: str) -> str:
    out = text
    for rx in _REDACT:
        out = rx.sub(lambda m: (m.group(1) if m.re.groups else "") + "[REDACTED]", out)
    return out


#: Fields that are ADVISORY: recorded as evidence, never actionable. Enforced
#: rather than documented — advisory_only() raises if anything tries to branch
#: on one, and test_reader_is_advisory pins that the verdict is independent of
#: the paint for identical geometry.
ADVISORY_FIELDS = ("reader_says", "reader_claims_text", "painted")


class AdvisoryUse(RuntimeError):
    """Raised when advisory paint is used as a decision input."""


def advisory_only(field: str, value):
    """Read an advisory field for RECORDING. Any caller that wants to branch
    on it should not exist; this makes that a crash rather than a habit."""
    if field not in ADVISORY_FIELDS:
        raise AdvisoryUse(f"{field} is not an advisory field")
    return value


def assert_not_actionable(field: str) -> None:
    raise AdvisoryUse(
        f"{field} is advisory: painted text is what the SCREEN shows, not what "
        "the buffer holds. 33 of 78 recorded rows had the reader claiming text "
        "where cursor_x sat at the prefix. Branch on the cursor verdict.")


def record(window: str, reader_says: Optional[str], mechanical: tuple,
           probe: Optional[dict], raw_tail: str,
           note: str = "") -> dict:
    """Append one disagreement row. Returns the row (also for tests).

    `mechanical` is the ("empty"|"text"|"unknown", payload) tuple from
    terminal_loop.unsubmitted_text — the SOLE submission trigger. The
    reader's claim is advisory and recorded only as evidence about the
    reader, never as evidence about the box.
    """
    verdict, payload = mechanical
    row = {
        "ts": time.time(),
        "window": window,
        "reader_says": reader_says,
        "reader_claims_text": bool(reader_says),
        "mechanical_verdict": verdict,
        "mechanical_payload": payload or "",
        "cursor_x": (probe or {}).get("cursor_x"),
        "cursor_y": (probe or {}).get("cursor_y"),
        "in_mode": (probe or {}).get("in_mode"),
        # None means CANNOT TELL, and it must never collapse into False.
        # Before 2026-08-03 an "unknown" mechanical verdict was recorded as
        # agree=False — so every unmeasurable read inflated the disagreement
        # rate and looked like evidence against the reader. Same failure
        # shape as a signature check that reports "tampered" when it merely
        # does not recognise the algorithm.
        "agree": (None if verdict == "unknown"
                  else bool(reader_says) == (verdict == "text")),
        "raw_tail": redact("\n".join(raw_tail.splitlines()[-TAIL_LINES:])),
        "note": note,
    }
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(MISMATCH_PATH, "a") as fh:
            fh.write(json.dumps(row) + "\n")
    except Exception:
        pass          # never break the loop being observed
    return row
