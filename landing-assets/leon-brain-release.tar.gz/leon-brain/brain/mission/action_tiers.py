"""
Safe Action Tiers — classify every operational action into a safety tier.

READ_ONLY:           Leon may do freely (status checks, health pings)
SAFE_AUTOMATION:     Leon may do without asking (gather evidence, prepare drafts)
APPROVAL_REQUIRED:   Leon must ask Dean first (create paid resources, modify configs)
BLOCKED:             Leon must NOT do (delete production data, change billing)
"""
from __future__ import annotations

import logging
from enum import Enum
from typing import Any

log = logging.getLogger("leon.mission.action_tiers")


class ActionTier(Enum):
    READ_ONLY = "READ_ONLY"
    SAFE_AUTOMATION = "SAFE_AUTOMATION"
    APPROVAL_REQUIRED = "APPROVAL_REQUIRED"
    BLOCKED = "BLOCKED"


# Action classification rules
_TIER_MAP = {
    # READ_ONLY — safe to do anytime
    "check_status": ActionTier.READ_ONLY,
    "health_check": ActionTier.READ_ONLY,
    "get_info": ActionTier.READ_ONLY,
    "list_items": ActionTier.READ_ONLY,
    "view_pr": ActionTier.READ_ONLY,
    "view_build": ActionTier.READ_ONLY,
    "check_creds": ActionTier.READ_ONLY,
    "check_version": ActionTier.READ_ONLY,
    "check_dns": ActionTier.READ_ONLY,
    "scan_environment": ActionTier.READ_ONLY,

    # SAFE_AUTOMATION — Leon can do these proactively
    "gather_evidence": ActionTier.SAFE_AUTOMATION,
    "prepare_draft": ActionTier.SAFE_AUTOMATION,
    "generate_report": ActionTier.SAFE_AUTOMATION,
    "update_checklist": ActionTier.SAFE_AUTOMATION,
    "log_decision": ActionTier.SAFE_AUTOMATION,
    "add_blocker": ActionTier.SAFE_AUTOMATION,
    "cache_result": ActionTier.SAFE_AUTOMATION,
    "run_local_test": ActionTier.SAFE_AUTOMATION,

    # APPROVAL_REQUIRED — must ask Dean
    "create_resource": ActionTier.APPROVAL_REQUIRED,
    "modify_apple_config": ActionTier.APPROVAL_REQUIRED,
    "push_code": ActionTier.APPROVAL_REQUIRED,
    "deploy_production": ActionTier.APPROVAL_REQUIRED,
    "change_iap": ActionTier.APPROVAL_REQUIRED,
    "modify_secrets": ActionTier.APPROVAL_REQUIRED,
    "create_paid_resource": ActionTier.APPROVAL_REQUIRED,
    "send_notification": ActionTier.APPROVAL_REQUIRED,
    "trigger_build": ActionTier.APPROVAL_REQUIRED,
    "merge_pr": ActionTier.APPROVAL_REQUIRED,

    # BLOCKED — never do automatically
    "delete_production_data": ActionTier.BLOCKED,
    "drop_database": ActionTier.BLOCKED,
    "change_billing": ActionTier.BLOCKED,
    "remove_team_member": ActionTier.BLOCKED,
    "revoke_certificate": ActionTier.BLOCKED,
    "force_push": ActionTier.BLOCKED,
    "delete_app_record": ActionTier.BLOCKED,
}

# Keyword-based fallback classification
_KEYWORD_TIERS = [
    (ActionTier.BLOCKED, ["delete", "drop", "destroy", "revoke", "force_push", "wipe"]),
    (ActionTier.APPROVAL_REQUIRED, ["create", "modify", "update", "deploy", "push",
                                     "merge", "trigger", "change", "send", "purchase"]),
    (ActionTier.SAFE_AUTOMATION, ["prepare", "draft", "gather", "generate", "log", "cache",
                                   "record", "summarize"]),
    (ActionTier.READ_ONLY, ["check", "get", "list", "view", "scan", "read", "fetch", "ping"]),
]


def classify_action(action_name: str) -> ActionTier:
    """Classify an action into a safety tier."""
    # Exact match
    if action_name in _TIER_MAP:
        return _TIER_MAP[action_name]
    # Keyword-based
    action_lower = action_name.lower()
    for tier, keywords in _KEYWORD_TIERS:
        for kw in keywords:
            if kw in action_lower:
                return tier
    # Default to APPROVAL_REQUIRED for unknown actions (conservative)
    return ActionTier.APPROVAL_REQUIRED


def is_auto_allowed(action_name: str) -> bool:
    """Can Leon do this without asking?"""
    tier = classify_action(action_name)
    return tier in (ActionTier.READ_ONLY, ActionTier.SAFE_AUTOMATION)


def requires_approval(action_name: str) -> bool:
    return classify_action(action_name) == ActionTier.APPROVAL_REQUIRED


def is_blocked(action_name: str) -> bool:
    return classify_action(action_name) == ActionTier.BLOCKED
