"""How text entered the box — and an honest account of what this cannot know.

Leon's question: cursor_x > 2 moves identically for a keystroke, a paste, and
injected bytes, so what separates hand-typed from everything else — timing, or
the tty's own key events?

NEITHER, and both fail for different reasons. This module implements the
timing one anyway, scoped to what it actually delivers.

  TTY KEY EVENTS ARE NOT AVAILABLE HERE. Checked 2026-08-03: /dev/input holds
  5 evdev devices, but they are the VM's virtual console ("AT Translated Set 2
  keyboard", "VirtualPS/2 VMware VMMouse"). The tmux client is on /dev/pts/3
  and every session arrives over SSH — sshd writes bytes to a pty master, and
  a pty carries no key events. `tmux send-keys` writes to the same pty master
  in exactly the same way. At that layer a keystroke and an injection are the
  same bytes, and no flag distinguishes them because none exists.

  TIMING SEPARATES PASTE FROM TYPING, NOT INJECTION FROM TYPING. A human emits
  characters over seconds with jitter; a paste or a single send-keys lands the
  whole string between two samples. That is a real and measurable difference.
  But an adversary — or our own loop — can send one character at a time with
  sleeps and reproduce the human profile exactly. There is no cost to doing
  so and no way to detect it afterwards.

SO THIS IS A CONVENIENCE DISCRIMINATOR, NOT A SECURITY ONE, and it must never
become load-bearing. The standing rule of this thread already covers it:
content can never establish provenance, only a record can. Timing is content.

What it is legitimately good for: deciding whether a submission the loop did
NOT author is worth opening a `sender=unknown` debt for, so a hand-driven
wedge stops being invisible to the watchdog. Getting that wrong costs a
spurious debt or a missed one — not a keystroke.
"""
from __future__ import annotations

import subprocess
import time
from typing import Optional

SESSION_DEFAULT = "agents"

#: A single sample interval that admits more than this many new cells did not
#: come from fingers. A fast human sustains ~8 chars/s; at a 150ms interval
#: that is ~1.2 cells per sample, so 8 is an order of magnitude clear.
BURST_CELLS = 8
INTERVAL_S = 0.15
#: A human filling a box emits characters across at least this many samples.
MIN_INCREMENTS = 3

PASTE, TYPED, EMPTY, UNKNOWN = "paste", "typed", "empty", "unknown"


def _probe(window: str, session: str) -> Optional[tuple]:
    try:
        out = subprocess.run(
            ["tmux", "display-message", "-p", "-t", f"{session}:{window}",
             "#{cursor_x}\t#{pane_in_mode}"],
            capture_output=True, text=True, timeout=5).stdout.strip()
        cx, mode = out.split("\t")
        return (int(cx), mode == "1") if cx.isdigit() else None
    except Exception:
        return None


def track(window: str, seconds: float = 3.0, interval: float = INTERVAL_S,
          session: str = SESSION_DEFAULT) -> list:
    """Sample cursor_x. Returns [(ts, cursor_x)] — raw, unjudged."""
    out, deadline = [], time.time() + seconds
    while time.time() < deadline:
        p = _probe(window, session)
        if p is not None and not p[1]:
            out.append((time.time(), p[0]))
        time.sleep(interval)
    return out


def classify(samples: list, prefix: int = 2) -> tuple:
    """(verdict, reason, max_jump). Pure — the demo and the live path share it."""
    cells = [cx - prefix for _, cx in samples]
    if not cells:
        return UNKNOWN, "no readable samples", 0
    if max(cells) <= 0:
        return EMPTY, "box never held characters", 0
    jumps = [b - a for a, b in zip(cells, cells[1:]) if b > a]
    max_jump = max(jumps) if jumps else max(cells)
    if not jumps:
        # Text was already present when tracking began — we saw its tail, not
        # its arrival. That is not a paste, it is a missed window.
        return UNKNOWN, "text predates the track; arrival not observed", max(cells)
    if max_jump >= BURST_CELLS:
        return PASTE, (f"{max_jump} cells arrived in one {INTERVAL_S}s sample — "
                       "faster than fingers, so a paste or an injection"), max_jump
    if len(jumps) >= MIN_INCREMENTS:
        return TYPED, (f"{len(jumps)} increments, largest {max_jump} cells — "
                       "consistent with typing, and ONLY consistent: slow "
                       "injection is indistinguishable"), max_jump
    return UNKNOWN, f"only {len(jumps)} increments seen — too few to call", max_jump


def may_open_unknown_debt(samples: list, prefix: int = 2) -> tuple:
    """Gate for opening a sender=unknown ledger row. Runs BEHIND may_autosubmit.

    TYPED opens a debt. Everything else refuses — including UNKNOWN, because a
    debt opened on a guess produces a phantom wedge escalation against a pane
    nobody sent to, which is the false positive we spent the night removing.
    """
    verdict, reason, jump = classify(samples, prefix)
    return (verdict == TYPED), verdict, reason
