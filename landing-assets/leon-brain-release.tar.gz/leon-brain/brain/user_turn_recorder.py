"""
Leon V2 user-turn recorder: one idempotent post-turn pipeline for every
Dean-facing reply, whichever provider produced it.

Why this exists
---------------
The code that recorded "Dean spoke" lived only on the direct-Anthropic API
branch of ``BrainAPIResponder.respond_streaming``. Production has answered on
the Claude CLI and then the local model for months, and that branch returns
before the bookkeeping, so it never ran: ``last_interaction_ts`` still equals
birth, ``accumulated_experience`` is 0, the bond never grew and no
conversation ever became a labelled hippocampal memory. This module moves
that bookkeeping to one place that every provider path reaches.

Contract
--------
* A turn is opened only for a genuine Dean turn: ``supervised`` and
  ``persist_history`` and not ``bypass_consciousness``, non-empty text and a
  known ``channel``. Background callers (inner voice, dreams, proactive,
  goal pursuit, mission) never open one; the recorder never keys on
  ``daemon``.
* Each turn has a stable ``turn_id`` (uuid4 hex) minted at admission.
* :func:`finalize` runs **exactly once** per turn (``turn.recorded`` plus a
  bounded process-wide set of finalized ids), whatever the outcome
  (replied / empty / error / aborted), so a fallback or retry can never
  double-record. The responder calls it *before* re-yielding ``done`` (a
  consumer that breaks on ``done`` closes the generator at that yield) and
  again from ``finally`` (Stop, errors), where it is a no-op if already done.
* Brain mutations go through the sim-thread queue
  (``request_inject_current``, ``request_surprise``,
  ``request_hippocampal_memory``); nothing here writes neurons directly.
* Each step has its own try/except and failure counter; one failure never
  skips the others.

Rollout (live flag ``user_turn_recorder`` in /etc/leon/v2_flags.json):
    off     no turn is opened
    shadow  turns are opened and finalized as *plans*: what would be written
            is logged and kept in a ring, nothing is written; legacy stays
    canary  authoritative for the canary's channels / fraction of turn ids
    on      authoritative for every genuine turn

History is never back-filled. The first authoritative turn starts counting
from the value on disk; the known gap is annotated once, forward-dated
(see :func:`annotate_history_gap`).
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
import uuid
from collections import OrderedDict, deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional

log = logging.getLogger("leon.v2.turns")

__all__ = ["UserTurn", "open_turn", "note_presence", "finalize", "stats",
           "recent", "annotate_history_gap", "CHANNELS", "FEATURE",
           "set_current", "current_turn"]

FEATURE = "user_turn_recorder"
#: Channels that are a person talking to Leon. Anything else is not a turn.
CHANNELS = frozenset({"dashboard", "discord", "voice", "wake", "wake_local",
                      "room_mic", "conversation_lane"})
#: Channels with no speaker identification: recorded as unverified.
_VOICE_CHANNELS = frozenset({"voice", "wake", "wake_local", "room_mic"})
#: Channels that are never a person talking to Leon (local tools, probes,
#: benchmarks, tests). A turn on them is not recorded, by design.
NON_PERSON_CHANNELS = frozenset({"loopback_ws", "synthetic"})
#: Channels whose consumer (server/routers/websocket.py) already writes the
#: "I told Dean" autobiography line on ``done``; the recorder writes it only
#: for the others, so no reply is recorded twice.
_WS_CHANNELS = frozenset({"dashboard", "discord", "loopback_ws"})
_FINALIZED_MAX = 1024
_RING = 200
_HIPPO_PATTERN_NEURONS = 50
_HIPPO_CURRENT = 15.0
_CONVERSATION_STRENGTH = 1.2
SIDECAR_DEFAULT = "/var/log/leon/v2/user_turns.jsonl"
SIDECAR_MAX_BYTES = 4 * 1024 * 1024

_lock = threading.Lock()
_finalized: "OrderedDict[str, float]" = OrderedDict()
_ring: Deque[Dict[str, Any]] = deque(maxlen=_RING)
_counters: Dict[str, int] = {}
_step_fail: Dict[str, int] = {}
_warned_no_channel = [0.0]
_tls = threading.local()


def set_current(turn: Optional["UserTurn"]) -> None:
    """The responder wrapper marks the turn being answered on this thread, so
    code deep in the provider path (the context package) can attribute its
    telemetry and canary selection to the same turn id and channel."""
    _tls.turn = turn


def current_turn() -> Optional["UserTurn"]:
    return getattr(_tls, "turn", None)


@dataclass
class UserTurn:
    turn_id: str
    channel: str
    received_ts: float
    opened_wall: float
    text: str = field(repr=False)         # in memory only; never logged or stored here
    text_sha1: str = ""
    chars: int = 0
    mode: str = "shadow"
    authoritative: bool = False
    presence_noted: bool = False
    recorded: bool = False
    outcome: Optional[str] = None
    provider: Optional[str] = None
    model: Optional[str] = None


def _count(name: str, n: int = 1) -> None:
    with _lock:
        _counters[name] = _counters.get(name, 0) + n


def _live_mode() -> str:
    try:
        from brain import v2_live_flags
        return v2_live_flags.live_mode(FEATURE)
    except Exception:
        return "off"


def _is_selected(channel: str, turn_id: str) -> bool:
    try:
        from brain import v2_live_flags
        return v2_live_flags.canary_selects(FEATURE, channel=channel, key=turn_id)
    except Exception:
        return False


def open_turn(user_text: str, *, channel: Optional[str], received_ts: Optional[float] = None,
              supervised: bool = False, persist_history: bool = True,
              bypass_consciousness: bool = False) -> Optional[UserTurn]:
    """A UserTurn for a genuine Dean turn, else None. Never raises."""
    try:
        if not supervised or not persist_history or bypass_consciousness:
            return None
        if not isinstance(user_text, str) or not user_text.strip():
            return None
        if channel not in CHANNELS:
            now = time.monotonic()
            if channel not in NON_PERSON_CHANNELS and now - _warned_no_channel[0] > 300:
                _warned_no_channel[0] = now
                print(f"[TURN-RECORDER] supervised turn without a known channel "
                      f"(channel={channel!r}) subsystem=v2.user_turn_recorder "
                      f"recovery=turn not recorded; legacy path unchanged", flush=True)
            _count("non_person_channel" if channel in NON_PERSON_CHANNELS else "no_channel")
            return None
        mode = _live_mode()
        if mode == "off":
            return None
        tid = uuid.uuid4().hex
        authoritative = mode == "on" or (mode == "canary" and _is_selected(channel, tid))
        _count("opened")
        return UserTurn(
            turn_id=tid, channel=channel,
            received_ts=float(received_ts) if received_ts else time.time(),
            opened_wall=time.time(), text=user_text,
            text_sha1=hashlib.sha1(user_text.encode("utf-8", "replace")).hexdigest()[:12],
            chars=len(user_text), mode=mode, authoritative=authoritative)
    except Exception as exc:
        _count("open_failed")
        log.warning("[TURN-RECORDER] open failed trace_id=- subsystem=v2.user_turn_recorder "
                    "exc=%s recovery=turn not recorded", type(exc).__name__)
        return None


#: Tests (and only tests) point this at a stand-in for the server package.
_SRV_OVERRIDE: Any = None


_TOKEN_SHAPE_RX = None


def _mask_token_shapes(text: str) -> str:
    """Belt and braces after redact_credentials_deep: anything shaped like a
    key or install token (known prefixes, or a 32+ char run of key alphabet)
    is masked before it can reach an append-only record."""
    global _TOKEN_SHAPE_RX
    import re
    if _TOKEN_SHAPE_RX is None:
        _TOKEN_SHAPE_RX = re.compile(
            r"(?:sk-[A-Za-z0-9_\-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|xox[abpr]-[A-Za-z0-9\-]{10,}"
            r"|AKIA[0-9A-Z]{16}|[A-Za-z0-9_\-]{32,})")
    return _TOKEN_SHAPE_RX.sub("[REDACTED-CREDENTIAL]", text)


def _redact(text: str) -> str:
    """Credential guard: the same redaction ConversationStore applies, plus a
    token-shape mask, so no secret reaches the append-only autobiography or
    hippocampal labels."""
    try:
        from brain.security import redact_credentials_deep
        out = redact_credentials_deep(text)
        out = out if isinstance(out, str) else str(out)
    except Exception:
        return "[redaction unavailable: text withheld]"
    return _mask_token_shapes(out)


def _looks_like_auth_failure(text: str) -> bool:
    try:
        from brain.security import looks_like_brain_auth_failure
        return bool(looks_like_brain_auth_failure(text))
    except Exception:
        return False


def _srv():
    if _SRV_OVERRIDE is not None:
        return _SRV_OVERRIDE
    import server as _server   # lazy: server is always loaded when turns happen
    return _server


def note_presence(turn: Optional[UserTurn], srv: Any = None) -> List[str]:
    """Admission-time presence stamps (safe to repeat): drives, daydream, dream.

    They run at admission so the idle timers do not lag the 30-40 s local
    reply. Authoritative turns only; shadow returns what it would do.
    """
    if turn is None or turn.presence_noted:
        return []
    turn.presence_noted = True
    plan = ["drive_system.note_user_input", "daydream_engine.note_user_activity",
            "dream_engine.note_activity"]
    if not turn.authoritative:
        return plan
    try:
        s = srv if srv is not None else _srv()
    except Exception:
        return []
    # The one-time history-gap annotation must capture the counters BEFORE
    # the presence stamps below change drive_system (2026-09-28 lesson).
    try:
        _ensure_gap_annotated(s, turn)
    except Exception as exc:
        _step_failed("history_gap_annotation", turn, exc)
    done = []
    for attr, meth in (("drive_system", "note_user_input"),
                       ("daydream_engine", "note_user_activity"),
                       ("dream_engine", "note_activity")):
        obj = getattr(s, attr, None)
        if obj is None:
            continue
        try:
            getattr(obj, meth)()
            done.append(f"{attr}.{meth}")
        except Exception as exc:
            _step_failed(f"{attr}.{meth}", turn, exc)
    return done


def _step_failed(step: str, turn: UserTurn, exc: BaseException) -> None:
    with _lock:
        _step_fail[step] = _step_fail.get(step, 0) + 1
    log.warning("[TURN-RECORDER] step failed trace_id=%s subsystem=v2.user_turn_recorder.%s "
                "exc=%s recovery=step skipped; other steps continue",
                turn.turn_id, step, type(exc).__name__)


def hippocampal_pattern(text: str, n_neurons: int):
    """Stable sparse firing pattern for ``text`` (hashlib, not the salted hash())."""
    import numpy as np
    pattern = np.zeros(n_neurons, dtype=np.float32)
    h = int.from_bytes(hashlib.sha256(text.encode("utf-8", "replace")).digest()[:8], "big")
    for i in range(min(_HIPPO_PATTERN_NEURONS, n_neurons // 10)):
        pattern[(h + i * 7919) % n_neurons] = _HIPPO_CURRENT
    return pattern


def _plan_for(turn: UserTurn, outcome: str) -> List[str]:
    steps = ["reward.sentiment", "emotion.currents", "concepts", "hippocampus.memory",
             "autobiography.dean_said"]
    if outcome == "replied" and turn.channel not in _WS_CHANNELS:
        steps.append("autobiography.i_told_dean")
    steps += ["stakes", "persistent_state.note_interaction"]
    return steps


def finalize(turn: Optional[UserTurn], reply_text: Optional[str], *, outcome: str,
             provider: Optional[str] = None, model: Optional[str] = None,
             sentiment_fn: Optional[Callable[[str], float]] = None,
             mortality_fn: Optional[Callable[[str], float]] = None,
             reward_callback: Optional[Callable[[float, str], Any]] = None,
             srv: Any = None) -> Optional[Dict[str, Any]]:
    """Record one Dean turn exactly once. Never raises. Returns the record."""
    if turn is None:
        return None
    try:
        with _lock:
            if turn.recorded or turn.turn_id in _finalized:
                _counters["duplicate_finalize_ignored"] = _counters.get("duplicate_finalize_ignored", 0) + 1
                turn.recorded = True
                return None
            turn.recorded = True
            _finalized[turn.turn_id] = time.monotonic()
            while len(_finalized) > _FINALIZED_MAX:
                _finalized.popitem(last=False)
        turn.outcome = outcome
        turn.provider = provider or turn.provider
        turn.model = model or turn.model
        steps = _plan_for(turn, outcome)
        rec: Dict[str, Any] = {
            "kind": "user_turn", "turn_id": turn.turn_id, "channel": turn.channel,
            "mode": turn.mode, "authoritative": turn.authoritative,
            "outcome": outcome, "provider": turn.provider, "model": turn.model,
            "received_ts": round(turn.received_ts, 3), "finalized_ts": round(time.time(), 3),
            "latency_s": round(time.time() - turn.received_ts, 3),
            "text_sha1": turn.text_sha1, "chars": turn.chars,
            "reply_chars": len(reply_text or ""), "steps": {},
        }
        if not turn.authoritative:
            rec["steps"] = {s: "would" for s in steps}
            _count("shadow_finalized")
        else:
            rec["steps"] = _apply(turn, reply_text, outcome, sentiment_fn, mortality_fn,
                                  reward_callback, srv)
            _count("recorded")
        _count(f"outcome.{outcome}")
        with _lock:
            _ring.append(rec)
        _sidecar(rec)
        failed = [k for k, v in rec["steps"].items() if v == "error"]
        print(f"[TURN-RECORDER] {'recorded' if turn.authoritative else 'shadow'} "
              f"turn={turn.turn_id[:12]} channel={turn.channel} outcome={outcome} "
              f"provider={turn.provider} model={turn.model} steps={len(rec['steps'])}"
              f"{' failed=' + ','.join(failed) if failed else ''}", flush=True)
        return rec
    except Exception as exc:
        _count("finalize_failed")
        log.warning("[TURN-RECORDER] finalize failed trace_id=%s subsystem=v2.user_turn_recorder "
                    "exc=%s recovery=turn not recorded; legacy path unaffected",
                    getattr(turn, "turn_id", "-"), type(exc).__name__)
        return None


_gap_done = [False]


def _gap_values(s: Any) -> Dict[str, Any]:
    """The affected counters exactly as they stand before the first recorded turn."""
    ps = getattr(s, "persistent_state", None)
    ds = getattr(s, "drive_system", None)
    st = getattr(getattr(s, "stakes_tracker", None), "_state", None)

    def g(obj, name):
        v = getattr(obj, name, None) if obj is not None else None
        return round(v, 3) if isinstance(v, float) else v
    return {
        "persistent_state.last_interaction_ts": g(ps, "_last_interaction"),
        "persistent_state.birth_ts": g(ps, "_birth_ts"),
        "persistent_state.accumulated_experience": g(ps, "_accumulated_experience"),
        "persistent_state.accumulated_loneliness": g(ps, "_accumulated_loneliness"),
        "persistent_state.accumulated_restlessness": g(ps, "_accumulated_restlessness"),
        "drive_system.last_user_input_ts": g(ds, "_last_user_input_ts"),
        "drive_system.leon_spoke_count": g(ds, "_leon_spoke_count"),
        "stakes.bond_strength": g(st, "bond_strength"),
        "stakes.bond_interactions": g(st, "bond_interactions"),
    }


def _ensure_gap_annotated(s: Any, turn: UserTurn) -> Optional[str]:
    """Once, before the first authoritative recording: forward-dated annotation
    of the historical gap (never back-filled). Idempotent via the sidecar."""
    if _gap_done[0]:
        return None
    auto = getattr(s, "autobiography", None)
    path = getattr(auto, "_path", None)
    if not path:
        return "no_autobiography"
    sidecar = os.path.join(os.path.dirname(path), "v2", "continuity_annotations.jsonl")
    os.makedirs(os.path.dirname(sidecar), exist_ok=True)
    note = annotate_history_gap(auto, values=_gap_values(s), sidecar_path=sidecar)
    _gap_done[0] = True
    if isinstance(note, dict) and not note.get("already_annotated"):
        print(f"[TURN-RECORDER] history gap annotated (forward-dated, no back-fill) "
              f"turn={turn.turn_id[:12]} sidecar={sidecar}", flush=True)
        return "annotated"
    return "already_annotated"


def _apply(turn: UserTurn, reply_text: Optional[str], outcome: str,
           sentiment_fn, mortality_fn, reward_callback, srv) -> Dict[str, str]:
    s = srv if srv is not None else _srv()
    text = turn.text
    brain = getattr(s, "brain", None)
    res: Dict[str, str] = {}
    try:
        gap = _ensure_gap_annotated(s, turn)
        if gap:
            res["history_gap_annotation"] = gap
    except Exception as exc:
        res["history_gap_annotation"] = "error"
        _step_failed("history_gap_annotation", turn, exc)
    details = {"turn_id": turn.turn_id, "channel": turn.channel, "provider": turn.provider,
               "model": turn.model, "outcome": outcome,
               "received_ts": round(turn.received_ts, 3), "recorder": "v2.user_turn_recorder"}
    safe_text = _redact(text)
    if turn.channel in _VOICE_CHANNELS:
        details["speaker_verified"] = False
        speaker = "Dean (voice, speaker not verified)"
    else:
        speaker = "Dean"

    def step(name, fn):
        try:
            r = fn()
            res[name] = "skipped" if r is False else "ok"
        except Exception as exc:
            res[name] = "error"
            _step_failed(name, turn, exc)

    sentiment = 0.0
    try:
        sentiment = float(sentiment_fn(text)) if sentiment_fn else 0.0
    except Exception as exc:
        _step_failed("sentiment", turn, exc)

    def reward():
        if reward_callback is None or sentiment == 0.0:
            return False
        reward_callback(sentiment, f"sentiment:{'pos' if sentiment > 0 else 'neg'}")

    def emotion():
        if brain is None or sentiment == 0.0 or not hasattr(brain, "request_inject_current"):
            return False
        import numpy as np
        intensity = abs(sentiment) * 15.0
        for region, scale in (("amygdala", 1.0), ("prefrontal_cortex", 0.7), ("insula", 0.5)):
            r = brain.regions.get(region)
            if r is not None:
                brain.request_inject_current(region, np.full(r.n_neurons, intensity * scale,
                                                             dtype=np.float32))

    def concepts():
        cm = getattr(s, "concept_map", None)
        if cm is None:
            return False
        prev = set(getattr(cm, "_active_concepts", ()) or ())
        # brain=None: activate() would otherwise write brain sensory input from
        # this request thread (races step()); the SNN side of a conversation
        # memory goes through the queued hippocampal request below.
        activated = cm.activate(safe_text, brain=None)
        cm.observe_text(safe_text)
        if activated:
            print(f"[CONCEPTS] activated: {activated}", flush=True)
            new = set(activated) - prev
            if prev and brain is not None and hasattr(brain, "request_surprise") and (
                    len(new) >= 2 or (len(new) >= 1 and not prev & set(activated))):
                brain.request_surprise(0.3, source=f"topic_change:{','.join(sorted(new))}")

    def hippocampus():
        if brain is None or not hasattr(brain, "request_hippocampal_memory"):
            return False
        hippo = brain.regions.get("hippocampus")
        if hippo is None:
            return False
        brain.request_hippocampal_memory(hippocampal_pattern(text, hippo.n_neurons),
                                         _CONVERSATION_STRENGTH, safe_text[:200])

    auto = getattr(s, "autobiography", None)

    def dean_said():
        if auto is None:
            return False
        auto.record("conversation", f"{speaker} said: '{safe_text[:120]}'", details=dict(details))

    def told_dean():
        if auto is None or not reply_text or _looks_like_auth_failure(reply_text):
            return False
        auto.record("conversation", f"I told Dean: '{_redact(reply_text)[:120]}'",
                    details=dict(details))

    def stakes():
        st = getattr(s, "stakes_tracker", None)
        if st is None:
            return False
        st.note_conversation()
        if sentiment > 0:
            st.note_positive_interaction(sentiment * 0.15)
        elif sentiment < 0 and hasattr(st, "note_negative_interaction"):
            st.note_negative_interaction(-sentiment * 0.1)

    # The legacy substring mortality detector is deliberately NOT run here: on
    # stored turns it fires on "send you" / "offend you" and would write
    # invented 'Felt mortality threat' fear events into the append-only
    # autobiography. Re-enabling it is a decision for Dean (word-boundary
    # matcher aimed at the SI, no 'Felt' wording).

    def interaction():
        ps = getattr(s, "persistent_state", None)
        if ps is None:
            return False
        ps.note_interaction()

    for name, fn in (("reward.sentiment", reward), ("emotion.currents", emotion),
                     ("concepts", concepts), ("hippocampus.memory", hippocampus),
                     ("autobiography.dean_said", dean_said)):
        step(name, fn)
    if outcome == "replied" and turn.channel not in _WS_CHANNELS:
        step("autobiography.i_told_dean", told_dean)
    for name, fn in (("stakes", stakes),
                     ("persistent_state.note_interaction", interaction)):
        step(name, fn)
    return res


_sidecar_state = {"disabled_until": 0.0}


def _sidecar(rec: Dict[str, Any]) -> None:
    path = os.environ.get("LEON_V2_TURN_SIDECAR", SIDECAR_DEFAULT)
    if not path or time.monotonic() < _sidecar_state["disabled_until"]:
        return
    try:
        d = os.path.dirname(path)
        if not os.path.isdir(os.path.dirname(d) or "/"):
            return
        os.makedirs(d, mode=0o750, exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > SIDECAR_MAX_BYTES:
            os.replace(path, path + ".1")
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, separators=(",", ":")) + "\n")
    except Exception as exc:
        _sidecar_state["disabled_until"] = time.monotonic() + 600
        log.warning("[TURN-RECORDER] sidecar write failed exc=%s recovery=paused 10 min",
                    type(exc).__name__)


def stats() -> Dict[str, Any]:
    with _lock:
        return {"feature": FEATURE, "mode": _live_mode(), "counters": dict(_counters),
                "step_failures": dict(_step_fail), "ring": len(_ring)}


def recent(limit: int = 50) -> List[Dict[str, Any]]:
    with _lock:
        items = list(_ring)
    return [dict(r) for r in items[-max(1, min(int(limit), _RING)):]]


def annotate_history_gap(autobiography: Any, *, values: Dict[str, Any],
                         sidecar_path: str) -> Dict[str, Any]:
    """Forward-dated, append-only annotation of the historical recording gap.

    Records the affected fields' values *at the moment the fix went live* and
    points at the authoritative record of past turns. Never back-dates,
    never infers counts, never rewrites any value. Idempotent via the sidecar.
    """
    now = time.time()
    fd_path = sidecar_path
    if os.path.exists(fd_path):
        try:
            with open(sidecar_path, encoding="utf-8") as f:
                for line in f:
                    if '"user_turn_recorder_gap"' in line:
                        return {"already_annotated": True}
        except OSError:
            pass
    note = {
        "kind": "user_turn_recorder_gap", "ts": now, "valid_from": now,
        "cause": ("Verified at the running code (v2/live-preservation-20260927, based on "
                  "fca61f23): Claude-CLI and local turns return before the per-turn "
                  "bookkeeping block, which existed only on the direct-API branch. The "
                  "stored counters show no completed update since this runtime state "
                  "began; code before 2026-06-25 is not in git, so earlier runs cannot "
                  "be ruled out."),
        "notes": {"drive_system.last_user_input_ts":
                  "synthetic: constructor default plus inner_voice decrements (60 s per "
                  "thought mentioning Dean); not evidence of the defect"},
        "fields_at_fix": values,
        "authoritative_history": "brain_state/knowledge.db table conversation_history",
        "policy": "not back-filled; counting starts at the fix; values above are as recorded",
    }
    fd = os.open(fd_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        os.write(fd, (json.dumps(note, separators=(",", ":")) + "\n").encode("utf-8"))
        os.fsync(fd)
    finally:
        os.close(fd)
    if autobiography is not None:
        autobiography.record(
            "annotation",
            "[system annotation] Per-turn conversation bookkeeping (interaction time, "
            "experience count, bond, conversation memories) is active from this "
            "moment. The stored counters show no completed update before it; values "
            "recorded before this point are kept as they were. Past conversations "
            "remain in conversation history.",
            details={"kind": "user_turn_recorder_gap", "fields_at_fix": values})
    return note


def _reset_for_tests() -> None:
    with _lock:
        _finalized.clear()
        _ring.clear()
        _counters.clear()
        _step_fail.clear()
    _gap_done[0] = False
