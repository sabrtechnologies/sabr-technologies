"""
Leon V2 Phase 5 (runbook 9.2): the persistent SceneModel.

What Leon currently believes about his surroundings: who is present, what the
owner is doing on screen, which objects the room holds, and the acoustic
context and light. The model is fed only by SensoryHub observations
(``apply``). It is the single persistent scene representation, so
vision_daemon does not keep a second one.

Persistence
-----------
* ``brain_state/scene_model_v2.json`` (the path is configurable), written
  atomically (temp file in the same directory, fsync, ``os.replace``) by a
  small persister thread. Saves happen at most once per
  :data:`MIN_PERSIST_INTERVAL_S` seconds. A high-salience change (salience >=
  :data:`HIGH_SALIENCE`, such as a confirmed presence flip) may save sooner,
  but never more often than once per :data:`HIGH_SALIENCE_MIN_INTERVAL_S`.
  Last-seen refreshes on a stable scene are saved at most once per
  :data:`TOUCH_PERSIST_INTERVAL_S`.
* A separate change log, ``scene_model_v2.changes.jsonl``, is capped by count
  (:data:`CHANGELOG_MAX_ENTRIES`) and size (:data:`CHANGELOG_MAX_BYTES`). It
  is append-only in memory and trimmed only from the oldest end. An entry is
  never edited once written.
* Persisted timestamps are wall clock (``time.time``). Throttles use
  ``time.monotonic``.
* The model writes these two files and nothing else. It never reads or
  rewrites legacy memories: knowledge store, autobiography, hippocampus,
  ``spatial_memory.json`` and ``temporal_patterns.json`` are untouched.
* An unreadable file is moved aside (``.corrupt-<unix>``), never deleted. A
  file with a newer schema makes the model read-only, so an older build never
  clobbers it.

Evidence rules mirror the legacy extractors (io_routes presence debounce,
perception_floors floors 3/5/7/11), so the two can be compared. The
comparison is kept in ``parity``. That parity record is the evidence for
later retiring perception_floors' private persistence.
"""
from __future__ import annotations

import copy
import json
import logging
import math
import os
import re
import sys
import threading
import time
from collections import deque
from dataclasses import asdict, dataclass
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

log = logging.getLogger("leon.v2.scene")

__all__ = ["SceneEntity", "SceneState", "SceneModel", "default_path", "FILE_NAME",
           "CHANGELOG_SUFFIX", "SCHEMA"]

SCHEMA = 1
FILE_NAME = "scene_model_v2.json"
CHANGELOG_SUFFIX = ".changes.jsonl"
STATE_DIR_NAME = "brain_state"
MIN_PERSIST_INTERVAL_S = 30.0
HIGH_SALIENCE = 0.8
HIGH_SALIENCE_MIN_INTERVAL_S = 2.0
TOUCH_PERSIST_INTERVAL_S = 300.0
CHANGELOG_MAX_ENTRIES = 1000
CHANGELOG_MAX_BYTES = 256 * 1024
MAX_ENTITIES = 256
MAX_FILE_BYTES = 4 * 1024 * 1024
LOCK_TIMEOUT_S = 0.005
PRESENCE_CONFIRM = {"appeared": 2, "left": 3}   # same asymmetry as io_routes
LABEL_CONFIRM = 2
BOOTSTRAP_CAPTIONS = 3
REAPPEAR_AFTER_S = 6 * 3600.0
UNCERTAINTY_HORIZON_S = 900.0
RECENT_OBJECT_S = 600.0
FAIL_LOG_INTERVAL_S = 60.0
FRESHNESS_S = {"screen": 120.0, "webcam": 120.0, "audio": 60.0, "telemetry": 120.0}
MIN_EVIDENCE_CONFIDENCE = 0.25

PRIMARY_PERSON = "person:primary"
ACTIVITY_ID = "activity:current"
DISPLAY_ID = "display:primary"
ROOM_ID = "room:primary"
SYSTEM_AUDIO_ID = "audio:system"
_FIXED_IDS = frozenset({PRIMARY_PERSON, ACTIVITY_ID, DISPLAY_ID, ROOM_ID, SYSTEM_AUDIO_ID})

# Same vocabularies as the legacy extractors, so parity is apples to apples.
_PERSON_RX = re.compile(r"\b(person|man|woman|face|someone|people|guy|figure)\b", re.I)
_ALERT_RX = re.compile(r"\b(error|crash|traceback|exception|failed|warning dialog|alert|"
                       r"blue screen|frozen)\b", re.I)
OBJECT_WORDS = ("bed", "chair", "desk", "door", "lamp", "monitor", "screen", "window",
                "wall", "mug", "phone", "laptop", "cable", "shelf", "plant", "light",
                "device")
ACTIVITY_RULES: Tuple[Tuple[Tuple[str, ...], str, str], ...] = (
    (("terminal", "code", "editor", "vim", "vscode", "ide"), "code editor", "coding"),
    (("browser", "chrome", "firefox", "web"), "web browser", "browsing"),
    (("game", "steam", "gaming"), "game", "gaming"),
    (("video", "youtube", "movie", "stream"), "video player", "watching"),
    (("chat", "discord", "slack", "message"), "chat app", "communicating"),
    (("desktop", "wallpaper", "empty"), "", "idle"),
)
EXPRESSION_RULES: Tuple[Tuple[Tuple[str, ...], str], ...] = (
    (("serious", "focused", "concentrat", "frown"), "focused"),
    (("smil", "laugh", "happy", "grin"), "happy"),
    (("tired", "sleepy", "yawn", "drooping"), "tired"),
    (("stress", "tense", "worried", "anxious"), "stressed"),
    (("relax", "calm", "peaceful"), "relaxed"),
)
LEVEL_CONTEXT = {"silence": "silence", "quiet": "quiet", "active": "active", "loud": "loud"}


def _app_root() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def default_path(state_dir: Optional[str] = None) -> str:
    """``<state_dir>/scene_model_v2.json``. The default state dir is the one
    brain.persistence uses (``<app root>/brain_state``)."""
    return os.path.join(state_dir or os.path.join(_app_root(), STATE_DIR_NAME), FILE_NAME)


# ----------------------------------------------------------------------
# dataclasses (runbook 9.2, field for field)


@dataclass
class SceneEntity:
    entity_id: str
    kind: str
    label: str
    location: dict
    properties: dict
    confidence: float
    first_seen_wall: float
    last_seen_wall: float
    last_changed_wall: float
    source_modalities: list[str]


@dataclass
class SceneState:
    entities: dict[str, SceneEntity]
    active_app: str | None
    room_occupancy: list[str]
    acoustic_context: str
    brightness: float | None
    uncertainty: float


# ----------------------------------------------------------------------
# pure extractors


def classify_activity(caption: str) -> Tuple[str, str]:
    lower = (caption or "").lower()
    for words, app, mode in ACTIVITY_RULES:
        if any(re.search(r"\b" + re.escape(w) + r"\b", lower) for w in words):
            return app, mode
    return "", "idle"


def extract_objects(caption: str) -> List[str]:
    lower = (caption or "").lower()
    return [w for w in OBJECT_WORDS if re.search(r"\b" + w + r"s?\b", lower)]


def classify_expression(caption: str) -> str:
    lower = (caption or "").lower()
    for words, label in EXPRESSION_RULES:
        if any(w in lower for w in words):
            return label
    return ""


def brightness_from_caption(caption: str) -> Optional[float]:
    lower = (caption or "").lower()
    if any(w in lower for w in ("dark", "dim", "dimly")):
        return 0.2
    if any(w in lower for w in ("bright", "sunlight", "well-lit", "daylight")):
        return 0.8
    if "illuminated" in lower or "light" in lower:
        return 0.5
    return None


def _num(x: Any) -> Optional[float]:
    if isinstance(x, bool) or x is None:
        return None
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _jsonable(v: Any) -> Any:
    if v is None or isinstance(v, (bool, int, str)):
        return v
    if isinstance(v, float):
        return round(v, 6) if math.isfinite(v) else None
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in list(v)[:64]]
    if isinstance(v, dict):
        return {str(k)[:64]: _jsonable(x) for k, x in list(v.items())[:64]}
    return str(v)[:120]


def _atomic_write(path: str, data: bytes) -> None:
    d = os.path.dirname(path) or "."
    tmp = os.path.join(d, ".%s.tmp-%d-%d" % (os.path.basename(path), os.getpid(),
                                             threading.get_ident()))
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    try:
        dfd = os.open(d, os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except OSError:
        pass


def _obs_get(obs: Any, name: str, default: Any = None) -> Any:
    if isinstance(obs, dict):
        return obs.get(name, default)
    return getattr(obs, name, default)


# ----------------------------------------------------------------------
# the model


class SceneModel:
    def __init__(self, path: str, *, min_persist_interval_s: float = MIN_PERSIST_INTERVAL_S,
                 high_salience_min_interval_s: float = HIGH_SALIENCE_MIN_INTERVAL_S,
                 touch_persist_interval_s: float = TOUCH_PERSIST_INTERVAL_S,
                 changelog_max_entries: int = CHANGELOG_MAX_ENTRIES,
                 changelog_max_bytes: int = CHANGELOG_MAX_BYTES,
                 max_entities: int = MAX_ENTITIES,
                 wall: Callable[[], float] = time.time,
                 mono: Callable[[], float] = time.monotonic,
                 load: bool = True) -> None:
        self.path = os.path.abspath(path)
        base = self.path[:-5] if self.path.endswith(".json") else self.path
        self.changelog_path = base + CHANGELOG_SUFFIX
        self.min_persist_interval_s = max(MIN_PERSIST_INTERVAL_S, float(min_persist_interval_s))
        self.high_salience_min_interval_s = max(HIGH_SALIENCE_MIN_INTERVAL_S, float(high_salience_min_interval_s))
        self.touch_persist_interval_s = max(MIN_PERSIST_INTERVAL_S, float(touch_persist_interval_s))
        self.changelog_max_entries = max(1, int(changelog_max_entries))
        self.changelog_max_bytes = max(256, int(changelog_max_bytes))
        self.max_entities = max(8, int(max_entities))
        self._wall = wall
        self._mono = mono
        self._lock = threading.RLock()
        self._save_lock = threading.Lock()
        self._state = SceneState(entities={}, active_app=None, room_occupancy=[],
                                 acoustic_context="unknown", brightness=None, uncertainty=1.0)
        self._evidence_wall: Dict[str, float] = {}
        self._applied_mono: Dict[tuple, float] = {}
        self._parity: Dict[str, Dict[str, int]] = {}
        self._pending: Dict[str, Tuple[Any, int]] = {}
        self._log: Deque[Tuple[str, int]] = deque()      # (json line, bytes)
        self._log_bytes = 0
        self._seq = 0
        self._webcam_captions = 0
        self._dirty = False
        self._touch_dirty = False
        self._high_pending = False
        self._last_save_mono: Optional[float] = None
        self._last_save_wall: Optional[float] = None
        self._readonly = False
        self._corrupt = False
        self._load_error: Optional[str] = None
        self._restored = False
        self._counters: Dict[str, int] = {}
        self._fail_last: Dict[str, float] = {}
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        if load:
            self.load()

    # -- plumbing --------------------------------------------------------

    def _count(self, name: str, n: int = 1) -> None:
        self._counters[name] = self._counters.get(name, 0) + n

    def _note_failure(self, where: str, exc: BaseException) -> None:
        self._count("failures." + where)
        now = self._mono()
        last = self._fail_last.get(where)
        if last is not None and now - last < FAIL_LOG_INTERVAL_S:
            return
        self._fail_last[where] = now
        log.warning("[V2] scene model %s failed trace_id=- subsystem=v2.scene exc=%s "
                    "recovery=scene kept in memory; legacy perception unaffected",
                    where, type(exc).__name__)

    # -- load / save -----------------------------------------------------

    def load(self) -> bool:
        """Restore from disk. Never raises. Missing file: empty model."""
        with self._lock:
            try:
                st = os.stat(self.path)
            except FileNotFoundError:
                return False
            except OSError as exc:
                self._load_error = f"stat: {type(exc).__name__}"
                self._corrupt = False
                self._readonly = True    # cannot see it: do not overwrite it blindly
                self._note_failure("load", exc)
                return False
            try:
                if st.st_size > MAX_FILE_BYTES:
                    raise ValueError(f"file is {st.st_size} bytes (limit {MAX_FILE_BYTES})")
                with open(self.path, "r", encoding="utf-8") as fh:
                    doc = json.load(fh)
                if not isinstance(doc, dict):
                    raise ValueError("top level is not an object")
                schema = doc.get("schema")
                if not isinstance(schema, int) or isinstance(schema, bool):
                    raise ValueError("missing schema")
                if schema > SCHEMA:
                    self._readonly = True
                    self._load_error = f"schema {schema} is newer than {SCHEMA}"
                    log.warning("[V2] scene model file has schema %s (this build knows %s) "
                                "trace_id=- subsystem=v2.scene exc=- recovery=read-only; the "
                                "file is left untouched", schema, SCHEMA)
                    return False
                self._restore(doc)
            except (OSError, ValueError, TypeError, KeyError) as exc:
                self._corrupt = True
                self._load_error = f"{type(exc).__name__}: {str(exc)[:120]}"
                log.warning("[V2] scene model file unreadable trace_id=- subsystem=v2.scene "
                            "exc=%s recovery=starting empty; the file is moved aside (never "
                            "deleted) on the first save", type(exc).__name__)
                return False
            self._load_changelog()
            self._restored = True
            self._count("loaded")
            return True

    def _restore(self, doc: Dict[str, Any]) -> None:
        ents: Dict[str, SceneEntity] = {}
        raw = doc.get("entities") or {}
        if not isinstance(raw, dict):
            raise ValueError("entities is not an object")
        for eid, e in list(raw.items())[:self.max_entities]:
            if not isinstance(e, dict):
                continue
            try:
                ent = SceneEntity(
                    entity_id=str(e.get("entity_id") or eid)[:96],
                    kind=str(e.get("kind") or "unknown")[:32],
                    label=str(e.get("label") or "")[:96],
                    location=dict(e.get("location") or {}),
                    properties=dict(e.get("properties") or {}),
                    confidence=float(_num(e.get("confidence")) or 0.0),
                    first_seen_wall=float(_num(e.get("first_seen_wall")) or 0.0),
                    last_seen_wall=float(_num(e.get("last_seen_wall")) or 0.0),
                    last_changed_wall=float(_num(e.get("last_changed_wall")) or 0.0),
                    source_modalities=[str(m)[:16] for m in list(e.get("source_modalities") or [])[:8]])
            except (TypeError, ValueError):
                continue
            ents[ent.entity_id] = ent
        s = doc.get("state") or {}
        if not isinstance(s, dict):
            raise ValueError("state is not an object")
        occ = [str(x)[:96] for x in list(s.get("room_occupancy") or [])[:16] if str(x) in ents]
        app = s.get("active_app")
        self._state = SceneState(
            entities=ents,
            active_app=str(app)[:64] if isinstance(app, str) and app else None,
            room_occupancy=occ,
            acoustic_context=str(s.get("acoustic_context") or "unknown")[:32],
            brightness=_num(s.get("brightness")),
            uncertainty=float(_num(s.get("uncertainty")) if _num(s.get("uncertainty")) is not None else 1.0))
        ev = doc.get("evidence_wall") or {}
        self._evidence_wall = {str(k)[:16]: float(v) for k, v in ev.items()
                               if _num(v) is not None} if isinstance(ev, dict) else {}
        par = doc.get("parity") or {}
        self._parity = {}
        if isinstance(par, dict):
            for k, v in list(par.items())[:32]:
                if isinstance(v, dict):
                    self._parity[str(k)[:32]] = {str(a)[:16]: int(b) for a, b in v.items()
                                                 if isinstance(b, int) and not isinstance(b, bool)}
        seq = doc.get("seq")
        self._seq = seq if isinstance(seq, int) and not isinstance(seq, bool) and seq >= 0 else 0
        cap = doc.get("webcam_captions")
        self._webcam_captions = cap if isinstance(cap, int) and not isinstance(cap, bool) else 0
        self._last_save_wall = _num(doc.get("saved_wall"))
        if self._last_save_wall is not None:
            self._last_save_mono = self._mono() - max(0.0, self._wall() - self._last_save_wall)

    def _load_changelog(self) -> None:
        try:
            with open(self.changelog_path, "r", encoding="utf-8") as fh:
                lines = fh.read(self.changelog_max_bytes * 2).splitlines()
        except FileNotFoundError:
            return
        except OSError as exc:
            self._note_failure("load_changelog", exc)
            return
        for line in lines[-self.changelog_max_entries:]:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except ValueError:
                continue
            if isinstance(entry, dict):
                seq = entry.get("seq")
                if isinstance(seq, int) and seq > self._seq:
                    self._seq = seq
                self._log_append(line)

    def _build_doc(self, wall: float) -> Dict[str, Any]:
        st = self._state
        return {"schema": SCHEMA, "kind": "leon.v2.scene_model", "saved_wall": round(wall, 6),
                "seq": self._seq, "webcam_captions": self._webcam_captions,
                "state": {"active_app": st.active_app, "room_occupancy": list(st.room_occupancy),
                          "acoustic_context": st.acoustic_context, "brightness": st.brightness,
                          "uncertainty": st.uncertainty},
                "entities": {eid: _jsonable(asdict(e)) for eid, e in st.entities.items()},
                "evidence_wall": dict(self._evidence_wall),
                "parity": {k: dict(v) for k, v in self._parity.items()}}

    def save(self) -> bool:
        """Write both files atomically now. Never raises."""
        if self._readonly:
            self._count("save_refused_readonly")
            return False
        with self._save_lock:
            if not self._lock.acquire(timeout=1.0):
                self._count("save_lock_timeout")
                return False
            try:
                wall = self._wall()
                doc = self._build_doc(wall)
                lines = [line for line, _n in self._log]
                flags = (self._dirty, self._touch_dirty, self._high_pending)
                self._dirty = self._touch_dirty = self._high_pending = False
            finally:
                self._lock.release()
            try:
                data = json.dumps(doc, sort_keys=True, allow_nan=False,
                                  separators=(",", ":")).encode("utf-8")
                log_data = ("\n".join(lines) + "\n").encode("utf-8") if lines else b""
                os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
                if self._corrupt and os.path.exists(self.path):
                    aside = "%s.corrupt-%d" % (self.path, int(wall))
                    n = 0
                    while os.path.exists(aside) and n < 100:
                        n += 1
                        aside = "%s.corrupt-%d-%d" % (self.path, int(wall), n)
                    if os.path.exists(aside):
                        raise FileExistsError("no free name to move the unreadable file aside")
                    os.replace(self.path, aside)
                    log.warning("[V2] scene model: unreadable file moved aside to %s "
                                "trace_id=- subsystem=v2.scene exc=- recovery=kept, not "
                                "deleted", aside)
                self._corrupt = False
                _atomic_write(self.path, data)
                _atomic_write(self.changelog_path, log_data)
            except Exception as exc:
                with self._lock:
                    self._dirty = self._dirty or flags[0]
                    self._touch_dirty = self._touch_dirty or flags[1]
                    self._high_pending = self._high_pending or flags[2]
                self._note_failure("save", exc)
                return False
            self._last_save_mono = self._mono()
            self._last_save_wall = wall
            self._count("saves")
            return True

    def maybe_persist(self, now_mono: Optional[float] = None) -> bool:
        """Save if due (see module docstring). Never raises."""
        if self._readonly:
            return False
        now = self._mono() if now_mono is None else now_mono
        last = self._last_save_mono
        if self._dirty:
            if last is None or now - last >= self.min_persist_interval_s:
                return self.save()
            if self._high_pending and now - last >= self.high_salience_min_interval_s:
                self._count("saves_high_salience")
                return self.save()
            return False
        if self._touch_dirty and (last is None or now - last >= self.touch_persist_interval_s):
            return self.save()
        return False

    def start_persister(self, interval_s: float = 5.0) -> bool:
        if self._thread is not None and self._thread.is_alive():
            return False
        self._stop.clear()
        t = threading.Thread(target=self._persist_loop, args=(max(0.01, float(interval_s)),),
                             name="scene-model-persist", daemon=True)
        self._thread = t
        t.start()
        return True

    def stop_persister(self, flush: bool = True, join_timeout: float = 2.0) -> bool:
        self._stop.set()
        t = self._thread
        if t is not None and t is not threading.current_thread():
            t.join(timeout=join_timeout)
        if t is not None and t.is_alive():
            # Keep the handle: do not start a second persister or block behind
            # a still-running writer while attempting a shutdown flush.
            self._count("stop_timeout")
            return False
        self._thread = None
        if flush and (self._dirty or self._touch_dirty):
            return self.save()
        return True

    def _persist_loop(self, interval_s: float) -> None:
        while not self._stop.wait(interval_s):
            try:
                self.maybe_persist()
            except Exception as exc:   # pragma: no cover - maybe_persist does not raise
                self._note_failure("persist_loop", exc)

    # -- change bookkeeping ---------------------------------------------

    def _log_append(self, line: str) -> None:
        n = len(line.encode("utf-8")) + 1
        self._log.append((line, n))
        self._log_bytes += n
        while self._log and (len(self._log) > self.changelog_max_entries
                             or self._log_bytes > self.changelog_max_bytes):
            _old, m = self._log.popleft()
            self._log_bytes -= m

    def _change(self, entity_id: str, fld: str, old: Any, new: Any, salience: float,
                obs: Any, now: float) -> Dict[str, Any]:
        self._seq += 1
        entry = {"seq": self._seq, "wall": round(now, 6), "entity_id": entity_id,
                 "field": fld, "old": _jsonable(old), "new": _jsonable(new),
                 "salience": round(float(salience), 3),
                 "observation_id": str(_obs_get(obs, "observation_id", "") or "")[:64],
                 "modality": str(_obs_get(obs, "modality", "") or "")[:16]}
        self._log_append(json.dumps(entry, sort_keys=True, allow_nan=False,
                                    separators=(",", ":")))
        self._dirty = True
        if salience >= HIGH_SALIENCE:
            self._high_pending = True
        return dict(entry)

    def _upsert(self, entity_id: str, kind: str, label: str, now: float, modality: str,
                confidence: float, touch: bool = True) -> Tuple[SceneEntity, bool]:
        ents = self._state.entities
        ent = ents.get(entity_id)
        if ent is None:
            ent = SceneEntity(entity_id=entity_id, kind=kind, label=label, location={},
                              properties={}, confidence=round(confidence, 4),
                              first_seen_wall=now, last_seen_wall=now if touch else 0.0,
                              last_changed_wall=now, source_modalities=[modality])
            ents[entity_id] = ent
            self._evict(now)
            return ent, True
        if modality and modality not in ent.source_modalities:
            ent.source_modalities = (ent.source_modalities + [modality])[-8:]
        if touch:
            ent.last_seen_wall = now
            # Repetition is not independent validation of the source's claim.
            ent.confidence = round(min(1.0, 0.7 * ent.confidence + 0.3 * confidence), 4)
            self._touch_dirty = True
        return ent, False

    def _evict(self, now: float) -> None:
        ents = self._state.entities
        if len(ents) <= self.max_entities:
            return
        victims = sorted((e for e in ents.values() if e.entity_id not in _FIXED_IDS),
                         key=lambda e: e.last_seen_wall)
        for e in victims[:len(ents) - self.max_entities]:
            del ents[e.entity_id]
            self._count("evicted")

    def _confirm(self, key: str, current: Any, value: Any, need: int) -> bool:
        """Hysteresis: True when ``value`` (!= current) has now been seen
        ``need`` times in a row. Agreement with ``current`` resets it."""
        if value == current:
            self._pending.pop(key, None)
            return False
        pend = self._pending.get(key)
        count = pend[1] + 1 if pend is not None and pend[0] == value else 1
        if count >= need:
            self._pending.pop(key, None)
            return True
        self._pending[key] = (value, count)
        return False

    def _bump_parity(self, name: str, outcome: str) -> None:
        d = self._parity.setdefault(name, {})
        d[outcome] = d.get(outcome, 0) + 1
        self._touch_dirty = True

    def _refresh_uncertainty(self, now: float) -> float:
        ages = [max(0.0, now - w) for k, w in self._evidence_wall.items() if w and k != "floors"]
        # Fresh audio must not make old visual evidence appear current.
        u = 1.0 if not ages else min(1.0, 0.05 + max(ages) / UNCERTAINTY_HORIZON_S)
        self._state.uncertainty = round(u, 4)
        return self._state.uncertainty

    # -- apply -----------------------------------------------------------

    def apply(self, obs: Any) -> List[Dict[str, Any]]:
        """Fold one observation into the scene. Returns the changes it caused
        (each a dict with entity_id, field, old, new, salience). Never raises;
        never blocks longer than LOCK_TIMEOUT_S; never touches the disk."""
        if not self._lock.acquire(timeout=LOCK_TIMEOUT_S):
            self._count("apply_lock_timeout")
            return []
        try:
            modality = str(_obs_get(obs, "modality", "") or "")
            feats = _obs_get(obs, "features", None) or {}
            kind = str(feats.get("kind") or "") if isinstance(feats, dict) else ""
            summary = str(_obs_get(obs, "summary", "") or "")
            conf = _num(_obs_get(obs, "confidence", None))
            conf = 0.5 if conf is None else min(1.0, max(0.0, conf))
            now = _num(_obs_get(obs, "created_wall", None)) or self._wall()
            if not isinstance(feats, dict):
                feats = {}
            observed = _num(feats.get("source_ts"))
            if observed is not None:
                if now - observed > FRESHNESS_S.get(modality, 120.0) or observed > now + 5:
                    self._count("stale_observation")
                    return []
                now = min(now, observed)
            if conf < MIN_EVIDENCE_CONFIDENCE:
                self._count("low_confidence")
                return []
            key = (modality, kind, str(_obs_get(obs, "source", ""))[:48])
            observed_mono = _num(_obs_get(obs, "created_mono", None))
            if observed_mono is not None:
                previous = self._applied_mono.get(key)
                if previous is not None and observed_mono < previous:
                    self._count("out_of_order")
                    return []
                self._applied_mono[key] = observed_mono
                if len(self._applied_mono) > 256:
                    self._applied_mono = {key: observed_mono}
            if modality == "webcam" and kind == "caption":
                changes = self._apply_webcam_caption(obs, summary, conf, now)
            elif modality == "screen" and kind == "caption":
                changes = self._apply_screen_caption(obs, summary, feats, conf, now)
            elif modality == "audio" and kind in ("scene", "level", "transcript"):
                changes = self._apply_audio(obs, kind, summary, feats, conf, now)
            elif modality == "telemetry" and kind == "floors":
                self._apply_floors_parity(feats, now)
                changes = []
            else:
                changes = []
                self._count("ignored." + (kind or "none")[:16])
            self._refresh_uncertainty(now)
            self._count("applied")
            return changes
        except Exception as exc:
            self._note_failure("apply", exc)
            return []
        finally:
            self._lock.release()

    def _apply_webcam_caption(self, obs, summary, conf, now):
        changes: List[Dict[str, Any]] = []
        self._webcam_captions += 1
        self._evidence_wall["webcam"] = now
        seen = bool(_PERSON_RX.search(summary)) and not re.search(
            r"\b(no|without)\s+(a\s+|any\s+)?(person|people|man|woman|face|one)\b|\bnobody\b",
            summary, re.I)
        # presence (debounced exactly like io_routes._presence_transition)
        person, created = self._upsert(PRIMARY_PERSON, "person", "unidentified person", now,
                                       "webcam", conf, touch=seen)
        props = person.properties
        cur = props.get("present")
        if cur is None:
            props["present"] = seen
            person.last_changed_wall = now
            changes.append(self._change(PRIMARY_PERSON, "present", None, seen, 0.3, obs, now))
        else:
            need = PRESENCE_CONFIRM["appeared" if seen else "left"]
            if self._confirm("presence", cur, seen, need):
                props["present"] = seen
                person.last_changed_wall = now
                changes.append(self._change(PRIMARY_PERSON, "present", cur, seen, 0.9, obs, now))
        if seen:
            props["last_present_wall"] = round(now, 6)
        self._state.room_occupancy = [PRIMARY_PERSON] if props.get("present") else []
        # expression (floor 3), only while someone is there
        expr = classify_expression(summary) if props.get("present") else ""
        if expr:
            cur_e = props.get("expression") or ""
            if self._confirm("expression", cur_e, expr, LABEL_CONFIRM):
                props["expression"] = expr
                person.last_changed_wall = now
                sal = 0.5 if expr in ("stressed", "tired") else 0.3
                changes.append(self._change(PRIMARY_PERSON, "expression", cur_e or None,
                                            expr, sal, obs, now))
        # objects (floor 7): appear once, then only last_seen moves
        bootstrapped = self._webcam_captions > BOOTSTRAP_CAPTIONS or self._restored
        for word in extract_objects(summary):
            eid = "object:" + word
            prev = self._state.entities.get(eid)
            gap = now - prev.last_seen_wall if prev is not None and prev.last_seen_wall else 0.0
            ent, made = self._upsert(eid, "object", word, now, "webcam", conf, touch=True)
            if made:
                ent.location = {"view": "webcam"}
                changes.append(self._change(eid, "appeared", None, word,
                                            0.5 if bootstrapped else 0.2, obs, now))
            elif gap > REAPPEAR_AFTER_S:
                ent.last_changed_wall = now
                changes.append(self._change(eid, "reappeared", round(gap, 1), word, 0.2, obs, now))
        # light (floor 5), debounced
        b = brightness_from_caption(summary)
        if b is not None:
            cur_b = self._state.brightness
            if cur_b is None:
                self._state.brightness = b
                changes.append(self._change(ROOM_ID, "brightness", None, b, 0.1, obs, now))
            elif self._confirm("brightness", cur_b, b, LABEL_CONFIRM):
                self._state.brightness = b
                sal = 0.5 if abs(b - cur_b) >= 0.3 else 0.2
                changes.append(self._change(ROOM_ID, "brightness", cur_b, b, sal, obs, now))
        return changes

    def _apply_screen_caption(self, obs, summary, feats, conf, now):
        changes: List[Dict[str, Any]] = []
        self._evidence_wall["screen"] = now
        app, mode = classify_activity(summary)
        act, made = self._upsert(ACTIVITY_ID, "activity", mode, now, "screen", conf)
        if made:
            act.properties["app"] = app
            changes.append(self._change(ACTIVITY_ID, "mode", None, mode, 0.2, obs, now))
        elif self._confirm("activity", act.label, mode, LABEL_CONFIRM):
            old = act.label
            act.label = mode
            act.properties["app"] = app
            act.last_changed_wall = now
            changes.append(self._change(ACTIVITY_ID, "mode", old, mode, 0.5, obs, now))
        elif mode == act.label and act.properties.get("app") != app:
            old_app = act.properties.get("app")
            act.properties["app"] = app
            changes.append(self._change(ACTIVITY_ID, "app", old_app, app, 0.2, obs, now))
        self._state.active_app = act.properties.get("app") or None
        disp, dmade = self._upsert(DISPLAY_ID, "display", "screen", now, "screen", conf)
        mon = feats.get("monitor")
        if isinstance(mon, int) and not isinstance(mon, bool) and disp.location.get("monitor") != mon:
            old_m = disp.location.get("monitor")
            disp.location = {"monitor": mon}
            if not dmade:
                changes.append(self._change(DISPLAY_ID, "monitor", old_m, mon, 0.1, obs, now))
        alert = bool(_ALERT_RX.search(summary))
        cur_a = disp.properties.get("alert")
        if cur_a is None:
            disp.properties["alert"] = alert
            if alert:
                changes.append(self._change(DISPLAY_ID, "alert", None, True, 0.8, obs, now))
        elif alert and not cur_a:
            self._pending.pop("alert", None)
            disp.properties["alert"] = True
            disp.last_changed_wall = now
            changes.append(self._change(DISPLAY_ID, "alert", False, True, 0.8, obs, now))
        elif not alert and cur_a and self._confirm("alert", True, False, LABEL_CONFIRM):
            disp.properties["alert"] = False
            disp.last_changed_wall = now
            changes.append(self._change(DISPLAY_ID, "alert", True, False, 0.3, obs, now))
        elif alert == cur_a:
            self._pending.pop("alert", None)
        return changes

    def _apply_audio(self, obs, kind, summary, feats, conf, now):
        changes: List[Dict[str, Any]] = []
        self._evidence_wall["audio"] = now
        source = str(_obs_get(obs, "source", "") or "")
        if kind == "scene" and source.endswith(".system"):
            label = str(feats.get("scene") or summary or "unknown")[:32]
            ent, made = self._upsert(SYSTEM_AUDIO_ID, "sound_source", label, now, "audio", conf)
            call = bool(feats.get("call_detected"))
            if made:
                ent.properties["call_detected"] = call
            else:
                if self._confirm("system_audio", ent.label, label, LABEL_CONFIRM):
                    old = ent.label
                    ent.label = label
                    ent.last_changed_wall = now
                    changes.append(self._change(SYSTEM_AUDIO_ID, "label", old, label, 0.2, obs, now))
                if bool(ent.properties.get("call_detected")) != call:
                    old_c = bool(ent.properties.get("call_detected"))
                    ent.properties["call_detected"] = call
                    ent.last_changed_wall = now
                    changes.append(self._change(SYSTEM_AUDIO_ID, "call_detected", old_c, call,
                                                0.5, obs, now))
            return changes
        room, _made = self._upsert(ROOM_ID, "place", "room", now, "audio", conf)
        if kind == "transcript":
            ctx = "speech"
            room.properties["last_speech_wall"] = round(now, 6)
            room.properties["speech_segments"] = int(room.properties.get("speech_segments") or 0) + 1
            if feats.get("addressed"):
                room.properties["addressed_segments"] = int(
                    room.properties.get("addressed_segments") or 0) + 1
            immediate = True
        elif kind == "level":
            ctx = LEVEL_CONTEXT.get(str(feats.get("level") or ""), "")
            immediate = False
        else:
            ctx = str(feats.get("scene") or summary or "")[:32]
            immediate = False
            if feats.get("startle"):
                room.properties["last_startle_wall"] = round(now, 6)
                changes.append(self._change(ROOM_ID, "startle", None, True, 0.6, obs, now))
        if ctx:
            cur = self._state.acoustic_context
            if cur != ctx and (immediate or cur == "unknown"
                               or self._confirm("acoustic", cur, ctx, LABEL_CONFIRM)):
                self._pending.pop("acoustic", None)
                self._state.acoustic_context = ctx
                room.last_changed_wall = now
                changes.append(self._change(ROOM_ID, "acoustic_context", cur, ctx, 0.3, obs, now))
            elif cur == ctx:
                self._pending.pop("acoustic", None)
        return changes

    def _apply_floors_parity(self, f: Dict[str, Any], now: float) -> None:
        """Compare perception_floors' private conclusions with this model.
        Nothing here changes the scene. When the floors have no vision input
        wired (the VPS), their visual fields are counted as 'blind'."""
        self._evidence_wall["floors"] = now
        ents = self._state.entities
        vision = bool(f.get("vision_wired"))
        person = ents.get(PRIMARY_PERSON)
        scene_present = person.properties.get("present") if person is not None else None
        fp = f.get("owner_present")
        if isinstance(fp, bool) and scene_present is not None:
            self._bump_parity("presence", "blind" if not vision else
                              ("agree" if fp == scene_present else "disagree"))
        act = ents.get(ACTIVITY_ID)
        fm = f.get("activity_mode")
        if isinstance(fm, str) and fm and act is not None:
            self._bump_parity("activity", "blind" if not vision else
                              ("agree" if fm == act.label else "disagree"))
        fo = {str(o) for o in (f.get("room_objects") or []) if isinstance(o, str)}
        so = {e.label for e in ents.values() if e.kind == "object"
              and now - e.last_seen_wall <= RECENT_OBJECT_S}
        if fo or so:
            jac = len(fo & so) / max(1, len(fo | so))
            self._bump_parity("objects", "blind" if not vision else
                              ("agree" if jac >= 0.5 else "disagree"))
        fb = _num(f.get("ambient_brightness"))
        if fb is not None and self._state.brightness is not None:
            self._bump_parity("brightness", "blind" if not vision else
                              ("agree" if abs(fb - self._state.brightness) < 0.15 else "disagree"))

    # -- read side ------------------------------------------------------

    def state(self) -> SceneState:
        """A deep copy; mutating it does not touch the model."""
        with self._lock:
            self._refresh_uncertainty(self._wall())
            result = copy.deepcopy(self._state)
            now = self._wall()
            for entity in result.entities.values():
                age = max(0.0, now - entity.last_seen_wall)
                horizon = min((FRESHNESS_S.get(m, 120.0) for m in entity.source_modalities), default=120.0)
                entity.properties["evidence_age_s"] = round(age, 3)
                entity.properties["stale"] = age > horizon
                if age > horizon:
                    entity.confidence *= max(0.0, 1.0 - (age - horizon) / UNCERTAINTY_HORIZON_S)
            result.room_occupancy = [eid for eid in result.room_occupancy
                                     if eid in result.entities and not result.entities[eid].properties["stale"]]
            if self._evidence_wall.get("screen", 0) + FRESHNESS_S["screen"] < now:
                result.active_app = None
            if self._evidence_wall.get("audio", 0) + FRESHNESS_S["audio"] < now:
                result.acoustic_context = "unknown"
            return result

    def status_metadata(self) -> Dict[str, Any]:
        """Bounded, content-free shadow projection. Never waits for a writer.

        Empty/stale occupancy is unknown evidence, not proof of an empty room.
        This reports model evidence freshness, not sensor or world truth.
        """
        unavailable = {"available": False, "reason": "busy"}
        if not self._lock.acquire(blocking=False):
            return unavailable
        try:
            if len(self._state.entities) > MAX_ENTITIES:
                return {"available": False, "reason": "entity_bound"}
            now = self._wall()
            stale_count = 0
            observed_people = set()
            for eid, entity in self._state.entities.items():
                age = now - entity.last_seen_wall
                horizon = min((FRESHNESS_S.get(m, 120.0) for m in entity.source_modalities), default=120.0)
                stale = not entity.last_seen_wall or age < 0 or age > horizon
                stale_count += int(stale)
                if not stale and entity.kind == "person" and isinstance(entity.properties.get("present"), bool):
                    observed_people.add(eid)
            ages = {kind: round(now - self._evidence_wall[kind], 3)
                    if 0 < self._evidence_wall.get(kind, 0) <= now else None
                    for kind in ("screen", "webcam", "audio")}
            return {"available": True, "entity_count": len(self._state.entities),
                    "stale_entity_count": stale_count,
                    "occupancy_evidence": "observed" if observed_people else "unknown",
                    "room_occupancy_count": sum(eid in observed_people for eid in self._state.room_occupancy)
                        if observed_people else None,
                    "screen_evidence_age_s": ages["screen"],
                    "webcam_evidence_age_s": ages["webcam"],
                    "audio_evidence_age_s": ages["audio"],
                    "uncertainty": self._refresh_uncertainty(now)}
        finally:
            self._lock.release()

    def change_log(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        with self._lock:
            lines = [line for line, _n in self._log]
        if limit is not None:
            count = max(0, int(limit))
            lines = lines[-count:] if count else []
        return [json.loads(line) for line in lines]

    def parity(self) -> Dict[str, Dict[str, int]]:
        with self._lock:
            return {k: dict(v) for k, v in self._parity.items()}

    def stats(self) -> Dict[str, Any]:
        return {"path": self.path, "entities": len(self._state.entities),
                "changelog_entries": len(self._log), "changelog_bytes": self._log_bytes,
                "dirty": self._dirty, "touch_dirty": self._touch_dirty,
                "readonly": self._readonly, "load_error": self._load_error,
                "restored": self._restored, "last_save_wall": self._last_save_wall,
                "counters": dict(self._counters)}

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            self._refresh_uncertainty(self._wall())
            doc = self._build_doc(self._wall())
            fresh = self.state()
            doc["fresh_state"] = _jsonable(asdict(fresh))
        doc.pop("schema", None)
        doc.pop("kind", None)
        doc["stats"] = self.stats()
        return doc
