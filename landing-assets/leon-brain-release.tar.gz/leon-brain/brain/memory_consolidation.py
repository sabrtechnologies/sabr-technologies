"""
Memory Consolidation — the promotion engine that makes Leon genuinely remember.

Models how the human hippocampus replays and promotes important memories during
sleep (and periodically while awake). Without this, conversation-distilled facts
decay and vanish within a week.

THREE tiers:
  conversation_distill → raw, decays (7-day halflife), searchable only
  dean_stated          → durable from birth (distiller tags importance>=4 + speaker=dean)
  consolidated         → promoted by this daemon, durable, injected in prompt

Promotion signals (weighted):
  1. Importance score from distiller (metadata.importance, 1-5)
  2. Access frequency (access_count — how often Leon searched for it)
  3. Emotional salience at encoding (high norepinephrine = correction/surprise)
  4. Repetition (similar facts appearing multiple times)
  5. Source = dean_stated (Dean said it directly)

Runs:
  - Every 30 minutes while awake (lightweight pass)
  - During sleep consolidation (full pass with dedup)
"""

from __future__ import annotations

import json
import logging
import math
import os
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger(__name__)


_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DB = os.path.join(_ROOT, "brain_state", "knowledge.db")

# Promotion threshold — facts scoring above this get promoted
_PROMOTE_THRESHOLD = 0.60

# Max consolidated facts to inject into prompt (prevent bloat)
MAX_CONSOLIDATED_IN_PROMPT = 30

# How often the background loop runs (seconds)
_INTERVAL_AWAKE = 30 * 60   # 30 min while awake
_INTERVAL_SLEEP = 10 * 60   # 10 min during sleep (more active consolidation)


def _score_for_promotion(row: dict) -> float:
    """Score a knowledge row for promotion to consolidated tier.
    Returns 0.0-1.0 where higher = more deserving of promotion.

    This is the "importance function" — it answers Dean's question
    "how do you decide what's important?" with 5 signals, weighted
    like a real brain would weight them."""

    score = 0.0

    # Signal 1: Distiller importance score (0-0.30)
    # The distiller already scored this 1-5 based on whether Dean
    # said it, whether it's a correction, etc.
    try:
        meta = json.loads(row.get("metadata") or "{}")
    except Exception:
        meta = {}
    importance = meta.get("importance", 2)
    score += min(importance / 5.0, 1.0) * 0.30

    # Signal 2: Access frequency (0-0.25)
    # If Leon keeps searching for this fact, it matters.
    access_count = row.get("access_count") or 0
    # Saturating curve: 1 access = 0.08, 3 = 0.19, 5 = 0.25
    score += min(1.0, 1.0 - math.exp(-access_count / 4.0)) * 0.25

    # Signal 3: Emotional salience at encoding (0-0.20)
    # High norepinephrine = surprise/correction = IMPORTANT
    # High dopamine = reward/excitement = IMPORTANT
    ne = row.get("emo_norepinephrine") or -1
    da = row.get("emo_dopamine") or -1
    if ne >= 0 and da >= 0:
        # NE > 0.6 = surprise/correction signal
        # DA > 0.7 = reward signal
        emo_signal = max(
            min(ne / 0.8, 1.0) if ne > 0.4 else 0.0,
            min(da / 0.9, 1.0) if da > 0.5 else 0.0,
        )
        score += emo_signal * 0.20

    # Signal 4: Source = dean_stated (0-0.15)
    # Dean said it directly — that's inherently important
    source = row.get("source") or ""
    if source == "dean_stated":
        score += 0.15
    elif source == "user":
        score += 0.10

    # Signal 5: Strength (survival signal) (0-0.10)
    # If it's already been reinforced by LTP, it matters
    strength = row.get("strength") or 1.0
    if strength > 1.5:
        score += min((strength - 1.0) / 4.0, 1.0) * 0.10

    return min(score, 1.0)


def _find_promotion_candidates(db_path: str = _DB,
                                limit: int = 50) -> List[dict]:
    """Find knowledge rows that deserve promotion to consolidated.
    Only looks at conversation_distill and dean_stated sources
    that haven't already been promoted."""
    conn = sqlite3.connect(db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT * FROM knowledge "
        "WHERE source IN ('conversation_distill', 'dean_stated') "
        "ORDER BY timestamp DESC "
        "LIMIT ?",
        (limit * 3,),  # fetch more than needed, score and filter
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# Dean's standing order 2026-08-11: lead generation is dead. Memories about
# leads / cold outreach kept getting auto-promoted into the prompt, which is
# how the dead topic kept resurrecting itself and making him repeat himself.
# Nothing matching these ever earns a permanent slot again.
_BANNED_PROMOTION_TERMS = (
    "lead gen", "leads", "lead list", "cold email", "cold outreach",
    "outreach", "prospect", "no website",
)


def _is_banned_memory(text: str) -> bool:
    low = (text or "").lower()
    return any(term in low for term in _BANNED_PROMOTION_TERMS)


_STOPWORDS = {
    "the","a","an","is","are","was","were","not","no","and","or","in","on",
    "of","to","it","that","this","for","with","at","as","be","been","has",
    "have","had","does","do","did","from","by","its","they","them",
}


def _subject_key(text: str) -> frozenset:
    """Content words of a claim, for same-subject matching."""
    import re
    words = [w.strip("._-") for w in re.findall(r"[a-z0-9][a-z0-9._-]*", (text or "").lower())]
    # Trailing punctuation used to survive ("technologies." != "technologies")
    # and short numbers were dropped ("17" of "17%"), so a reworded claim
    # never matched the fact that already carried it (2026-09-02).
    return frozenset(w for w in words if w and w not in _STOPWORDS and (len(w) > 2 or w.isdigit()))


def _find_same_subject_siblings(row_id: int, text: str, conn) -> List[dict]:
    """Rows making a claim about the same subject as `text`.

    A collaborator's round-22 finding: that store held two outside-verified rows
    directly contradicting each other on a trivially checkable property.
    The wrong one had been promoted into core facts and was read back to
    her every turn; the right one sat at ordinary priority, unsurfaced.
    Nothing in the store could detect it, because promotion recorded
    nothing about what it beat.

    Detecting arbitrary contradiction is hard. Detecting that a promoted
    fact has a same-subject sibling is not, and it is the one that would
    have caught this. We record; we do not adjudicate.
    """
    key = _subject_key(text)
    if len(key) < 2:
        return []
    out = []
    for rid, txt in conn.execute(
        "SELECT id, text FROM knowledge WHERE id != ?", (row_id,)
    ):
        other = _subject_key(txt)
        if not other:
            continue
        overlap = key & other
        # Same subject = strong content-word overlap with the smaller claim.
        if len(overlap) >= 2 and len(overlap) / min(len(key), len(other)) >= 0.5:
            out.append({"id": rid, "text": txt})
    return out


def _ensure_promotion_columns(conn) -> None:
    """Add the supersede-audit columns if this DB predates them."""
    cols = {r[1] for r in conn.execute("PRAGMA table_info(knowledge)")}
    if "promoted_at" not in cols:
        conn.execute("ALTER TABLE knowledge ADD COLUMN promoted_at REAL")
    if "superseded_ids" not in cols:
        conn.execute("ALTER TABLE knowledge ADD COLUMN superseded_ids TEXT")


def _promote_rows(row_ids: List[int], db_path: str = _DB) -> int:
    """Promote rows to consolidated source. Updates source and boosts strength."""
    if not row_ids:
        return 0
    # Filter out anything on the banned-topic list BEFORE it becomes permanent.
    conn = sqlite3.connect(db_path, timeout=30)
    ph0 = ",".join("?" * len(row_ids))
    texts = conn.execute(
        f"SELECT id, text FROM knowledge WHERE id IN ({ph0})", row_ids
    ).fetchall()
    conn.close()
    banned = {rid for rid, txt in texts if _is_banned_memory(txt)}
    row_ids = [r for r in row_ids if r not in banned]
    if not row_ids:
        return 0
    conn = sqlite3.connect(db_path, timeout=30)
    _ensure_promotion_columns(conn)

    # Record what each promotion beat BEFORE it becomes permanent, so a
    # later contradiction is findable instead of silent.
    import json as _json, time as _time
    now = _time.time()
    for rid, txt in conn.execute(
        f"SELECT id, text FROM knowledge WHERE id IN ({','.join('?' * len(row_ids))})",
        row_ids,
    ).fetchall():
        sibs = _find_same_subject_siblings(rid, txt, conn)
        conn.execute(
            "UPDATE knowledge SET source = 'consolidated', "
            "  strength = MAX(strength, 3.0), promoted_at = ?, superseded_ids = ? "
            "WHERE id = ?",
            (now, _json.dumps([x["id"] for x in sibs]) if sibs else None, rid),
        )
        if sibs:
            log.warning(
                "PROMOTION CONFLICT: row %d promoted to permanent memory while "
                "%d same-subject sibling(s) remain at ordinary priority: %s",
                rid, len(sibs), [x["id"] for x in sibs],
            )
    conn.commit()
    n = conn.total_changes
    conn.close()
    return n


def _deduplicate_consolidated(db_path: str = _DB) -> int:
    """Remove duplicate consolidated facts (same text, keep highest strength)."""
    conn = sqlite3.connect(db_path, timeout=30)
    # Find duplicates by normalized text
    rows = conn.execute(
        "SELECT id, LOWER(TRIM(text)) as norm_text, strength "
        "FROM knowledge "
        "WHERE source IN ('consolidated', 'dean_stated') "
        "ORDER BY norm_text, strength DESC"
    ).fetchall()
    conn.close()

    # Group by normalized text, keep the strongest
    seen = {}
    to_delete = []
    for row_id, norm_text, strength in rows:
        if norm_text in seen:
            to_delete.append(row_id)
        else:
            seen[norm_text] = row_id

    if to_delete:
        conn = sqlite3.connect(db_path, timeout=30)
        ph = ",".join("?" * len(to_delete))
        conn.execute(f"DELETE FROM knowledge WHERE id IN ({ph})", to_delete)
        conn.commit()
        conn.close()
    return len(to_delete)


# ── Promotion to PERMANENT memory (the collaborator-equity gap, 2026-08-26 / fixed 2026-09-02) ──
# "consolidated" rows are durable in knowledge.db and ride in the prompt, but
# only the top MAX_CONSOLIDATED_IN_PROMPT of them, ordered by strength. A fact
# Dean stated ONCE about a person's role, equity or access (e.g. a collaborator: 17% owner,
# Mac signing keymod) could therefore be true, stored, and still absent from
# what Leon knows — it never reached brain/owner_facts.py, the permanent tier.
# This step lifts durable, Dean-stated facts about people and ownership into
# the core facts. ORIGINAL install only: on a client there is no owner_facts.py
# and creating one would make origin.is_original() lie.
_DURABLE_RX = None
_CORE_PROMOTE_CAP = 3


def _durable_rx():
    global _DURABLE_RX
    if _DURABLE_RX is None:
        import re
        _DURABLE_RX = re.compile(
            r"\b(?:is|are|was|became|as)\s+(?:a |an |the |my |our |his |her |their )?"
            r"(?:ceo|cto|coo|cpo|president|co-?founder|founder|owner|investor|partner|client|"
            r"employee|engineer|developer|contractor|mom|mother|dad|father|brother|sister|friend|"
            r"wife|husband|girlfriend|boyfriend|stepson|stepdaughter|son|daughter)\b"
            r"|\b\d{1,3}\s?(?:%|percent)\b|\bequity\b|\bown(?:s|ed)\b|\b(?:has|given|gets?)\s+(?:access|the keys?|a key|the .{0,20}keymod)\b"
            r"|\b(?:email|phone number|address|hostname|username)\s+(?:is|=)|\bis (?:named|called)\b",
            re.I,
        )
    return _DURABLE_RX


def _core_fact_texts() -> List[str]:
    try:
        import importlib
        import brain.owner_facts as _of
        importlib.reload(_of)
        return [t for t, _ in getattr(_of, "OWNER_FACTS", [])]
    except Exception:
        return []


def _already_core(text: str, core_texts: List[str]) -> bool:
    """True when permanent memory already carries this claim.

    Two tests: one core fact restating it (>= 80% of its content words), or
    the core facts as a whole already knowing its content (>= 70% of its
    words appear somewhere in them, 60%). The second catches rewordings — "Dean
    owns a Tesla named Phantom" is already inside the long TESLA fact, and an
    address is already inside TESLA PLACES — without a fact-by-fact match.
    """
    key = _subject_key(text)
    if not key:
        return True
    union = set()
    for t in core_texts:
        k2 = _subject_key(t)
        if not k2:
            continue
        union |= k2
        if len(key & k2) / float(len(key)) >= 0.8:
            return True
    return bool(union) and len(key & union) / float(len(key)) >= 0.6


def _core_promotion_candidates(db_path: str = _DB, limit: int = 200) -> List[dict]:
    conn = sqlite3.connect(db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM knowledge WHERE source IN ('dean_stated', 'consolidated') "
        "ORDER BY timestamp DESC LIMIT ?", (limit,)).fetchall()]
    conn.close()
    out = []
    for row in rows:
        try:
            meta = json.loads(row.get("metadata") or "{}")
        except Exception:
            meta = {}
        if meta.get("core_promoted"):
            continue
        text = (row.get("text") or "").strip()
        if not (30 <= len(text) <= 400) or _is_banned_memory(text):
            continue
        importance = meta.get("importance", 4 if row.get("source") == "dean_stated" else 2)
        if importance < 4 or (row.get("source") != "dean_stated" and importance < 5):
            continue
        if not _durable_rx().search(text):
            continue
        out.append(row)
    return out


def promote_to_core_facts(db_path: str = _DB, dry_run: bool = False) -> Dict[str, Any]:
    """Lift durable Dean-stated facts into brain/owner_facts.py (permanent).

    Returns {"candidates": [...texts], "promoted": n, "skipped_client": bool}.
    """
    try:
        from brain.origin import is_original
    except Exception:
        return {"candidates": [], "promoted": 0, "skipped_client": True}
    if not is_original():
        return {"candidates": [], "promoted": 0, "skipped_client": True}
    core_texts = _core_fact_texts()
    picked = []
    for row in _core_promotion_candidates(db_path):
        if _already_core(row["text"], core_texts):
            continue
        picked.append(row)
        if len(picked) >= _CORE_PROMOTE_CAP:
            break
    report = {"candidates": [r["text"][:120] for r in picked], "promoted": 0, "skipped_client": False}
    if dry_run or not picked:
        return report
    from brain.tools import fact_tool as ft
    facts = ft._read_owner_facts()
    stamp = time.strftime("%Y-%m-%d")
    for row in picked:
        facts.append((f"{row['text'].strip()} [auto-promoted from conversation {stamp}]",
                      f"auto-promoted,dean_stated,{stamp}"))
    if not ft._write_owner_facts(facts):
        return report
    conn = sqlite3.connect(db_path, timeout=30)
    for row in picked:
        try:
            meta = json.loads(row.get("metadata") or "{}")
        except Exception:
            meta = {}
        meta["core_promoted"] = stamp
        conn.execute("UPDATE knowledge SET metadata=? WHERE id=?", (json.dumps(meta), row["id"]))
    conn.commit(); conn.close()
    ft._reseed()
    report["promoted"] = len(picked)
    print(f"[CONSOLIDATION] promoted {len(picked)} durable fact(s) to CORE memory")
    for r in picked:
        print(f"  + {r['text'][:100]}")
    return report


def run_consolidation_pass(db_path: str = _DB) -> Dict[str, Any]:
    """Run one consolidation pass. Score candidates, promote qualifying ones,
    deduplicate. Returns a report dict."""
    t0 = time.time()

    candidates = _find_promotion_candidates(db_path)
    scored = []
    for row in candidates:
        s = _score_for_promotion(row)
        if s >= _PROMOTE_THRESHOLD:
            scored.append((row["id"], s, row["text"][:80]))

    promoted = 0
    if scored:
        ids_to_promote = [row_id for row_id, _, _ in scored]
        promoted = _promote_rows(ids_to_promote, db_path)

    deduped = _deduplicate_consolidated(db_path)
    try:
        core = promote_to_core_facts(db_path)
    except Exception as e:  # never let permanent-tier promotion break the pass
        log.warning("core promotion failed: %s", e)
        core = {"candidates": [], "promoted": 0}

    report = {
        "candidates_checked": len(candidates),
        "promoted": promoted,
        "deduplicated": deduped,
        "promoted_to_core": core.get("promoted", 0),
        "duration_ms": round((time.time() - t0) * 1000),
        "promoted_facts": [(text, round(score, 3)) for _, score, text in scored[:10]],
    }
    if promoted > 0:
        print(f"[CONSOLIDATION] promoted {promoted} facts, deduped {deduped}")
        for text, score in report["promoted_facts"][:5]:
            print(f"  [{score}] {text}")
    return report


def get_consolidated_facts(db_path: str = _DB,
                           limit: int = MAX_CONSOLIDATED_IN_PROMPT) -> List[str]:
    """Get all consolidated facts for prompt injection.
    Returns the text of each consolidated fact, ordered by strength then recency."""
    conn = sqlite3.connect(db_path, timeout=30)
    rows = conn.execute(
        "SELECT text FROM knowledge "
        "WHERE source IN ('consolidated', 'dean_stated') "
        "ORDER BY strength DESC, timestamp DESC "
        "LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [r[0] for r in rows]


# ── Background daemon ────────────────────────────────────────────────

class MemoryConsolidationDaemon:
    """Background thread that periodically runs consolidation passes."""

    def __init__(self, db_path: str = _DB):
        self.db_path = db_path
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._is_sleeping = False

    def set_sleeping(self, sleeping: bool) -> None:
        """Tell the daemon Leon is sleeping — run more aggressively."""
        self._is_sleeping = sleeping

    def _loop(self) -> None:
        # Wait 2 min after startup before first pass
        if self._stop.wait(120):
            return
        while not self._stop.is_set():
            try:
                run_consolidation_pass(self.db_path)
            except Exception as e:
                print(f"[CONSOLIDATION] pass failed: {e}")
            interval = _INTERVAL_SLEEP if self._is_sleeping else _INTERVAL_AWAKE
            if self._stop.wait(interval):
                return

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="MemoryConsolidation", daemon=True
        )
        self._thread.start()
        print(f"[CONSOLIDATION] daemon started (awake={_INTERVAL_AWAKE}s, "
              f"sleep={_INTERVAL_SLEEP}s, threshold={_PROMOTE_THRESHOLD})")

    def stop(self) -> None:
        self._stop.set()
