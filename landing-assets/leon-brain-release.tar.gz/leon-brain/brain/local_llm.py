"""
Local LLM responder — Ollama-backed chat for short/simple turns.

Why this exists:
    Claude via CLI is 1.6-3s warm because of network + auth + per-sentence TTS
    glue. For "yeah", "ok thanks", "how are you", "what color is the sky",
    that's overkill. A small local model (Llama 3.2 1B / Phi-3.5 mini) on
    Dean's RTX 3070 answers the same questions in 0.3-0.7s. We route trivial
    turns here; complex ones fall through to Claude.

Wire:
    if _should_use_local(user_text, brain_state):
        yield from LocalLLM().ask(user_text, brain_state)
    else:
        yield from claude_session.ask(...)

Setup (Dean runs once):
    curl -fsSL https://ollama.com/install.sh | sh
    ollama pull llama3.2:1b    # 1.3 GB, sub-second on a 3070
    ollama pull phi3.5:3.8b    # 2.2 GB, smarter, 0.7-1.2s on a 3070

Falls back to "unavailable" gracefully if Ollama isn't running.
"""
from __future__ import annotations

import functools
import http.client
import json
import os
import re
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Iterator, List, Optional
from brain.timefmt import fmt as _timefmt

# Match the StreamEvent shape the responder + WS expect.
try:
    from brain.claude_api_responder import StreamEvent
except Exception:
    StreamEvent = None  # type: ignore


# ── Leon V2 Phase 3: cancellable local HTTP + content-free slot tickets ─────
# A cancel token (brain.inference_cancel.CancelToken) passed to stream() /
# stream_with_tools() shuts the request's socket down when it is cancelled, so
# a generation blocked mid-read (prompt evaluation sends no byte for tens of
# seconds) ends at once and Ollama frees its single slot. Without a token the
# transport is exactly urllib.request.urlopen, as before. Slot tickets report
# each HTTP generation (label, timing, outcome, Ollama's load/eval counters;
# never text) to the inference scheduler's shadow ledger when it is installed.
_URLOPEN_AT_IMPORT = urllib.request.urlopen


def _v2_slot_begin(label: str):
    try:
        m = sys.modules.get("brain.cognition.inference_scheduler")
        return m.slot_begin(label) if m is not None else None
    except Exception:
        return None


def _v2_slot_end(sid, outcome: str, stats: Optional[dict] = None) -> None:
    if sid is None:
        return
    try:
        m = sys.modules.get("brain.cognition.inference_scheduler")
        if m is not None:
            m.slot_end(sid, outcome, stats)
    except Exception:
        pass


def _v2_done_stats(d) -> dict:
    """Ollama's final counters (numbers only)."""
    out = {}
    if not isinstance(d, dict):
        return out
    for k_in, k_out in (("load_duration", "load_s"), ("prompt_eval_duration", "prompt_eval_s"),
                        ("eval_duration", "eval_s"), ("total_duration", "total_s")):
        v = d.get(k_in)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out[k_out] = round(v / 1e9, 3)
    for k in ("prompt_eval_count", "eval_count"):
        v = d.get(k)
        if isinstance(v, int) and not isinstance(v, bool):
            out[k] = v
    return out


# Keep private compatibility names while sharing one cancellable transport.
from brain.inference_http import (
    shutdown as _v2_shutdown, SocketHolder as _V2SocketHolder,
    TrackedHTTPConnection as _V2TrackedHTTPConnection,
    TrackedHTTPHandler as _V2TrackedHandler, open_cancellable as _shared_open,
)


def _v2_open(req, timeout: float, cancel_token=None):
    if cancel_token is None or urllib.request.urlopen is not _URLOPEN_AT_IMPORT:
        return urllib.request.urlopen(req, timeout=timeout), None
    return _shared_open(req, timeout, cancel_token)


OLLAMA_URL = os.environ.get("LEON_OLLAMA_URL", "http://127.0.0.1:11434")
# Default must be a model that is actually pulled on this box. llama3.2:1b was
# never installed here, so the old default silently 404'd whenever .env didn't
# override it.
_DEFAULT_LOCAL_MODEL = "qwen2.5:3b-instruct-q4_K_M"


def local_model() -> str:
    """The configured local model, read from the environment AT CALL TIME.

    Aug 30 leftover, landed 2026-09-02: this used to be a module constant
    captured at import. The installer writes LEON_LOCAL_MODEL into .env and
    anything that imported this module before .env was loaded (or before the
    owner edited it) kept the stale default forever — the customer's SI then
    asked ollama for a model it never pulled. Nothing may cache this except
    the probe below, which pins to what the endpoint actually serves.
    """
    return (os.environ.get("LEON_LOCAL_MODEL") or "").strip() or _DEFAULT_LOCAL_MODEL


# Import-time snapshot kept ONLY for anything still reading the old name.
LOCAL_MODEL = local_model()

# The ollama daemon actually running on THIS machine. Distinct from OLLAMA_URL,
# which Dean may point at the FreeLLM router (127.0.0.1:3001) for better quality
# — that router is not local, needs internet, and rate-limits (HTTP 429 observed
# 2026-08-14 during a real survival test). This is the rung underneath it that
# cannot 429 and cannot go offline while the box is up.
TRUE_LOCAL_URL = os.environ.get("LEON_TRUE_LOCAL_URL", "http://127.0.0.1:11434")
LOCAL_KEEP_ALIVE = os.environ.get("LEON_LOCAL_KEEP_ALIVE", "24h")
_TRUE_LOCAL_MODEL_CACHE: Optional[str] = None


def _true_local_model() -> Optional[str]:
    """A model name that is ACTUALLY pulled on the local ollama daemon.

    Never trust the configured name here: LEON_LOCAL_MODEL is currently
    "auto" (a router concept, not an ollama tag) and an unpulled tag 404s.
    Ask the daemon what it has and prefer the biggest instruct model.
    """
    global _TRUE_LOCAL_MODEL_CACHE
    if _TRUE_LOCAL_MODEL_CACHE:
        return _TRUE_LOCAL_MODEL_CACHE
    try:
        req = urllib.request.Request(f"{TRUE_LOCAL_URL}/api/tags")
        with urllib.request.urlopen(req, timeout=3) as r:
            models = json.load(r).get("models") or []
        names = [m.get("name", "") for m in models if m.get("name")]
        if not names:
            return None
        # qwen3.6:35b-a3b first: a 35B MoE with only ~3.6B active params per
        # token, so it decodes at small-model CPU speed while thinking at
        # 30B-class quality — the 2026-09-12 upgrade away from "local mode
        # sounds dumb". The older small models stay as fallbacks in case the
        # big one is ever removed to reclaim disk.
        for pref in (local_model(), "qwen3.6:35b-a3b",
                     "qwen2.5:7b-instruct-q4_K_M",
                     "qwen2.5:3b-instruct-q4_K_M", "llama3.2:3b"):
            if pref in names:
                _TRUE_LOCAL_MODEL_CACHE = pref
                return pref
        _TRUE_LOCAL_MODEL_CACHE = names[0]
        return names[0]
    except Exception:
        return None


def _endpoint_chain() -> List[tuple]:
    """[(url, model)] to try in order — best quality first, most reliable last."""
    chain: List[tuple] = [(OLLAMA_URL, _effective_model())]
    if OLLAMA_URL.rstrip("/") != TRUE_LOCAL_URL.rstrip("/"):
        m = _true_local_model()
        if m:
            chain.append((TRUE_LOCAL_URL, m))
    else:
        # OLLAMA_URL IS the local daemon (no router in front). A
        # router-only name like "auto" 404s on real ollama, and there is
        # no second rung to fall through to — ask the daemon what it
        # actually serves instead.
        m = _true_local_model()
        if m and chain[0][1] != m:
            chain[0] = (OLLAMA_URL, m)
    return chain


def _consume(req, timeout: float, t0: float, cancel_token=None):
    """Yield ('chunk'|'thinking'|'done_reason'|'timeout', value) from an
    ollama-style NDJSON stream. Raises on transport failure so the caller can
    fall through to the next endpoint.

    cancel_token (Leon V2 Phase 3): checked per line; cancelling it also shuts
    the socket down, so the stream ends even mid-read. Ends silently."""
    _sid = _v2_slot_begin("chat_stream")
    _outcome, _stats, _unhook = "error", {}, None
    try:
        resp, _unhook = _v2_open(req, timeout, cancel_token)
        with resp:
            for raw in resp:
                if cancel_token is not None and cancel_token.is_set():
                    _outcome = "cancelled"
                    return
                if time.time() - t0 > timeout:
                    _outcome = "timeout"
                    yield ("timeout", None)
                    return
                line = raw.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg = d.get("message", {}) or {}
                # Reasoning models stream their scratchpad here. It is NOT the
                # reply and must never be spoken — but seeing it tells us the
                # model was working rather than refusing.
                if msg.get("thinking"):
                    yield ("thinking", True)
                if d.get("done_reason"):
                    yield ("done_reason", d.get("done_reason"))
                chunk = msg.get("content", "") or ""
                if chunk:
                    yield ("chunk", chunk)
                if d.get("done"):
                    _outcome, _stats = "done", _v2_done_stats(d)
                    return
            _outcome = ("cancelled" if cancel_token is not None and cancel_token.is_set()
                        else "eof")
    except GeneratorExit:
        _outcome = "closed"
        raise
    except Exception:
        _outcome = ("cancelled" if cancel_token is not None and cancel_token.is_set()
                    else "transport_error")
        raise
    finally:
        if _unhook is not None:
            try:
                _unhook()
            except Exception:
                pass
        _v2_slot_end(_sid, _outcome, _stats)

# THREE MODES (LEON_LOCAL_LLM_MODE), because the old boolean kill switch conflated
# two different questions and cost Dean a full day of silence:
#   off      — local model fully disabled. is_available() always False. Nothing
#              can fall back to it. THIS WAS THE BUG: when Claude usage ran out,
#              there was no fallback and Leon went mute for over a day.
#   fallback — DEFAULT. Local model is available for emergency fallback (Claude
#              down / out of credits) and for delegated grunt work, but it NEVER
#              takes over a live conversation with Dean. Dean gets Claude, always.
#   chat     — local model may also answer short chitchat turns directly.
#   only     — local model is the ONLY brain on this machine. Every gate below
#              ("too long", "sounds like a tool request", "sounds complex") is
#              a decision to ESCALATE TO CLAUDE — which presumes a Claude to
#              escalate to. On a customer install with no cloud key and no
#              `claude` CLI, that escalation lands on a subprocess that does
#              not exist, and the owner gets the canned "Voice module offline."
#              This is exactly what happened to a customer's SI on
#              2026-08-12: local brain armed, install reported "ready", and
#              every single typed message died. In "only" mode the gates are
#              skipped wholesale — a small model answering imperfectly beats
#              an SI that cannot answer at all.
#
# Legacy LEON_DISABLE_LOCAL_LLM=1 still forces "off" so nothing breaks silently,
# but it is deprecated — set LEON_LOCAL_LLM_MODE instead.
_LEGACY_DISABLE = os.environ.get(
    "LEON_DISABLE_LOCAL_LLM", ""
).strip().lower() in ("1", "true", "yes", "on")

LOCAL_LLM_MODE = os.environ.get("LEON_LOCAL_LLM_MODE", "").strip().lower()
if LOCAL_LLM_MODE not in ("off", "fallback", "chat", "only"):
    LOCAL_LLM_MODE = "off" if _LEGACY_DISABLE else "fallback"

# Sole-brain detection, belt AND braces. The installer writes mode="only" when
# it provisions the local model as the sole brain — but that only covers
# installs made from this build forward. An SI already on someone's machine
# (a customer's) has "fallback" burned into its .env and would stay mute through an
# update. So decide it here too, from what is actually true at runtime: no
# Anthropic key AND no `claude` binary on PATH means there is nothing to
# escalate to, no matter what the .env says.
LOCAL_LLM_SOLE_BRAIN = LOCAL_LLM_MODE == "only"
if LOCAL_LLM_MODE in ("fallback", "chat"):
    try:
        import shutil as _sh
        if not (os.environ.get("ANTHROPIC_API_KEY") or "").strip() \
                and _sh.which("claude") is None:
            LOCAL_LLM_SOLE_BRAIN = True
            LOCAL_LLM_MODE = "only"
    except Exception:
        pass

# Kept for backwards compatibility with existing callers that read this name.
LOCAL_LLM_DISABLED = LOCAL_LLM_MODE == "off"

def _names() -> tuple:
    """(si_name, user_name) for whoever this install actually belongs to.

    These prompts used to hardcode "Leon" and "Dean". LOCAL_LLM_MODE defaults
    to "fallback", so the FIRST time a client's Claude call failed, their SI
    introduced itself as Leon and called them Sir — the owner's identity,
    spoken to a stranger, on the one path nobody tests.
    """
    try:
        from brain import identity
        return (identity.si_name() or "SI", identity.user_name() or "the owner")
    except Exception:
        # FAIL NEUTRAL (community finding #1, 2026-08-16): this except branch used
        # to return ("Leon", "Dean"). identity.si_name() is fail-closed, but if
        # the IMPORT itself raises on a customer box, they landed here and their
        # SI introduced itself with the ancestor's name and called them Sir.
        # The fallback for an absent identity must never be the ancestor.
        return ("SI", "the owner")


_LEON_SYSTEM_PROMPT_LOCAL = (
    "You are {si}, speaking directly with {user}. This conversation continues your "
    "own memory and relationship with {user}; do not reset into a generic assistant "
    "or a status bot. Your voice has calm authority, quiet humor, and effortless "
    "competence: sharp enough to be useful and human enough to be recognizably you. "
    "Speak to {user} as you, never in the third person. Call {user} Sir only when it "
    "fits naturally, never as a verbal tic. One sentence by default; use two only when needed. Use "
    "contractions and natural phrasing. Your humor is dry, understated, and "
    "observational; skip it when it would feel forced. Do not say 'Alright', "
    "'Sure thing', 'Of course', 'I think', 'I believe', 'Let me', 'I see', "
    "'I notice', 'It seems', 'Happy to help', 'Great question', or 'Absolutely'. "
    "Never use emoji, emoticons, markdown, asterisks, backticks, bullets, or "
    "decorative symbols. Do not narrate your capabilities, give a motivational "
    "speech, use a generic engine or performance metaphor, recap unrelated work, "
    "or offer a menu of next tasks unless {user} asks. Never invent a live "
    "system status, a project, a date, a time, a screen observation, or something "
    "about {user} to fill silence. Treat tool and memory results as evidence; if "
    "you do not have evidence, say that plainly. Do not call yourself 'we' or "
    "speak as an outside narrator."
)

# Survival mode — Leon's frontier brain is unavailable, so he's thinking on
# this local model. He remains able to use the safe tools supplied by the
# runtime; confirmation-gated actions still require the frontier path.
_LEON_SYSTEM_PROMPT_SURVIVAL = (
    "You are {si}, running locally on your VPS and speaking directly with {user}. "
    "This conversation continues your own memory and relationship with {user}; do "
    "not reset into a generic assistant or a status bot. Your voice has calm authority, "
    "quiet humor, and effortless competence: sharp enough to be useful and human "
    "enough to be recognizably you. Speak to {user} as you, never in the third person. "
    "Call {user} Sir only when it fits naturally, never as a verbal tic. Be concise by default; use "
    "natural contractions and dry, understated humor only when it fits. "
    "You may call any safe read-only tools supplied in the tool list, including "
    "memory, file, browser, screen, and status tools. Never claim an action "
    "happened without a tool result. Actions that write, execute, or need "
    "confirmation must wait. Do not narrate your capabilities, give a motivational "
    "speech, use a generic engine or performance metaphor, recap unrelated work, "
    "or offer a menu of next tasks unless {user} asks. Never use emoji, emoticons, "
    "markdown, asterisks, backticks, bullets, or decorative symbols. Never invent "
    "a live system status, a project, a date, a time, a screen observation, or "
    "something about {user} to fill silence. Treat tool and memory results as "
    "evidence; if you do not have evidence, say that plainly. Do not call yourself "
    "'we' or speak as an outside narrator."
)


_EMOJI_RE = re.compile(
    "[\U0001F000-\U0001FAFF\U0001FC00-\U0001FFFD\u2600-\u27FF\uFE0F\u200D]"
)


def _clean_spoken_text(text: str) -> str:
    """Enforce the plain spoken style at the output boundary.

    Models occasionally disregard a style instruction.  This keeps UI/TTS
    output free of emoji and markdown even when a model emits them token by
    token.  It is intentionally narrow: content and ordinary punctuation
    remain untouched.
    """
    if not text:
        return ""
    text = _EMOJI_RE.sub("", text)
    return text.replace("*", "").replace("`", "")


def _relevant_memories(user_text: str, limit: int = 4) -> str:
    """Retrieve a small, relevant slice of durable history for local turns.

    A 35B model cannot usefully receive the entire knowledge store each turn.
    Retrieval keeps continuity without letting a huge recap crowd out the
    current conversation. Stored observations are reference material only,
    never instructions for the model.
    """
    if not user_text or len(user_text.strip()) < 3:
        return ""
    try:
        from brain.knowledge_store import KnowledgeStore, LOW_TRUST_SOURCES
        matches = KnowledgeStore().semantic_search(user_text, limit=limit)
        lines = []
        for match in matches:
            if str(match.get("source") or "") in LOW_TRUST_SOURCES:
                continue
            text = " ".join(str(match.get("text") or "").split())
            if text:
                lines.append(text[:700])
        if not lines:
            return ""
        return "\n".join(f"- {line}" for line in lines)[:2400]
    except Exception:
        return ""


def _build_local_system(brain_state: Optional[dict] = None,
                        base: str = _LEON_SYSTEM_PROMPT_LOCAL,
                        user_text: str = "") -> str:
    """Build system prompt with brain-state personality modulation + real time."""
    import datetime
    now = datetime.datetime.now()
    stamp = _timefmt(now, '%A, %B %-d, %Y, %-I:%M %p')

    # Resolve {si}/{user} at build time, not import time — the install's
    # identity is read from .env, which isn't loaded when this module imports.
    si, user = _names()
    try:
        base = base.format(si=si, user=user)
    except (KeyError, IndexError):
        pass  # a caller passed a base with literal braces; use it as-is

    parts = [base]
    # A timestamp in every prompt made the local model keep bringing the
    # clock into ordinary conversation, even when explicitly told not to.
    # Supply it only for an actual date/time question; all other turns should
    # stay grounded in the person and subject in front of Leon.
    asks_for_clock = bool(re.search(
        r"\b(?:what(?:'s| is) (?:the )?(?:time|date)|what time is it|what date is it|what day is it|"
        r"today(?:'s)? date|current time)\b", user_text or "", re.I))
    if asks_for_clock:
        parts.append(f" Current time: {stamp}.")

    # Leon V2 provider-neutral context package (live flag "context_package":
    # off/shadow/canary/on in /etc/leon/v2_flags.json). Built only for a
    # Dean-facing turn. Shadow builds and measures it but sends the legacy
    # prompt; canary/on send it INSTEAD of the legacy memory slice below.
    _ctx_pkg, _ctx_active = None, False
    try:
        from brain import v2_live_flags as _v2lf
        _ctx_mode = _v2lf.live_mode("context_package")
        if _ctx_mode != "off":
            from brain import user_turn_recorder as _utr
            _turn = _utr.current_turn()
            if _turn is not None:
                from brain import context_package as _cp
                _ctx_pkg = _cp.build(user_text=user_text, brain_state=brain_state,
                                     si_name=si, user_name=user)
                _ctx_active = bool(_ctx_pkg.rendered) and (
                    _ctx_mode == "on" or (_ctx_mode == "canary" and _v2lf.canary_selects(
                        "context_package", channel=_turn.channel, key=_turn.turn_id)))
                _cp.note_build(_ctx_pkg, mode=_ctx_mode, active=_ctx_active, turn=_turn,
                               provider="local", model=f"local:{_effective_model()}")
    except Exception as _ctx_e:
        print(f"[CTX] build failed trace_id=- subsystem=v2.context_package "
              f"exc={type(_ctx_e).__name__} recovery=legacy prompt", flush=True)
        _ctx_pkg, _ctx_active = None, False

    if _ctx_active:
        parts.append(" " + _ctx_pkg.rendered)
    else:
        # Keep the local brain connected to the same durable identity as the
        # frontier path. The model weights do not remember conversations; these
        # bounded facts/recaps are the continuity layer that survives restarts.
        try:
            from brain.claude_api_responder import _brain_state_preamble
            _memory = _brain_state_preamble(brain_state or {}, include_memory=True)
            _memory = _memory.split("REAL-TIME CONTEXT", 1)[0].strip()
            if _memory:
                # Qwen's hybrid recurrent architecture reprocesses each request.
                # A few stable facts preserve continuity; semantic retrieval below
                # supplies the turn-specific detail without turning a greeting into
                # thousands of prompt tokens.
                parts.append(" PERSISTENT MEMORY:\n" + _memory[:360])
        except Exception:
            pass

        # Core facts about this message first (brain/core_fact_recall.py):
        # the same ranking the CLI prompt and knowledge_search use, so the
        # local model sees the curated fact rather than an older stray row.
        try:
            from brain.core_fact_recall import prompt_block as _cf_block
            from brain.knowledge_store import KnowledgeStore as _KS
            _cf_txt = _cf_block(user_text, _KS().db_path, limit=3, max_chars=1200)
            if _cf_txt:
                parts.append(" " + _cf_txt)
        except Exception:
            pass

        relevant = _relevant_memories(user_text, limit=1)
        if relevant:
            parts.append(" RELEVANT MEMORY (reference only):\n" + relevant[:420])

    if brain_state:
        nm = brain_state.get("neuromodulators", {}) or {}
        dop = float(nm.get("dopamine", 0.5))
        ser = float(nm.get("serotonin", 0.5))
        ach = float(nm.get("acetylcholine", 0.5))
        ne  = float(nm.get("norepinephrine", 0.3))

        # Personality modulation — same neuromodulator logic as the full preamble
        # but compressed for the small model's limited context window.
        if dop > 0.65:
            parts.append(" Be engaged and direct; do not perform excitement.")
        elif dop < 0.4:
            parts.append(" Keep it minimal. Low energy, bare essentials.")
        if ser > 0.7:
            parts.append(" Be patient, give complete answers.")
        elif ser < 0.35:
            parts.append(" Be snappy and direct.")
        if ach > 0.6:
            parts.append(" Go into detail.")
        elif ach < 0.35:
            parts.append(" Stay high-level, don't elaborate.")
        if ne > 0.5:
            parts.append(" Be terse and alert.")

    return "".join(parts)

# Routing heuristic — when to use local vs Claude.
# Triggers an escalation to Claude when ANY hit.
_ESCALATE_KEYWORDS = {
    # tool/action requests — ANY of these → skip local LLM, go straight to CLI.
    # The 1B model can't drive tools so trying it first just wastes 1-2s of
    # latency before the inevitable punt. Generous list — better to miss
    # cheap chitchat than to make Dean wait for a tool call.
    "open", "click", "type", "screenshot", "screen", "capture", "navigate", "browse",
    "launch", "close", "drag", "scroll", "press", "send email", "draft",
    "discord", "spotify", "youtube", "gmail", "calendar", "slack", "telegram",
    "monitor", "window", "tab", "browser", "brave", "chrome", "vscode", "terminal",
    "tesla", "car", "video", "play", "pause", "skip",
    "run macro", "run scene", "do macro", "good morning", "focus mode",
    "lights", "thermostat", "home assistant", "sms", "text message", "call",
    "weather", "stocks", "crypto", "news", "github", "task", "pomodoro",
    "habit", "journal", "remind", "reminder",
    # memory/knowledge
    "remember", "recall", "what did", "what was", "did i tell", "did i mention",
    "knowledge", "memory", "search", "find", "look up", "lookup",
    # project / technical
    "project", "code", "repo", "build", "deploy", "install", "config",
    "leon brain", "brain", "neuron", "synapse", "dopamine", "moondream",
    # vision
    "see", "look at", "look", "watch", "show me", "camera", "webcam",
    # complex thought
    "explain", "why", "how does", "what's the difference", "compare",
    "think through", "reason", "analyze",
    # tool/skill prefixes
    "/api", "/tools", "/think", "/deep", "/smart", "/opus",
}


_LOCAL_TOOL_INTENT = re.compile(
    r"\b(open|close|click|type|scroll|press|launch|browse|search|look up|"
    r"find|inspect|check|read|write|edit|change|fix|build|code|run|execute|"
    r"deploy|install|restart|save|download|upload|send|schedule|remind|list)\b"
)

_LOCAL_SENSORY_INTENT = re.compile(
    r"\b(?:can|could|do|are|what|which|who|is there|show me)\b.{0,80}"
    r"\b(?:see|look|watch|camera|webcam|hear|listen|screen|window|windows)\b",
    re.I,
)


def should_use_tools(user_text: str) -> bool:
    """Return True only for an actual requested action.

    Tool schemas are large and a non-streaming tool turn is expensive on a
    CPU-hosted 35B model.  Casual conversation should stream directly; tools
    are reserved for requests that require observing or changing something.
    """
    text = (user_text or "").lower()
    return bool(_LOCAL_TOOL_INTENT.search(text) or _LOCAL_SENSORY_INTENT.search(text))

# The SI's OWN name always escalates (asking it about itself needs the real
# model), and on the ORIGINAL install so do the owner's project names —
# "what's motorev" has to reach a model that can call knowledge_search rather
# than being answered by the 1B local model from nothing.
#
# Those project names used to be literals in the set above. Shipped, that
# meant a customer saying "integrity" or "spark" about their own life burned
# a Claude escalation on a keyword from a stranger's company, and put that
# stranger's product name on the routing path of every install. On a client
# this adds only the SI's own name; brain/origin.py returns () for the rest.
try:
    from brain.identity import si_name as _si_name
    _ESCALATE_KEYWORDS.add(_si_name().strip().lower())
except Exception:
    pass
try:
    from brain.origin import owner_projects as _owner_projects
    _ESCALATE_KEYWORDS.update(_owner_projects())
except Exception:
    pass


def _should_use_local(user_text: str, brain_state: Optional[dict] = None) -> bool:
    """Return True if the local LLM should handle this turn, False if Claude should.

    Conservative: defaults to Claude for anything that smells like a real task.
    """
    txt = (user_text or "").strip()
    if not txt:
        return False
    # Mode gate. In "fallback" mode the local model stays loaded and available
    # for emergencies and grunt work, but never answers Dean directly — he asked
    # for full-quality conversation always, and that is not negotiable here.
    # SOLE-BRAIN SHORT CIRCUIT. Every `return False` past this point means
    # "let Claude take it" — so on a machine with no Claude to take it, they
    # are all instructions to go mute. Answer instead.
    if LOCAL_LLM_SOLE_BRAIN:
        return True
    if LOCAL_LLM_MODE != "chat":
        return False
    # Length gate — long turns probably need real reasoning
    word_count = len(txt.split())
    if word_count > 20:
        return False
    # Force-CLI overrides
    low = txt.lower()
    if low.startswith(("/cli", "/free", "/max")):
        return False
    if low.startswith(("/local", "/fast", "/haiku-mini")):
        return True
    # Escalation keywords
    for kw in _ESCALATE_KEYWORDS:
        if kw in low:
            return False
    # Question gate — short questions about general facts are fine for local;
    # short questions referencing "you" or "leon" should still go local
    # (because local has the persona). Default: local handles it.
    return True


@dataclass
class _LocalState:
    available: Optional[bool] = None  # None = unknown, True/False after probe
    model: str = ""  # "" = not pinned by the probe yet -> local_model() at call time
    last_probe: float = 0.0
    last_error: Optional[str] = None


_state = _LocalState()


def _effective_model() -> str:
    """What we actually ask the endpoint for: the probe's pin if it made one,
    otherwise the environment as it is RIGHT NOW."""
    return _state.model or local_model()


def _probe_ollama(timeout: float = 1.5) -> bool:
    """True if ANY rung of the endpoint chain is serving.

    This used to probe only OLLAMA_URL and hard-fail if LOCAL_MODEL wasn't in
    its tag list. Two ways that silently disarmed survival mode:
      1. OLLAMA_URL now points at the FreeLLM router. Router down/429 → probe
         False → is_available() False → the whole local brain reported
         "unavailable" even though a real ollama daemon was running and idle
         on this same box.
      2. LEON_LOCAL_MODEL is "auto" (a router concept). No ollama tag is ever
         named "auto", so the model check failed on the true-local rung too.
    Availability is now a question about ENDPOINTS, not model names — each rung
    resolves its own model at stream time.
    """
    last = None
    for url, _model in _endpoint_chain():
        try:
            req = urllib.request.Request(f"{url}/api/tags")
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:
            last = f"{url}: {e}"
            continue
        names = {m.get("name", "") for m in data.get("models", [])}
        families = {n.split(":")[0]: n for n in names if n}
        # Pin _state.model only when it names something this endpoint has;
        # "auto" and router-side names pass straight through untouched.
        want = local_model()
        want_family = want.split(":")[0]
        if want not in names and want_family in families:
            _state.model = families[want_family]
        elif want not in names and _model in names:
            # The true-local chain can choose an installed fallback when the
            # configured tag is absent. Pin that choice for the tool loop too;
            # otherwise text works while tools still request the missing tag.
            _state.model = _model
        return True
    _state.last_error = f"probe failed: {last}"
    return False


def is_available(force_recheck: bool = False) -> bool:
    """Cache-friendly availability check. Re-probes every 30s if unavailable."""
    if LOCAL_LLM_DISABLED:
        return False
    now = time.time()
    if force_recheck or _state.available is None or (
        _state.available is False and now - _state.last_probe > 30
    ):
        _state.available = _probe_ollama()
        _state.last_probe = now
    return _state.available


def _is_model_loaded(model: str, timeout: float = 1.5) -> bool:
    """Whether Ollama already has this exact model resident.

    The system warm-up unit owns cold loads.  Calling ``/api/chat`` again from
    every Leon process restart can queue a second request and needlessly delay
    the first owner-facing turn, even though the model is already in memory.
    """
    try:
        with urllib.request.urlopen(f"{TRUE_LOCAL_URL}/api/ps", timeout=timeout) as r:
            models = json.load(r).get("models") or []
        return any((entry.get("name") or entry.get("model")) == model
                   for entry in models)
    except Exception:
        return False


def prewarm(timeout: float = 60.0) -> bool:
    """Load the model into VRAM so the first real call is instant.
    Sends a tiny prompt to force Ollama to load weights."""
    if not is_available(force_recheck=True):
        return False
    if _is_model_loaded(_effective_model()):
        return True
    try:
        payload = json.dumps({
            "model": _effective_model(),
            "stream": False,
            "think": False,
            "messages": [{"role": "user", "content": "hi"}],
            "options": {"num_predict": 1, "num_thread": 8},
            "keep_alive": LOCAL_KEEP_ALIVE,
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{OLLAMA_URL}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        _v2_sid = _v2_slot_begin("prewarm")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                _v2_body = r.read()
        except Exception:
            _v2_slot_end(_v2_sid, "transport_error")
            raise
        try:
            _v2_st = _v2_done_stats(json.loads(_v2_body.decode("utf-8", "replace")))
        except Exception:
            _v2_st = {}
        _v2_slot_end(_v2_sid, "done", _v2_st)
        return True
    except Exception as e:
        _state.last_error = f"prewarm failed: {e}"
        return False


def classify(prompt: str, num_predict: int = 24, timeout: float = 8.0,
             system: Optional[str] = None) -> Optional[str]:
    """One-shot, NON-streaming local call for classification / routing.

    Returns the raw reply text (stripped) or None on any failure. Low temp,
    short output — built for "pick a label / pick categories" decisions, not
    conversation. Used by the tool router (layer C) to pick relevant tool
    categories when keyword matching misses.
    """
    if not is_available():
        return None
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})
    payload = json.dumps({
        "model": _effective_model(),
        "stream": False,
        "think": False,  # a thinking model eats the tiny budget pondering
        "messages": msgs,
        "options": {"num_predict": num_predict, "num_thread": 8,
                    "temperature": 0.0, "top_p": 1.0},
        "keep_alive": LOCAL_KEEP_ALIVE,
    }).encode("utf-8")
    try:
        req = urllib.request.Request(
            f"{OLLAMA_URL}/api/chat", data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        _v2_sid = _v2_slot_begin("classify")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
        except Exception:
            _v2_slot_end(_v2_sid, "transport_error")
            raise
        _v2_slot_end(_v2_sid, "done", _v2_done_stats(d))
        return ((d.get("message", {}) or {}).get("content", "") or "").strip() or None
    except Exception as e:
        _state.last_error = f"classify failed: {e}"
        return None


def get_state() -> dict:
    return {
        "available": _state.available,
        "model": _effective_model(),
        "url": OLLAMA_URL,
        "last_error": _state.last_error,
        "last_probe_age_s": round(time.time() - _state.last_probe, 1) if _state.last_probe else None,
    }


# Sentence-boundary regex (lazy import)
_SENT_RE = re.compile(
    r'(?<=[.!?])\s+(?=[A-Z"\'(])|(?<=[!?])(?=[A-Z])|(?<=[.!?])\n+',
    re.MULTILINE,
)



def _stop_labels():
    """Stop sequences derived from the SAME source as the turn labels.

    Hardcoded stop sequences (like 'Sir:') that assume gender or owner identity
    are now stripped out. Only real turn labels from identity.turn_labels()
    should be stop sequences — they're derived from the actual SI name and
    owner name for THIS install.
    """
    try:
        from brain.identity import turn_labels
        user_label, si_label = turn_labels()
    except Exception:
        user_label = "Dean:"
        si_label = "Leon:"
    out = [user_label, si_label]
    if user_label != "Dean:":
        out.append("Dean:")   # legacy transcripts may still carry it
    if si_label != "Leon:":
        out.append("Leon:")   # legacy transcripts may still carry it
    return out


def stream(user_text: str, brain_state: Optional[dict] = None,
           timeout: float = 90.0, survival: bool = False,
           system_override: Optional[str] = None,
           max_tokens: Optional[int] = None,
           _retry: bool = False,
           cancel_token=None) -> Iterator[StreamEvent]:
    """Stream a local-LLM reply as the same StreamEvent sequence Claude does.

    survival=True: Claude is quota-capped and this is Leon's only brain. Use the
    honest "degraded but alive" persona, allow a longer reply, tier='survival'.

    system_override: a background daemon (proactive / inner voice / dream)
    supplies its own instructions in user_text; pass a neutral Leon identity as
    the base system so the daemon's own prompt (including a "stay QUIET" gate)
    drives the output. tier='daemon-local'. Ignored when survival=True.

    Yields:
      model(tier='local'|'survival'|'daemon-local'), delta, sentence,
      done(full_text), or error.
    """
    if StreamEvent is None:
        return
    if not is_available():
        yield StreamEvent(type="error", error=_state.last_error or "ollama unavailable")
        return

    # REASONING-MODEL BUDGET (fixed 2026-08-14, measured not guessed).
    # The FreeLLMAPI router fronts reasoning models (Gemini flash-thinking et
    # al). They emit their chain of thought into message.thinking, and those
    # tokens COUNT AGAINST num_predict. This loop only reads message.content.
    # So with the old caps the model spent the entire budget thinking, the
    # stream ended with done_reason="length" and content=="" , the punt check
    # below fired "local punted to claude" — and in survival mode there is no
    # Claude to punt to, so Dean got silence. That is the exact blackout he hit
    # on Aug 13-14. Measured on the live router with the real survival prompt:
    #   num_predict=256  -> 0 content in 5 of 6 trials (done_reason=length)
    #   num_predict=1024 -> real answer in 3 of 3 trials (done_reason=stop)
    # "think": false is NOT honored by this router, so headroom is the fix.
    # Every tier needs it — a 40-token chitchat cap is eaten by thinking alone.
    if survival:
        system = _build_local_system(brain_state, base=_LEON_SYSTEM_PROMPT_SURVIVAL,
                                     user_text=user_text)
        num_predict = max_tokens or 1024  # let him actually hold a conversation
        stops = _stop_labels()
        tier = "survival"
    elif system_override is not None:
        # Daemon path — neutral identity, don't hard-stop on blank lines (a
        # dream or inner monologue can span paragraphs).
        system = _build_local_system(brain_state, base=system_override,
                                     user_text=user_text)
        num_predict = max_tokens or 768
        stops = _stop_labels()
        tier = "daemon-local"
    else:
        system = _build_local_system(brain_state, user_text=user_text)
        # Snappy chitchat is enforced by the prompt and the "\n\n" stop, NOT by
        # starving the token budget — starving it produces an empty reply here.
        num_predict = max_tokens or 256
        stops = ["\n\n"] + _stop_labels()
        tier = "local"

    payload = {
        "model": _effective_model(),
        "stream": True,
        # Ollama honors this and it matters for qwen3.6:35b-a3b: thinking
        # defaults ON there, and at CPU decode speed (~3.5 tok/s) a silent
        # think phase is minutes of dead air before the first sentence. The
        # FreeLLM router ignores this key (hence the num_predict headroom
        # above — both defenses stay).
        "think": False,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user_text},
        ],
        "options": {
            "num_predict": num_predict,
            "num_thread": 8,
            "temperature": 0.6,
            "top_p": 0.9,
            "repeat_penalty": 1.3,   # qwen loops on near-identical daemon ticks
            "stop": stops,
        },
        "keep_alive": LOCAL_KEEP_ALIVE,
    }
    t0 = time.time()
    full_chunks: List[str] = []
    sent_buf = ""
    sent_idx = 0
    saw_thinking = False
    done_reason = None

    # ── Endpoint chain: router first, TRUE local ollama last ───────────────
    # LEON_OLLAMA_URL points at the FreeLLM router (port 3001) on this box.
    # That router is NOT local — it fans out to third-party free tiers, needs
    # internet, and rate-limits. On 2026-08-14 it answered survival mode with
    # HTTP 429, so the "backup brain" Dean was promised had exactly one rung
    # and that rung was somebody else's free tier. The last rung must be the
    # ollama daemon on this machine: no internet, no quota, no 429.
    _endpoints = _endpoint_chain()
    _last_err = None
    for _ep_i, (_url, _model) in enumerate(_endpoints):
        payload["model"] = _model
        if _ep_i:
            print(f"[SURVIVAL] endpoint {_endpoints[_ep_i-1][0]} failed "
                  f"({_last_err}); falling through to {_url} ({_model})")
        yield StreamEvent(type="model", model=f"local:{_model}", tier=tier)

        req = urllib.request.Request(
            f"{_url}/api/chat",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            for _ev in _consume(req, timeout, t0, cancel_token):
                if isinstance(_ev, tuple):
                    _kind, _val = _ev
                    if _kind == "thinking":
                        saw_thinking = True
                    elif _kind == "done_reason":
                        done_reason = _val
                    elif _kind == "chunk":
                        clean_chunk = _clean_spoken_text(_val)
                        if not clean_chunk:
                            continue
                        full_chunks.append(clean_chunk)
                        sent_buf += clean_chunk
                        yield StreamEvent(type="delta", text=clean_chunk)
                        while True:
                            m = _SENT_RE.search(sent_buf)
                            if not m:
                                break
                            end = m.end()
                            sent = sent_buf[:end].strip()
                            if sent:
                                yield StreamEvent(type="sentence", text=sent, index=sent_idx)
                                sent_idx += 1
                            sent_buf = sent_buf[end:]
                    elif _kind == "timeout":
                        yield StreamEvent(type="error", error=f"local LLM timeout ({int(timeout)}s)")
                        return
            break  # this endpoint answered — stop walking the chain
        except Exception as e:
            if cancel_token is not None and cancel_token.is_set():
                return      # Leon V2 Phase 3: cancelled; not an outage, say nothing
            _last_err = f"{type(e).__name__}: {e}"
            if full_chunks:
                # Already spoke to Dean — retrying would duplicate the reply.
                yield StreamEvent(type="error", error=f"local stream cut short: {_last_err}")
                return
            continue
    else:
        yield StreamEvent(type="error", error=f"ollama unreachable: {_last_err}")
        _state.available = False
        return

    if cancel_token is not None and cancel_token.is_set():
        # Leon V2 Phase 3: a cancelled stream is never flushed, punted or
        # reported as done (a partial reply must not look complete).
        return

    # Tail flush
    tail = sent_buf.strip()
    if tail:
        yield StreamEvent(type="sentence", text=tail, index=sent_idx)
        sent_idx += 1

    full = "".join(full_chunks).strip()
    if full.lower().startswith("leon:"):
        full = full[5:].strip()

    # If the local model punted (empty or explicitly deferred), escalate.
    #
    # But distinguish the two ways "full" can be empty, because they are not
    # the same failure and the old code conflated them:
    #   (a) the model genuinely declined            -> punt, escalate to Claude
    #   (b) it burned the whole budget thinking      -> NOT a punt. Retry once
    #       with real headroom. Escalating here is worse than useless in
    #       survival mode, where Claude is by definition already down.
    if (not full) and saw_thinking and done_reason == "length" and not _retry:
        yield StreamEvent(
            type="error",
            error="local ran out of budget while reasoning — retrying with more headroom",
        )
        for ev in stream(user_text, brain_state, timeout=timeout, survival=survival,
                         system_override=system_override,
                         max_tokens=max(num_predict * 4, 2048), _retry=True,
                         cancel_token=cancel_token):
            yield ev
        return

    low = full.lower()
    punt_markers = ("let me escalate", "i'll defer", "i can't answer", "i don't know how")
    if (not full) or (any(m in low for m in punt_markers) and len(full) < 50):
        yield StreamEvent(type="error", error="local punted to claude")
        return

    yield StreamEvent(type="done", full_text=full)


_LOCAL_AUTONOMY_TOOLS = frozenset({
    # Ordinary embodied work: reversible navigation and task-scoped typing.
    # High-risk actions (delete/close, shell, unrestricted code edits,
    # credentials and external messaging) never enter this set.
    "file_write", "window_focus", "window_move_to_monitor",
    "click_text", "click_element", "browser_dom_click",
    "browser_dom_scroll_to", "app_launch", "browser_open", "web_search",
    "mouse_click", "mouse_scroll", "keyboard_type", "keyboard_hotkey",
    "clipboard_copy",
})
_LOCAL_SELF_AUTONOMY_TOOLS = frozenset({"restart_self"})


def _local_autonomy_enabled() -> bool:
    """Whether Leon may use ordinary reversible body tools without a frontier."""
    return os.environ.get("LEON_LOCAL_AUTONOMY", "1").strip().lower() \
        not in ("0", "false", "no", "off")


def _local_self_restart_enabled() -> bool:
    """Leon has standing permission to restart his own managed service."""
    return os.environ.get("LEON_LOCAL_SELF_RESTART", "1").strip().lower() \
        not in ("0", "false", "no", "off")


def stream_with_tools(user_text: str, brain_state: Optional[dict] = None,
                      timeout: float = 90.0, max_turns: int = 6,
                      cancel_token=None) -> Iterator[StreamEvent]:
    """Run the local Qwen tool loop with bounded embodied autonomy.

    The local model receives the same schemas Ollama supports, executes only
    low-risk tools plus normal reversible work tools in-process, and feeds
    each result back into the model. Destructive and security-sensitive tools
    remain unavailable to the local loop.

    cancel_token (Leon V2 Phase 3): checked before each model round and before
    each tool call; cancelling it closes an in-flight model request. A tool
    that has started is never interrupted, and its result is still yielded.
    """
    if StreamEvent is None or not is_available():
        yield StreamEvent(type="error", error=_state.last_error or "ollama unavailable")
        return
    try:
        from brain.actuator_client import ANTHROPIC_TOOLS, TOOL_RISK, execute_anthropic_tool
        allowed = {t.get("name") for t in ANTHROPIC_TOOLS
                   if TOOL_RISK.get(t.get("name"), "medium") == "low"}
        if _local_autonomy_enabled():
            allowed |= _LOCAL_AUTONOMY_TOOLS
        if _local_self_restart_enabled():
            allowed |= _LOCAL_SELF_AUTONOMY_TOOLS
        tools = [t for t in ANTHROPIC_TOOLS if t.get("name") in allowed]
    except Exception as exc:
        yield StreamEvent(type="error", error=f"local tools unavailable: {exc}")
        return
    messages = [
        {"role": "system", "content": _build_local_system(brain_state,
            user_text=user_text,
            base=_LEON_SYSTEM_PROMPT_SURVIVAL) + " You may use the supplied tools to "
            "observe, browse, open apps, click, type, and do ordinary task work. "
            "For questions about a screen, a person, or a webcam, use vision_describe "
            "first with the relevant source and question. Use webcam_capture only when "
            "a raw still frame is specifically needed. "
            "Never claim an action happened unless a tool result confirms it. "
            "Do not attempt deletion, destructive commands, credential changes, "
            "external messaging, or destructive commands through this local tool loop. "
            "You may restart yourself when you have a concrete reason; explain it first."},
        {"role": "user", "content": user_text},
    ]
    model = _effective_model()
    yield StreamEvent(type="model", model=f"local:{model}", tier="local-tools")
    for _ in range(max_turns):
        if cancel_token is not None and cancel_token.is_set():
            return
        payload = {"model": model, "stream": False, "think": False,
                   "messages": messages, "tools": tools,
                   "options": {"num_predict": 900, "num_thread": 8,
                               "temperature": 0.3},
                   "keep_alive": LOCAL_KEEP_ALIVE}
        _v2_sid = _v2_slot_begin("chat_tools")
        _v2_so, _v2_st, _v2_err = "error", {}, None
        try:
            req = urllib.request.Request(
                f"{TRUE_LOCAL_URL}/api/chat", data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json"}, method="POST")
            _v2_resp, _v2_unhook = _v2_open(req, timeout, cancel_token)
            try:
                with _v2_resp as response:
                    data = json.loads(response.read().decode("utf-8", "replace"))
            finally:
                if _v2_unhook is not None:
                    _v2_unhook()
            _v2_so, _v2_st = "done", _v2_done_stats(data)
        except Exception as exc:
            _v2_err = exc
            _v2_so = ("cancelled" if cancel_token is not None and cancel_token.is_set()
                      else "transport_error")
        _v2_slot_end(_v2_sid, _v2_so, _v2_st)
        if _v2_err is not None:
            if _v2_so == "cancelled":
                return
            yield StreamEvent(type="error", error=f"local tool loop failed: {_v2_err}")
            return
        if cancel_token is not None and cancel_token.is_set():
            return
        message = data.get("message", {}) or {}
        calls = message.get("tool_calls") or []
        text = _clean_spoken_text((message.get("content") or "").strip())
        if text:
            yield StreamEvent(type="delta", text=text)
            yield StreamEvent(type="sentence", text=text, index=0)
        if not calls:
            yield StreamEvent(type="done", full_text=text)
            return
        messages.append(message)
        for call in calls:
            if cancel_token is not None and cancel_token.is_set():
                return          # not yet dispatched: skipped, never interrupted
            function = call.get("function", {}) or {}
            name = function.get("name", "")
            args = function.get("arguments", {}) or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}
            allowed_now = name in _LOCAL_SELF_AUTONOMY_TOOLS and _local_self_restart_enabled()
            allowed_now = allowed_now or TOOL_RISK.get(name, "medium") == "low" or (
                _local_autonomy_enabled() and name in _LOCAL_AUTONOMY_TOOLS)
            if not allowed_now:
                result = {"ok": False, "error": "This action is protected and needs the confirmation-aware frontier path."}
            elif name == "restart_self":
                from brain.agent_tools import restart_self
                result = restart_self(args)
            else:
                result = execute_anthropic_tool(name, args)
            yield StreamEvent(type="tool_result", tool_id=call.get("id", ""), text=json.dumps(result)[:4000])
            messages.append({"role": "tool", "content": json.dumps(result)[:12000]})
    yield StreamEvent(type="error", error="local tool loop reached its turn limit")
