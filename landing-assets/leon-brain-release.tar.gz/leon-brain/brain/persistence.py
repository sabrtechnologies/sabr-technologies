"""
Brain Persistence - Save and load brain state across sessions.

Stores synapse weights, neuromodulators, development stage, working memory,
hippocampus memories, and step count so the brain remembers everything.

SAFETY FEATURES:
- Automatic versioned backups before every save
- Keeps the last 10 backups rolling
- If load fails due to neuron mismatch, save is PRESERVED (never overwritten)
- Update-safe: brain_state folder is separate from code - updates never touch it
"""

import os
import sys
import json
import time
import shutil
import threading
import numpy as np
from scipy import sparse

# Module-level lock — save_brain has 4+ concurrent call sites (sim
# auto-save, FastAPI shutdown, WS cmd=save, HTTP /api/brain/save,
# SIGUSR1 handler). Without this, two saves can interleave and write
# half-pruned synapse matrices to disk while .eliminate_zeros() runs in
# the sim thread. Audit 2026-06-08 finding #2.
_SAVE_MUTEX = threading.Lock()


def _app_root():
    """Directory where brain_state/ should live.

    When frozen by PyInstaller, this is next to the .exe (so users can back up
    their data without spelunking into _internal/). Otherwise it's the project
    root (parent of the `brain/` package).
    """
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


SAVE_DIR = os.path.join(_app_root(), "brain_state")
BACKUP_DIR = os.path.join(SAVE_DIR, "backups")
MAX_BACKUPS = 3  # was 10 — each backup is ~19GB

# If a load is rejected, we set this flag and the server won't auto-save
# over the preserved state until the user explicitly opts in.
_SAVE_LOCKED = False
_LOCK_REASON = ""


def is_save_locked():
    """Check if auto-save is locked (protects preserved state)."""
    return _SAVE_LOCKED


def get_lock_reason():
    return _LOCK_REASON


def unlock_save(user_consent=False):
    """Manually unlock saving. Call this after user confirms they want to overwrite."""
    global _SAVE_LOCKED, _LOCK_REASON
    if user_consent:
        _SAVE_LOCKED = False
        _LOCK_REASON = ""
        print("[PERSIST] Save lock released - fresh brain will be saved")
        return True
    return False


def ensure_save_dir():
    """Ensure SAVE_DIR and BACKUP_DIR exist. Defensive against an observed
    transient permission failure where os.makedirs returns EACCES from
    inside the running brain process even though:
      - the dir exists already
      - the process is UID 0 with full capabilities
      - the parent perms (700 root) allow root to write
      - the exact same call from an interactive root shell succeeds

    Root cause is still under investigation (logged ~20 hits/log file as of
    2026-06-10 with no full repro). Until the underlying race or sysctl
    interaction is understood, skip makedirs when the dir is already a
    writable directory — that avoids the failing syscall entirely on the
    common path."""
    for d in (SAVE_DIR, BACKUP_DIR):
        if os.path.isdir(d) and os.access(d, os.W_OK):
            continue
        try:
            os.makedirs(d, exist_ok=True)
        except PermissionError:
            # Final fallback: if the dir does exist (race with another
            # save attempt that just created it) treat as success.
            if not os.path.isdir(d):
                raise


def _backup_current_state():
    """Create a timestamped backup of the current brain_state before overwriting."""
    meta_path = os.path.join(SAVE_DIR, "meta.json")
    if not os.path.exists(meta_path):
        return None  # Nothing to back up

    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)

        # Read existing meta to include stage/step in backup name
        try:
            with open(meta_path, "r") as f:
                meta = json.load(f)
            stage = meta.get("development_stage", "unknown")
            steps = meta.get("step_count", 0)
            neurons = meta.get("total_neurons", 0)
        except Exception:
            stage = "unknown"
            steps = 0
            neurons = 0

        # Timestamp folder name
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_name = f"{timestamp}_{stage}_{steps}steps_{neurons}n"
        backup_path = os.path.join(BACKUP_DIR, backup_name)
        os.makedirs(backup_path, exist_ok=True)

        # Only backup brain simulation state — NOT databases, voice models, etc.
        # Databases have WAL journaling. Voice models don't change. Backing up
        # everything was creating 19GB backups (17GB was just voice/).
        _BACKUP_ITEMS = {"regions", "synapses", "meta.json", "self_model.json"}
        for item in os.listdir(SAVE_DIR):
            if item not in _BACKUP_ITEMS and not item.endswith(".npz"):
                continue
            src = os.path.join(SAVE_DIR, item)
            dst = os.path.join(backup_path, item)
            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)

        print(f"[PERSIST] Backup created: {backup_name}")

        # Rotate - keep only the last MAX_BACKUPS
        _rotate_backups()

        return backup_path
    except Exception as e:
        print(f"[PERSIST] Backup failed (continuing anyway): {e}")
        return None


def _rotate_backups():
    """Keep only the last MAX_BACKUPS backups."""
    try:
        if not os.path.exists(BACKUP_DIR):
            return
        backups = sorted([
            os.path.join(BACKUP_DIR, d) for d in os.listdir(BACKUP_DIR)
            if os.path.isdir(os.path.join(BACKUP_DIR, d))
        ])
        while len(backups) > MAX_BACKUPS:
            oldest = backups.pop(0)
            shutil.rmtree(oldest, ignore_errors=True)
    except Exception:
        pass


def list_backups():
    """List all available backups."""
    if not os.path.exists(BACKUP_DIR):
        return []
    backups = []
    for d in sorted(os.listdir(BACKUP_DIR), reverse=True):
        full = os.path.join(BACKUP_DIR, d)
        if os.path.isdir(full):
            meta_file = os.path.join(full, "meta.json")
            info = {"name": d, "path": full}
            if os.path.exists(meta_file):
                try:
                    with open(meta_file, "r") as f:
                        info.update(json.load(f))
                except Exception:
                    pass
            backups.append(info)
    return backups


def restore_backup(backup_name):
    """Restore a specific backup as the current brain_state."""
    backup_path = os.path.join(BACKUP_DIR, backup_name)
    if not os.path.isdir(backup_path):
        print(f"[PERSIST] Backup not found: {backup_name}")
        return False

    # First, back up whatever's currently in SAVE_DIR
    _backup_current_state()

    # Clear current state (except backups folder)
    for item in os.listdir(SAVE_DIR):
        if item == "backups":
            continue
        src = os.path.join(SAVE_DIR, item)
        if os.path.isdir(src):
            shutil.rmtree(src, ignore_errors=True)
        else:
            os.remove(src)

    # Copy backup content into SAVE_DIR
    for item in os.listdir(backup_path):
        src = os.path.join(backup_path, item)
        dst = os.path.join(SAVE_DIR, item)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)

    print(f"[PERSIST] Restored backup: {backup_name}")
    return True


def save_brain(brain, path=None, force=False):
    """Save complete brain state to disk.

    Args:
        brain: Brain instance to save
        path: Save directory (default: brain_state/)
        force: If True, save even when save is locked (user-initiated save)

    Concurrency (post-2026-06-08 audit fix #2):
      - Whole body wrapped in _SAVE_MUTEX so the 4+ caller sites serialize.
      - Synapse .npz and traces .npz are written to *.tmp then atomically
        renamed via os.replace, matching the meta.json pattern. A crash
        mid-write leaves the previous correct file in place instead of
        a half-written .npz that sparse.load_npz silently misreads.
      - meta.json is written LAST (was first) so its presence on disk
        means "everything else is also on disk" — an atomic "save valid"
        indicator on recovery.
    """
    with _SAVE_MUTEX:
        return _save_brain_unlocked(brain, path, force)


def _save_brain_unlocked(brain, path, force):
    if path is None:
        path = SAVE_DIR
    ensure_save_dir()

    # Check lock - prevents auto-save from overwriting preserved state
    if _SAVE_LOCKED and not force:
        print(f"[PERSIST] Save skipped - state is locked: {_LOCK_REASON}")
        print(f"[PERSIST] Use /api/brain/unlock or restart with matching neuron count to enable saves")
        return False

    # Back up existing state before overwriting (rolling versioned backups)
    _backup_current_state()

    # Snapshot scalar metadata up front so meta.json (written LAST)
    # describes the state we are about to commit, not the state that
    # advanced while synapses were being serialized.
    state = {
        "step_count": brain.step_count,
        "total_neurons": brain.total_neurons,
        "development_stage": brain.development_stage,
        "neuromodulators": dict(brain.neuromodulators),
        "saved_at": time.time(),
        "uptime": time.time() - brain.start_time,
    }

    # Save synapse weights (sparse matrices) — atomic per-file via .tmp + rename.
    # Tmp paths MUST already end in .npz, because both sparse.save_npz and
    # np.savez_compressed auto-append ".npz" if the path doesn't end with
    # it. We use the pattern "foo.tmp.npz" → rename to "foo.npz" so scipy
    # writes exactly what we expect.
    syn_dir = os.path.join(path, "synapses")
    os.makedirs(syn_dir, exist_ok=True)

    # Sweep orphaned .tmp.npz before writing. A crash or a hard restart
    # between save_npz() and os.replace() leaves a partial (often zero-byte)
    # tmp file behind forever. It is never LOADED — load reads explicit
    # src__dst names — so it does no harm to the brain. It harms measurement:
    # on 2026-08-18 a zero-byte visual_cortex__thalamus.npz.tmp.npz crashed a
    # census tool that globbed *.npz, and a tool that dies on litter is a tool
    # you stop running. Found because the ratchet audit globbed the directory.
    try:
        for _orphan in os.listdir(syn_dir):
            if _orphan.endswith(".tmp.npz"):
                os.remove(os.path.join(syn_dir, _orphan))
    except Exception:
        pass

    for (src, dst), syn in brain.connections.items():
        if syn.nnz > 0:
            fpath = os.path.join(syn_dir, f"{src}__{dst}.npz")
            tmppath = os.path.join(syn_dir, f"{src}__{dst}.tmp.npz")
            sparse.save_npz(tmppath, syn.weights)
            os.replace(tmppath, fpath)
            # Save traces — same atomic pattern.
            tfpath = os.path.join(syn_dir, f"{src}__{dst}_traces.npz")
            tftmp  = os.path.join(syn_dir, f"{src}__{dst}_traces.tmp.npz")
            np.savez_compressed(
                tftmp,
                pre_trace=syn.pre_trace,
                post_trace=syn.post_trace,
                modulation=np.array([syn.modulation]),
            )
            os.replace(tftmp, tfpath)

    # Save region-specific state
    reg_dir = os.path.join(path, "regions")
    os.makedirs(reg_dir, exist_ok=True)

    for name, region in brain.regions.items():
        reg_state = {}

        # Save neuron state
        reg_state["v"] = region.neurons.v.tolist()
        reg_state["u"] = region.neurons.u.tolist()

        # Region-specific data
        if name == "hippocampus" and hasattr(region, "memory_buffer"):
            tail = slice(-100, None)
            memories = [m.tolist() for m in region.memory_buffer[tail]]
            reg_state["memory_buffer"] = memories
            # Also persist labels and strength so replay weighting survives restart
            if hasattr(region, "_memory_labels"):
                reg_state["memory_labels"] = region._memory_labels[tail]
            if hasattr(region, "_memory_strength"):
                reg_state["memory_strength"] = region._memory_strength[tail]

        if name == "prefrontal_cortex" and hasattr(region, "working_memory"):
            reg_state["working_memory"] = region.working_memory.tolist()

        if name == "anterior_cingulate" and hasattr(region, "prediction"):
            reg_state["prediction"] = region.prediction.tolist()

        if name in ("parietal_association", "temporal_association") and \
                hasattr(region, "binding_strength"):
            reg_state["binding_strength"] = region.binding_strength.tolist()

        if name == "brainstem":
            reg_state["energy"] = float(region.energy)
            reg_state["arousal"] = float(region.arousal)

        # Region JSON — also atomic.
        reg_path = os.path.join(reg_dir, f"{name}.json")
        reg_tmp = reg_path + ".tmp"
        with open(reg_tmp, "w") as f:
            json.dump(reg_state, f)
        os.replace(reg_tmp, reg_path)

    # Save metadata LAST. meta.json appearing on disk is the atomic
    # "save complete and consistent" indicator (audit fix #2 / finding 11).
    meta_path = os.path.join(path, "meta.json")
    meta_tmp = meta_path + ".tmp"
    with open(meta_tmp, "w") as f:
        json.dump(state, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(meta_tmp, meta_path)

    print(f"[PERSIST] Brain saved ({brain.step_count} steps, {len(brain.connections)} connections)")
    return True


def load_brain(brain, path=None):
    """Load brain state from disk. Returns True if successful."""
    global _SAVE_LOCKED, _LOCK_REASON

    if path is None:
        path = SAVE_DIR

    meta_path = os.path.join(path, "meta.json")
    if not os.path.exists(meta_path):
        print("[PERSIST] No saved state found")
        return False

    try:
        with open(meta_path, "r") as f:
            meta = json.load(f)

        # Verify compatibility
        if meta["total_neurons"] != brain.total_neurons:
            print(f"[PERSIST] Neuron count mismatch: saved={meta['total_neurons']}, current={brain.total_neurons}")
            print(f"[PERSIST] *** SAVE LOCKED *** Preserved state will NOT be overwritten.")
            print(f"[PERSIST] To restore this state, restart with: python run.py --neurons {meta['total_neurons']}")
            print(f"[PERSIST] Stage was: {meta.get('development_stage', '?')}, Steps: {meta.get('step_count', 0):,}")

            # Create a safety backup of the preserved state
            _backup_current_state()

            # Lock saves so this precious state isn't overwritten
            _SAVE_LOCKED = True
            _LOCK_REASON = (
                f"Saved state has {meta['total_neurons']:,} neurons but brain is running "
                f"with {brain.total_neurons:,}. Restart with --neurons {meta['total_neurons']} "
                f"to restore, or call /api/brain/unlock to discard."
            )
            return False

        # Restore metadata
        brain.step_count = meta["step_count"]
        brain.development_stage = meta["development_stage"]
        brain.neuromodulators = meta["neuromodulators"]
        # Floor alertness on restore — old snapshots saved norepinephrine=0.1
        # (basement), and nothing else pulls it back up day-to-day, so Leon
        # booted chronically under-alert. 0.3 = healthy resting alertness.
        try:
            if float(brain.neuromodulators.get("norepinephrine", 0.5)) < 0.5:
                brain.neuromodulators["norepinephrine"] = 0.5
        except Exception:
            pass

        # Restore synapse weights
        syn_dir = os.path.join(path, "synapses")
        if os.path.exists(syn_dir):
            # DEAD-PATHWAY BUG, found and fixed 2026-08-17.
            #
            # The guard used to read `os.path.exists(fname) and syn.nnz > 0`.
            # That checks the FRESHLY CONSTRUCTED matrix — which is always
            # populated, because __init__ wires every configured pathway at its
            # configured probability. It never checked the thing being loaded.
            # So an empty file on disk silently overwrote a healthy matrix, and
            # since save_brain() skips any matrix with nnz==0, the empty file
            # was never replaced. Once a pathway went empty it stayed empty
            # through every subsequent restart, permanently.
            #
            # Measured on this brain before the fix: 37 of 48 inter-region
            # pathways carried exactly zero current, including
            # thalamus>prefrontal_cortex, hippocampus>prefrontal_cortex,
            # wernicke>broca and every output of default_mode_network.
            # wernicke>broca alone: 8,914,838 synapses constructed at boot,
            # then zeroed by this line, on each of 654 restarts.
            #
            # Now: an empty or wrong-shaped file is REJECTED and the healthy
            # constructed matrix is kept, so the pathway self-heals on next
            # boot instead of staying dead forever. Loud, never silent — a
            # silently dropped pathway is exactly how this survived 88 days.
            _rejected = []
            for (src, dst), syn in brain.connections.items():
                fname = os.path.join(syn_dir, f"{src}__{dst}.npz")
                if os.path.exists(fname) and syn.nnz > 0:
                    loaded = sparse.load_npz(fname)
                    if loaded.nnz == 0:
                        _rejected.append(f"{src}>{dst} (empty on disk)")
                        continue
                    if loaded.shape != syn.weights.shape:
                        _rejected.append(f"{src}>{dst} (shape mismatch)")
                        continue
                    syn.weights = loaded
                    traces_path = os.path.join(syn_dir, f"{src}__{dst}_traces.npz")
                    if os.path.exists(traces_path):
                        traces = np.load(traces_path)
                        syn.pre_trace = traces["pre_trace"]
                        syn.post_trace = traces["post_trace"]
                        syn.modulation = float(traces["modulation"][0])
            if _rejected:
                print(f"[PERSIST] REJECTED {len(_rejected)} bad synapse file(s); "
                      f"kept freshly-wired matrices instead: {', '.join(_rejected)}")

            # Weights just came off disk saturated-or-not. Clamp total incoming
            # inter-region drive BEFORE the first tick. Saved state from any
            # build that ran the dead-wire bug has ~100% of its inter-region
            # weights pinned at STDP_W_MAX, which drives regions to 99% firing
            # within minutes once propagation actually works. Loading is the
            # only place we can catch it before it does damage.
            try:
                brain.normalize_inter_region_drive()
            except Exception as e:
                print(f"[PERSIST] inter-region drive normalization failed: {e}")

        # Restore region state
        reg_dir = os.path.join(path, "regions")
        if os.path.exists(reg_dir):
            for name, region in brain.regions.items():
                reg_path = os.path.join(reg_dir, f"{name}.json")
                if not os.path.exists(reg_path):
                    continue
                with open(reg_path, "r") as f:
                    reg_state = json.load(f)

                # Restore neuron state
                if "v" in reg_state:
                    v = np.array(reg_state["v"], dtype=np.float64)
                    if len(v) == region.n_neurons:
                        region.neurons.v = v
                if "u" in reg_state:
                    u = np.array(reg_state["u"], dtype=np.float64)
                    if len(u) == region.n_neurons:
                        region.neurons.u = u

                # Region-specific
                if name == "hippocampus" and "memory_buffer" in reg_state:
                    region.memory_buffer = [
                        np.array(m, dtype=bool) for m in reg_state["memory_buffer"]
                    ]
                    n = len(region.memory_buffer)
                    if "memory_labels" in reg_state:
                        labels = reg_state["memory_labels"]
                        region._memory_labels = list(labels) + [""] * max(0, n - len(labels))
                    else:
                        region._memory_labels = [""] * n
                    if "memory_strength" in reg_state:
                        strengths = reg_state["memory_strength"]
                        region._memory_strength = list(strengths) + [1.0] * max(0, n - len(strengths))
                    else:
                        region._memory_strength = [1.0] * n

                if name == "prefrontal_cortex" and "working_memory" in reg_state:
                    wm = np.array(reg_state["working_memory"], dtype=np.float32)
                    if len(wm) == region.n_neurons:
                        region.working_memory = wm

                if name == "anterior_cingulate" and "prediction" in reg_state:
                    pred = np.array(reg_state["prediction"], dtype=np.float32)
                    if len(pred) == region.n_neurons:
                        region.prediction = pred

                if name in ("parietal_association", "temporal_association") and \
                        "binding_strength" in reg_state:
                    bs = np.array(reg_state["binding_strength"], dtype=np.float64)
                    if len(bs) == region.n_neurons:
                        region.binding_strength = bs

                if name == "brainstem":
                    if "energy" in reg_state:
                        region.energy = reg_state["energy"]
                    if "arousal" in reg_state:
                        region.arousal = reg_state["arousal"]

        print(f"[PERSIST] Brain loaded (step {brain.step_count}, stage {brain.development_stage})")
        return True

    except Exception as e:
        print(f"[PERSIST] Load error: {e}")
        return False


def get_save_info(path=None):
    """Get info about saved brain state without loading it."""
    if path is None:
        path = SAVE_DIR
    meta_path = os.path.join(path, "meta.json")
    if not os.path.exists(meta_path):
        return None
    with open(meta_path, "r") as f:
        return json.load(f)
