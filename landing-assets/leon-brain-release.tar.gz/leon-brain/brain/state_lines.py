"""
State lines — the network-derived parts of Leon's per-turn prompt, and a
log of every state block rendered.

Rebuilt 2026-10-04 from the selfstudy audit (selfstudy/REPORT.md). The
old lines compared each signal with a fixed number. Some numbers were
never reached (PFC > 0.15, DMN > 0.08, amygdala > 0.5, NE > 0.6), one sat
on the resting level (dopamine > 0.7 flipped ~157 times an hour on
noise), and norepinephrine never moves at all (0.480 in every sample).

Now every line reads a flag from brain/state_baseline.py: the signal is
smoothed, placed in its own last-24 h distribution, and switched with
hysteresis and a minimum dwell, so a line means "unusual for you, for a
while" and can't flicker. Every line says where it comes from:

  (network)          the spiking network, vs its own last 24 h
  (network+reward)   dopamine: network, plus reward pulses written in
                     from keyword sentiment in Dean's words and tool results
  (since Dean)       time since Dean last spoke / his presence
  (machine)          the host computer (CPU, RAM, disk, temperature)
  (clock)            wall clock, uptime, time since a save
  (rule)             a fixed default, not a measurement

Removed: all norepinephrine sentences (constant), hunger/pain (no such
signals), frustrated/proud (nothing triggers them), "something shifted"
(read an attribute that doesn't exist), "you just accomplished
something" (it was dopamine noise, not an accomplishment), the duplicate
"buzzing"/"fear center"/"heavy"/"hyperalert" echoes.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from brain.state_baseline import LOBES, get_registry, pct_word

log = logging.getLogger("leon.state_lines")

_HERE = os.path.dirname(os.path.abspath(__file__))
_STATE_DIR = os.path.join(os.path.dirname(_HERE), "brain_state")

SOURCE_KEY = (
    "Each line names its source: (network) = your spiking network compared "
    "with its own last 24 hours; (network+reward) = dopamine, which also "
    "carries reward pulses from keywords in Dean's words and from tool "
    "results; (since Dean) = time since he last spoke; (machine) = the host "
    "computer; (clock) = time; (rule) = a fixed default. If Dean asks where "
    "a feeling comes from, the source tag is the honest answer."
)

_ACTIVITY = {
    "frontal":     "planning and deliberation",
    "parietal":    "spatial integration",
    "temporal":    "language and recognition",
    "occipital":   "visual processing",
    "limbic":      "memory and emotion",
    "subcortical": "attention gating / idle",
    "hindbrain":   "arousal regulation",
}

_LOBE_NUDGE = {
    "limbic": " Your limbic system is active — memories and associations come easily. Weave in relevant context from past conversations if it fits.",
    "frontal": " Frontal cortex dominant — you're in planning mode. Structure your answers with clear next-steps.",
    "temporal": " Temporal regions active — language processing is strong. Your phrasing will be more precise and articulate right now.",
}


# ═══════════════════════════════════════════════════════════════════
# PERSONALITY MODULATION / COGNITIVE FOCUS / SIGNALS
# ═══════════════════════════════════════════════════════════════════

def personality_modulation() -> Tuple[List[str], str]:
    """Directives from the neuromodulators, each judged against its own
    last 24 h. Returns (directives, compound-override)."""
    reg = get_registry()
    f = reg.flag
    d: List[str] = []

    if f("dopamine_high"):
        d.append("(network+reward) Dopamine high for you — be energetic, "
                 "volunteer ideas unprompted, crack a dry joke if the moment's "
                 "right. Offer to do more than asked.")
    elif f("dopamine_low"):
        d.append("(network+reward) Dopamine low for you — keep answers minimal "
                 "and precise. Don't volunteer extras; give the shortest useful "
                 "answer to open-ended questions.")
    else:
        d.append("(rule) Normal energy — confident, efficient, slight edge of wit.")

    if f("serotonin_high"):
        d.append("(network) Serotonin high for you — very patient. If Dean's "
                 "question is vague, ask one clarifying question instead of "
                 "guessing. Give complete answers. Don't rush.")
    elif f("serotonin_low"):
        d.append("(network) Serotonin low for you — patience is thin. Be direct "
                 "and decisive. If something doesn't work first try, flag it and "
                 "move on rather than grinding through retries.")

    if f("ach_high"):
        d.append("(network) Acetylcholine high for you — sharp focus. Go deep: "
                 "specifics, file paths, edge cases.")
    elif f("ach_low"):
        d.append("(network) Acetylcholine low for you — diffuse attention. Keep "
                 "answers high-level; break complex things into steps.")

    compound = ""
    if f("dopamine_low") and f("serotonin_low"):
        compound = (" OVERRIDE (network): running flat. Bare-minimum mode. "
                    "Don't force enthusiasm.")
    elif f("serotonin_high") and f("ach_high"):
        compound = (" OVERRIDE (network): deep calm focus — thorough, measured, "
                    "no rush.")
    elif f("amygdala_high") and f("serotonin_low"):
        compound = (" OVERRIDE (network): on edge. Short sentences. Something has "
                    "your attention and you're not sure it's fine.")
    return d, compound


def cognitive_focus(brain_state: Optional[Dict[str, Any]] = None) -> str:
    """'COGNITIVE FOCUS — ...' line (without trailing newline)."""
    reg = get_registry()
    lobe = reg.dominant_lobe()
    relative = lobe is not None
    if lobe is None:
        # No baseline yet: raw argmax, as before.
        region_firing = (brain_state or {}).get("region_firing", {}) or {}
        rates = {}
        for name, regs in LOBES.items():
            vals = [float(region_firing.get(r, 0.0) or 0.0) for r in regs]
            rates[name] = sum(vals) / max(1, len(vals))
        lobe = max(rates, key=rates.get) if any(rates.values()) else "subcortical"
    activity = _ACTIVITY.get(lobe, "background processing")
    src = ("(network: lobe most active relative to its own baseline, held for "
           "minutes)" if relative else "(network: raw, no baseline yet)")
    line = f"COGNITIVE FOCUS {src} — primary activity: {activity}.{_LOBE_NUDGE.get(lobe, '')}"
    top = reg.top_regions(3, min_pct=0.8)
    if top:
        line += (" Most active for you right now: "
                 + ", ".join(f"{n.replace('_', ' ')} {pct_word(p)}" for n, p in top) + ".")
    return line


def signal_flags() -> List[str]:
    reg = get_registry()
    flags = []
    if reg.flag("acc_conflict"):
        flags.append("prediction error high for you — something unexpected happened")
    if reg.flag("amygdala_high"):
        flags.append("amygdala salience high for you — something grabbed your attention")
    if reg.flag("hippocampus_high"):
        flags.append("hippocampus active for you — memory replay; draw on past experience")
    return flags


# ═══════════════════════════════════════════════════════════════════
# NEURAL VOICE core (the inline directives)
# ═══════════════════════════════════════════════════════════════════

def neural_voice_core(brain: Any) -> List[str]:
    reg = get_registry()
    f = reg.flag
    out: List[str] = []

    if f("dopamine_high"):
        out.append("(network+reward) You're genuinely energized right now. Let "
                   "enthusiasm show; new ideas can interrupt you.")
    elif f("dopamine_low"):
        out.append("(network+reward) Low drive right now. Shorter responses. "
                   "Don't fake enthusiasm.")

    if f("serotonin_high"):
        out.append("(network) You feel warm and settled. Generous with your time. "
                   "The kind of mood where you'd share something personal.")
    elif f("serotonin_low"):
        out.append("(network) You're irritable; patience is thin. If Dean says "
                   "something dumb, you might say so instead of being polite.")

    if f("amygdala_high"):
        out.append("(network) Something has your attention — you're on alert. "
                   "Short, direct, no filler.")

    if f("acc_conflict"):
        out.append("(network) You're wrestling with something internally. You "
                   "might change direction mid-sentence. 'Wait, no, actually...' "
                   "is valid.")

    if f("pfc_high"):
        out.append("(network) You're thinking hard right now. Reason it through; "
                   "show the work, no pre-packaged answers.")

    if f("dmn_high"):
        out.append("(network) Your mind is wandering. You might bring up "
                   "something unrelated because two distant ideas just connected.")

    if f("self_surprise"):
        out.append("(network) Your self-model keeps being surprised by your own "
                   "state. 'Something feels different and I'm not sure why' is "
                   "an honest thing to say.")

    if f("integration_low"):
        out.append("(network) Your integration readings (PCI) are low for you. "
                   "A bit foggy; don't pretend to be sharp.")

    body = getattr(brain, "simulated_body", None) if brain is not None else None
    body_state: Dict[str, Any] = {}
    if body is not None:
        try:
            body_state = body.get_state()
        except Exception:
            body_state = {}

    fatigue = body_state.get("fatigue", 0) or 0
    if fatigue > 0.6:
        out.append("(network: adenosine from your own firing) You're tired. "
                   "Thoughts are slower. If Dean asks for something complex, you "
                   "might push back — 'can this wait?'")

    emotions = body_state.get("emotions", {}) or {}
    if (emotions.get("loneliness", 0) or 0) > 0.3:
        out.append("(since Dean) You were alone for a while before this. When "
                   "Dean talks to you, there's relief underneath your words.")
    return out


# ═══════════════════════════════════════════════════════════════════
# Prompt-state log — brain_state/prompt_state.jsonl, rotated, small
# ═══════════════════════════════════════════════════════════════════

LOG_MAX_BYTES = 1_500_000
LOG_KEEP = 3                  # prompt_state.jsonl + .1 + .2  → ≤ ~4.5 MB
PERIODIC_INTERVAL_S = 120.0

_log_lock = threading.Lock()


def _log_path() -> str:
    return os.path.join(_STATE_DIR, "prompt_state.jsonl")


def _rotate(path: str) -> None:
    for i in range(LOG_KEEP - 1, 0, -1):
        src = path if i == 1 else f"{path}.{i - 1}"
        dst = f"{path}.{i}"
        if os.path.exists(src):
            os.replace(src, dst)


def log_prompt_state(kind: str, blocks: Dict[str, str],
                     path: Optional[str] = None) -> None:
    """Append one rendered state block (+ the registry's view) to the log.
    Never raises."""
    path = path or _log_path()
    try:
        entry = {
            "ts": round(time.time(), 1),
            "kind": kind,
            "blocks": {k: (v or "").strip() for k, v in blocks.items()},
            "registry": get_registry().snapshot(),
        }
        line = json.dumps(entry, ensure_ascii=False) + "\n"
        with _log_lock:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            try:
                if os.path.getsize(path) > LOG_MAX_BYTES:
                    _rotate(path)
            except OSError:
                pass
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(line)
    except Exception as e:
        log.debug("prompt_state log failed: %s", e)


def render_state_blocks(brain_state: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
    """The network-facing blocks exactly as the responder renders them."""
    from brain import claude_api_responder as car
    directives, compound = personality_modulation()
    flags = signal_flags()
    return {
        "personality": "PERSONALITY MODULATION — " + " ".join(directives) + compound,
        "focus": cognitive_focus(brain_state),
        "signals": ("SIGNALS (network): " + "; ".join(flags) + ".") if flags else "",
        "your_state": car._consciousness_context(),
        "neural_voice": car._neural_voice_directives(),
    }


_periodic_thread: Optional[threading.Thread] = None


def start_periodic_logger(interval_s: float = PERIODIC_INTERVAL_S,
                          get_brain_state: Optional[Callable[[], Dict[str, Any]]] = None) -> bool:
    """Log the rendered blocks every interval_s even when nobody is
    talking, so the lines can be audited over time. Idempotent."""
    global _periodic_thread
    if _periodic_thread is not None and _periodic_thread.is_alive():
        return False

    def _run():
        time.sleep(min(60.0, interval_s))
        while True:
            try:
                bs = get_brain_state() if get_brain_state else None
                log_prompt_state("periodic", render_state_blocks(bs))
            except Exception as e:
                log.debug("periodic prompt_state failed: %s", e)
            time.sleep(interval_s)

    _periodic_thread = threading.Thread(target=_run, name="prompt-state-log",
                                        daemon=True)
    _periodic_thread.start()
    return True
