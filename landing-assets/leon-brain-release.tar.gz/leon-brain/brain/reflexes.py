"""
Leon Reflexes — instant motor commands that bypass Claude entirely.

Simple PC control requests (volume, mute, brightness, lock) don't need
AI reasoning. They're reflexes: hear the command, fire the actuator,
report back. No LLM call, no tool selection, no shell commands.

This runs BEFORE the message reaches Claude. If a reflex matches,
it executes immediately and returns the response text. If nothing
matches, returns None and the normal Claude path continues.

Uses the actuator bridge (works from VPS via PC relay).
"""

from __future__ import annotations
import re
from typing import Optional


_last_reflex: Optional[tuple] = None  # (handler, text, match) — for "more"/"again"
_procedural_router = None  # explicit integrator cutover; legacy remains default
# Context follow-ups ("more"/"again"); shared by try_reflex and would_reflex.
_FOLLOW_UP_RE = r'^(?:more|again|keep going|do it again|one more|repeat|same|yes|yep|yea|yeah)[\s!.]*$'


def configure_procedural_router(router=None) -> None:
    """Install the shared router after parity/gate approval; None rolls back.

    Keep the same instance in command_spotter and final-STT consumers. Shadow
    predicts only, then legacy still executes exactly once. ON never falls
    back to this module's ungated learned action path after a router failure.
    """
    global _procedural_router
    _procedural_router = router


def try_reflex(user_text: str, *, trace_id=None, utterance_id=None) -> Optional[str]:
    """Try to handle this as a reflex action. Returns response text or None."""
    global _last_reflex
    router = _procedural_router
    if router is not None and router.mode != "off":
        import uuid
        trace_id = trace_id or uuid.uuid4().hex
        utterance_id = utterance_id or trace_id
        try:
            router.refresh_sources()  # new promotions import without rewriting their store
            result = router.route(user_text, trace_id=trace_id, utterance_id=utterance_id)
        except Exception:
            if router.mode == "on":
                # Receipt/storage failure may follow a dispatched action. Do
                # not ask a second execution path to repeat an uncertain turn.
                return "I couldn't safely finish that action; its execution status needs checking."
        else:
            if router.mode == "on":
                if result and result.get("executed"):
                    return result.get("response") or "That action is already in progress."
                return None
    text = (user_text or "").strip().lower()
    if not text:
        return None

    # Skip reflexes on long messages — those are conversations, dictations,
    # or emails, not motor commands. A volume command is never 80+ chars.
    if len(text) > 80:
        return None

    # Context follow-ups: "more", "again", "keep going", "do it again"
    if _last_reflex and re.match(_FOLLOW_UP_RE, text):
        handler, prev_text, prev_match = _last_reflex
        try:
            return handler(prev_text, prev_match)
        except Exception as e:
            return f"Tried again but failed: {e}"

    # Check learned reflexes (patterns Leon discovered through experience)
    try:
        from brain.reflex_learning import try_learned_reflex
        learned = try_learned_reflex(user_text)
        if learned is not None:
            return learned
    except Exception:
        pass

    for pattern, handler in _REFLEXES:
        m = re.search(pattern, text)
        if m:
            try:
                result = handler(text, m)
                _last_reflex = (handler, text, m)
                return result
            except Exception as e:
                return f"Tried but failed: {e}"
    return None


def would_reflex(user_text: str) -> bool:
    """Pure predicate: would try_reflex act on this text?

    Mirrors try_reflex's matching and executes nothing: no handler, no
    actuator call, no learned-reflex dispatch, no procedural route. Where the
    answer cannot be known without executing (the procedural router owns the
    turn in ON mode) it answers True, the conservative side for callers that
    use it to keep a turn on the tool-capable path.
    """
    router = _procedural_router
    if router is not None and getattr(router, "mode", "on") == "on":
        return True
    text = (user_text or "").strip().lower()
    if not text or len(text) > 80:
        return False
    if _last_reflex and re.match(_FOLLOW_UP_RE, text):
        return True
    try:
        from brain.reflex_learning import matches_learned_reflex
        if matches_learned_reflex(user_text):
            return True
    except Exception:
        return True
    return any(re.search(pattern, text) for pattern, _ in _REFLEXES)


# ── Actuator helpers ──────────────────────────────────────────────────

def _hotkey(combo: str) -> dict:
    from brain.actuator_client import call
    return call("keyboard.hotkey", {"combo": combo})


def _notify(msg: str) -> None:
    try:
        from brain.actuator_client import call
        call("notify", {"title": "Leon", "body": msg})
    except Exception:
        pass


# ── Reflex handlers ──────────────────────────────────────────────────

def _volume_down(text, match):
    """Lower volume via PC relay volume.adjust tool."""
    amount = _extract_number(text, default=5)
    from brain.actuator_client import call
    result = call("volume.adjust", {"delta": -amount})
    if not result.get("ok"):
        return f"Couldn't lower volume: {result.get('error', 'unknown')}"
    from server.helpers import broadcast_activity
    broadcast_activity("tool", f"✓ Volume lowered by {amount}%", 5000)
    return f"Done — lowered volume by {amount}%."


def _volume_up(text, match):
    amount = _extract_number(text, default=5)
    from brain.actuator_client import call
    result = call("volume.adjust", {"delta": amount})
    if not result.get("ok"):
        return f"Couldn't raise volume: {result.get('error', 'unknown')}"
    from server.helpers import broadcast_activity
    broadcast_activity("tool", f"✓ Volume raised by {amount}%", 5000)
    return f"Done — raised volume by {amount}%."


def _volume_mute(text, match):
    from brain.actuator_client import call
    result = call("volume.mute", {})
    if not result.get("ok"):
        return f"Couldn't toggle mute: {result.get('error', 'unknown')}"
    from server.helpers import broadcast_activity
    broadcast_activity("tool", "✓ Mute toggled", 5000)
    return "Toggled mute."


def _volume_max(text, match):
    from brain.actuator_client import call
    result = call("volume.set", {"percent": 100})
    if not result.get("ok"):
        return f"Couldn't set volume: {result.get('error', 'unknown')}"
    from server.helpers import broadcast_activity
    broadcast_activity("tool", "✓ Volume maxed (100%)", 5000)
    return "Volume maxed out at 100%."


def _volume_min(text, match):
    from brain.actuator_client import call
    result = call("volume.set", {"percent": 0})
    if not result.get("ok"):
        return f"Couldn't set volume: {result.get('error', 'unknown')}"
    from server.helpers import broadcast_activity
    broadcast_activity("tool", "✓ Volume set to 0%", 5000)
    return "Volume set to 0%."


def _volume_set(text, match):
    """Set volume to a specific percentage."""
    target = int(match.group(1))
    from brain.actuator_client import call
    result = call("volume.set", {"percent": target})
    if not result.get("ok"):
        return f"Couldn't set volume: {result.get('error', 'unknown')}"
    from server.helpers import broadcast_activity
    broadcast_activity("tool", f"✓ Volume set to {target}%", 5000)
    return f"Volume set to {target}%."


def _play_pause(text, match):
    result = _hotkey("XF86AudioPlay")
    if not result.get("ok"):
        return f"Couldn't toggle play/pause: {result.get('error', 'unknown')}"
    return "Toggled play/pause."


def _next_track(text, match):
    result = _hotkey("XF86AudioNext")
    return "Skipped to next track." if result.get("ok") else f"Failed: {result.get('error')}"


def _prev_track(text, match):
    result = _hotkey("XF86AudioPrev")
    return "Went to previous track." if result.get("ok") else f"Failed: {result.get('error')}"


def _lock_screen(text, match):
    result = _hotkey("super+l")
    return "Screen locked." if result.get("ok") else f"Failed: {result.get('error')}"


def _screenshot(text, match):
    from brain.actuator_client import call
    result = call("screen.capture", {})
    if result.get("ok"):
        from server.helpers import broadcast_activity
        broadcast_activity("tool", "✓ Screenshot taken", 5000)
        return "Screenshot captured."
    return f"Screenshot failed: {result.get('error')}"


# ── Utility ───────────────────────────────────────────────────────────

def _extract_number(text: str, default: int = 5) -> int:
    """Pull a number from text like 'by 5' or 'turn down 10'."""
    m = re.search(r'\b(\d{1,3})\b', text)
    if m:
        return min(int(m.group(1)), 100)
    # Word numbers
    words = {"one": 1, "two": 2, "three": 3, "five": 5, "ten": 10, "twenty": 20}
    for w, n in words.items():
        if w in text:
            return n
    return default


# ── Pattern → handler mapping ─────────────────────────────────────────
# Order matters — first match wins. More specific patterns first.

_REFLEXES = [
    # Volume — handle all natural orderings: "turn down volume", "volume down",
    # "lower the volume", "turn my volume down", etc.
    # Max/min shortcuts
    (r"(?:max|full|maximum).*(?:volume|sound|audio)", _volume_max),
    (r"(?:volume|sound|audio).*(?:max|full|maximum)", _volume_max),
    (r"(?:volume|sound|audio).*(?:min|minimum|zero|off)", _volume_min),
    # Set to specific %
    (r"(?:set|change).*volume.*?(\d{1,3})\s*%?", _volume_set),
    (r"volume.*?(\d{1,3})\s*%", _volume_set),
    (r"(?:turn|go|bring)\s.*down.*(?:volume|sound|audio)", _volume_down),
    (r"(?:turn|go|bring)\s.*(?:volume|sound|audio).*down", _volume_down),
    (r"(?:turn|go|bring)\s+it\s+down", _volume_down),
    (r"(?:lower|reduce|decrease)\s.*(?:volume|sound|audio)", _volume_down),
    (r"(?:volume|sound|audio)\s.*(?:down|lower|reduce|decrease)", _volume_down),
    (r"^(?:quieter|softer)[\s!.]*$", _volume_down),
    (r"(?:turn|go|bring|crank|raise)\s.*up.*(?:volume|sound|audio)", _volume_up),
    (r"(?:turn|go|bring|crank|raise)\s.*(?:volume|sound|audio).*up", _volume_up),
    (r"(?:turn|raise)\s+it\s+up", _volume_up),
    (r"(?:raise|increase)\s.*(?:volume|sound|audio)", _volume_up),
    (r"(?:volume|sound|audio)\s.*(?:up|higher|increase|raise)", _volume_up),
    (r"^(?:louder)[\s!.]*$", _volume_up),
    (r"(?:^|\s)(?:un)?mute(?:\s|$|\.)", _volume_mute),
    # Media
    (r"(?:play|pause|resume).*(?:music|song|track|media|spotify)", _play_pause),
    (r"(?:next|skip).*(?:song|track)", _next_track),
    (r"(?:previous|prev|back|last).*(?:song|track)", _prev_track),
    # System
    (r"lock.*(?:screen|computer|pc)", _lock_screen),
    (r"(?:take|grab).*screenshot", _screenshot),
]
