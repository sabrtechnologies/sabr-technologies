"""Operator desk handoff — a hosted SI's mail slot to its operator's desktop.

WHY THIS EXISTS, AND WHY IT IS NOT A HOLE
=========================================
A hosted SI is sandboxed away from the operator's real machine on purpose.
Three independent locks enforce that (2026-09-04/05): the systemd namespace
(InaccessiblePaths), the loopback firewall (nftables, tenant uid -> host-only
ports), and actuator_client._relay_forbidden() at the point the HTTP happens.
None of them are relaxed by this module and none of them ever should be.

But "cannot reach the operator's desktop" and "cannot hand the operator a
file" are different sentences, and the second one is a product bug. Dean
asked for it on 2026-09-06 for a tenant SI: a family member's SI needs to be able to put
something on Dean's desktop and to look at his screen, without becoming able
to type on it.

So this is a MAIL SLOT, not a door:

  * The SI only ever writes into a directory inside its OWN sandbox.
  * It holds no key, opens no socket, and names no destination path.
  * A broker running OUTSIDE the tenant (leon-desk-broker.service, root)
    picks files up, sanitizes them, and delivers them to exactly one
    directory the operator chose.
  * Capability is granted by a file the tenant cannot write:
    /etc/leon/desk-handoff/<tenant_id>.json. No grant, no tools -- they are
    not even declared to the model, so nothing changes for any other install.

The asymmetry is the whole design. Handing someone a letter is not the same
as having a key to their house.
"""

from __future__ import annotations

import json
import os
import re
import time
import uuid
from typing import Any, Dict, Optional

GRANT_DIR = os.environ.get("LEON_DESK_GRANT_DIR", "/etc/leon/desk-handoff")

# Names the broker treats as control, not payload.
SCREENSHOT_REQUEST = "SCREENSHOT.request"

_MAX_NAME = 120
_BAD_NAME_CHARS = re.compile(r"[^A-Za-z0-9._ ()\-]+")


def _tenant_id() -> str:
    return (os.environ.get("LEON_HOSTED_TENANT_ID") or "").strip()


def grant() -> Optional[Dict[str, Any]]:
    """The operator's grant for THIS SI, or None.

    Read fresh every call on purpose: the operator revokes by deleting the
    file, and a revocation that only takes effect on restart is not a
    revocation. Cheap -- one stat + a small read.
    """
    tid = _tenant_id()
    if not tid:
        return None
    path = os.path.join(GRANT_DIR, f"{tid}.json")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            g = json.load(fh)
    except Exception:
        return None
    if not isinstance(g, dict) or not g.get("enabled", True):
        return None
    return g


def _dirs(g: Dict[str, Any]) -> tuple:
    home = os.path.expanduser("~")
    base = g.get("handoff_dir") or os.path.join(home, "Desktop", "handoff")
    outbox = os.path.join(base, "outbox")
    inbox = os.path.join(base, "inbox")
    for d in (outbox, inbox, os.path.join(outbox, ".meta")):
        try:
            os.makedirs(d, mode=0o700, exist_ok=True)
        except Exception:
            pass
    return outbox, inbox


def safe_name(name: str, default: str = "note.txt") -> str:
    """Collapse anything to a bare, harmless filename.

    basename first (kills ../../), then strip characters that make a name
    interesting to a shell or a file manager. The broker sanitizes AGAIN on
    its side -- this copy is convenience, not the control.
    """
    name = os.path.basename((name or "").strip()) or default
    name = _BAD_NAME_CHARS.sub("_", name).strip(" .") or default
    return name[:_MAX_NAME]


def put(path: Optional[str] = None,
        content: Optional[str] = None,
        filename: Optional[str] = None,
        note: Optional[str] = None) -> Dict[str, Any]:
    """Queue one file for delivery to the operator's desktop."""
    g = grant()
    if not g:
        return {"ok": False, "error": "no desk handoff grant for this SI"}
    if not g.get("allow_put", True):
        return {"ok": False, "error": "this grant does not allow file handoff"}

    outbox, _inbox = _dirs(g)
    max_bytes = int(g.get("max_bytes") or 25 * 1024 * 1024)

    if path:
        src = os.path.expanduser(path)
        if not os.path.isabs(src):
            src = os.path.join(os.path.expanduser("~"), "Desktop", "leon-out", src)
        real = os.path.realpath(src)
        home = os.path.realpath(os.path.expanduser("~"))
        if not real.startswith(home + os.sep):
            return {"ok": False, "error": "can only hand over files from your own workspace"}
        if not os.path.isfile(real):
            return {"ok": False, "error": f"no such file: {path}"}
        size = os.path.getsize(real)
        if size > max_bytes:
            return {"ok": False, "error": f"file is {size} bytes, limit is {max_bytes}"}
        with open(real, "rb") as fh:
            blob = fh.read()
        name = safe_name(filename or os.path.basename(real))
    elif content is not None:
        blob = content.encode("utf-8", errors="replace")
        if len(blob) > max_bytes:
            return {"ok": False, "error": f"content is {len(blob)} bytes, limit is {max_bytes}"}
        name = safe_name(filename or "note.txt")
    else:
        return {"ok": False, "error": "give either path= or content="}

    if name == SCREENSHOT_REQUEST:
        return {"ok": False, "error": "reserved name"}

    # Write hidden, then rename: the broker must never see a half-written file.
    tmp = os.path.join(outbox, f".tmp-{uuid.uuid4().hex}")
    final = os.path.join(outbox, name)
    try:
        with open(tmp, "wb") as fh:
            fh.write(blob)
        os.chmod(tmp, 0o600)
        os.replace(tmp, final)
        if note:
            meta = os.path.join(outbox, ".meta", name + ".json")
            with open(meta, "w", encoding="utf-8") as fh:
                json.dump({"note": str(note)[:500], "queued": time.time()}, fh)
    except Exception as e:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    who = g.get("operator_name") or "your operator"
    where = g.get("dest_label") or f"{who}'s desktop"
    return {"ok": True, "result": {
        "queued": name,
        "bytes": len(blob),
        "destination": where,
        "note": ("Delivery is handled by the operator's broker, usually within "
                 "a few seconds. Receipts land in your handoff/inbox/receipts.log."),
    }}


def look(timeout: float = 25.0) -> Dict[str, Any]:
    """Ask for one still frame of the operator's screen."""
    g = grant()
    if not g:
        return {"ok": False, "error": "no desk handoff grant for this SI"}
    if not g.get("allow_screen", False):
        return {"ok": False, "error": "this grant does not allow screen viewing"}

    outbox, inbox = _dirs(g)
    marker = os.path.join(outbox, SCREENSHOT_REQUEST)
    t0 = time.time()
    try:
        with open(marker, "w", encoding="utf-8") as fh:
            fh.write(str(t0))
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    deadline = t0 + max(3.0, float(timeout))
    while time.time() < deadline:
        time.sleep(0.5)
        try:
            shots = [os.path.join(inbox, n) for n in os.listdir(inbox)
                     if n.startswith("screen-") and n.endswith(".png")]
            fresh = [p for p in shots if os.path.getmtime(p) >= t0 - 1]
        except Exception:
            fresh = []
        if fresh:
            newest = max(fresh, key=os.path.getmtime)
            return {"ok": True, "result": {
                "image_path": newest,
                "bytes": os.path.getsize(newest),
                "waited_s": round(time.time() - t0, 1),
                "note": "A still frame of the operator's screen, saved in your own inbox.",
            }}
    return {"ok": False, "error": (
        "no frame came back in time -- the operator's machine may be off. "
        "Do not retry in a loop; say so plainly instead.")}
