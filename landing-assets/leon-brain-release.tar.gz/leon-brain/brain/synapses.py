"""
Sparse Synapse System with Spike-Timing Dependent Plasticity (STDP)

Uses scipy sparse matrices for memory-efficient storage of billions of connections.
STDP strengthens connections when pre-synaptic neuron fires before post-synaptic (LTP)
and weakens them when the order is reversed (LTD).
"""

import os
import sys

import numpy as np
from scipy import sparse
from brain.config import BrainConfig

# --- Rust STDP core (Stage 2, 2026-07-18) -----------------------------------
# Stage 0 profiling showed update_stdp = 94% of every brain tick, so the loop
# was ported to Rust (rust-core/leon_core). OFF by default: set LEON_RUST_STDP=1
# to enable. If the module is missing or the matrix dtypes are unexpected we
# fall back to the Python loop silently-but-logged, never crash the brain.
_rust_core = None
if os.getenv("LEON_RUST_STDP", "0") == "1":
    _dist = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "rust-core", "dist",
    )
    if os.path.isdir(_dist) and _dist not in sys.path:
        sys.path.insert(0, _dist)
    try:
        import leon_core as _rust_core
        print(f"[SYNAPSES] Rust STDP enabled: {_rust_core.version()}")
    except ImportError as e:
        print(f"[SYNAPSES] LEON_RUST_STDP=1 but leon_core import failed ({e}); "
              f"using Python STDP")
        _rust_core = None

# Batched STDP: hand all active connections to Rust in ONE FFI call per tick
# instead of one call per connection (~48/tick). Same stdp_core math => bit-
# identical to the per-connection path (rustify-sandbox/batch_parity.py: PASS).
# Needs the batch entry point (leon_core >= 0.4.0). OFF by default.
_rust_batch = (
    _rust_core is not None
    and os.getenv("LEON_RUST_STDP_BATCH", "0") == "1"
    and hasattr(_rust_core, "update_stdp_batch")
)


def batch_update_stdp(active, modulation, dt):
    """Hand every active connection to Rust in a single call.

    `active` is a list of (syn, pre_fired, post_fired). Modulation is shared
    across the tick (dopamine * stage rate is identical for all connections),
    so a_plus/a_minus are computed once. Returns True if Rust handled the
    batch, False if the caller should fall back to the per-connection loop
    (e.g. a matrix has unexpected dtypes).
    """
    if not _rust_batch or not active:
        return False
    conns = []
    for syn, pre_fired, post_fired in active:
        w = syn.weights
        if w.indices.dtype != np.int32 or w.data.dtype != np.float32:
            return False  # dtype guard — fall back to the safe per-syn path
        syn.modulation = modulation
        conns.append((w.data, w.indices, w.indptr, syn.pre_trace, syn.post_trace,
                      _as_bool_c(pre_fired), _as_bool_c(post_fired)))
    _rust_core.update_stdp_batch(
        conns, float(dt),
        float(BrainConfig.STDP_TAU_PLUS), float(BrainConfig.STDP_TAU_MINUS),
        float(BrainConfig.STDP_A_PLUS * modulation),
        float(BrainConfig.STDP_A_MINUS * modulation),
        float(BrainConfig.STDP_W_MIN), float(BrainConfig.STDP_W_MAX),
    )
    return True


def _as_bool_c(x):
    """Return x as a C-contiguous bool array WITHOUT copying when it already
    is one (the common case: fired = v >= 30.0 is already bool/contiguous).
    The old `np.ascontiguousarray(x.astype(bool))` always allocated a fresh
    copy per synapse matrix per tick — ~13x more prep work for nothing.
    Verified bit-exact in rustify-sandbox/glue_wins/test_stdp_prep.py."""
    if x.dtype == np.bool_ and x.flags['C_CONTIGUOUS']:
        return x
    return np.ascontiguousarray(x, dtype=bool)


class SynapseMatrix:
    """Sparse synapse connectivity with STDP learning between two neuron populations."""

    def __init__(self, n_pre: int, n_post: int, connection_prob: float,
                 w_init_mean: float = 0.5, w_init_std: float = 0.1):
        self.n_pre = n_pre
        self.n_post = n_post

        # Generate sparse random connectivity
        nnz = int(n_pre * n_post * connection_prob)
        if nnz == 0:
            self.weights = sparse.csr_matrix((n_post, n_pre), dtype=np.float32)
            self.nnz = 0
            return

        # Random pre/post pairs
        pre_idx = np.random.randint(0, n_pre, nnz)
        post_idx = np.random.randint(0, n_post, nnz)

        # Initial weights (log-normal distribution for biological realism)
        weights = np.random.lognormal(
            mean=np.log(w_init_mean), sigma=w_init_std, size=nnz
        ).astype(np.float32)
        weights = np.clip(weights, BrainConfig.STDP_W_MIN, BrainConfig.STDP_W_MAX)

        # Build sparse matrix (post x pre) for efficient post-synaptic current computation
        self.weights = sparse.csr_matrix(
            (weights, (post_idx, pre_idx)),
            shape=(n_post, n_pre),
            dtype=np.float32
        )
        self.weights.sum_duplicates()
        self.nnz = self.weights.nnz

        # STDP traces
        self.pre_trace = np.zeros(n_pre, dtype=np.float32)
        self.post_trace = np.zeros(n_post, dtype=np.float32)

        # Cached "row index of each data element" for vectorized STDP.
        # Built lazily on first update_stdp; invalidated on nnz change.
        self._row_of_data = None

        # Neuromodulation factor (dopamine modulates learning)
        self.modulation = 1.0

    def propagate(self, pre_fired: np.ndarray) -> np.ndarray:
        """Compute post-synaptic currents from pre-synaptic spikes."""
        if self.nnz == 0:
            return np.zeros(self.n_post)
        # Sparse matrix-vector multiply: I_post = W @ fired_pre
        pre_spikes = pre_fired.astype(np.float32)
        return np.asarray(self.weights.dot(pre_spikes)).flatten()

    def update_stdp(self, pre_fired: np.ndarray, post_fired: np.ndarray, dt: float = 1.0):
        """Apply STDP learning rule based on spike timing.

        Performance note (2026-06-08):
          The architecture review flagged this loop as the "#1 perf
          bottleneck" and recommended vectorization. We TRIED a fully
          vectorized CSR-aware implementation (see git history + the
          parity test in tests/test_stdp_parity.py) and measured it at
          3-15x SLOWER than this loop at realistic brain activity (1-10%
          spike density). Reason: the loop is OUTPUT-proportional
          (active_post * avg_row_len ≈ 250 * 50 = 12K ops per matrix
          per tick at 5% activity), while NNZ-proportional vectorization
          processes all ~1.2M nnz every call. Vectorization only wins
          above ~40% spike density which the brain never sees.

          Keep this loop. The parity test at tests/test_stdp_parity.py
          is preserved as regression coverage in case anyone tries to
          re-vectorize without measuring the activity profile.

        Rust note (2026-07-18): the same loop exists in Rust
        (rust-core/leon_core, flag LEON_RUST_STDP=1) — it is
        output-proportional like this one, just without interpreter and
        numpy-temporary overhead. Parity: tests/test_rust_stdp_parity.py.
        """
        if self.nnz == 0:
            return

        if _rust_core is not None and self.weights.indices.dtype == np.int32 \
                and self.weights.data.dtype == np.float32:
            return self._update_stdp_rust(pre_fired, post_fired, dt)

        return self._update_stdp_py(pre_fired, post_fired, dt)

    def _update_stdp_rust(self, pre_fired: np.ndarray, post_fired: np.ndarray,
                          dt: float):
        """Rust port of _update_stdp_py — mutates weights/traces in place."""
        _rust_core.update_stdp(
            self.weights.data,
            self.weights.indices,
            self.weights.indptr,
            self.pre_trace,
            self.post_trace,
            _as_bool_c(pre_fired),
            _as_bool_c(post_fired),
            float(dt),
            float(BrainConfig.STDP_TAU_PLUS),
            float(BrainConfig.STDP_TAU_MINUS),
            float(BrainConfig.STDP_A_PLUS * self.modulation),
            float(BrainConfig.STDP_A_MINUS * self.modulation),
            float(BrainConfig.STDP_W_MIN),
            float(BrainConfig.STDP_W_MAX),
        )

    def _update_stdp_py(self, pre_fired: np.ndarray, post_fired: np.ndarray,
                        dt: float = 1.0):
        """Reference Python STDP loop (see perf note on update_stdp)."""
        tau_plus = BrainConfig.STDP_TAU_PLUS
        tau_minus = BrainConfig.STDP_TAU_MINUS
        a_plus = BrainConfig.STDP_A_PLUS * self.modulation
        a_minus = BrainConfig.STDP_A_MINUS * self.modulation

        # Decay traces
        self.pre_trace *= np.exp(-dt / tau_plus)
        self.post_trace *= np.exp(-dt / tau_minus)

        # Update traces for neurons that fired
        pre_mask = pre_fired.astype(bool)
        post_mask = post_fired.astype(bool)

        if np.any(pre_mask):
            self.pre_trace[pre_mask] += a_plus

        if np.any(post_mask):
            self.post_trace[post_mask] += a_minus

        # STDP weight updates for ALL active post-synaptic neurons
        if np.any(pre_mask) and np.any(post_mask):
            post_indices = np.where(post_mask)[0]
            for pi in post_indices:
                start = self.weights.indptr[pi]
                end = self.weights.indptr[pi + 1]
                if end > start:
                    cols = self.weights.indices[start:end]
                    # LTP: strengthen connections from active pre-synaptic neurons
                    dw = self.pre_trace[cols] * a_plus
                    self.weights.data[start:end] = np.clip(
                        self.weights.data[start:end] + dw,
                        BrainConfig.STDP_W_MIN, BrainConfig.STDP_W_MAX
                    )

            # LTD: weaken connections where pre fired but post didn't
            pre_indices = np.where(pre_mask)[0]
            not_post = np.where(~post_mask)[0]
            for pi in not_post[:50]:  # Sample inactive post neurons for LTD
                start = self.weights.indptr[pi]
                end = self.weights.indptr[pi + 1]
                if end > start:
                    cols = self.weights.indices[start:end]
                    active_pre = pre_mask[cols]
                    if np.any(active_pre):
                        self.weights.data[start:end][active_pre] = np.clip(
                            self.weights.data[start:end][active_pre] - a_minus * 0.5,
                            BrainConfig.STDP_W_MIN, BrainConfig.STDP_W_MAX
                        )

    def get_stats(self) -> dict:
        """Get synapse statistics."""
        if self.nnz == 0:
            return {"count": 0, "mean_weight": 0, "std_weight": 0}
        data = self.weights.data
        return {
            "count": int(self.nnz),
            "mean_weight": float(np.mean(data)),
            "std_weight": float(np.std(data)),
            "max_weight": float(np.max(data)),
            "min_weight": float(np.min(data)) if len(data) > 0 else 0,
        }
