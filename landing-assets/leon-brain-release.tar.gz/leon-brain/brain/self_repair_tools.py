"""
Self-Repair — Leon diagnoses and fixes broken tools autonomously.

When a tool fails, Leon doesn't just record it — he tries to understand
WHY and fix it. Common failure modes and their fixes:

  - Missing credential → tell Dean which key to add
  - Wrong environment (VPS vs PC) → route through relay
  - Stale socket/connection → restart the relevant daemon
  - Missing dependency → suggest install command
  - Permission denied → suggest chmod/chown

Runs on-demand when failures are detected, and periodically during idle.
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_REPAIR_LOG = _STATE_DIR / "repair_log.json"


def diagnose(tool: str, error: str) -> dict:
    """Analyze a tool failure and return diagnosis + suggested fix."""
    error_lower = error.lower()
    diagnosis = {
        "tool": tool,
        "error": error[:200],
        "diagnosed_at": time.time(),
        "cause": "unknown",
        "fix": None,
        "auto_fixable": False,
    }

    if "connection refused" in error_lower:
        if "pulse" in error_lower or "audio" in error_lower:
            diagnosis["cause"] = "PulseAudio/PipeWire not reachable (VPS has no audio)"
            diagnosis["fix"] = "Use actuator relay (volume.adjust) instead of shell pactl"
            diagnosis["auto_fixable"] = True
        elif "actuator" in error_lower:
            diagnosis["cause"] = "Actuator daemon not running on PC"
            diagnosis["fix"] = "Start actuator: cd leon-actuator && python3 actuator.py &"
        elif "9100" in error_lower or "relay" in error_lower:
            diagnosis["cause"] = "PC relay not running"
            diagnosis["fix"] = "Start relay: cd leon-actuator && python3 pc_relay.py &"
        else:
            diagnosis["cause"] = "Service not running or not reachable"

    elif "command not found" in error_lower or "no such file" in error_lower:
        cmd = re.search(r'(\w+): command not found', error_lower)
        if cmd:
            diagnosis["cause"] = f"Missing command: {cmd.group(1)}"
            diagnosis["fix"] = f"Install: sudo apt install {cmd.group(1)}"

    elif "permission denied" in error_lower:
        diagnosis["cause"] = "Permission denied"
        diagnosis["fix"] = "Check file permissions or run with appropriate user"

    elif "no display" in error_lower or "cannot open display" in error_lower:
        diagnosis["cause"] = "No X11 display available (running on VPS)"
        diagnosis["fix"] = "Use actuator tools instead of direct X11 commands"
        diagnosis["auto_fixable"] = True

    elif any(kw in error_lower for kw in ["api key", "unauthorized", "403", "401",
                                           "invalid token", "missing token"]):
        diagnosis["cause"] = "Missing or invalid API credential"
        diagnosis["fix"] = f"Add the API key for {tool.split('.')[0]} to .env"

    elif "timeout" in error_lower:
        diagnosis["cause"] = "Tool timed out"
        diagnosis["fix"] = "Retry with longer timeout or check network"

    elif "socket missing" in error_lower or "socket refused" in error_lower:
        diagnosis["cause"] = "Unix socket not available"
        diagnosis["fix"] = "Restart the relevant daemon or clean stale socket"
        diagnosis["auto_fixable"] = True

    return diagnosis


def attempt_auto_fix(diagnosis: dict) -> dict:
    """Try to automatically fix a diagnosed issue."""
    cause = diagnosis.get("cause", "")
    result = {"attempted": False, "success": False, "action": ""}

    if not diagnosis.get("auto_fixable"):
        return result

    if "PulseAudio" in cause or "no audio" in cause.lower():
        result = {"attempted": True, "success": True,
                  "action": "Routing audio through PC relay instead of local shell"}

    if "No X11" in cause:
        result = {"attempted": True, "success": True,
                  "action": "Using actuator bridge instead of direct X11"}

    if "socket" in cause.lower():
        try:
            from brain.actuator_client import _call_relay
            test = _call_relay("window.list", {}, 3.0)
            result = {"attempted": True, "success": test.get("ok", False),
                      "action": "Switched to HTTP relay after socket failure"}
        except Exception as e:
            result = {"attempted": True, "success": False,
                      "action": f"Relay fallback failed: {e}"}

    _log_repair(diagnosis, result)
    return result


def _log_repair(diagnosis: dict, result: dict) -> None:
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        log = json.loads(_REPAIR_LOG.read_text(encoding="utf-8"))
    except Exception:
        log = []
    log.append({
        "ts": time.time(),
        "tool": diagnosis.get("tool"),
        "cause": diagnosis.get("cause"),
        "fix_attempted": result.get("attempted"),
        "fix_success": result.get("success"),
        "action": result.get("action"),
    })
    if len(log) > 200:
        log = log[-200:]
    _REPAIR_LOG.write_text(json.dumps(log, indent=2), encoding="utf-8")

    if result.get("attempted"):
        try:
            from server.helpers import broadcast_activity
            status = "✓ fixed" if result["success"] else "✗ couldn't fix"
            broadcast_activity("inner",
                f"Self-repair: {diagnosis['tool']} — {status}: {result['action'][:60]}",
                10000)
        except Exception:
            pass


def repair_check() -> List[dict]:
    """Check all known failures and attempt repairs."""
    results = []
    try:
        from brain.failure_memory import _load as load_failures
        data = load_failures()
        for key, entry in data.get("failures", {}).items():
            if entry.get("count", 0) >= 2:
                diag = diagnose(entry["tool"], entry.get("error", ""))
                if diag.get("auto_fixable"):
                    fix = attempt_auto_fix(diag)
                    results.append({**diag, "repair": fix})
    except Exception:
        pass
    return results
