"""Autonomous multi-step task planner.

Takes a high-level goal → decomposes into a step list → dispatches each step
through the same tool-resolution surface as `brain/macros.py` → recovers from
failures with sensible fallbacks → reports the full transcript back.

Planning uses the `claude -p` CLI by default (Max-plan, no API key); if
ANTHROPIC_API_KEY is set, the Anthropic SDK is used instead. The planner is
told the names of ~50 likely tools and a strict JSON output schema; on parse
failure it falls back to a single "ask Dean to clarify" step.

Every run is appended to `brain_state/autopilot-runs.jsonl` (append-only) for
later inspection / replay / failure-clustering.

Public tools (~15) — see EXTRA_TOOLS at bottom.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from brain.engine_health import resolve as _claude_bin  # never spawn claude by bare name
from brain.engine_health import mark_fail as _engine_fail, owner_message as _engine_message
import threading
import time
import traceback
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_STATE_DIR.mkdir(exist_ok=True)
_RUNS_FILE = _STATE_DIR / "autopilot-runs.jsonl"

# Modules walked, in order, to resolve dotted tool names. Mirrors
# brain/macros.py::_resolve_tool_callable, extended with the integrations
# packages the rest of Leon exposes.
_TOOL_MODULES: Tuple[str, ...] = (
    "brain.memory_extras",
    "brain.introspection",
    "brain.tentacle_orchestration",
    "brain.reports",
    "brain.presence",
    "brain.self_improve",
    "brain.integrations.comms",
    "brain.integrations.smart_home",
    "brain.integrations.phone",
    "brain.integrations.research",
    "brain.integrations.productivity",
    "brain.integrations.ai_providers",
    "brain.integrations.life",
    "brain.integrations.coding",
    "brain.integrations.workflow",
    "brain.integrations.fun",
)

# Hint list shown to the planner LLM. Keeping this hand-curated and short
# beats dumping the full 1000-tool inventory — the model picks better with
# fewer choices. (This used to claim "skill_inventory() exists if a richer
# view is needed". It does not exist and never did — same shape as the
# provision_local_llm comment that promised an offline model nobody armed.
# If a richer view is wanted, it has to be written first.)
_PLANNER_HINT_TOOLS: List[Dict[str, str]] = [
    {"name": "presence.tts_say", "args": "text"},
    {"name": "presence.dashboard_event", "args": "kind, message, icon"},
    {"name": "presence.set_status_message", "args": "message, icon, severity, ttl_seconds"},
    {"name": "presence.voice_tone_set", "args": "tone (quiet|casual|professional)"},
    {"name": "presence.chime", "args": "tone"},
    {"name": "presence.notify", "args": "title, body"},
    {"name": "report.daily_briefing", "args": "location, max_news"},
    {"name": "report.end_of_day", "args": ""},
    {"name": "report.status_pulse", "args": ""},
    {"name": "info.weather_now", "args": "location"},
    {"name": "info.weather_forecast", "args": "location, days"},
    {"name": "info.news_hackernews_top", "args": "limit"},
    {"name": "memory.episode_log", "args": "event, tags"},
    {"name": "memory.preference_set", "args": "category, key, value"},
    {"name": "memory.mood_log", "args": "dopamine, serotonin, norepinephrine, acetylcholine"},
    {"name": "macro.run", "args": "name, stop_on_error"},
    {"name": "macro.list", "args": ""},
    {"name": "comms.gmail_search", "args": "query, limit"},
    {"name": "comms.gmail_read_thread", "args": "thread_id"},
    {"name": "comms.list_all_unread", "args": ""},
    {"name": "calendar.next_event", "args": ""},
    {"name": "calendar.list_events", "args": "days"},
    {"name": "home.lights_scene", "args": "name"},
    {"name": "home.lights_dim", "args": "area, percent"},
    {"name": "home.lights_off", "args": ""},
    {"name": "home.ha_call_service", "args": "domain, service, service_data"},
    {"name": "spotify.play_pause", "args": ""},
    {"name": "spotify.next_track", "args": ""},
    {"name": "browser.goto", "args": "url"},
    {"name": "browser_dom_click", "args": "selector"},
    {"name": "click_element", "args": "description, position"},
    {"name": "click_text", "args": "text"},
    {"name": "mouse_click", "args": "x, y"},
    {"name": "screen.capture", "args": "monitor"},
    {"name": "window.list", "args": ""},
    {"name": "window.focus", "args": "title"},
    {"name": "window_move_to_monitor", "args": "title, monitor"},
    {"name": "vscode.open_file", "args": "path"},
    {"name": "file.read", "args": "path"},
    {"name": "file.write", "args": "path, content"},
    {"name": "shell.run", "args": "cmd"},
    {"name": "git.status", "args": "repo"},
    {"name": "clipboard.set", "args": "text"},
    {"name": "clipboard.get", "args": ""},
    {"name": "tentacle.list", "args": ""},
    {"name": "tentacle.relay", "args": "to, message"},
    {"name": "research.web_search", "args": "query"},
    {"name": "research.summarize_url", "args": "url"},
    {"name": "phone.send_sms", "args": "to, body"},
    {"name": "meta.snapshot_brain_state", "args": "label"},
    {"name": "introspect.self_describe", "args": ""},
]

# Click-fallback chain: if a click step fails and retry_alternatives is on,
# we cycle through these in order with the same args (best-effort).
_CLICK_FALLBACK_CHAIN: Tuple[str, ...] = (
    "browser_dom_click",
    "click_element",
    "click_text",
    "mouse_click",
)

# In-flight async runs — best-effort cancellation flags.
_ASYNC_RUNS: Dict[str, Dict[str, Any]] = {}
_ASYNC_LOCK = threading.Lock()


# ── Tool resolution ────────────────────────────────────────────────────

def _resolve_tool_callable(dotted: str) -> Tuple[Optional[Callable], str]:
    """(callable_or_None, kind) — kind is 'local' | 'actuator'. Walks the
    same module list as macros.py, falling through to actuator dispatch."""
    for mod_path in _TOOL_MODULES:
        try:
            m = __import__(mod_path, fromlist=["EXTRA_TOOLS"])
            et = getattr(m, "EXTRA_TOOLS", {})
            if dotted in et:
                return et[dotted], "local"
        except Exception:
            continue
    return None, "actuator"


def _invoke(tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Single tool call. Never raises — wraps the actuator dispatcher and
    normalizes the return shape to {ok, ...}."""
    fn, kind = _resolve_tool_callable(tool)
    try:
        if fn is not None:
            r = fn(args or {})
        else:
            from brain.actuator_client import call as _act_call
            r = _act_call(tool, args or {})
        if not isinstance(r, dict):
            r = {"ok": True, "result": r}
        r.setdefault("ok", True)
        r["__tool"] = tool
        r["__kind"] = kind
        return r
    except Exception as e:
        return {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "__tool": tool,
            "__kind": kind,
        }


# ── Persistence ────────────────────────────────────────────────────────

def _append_run(entry: Dict[str, Any]) -> None:
    try:
        with _RUNS_FILE.open("a") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass


def _read_runs() -> List[Dict[str, Any]]:
    if not _RUNS_FILE.exists():
        return []
    out: List[Dict[str, Any]] = []
    try:
        for line in _RUNS_FILE.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
    except OSError:
        return []
    return out


# ── LLM planning ───────────────────────────────────────────────────────

def _planner_system_prompt() -> str:
    tools_blob = "\n".join(
        f"  - {t['name']}({t['args']})" for t in _PLANNER_HINT_TOOLS
    )
    return (
        "You are Leon's autopilot planner. Decompose a goal into a short ordered "
        "list of concrete tool calls. Each tool call has a dotted name (e.g. "
        "presence.tts_say), structured args, and a 1-sentence 'why'.\n\n"
        "Likely tools (not exhaustive — there are 300+ more under prefixes like "
        "browser., file., vscode., comms., calendar., home., spotify., memory., "
        "research., phone., window., git.):\n"
        f"{tools_blob}\n\n"
        "Reply ONLY with a single JSON object — no prose, no markdown fences, no "
        "code blocks. Schema:\n"
        '{"steps": [{"name": str, "tool": str, "args": object, "why": str}], '
        '"reasoning": str}\n\n'
        "Rules:\n"
        "- Prefer existing macros (macro.run) when one obviously fits.\n"
        "- Keep plans short — 1 to 8 steps is normal, never more than max_steps.\n"
        "- Use presence.dashboard_event at the start and end of multi-step plans.\n"
        "- If the goal is a simple statement (not a task), reply with one step "
        "that calls presence.tts_say with a fitting acknowledgement.\n"
    )


def _strip_code_fences(s: str) -> str:
    s = s.strip()
    if s.startswith("```"):
        # ```json\n{...}\n```  or  ```\n{...}\n```
        s = re.sub(r"^```[a-zA-Z]*\n", "", s)
        if s.endswith("```"):
            s = s[:-3]
    return s.strip()


def _extract_json(text: str) -> Optional[Dict[str, Any]]:
    text = _strip_code_fences(text)
    # Direct parse first
    try:
        return json.loads(text)
    except Exception:
        pass
    # Greedy brace match
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:
        return None


def _llm_plan_via_anthropic(goal: str, max_steps: int) -> Optional[str]:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None
    try:
        import anthropic  # type: ignore
    except Exception:
        return None
    try:
        client = anthropic.Anthropic(api_key=api_key)
        msg = client.messages.create(
            model=os.environ.get("LEON_PLANNER_MODEL", "claude-sonnet-4-6"),
            max_tokens=1500,
            system=_planner_system_prompt(),
            messages=[{
                "role": "user",
                "content": f"Goal: {goal}\nmax_steps: {max_steps}\n\nReturn only the JSON object.",
            }],
        )
        parts = []
        for block in getattr(msg, "content", []) or []:
            t = getattr(block, "text", None)
            if t:
                parts.append(t)
        return "".join(parts) if parts else None
    except Exception:
        return None


# Why the LAST CLI planner attempt failed ("not_found" | "timeout" | None).
# Lets the fallback plan name the real problem instead of blaming the goal.
_LAST_CLI_ERROR: Optional[str] = None


def _llm_plan_via_cli(goal: str, max_steps: int) -> Optional[str]:
    """Shell out to `claude -p` for Max-plan use. Strips ANTHROPIC_API_KEY from
    the subprocess env so the CLI uses the OAuth/Max-plan session, never the
    pay-per-token API."""
    global _LAST_CLI_ERROR
    env = {k: v for k, v in os.environ.items() if k != "ANTHROPIC_API_KEY"}
    prompt = (
        f"{_planner_system_prompt()}\n\n"
        f"Goal: {goal}\nmax_steps: {max_steps}\n\nReturn only the JSON object."
    )
    try:
        proc = subprocess.run(
            # Pin the planner off the (weekly-capped) Sonnet tier; the CLI
            # default could be Sonnet. Override via LEON_PLANNER_MODEL_CLI.
            [_claude_bin(), "--model", os.environ.get("LEON_PLANNER_MODEL_CLI", "haiku"),
             "-p", prompt],
            env=env,
            capture_output=True,
            text=True,
            timeout=int(os.environ.get("LEON_PLANNER_TIMEOUT", "60")),
        )
    except OSError as e:
        # FileNotFoundError and friends mean the CLI could not be LAUNCHED
        # (missing claude, stale PATH, Windows claude.cmd). That is the engine
        # being down, not an unclear goal — record it so the caller can say so
        # instead of asking the owner to reword (Aiden, 2026-08-29).
        _LAST_CLI_ERROR = "not_found"
        _engine_fail("not_found", f"autopilot planner: {e}")
        return None
    except subprocess.TimeoutExpired as e:
        _LAST_CLI_ERROR = "timeout"
        _engine_fail("timeout", f"autopilot planner: {e}")
        return None
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    return (proc.stdout or "").strip() or None


def _fallback_plan(engine_error: Optional[str] = None) -> List[Dict[str, Any]]:
    if engine_error:
        # The planner never answered because the reasoning engine could not be
        # reached. Blaming the goal here sent Aiden chasing his own wording for
        # twelve hours while nothing was running.
        return [{
            "name": "report_engine_down",
            "tool": "presence.tts_say",
            "args": {"text": _engine_message(engine_error)},
            "why": f"Planner CLI failed ({engine_error}) — report the engine, not the goal.",
        }]
    return [{
        "name": "think_and_respond",
        "tool": "presence.tts_say",
        "args": {"text": "I couldn't plan that — can you break it into smaller steps?"},
        "why": "Planner returned no parseable JSON; ask Dean to refine the goal.",
    }]


def _plan(args: Dict[str, Any]) -> Dict[str, Any]:
    """Decompose a goal into a step list.

    Args:
      goal: high-level natural-language goal (required)
      max_steps: cap on plan length (default 12)
      model_hint: 'cli' (default) or 'api' — preference order for LLM call
    """
    goal = args.get("goal")
    if not goal:
        return {"ok": False, "error": "goal is required"}
    max_steps = max(1, min(50, int(args.get("max_steps", 12))))
    model_hint = (args.get("model_hint") or "cli").lower()

    # Order the two backends by hint, but try both before falling back.
    global _LAST_CLI_ERROR
    _LAST_CLI_ERROR = None
    raw: Optional[str] = None
    if model_hint == "api":
        raw = _llm_plan_via_anthropic(goal, max_steps) or _llm_plan_via_cli(goal, max_steps)
    else:
        raw = _llm_plan_via_cli(goal, max_steps) or _llm_plan_via_anthropic(goal, max_steps)

    parsed = _extract_json(raw) if raw else None
    if not parsed or not isinstance(parsed.get("steps"), list):
        if _LAST_CLI_ERROR:
            return {
                "ok": True,
                "steps": _fallback_plan(_LAST_CLI_ERROR),
                "reasoning": f"Planner CLI {_LAST_CLI_ERROR} — reporting the engine, not the goal.",
                "fallback": True,
                "engine_error": _LAST_CLI_ERROR,
            }
        return {
            "ok": True,
            "steps": _fallback_plan(),
            "reasoning": "Planner unreachable or returned non-JSON — using clarify fallback.",
            "fallback": True,
        }

    steps = parsed["steps"][:max_steps]
    # Light coercion so callers never see exotic shapes.
    cleaned: List[Dict[str, Any]] = []
    for i, s in enumerate(steps):
        if not isinstance(s, dict) or not s.get("tool"):
            continue
        cleaned.append({
            "name": str(s.get("name") or f"step_{i+1}"),
            "tool": str(s["tool"]),
            "args": s.get("args") if isinstance(s.get("args"), dict) else {},
            "why": str(s.get("why") or ""),
        })
    if not cleaned:
        return {
            "ok": True,
            "steps": _fallback_plan(),
            "reasoning": "Planner produced no valid steps — using clarify fallback.",
            "fallback": True,
        }
    return {
        "ok": True,
        "steps": cleaned,
        "reasoning": str(parsed.get("reasoning") or ""),
        "fallback": False,
    }


# ── Step execution ─────────────────────────────────────────────────────

def _is_click_tool(tool: str) -> bool:
    return tool in _CLICK_FALLBACK_CHAIN or tool.endswith("_click") or tool.endswith(".click")


def _run_step(args: Dict[str, Any]) -> Dict[str, Any]:
    """Execute one step. On failure, optionally walk the click fallback chain.

    Args:
      tool: dotted tool name (required)
      args: tool args dict
      retry_alternatives: if True (default), try the click fallback chain on
        click failures.

    Phase 5 — when LEON_COGNITION_AUTOPILOT=on, consult cognition.rollout
    before each step; ABORT recommendations skip the step entirely.
    """
    tool = args.get("tool")
    tool_args = args.get("args", {}) or {}
    retry_alts = bool(args.get("retry_alternatives", True))
    if not tool:
        return {"ok": False, "error": "tool is required"}

    # Phase 5+11A — cognition pre-flight (pass-through when env flag is off).
    # Phase 11A: pass remaining_plan so preflight can do multi-step rollout.
    try:
        from brain.cognition.autopilot_integration import maybe_preflight_step
        preflight = maybe_preflight_step(
            tool, tool_args,
            remaining_plan=args.get("__remaining_plan") or None,
        )
        if not preflight.get("proceed", True):
            return {
                "ok": False,
                "error": preflight.get("reason", "cognition aborted step"),
                "cognition_aborted": True,
                "cognition": preflight,
            }
    except Exception:
        # Cognition module unavailable — proceed as if no preflight
        preflight = {"proceed": True}

    r = _invoke(tool, tool_args)
    # Attach cognition annotation if we had a warning
    if isinstance(r, dict) and preflight.get("warning"):
        r["cognition_warning"] = preflight["warning"]
    if r.get("ok") or not retry_alts or not _is_click_tool(tool):
        return r

    # Click-failure fallback chain.
    attempts = [{"tool": tool, "result": r}]
    for alt in _CLICK_FALLBACK_CHAIN:
        if alt == tool:
            continue
        alt_r = _invoke(alt, tool_args)
        attempts.append({"tool": alt, "result": alt_r})
        if alt_r.get("ok"):
            alt_r["__fallback_from"] = tool
            alt_r["__attempts"] = attempts
            return alt_r
    final = attempts[-1]["result"]
    final["__attempts"] = attempts
    final["__fallback_exhausted"] = True
    return final


# ── Full run ───────────────────────────────────────────────────────────

def _new_run_id() -> str:
    return f"ap-{int(time.time())}-{uuid.uuid4().hex[:6]}"


def _run(args: Dict[str, Any]) -> Dict[str, Any]:
    """Plan (if needed) and execute. Returns the full transcript.

    Args:
      goal: high-level goal (required if plan not provided)
      plan: pre-built step list (optional — skips planning)
      max_steps: cap on plan length (default 12)
      dry_run: if True, return the plan without executing
      stop_on_error: abort on first failure (default True)
      retry_alternatives: pass through to per-step (default True)
      run_id: optional caller-supplied run id (for async/replay)
    """
    goal = args.get("goal")
    plan = args.get("plan")
    max_steps = max(1, min(50, int(args.get("max_steps", 12))))
    dry_run = bool(args.get("dry_run", False))
    stop_on_error = bool(args.get("stop_on_error", True))
    retry_alts = bool(args.get("retry_alternatives", True))
    run_id = args.get("run_id") or _new_run_id()

    if plan is None:
        if not goal:
            return {"ok": False, "error": "goal or plan is required"}
        planned = _plan({"goal": goal, "max_steps": max_steps,
                         "model_hint": args.get("model_hint", "cli")})
        if not planned.get("ok"):
            return planned
        plan = planned.get("steps") or []
        reasoning = planned.get("reasoning", "")
        plan_was_fallback = planned.get("fallback", False)
    else:
        if not isinstance(plan, list):
            return {"ok": False, "error": "plan must be a list of steps"}
        plan = plan[:max_steps]
        reasoning = "caller-supplied plan"
        plan_was_fallback = False

    started = time.time()
    results: List[Dict[str, Any]] = []
    aborted = False
    cancelled = False

    if dry_run:
        entry = {
            "run_id": run_id,
            "ts": started,
            "goal": goal,
            "plan": plan,
            "reasoning": reasoning,
            "dry_run": True,
            "results": [],
            "aborted": False,
            "cancelled": False,
            "duration_s": 0.0,
            "fallback_plan": plan_was_fallback,
        }
        _append_run(entry)
        return {"ok": True, **entry}

    for i, step in enumerate(plan):
        # Cancellation check
        with _ASYNC_LOCK:
            slot = _ASYNC_RUNS.get(run_id)
        if slot and slot.get("cancel"):
            cancelled = True
            break

        # Phase 11A — pass remaining plan so preflight can run multi-step chain rollout.
        # Pure pass-through when LEON_COGNITION_AUTOPILOT=off.
        remaining = plan[i + 1 : i + 5]  # up to 4 steps after this one
        r = _run_step({
            "tool": step.get("tool"),
            "args": step.get("args") or {},
            "retry_alternatives": retry_alts,
            "__remaining_plan": remaining,
        })
        r["__step_index"] = i
        r["__step_name"] = step.get("name")
        results.append(r)
        if not r.get("ok") and stop_on_error:
            aborted = True
            break

    finished = time.time()
    entry = {
        "run_id": run_id,
        "ts": started,
        "goal": goal,
        "plan": plan,
        "reasoning": reasoning,
        "dry_run": False,
        "results": results,
        "aborted": aborted,
        "cancelled": cancelled,
        "duration_s": round(finished - started, 3),
        "step_oks": sum(1 for r in results if r.get("ok")),
        "step_failures": sum(1 for r in results if not r.get("ok")),
        "fallback_plan": plan_was_fallback,
    }
    _append_run(entry)

    with _ASYNC_LOCK:
        if run_id in _ASYNC_RUNS:
            _ASYNC_RUNS[run_id]["done"] = True
            _ASYNC_RUNS[run_id]["result"] = entry

    # Phase 5 — feed the cognition layer with run-level outcome + reinforce
    # graph chain if every step succeeded. Pass-through when env flag is off.
    try:
        from brain.cognition.autopilot_integration import (
            maybe_record_run_outcome, maybe_reinforce_successful_chain,
        )
        success = not aborted and not cancelled
        maybe_record_run_outcome(
            goal=goal or "(no-goal)",
            steps=len(plan),
            success=success,
            duration_s=finished - started,
            failed_steps=entry["step_failures"],
        )
        if success and entry["step_failures"] == 0:
            action_names = [s.get("tool") for s in plan if s.get("tool")]
            maybe_reinforce_successful_chain(action_names)
    except Exception:
        pass

    return {"ok": not aborted and not cancelled, **entry}


def _run_async(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fire-and-forget background run. Returns immediately with the run_id;
    poll `autopilot.get_run` for status.

    Args: same as autopilot.run.
    """
    run_id = args.get("run_id") or _new_run_id()
    args = dict(args)
    args["run_id"] = run_id

    with _ASYNC_LOCK:
        _ASYNC_RUNS[run_id] = {"cancel": False, "done": False, "result": None,
                                "started": time.time()}

    def _worker():
        try:
            _run(args)
        except Exception:
            with _ASYNC_LOCK:
                if run_id in _ASYNC_RUNS:
                    _ASYNC_RUNS[run_id]["done"] = True
                    _ASYNC_RUNS[run_id]["error"] = traceback.format_exc()

    t = threading.Thread(target=_worker, name=f"autopilot-{run_id}", daemon=True)
    t.start()
    return {"ok": True, "run_id": run_id, "started": True}


def _cancel_run(args: Dict[str, Any]) -> Dict[str, Any]:
    """Best-effort cancel of an in-flight async run. The current step finishes
    but no further steps fire.

    Args:
      run_id (required)
    """
    run_id = args.get("run_id")
    if not run_id:
        return {"ok": False, "error": "run_id is required"}
    with _ASYNC_LOCK:
        slot = _ASYNC_RUNS.get(run_id)
        if not slot:
            return {"ok": False, "error": f"no in-flight run with id {run_id}"}
        if slot.get("done"):
            return {"ok": True, "already_done": True, "run_id": run_id}
        slot["cancel"] = True
    return {"ok": True, "run_id": run_id, "cancel_requested": True}


# ── Run history ────────────────────────────────────────────────────────

def _recent_runs(args: Dict[str, Any]) -> Dict[str, Any]:
    """Tail of autopilot-runs.jsonl.

    Args:
      limit: how many recent runs (default 20)
    """
    limit = min(500, max(1, int(args.get("limit", 20))))
    runs = _read_runs()[-limit:]
    return {"ok": True, "runs": runs, "count": len(runs)}


def _get_run(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fetch a single run by id.

    Args:
      run_id (required)
    """
    run_id = args.get("run_id")
    if not run_id:
        return {"ok": False, "error": "run_id is required"}
    for r in reversed(_read_runs()):
        if r.get("run_id") == run_id:
            return {"ok": True, "run": r}
    # Also check in-flight async slot
    with _ASYNC_LOCK:
        slot = _ASYNC_RUNS.get(run_id)
    if slot:
        return {"ok": True, "in_flight": True, "slot": {
            "done": slot.get("done"),
            "cancel": slot.get("cancel"),
            "started": slot.get("started"),
            "result": slot.get("result"),
        }}
    return {"ok": False, "error": f"no run with id {run_id}"}


def _list_recent_goals(args: Dict[str, Any]) -> Dict[str, Any]:
    """Distinct goals across recent runs, newest first.

    Args:
      limit: max distinct goals to return (default 20)
    """
    limit = min(200, max(1, int(args.get("limit", 20))))
    seen = []
    seen_set = set()
    for r in reversed(_read_runs()):
        g = r.get("goal")
        if not g or g in seen_set:
            continue
        seen.append({"goal": g, "ts": r.get("ts"), "run_id": r.get("run_id"),
                     "aborted": r.get("aborted", False)})
        seen_set.add(g)
        if len(seen) >= limit:
            break
    return {"ok": True, "goals": seen, "count": len(seen)}


def _replay(args: Dict[str, Any]) -> Dict[str, Any]:
    """Re-execute a prior run's plan from scratch (new run_id, fresh results).

    Args:
      run_id (required)
      with_alternatives: pass through retry_alternatives (default False)
    """
    run_id = args.get("run_id")
    if not run_id:
        return {"ok": False, "error": "run_id is required"}
    target = None
    for r in reversed(_read_runs()):
        if r.get("run_id") == run_id:
            target = r
            break
    if not target:
        return {"ok": False, "error": f"no run with id {run_id}"}
    plan = target.get("plan") or []
    return _run({
        "goal": target.get("goal"),
        "plan": plan,
        "retry_alternatives": bool(args.get("with_alternatives", False)),
        "stop_on_error": True,
    })


# ── Observation-driven helpers ─────────────────────────────────────────

# Cheap keyword→tool heuristics for suggest_next_action. Order matters —
# first match wins. This is intentionally dumb; the LLM-backed planner is
# the real brain. Used as a 0-latency hint for proactive routines.
_OBSERVATION_RULES: Tuple[Tuple[str, Dict[str, Any]], ...] = (
    ("weather", {"tool": "info.weather_now", "args": {"location": "Los Angeles"},
                 "why": "observation mentions weather"}),
    ("forecast", {"tool": "info.weather_forecast", "args": {"location": "Los Angeles", "days": 3},
                  "why": "observation mentions forecast"}),
    ("email", {"tool": "comms.list_all_unread", "args": {},
               "why": "observation mentions email"}),
    ("inbox", {"tool": "comms.list_all_unread", "args": {},
               "why": "observation mentions inbox"}),
    ("calendar", {"tool": "calendar.next_event", "args": {},
                  "why": "observation mentions calendar"}),
    ("meeting", {"tool": "calendar.next_event", "args": {},
                 "why": "observation mentions meeting"}),
    ("focus", {"tool": "macro.run", "args": {"name": "focus_mode"},
               "why": "observation mentions focus"}),
    ("sleep", {"tool": "macro.run", "args": {"name": "sleep_mode"},
               "why": "observation mentions sleep"}),
    ("good morning", {"tool": "macro.run", "args": {"name": "good_morning"},
                       "why": "morning greeting detected"}),
    ("goodnight", {"tool": "macro.run", "args": {"name": "sleep_mode"},
                    "why": "goodnight detected"}),
    ("news", {"tool": "info.news_hackernews_top", "args": {"limit": 5},
              "why": "observation mentions news"}),
    ("status", {"tool": "report.status_pulse", "args": {},
                "why": "observation mentions status"}),
    ("music", {"tool": "spotify.play_pause", "args": {},
               "why": "observation mentions music"}),
    ("lights", {"tool": "home.lights_scene", "args": {"name": "evening"},
                "why": "observation mentions lights"}),
    ("error", {"tool": "presence.dashboard_event",
               "args": {"kind": "warn", "message": "Error observed", "icon": "⚠"},
               "why": "error keyword in observation"}),
)


def _suggest_next_action(args: Dict[str, Any]) -> Dict[str, Any]:
    """Given an observation string, suggest one tool to fire. Heuristic-only —
    no LLM call. Returns the matched suggestion or a no-op presence event.

    Args:
      observation_text (required)
    """
    text = (args.get("observation_text") or "").lower().strip()
    if not text:
        return {"ok": False, "error": "observation_text is required"}
    for keyword, sugg in _OBSERVATION_RULES:
        if keyword in text:
            return {"ok": True, "matched": keyword, "suggestion": sugg}
    return {
        "ok": True,
        "matched": None,
        "suggestion": {
            "tool": "memory.episode_log",
            "args": {"event": f"observation: {text[:200]}", "tags": ["passive-observation"]},
            "why": "no rule matched — log the observation for later review",
        },
    }


def _explain_step(args: Dict[str, Any]) -> Dict[str, Any]:
    """1-2 sentence English description of a step dict. For the observation
    feed and the dashboard.

    Args:
      step: {name?, tool, args?, why?} (required)
    """
    step = args.get("step")
    if not isinstance(step, dict) or not step.get("tool"):
        return {"ok": False, "error": "step dict with 'tool' is required"}
    tool = step["tool"]
    why = (step.get("why") or "").strip()
    s_args = step.get("args") or {}

    # A few high-traffic tools get hand-written prose; everything else falls
    # through to a generic "calling X with Y" sentence.
    if tool == "presence.tts_say":
        text = s_args.get("text", "")
        desc = f"Speaks aloud: \"{text}\"."
    elif tool == "presence.dashboard_event":
        msg = s_args.get("message", "")
        desc = f"Posts a dashboard event: \"{msg}\"."
    elif tool == "macro.run":
        desc = f"Runs the macro `{s_args.get('name', '?')}`."
    elif tool.startswith("home.lights"):
        desc = f"Adjusts the lights ({tool.split('.', 1)[1]})."
    elif tool == "report.daily_briefing":
        desc = "Generates the daily briefing (weather + calendar + news)."
    elif tool.startswith("comms.gmail"):
        desc = f"Touches Gmail via {tool}."
    elif tool.startswith("calendar."):
        desc = f"Reads Google Calendar via {tool}."
    elif tool.startswith("spotify."):
        desc = f"Controls Spotify via {tool}."
    elif _is_click_tool(tool):
        desc = f"Clicks on the screen via {tool}."
    else:
        key_preview = ", ".join(list(s_args.keys())[:4]) if isinstance(s_args, dict) else ""
        desc = f"Calls `{tool}`" + (f" with {key_preview}." if key_preview else ".")

    if why:
        desc = f"{desc} Reason: {why}"
    return {"ok": True, "tool": tool, "description": desc}


# ── Analytics ──────────────────────────────────────────────────────────

def _runs_within(days: int) -> List[Dict[str, Any]]:
    cutoff = time.time() - max(0, days) * 86400
    return [r for r in _read_runs() if (r.get("ts") or 0) >= cutoff]


def _success_rate(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fraction of runs in the last N days that completed without aborting.

    Args:
      days: window size (default 7)
    """
    days = max(1, int(args.get("days", 7)))
    runs = _runs_within(days)
    total = len(runs)
    if total == 0:
        return {"ok": True, "days": days, "total": 0, "success_rate": None,
                "successes": 0, "aborted": 0, "cancelled": 0}
    successes = sum(1 for r in runs if not r.get("aborted") and not r.get("cancelled")
                                       and not r.get("dry_run"))
    aborted = sum(1 for r in runs if r.get("aborted"))
    cancelled = sum(1 for r in runs if r.get("cancelled"))
    non_dry = [r for r in runs if not r.get("dry_run")]
    denom = len(non_dry) or 1
    return {
        "ok": True,
        "days": days,
        "total": total,
        "non_dry_total": len(non_dry),
        "successes": successes,
        "aborted": aborted,
        "cancelled": cancelled,
        "success_rate": round(successes / denom, 4),
    }


def _failure_clusters(args: Dict[str, Any]) -> Dict[str, Any]:
    """Which kinds of steps fail most in the last N days, grouped by tool name.

    Args:
      days: window size (default 7)
      limit: top-N tools to return (default 10)
    """
    days = max(1, int(args.get("days", 7)))
    limit = max(1, int(args.get("limit", 10)))
    runs = _runs_within(days)
    by_tool: Dict[str, Dict[str, int]] = {}
    for r in runs:
        for s in r.get("results") or []:
            tool = s.get("__tool") or "?"
            slot = by_tool.setdefault(tool, {"fails": 0, "calls": 0})
            slot["calls"] += 1
            if not s.get("ok"):
                slot["fails"] += 1
    rows = []
    for tool, slot in by_tool.items():
        if slot["fails"] == 0:
            continue
        rate = slot["fails"] / slot["calls"] if slot["calls"] else 0.0
        rows.append({"tool": tool, "fails": slot["fails"], "calls": slot["calls"],
                     "fail_rate": round(rate, 4)})
    rows.sort(key=lambda x: (x["fails"], x["fail_rate"]), reverse=True)
    return {"ok": True, "days": days, "clusters": rows[:limit], "count": len(rows)}


def _confidence_check(args: Dict[str, Any]) -> Dict[str, Any]:
    """Static sanity-check on a plan before execution. Verifies tool names
    resolve and flags steps with empty args dicts where args are usually
    required.

    Args:
      plan: list of step dicts (required)
    """
    plan = args.get("plan")
    if not isinstance(plan, list):
        return {"ok": False, "error": "plan (list) is required"}
    warnings: List[Dict[str, Any]] = []
    for i, s in enumerate(plan):
        if not isinstance(s, dict):
            warnings.append({"step": i, "issue": "step is not a dict"})
            continue
        tool = s.get("tool")
        if not tool:
            warnings.append({"step": i, "issue": "missing 'tool'"})
            continue
        fn, kind = _resolve_tool_callable(tool)
        if fn is None and kind != "actuator":
            warnings.append({"step": i, "tool": tool, "issue": "tool does not resolve"})
        # Flag clearly-empty args for tools that almost always need text input.
        s_args = s.get("args") or {}
        if tool == "presence.tts_say" and not s_args.get("text"):
            warnings.append({"step": i, "tool": tool, "issue": "tts_say with no 'text'"})
        if tool == "macro.run" and not s_args.get("name"):
            warnings.append({"step": i, "tool": tool, "issue": "macro.run with no 'name'"})
        if tool.startswith("comms.gmail_search") and not s_args.get("query"):
            warnings.append({"step": i, "tool": tool, "issue": "gmail_search with no 'query'"})
    return {
        "ok": True,
        "step_count": len(plan),
        "warning_count": len(warnings),
        "warnings": warnings,
        "confidence": "high" if not warnings else ("medium" if len(warnings) <= 2 else "low"),
    }


def _skill_inventory(args: Dict[str, Any]) -> Dict[str, Any]:
    """Compact list of every dotted tool Leon currently exposes via the
    EXTRA_TOOLS registries, grouped by dotted prefix. Useful for showing
    the planner its own affordances.

    Args:
      include_actuator: if True, also try to ask the actuator for its tool
        list (best-effort, may be empty)
    """
    include_actuator = bool(args.get("include_actuator", False))
    by_prefix: Dict[str, List[str]] = {}
    all_tools: List[str] = []
    for mod_path in _TOOL_MODULES:
        try:
            m = __import__(mod_path, fromlist=["EXTRA_TOOLS"])
            et = getattr(m, "EXTRA_TOOLS", {})
        except Exception:
            continue
        for name in et.keys():
            all_tools.append(name)
            prefix = name.split(".", 1)[0] if "." in name else name
            by_prefix.setdefault(prefix, []).append(name)

    actuator_tools: List[str] = []
    if include_actuator:
        try:
            from brain.actuator_client import call as _act_call  # type: ignore
            r = _act_call("meta.list_tools", {})
            if isinstance(r, dict) and isinstance(r.get("tools"), list):
                actuator_tools = list(r["tools"])
        except Exception:
            actuator_tools = []

    for k in by_prefix:
        by_prefix[k] = sorted(set(by_prefix[k]))

    return {
        "ok": True,
        "total": len(set(all_tools)) + len(actuator_tools),
        "local_total": len(set(all_tools)),
        "prefixes": sorted(by_prefix.keys()),
        "by_prefix": by_prefix,
        "actuator_tools": actuator_tools,
    }


# ── Registry ───────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    "autopilot.plan":                _plan,
    "autopilot.run":                 _run,
    "autopilot.run_step":            _run_step,
    "autopilot.run_async":           _run_async,
    "autopilot.cancel_run":          _cancel_run,
    "autopilot.recent_runs":         _recent_runs,
    "autopilot.get_run":             _get_run,
    "autopilot.list_recent_goals":   _list_recent_goals,
    "autopilot.replay":              _replay,
    "autopilot.suggest_next_action": _suggest_next_action,
    "autopilot.explain_step":        _explain_step,
    "autopilot.success_rate":        _success_rate,
    "autopilot.failure_clusters":    _failure_clusters,
    "autopilot.confidence_check":    _confidence_check,
    "autopilot.skill_inventory":     _skill_inventory,
}


# ── Goal queue — lets Leon defer multi-step jobs + auto-process them ──
# Dean says "later, do X" → queue_goal. A routine (autopilot_queue,
# disabled by default) drains the queue when Leon is idle.
import json as _json
from pathlib import Path as _Path

_QUEUE_FILE = _Path(__file__).resolve().parent.parent / "brain_state" / "autopilot_queue.json"


def _queue_load():
    if not _QUEUE_FILE.exists():
        return []
    try:
        return _json.loads(_QUEUE_FILE.read_text())
    except Exception:
        return []


def _queue_save(items):
    try:
        _QUEUE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _QUEUE_FILE.write_text(_json.dumps(items, indent=2))
    except OSError:
        pass


def _queue_goal(args):
    """Queue a goal for Leon to execute later (drained by the autopilot_queue
    routine, or manually via autopilot.process_queue).

    Args:
      goal: the task description (required)
      priority: 'low'|'normal'|'high' (default normal)
      not_before: optional ISO timestamp — don't run before this
    """
    import time as _t
    goal = args.get("goal")
    if not goal:
        return {"ok": False, "error": "goal is required"}
    items = _queue_load()
    entry = {
        "id": f"g{int(_t.time())}{len(items)}",
        "goal": goal,
        "priority": args.get("priority", "normal"),
        "not_before": args.get("not_before"),
        "queued_at": _t.time(),
        "status": "pending",
    }
    items.append(entry)
    _queue_save(items)
    return {"ok": True, "queued": entry, "queue_depth": len([i for i in items if i.get("status") == "pending"])}


def _queue_list(args):
    """List queued autopilot goals."""
    items = _queue_load()
    pending = [i for i in items if i.get("status") == "pending"]
    return {"ok": True, "queue": items[-30:], "pending_count": len(pending)}


def _queue_clear(args):
    """Clear the autopilot goal queue (or just done items with done_only=true)."""
    if args.get("done_only"):
        items = [i for i in _queue_load() if i.get("status") == "pending"]
        _queue_save(items)
        return {"ok": True, "cleared": "done items only", "remaining": len(items)}
    _queue_save([])
    return {"ok": True, "cleared": "all"}


def _process_queue(args):
    """Drain the autopilot goal queue — run each pending goal in priority
    order. Honors not_before timestamps. Marks each done/failed.

    Args:
      max_goals: cap how many to process this pass (default 3)
    """
    import time as _t
    max_goals = int(args.get("max_goals", 3))
    items = _queue_load()
    now = _t.time()
    prio_rank = {"high": 0, "normal": 1, "low": 2}
    pending = [i for i in items if i.get("status") == "pending"]
    # filter not_before
    runnable = []
    for i in pending:
        nb = i.get("not_before")
        if nb:
            try:
                from datetime import datetime as _dt
                if _dt.fromisoformat(nb.replace("Z", "+00:00")).timestamp() > now:
                    continue
            except Exception:
                pass
        runnable.append(i)
    runnable.sort(key=lambda i: prio_rank.get(i.get("priority", "normal"), 1))

    results = []
    for entry in runnable[:max_goals]:
        try:
            run_result = _run({"goal": entry["goal"]})
            entry["status"] = "done" if run_result.get("ok") else "failed"
            entry["completed_at"] = _t.time()
            results.append({"goal": entry["goal"], "ok": run_result.get("ok"),
                            "ran_steps": run_result.get("ran")})
        except Exception as e:
            entry["status"] = "failed"
            entry["error"] = str(e)
            results.append({"goal": entry["goal"], "ok": False, "error": str(e)})
    _queue_save(items)
    return {"ok": True, "processed": len(results), "results": results,
            "remaining": len([i for i in items if i.get("status") == "pending"])}


EXTRA_TOOLS["autopilot.queue_goal"] = _queue_goal
EXTRA_TOOLS["autopilot.queue_list"] = _queue_list
EXTRA_TOOLS["autopilot.queue_clear"] = _queue_clear
EXTRA_TOOLS["autopilot.process_queue"] = _process_queue
