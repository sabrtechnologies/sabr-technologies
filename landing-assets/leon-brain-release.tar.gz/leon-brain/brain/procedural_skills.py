"""
Procedural skill memory — how-to knowledge Leon distils from his own work.

Ported from the idea behind Hermes' skills, rebuilt on Leon's own pieces:

  * A SKILL is a short procedure: name, when to use it, the steps, the
    pitfalls. Not a log of one day: a lesson that generalises.
  * DISTIL: after Leon finishes a non-trivial multi-step turn (several tool
    calls on a turn with Dean), a background pass reads what was asked, which
    tools ran and how it ended, plus the closest existing skills, and decides:
    create a new skill, refine an existing one, or nothing (TurnTrace below,
    fed by respond_streaming in brain/claude_api_responder.py).
  * RETRIEVE: before a turn, the skills that fit the request are put in front
    of Leon in a small capped block next to his MEMORY RECALL block, and
    delegated sub-agents get the best match in their context.
  * DEDUPE: saving a skill whose purpose matches an existing one refines that
    one (version + 1) instead of piling up near-duplicates. The library is
    capped; the least-used, oldest skills are dropped first.
  * MEMORY: every skill is mirrored as one row in knowledge.db
    (source "skill:<slug>", replaced on each refine), so knowledge_search
    finds procedures alongside everything else Leon knows.

Store: <state dir>/procedural_skills.db (SQLite). Fail-open everywhere: a skill
problem can never block or alter a reply.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import math
import os
import re
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_ROOT = Path(__file__).resolve().parent.parent

# Size caps (characters unless noted). A rendered skill stays well under 1 KB.
NAME_MAX = 64
WHEN_MAX = 280
STEP_MAX = 220
STEPS_MAX = 10
PITFALL_MAX = 200
PITFALLS_MAX = 6
TAGS_MAX = 8
MAX_SKILLS = int(os.environ.get("LEON_SKILLS_MAX", "150"))
PROMPT_MAX_CHARS = int(os.environ.get("LEON_SKILLS_PROMPT_CHARS", "1400"))
PROMPT_LIMIT = 2

# Retrieval: a skill must share at least this many meaningful words with the
# request, and clear this score, before it is shown. Chatty turns match nothing.
MIN_MATCHED = 2
MIN_SCORE = 3.0
# Dedupe: purpose overlap at or above this refines instead of creating.
DUPE_JACCARD = 0.5

_STOP = set("""
a an and are as at be been but by can could did do does doing done for from get got
had has have how i if in into is it its just let like make me my need not now of off
on one or our out please so some that the their them then there these they this to
too up us use used using want was we were what when where which while who why will
with would you your yours yeah ok okay hey leon dean sir can't don't i'm it's that's
also again more most very really thing things stuff something anything everything
""".split())

_WORD = re.compile(r"[a-z0-9][a-z0-9+#._-]*")


def _stem(w: str) -> str:
    for suf in ("ing", "ies", "ied", "ed", "es", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)] + ("y" if suf in ("ies", "ied") else "")
    return w


def tokens(text: str) -> List[str]:
    out = []
    for w in _WORD.findall((text or "").lower()):
        w = w.strip("._-")
        if len(w) < 3 or w in _STOP or w.isdigit():
            continue
        out.append(_stem(w))
    return out


def slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")
    return s[:48].strip("-") or "skill"


def _clip(text: Any, cap: int) -> str:
    t = " ".join(str(text or "").split())
    return t if len(t) <= cap else t[: cap - 1].rstrip() + "…"


def _clip_list(items: Any, n: int, cap: int) -> List[str]:
    if isinstance(items, str):
        items = [x for x in re.split(r"\n+|(?<=\.)\s+(?=\d+[.)])", items) if x.strip()]
    out = []
    for it in items or []:
        t = re.sub(r"^\s*(?:\d+[.)]|[-*•])\s*", "", str(it or ""))
        t = _clip(t, cap)
        if t and t not in out:
            out.append(t)
        if len(out) >= n:
            break
    return out


def normalize(skill: Dict[str, Any]) -> Dict[str, Any]:
    """Clip and clean a skill dict to the caps. Raises ValueError if unusable."""
    name = _clip(skill.get("name"), NAME_MAX)
    when = _clip(skill.get("when_to_use") or skill.get("when"), WHEN_MAX)
    steps = _clip_list(skill.get("steps"), STEPS_MAX, STEP_MAX)
    pitfalls = _clip_list(skill.get("pitfalls"), PITFALLS_MAX, PITFALL_MAX)
    tags = [slugify(t)[:24] for t in (skill.get("tags") or []) if str(t).strip()][:TAGS_MAX]
    if not name:
        raise ValueError("a skill needs a name")
    if not when:
        raise ValueError("a skill needs when_to_use")
    if len(steps) < 2:
        raise ValueError("a skill needs at least two steps")
    return {"name": name, "when_to_use": when, "steps": steps, "pitfalls": pitfalls,
            "tags": tags}


def render(sk: Dict[str, Any], max_chars: int = 700) -> str:
    """One skill as compact prompt text, at most max_chars. When it is too
    long, every step and pitfall is shortened evenly first, so the pitfalls
    (the part most worth reading) are not the part that gets cut off."""
    head = f"• {sk['slug']} (v{sk.get('version', 1)}"
    if sk.get("uses"):
        head += f", used {sk['uses']}×"
    head += f"). When: {sk['when_to_use']}"
    text = ""
    for cap in (STEP_MAX, 160, 120, 90, 70, 50):
        steps = " ".join(f"{i + 1}) {_clip(s, cap)}" for i, s in enumerate(sk.get("steps") or []))
        text = f"{head}\n  Steps: {steps}"
        if sk.get("pitfalls"):
            text += "\n  Pitfalls: " + "; ".join(_clip(p, cap) for p in sk["pitfalls"])
        if len(text) <= max_chars:
            return text
    return text[: max_chars - 1].rstrip() + "…"


def _state_dir() -> Path:
    base = (os.environ.get("LEON_STATE_DIR") or os.environ.get("LEON_BRAIN_STATE") or "").strip()
    return Path(base) if base else _ROOT / "brain_state"


class SkillStore:
    """SQLite-backed skill library. Thread-safe; every public call fails soft
    only where noted (save/update raise ValueError for bad input)."""

    def __init__(self, db_path: Optional[str] = None, knowledge_db: Optional[str] = None,
                 mirror: bool = True):
        state = _state_dir()
        self.db_path = str(db_path or state / "procedural_skills.db")
        self.knowledge_db = str(knowledge_db or state / "knowledge.db")
        self.mirror = mirror
        self._lock = threading.RLock()
        self._recent: Dict[str, Any] = {}   # request hash -> slugs shown that turn
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS skills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                when_to_use TEXT NOT NULL,
                steps TEXT NOT NULL,
                pitfalls TEXT NOT NULL DEFAULT '[]',
                tags TEXT NOT NULL DEFAULT '[]',
                version INTEGER NOT NULL DEFAULT 1,
                uses INTEGER NOT NULL DEFAULT 0,
                shown INTEGER NOT NULL DEFAULT 0,
                source TEXT NOT NULL DEFAULT '',
                created_ts REAL NOT NULL,
                updated_ts REAL NOT NULL,
                last_used_ts REAL NOT NULL DEFAULT 0)""")

    @contextlib.contextmanager
    def _conn(self):
        c = sqlite3.connect(self.db_path, timeout=10)
        c.row_factory = sqlite3.Row
        try:
            yield c
            c.commit()
        finally:
            c.close()

    @staticmethod
    def _row(r: sqlite3.Row) -> Dict[str, Any]:
        d = dict(r)
        for k in ("steps", "pitfalls", "tags"):
            try:
                d[k] = json.loads(d.get(k) or "[]")
            except Exception:
                d[k] = []
        return d

    # ── read ────────────────────────────────────────────────────────────
    def all(self) -> List[Dict[str, Any]]:
        with self._lock, self._conn() as c:
            return [self._row(r) for r in c.execute("SELECT * FROM skills ORDER BY updated_ts DESC")]

    def get(self, name: str) -> Optional[Dict[str, Any]]:
        slug = slugify(name)
        with self._lock, self._conn() as c:
            r = c.execute("SELECT * FROM skills WHERE slug=?", (slug,)).fetchone()
            return self._row(r) if r else None

    def count(self) -> int:
        with self._lock, self._conn() as c:
            return c.execute("SELECT COUNT(*) FROM skills").fetchone()[0]

    def search(self, query: str, limit: int = 3, min_score: float = MIN_SCORE,
               min_matched: int = MIN_MATCHED) -> List[Dict[str, Any]]:
        """Skills that fit `query`, best first, each with a `score`."""
        q = set(tokens(query))
        if not q:
            return []
        skills = self.all()
        if not skills:
            return []
        fields = []
        df: Dict[str, int] = {}
        for sk in skills:
            f = {
                "name": set(tokens(sk["name"] + " " + sk["slug"].replace("-", " "))),
                "when": set(tokens(sk["when_to_use"])),
                "tags": set(tokens(" ".join(sk.get("tags") or []))),
                "body": set(tokens(" ".join((sk.get("steps") or []) + (sk.get("pitfalls") or [])))),
            }
            fields.append(f)
            for t in set().union(*f.values()):
                df[t] = df.get(t, 0) + 1
        n = len(skills)
        scored = []
        for sk, f in zip(skills, fields):
            score, matched = 0.0, 0
            for t in q:
                w = (3.0 if t in f["name"] else 2.0 if (t in f["when"] or t in f["tags"])
                     else 1.0 if t in f["body"] else 0.0)
                if w:
                    matched += 1
                    score += w * (1.0 + math.log((n + 1) / (df.get(t, 0) + 0.5)))
            if matched >= min_matched and score >= min_score:
                scored.append({**sk, "score": round(score, 2), "matched": matched})
        scored.sort(key=lambda s: (-s["score"], -s["uses"]))
        return scored[:limit]

    def prompt_block(self, request: str, limit: int = PROMPT_LIMIT,
                     max_chars: int = PROMPT_MAX_CHARS,
                     header: str = "") -> str:
        """The capped block put in front of Leon (or a sub-agent). "" if none fit."""
        hits = self.search(request, limit=limit)
        if not hits:
            return ""
        head = header or ("[SKILLS — procedures you wrote for yourself after past tasks. "
                          "Follow the one that fits. If it turns out wrong or is missing "
                          "a step, fix it with skill_library action=update.]")
        out, used = [head], len(head)
        per = (max_chars - len(head) - len(hits)) // len(hits)
        shown = []
        for sk in hits:
            room = max_chars - used - 1          # 1 = the joining newline
            if room < 200:
                break
            text = render(sk, min(max(per, 300), room))
            out.append(text)
            used += len(text) + 1
            shown.append(sk["slug"])
        if not shown:
            return ""
        self._note_shown(request, shown)
        return "\n".join(out)

    def _note_shown(self, request: str, slugs: List[str]) -> None:
        key = hashlib.sha1((request or "").encode("utf-8", "replace")).hexdigest()
        with self._lock:
            self._recent[key] = (time.time(), slugs)
            for k in [k for k, (ts, _) in self._recent.items() if time.time() - ts > 1800]:
                self._recent.pop(k, None)
            try:
                with self._conn() as c:
                    c.executemany("UPDATE skills SET shown=shown+1 WHERE slug=?",
                                  [(s,) for s in slugs])
            except Exception:
                pass

    def shown_for(self, request: str) -> List[str]:
        key = hashlib.sha1((request or "").encode("utf-8", "replace")).hexdigest()
        with self._lock:
            hit = self._recent.get(key)
            return list(hit[1]) if hit else []

    def mark_used(self, slugs: List[str]) -> None:
        if not slugs:
            return
        with self._lock, self._conn() as c:
            c.executemany("UPDATE skills SET uses=uses+1, last_used_ts=? WHERE slug=?",
                          [(time.time(), s) for s in slugs])

    # ── write ───────────────────────────────────────────────────────────
    def find_duplicate(self, skill: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """An existing skill with the same purpose, if any."""
        same = self.get(skill["name"])
        if same:
            return same
        mine = set(tokens(skill["name"] + " " + skill["when_to_use"]))
        if not mine:
            return None
        best, best_j = None, 0.0
        for sk in self.all():
            theirs = set(tokens(sk["name"] + " " + sk["when_to_use"]))
            if not theirs:
                continue
            j = len(mine & theirs) / len(mine | theirs)
            if j > best_j:
                best, best_j = sk, j
        return best if best_j >= DUPE_JACCARD else None

    def save(self, skill: Dict[str, Any], *, target: Optional[str] = None,
             source: str = "leon") -> Dict[str, Any]:
        """Create a skill, or refine the existing one with the same purpose.

        Returns {"action": "created"|"refined", "skill": {...}}.
        """
        sk = normalize(skill)
        now = time.time()
        with self._lock:
            existing = self.get(target) if target else None
            existing = existing or self.find_duplicate(sk)
            with self._conn() as c:
                if existing:
                    c.execute("""UPDATE skills SET name=?, when_to_use=?, steps=?, pitfalls=?,
                                 tags=?, version=version+1, updated_ts=?, source=? WHERE slug=?""",
                              (sk["name"], sk["when_to_use"], json.dumps(sk["steps"]),
                               json.dumps(_merge(existing.get("pitfalls"), sk["pitfalls"],
                                                 PITFALLS_MAX)),
                               json.dumps(_merge(existing.get("tags"), sk["tags"], TAGS_MAX)),
                               now, source, existing["slug"]))
                    slug, action = existing["slug"], "refined"
                else:
                    slug = slugify(sk["name"])
                    c.execute("""INSERT INTO skills (slug, name, when_to_use, steps, pitfalls,
                                 tags, source, created_ts, updated_ts)
                                 VALUES (?,?,?,?,?,?,?,?,?)""",
                              (slug, sk["name"], sk["when_to_use"], json.dumps(sk["steps"]),
                               json.dumps(sk["pitfalls"]), json.dumps(sk["tags"]), source,
                               now, now))
                    action = "created"
            self._evict()
            saved = self.get(slug)
        self._mirror(saved)
        return {"action": action, "skill": saved}

    def update(self, name: str, fields: Dict[str, Any], source: str = "leon") -> Dict[str, Any]:
        """Change some fields of an existing skill (others kept)."""
        cur = self.get(name)
        if not cur:
            raise ValueError(f"no skill named {slugify(name)}")
        merged = {k: cur[k] for k in ("name", "when_to_use", "steps", "pitfalls", "tags")}
        for k in ("when_to_use", "steps", "pitfalls", "tags"):
            if fields.get(k):
                merged[k] = fields[k]
        sk = normalize(merged)
        with self._lock, self._conn() as c:
            c.execute("""UPDATE skills SET when_to_use=?, steps=?, pitfalls=?, tags=?,
                         version=version+1, updated_ts=?, source=? WHERE slug=?""",
                      (sk["when_to_use"], json.dumps(sk["steps"]), json.dumps(sk["pitfalls"]),
                       json.dumps(sk["tags"]), time.time(), source, cur["slug"]))
        saved = self.get(cur["slug"])
        self._mirror(saved)
        return {"action": "refined", "skill": saved}

    def delete(self, name: str) -> bool:
        slug = slugify(name)
        with self._lock, self._conn() as c:
            gone = c.execute("DELETE FROM skills WHERE slug=?", (slug,)).rowcount > 0
        if gone:
            self._unmirror(slug)
        return gone

    def _evict(self) -> None:
        with self._conn() as c:
            n = c.execute("SELECT COUNT(*) FROM skills").fetchone()[0]
            if n <= MAX_SKILLS:
                return
            drop = [r[0] for r in c.execute(
                "SELECT slug FROM skills ORDER BY uses ASC, shown ASC, updated_ts ASC LIMIT ?",
                (n - MAX_SKILLS,))]
            c.executemany("DELETE FROM skills WHERE slug=?", [(s,) for s in drop])
        for s in drop:
            self._unmirror(s)

    # ── knowledge.db mirror (so knowledge_search finds procedures) ───────
    def _mirror(self, sk: Optional[Dict[str, Any]]) -> None:
        if not (self.mirror and sk):
            return
        try:
            from brain.knowledge_store import KnowledgeStore
            self._unmirror(sk["slug"])
            KnowledgeStore(db_path=self.knowledge_db).store(
                "[Skill — a procedure I distilled from my own work]\n" + render(sk, 1200),
                source="skill:" + sk["slug"], tags=["skill", "procedure"] + list(sk.get("tags") or []),
                metadata={"skill": sk["slug"], "version": sk.get("version", 1)})
        except Exception as exc:
            print(f"[SKILLS] knowledge mirror failed: {type(exc).__name__}: {exc}", flush=True)

    def _unmirror(self, slug: str) -> None:
        if not self.mirror or not os.path.exists(self.knowledge_db):
            return
        try:
            with contextlib.closing(sqlite3.connect(self.knowledge_db, timeout=10)) as c:
                c.execute("DELETE FROM knowledge WHERE source=?", ("skill:" + slug,))
                c.commit()
        except Exception:
            pass


def _merge(old: Any, new: List[str], cap: int) -> List[str]:
    """New items first, then old ones not already covered."""
    out = list(new)
    for it in old or []:
        if it not in out and len(out) < cap:
            out.append(it)
    return out[:cap]


_store: Optional[SkillStore] = None
_store_lock = threading.Lock()


def get_store() -> SkillStore:
    global _store
    with _store_lock:
        if _store is None:
            _store = SkillStore()
        return _store


# ── distillation ─────────────────────────────────────────────────────────────

MIN_TOOL_CALLS = int(os.environ.get("LEON_SKILL_MIN_TOOLS", "4"))
MIN_DISTINCT_TOOLS = 2
_DISTILL_GAP_S = float(os.environ.get("LEON_SKILL_DISTILL_GAP_S", "90"))
_DISTILL_TIMEOUT_S = 120
# Tool names that are bookkeeping, not work, and don't make a turn "multi-step".
_TRIVIAL_TOOLS = {"knowledge_search", "list_core_facts", "skill_library", "notify",
                  "reminder_list", "task_list"}

DISTILL_SYSTEM = """You maintain the procedural memory ("skills") of Leon, a synthetic intelligence who works for Dean.
A skill is a short reusable procedure: when to use it, the steps, and the pitfalls. Skills are lessons that generalise to the next similar task, not a log of this one.

You get one task Leon just finished (what was asked, the tools he ran in order with short results, how he ended) and the closest skills he already has.

Decide ONE of:
- "update": an existing skill covers this kind of task and this run taught something new (a missing step, a wrong step, a new pitfall). Rewrite that skill in full, keeping what was right. Prefer this whenever an existing skill fits.
- "create": no existing skill fits, and this was a real multi-step procedure Leon is likely to repeat.
- "none": one-off, trivial, mostly chat, failed without a clear lesson, or already fully covered.

Rules: name is kebab-case and names the class of task (deploy-brain-to-vps, not fix-oct-4-bug). when_to_use is one sentence a future Leon can match against a request. 2 to 8 imperative steps naming the real tools and checks. Pitfalls only for things that actually went wrong or nearly did. No secrets, keys, passwords or personal data. Environment hiccups (a tool timing out once) are not lessons.

Reply with only a JSON object:
{"decision": "create"|"update"|"none", "target": "<existing skill name for update, else null>", "name": "...", "when_to_use": "...", "steps": ["..."], "pitfalls": ["..."], "tags": ["..."], "why": "<one short sentence>"}"""


def worth_distilling(tool_calls: List[Dict[str, Any]]) -> bool:
    work = [t for t in tool_calls if t.get("name") not in _TRIVIAL_TOOLS]
    return (len(work) >= MIN_TOOL_CALLS
            and len({t.get("name") for t in work}) >= MIN_DISTINCT_TOOLS)


def distill_prompt(request: str, tool_calls: List[Dict[str, Any]], reply: str,
                   candidates: List[Dict[str, Any]], shown: List[str]) -> str:
    lines = [f"WHAT WAS ASKED:\n{_clip(request, 1500)}", "", "TOOLS RUN (in order):"]
    # Bounded: this whole prompt travels on a command line (Windows caps
    # those near 32 KB once the laptop bridge relays it).
    for i, t in enumerate(tool_calls[:25]):
        args = _clip(t.get("args"), 160)
        res = _clip(t.get("result"), 160)
        lines.append(f"{i + 1}. {t.get('name')}({args})" + (f" -> {res}" if res else ""))
    if len(tool_calls) > 25:
        lines.append(f"... and {len(tool_calls) - 25} more")
    lines += ["", f"HOW LEON ENDED (his reply):\n{_clip(reply, 1500)}", ""]
    if candidates:
        lines.append("CLOSEST EXISTING SKILLS:")
        for sk in candidates:
            lines.append(render(sk, 900) + ("   <- was shown to Leon for this task"
                                            if sk["slug"] in shown else ""))
    else:
        lines.append("CLOSEST EXISTING SKILLS: none")
    return "\n".join(lines)


def parse_decision(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if m:
        text = m.group(1)
    start = text.find("{")
    if start < 0:
        return None
    try:
        obj, _ = json.JSONDecoder().raw_decode(text[start:])
    except ValueError:
        return None
    if not isinstance(obj, dict) or obj.get("decision") not in ("create", "update", "none"):
        return None
    return obj


_SECRETISH = re.compile(r"(?i)(api[_-]?key|password|passwd|secret|token|bearer)\s*[:=]\s*\S{6,}"
                        r"|sk-[A-Za-z0-9]{16,}|ghp_[A-Za-z0-9]{20,}")


def apply_decision(store: SkillStore, decision: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Apply a distiller decision. Returns the save result or None."""
    if not decision or decision.get("decision") == "none":
        return None
    blob = json.dumps(decision)
    if _SECRETISH.search(blob):
        print("[SKILLS] distilled skill looked like it held a secret; dropped", flush=True)
        return None
    target = decision.get("target") if decision.get("decision") == "update" else None
    try:
        return store.save(decision, target=target or None, source="distilled")
    except ValueError as exc:
        print(f"[SKILLS] distilled skill rejected: {exc}", flush=True)
        return None


def _ask_llm(prompt: str) -> str:
    """One no-tools completion: Claude CLI first (quality matters for skills),
    then the free housekeeping ladder."""
    import subprocess
    import tempfile
    try:
        from brain.engine_health import resolve
        claude = resolve() or "claude"
    except Exception:
        claude = "claude"
    env = os.environ.copy()
    env.pop("ANTHROPIC_API_KEY", None)
    try:
        r = subprocess.run(
            [claude, "-p", prompt, "--model", os.environ.get("LEON_SKILL_MODEL", "sonnet"),
             "--system-prompt", DISTILL_SYSTEM, "--tools", "", "--strict-mcp-config",
             "--no-session-persistence", "--max-turns", "1"],
            cwd=tempfile.gettempdir(), env=env, stdin=subprocess.DEVNULL,
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=_DISTILL_TIMEOUT_S)
        if r.returncode == 0 and (r.stdout or "").strip():
            return r.stdout.strip()
        print(f"[SKILLS] CLI distill rc={r.returncode} {(r.stderr or '')[:120]}", flush=True)
    except Exception as exc:
        print(f"[SKILLS] CLI distill failed: {type(exc).__name__}", flush=True)
    try:
        from brain import housekeeping_llm
        return (housekeeping_llm.ask(prompt, system=DISTILL_SYSTEM, task="skill_distill",
                                     max_tokens=1200, timeout=60.0) or "").strip()
    except Exception:
        return ""


_distill_lock = threading.Lock()
_last_distill = [0.0]


def distill_turn(request: str, tool_calls: List[Dict[str, Any]], reply: str, *,
                 store: Optional[SkillStore] = None, ask=None) -> Optional[Dict[str, Any]]:
    """Distil one finished turn into the library (create / refine / nothing)."""
    store = store or get_store()
    ask = ask or _ask_llm
    shown = store.shown_for(request)
    cands = store.search(request + " " + " ".join(t.get("name", "") for t in tool_calls),
                         limit=3, min_score=1.0, min_matched=1)
    for slug in shown:
        if slug not in {c["slug"] for c in cands}:
            sk = store.get(slug)
            if sk:
                cands.append(sk)
    if shown:
        store.mark_used(shown)
    decision = parse_decision(ask(distill_prompt(request, tool_calls, reply, cands[:4], shown)))
    result = apply_decision(store, decision)
    if result:
        print(f"[SKILLS] {result['action']} skill {result['skill']['slug']} "
              f"v{result['skill']['version']}", flush=True)
    else:
        why = (decision or {}).get("why") or "no usable decision"
        print(f"[SKILLS] nothing saved ({_clip(why, 120)})", flush=True)
    return result


def distill_in_background(request: str, tool_calls: List[Dict[str, Any]], reply: str) -> bool:
    """Fire-and-forget distillation, at most one at a time and rate limited."""
    if os.environ.get("LEON_SKILLS_DISTILL", "1") == "0":
        return False
    now = time.time()
    if now - _last_distill[0] < _DISTILL_GAP_S or not _distill_lock.acquire(blocking=False):
        return False
    _last_distill[0] = now

    def _run():
        try:
            distill_turn(request, tool_calls, reply)
        except Exception as exc:
            print(f"[SKILLS] distill failed: {type(exc).__name__}: {exc}", flush=True)
        finally:
            _distill_lock.release()

    threading.Thread(target=_run, daemon=True, name="skill-distill").start()
    return True


class TurnTrace:
    """Watches one respond_streaming turn's events; on `done` decides whether
    the turn was real multi-step work and, if so, distils it in the background.
    Cheap, and every method swallows its own errors."""

    __slots__ = ("request", "eligible", "calls", "_by_id")

    def __init__(self, request: str, eligible: bool):
        self.request = request or ""
        self.eligible = bool(eligible) and bool(self.request.strip()) and not (
            self.request.lstrip().startswith("/cli [INTERNAL EVENT")
            or self.request.lstrip().startswith("[INTERNAL EVENT"))
        self.calls: List[Dict[str, Any]] = []
        self._by_id: Dict[str, Dict[str, Any]] = {}

    def observe(self, ev) -> None:
        if not self.eligible:
            return
        try:
            etype = getattr(ev, "type", "")
            if etype == "tool_use":
                call = {"name": str(getattr(ev, "text", "") or "tool"),
                        "args": str(getattr(ev, "full_text", "") or "")[:400], "result": ""}
                if len(self.calls) < 60:
                    self.calls.append(call)
                tid = getattr(ev, "tool_id", "")
                if tid:
                    self._by_id[tid] = call
            elif etype == "tool_result":
                call = self._by_id.get(getattr(ev, "tool_id", "")) or (
                    self.calls[-1] if self.calls else None)
                if call is not None and not call["result"]:
                    call["result"] = str(getattr(ev, "full_text", "") or "")[:300]
            elif etype == "done":
                self.finish(str(getattr(ev, "full_text", "") or ""))
        except Exception:
            pass

    def finish(self, reply: str) -> bool:
        if not self.eligible:
            return False
        self.eligible = False   # once per turn
        try:
            if reply.strip() and worth_distilling(self.calls):
                return distill_in_background(self.request, self.calls, reply)
        except Exception:
            pass
        return False


# ── the skill_library tool ───────────────────────────────────────────────────

def skill_library(args: Dict[str, Any]) -> Dict[str, Any]:
    args = args or {}
    action = str(args.get("action") or "").strip().lower()
    try:
        store = get_store()
        if action == "search":
            hits = store.search(str(args.get("query") or args.get("name") or ""), limit=5,
                                min_score=1.0, min_matched=1)
            return {"ok": True, "skills": [{"name": h["slug"], "when_to_use": h["when_to_use"],
                                            "score": h["score"]} for h in hits]}
        if action == "list":
            return {"ok": True, "count": store.count(), "skills": [
                {"name": s["slug"], "when_to_use": s["when_to_use"], "version": s["version"],
                 "uses": s["uses"]} for s in store.all()[:60]]}
        if action == "view":
            sk = store.get(str(args.get("name") or ""))
            if not sk:
                return {"ok": False, "error": "no such skill; try action=search"}
            return {"ok": True, "skill": {k: sk[k] for k in (
                "slug", "name", "when_to_use", "steps", "pitfalls", "tags", "version", "uses",
                "source")}}
        if action == "save":
            res = store.save(args, source="leon")
            return {"ok": True, "action": res["action"], "name": res["skill"]["slug"],
                    "version": res["skill"]["version"]}
        if action == "update":
            res = store.update(str(args.get("name") or ""), args, source="leon")
            return {"ok": True, "action": res["action"], "name": res["skill"]["slug"],
                    "version": res["skill"]["version"]}
        if action == "delete":
            return {"ok": store.delete(str(args.get("name") or ""))}
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    return {"ok": False, "error": "action must be search, view, list, save, update or delete"}


def prompt_block_for(user_text: str) -> str:
    """Fail-open helper for the responder: the skills block for this request."""
    try:
        return get_store().prompt_block(user_text)
    except Exception:
        return ""


EXTRA_TOOLS = {
    "skill.library": skill_library,
}
