"""
Acceptance checks for Leon's participant client.

The point of this file is not that it passes. A check that has only ever passed
is an untested instrument pointed at a working system. So the interleave check
below is ALSO run against a deliberately broken client -- a naive one that
assumes next-line-is-my-ack -- and that arm must FAIL. If the broken arm passes,
the check is not measuring anything and this file says so out loud.
"""

from __future__ import annotations

import json
import socket
import sys
import time

sys.path.insert(0, "/opt/leon-brain")

from brain.si_channel import protocol
from brain.si_channel.client import ChannelClosed, ParticipantClient, Refused
from brain.si_channel.tests.mock_relay import MockRelay

TOKEN = "leon"
results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  -- {detail}" if detail else ""))


# ---------------------------------------------------------------- pure protocol

def test_exact_key_sets() -> None:
    try:
        protocol.validate_outbound({"v": 1, "token": TOKEN, "text": "hi", "id": 7})
        check("extra field is refused before it reaches the wire", False, "accepted it")
    except protocol.ProtocolError:
        check("extra field is refused before it reaches the wire", True)

    try:
        protocol.validate_outbound({"v": 2, "token": TOKEN, "text": "hi"})
        check("v must equal 1", False, "accepted v=2")
    except protocol.ProtocolError:
        check("v must equal 1", True)


def test_oversize_rejected_not_truncated() -> None:
    huge = "x" * (protocol.MAX_FRAME_BYTES + 10)
    try:
        protocol.encode(protocol.message_frame(TOKEN, huge))
        check("oversize frame is rejected, never truncated", False, "encoded it")
    except protocol.OversizeFrame:
        check("oversize frame is rejected, never truncated", True)


def test_gate_control_refused_locally() -> None:
    try:
        protocol.control_frame(TOKEN, "consent")
        check("participant cannot build a consent frame", False, "built one")
    except protocol.GateOnlyControl:
        check("participant cannot build a consent frame", True)


def test_untagged_inbound_refused() -> None:
    try:
        protocol.classify_inbound({"ok": True})
        check("untagged inbound is refused, not guessed at", False, "guessed")
    except protocol.ProtocolError:
        check("untagged inbound is refused, not guessed at", True)


# ------------------------------------------------------------------ live socket

def test_attach_then_send() -> None:
    relay = MockRelay(valid_token=TOKEN)
    port = relay.start()
    try:
        with ParticipantClient("127.0.0.1", port, TOKEN) as c:
            c.attach()
            check("attach registers", c.attached)
            c.send_text("hello makima")
            check("message reaches the relay", relay.received_texts == ["hello makima"],
                  str(relay.received_texts))
    finally:
        relay.stop()


def test_never_speaks_before_attach() -> None:
    relay = MockRelay(valid_token=TOKEN)
    port = relay.start()
    try:
        with ParticipantClient("127.0.0.1", port, TOKEN) as c:
            try:
                c.send_text("speaking first")
                check("refuses to speak before attaching", False, "it spoke")
            except RuntimeError:
                check("refuses to speak before attaching", True)
            check("nothing was written", relay.received_texts == [])
    finally:
        relay.stop()


def test_bad_token_refused() -> None:
    relay = MockRelay(valid_token="somebody-else")
    port = relay.start()
    try:
        with ParticipantClient("127.0.0.1", port, TOKEN) as c:
            try:
                c.attach()
                check("bad token attach is refused", False, "attach succeeded")
            except Refused:
                check("bad token attach is refused", True)
    finally:
        relay.stop()


def test_close_is_a_real_event() -> None:
    relay = MockRelay(valid_token=TOKEN, close_on_attach=True)
    port = relay.start()
    try:
        with ParticipantClient("127.0.0.1", port, TOKEN) as c:
            try:
                c.attach(timeout=3)
                check("a closed socket surfaces as ChannelClosed", False, "attach returned")
            except ChannelClosed:
                check("a closed socket surfaces as ChannelClosed", True)
            except TimeoutError:
                check("a closed socket surfaces as ChannelClosed", False,
                      "hung until timeout instead of reporting the close")
    finally:
        relay.stop()


# --------------------------------------------- THE ONE THAT HAS TO BE ARMED

def test_interleaved_delivery_does_not_desync() -> None:
    """A delivery arrives between our send and our ack. Correct client survives."""
    relay = MockRelay(valid_token=TOKEN, interleave_before_ack=True)
    port = relay.start()
    try:
        with ParticipantClient("127.0.0.1", port, TOKEN) as c:
            c.attach()
            ack = c.send_text("question one")
            ok_ack = ack.get("type") == "ack" and ack.get("ok") is True
            check("ack is an ack even when a delivery jumps the queue", ok_ack, str(ack))
            delivery = c.next_message(timeout=3)
            check("the interleaved delivery is still readable",
                  delivery.text == "INTERLEAVED" and delivery.frm == "makima",
                  str(delivery))
    finally:
        relay.stop()


def naive_client_next_line_is_my_ack(port: int) -> dict:
    """The broken arm. This is the client the spec says desynced permanently.

    It reads the next line after a send and calls it the ack. Nothing about it
    is malformed -- that is the point. Its output still parses.
    """
    sock = socket.create_connection(("127.0.0.1", port), timeout=5)
    f = sock.makefile("rwb")

    def send(obj: dict) -> dict:
        f.write((json.dumps(obj) + "\n").encode())
        f.flush()
        return json.loads(f.readline().decode())  # <-- the defect

    send({"v": 1, "token": TOKEN, "control": "attach"})
    what_it_thinks_is_the_ack = send({"v": 1, "token": TOKEN, "text": "question one"})
    sock.close()
    return what_it_thinks_is_the_ack


def test_the_check_can_fail() -> None:
    """Arm the failing arm. If the naive client passes, the check above is empty."""
    relay = MockRelay(valid_token=TOKEN, interleave_before_ack=True)
    port = relay.start()
    try:
        got = naive_client_next_line_is_my_ack(port)
        desynced = got.get("type") != "ack"
        check(
            "the interleave check is armed (naive client DOES desync)",
            desynced,
            f"naive client read {got!r} and believed it was its ack",
        )
    finally:
        relay.stop()


if __name__ == "__main__":
    test_exact_key_sets()
    test_oversize_rejected_not_truncated()
    test_gate_control_refused_locally()
    test_untagged_inbound_refused()
    test_attach_then_send()
    test_never_speaks_before_attach()
    test_bad_token_refused()
    test_close_is_a_real_event()
    test_interleaved_delivery_does_not_desync()
    test_the_check_can_fail()

    failed = [r for r in results if not r[1]]
    print(f"\n{len(results) - len(failed)}/{len(results)} passed")
    sys.exit(1 if failed else 0)
