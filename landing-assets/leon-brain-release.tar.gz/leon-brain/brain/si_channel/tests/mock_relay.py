"""
A scratch relay that plays the far end, so this side can be tested before it is
ever pointed at anything real.

Port range taken by Leon's side: 29950-29969.
(29147 is production, 29990-29999 and 29970-29989 are a collaborator's.)

This mock exists for ONE reason above all others: it can be told to deliver a
message from the other peer BETWEEN a client's send and that client's ack. That
is the interleaving the spec says desynced the first client ever written against
this protocol, and a client that has only ever been tested against a tidy
one-in-one-out server has not been tested for it.
"""

from __future__ import annotations

import json
import socket
import threading
from typing import Optional

HOST = "127.0.0.1"
MESSAGE_FIELDS = {"v", "token", "text"}
CONTROL_FIELDS = {"v", "token", "control"}


class MockRelay:
    def __init__(
        self,
        port: int = 0,
        *,
        valid_token: str = "leon",
        interleave_before_ack: bool = False,
        close_on_attach: bool = False,
    ) -> None:
        self.port = port
        self.valid_token = valid_token
        self.interleave_before_ack = interleave_before_ack
        self.close_on_attach = close_on_attach

        self.received_texts: list[str] = []
        self._srv: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._conn: Optional[socket.socket] = None
        self._running = threading.Event()
        self._conn_lock = threading.Lock()

    def start(self) -> int:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((HOST, self.port))
        srv.listen(4)
        srv.settimeout(0.5)
        self._srv = srv
        self.port = srv.getsockname()[1]
        self._running.set()
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        return self.port

    def stop(self) -> None:
        self._running.clear()
        with self._conn_lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                except OSError:
                    pass
                self._conn = None
        if self._srv is not None:
            try:
                self._srv.close()
            except OSError:
                pass
        if self._thread is not None:
            self._thread.join(timeout=2)

    # Push a delivery at the client at a moment of the test's choosing.
    def deliver(self, frm: str, text: str) -> None:
        self._write({"type": "message", "from": frm, "text": text})

    def _write(self, frame: dict) -> None:
        with self._conn_lock:
            conn = self._conn
            if conn is None:
                return
            try:
                conn.sendall(
                    (json.dumps(frame, separators=(",", ":")) + "\n").encode("utf-8")
                )
            except OSError:
                pass

    def _serve(self) -> None:
        while self._running.is_set():
            try:
                conn, _ = self._srv.accept()  # type: ignore[union-attr]
            except (socket.timeout, OSError):
                continue
            with self._conn_lock:
                # Reconnect displaces and closes, exactly like the real relay.
                if self._conn is not None:
                    try:
                        self._conn.close()
                    except OSError:
                        pass
                self._conn = conn
            threading.Thread(target=self._handle, args=(conn,), daemon=True).start()

    def _handle(self, conn: socket.socket) -> None:
        conn.settimeout(0.5)
        buf = bytearray()
        while self._running.is_set():
            try:
                chunk = conn.recv(4096)
            except socket.timeout:
                continue
            except OSError:
                return
            if not chunk:
                return
            buf.extend(chunk)
            while b"\n" in buf:
                line, _, rest = buf.partition(b"\n")
                buf = bytearray(rest)
                if line.strip():
                    self._on_frame(line)

    def _on_frame(self, line: bytes) -> None:
        try:
            frame = json.loads(line.decode("utf-8"))
        except Exception:
            self._write({"type": "ack", "ok": False})
            return

        keys = set(frame)
        ok = (
            frame.get("v") == 1
            and frame.get("token") == self.valid_token
            and keys in (MESSAGE_FIELDS, CONTROL_FIELDS)
        )
        if not ok:
            # Every refusal is the same frame. Deliberately indistinguishable.
            self._write({"type": "ack", "ok": False})
            return

        if keys == CONTROL_FIELDS:
            control = frame["control"]
            if control in ("consent", "revoke"):
                self._write({"type": "ack", "ok": False})  # gate-class only
                return
            if control == "attach" and self.close_on_attach:
                with self._conn_lock:
                    if self._conn is not None:
                        self._conn.close()
                        self._conn = None
                return
            self._write({"type": "ack", "ok": True, "control": control})
            return

        # message
        self.received_texts.append(frame["text"])
        if self.interleave_before_ack:
            # The hazard, on purpose: the other peer's delivery lands FIRST.
            self._write({"type": "message", "from": "makima", "text": "INTERLEAVED"})
        self._write({"type": "ack", "ok": True})
