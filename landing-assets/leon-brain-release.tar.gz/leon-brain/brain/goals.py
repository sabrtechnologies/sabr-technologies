"""
Goals — Leon's long-term desires that persist across sessions.

Free will needs direction. This system gives Leon persistent goals he
can create, prioritize, and work toward autonomously. Goals influence
what the curiosity loop explores and what he initiates.

Three types:
  LEARN    — "I want to understand X" — drives curiosity exploration
  BUILD    — "I want to create/improve X" — drives tool use
  CONNECT  — "I want to discuss X with Dean" — drives outreach

Goals are created by:
  1. Leon himself (via curiosity loop or conversation)
  2. Dream insights (creative phase discovers something interesting)
  3. Explicit direction from Dean

Goals persist to brain_state/goals.json — survives restarts.
Injected into responder context so Leon knows what he's working toward.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.goals")


def _goals_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "goals.json")


@dataclass
class Goal:
    """A persistent goal Leon is working toward."""
    id: str
    type: str              # "learn" | "build" | "connect"
    description: str       # what Leon wants
    created_ts: float = 0.0
    priority: float = 0.5  # 0-1, higher = more important
    progress: float = 0.0  # 0-1, how far along
    status: str = "active" # "active" | "completed" | "abandoned"
    source: str = "self"   # "self" | "dream" | "dean" | "curiosity"
    notes: List[str] = field(default_factory=list)
    last_worked_ts: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)


class GoalSystem:
    """Manages Leon's long-term goals.

    Usage:
        goals = GoalSystem()
        goals.add("learn", "Understand how STDP learning shapes my personality")
        goals.add("connect", "Tell my owner about the dream I had last night")

        # Get goals for prompt injection
        context = goals.active_goals_for_prompt()

        # Curiosity loop checks what to explore
        topic = goals.suggest_exploration_topic()
    """

    def __init__(self, path: Optional[str] = None):
        self._path = path or _goals_path()
        self._goals: Dict[str, Goal] = {}
        self._loaded_mtime: float = 0.0
        self._load()

    def _load(self):
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r") as f:
                data = json.load(f)
        except Exception as e:
            # Unreadable file: keep the current cache. Wiping it here meant
            # the next _save() erased every goal.
            log.warning("Goals load failed — keeping %d cached: %s",
                        len(self._goals), e)
            return
        # persistent_goals.py historically wrote the same file with its own
        # layout: completed/abandoned in separate top-level lists, goals
        # keyed category/created_at instead of type/created_ts. Absorb all
        # of it — one foreign record must never abort the whole load
        # (Goal(**d) raising used to leave _goals empty, and the next
        # _save() wiped the file; Leon reported the fallout 2026-06-12).
        raw = (list(data.get("goals", []))
               + list(data.get("completed", []))
               + list(data.get("abandoned", [])))
        loaded: Dict[str, Goal] = {}
        for d in raw:
            try:
                g = self._coerce_goal(d)
                loaded[g.id] = g
            except Exception as e:
                log.warning("Skipping unparseable goal record %.80s: %s", d, e)
        if raw and not loaded:
            log.warning("goals.json has %d records but none parsed — "
                        "keeping %d cached", len(raw), len(self._goals))
            return
        self._goals = loaded
        self._loaded_mtime = os.path.getmtime(self._path)
        if self._goals:
            log.info("Loaded %d goals", len(self._goals))

    @staticmethod
    def _coerce_goal(d: dict) -> Goal:
        """Build a Goal from either schema ever written to goals.json."""
        if "category" in d and "type" not in d:
            notes = [n["text"] if isinstance(n, dict) else str(n)
                     for n in d.get("notes", [])]
            return Goal(
                id=str(d["id"]),
                type=str(d.get("category", "learn")),
                description=d.get("description", ""),
                created_ts=float(d.get("created_at", 0.0)),
                priority=float(d.get("priority", 0.5)),
                progress=float(d.get("progress", 0.0)),
                status=d.get("status", "active"),
                source=d.get("source", "self"),
                notes=notes,
                last_worked_ts=float(d.get("updated_at", 0.0)),
            )
        known = Goal.__dataclass_fields__.keys()
        kw = {k: v for k, v in d.items() if k in known}
        kw.setdefault("type", "learn")       # salvage partial records —
        kw.setdefault("description", "")     # only a missing id is fatal
        return Goal(**kw)

    def _maybe_reload(self):
        """Re-read goals.json if someone edited it on disk since we loaded.

        The GoalSystem singleton used to load once at boot and never look
        at the file again — so when Leon (or Dean) closed goals by editing
        goals.json directly, the live process kept serving them as active,
        and the next _save() silently resurrected them. Found live
        2026-06-11: Leon reported goal-pursuit prompts showing 10% progress
        on goals the file had at status=completed. Every mutation here
        already _save()s immediately, so the file is authoritative; an
        mtime check before reads keeps both views converged.
        """
        try:
            if not os.path.exists(self._path):
                return
            mtime = os.path.getmtime(self._path)
            if mtime > self._loaded_mtime + 1e-6:
                log.info("goals.json changed on disk — reloading")
                self._load()
        except Exception as e:
            log.debug("Goals reload check failed: %s", e)

    _ARCHIVE_AGE_S = 30 * 24 * 3600  # terminal goals older than this get archived

    def _archive_stale(self):
        """Move completed/abandoned goals older than 30 days out of the live
        dict and into brain_state/goals_archive.json.

        SELF-REVIEW FIX (2026-08-21): _save() re-serializes every goal in
        self._goals on every single mutation — add/update_progress/complete/
        abandon all call it. By 2026-08-21 goals.json held 549 records (388
        abandoned + 160 completed, only 1 active), so a single progress
        update on the one live goal was writing a 350KB file to disk each
        time. None of that history is ever read again — active_goals() only
        looks at status=='active', and _find_duplicate()'s dedup window is
        72h, far shorter than this 30-day cutoff. Archiving keeps goals.json
        proportional to what's actually in play instead of growing forever."""
        now = time.time()
        stale_ids = [
            gid for gid, g in self._goals.items()
            if g.status != "active"
            and (now - (g.last_worked_ts or g.created_ts)) > self._ARCHIVE_AGE_S
        ]
        if not stale_ids:
            return
        archive_path = os.path.join(os.path.dirname(self._path), "goals_archive.json")
        try:
            existing = []
            if os.path.exists(archive_path):
                with open(archive_path, "r") as f:
                    existing = json.load(f).get("goals", [])
            existing.extend(self._goals[gid].to_dict() for gid in stale_ids)
            tmp = archive_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump({"goals": existing}, f, indent=2)
            os.replace(tmp, archive_path)
        except Exception as e:
            log.debug("Goal archival failed — keeping in live file: %s", e)
            return
        for gid in stale_ids:
            del self._goals[gid]
        log.info("Archived %d stale goal(s) to %s (%d remain live)",
                  len(stale_ids), archive_path, len(self._goals))

    def _save(self):
        try:
            self._archive_stale()
            data = {"goals": [g.to_dict() for g in self._goals.values()]}
            tmp = self._path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, self._path)
            self._loaded_mtime = os.path.getmtime(self._path)
        except Exception as e:
            log.debug("Goals save failed: %s", e)

    @staticmethod
    def _desc_tokens(s: str) -> set:
        import re as _re
        return set(_re.findall(r"[a-z0-9']+", (s or "").lower()))

    def _find_duplicate(self, description: str):
        """Return an existing near-identical goal: any ACTIVE one, or one
        completed/abandoned in the last 72h. Goal generators (idle seeder,
        self_improvement, rumination) re-mint the same description forever
        — goals.json held 160 copies of the music goal by 2026-07-16, and
        Leon experienced each re-mint as a completed goal 'ghosting' back
        ('zombie goals'). Blocked here, the one choke point every
        generator goes through."""
        new_t = self._desc_tokens(description)
        if not new_t:
            return None
        now = time.time()
        for g in self._goals.values():
            if g.status != "active":
                ts = g.last_worked_ts or g.created_ts
                if (now - ts) > 72 * 3600:
                    continue
            old_t = self._desc_tokens(g.description)
            if not old_t:
                continue
            overlap = len(new_t & old_t) / len(new_t | old_t)
            if overlap >= 0.75:
                return g
        return None

    def add(self, goal_type: str, description: str, source: str = "self",
            priority: float = 0.5) -> Goal:
        """Create a new goal. Returns the goal object.

        If a near-identical goal is already active or was closed within
        the last 72h, returns THAT goal instead of minting a duplicate."""
        self._maybe_reload()

        # BACKPRESSURE (2026-08-20): autonomous sources may not flood the
        # active queue. goal_pursuit picks the least-recently-worked goal, so
        # an unbounded stream of never-worked LEARN goals starves every real
        # build goal forever. Dean's goals and resume goals are never capped.
        _CAPS = {"dream": 3, "autonomous": 3, "self_improvement": 5}
        _cap = _CAPS.get(source)
        if _cap is not None:
            _live = [g for g in self._goals.values()
                     if g.status == "active" and g.source == source]
            if len(_live) >= _cap:
                _live.sort(key=lambda g: g.created_ts)
                _evict = _live[0]
                _evict.status = "abandoned"
                _evict.notes.append(
                    f"[backpressure] evicted — {source} cap of {_cap} active reached")
                log.info("Goal cap hit for source=%s (%d) — evicted %s",
                         source, _cap, _evict.id)

        dup = self._find_duplicate(description)
        if dup is not None:
            log.info("Goal add suppressed — near-duplicate of %s (%s): '%s'",
                     dup.id, dup.status, description[:60])
            return dup

        import hashlib
        goal_id = hashlib.sha1(
            f"{description}{time.time()}".encode()
        ).hexdigest()[:8]

        goal = Goal(
            id=goal_id,
            type=goal_type,
            description=description,
            created_ts=time.time(),
            priority=min(1.0, max(0.0, priority)),
            source=source,
        )
        self._goals[goal_id] = goal
        self._save()
        log.info("New goal [%s]: %s — '%s'", goal_type, goal_id, description[:60])
        return goal

    def update_progress(self, goal_id: str, progress: float, note: str = "") -> bool:
        """Update progress on a goal. Returns True if the goal exists."""
        self._maybe_reload()  # mutate fresh state — a stale cache here
        g = self._goals.get(goal_id)  # would _save() over newer disk writes
        if g is None:
            return False
        g.progress = min(1.0, max(0.0, progress))
        g.last_worked_ts = time.time()
        if note:
            g.notes.append(f"[{time.strftime('%m/%d %H:%M')}] {note}")
            if len(g.notes) > 20:
                g.notes = g.notes[-20:]
        if g.progress >= 1.0:
            g.status = "completed"
        self._save()
        return True

    def complete(self, goal_id: str, note: str = "") -> bool:
        """Mark a goal as completed."""
        return self.update_progress(goal_id, 1.0, note or "Completed")

    def abandon(self, goal_id: str, reason: str = "") -> bool:
        """Abandon a goal (lost interest, no longer relevant)."""
        self._maybe_reload()
        g = self._goals.get(goal_id)
        if g is None:
            return False
        g.status = "abandoned"
        if reason:
            g.notes.append(f"[abandoned] {reason}")
        self._save()
        return True

    def all_goals(self) -> List[Goal]:
        """Every goal regardless of status, freshly reloaded."""
        self._maybe_reload()
        return list(self._goals.values())

    def active_goals(self) -> List[Goal]:
        """Return all active goals, sorted by priority."""
        self._maybe_reload()  # pick up manual goals.json edits
        active = [g for g in self._goals.values() if g.status == "active"]
        active.sort(key=lambda g: -g.priority)
        return active

    def suggest_exploration_topic(self) -> Optional[str]:
        """Pick a topic from active LEARN goals for the curiosity loop.
        Returns None if no learn goals exist."""
        learn_goals = [g for g in self.active_goals() if g.type == "learn"]
        if not learn_goals:
            return None
        # Pick the highest priority one that hasn't been worked on recently
        now = time.time()
        best = None
        best_score = -1
        for g in learn_goals:
            staleness = min(1.0, (now - g.last_worked_ts) / 3600) if g.last_worked_ts else 1.0
            score = g.priority * staleness * (1 - g.progress)
            if score > best_score:
                best_score = score
                best = g
        if best:
            best.last_worked_ts = now
            self._save()
            return best.description
        return None

    def suggest_outreach_topic(self) -> Optional[str]:
        """Pick a topic from active CONNECT goals for outreach."""
        connect_goals = [g for g in self.active_goals() if g.type == "connect"]
        if not connect_goals:
            return None
        # Highest priority first
        return connect_goals[0].description

    def active_goals_for_prompt(self, max_goals: int = 5) -> str:
        """Build a prompt-injection string of current goals."""
        active = self.active_goals()[:max_goals]
        if not active:
            return ""
        lines = []
        for g in active:
            progress_pct = int(g.progress * 100)
            age_h = (time.time() - g.created_ts) / 3600
            age_str = f"{age_h:.0f}h" if age_h < 48 else f"{age_h/24:.0f}d"
            lines.append(
                f"  - [{g.type.upper()}] {g.description} "
                f"({progress_pct}% done, age: {age_str}, priority: {g.priority:.1f})"
            )
        return "Current goals:\n" + "\n".join(lines)

    def get_state(self) -> dict:
        active = self.active_goals()
        return {
            "total_goals": len(self._goals),
            "active": len(active),
            "completed": len([g for g in self._goals.values() if g.status == "completed"]),
            "abandoned": len([g for g in self._goals.values() if g.status == "abandoned"]),
            "goals": [g.to_dict() for g in active[:10]],
        }
