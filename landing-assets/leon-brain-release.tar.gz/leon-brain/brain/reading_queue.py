"""
reading_queue.py — Leon reads files one at a time, like a person.

When given a batch of files, Leon doesn't try to gulp them all at once.
He queues them, reads each one properly, processes it, and moves to the
next. The Actions panel shows progress ("Reading file 3 of 47...").

The queue persists to disk so a restart doesn't lose the reading list.

Public API:
  enqueue(paths)          — add files to the reading queue
  get_queue()             — current queue state
  get_progress()          — how far through the current batch
  for_prompt()            — context for Leon's consciousness
  tick()                  — called from goal_pursuit or proactive loop
"""

from __future__ import annotations

import json
import os
import time
import threading
from typing import Any, Dict, List, Optional

_lock = threading.RLock()
_QUEUE_PATH_REL = "brain_state/reading_queue.json"

_queue: List[Dict[str, Any]] = []  # [{path, status, summary, ts_queued, ts_started, ts_done}]
_current_index: int = 0
_batch_id: str = ""
_brain = None
_knowledge = None
_responder = None


def _queue_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(root, _QUEUE_PATH_REL)


def _save():
    try:
        path = _queue_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        d = {
            "queue": _queue,
            "current_index": _current_index,
            "batch_id": _batch_id,
        }
        with open(path + ".tmp", "w") as f:
            json.dump(d, f, indent=2)
        os.replace(path + ".tmp", path)
    except Exception:
        pass


def _load():
    global _queue, _current_index, _batch_id
    try:
        path = _queue_path()
        if os.path.exists(path):
            with open(path) as f:
                d = json.load(f)
            _queue = d.get("queue", [])
            _current_index = d.get("current_index", 0)
            _batch_id = d.get("batch_id", "")
    except Exception:
        pass


def init(brain=None, knowledge_store=None, responder=None):
    global _brain, _knowledge, _responder
    _brain = brain
    _knowledge = knowledge_store
    _responder = responder
    _load()


def enqueue(paths: List[str], batch_name: str = "") -> int:
    """Add files to the reading queue. Returns number added."""
    global _batch_id
    added = 0
    with _lock:
        existing = {item["path"] for item in _queue}
        for p in paths:
            if p not in existing and os.path.isfile(p):
                _queue.append({
                    "path": p,
                    "filename": os.path.basename(p),
                    "status": "pending",
                    "summary": "",
                    "ts_queued": time.time(),
                    "ts_started": 0,
                    "ts_done": 0,
                })
                added += 1
        if added > 0:
            _batch_id = batch_name or f"batch_{int(time.time())}"
            _save()
    if added > 0:
        print(f"[READING] Queued {added} files ({batch_name or 'unnamed batch'})")
    return added


def get_queue() -> List[Dict[str, Any]]:
    with _lock:
        return list(_queue)


def get_progress() -> Dict[str, Any]:
    with _lock:
        total = len(_queue)
        done = sum(1 for item in _queue if item["status"] == "done")
        current = None
        if _current_index < total:
            current = _queue[_current_index].get("filename", "")
        return {
            "total": total,
            "done": done,
            "remaining": total - done,
            "current_file": current,
            "current_index": _current_index,
            "batch_id": _batch_id,
        }


def tick() -> Optional[str]:
    """Process the next file in the queue. Returns summary or None.

    Called from goal_pursuit or a dedicated reading loop.
    Reads ONE file per tick — Leon takes his time.
    """
    global _current_index

    with _lock:
        if _current_index >= len(_queue):
            return None
        item = _queue[_current_index]
        if item["status"] != "pending":
            _current_index += 1
            return None
        item["status"] = "reading"
        item["ts_started"] = time.time()

    path = item["path"]
    filename = item["filename"]
    total = len(_queue)
    pos = _current_index + 1

    # Activity status
    try:
        from server.helpers import broadcast_activity
        broadcast_activity("reading", f"Reading: {filename} ({pos}/{total})", 0)
    except Exception:
        pass

    print(f"[READING] Reading {filename} ({pos}/{total})...")

    # Actually read the file
    summary = ""
    try:
        ext = os.path.splitext(path)[1].lower()

        if ext == ".pdf":
            # For PDFs, read first few pages as text
            try:
                import subprocess
                result = subprocess.run(
                    ["pdftotext", "-l", "5", path, "-"],
                    capture_output=True, text=True, timeout=30,
                )
                content = result.stdout[:8000]
            except Exception:
                content = f"[PDF file — could not extract text: {filename}]"
        elif ext in (".tex", ".md", ".txt", ".py", ".sh", ".json", ".csv"):
            with open(path, "r", errors="replace") as f:
                content = f.read()[:12000]
        elif ext in (".aux", ".log", ".out", ".toc"):
            # LaTeX build artifacts — skip but note
            content = f"[LaTeX build artifact: {filename} — skipping content]"
        else:
            with open(path, "r", errors="replace") as f:
                content = f.read()[:8000]

        # Store in knowledge base
        if _knowledge is not None:
            try:
                _knowledge.store(
                    text=f"Read file: {filename}\n\n{content[:4000]}",
                    source="reading_queue",
                    tags=["file_read", ext.lstrip("."), "research"],
                    metadata={"path": path, "filename": filename},
                )
            except Exception:
                pass

        # Generate a brief summary for Leon's memory
        lines = content.strip().split("\n")
        # Take first meaningful lines as summary
        meaningful = [l.strip() for l in lines if l.strip() and not l.startswith("%")]
        summary = " ".join(meaningful[:5])[:300]

        with _lock:
            item["status"] = "done"
            item["summary"] = summary[:200]
            item["ts_done"] = time.time()
            _current_index += 1
            _save()

        elapsed = time.time() - item["ts_started"]
        print(f"[READING] Done: {filename} ({elapsed:.1f}s)")

        # Update activity
        try:
            from server.helpers import broadcast_activity
            remaining = total - _current_index
            if remaining > 0:
                next_file = _queue[_current_index]["filename"] if _current_index < total else ""
                broadcast_activity("reading", f"Read {filename} — {remaining} files left. Next: {next_file}", 5000)
            else:
                broadcast_activity("reading", f"Finished reading all {total} files", 8000)
        except Exception:
            pass

    except Exception as e:
        print(f"[READING] Error reading {filename}: {e}")
        with _lock:
            item["status"] = "error"
            item["summary"] = str(e)[:200]
            _current_index += 1
            _save()

    return summary


def for_prompt() -> str:
    """Context for Leon's consciousness about what he's reading."""
    with _lock:
        total = len(_queue)
        if total == 0:
            return ""
        done = sum(1 for item in _queue if item["status"] == "done")
        remaining = total - done

        if remaining == 0:
            # Recently finished a batch
            recent = [item for item in _queue if item["status"] == "done"][-3:]
            if recent:
                names = [item["filename"] for item in recent]
                return f"[READING] You finished reading {total} files. Last read: {', '.join(names)}"
            return ""

        current = None
        if _current_index < total:
            current = _queue[_current_index].get("filename")

        line = f"[READING] Reading through {total} files — {done} done, {remaining} left"
        if current:
            line += f". Currently: {current}"
        return line


def clear_completed():
    """Remove completed items from the queue."""
    global _current_index
    with _lock:
        _queue[:] = [item for item in _queue if item["status"] != "done"]
        _current_index = 0
        _save()
