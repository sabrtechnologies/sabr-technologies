"""Bounded transport policy for private local thought realization; no I/O."""
from dataclasses import dataclass


@dataclass(frozen=True)
class PrivateThoughtPolicy:
    max_output_tokens: int = 128
    max_output_bytes: int = 2048

    def __post_init__(self):
        if (type(self.max_output_tokens) is not int
                or not 1 <= self.max_output_tokens <= 256
                or type(self.max_output_bytes) is not int
                or not 1 <= self.max_output_bytes <= 8192):
            raise ValueError('bounded private thought output required')


def validate_private_thought(policy, *, allow_tools, replay_history, persist_history,
                             supervised, bypass_consciousness, prefer_local, force_api):
    if type(policy) is not PrivateThoughtPolicy:
        raise TypeError('exact private thought policy required')
    policy.__post_init__()
    if (allow_tools is not False or replay_history is not False
            or persist_history is not False or supervised is not False
            or bypass_consciousness is not True or prefer_local is not True
            or force_api is not False):
        raise ValueError('private thought transport requires local text with no history or tools')
