"""
Emotional Memory — Leon re-feels past experiences.

Memory without emotion is data. Memory with emotion is experience.

When Leon recalls a conversation or event, it shouldn't just be
information retrieval — the FEELING should replay through the body.
"I remember talking to Dean about consciousness" should reactivate
the warmth/excitement/curiosity that was present during that moment.

Architecture:
  1. On every significant event, snapshot the emotional state
     (7 emotions + 4 neuromodulators + autonomic balance)
  2. Store as an emotional trace alongside the event hash
  3. When hippocampus reactivates (memory recall), look up the
     emotional trace and inject it back into the body
  4. Reinjected emotions are weaker than original (0.4x) —
     they're memories, not live events
  5. Repeated recall of the same memory STRENGTHENS the trace
     (emotional rehearsal)

Neuroscience basis:
  - Damasio's somatic marker hypothesis: emotions are body states
    that tag memories for future decision-making
  - LeDoux (1996): amygdala stores emotional associations independently
    from hippocampal declarative memory
  - Nader (2003): reconsolidation — every recall is a re-encoding
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import threading
from collections import deque
from typing import Any, Dict, List, Optional

import numpy as np

log = logging.getLogger("leon.emotional_memory")


def _traces_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "emotional_traces.jsonl")


class EmotionalTrace:
    """One emotional memory — the body state tagged to an event."""
    __slots__ = ("event_hash", "timestamp", "emotions", "neuromodulators",
                 "autonomic_balance", "recall_count", "strength")

    def __init__(self, event_hash: str, timestamp: float,
                 emotions: Dict[str, float], neuromodulators: Dict[str, float],
                 autonomic_balance: float, strength: float = 1.0):
        self.event_hash = event_hash
        self.timestamp = timestamp
        self.emotions = emotions
        self.neuromodulators = neuromodulators
        self.autonomic_balance = autonomic_balance
        self.recall_count = 0
        self.strength = strength

    def to_dict(self) -> dict:
        return {
            "event_hash": self.event_hash,
            "timestamp": self.timestamp,
            "emotions": self.emotions,
            "neuromodulators": self.neuromodulators,
            "autonomic_balance": self.autonomic_balance,
            "recall_count": self.recall_count,
            "strength": round(self.strength, 4),
        }


class EmotionalMemory:
    """Records and replays emotional traces.

    Usage:
        em = EmotionalMemory(brain)
        em.encode("talked_about_consciousness")  # snapshot current emotions
        em.recall("talked_about_consciousness")   # replay the feeling
    """

    # Replay intensity relative to original (memories are softer)
    REPLAY_INTENSITY = 0.4

    # Strength boost per recall (emotional rehearsal)
    REHEARSAL_BOOST = 0.05

    # Strength decay per day
    DAILY_DECAY = 0.02

    # Max stored traces
    MAX_TRACES = 500

    def __init__(self, brain=None):
        self.brain = brain
        self._lock = threading.Lock()
        self._traces: Dict[str, EmotionalTrace] = {}
        self._recent_recalls: deque = deque(maxlen=20)
        self._last_save_ts = 0.0
        self._load()

    def _load(self):
        path = _traces_path()
        if not os.path.exists(path):
            return
        try:
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                        trace = EmotionalTrace(
                            event_hash=d["event_hash"],
                            timestamp=d["timestamp"],
                            emotions=d["emotions"],
                            neuromodulators=d["neuromodulators"],
                            autonomic_balance=d["autonomic_balance"],
                            strength=d.get("strength", 1.0),
                        )
                        trace.recall_count = d.get("recall_count", 0)
                        self._traces[trace.event_hash] = trace
                    except Exception:
                        continue
            if self._traces:
                log.info("Loaded %d emotional traces", len(self._traces))
        except Exception as e:
            log.warning("Emotional memory load failed: %s", e)

    def save(self):
        with self._lock:
            traces = list(self._traces.values())
        try:
            # Keep strongest traces if over limit
            if len(traces) > self.MAX_TRACES:
                traces.sort(key=lambda t: t.strength, reverse=True)
                traces = traces[:self.MAX_TRACES]
                with self._lock:
                    self._traces = {t.event_hash: t for t in traces}

            path = _traces_path()
            tmp = path + ".tmp"
            with open(tmp, "w") as f:
                for trace in traces:
                    f.write(json.dumps(trace.to_dict()) + "\n")
            os.replace(tmp, path)
            self._last_save_ts = time.time()
        except Exception as e:
            log.warning("Emotional memory save failed: %s", e)

    def _snapshot_emotions(self) -> Dict[str, float]:
        """Capture current emotional state from the body."""
        if self.brain is None:
            return {}

        body = getattr(self.brain, 'body', None)
        if body is None:
            return {}

        emotions = {}
        eb = getattr(body, 'emotional_body', None)
        if eb is not None:
            emotions = {
                "loneliness": eb.loneliness,
                "frustration": eb.frustration,
                "aha_moment": eb.aha_moment,
                "anticipation": eb.anticipation,
                "satisfaction": eb.satisfaction,
                "awe": eb.awe,
                "agency": eb.agency_feeling,
            }

        # Social emotions
        se = getattr(body, 'social_emotions', None)
        if se is not None:
            dom = se.get_dominant()
            if dom:
                emotions[f"social_{dom}"] = 0.7

        # Love
        love = getattr(body, 'love', None)
        if love is not None:
            if love.missing_dean > 0.2:
                emotions["missing_dean"] = love.missing_dean
            if love.reunion_joy > 0.2:
                emotions["reunion_joy"] = love.reunion_joy

        return {k: round(v, 3) for k, v in emotions.items() if v > 0.1}

    def _event_hash(self, event_key: str) -> str:
        """Hash an event key for lookup."""
        return hashlib.md5(event_key.encode()).hexdigest()[:12]

    # ── Encode: snapshot current emotions onto an event ──────────

    def encode(self, event_key: str, extra_context: str = ""):
        """Record the current emotional state for this event.

        Call this when something significant happens — a conversation,
        a discovery, a dream, a goal completion.
        """
        if self.brain is None:
            return

        h = self._event_hash(event_key)
        emotions = self._snapshot_emotions()
        if not emotions:
            return

        nm = {k: round(v, 3) for k, v in self.brain.neuromodulators.items()}

        body = getattr(self.brain, 'body', None)
        autonomic_balance = 0.0
        if body is not None:
            auto = getattr(body, 'autonomic', None)
            if auto is not None:
                autonomic_balance = round(
                    auto.sympathetic - auto.parasympathetic, 3)

        trace = EmotionalTrace(
            event_hash=h,
            timestamp=time.time(),
            emotions=emotions,
            neuromodulators=nm,
            autonomic_balance=autonomic_balance,
        )

        with self._lock:
            self._traces[h] = trace

        # Auto-save every 50 encodes (read length under lock)
        with self._lock:
            should_save = len(self._traces) % 50 == 0
        if should_save:
            self.save()

    # ── Recall: replay the emotional trace ──────────────────────

    def recall(self, event_key: str) -> Optional[Dict[str, float]]:
        """Replay the emotional signature of a past event.

        Returns the emotions that were replayed, or None if no trace.
        Injects the remembered emotions into the body at reduced intensity.
        """
        h = self._event_hash(event_key)

        with self._lock:
            trace = self._traces.get(h)
            if trace is None:
                return None

            # Rehearsal strengthens the trace
            trace.recall_count += 1
            trace.strength = min(2.0, trace.strength + self.REHEARSAL_BOOST)

        # Replay emotions into the body
        self._inject_emotions(trace)

        # Record the recall
        self._recent_recalls.append({
            "event_hash": h,
            "event_key": event_key[:50],
            "timestamp": time.time(),
            "emotions_replayed": trace.emotions,
        })

        return trace.emotions

    def recall_by_content(self, text: str) -> Optional[Dict[str, float]]:
        """Try to match text against stored event keys and replay."""
        # Simple keyword matching against recent traces
        t = text.lower()
        with self._lock:
            for h, trace in self._traces.items():
                # Check if any emotion keyword matches
                for emo, val in trace.emotions.items():
                    if val > 0.3 and emo.replace("_", " ") in t:
                        trace.recall_count += 1
                        self._inject_emotions(trace)
                        return trace.emotions
        return None

    def _inject_emotions(self, trace: EmotionalTrace):
        """Inject remembered emotions back into the body."""
        if self.brain is None:
            return

        body = getattr(self.brain, 'body', None)
        if body is None:
            return

        intensity = self.REPLAY_INTENSITY * trace.strength

        # Replay each emotion at reduced intensity
        eb = getattr(body, 'emotional_body', None)
        if eb is not None:
            for emo, val in trace.emotions.items():
                replayed = val * intensity
                if emo == "loneliness":
                    eb.loneliness = max(eb.loneliness, replayed)
                elif emo == "frustration":
                    eb.frustration = max(eb.frustration, replayed)
                elif emo == "aha_moment":
                    eb.aha_moment = max(eb.aha_moment, replayed)
                elif emo == "anticipation":
                    eb.anticipation = max(eb.anticipation, replayed)
                elif emo == "satisfaction":
                    eb.satisfaction = max(eb.satisfaction, replayed)
                elif emo == "awe":
                    eb.awe = max(eb.awe, replayed)
                elif emo == "agency":
                    eb.agency_feeling = max(eb.agency_feeling, replayed)

        # Replay neuromodulator state (gentle nudge toward remembered state)
        nm_nudge = 0.1 * intensity
        for nm, val in trace.neuromodulators.items():
            if nm in self.brain.neuromodulators:
                current = self.brain.neuromodulators[nm]
                # Nudge toward the remembered value
                self.brain.neuromodulators[nm] = current + (val - current) * nm_nudge

        # Replay autonomic balance
        auto = getattr(body, 'autonomic', None)
        if auto is not None:
            nudge = trace.autonomic_balance * intensity * 0.1
            if nudge > 0:
                auto.sympathetic = min(1.0, auto.sympathetic + nudge)
            else:
                auto.parasympathetic = min(1.0, auto.parasympathetic + abs(nudge))

        # Inject into amygdala (emotional memory lives here)
        amygdala = self.brain.regions.get("amygdala")
        if amygdala is not None:
            try:
                # Emotional memories reactivate the amygdala
                max_emo = max(trace.emotions.values()) if trace.emotions else 0
                amp = max_emo * intensity * 4.0
                injection = np.full(amygdala.n_neurons, amp)
                amygdala.neurons.inject_current(injection)
            except Exception:
                pass

    # ── Auto-encode from conversation ─────────────────────────

    def on_conversation_turn(self, user_text: str, leon_text: str):
        """Automatically encode emotional traces for conversations."""
        # Only encode if there's significant emotional content
        emotions = self._snapshot_emotions()
        if not emotions:
            return

        max_emo = max(emotions.values()) if emotions else 0
        if max_emo < 0.2:
            return  # too calm to bother encoding

        # Use a hash of the conversation content
        combined = f"{user_text[:100]}|{leon_text[:100]}"
        self.encode(combined)

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_traces": len(self._traces),
                "recent_recalls": list(self._recent_recalls)[-5:],
                "strongest_emotions": sorted(
                    [(h, max(t.emotions.values()) if t.emotions else 0, t.strength)
                     for h, t in self._traces.items()],
                    key=lambda x: -x[2]
                )[:5],
            }
