"""Schemas for the registered brain-local delegation and skill tools."""

_OPTIONS = {
    "model": {"type": "string", "description": "Optional Claude model alias."},
    "system": {"type": "string", "description": "Optional task-specific instructions."},
    "name": {"type": "string", "description": "Short label for the agent registry."},
}

_TASK = {
    "type": "object",
    "properties": {
        "goal": {"type": "string", "minLength": 10,
                 "description": "What this sub-agent must find out or produce. A full sentence "
                                "a stranger could act on."},
        "context": {"type": "string",
                    "description": "Extra facts only this sub-agent needs."},
        "name": {"type": "string", "description": "Short label shown in the Agents panel."},
    },
    "required": ["goal"],
    "additionalProperties": False,
}

DELEGATION_TOOLS = [
    {
        "name": "delegate_task",
        "description": (
            "Fork 1 to 5 focused sub-agents that work in parallel, each with its own clean "
            "context, a restricted toolset and a turn/time budget, and get back a compact "
            "report from each (not their transcripts). Use it to research several things at "
            "once, dig into one question without filling your own context, or get a second "
            "analysis. Sub-agents know NOTHING of this conversation: put everything they need "
            "in goal/context. Toolsets: research (web search + page reading + Reddit + your "
            "memory, read-only; the default), recall (your memory, notes and tasks, read-only), "
            "reason (no tools; think or write from the context). They cannot delegate, write "
            "memory, speak, message anyone, touch the desktop or start coding jobs. For work "
            "that edits code or files, start a coding job instead. Sync (default) waits up to "
            "about 4 minutes and returns the reports. background=true returns at once with a "
            "delegation_id and the reports reach you later as an internal event (up to 30 "
            "minutes): use it for slow work and keep talking to Dean meanwhile. Reports are "
            "the sub-agents' own claims, unverified. action=status (delegation_id), "
            "result (agent_id, the full report) and list look things up."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["spawn", "status", "result", "list"],
                           "description": "Default spawn."},
                "goal": {"type": "string", "description": "One task (or use tasks)."},
                "tasks": {"type": "array", "items": _TASK, "minItems": 1, "maxItems": 5,
                          "description": "Several independent tasks, run in parallel."},
                "context": {"type": "string",
                            "description": "Background every sub-agent needs: who/what/why, "
                                           "constraints, what a good answer looks like."},
                "toolset": {"type": "string", "enum": ["research", "recall", "reason"]},
                "model": {"type": "string", "enum": ["sonnet", "opus", "haiku"],
                          "description": "Default sonnet; opus for hard reasoning, haiku for "
                                         "quick lookups."},
                "max_turns": {"type": "integer", "minimum": 1, "maximum": 40,
                              "description": "Per sub-agent, default 15."},
                "timeout_s": {"type": "integer", "minimum": 30, "maximum": 1800,
                              "description": "Per sub-agent. Sync max 270 (default 240); "
                                             "background max 1800 (default 600)."},
                "background": {"type": "boolean"},
                "purpose": {"type": "string",
                            "description": "Background mode: why you delegated, so the "
                                           "results make sense when they come back."},
                "delegation_id": {"type": "string"},
                "agent_id": {"type": "string"},
            },
            "additionalProperties": False,
        },
    },
    {
        "name": "skill_library",
        "description": (
            "Your procedural memory: short how-to skills (when to use, steps, pitfalls) that "
            "you distil from your own multi-step work. Relevant skills are put in front of you "
            "automatically before similar tasks, and a skill is drafted automatically after a "
            "long tool-using task. Use this to save one on purpose (action=save: name, "
            "when_to_use, steps, pitfalls; an existing skill with the same purpose is refined, "
            "not duplicated), fix one that was wrong or missing a step (action=update with "
            "name plus the fields to change), or search, view, list and delete. Write lessons "
            "that generalise, not a log of one day."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "action": {"type": "string",
                           "enum": ["search", "view", "list", "save", "update", "delete"]},
                "query": {"type": "string", "description": "search: what you are about to do."},
                "name": {"type": "string", "description": "Skill name, e.g. deploy-brain-to-vps."},
                "when_to_use": {"type": "string"},
                "steps": {"type": "array", "items": {"type": "string"}, "maxItems": 10},
                "pitfalls": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
                "tags": {"type": "array", "items": {"type": "string"}, "maxItems": 8},
            },
            "required": ["action"],
            "additionalProperties": False,
        },
    },
    {
        "name": "agent_spawn",
        "description": "Legacy alias of delegate_task (one research sub-agent, sync). Prefer delegate_task.",
        "input_schema": {
            "type": "object",
            "properties": {**_OPTIONS, "task": {"type": "string", "minLength": 1}},
            "required": ["task"], "additionalProperties": False,
        },
    },
    {
        "name": "agent_spawn_parallel",
        "description": "Legacy alias of delegate_task (up to five research sub-agents, sync). Prefer delegate_task.",
        "input_schema": {
            "type": "object",
            "properties": {**_OPTIONS, "tasks": {
                "type": "array", "items": {"type": "string", "minLength": 1},
                "minItems": 1, "maxItems": 5,
            }},
            "required": ["tasks"], "additionalProperties": False,
        },
    },
]


# Dean (2026-10-15 20:01): anything Leon spawns must be Hermes, helpers included, because
# Hermes keeps memory and these `claude -p` sub-agents do not. They are kept in the code
# for a Hermes-backed replacement (ledger item 3) but are not offered as tools.
NON_HERMES_SPAWN = ("delegate_task", "agent_spawn", "agent_spawn_parallel")
DELEGATION_TOOLS = [tool for tool in DELEGATION_TOOLS if tool["name"] not in NON_HERMES_SPAWN]

from brain.hermes_research import TOOL as HERMES_RESEARCH_TOOL
DELEGATION_TOOLS.append(HERMES_RESEARCH_TOOL)

from brain.owner_requests import TOOL as QUEUE_OWNER_REQUEST_TOOL
DELEGATION_TOOLS.append(QUEUE_OWNER_REQUEST_TOOL)
