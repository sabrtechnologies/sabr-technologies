"""Bounded local conversation transport; optional single-scheduler ownership."""
import json
import math
import os
import re
import threading
import time
from urllib.parse import urlsplit
from types import SimpleNamespace

_OWNER = threading.local()


def _invalid_number(value):
    raise ValueError('non-finite model JSON number')


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate model JSON key')
        result[key] = value
    return result


def scheduler_selected(group, *, channel=None, key=None):
    from brain import v2_live_flags
    return (v2_live_flags.live_mode('inference_scheduler') != 'off'
            and v2_live_flags.is_active('inference_scheduler.' + group,
                                       channel=channel, key=key))


def scheduler_route(group, *, channel=None, key=None):
    """Selection and availability are separate: selected failure never falls back."""
    if not scheduler_selected(group, channel=channel, key=key):
        return False, None
    from brain.cognition import inference_scheduler
    return True, inference_scheduler.route(group, channel=channel, key=key)


def scheduled_provider(messages, *, group, channel=None, key=None,
                       timeout=35, max_tokens=160):
    """Custom-provider contract. The scheduler owns all transport iteration."""
    def provide(request, prompt, kwargs, cancel_token):
        from brain.cognition import inference_scheduler
        from brain.inference_cancel import CancelToken
        if (not inference_scheduler.in_worker_context()
                or not isinstance(cancel_token, CancelToken)
                or request.allow_tools or request.persist_history):
            raise RuntimeError('local conversation requires a no-tools scheduler owner')
        previous = getattr(_OWNER, 'context', None)
        _OWNER.context = (cancel_token, group)
        full = []
        stream = chunks(messages, cancel_token, timeout=timeout, max_tokens=max_tokens,
                        routing_group=group, routing_channel=channel, routing_key=key)
        try:
            for text in stream:
                if cancel_token.is_set():
                    return
                full.append(text)
                yield SimpleNamespace(type='delta', text=text)
            if not cancel_token.is_set():
                reply = ''.join(full)
                if not reply.strip():
                    raise RuntimeError('empty local conversation reply')
                yield SimpleNamespace(type='done', full_text=reply)
        finally:
            try:
                stream.close()
            finally:
                _OWNER.context = previous
    return provide


def selected(text):
    if os.environ.get('LEON_CONVERSATION_LANE', '0') != '1':
        return False
    text = text.strip().lower()
    if text.startswith('/chat '):
        return True
    # Conservative admission: ambiguous follow-ups and actions retain the tool lane.
    if len(text) > 800 or text.startswith('/') or '[attached' in text:
        return False
    if re.search(r'\b(code|coding|build|fix|deploy|install|run|execute|open|close|click|send|delete|remove|save|write|edit|change|update|search|browse|look up|screen|file|repo|terminal|weather|news|stock|price|remind|remember|recall|continue|do it|go ahead|yes|go)\b', text):
        # A direct question about chatting during work requires no tools.
        return bool(re.search(r'can we (still )?(talk|chat) while', text))
    return bool(re.search(r'^(hey|hi\b|hello|thanks|thank you|how are|how do you feel|what do you think|why do|i feel|i am |i\x27m |tell me a joke|can we talk|let\x27s talk)', text))


def chunks(messages, cancelled=None, timeout=35, max_tokens=160, *,
           routing_group='conversation', routing_channel=None, routing_key=None):
    """Only loopback HTTP; bounded connect, silence and total duration. No fallback."""
    if scheduler_selected(routing_group, channel=routing_channel, key=routing_key):
        from brain.cognition import inference_scheduler
        if (not inference_scheduler.in_worker_context()
                or getattr(_OWNER, 'context', None) != (cancelled, routing_group)):
            raise RuntimeError('selected local inference requires scheduler admission')
    if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
            or not math.isfinite(timeout) or not 0 < timeout <= 120
            or type(max_tokens) is not int or not 1 <= max_tokens <= 512):
        raise ValueError('invalid local inference bounds')
    if not isinstance(messages, list) or not 1 <= len(messages) <= 16:
        raise ValueError('invalid conversation messages')
    for message in messages:
        if (not isinstance(message, dict) or set(message) != {'role', 'content'}
                or message['role'] not in ('system', 'user', 'assistant')
                or not isinstance(message['content'], str)):
            raise ValueError('conversation accepts text messages only')
    payload = {'model':os.environ.get('LEON_CONVERSATION_MODEL','qwen3.5:4b'),
               'messages':messages,'stream':True,'think':False,'keep_alive':os.environ.get('LEON_LOCAL_KEEP_ALIVE','3m'),
               'options':{'num_ctx':2048,'num_thread':4,'num_predict':max_tokens,'temperature':.6}}
    encoded = json.dumps(payload, allow_nan=False).encode('utf-8')
    if len(encoded) > 65536:
        raise ValueError('conversation input too large')
    target = urlsplit(os.environ.get('LEON_CONVERSATION_URL', 'http://127.0.0.1:11435'))
    if (target.scheme != 'http' or target.hostname not in ('127.0.0.1', '::1', 'localhost')
            or target.username is not None or target.password is not None
            or target.path not in ('', '/') or target.query or target.fragment):
        raise ValueError('conversation endpoint must be local loopback HTTP')
    from brain.inference_cancel import CancelToken
    from brain.inference_http import SocketHolder, TrackedHTTPConnection
    native = cancelled if isinstance(cancelled, CancelToken) else CancelToken()
    if cancelled is not None and cancelled.is_set():
        return
    holder = SocketHolder()
    # Resolve the literal localhost alias locally; never follow redirects.
    hostname = '127.0.0.1' if target.hostname == 'localhost' else target.hostname
    conn = TrackedHTTPConnection(hostname, target.port or 80, timeout=min(8, timeout), v2_holder=holder)
    unhook = native.add_callback(holder.kill)
    stop = threading.Event()
    deadline = time.monotonic() + timeout
    def interrupt():
        while not stop.wait(min(.05, timeout)):
            if time.monotonic() >= deadline:
                native.cancel('deadline')
                return
            if cancelled is not None and cancelled.is_set():
                native.cancel('cancelled')
                return
    watcher = threading.Thread(target=interrupt, daemon=True, name='local-chat-transport-watch')
    done = False
    response = None
    total = events = output = 0
    try:
        watcher.start()
        conn.request('POST','/api/chat',encoded,{'Content-Type':'application/json'})
        response = conn.getresponse()
        if response.status != 200:
            raise RuntimeError('local conversation HTTP %s' % response.status)
        while not native.is_set():
            line = response.readline(65537)
            if not line: break
            if len(line)>65536: raise RuntimeError('oversize model stream event')
            total += len(line); events += 1
            if total > 262144 or events > 2048:
                raise RuntimeError('local conversation stream limit')
            data = json.loads(line, parse_constant=_invalid_number, object_pairs_hook=_unique_object)
            if not isinstance(data, dict): raise RuntimeError('invalid model event')
            if data.get('error'): raise RuntimeError('local conversation model error')
            message = data.get('message', {})
            if (not isinstance(message, dict) or message.get('role', 'assistant') != 'assistant'
                    or any(data.get(k) or message.get(k) for k in ('tool_calls', 'function_call', 'tools'))):
                raise RuntimeError('local conversation received unsupported tool output')
            content = message.get('content','')
            if not isinstance(content, str) or type(data.get('done', False)) is not bool:
                raise RuntimeError('invalid model text or completion')
            output += len(content.encode('utf-8'))
            if output > 32768: raise RuntimeError('local conversation output limit')
            if native.is_set(): break
            if content: yield content
            if native.is_set(): break
            if data.get('done') is True:
                done = True
                break
        if not done and not (cancelled is not None and cancelled.is_set()):
            raise TimeoutError('local conversation exceeded its deadline or ended early')
    finally:
        stop.set()
        unhook()
        holder.kill()
        try:
            if response is not None:
                response.close()
        finally:
            try:
                conn.close()
            finally:
                if watcher.ident is not None:
                    watcher.join(.25)


class ConversationGate:
    """Channel cancellation coordinator; mutex retained for legacy OFF callers."""
    def __init__(self):
        self.lock = threading.Lock()
        self.mu = threading.Lock()
        self.current = None
        self._callbacks = {}

    def _cancel_locked(self, token):
        if token is None: return []
        token.set()
        return list(self._callbacks.pop(token, ()))

    @staticmethod
    def _notify(callbacks):
        for fn in callbacks:
            try: fn()
            except Exception: pass

    def cancel(self):
        with self.mu:
            callbacks = self._cancel_locked(self.current)
        self._notify(callbacks)

    def begin(self):
        token = threading.Event()
        with self.mu:
            callbacks = self._cancel_locked(self.current)
            self.current = token
        self._notify(callbacks)
        return token

    def bind(self, token, cancel):
        """Bind a scheduler handle; cancellation before binding is not lost."""
        with self.mu:
            immediate = token.is_set()
            if not immediate: self._callbacks.setdefault(token, []).append(cancel)
        if immediate: cancel()
        def unbind():
            with self.mu:
                callbacks = self._callbacks.get(token, [])
                if cancel in callbacks: callbacks.remove(cancel)
                if not callbacks: self._callbacks.pop(token, None)
        return unbind

    def begin_background(self):
        with self.mu:
            if self.current is not None: return None
            self.current = threading.Event()
            return self.current

    def active(self):
        with self.mu:
            return self.current is not None and not self.current.is_set()

    def end(self, token):
        with self.mu:
            self._callbacks.pop(token, None)
            if self.current is token: self.current = None


GATE = ConversationGate()
