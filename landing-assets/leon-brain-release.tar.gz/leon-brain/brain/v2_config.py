"""
Leon V2 feature-flag framework.

Implements Section 3 ("V2 Feature-Flag Framework") of the Leon V2
Continuity-Preserving Implementation Runbook.

Every major V2 migration component runs in exactly one of three modes:

    off     - the component is not constructed and has no effect at all.
    shadow  - the component observes and records what it *would* do while the
              legacy path stays authoritative. This is the default posture for
              every new subsystem until its phase gate passes.
    on      - the component is authoritative for its resource (see the
              ownership table in runbook Section 0.1).

The point of this module is that there is exactly ONE place where those modes
are parsed. Runbook Section 3: "No scattered ad-hoc truthy environment
parsing." Parsing is therefore strict - an unrecognised value raises
ValueError rather than silently degrading to off. A typo such as
LEON_INFERENCE_SCHEDULER=ture must not quietly disable a subsystem an operator
believed was enabled, nor quietly enable one they believed was off.

Accepted spellings: "off", "shadow", "on", case-insensitive, surrounding
whitespace stripped. Deliberately NOT accepted: 1/0/true/false/yes/no - those
are two-state and this framework is three-state.

An environment variable that is unset, or set to an empty/whitespace-only
value, uses the runbook's initial default for that flag. Empty is the
conventional systemd/shell idiom for "not set"; it is not a typo the way
"ture" is.

Import side effects: NONE, by design. In Phase 0 nothing consumes this module
yet. Importing it reads no files, writes no files, configures no logging,
mutates no environment and parses no environment. Env parsing happens only
when a caller invokes load_v2_config() / get_v2_config().

Public API (runbook Section 19): load_v2_config() -> V2Config, plus V2Mode and
V2Config.

CLI (read-only, for operator preflight on the VPS):

    python3 -m brain.v2_config            # print the active flags
    python3 -m brain.v2_config --json     # machine-readable
    python3 -m brain.v2_config --defaults # print the runbook defaults

Exit codes: 0 success, 1 a flag failed validation, 2 usage error.
"""

from __future__ import annotations

import json
import os
import sys
import threading
from dataclasses import dataclass, fields as dataclass_fields
from enum import Enum
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

__all__ = [
    "V2Mode",
    "V2Config",
    "load_v2_config",
    "get_v2_config",
    "reset_v2_config_cache",
    "describe_v2_config",
    "parse_v2_mode",
    "ENV_BINDINGS",
    "ENV_VARS",
    "DEFAULTS",
    "LEGAL_VALUES",
]


class V2Mode(str, Enum):
    """The only three states a V2 subsystem may be in (runbook Section 3)."""

    OFF = "off"
    SHADOW = "shadow"
    ON = "on"

    def __str__(self) -> str:
        # So f"{mode}" logs "shadow", not "V2Mode.SHADOW".
        return self.value


#: Legal spellings, in the order the runbook lists them. Used in error text.
LEGAL_VALUES: Tuple[str, ...] = tuple(m.value for m in V2Mode)


@dataclass(frozen=True)
class V2Config:
    """Resolved V2 feature flags. Immutable - reload instead of mutating."""

    runtime: V2Mode
    inference_scheduler: V2Mode
    procedural_router: V2Mode
    sensory_hub: V2Mode
    memory_service: V2Mode
    provider_router: V2Mode
    quantum_v2: V2Mode
    prediction_error: V2Mode = V2Mode.OFF
    tasks: V2Mode = V2Mode.OFF
    speech_arbitration: V2Mode = V2Mode.OFF

    def as_dict(self) -> Dict[str, str]:
        """Plain {field: "off"|"shadow"|"on"} - safe for JSON/ledger records."""
        return {
            f.name: V2Mode(getattr(self, f.name)).value
            for f in dataclass_fields(self)
        }

    def mode(self, field_name: str) -> V2Mode:
        """Look a flag up by field name. Raises KeyError for unknown fields."""
        if field_name not in _FIELD_NAMES:
            raise KeyError(
                "unknown V2 flag {0!r}; known flags: {1}".format(
                    field_name, ", ".join(_FIELD_NAMES)
                )
            )
        return V2Mode(getattr(self, field_name))

    def is_enabled(self, field_name: str) -> bool:
        """True when the flag is shadow or on (i.e. the subsystem is built)."""
        return self.mode(field_name) is not V2Mode.OFF

    def is_authoritative(self, field_name: str) -> bool:
        """True only when the flag is on (the V2 path owns the resource)."""
        return self.mode(field_name) is V2Mode.ON

    def describe(self, multiline: bool = False) -> str:
        """Render for logging. See describe_v2_config()."""
        return describe_v2_config(self, multiline=multiline)


#: field name -> (environment variable, initial default), exactly as the
#: runbook Section 3 table states. Order is the table's order.
ENV_BINDINGS: Tuple[Tuple[str, str, V2Mode], ...] = (
    ("runtime", "LEON_V2_RUNTIME", V2Mode.SHADOW),
    ("inference_scheduler", "LEON_INFERENCE_SCHEDULER", V2Mode.SHADOW),
    ("procedural_router", "LEON_PROCEDURAL_ROUTER", V2Mode.SHADOW),
    ("sensory_hub", "LEON_SENSORY_HUB", V2Mode.SHADOW),
    ("memory_service", "LEON_MEMORY_V2", V2Mode.SHADOW),
    ("provider_router", "LEON_PROVIDER_ROUTER", V2Mode.OFF),
    ("quantum_v2", "LEON_QUANTUM_V2", V2Mode.OFF),
    ("prediction_error", "LEON_PREDICTION_ERROR", V2Mode.OFF),
    ("tasks", "LEON_TASKS", V2Mode.OFF),
    ("speech_arbitration", "LEON_SPEECH_ARBITRATION", V2Mode.OFF),
)

#: field name -> initial default mode (runbook Section 3 "Initial value").
DEFAULTS: Dict[str, V2Mode] = {
    name: default for name, _env, default in ENV_BINDINGS
}

#: field name -> environment variable that overrides it.
ENV_VARS: Dict[str, str] = {
    name: env for name, env, _default in ENV_BINDINGS
}

_FIELD_NAMES: Tuple[str, ...] = tuple(name for name, _e, _d in ENV_BINDINGS)


def _check_bindings_match_dataclass() -> None:
    """Guard against ENV_BINDINGS and V2Config drifting apart in Phase 1+."""
    declared = tuple(f.name for f in dataclass_fields(V2Config))
    if declared != _FIELD_NAMES:
        raise RuntimeError(
            "brain.v2_config is inconsistent: V2Config fields {0} do not "
            "match ENV_BINDINGS {1}. Add the new flag to both, and to the "
            "runbook Section 3 table.".format(declared, _FIELD_NAMES)
        )


def parse_v2_mode(var_name: str, raw: str) -> V2Mode:
    """
    Strictly parse one flag value.

    Case-insensitive, whitespace-stripped. Anything that is not off/shadow/on
    raises ValueError naming the variable, the offending value and the legal
    values. Truthy spellings (1/0/true/false/yes/no) are rejected on purpose:
    this framework is three-state and a two-state answer is ambiguous.
    """
    cleaned = raw.strip().lower()
    for mode in V2Mode:
        if cleaned == mode.value:
            return mode
    # Re-raised, never swallowed: runbook 0.2 forbids hiding failures in new
    # core code. Recovery action is stated in the message itself.
    raise ValueError(
        "{0}={1!r} is not a valid Leon V2 mode. Legal values are {2} "
        "(case-insensitive, surrounding whitespace ignored). Two-state values "
        "such as 1/0/true/false are not accepted - choose one of {2}, or "
        "unset {0} to take the runbook default.".format(
            var_name, raw, ", ".join(LEGAL_VALUES)
        )
    )


def load_v2_config(env: Optional[Mapping[str, str]] = None) -> V2Config:
    """
    Parse the V2 flags from the environment and return a fresh V2Config.

    Always re-reads; no caching. Use get_v2_config() on hot paths.

    Args:
        env: mapping to read instead of os.environ (tests, preflight tooling).

    Returns:
        A frozen V2Config with every flag resolved.

    Raises:
        ValueError: a variable is set to something that is not off/shadow/on.
                    The message names the variable and the legal values.
    """
    _check_bindings_match_dataclass()
    source: Mapping[str, str] = os.environ if env is None else env
    resolved: Dict[str, V2Mode] = {}
    for field_name, var_name, default in ENV_BINDINGS:
        raw = source.get(var_name)
        if raw is None or not raw.strip():
            resolved[field_name] = default
        else:
            resolved[field_name] = parse_v2_mode(var_name, raw)
    return V2Config(**resolved)


_cache_lock = threading.Lock()
_cached_config: Optional[V2Config] = None


def get_v2_config(reload: bool = False) -> V2Config:
    """
    Return the process-wide V2Config, parsing os.environ at most once.

    Leon is multithreaded, so the cache is lock-guarded and concurrent first
    calls cannot race. Pass reload=True (or call reset_v2_config_cache()) in
    tests, or after an intentional in-process environment change.

    Raises:
        ValueError: same as load_v2_config(). A bad value is never cached.
    """
    global _cached_config
    with _cache_lock:
        if _cached_config is None or reload:
            _cached_config = load_v2_config()
        return _cached_config


def reset_v2_config_cache() -> None:
    """Drop the cached config so the next get_v2_config() re-parses os.environ."""
    global _cached_config
    with _cache_lock:
        _cached_config = None


def describe_v2_config(config: Optional[V2Config] = None,
                       multiline: bool = False) -> str:
    """
    Render the active flags for a startup log line.

    Values that differ from the runbook's initial default are annotated, so a
    log reader can tell an explicit operator override from a default:

        Leon V2 flags: runtime=shadow inference_scheduler=on(default shadow) ...

    Passing config=None renders the cached config (parsing env if needed).
    """
    cfg = get_v2_config() if config is None else config
    rows: List[Tuple[str, str, str, Optional[str]]] = []
    for field_name, var_name, default in ENV_BINDINGS:
        mode = cfg.mode(field_name)
        rows.append(
            (field_name, var_name, mode.value,
             None if mode is default else default.value)
        )
    if multiline:
        lines = ["Leon V2 flags:"]
        for field_name, var_name, value, default_value in rows:
            suffix = "" if default_value is None else "   (default {0})".format(
                default_value)
            lines.append(
                "  {0:<20} {1:<7} [{2}]{3}".format(
                    field_name, value, var_name, suffix)
            )
        return "\n".join(lines)
    rendered: Iterable[str] = (
        "{0}={1}".format(field_name, value) if default_value is None
        else "{0}={1}(default {2})".format(field_name, value, default_value)
        for field_name, _var, value, default_value in rows
    )
    return "Leon V2 flags: " + " ".join(rendered)


def _defaults_report() -> str:
    lines = ["Leon V2 flag defaults (runbook Section 3):"]
    for field_name, var_name, default in ENV_BINDINGS:
        lines.append(
            "  {0:<26} {1:<7} -> V2Config.{2}".format(
                var_name, default.value, field_name)
        )
    lines.append("  legal values: {0}".format(", ".join(LEGAL_VALUES)))
    return "\n".join(lines)


def _main(argv: List[str]) -> int:
    """Read-only CLI. Touches no state; prints the resolved flags."""
    args = list(argv)
    if "--help" in args or "-h" in args:
        print((__doc__ or "").strip())
        return 0
    if "--defaults" in args:
        args.remove("--defaults")
        if args:
            print("unexpected arguments: {0}".format(" ".join(args)),
                  file=sys.stderr)
            return 2
        print(_defaults_report())
        return 0
    as_json = False
    if "--json" in args:
        args.remove("--json")
        as_json = True
    if args:
        print("unexpected arguments: {0}".format(" ".join(args)),
              file=sys.stderr)
        print("usage: python3 -m brain.v2_config [--json|--defaults|--help]",
              file=sys.stderr)
        return 2
    try:
        config = load_v2_config()
    except ValueError as exc:
        # subsystem / exception type / recovery action (runbook 0.2)
        print("[v2_config] ValueError while parsing V2 feature flags: "
              "{0}".format(exc), file=sys.stderr)
        print("[v2_config] recovery: correct the environment variable (or "
              "unset it to take the runbook default) and re-run.",
              file=sys.stderr)
        return 1
    if as_json:
        payload: Dict[str, Any] = {
            "schema": 1,
            "flags": config.as_dict(),
            "env_vars": dict(ENV_VARS),
            "defaults": {k: v.value for k, v in DEFAULTS.items()},
            "legal_values": list(LEGAL_VALUES),
        }
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(describe_v2_config(config, multiline=True))
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
