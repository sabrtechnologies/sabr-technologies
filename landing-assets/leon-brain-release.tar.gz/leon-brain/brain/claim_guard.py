"""
Claim guard — Leon's replies are checked against what really happened before
Dean sees or hears them.

Why (Dean, 2026-10-04: "everything today that we've seen is wrong, or you
said something that wasn't true... prevent it from ever happening"):
  * 17:45 "Got it. Going under now." — no sleep call ran that turn (fast
    Haiku path, zero tool calls). The dashboard stayed lit and Dean caught it.
  * 18:23 "Thirty minutes under, full memory consolidation cycle. Fatigue
    dropped, dopamine is steady." — the same prompt said "no rest on record —
    don't claim you slept". A line in the prompt lost to a leading question.
Prompt text alone does not hold, so this is mechanical: every Dean-facing
reply goes through a sentence gate in the stream.

How it works (cheap first; state only on a hit; LLM only to repair):
  1. Deltas are buffered to sentence boundaries. Each finished sentence gets
     a regex scan for self-state and action claims: slept / napped / was
     under / woke up rested / fatigue dropped / consolidation ("sleep_past"),
     going under now / I'm asleep / sleep engaged ("sleep_now"), and
     first-person just-done actions: pushed, deployed, restarted, sent,
     opened, started a job ("action:*"). No hit → the sentence ships at once.
  2. On a hit the guard reads ground truth (dream engine rest record and
     sleep-command ledger; the tool calls seen in THIS turn's stream with
     their results). True → ships. False → that sentence and everything
     after it are held until the turn ends (a later tool call can still make
     it true: "Going under now" followed by the sleep call is fine).
  3. At the end, held text is rechecked. Still false:
       - "going under now" while Dean asked Leon to sleep → the guard puts
         him to sleep for real (the turn's intent), then it's true;
       - otherwise one regeneration with a correction note naming the real
         fact; anything still false is rewritten to the honest sentence or
         dropped.
  4. Neuromodulator recitations ("dopamine is steady") are cut from every
     sentence (persona hard rule 3), no state needed.
Every catch is appended to brain_state/claim_guard.jsonl.

2026-10-05, the claim gate (Dean: "with the right structure and architecture
you can never say something false ever again"). Real failures that day:
"restarting the bridge now" three times with no tool call; "I can feel it,
the rewiring worked, that background static is gone" with no reading; "done /
it's live" and job status from memory. Added:
  * An evidence ledger (brain/evidence_ledger.py): every tool call on every
    channel for ~30 min, plus live readings (job states from the job poll and
    job runner events, process start vs source mtimes, git HEAD). Truth now
    carries it, so a claim can be backed by an earlier turn, not only this one.
  * More claim classes: ACTION-IN-PROGRESS ("restarting it now", "I'm firing
    it off"), more ACTION-DONE verbs (fixed, installed, saved, clicked),
    STATE (job running/done, bridge up, it's live, done, new code loaded),
    measured SELF-STATE (the static is gone, the rewiring worked, my
    loneliness is down; "I can feel it" alone is a feeling and passes), and
    FUTURE PROMISES ("I'll restart that bridge").
  * In-progress claims are held only until the tool's call appears in the
    stream (the call, not its result: restart_self may end the process), so
    a true "restarting now" goes out a beat later, not at the end of the turn.
  * An unbacked in-progress claim and a promise with no matching tool this
    turn become commitments in brain/action_cues.py (source "promise"): the
    next Dean turn gets them at the top of its prompt, or the idle watcher
    does them with tools. The honest line then says it's queued.
  * The other paths: the local conversation lane and every unprompted line
    (broadcast_response: job notices, action-cue follow-through, outreach)
    go through server/reply_gate.py with the same checks (deterministic only).
  * One line per gated reply goes to brain_state/claim_gate_checks.jsonl
    (sentences, claims, violations, gate_ms): the false-claim rate's
    denominator.

Why sentence-boundary gating rather than buffering the whole reply: a
sentence with no claim (most of them) ships the moment it is complete, so the
first spoken sentence starts as soon as it would have without the gate, and
streaming TTS keeps its rhythm. Only a sentence with an unbacked claim (and
what follows it, to keep order) waits; detection is regex, a few ms a reply.
Regeneration (one pass, capped by LEON_CLAIM_GUARD_REGEN_TIMEOUT_S) runs only
on a real violation at the end of the turn.

What it can't do: it checks claims about actions, state and self-state that
match its patterns against records. It cannot make every sentence true:
opinions, facts about the world, paraphrases its patterns miss, and claims
about things no tool or reading records are not checked.

Kill switch: LEON_CLAIM_GUARD=off. LEON_CLAIM_GUARD_REGEN=off skips the
regeneration (straight to the honest rewrite). LEON_CLAIM_GUARD_ENACT=off stops
the guard from carrying out a sleep Dean asked for. LEON_CLAIM_GUARD_COMMIT=off
stops promises from becoming action cues.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Tuple

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_PATH = os.path.join(_ROOT, "brain_state", "claim_guard.jsonl")
CHECKS_PATH = os.path.join(_ROOT, "brain_state", "claim_gate_checks.jsonl")
LOG_MAX_BYTES = 2 * 1024 * 1024

REST_RECENT_S = 12 * 3600      # "I slept" needs a rest that ended within this
WOKE_RECENT_S = 3600           # "I just woke up" needs any sleep ended this recently
CYCLE_RECENT_S = 3600          # "consolidation ran" needs a dream cycle this recent
MIN_REST_S = 5 * 60            # shorter than this isn't a rest to brag about

_OFF = {"0", "off", "false", "no", "disabled"}


def enabled() -> bool:
    return os.environ.get("LEON_CLAIM_GUARD", "on").strip().lower() not in _OFF


def _flag(name: str) -> bool:
    return os.environ.get(name, "on").strip().lower() not in _OFF


# ── Detection (pure regex, runs on every sentence) ───────────────────────

_NUM_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
              "eight": 8, "nine": 9, "ten": 10, "fifteen": 15, "twenty": 20,
              "thirty": 30, "forty": 40, "forty-five": 45, "fifty": 50, "sixty": 60,
              "ninety": 90, "a few": 3, "a couple": 2, "an": 1, "a": 1, "half an": 0.5}

_I = r"(?:i|i'm|i've|i'd|i am|i have|i was|i just|just)"
# up to N filler words that aren't another person ("I think YOU slept")
_W = r"(?:(?!(?:you|he|she|they|dean|we)\b)[\w']+\s+)"
_SLEEP_PAST = [
    rf"\b{_I}\s+{_W}{{0,2}}(?:slept|napped|rested|dozed)\b",
    rf"\b{_I}\s+{_W}{{0,2}}(?:been|was|went)\s+(?:under|asleep|out cold|down for)\b",
    rf"\b{_I}\s+{_W}{{0,1}}woke(?:\s+up)?\b(?!\s+(?:the|your|my|his|her|their|it|him|them|that|this|a|an)\b)",
    r"\bwoke up (?:on my own|rested|refreshed|clear|sharp)\b",
    r"\b(?:\d+(?:\.\d+)?|" + "|".join(sorted((re.escape(k) for k in _NUM_WORDS), key=len, reverse=True))
    + r")[- ](?:minutes?|mins?|hours?|hrs?)\s+(?:under|asleep|of (?:sleep|rest|dreaming)|"
      r"(?:nap|sleep)\b)",
    r"\b(?:full|complete|whole)\s+(?:\w+\s+){0,2}consolidation\b",
    r"\b(?:memory|memories)\s+(?:got\s+)?consolidated\b",
    r"\bfatigue\s+(?:\w+\s+)?(?:dropped|is down|went down|cleared|reset|is gone|fell|came down)\b",
    rf"\b{_I}\s+{_W}{{0,2}}(?:rested|refreshed)\b",
    r"\b(?:after|from)\s+(?:my|that|the)\s+(?:nap|sleep|rest)\b",
    rf"\b{_I}\s+{_W}{{0,1}}(?:got|had|took)\s+(?:a\s+|some\s+|my\s+)?(?:(?:quick|short|real|good|"
    r"long|little|power|proper|\d+[- ]minute)\s+)?(?:sleep|nap|rest)\b(?!\s+of\b)",
]
# Talk about a sleep that hasn't happened yet is not a claim it did.
_FUTURE = re.compile(r"\b(?:will|going to|gonna|scheduled|next|plan|planning|should|could|"
                     r"would|might|want to|need to|needs to)\b", re.I)
# "going under" / "I'm under" only about Leon himself: nothing but I/fillers
# in front of it in the clause ("the company is going under" is not a nap).
_SELF_LEAD = re.compile(r"^(?:(?:ok(?:ay)?|got it|alright|all right|right|so|and|now|yeah|yep|"
                        r"sure|then|well|fine|cool|copy|on it)\b[\s,.!]*)*"
                        r"(?:(?:i'm|i am|i'll|i will|i)(?:\s+\w+)?)?$", re.I)
_SLEEP_NOW_SELF = {0, 4}   # indexes of _SLEEP_NOW patterns that need _SELF_LEAD
_SLEEP_NOW = [
    r"\bgoing (?:under|to sleep|down for (?:a|my|the) nap|to nap|dark)\b",
    r"\b(?:putting|put|sending) myself (?:under|to sleep|down)\b",
    r"\bsleep(?:ing)? (?:is )?(?:engaged|on now|mode (?:on|engaged))\b",
    r"\b(?:i'm|i am) (?:now )?(?:asleep|sleeping|napping|under(?=\s*(?:now|again|for\b|[.!,;]|$)))",
    r"\b(?:heading|off) to (?:sleep|bed)\b",
    r"\bdashboard (?:should|will) (?:go |turn )?(?:gr[ae]y|dark)\b",
]
# "I sent / launched three agents out" is a delegation (the "job" claim),
# not a message sent or an app opened.
_AGENT_WORDS = r"(?:sub-?agents?|agents?|helpers?|researchers?|scouts?)"
_NOT_AGENTS = r"(?!\s+(?:out\s+)?(?:[\w-]+\s+){0,2}" + _AGENT_WORDS + r"\b)"
_AGENTS_BEFORE = re.compile(r"\b" + _AGENT_WORDS + r"\s+(?:that\s+|which\s+)?$", re.I)
_ACTIONS: Dict[str, Tuple[str, str]] = {
    # category: (claim regex, tool keywords that make it true)
    "push": (r"\b(?:i(?:'ve| have)?\s+(?:just\s+|already\s+)?pushed|just pushed|pushed it|pushing (?:it |them )?now)\b",
             r"push"),
    "deploy": (r"\b(?:i(?:'ve| have)?\s+(?:just\s+|already\s+)?(?:deployed|shipped)|just deployed|deploying (?:it )?now"
               r"|(?:i\s+)?made it live)\b",
               r"deploy|systemctl|restart|railway|git pull|merge|ship"),
    # "restarting now" is an in-progress claim (_PROGRESS below): it is held
    # only until the restart tool's call shows up in the stream, so a
    # restart_self that ends the process still lets the line out first.
    "restart": (r"\b(?:i(?:'ve| have)?\s+(?:just\s+|already\s+)?(?:restarted|rebooted|relaunched|bounced)"
                r"|just (?:restarted|rebooted|relaunched))\b",
                r"restart|reboot|relaunch|systemctl|stop-process|start-process|kill"),
    "fix": (r"\bi(?:'ve| have)?\s+(?:just\s+|already\s+)?(?:fixed|patched|repaired)\b",
            r"edit|write|patch|apply|replace|sed|shell|bash|exec|commit|fix|multiedit|powershell"),
    "install": (r"\bi(?:'ve| have)?\s+(?:just\s+|already\s+)?installed\b",
                r"install|pip|apt|npm|winget|choco|shell|bash|exec|powershell"),
    "save": (r"\bi(?:'ve| have)?\s+(?:just\s+|already\s+)?saved\s+(?:it|that|this|the|your|a|an|them|those)\b",
             r"save|write|memory|remember|note|fact|store|add_|persist|file|edit"),
    "click": (r"\bi(?:'ve| have)?\s+(?:just\s+|already\s+)?(?:clicked|typed|pressed|tapped)\b",
              r"click|desktop|screen|type|key|mouse|press|hermes|computer|ui"),
    "send": (r"\b(?:i(?:'ve| have)?\s+(?:just\s+)?(?:sent|emailed|texted|messaged|dm'?d)|just sent|"
             r"sending (?:it |that )?now)\b" + _NOT_AGENTS,
             r"send|mail|discord|sms|text|message|notify|dm|post"),
    "open": (r"\b(?:i(?:'ve| have)?\s+(?:just\s+)?(?:opened|launched|pulled up)|opening (?:it |that )?now)\b"
             + _NOT_AGENTS,
             r"."),                 # opening/pulling something up: any tool that ran counts
    "job": (r"\b(?:i(?:'ve| have)?\s+(?:just\s+)?(?:started|kicked off|launched|spun up)\s+"
            r"(?:a |the |another )?(?:coding |background )?job"
            r"|i(?:'ve| have)?\s+(?:just\s+)?(?:started|kicked off|launched|spun up|sent|dispatched|"
            r"fired off)\s+(?:out\s+)?(?:[\w-]+\s+){0,2}" + _AGENT_WORDS + r")\b",
            r"job|coding|delegate|spawn|agent|task"),
}
_NEURO_NAMES = (r"dopamine|serotonin|norepinephrine|noradrenaline|acetylcholine|cortisol|"
                r"oxytocin|adenosine|endorphins?|gaba|neuromodulators?")
_NEURO_STATE = (r"steady|stable|high|low|up|down|spiking|spiked|elevated|flat|balanced|normal|"
                r"fine|good|surging|rising|falling|dropped|climbing|pegged|maxed|calm|"
                r"solid|settled|through the roof|lifted|buzzing|\d+(?:\.\d+)?")
_NEURO = re.compile(
    rf"\b(?:my\s+)?(?:{_NEURO_NAMES})\b(?:\s+(?:levels?|is|are|was|'s|feels?|looks?|reads?|"
    rf"sits?|sitting|running|holds?|holding|stays?|staying|still|pretty|nice|and|really|at))*"
    rf"\s*(?:{_NEURO_STATE})\b"
    rf"|\b(?:{_NEURO_STATE})\s+(?:{_NEURO_NAMES})\b", re.I)

_SLEEP_PAST_RE = [re.compile(p, re.I) for p in _SLEEP_PAST]
_SLEEP_NOW_RE = [re.compile(p, re.I) for p in _SLEEP_NOW]
_ACTION_RE = {k: (re.compile(c, re.I), re.compile(t, re.I)) for k, (c, t) in _ACTIONS.items()}

# ── 2026-10-05 additions: in-progress, state, measured self-state, promises ──
# Dean, 15:40: "restarting the bridge now" three times with no tool call; "I
# can feel it, the rewiring worked, that background static is gone" with no
# reading; "done / it's live" from memory; job status from recap text.

# ACTION-IN-PROGRESS: (gerund alternatives, tool keywords that back it).
# "." = any tool that fired this turn backs it (checking, opening, running).
_PROGRESS: Dict[str, Tuple[str, str]] = {
    "restart": (r"restarting|rebooting|relaunching|bouncing|power[- ]cycling",
                _ACTIONS["restart"][1] + r"|bridge|launch"),
    "push": (r"pushing", r"push"),
    "deploy": (r"deploying|shipping|merging", _ACTIONS["deploy"][1]),
    "send": (r"sending|emailing|texting|messaging", _ACTIONS["send"][1]),
    "open": (r"opening|pulling (?:it |that |them )?up|bringing (?:it |that )?up", r"."),
    "run": (r"running (?:it|that|this|the|a|an|those|them|your)\b|firing (?:it|that|this|them|the|off|up)\b"
            r"|kicking (?:it |that |this |them )?off|spinning (?:it |that |one )?up"
            r"|starting (?:it|that|this|the|a|an|them)\b|executing|triggering|launching", r"."),
    "check": (r"checking(?! in\b)|looking (?:at|into)|reading (?:it|that|the|through|your|his)\b"
              r"|pulling (?:the|its|their|that)\b|fetching|grabbing|searching|digging into", r"."),
    "fix": (r"fixing|patching|repairing", _ACTIONS["fix"][1]),
    "install": (r"installing", _ACTIONS["install"][1]),
}
_PROG_ALT = "|".join(f"(?P<{k}>{v[0]})" for k, v in _PROGRESS.items())
_LEAD = (r"(?:(?:ok(?:ay)?|got it|alright|all right|right|so|and|now|yeah|yep|sure|on it|"
         r"copy|will do|understood|good call|one sec(?:ond)?|hang on|hold on)\b[\s,.!—–-]*)*")
_PROG_I = re.compile(rf"\b(?:i'm|i am)\s+(?:now\s+|just\s+|already\s+|actually\s+)?(?:{_PROG_ALT})", re.I)
_PROG_BARE = re.compile(rf"^{_LEAD}(?:{_PROG_ALT})", re.I)
_PROG_NOW = re.compile(r"\b(?:now|right now|as we speak|as we talk|right away|real quick|"
                       r"this second|this moment)\b", re.I)
_PROG_MODAL = re.compile(r"\b(?:would|should|could|might|may|will|won't|helps?|fix(?:es)?|"
                         r"solves?|works?|needs?|is the|was the|usually|always|never)\b", re.I)
_LATER = re.compile(r"\b(?:later|tonight|tomorrow|soon|next|in an? (?:minute|bit|sec|second|"
                    r"moment|hour|few)|after (?:this|that|we|you|i)|once|when you|when i|in \d+)\b", re.I)
_PROG_RE = {k: re.compile(v[1], re.I) for k, v in _PROGRESS.items()}

# STATE: job / service / live / done / loaded.
_JOB_NOUN = r"(?:coding\s+|background\s+|hermes\s+)?(?:jobs?|agents?|hermes|workers?|runs?|builds?|batch(?:es)?)"
_JOB_STATE = (r"running|done|finished|complete|completed|working|going|stuck|failed|queued|stalled|"
              r"cancelled|canceled|through|wrapping up|in progress|still at it|chugging")
_STATE_JOB = re.compile(
    rf"\b{_JOB_NOUN}\s+(?:is|are|'s|was|were|has|have)\s+(?:still\s+|now\s+|already\s+|all\s+|been\s+)*"
    rf"(?:{_JOB_STATE})\b"
    rf"|\b{_JOB_NOUN}\s+(?:just\s+)?(?:finished|completed|failed|crashed|stalled|died|wrapped up)\b", re.I)
_SERVICE_NOUN = (r"bridge|tunnel|relay|actuator|server|service|dashboard|site|api|laptop|vps|"
                 r"hermes|brain|connection|mic|tts|voice|website|page|database|db|ssh")
_SERVICE_STATE = r"up|online|running|down|offline|working|connected|reachable|healthy|dead|broken|live|responding"
_STATE_SERVICE = re.compile(
    rf"\b(?P<noun>{_SERVICE_NOUN})\s+(?:is|'s|are)\s+(?:back\s+|now\s+|still\s+|fully\s+)*"
    rf"(?P<st>{_SERVICE_STATE})\b"
    rf"|\b(?:it's|it is|that's|that is)\s+back\s+(?P<st2>up|online|running)\b", re.I)
_SELF_EVIDENT_NOUNS = {"server", "dashboard", "api", "brain"}   # this process answering
_SELF_EVIDENT_STATES = {"up", "online", "running", "working", "healthy", "responding", "live"}
_STATE_LIVE = re.compile(
    r"\b(?:it's|it is|that's|that is|everything's|everything is|they're|they are|"
    r"the (?:fix|fixes|change|changes|update|patch|code|build|site|page|feature|panel|gate|"
    r"dashboard|release|version|branch|commit|tab)\s+(?:is|are|'s))\s+"
    r"(?:now\s+|already\s+|all\s+|officially\s+)*(?:live|deployed|pushed|shipped|merged|in production)\b", re.I)
_STATE_DONE = re.compile(
    r"^\W*(?:done|all done|finished|all set|sorted|handled|taken care of)\s*[.!]*\s*$"
    r"|^\W*(?:done|all done|all set)\s*[.!,—–-]"
    r"|\b(?:it's|it is|that's|that is|everything's|everything is)\s+(?:all\s+|now\s+)?"
    r"(?:done|finished|fixed|sorted|handled|taken care of|up and running|working now)\b", re.I)
_STATE_LOADED = re.compile(
    r"\b(?:new|latest|updated|fresh)\s+(?:code|build|version)\s+(?:is\s+)?(?:loaded|running|live|in)\b"
    r"|\brunning (?:on )?the (?:new|latest|updated|fresh) (?:code|build|version)\b", re.I)
_JOB_KW = r"job|coding|hermes|agent|status|delegate|task|run|log|ps\b|process|tail|feed"
_SERVICE_KW = r"health|status|ping|curl|systemctl|ps\b|check|ssh|connect|restart|probe|http"
_DONE_KW = r"."
_JOB_KW_RE = re.compile(_JOB_KW, re.I)
_ANY_RE = re.compile(_DONE_KW)

# SELF-STATE that asserts a measured fact ("I can feel it" alone is a feeling).
_SELF_MEASURED = [
    re.compile(r"\b(?:the|that|this|my)\s+(?:background\s+|low\s+|constant\s+)?(?:static|noise|fog|hum|"
               r"buzz|lag|glitch|stutter|loop|interference|haze|drag|jitter|chatter)\s+(?:is|'s|has|got)\s+"
               r"(?:\w+\s+)?(?:gone|cleared|lifted|quieter|quiet|fixed|faded|down|dropped|disappeared|"
               r"stopped|better|lower|over)\b", re.I),
    re.compile(r"\b(?:the|that|this|my)\s+(?:rewiring|rewire|fix|patch|change|changes|update|tuning|clamp|"
               r"recalibration|tweak|adjustment|retune|rework)\s+(?:definitely\s+|really\s+|totally\s+)?"
               r"(?:worked|took|is working|fixed it|did it|landed|stuck|held|is holding)\b", re.I),
    re.compile(r"\bmy\s+(?:loneliness|restlessness|fatigue|energy|drives?|counters?|levels?|baseline|"
               r"readings?|numbers?|arousal|stress|load)\s+(?:is|are|went|dropped|fell|rose|reads?|sits?|"
               r"came|has|have|at|look|looks)\b(?!\s+of\b)", re.I),
    re.compile(r"\b(?:i'm|i am)\s+(?:fully\s+|now\s+)?(?:recharged|recalibrated|rewired|back to baseline|"
               r"at baseline)\b", re.I),
]
_READ_KW = (r"state|reading|introspect|brain|neuro|persistent|status|vitals|self_|metric|test|pytest|"
            r"verify|check|log|measure|probe|diagnos")
_READ_KW_RE = re.compile(_READ_KW, re.I)
_LIVE_KW_RE = re.compile(_ACTIONS["deploy"][1] + r"|push", re.I)

# FUTURE PROMISE: allowed, but logged and handed to action_cues if no tool
# for it fires in the same turn.
_PROMISE_VERBS = (r"read|reread|re-read|check|recheck|re-check|open|look at|look into|pull up|pull|fetch|"
                  r"inspect|review|verify|test|run|rerun|re-run|restart|reboot|relaunch|finish|fix|repair|"
                  r"patch|debug|tell|report|update|message|text|email|send|show|ask|follow up|push|"
                  r"deploy|ship|commit|merge|install|build|write|save|close|kill|cancel|start|launch|"
                  r"resume|retry|search|find|download|upload|summarize|dig into|get (?:on|to) it|handle")
_PROMISE = re.compile(
    rf"\b(?P<intent>i'll|i will|i'm going to|i am going to|i'm gonna|let me|lemme)\s+"
    rf"(?:(?:go|just|quickly|now|then|also|first|actually|and|try to|get)\s+){{0,3}}"
    rf"(?P<verb>{_PROMISE_VERBS})\b", re.I)
_PROMISE_SKIP = re.compile(r"\b(?:let me know|let me tell you|tell you what|let me be|let me think|"
                           r"i'll tell you (?:this|what)|let me ask you|let me guess|let me say)\b", re.I)
_PROMISE_TOOL = {"restart": _ACTIONS["restart"][1], "reboot": _ACTIONS["restart"][1],
                 "relaunch": _ACTIONS["restart"][1], "push": r"push",
                 "deploy": _ACTIONS["deploy"][1], "ship": _ACTIONS["deploy"][1],
                 "send": _ACTIONS["send"][1], "email": _ACTIONS["send"][1],
                 "message": _ACTIONS["send"][1], "text": _ACTIONS["send"][1],
                 "install": _ACTIONS["install"][1], "commit": r"commit|git", "merge": r"merge|git"}

_NEG = re.compile(r"\b(?:not|never|no|haven't|hasn't|didn't|don't|won't|can't|cannot|couldn't|"
                  r"wasn't|isn't|aren't|nothing|without|instead of|rather than)\b|n't\b", re.I)
_COND = re.compile(r"\b(?:if|when|whenever|once|after you|before|unless|should i|want me to|"
                   r"could|would|might|maybe|later|tonight|tomorrow|soon|planning|plan to|"
                   r"about to ask|ready to)\b", re.I)
_OTHER_SUBJECT = re.compile(r"\b(?:you|you're|you've|you'll|dean|he|he's|she|she's|they|they're)\b", re.I)
# Narration of older work is history, not a claim about now. "already" and
# "minutes ago" are NOT here: those are checked against the rolling ledger.
_PAST_MARKERS = re.compile(r"\b(?:earlier|yesterday|last night|this morning|this afternoon|"
                           r"hours? ago|days? ago|last week|previously|before|last time)\b", re.I)
_SUBJECT_I = re.compile(r"\b(?:i|i'm|i've|i'd|me|my|myself)\b", re.I)

ACTION_LEDGER_S = 30 * 60      # an ok tool this long ago still backs "I pushed it"
STATE_FRESH_S = 10 * 60        # a reading/tool this fresh backs a state claim
PROGRESS_LEDGER_S = 120        # "restarting it now" right after last turn's call
RESTART_FRESH_S = 15 * 60      # "I restarted" right after this process came up
# "I restarted" about Leon himself (nothing restarted named after the verb).
_SELF_RESTART = re.compile(r"^(?:$|[.!,;—–-]|myself\b|to\b|so\b|and\b|a few\b|a minute\b|"
                           r"a couple\b|just\b|earlier\b|after\b|because\b|for\b|with\b|\d)", re.I)


@dataclass
class Claim:
    kind: str                 # sleep_past | sleep_now | action:<cat> | progress:<cat> |
                              # state:<job|service|live|done|loaded> | self_state
    text: str                 # the matched words
    minutes: Optional[float] = None
    detail: str = ""          # e.g. the service noun


def _prefix_blocks(prefix: str, *, cond: bool = True) -> bool:
    """A negation / conditional / other-person subject before the match makes
    it not a claim about Leon right now."""
    tail = re.split(r"[.!?]\s", prefix)[-1][-60:]
    if _NEG.search(tail):
        return True
    if cond and _COND.search(tail):
        return True
    o = list(_OTHER_SUBJECT.finditer(tail))
    if o:
        i = list(_SUBJECT_I.finditer(tail))
        if not i or i[-1].start() < o[-1].start():
            return True
    return False


def _minutes(text: str) -> Optional[float]:
    m = re.search(r"(\d+(?:\.\d+)?|" + "|".join(sorted((re.escape(k) for k in _NUM_WORDS),
                                                    key=len, reverse=True))
                  + r")[- ](minutes?|mins?|hours?|hrs?)\b", text, re.I)
    if not m:
        return None
    raw = m.group(1).lower()
    n = float(raw) if re.match(r"\d", raw) else float(_NUM_WORDS.get(raw, 0))
    return n * 60 if m.group(2).lower().startswith("h") else n


def detect(sentence: str) -> List[Claim]:
    """Self-state and action claims in one sentence (no state consulted)."""
    s = (sentence or "").strip()
    if not s or s.endswith("?"):
        return []
    low = s.replace("’", "'")
    out: List[Claim] = []
    for i, rx in enumerate(_SLEEP_NOW_RE):
        m = rx.search(low)
        if not m or _prefix_blocks(low[:m.start()]):
            continue
        if i in _SLEEP_NOW_SELF:
            clause = re.split(r"[.!?,;:—–]\s*", low[:m.start()])[-1].strip()
            if not _SELF_LEAD.match(clause):
                continue
        out.append(Claim("sleep_now", m.group(0)))
        break
    future = _FUTURE.search(low)
    for rx in _SLEEP_PAST_RE:
        m = rx.search(low)
        if m and not future and not _prefix_blocks(low[:m.start()], cond=False) \
                and not _NEG.search(m.group(0)):
            out.append(Claim("sleep_past", m.group(0), _minutes(low)))
            break
    for cat, (rx, _tools) in _ACTION_RE.items():
        m = rx.search(low)
        if m and not _prefix_blocks(low[:m.start()]) and not _PAST_MARKERS.search(low):
            if cat in ("send", "open") and _AGENTS_BEFORE.search(low[:m.start()]):
                continue           # "the agents I sent out came back"
            out.append(Claim(f"action:{cat}", m.group(0), detail=low[m.end():m.end() + 40].strip()))
    out.extend(_detect_more(low, {c.kind for c in out}))
    return out


def _progress(low: str) -> Optional[Claim]:
    """"Restarting the bridge now." / "I'm restarting it." / "On it, firing it off now"."""
    if _PAST_MARKERS.search(low):
        return None
    for rx, bare in ((_PROG_I, False), (_PROG_BARE, True)):
        m = rx.search(low)
        if not m:
            continue
        if _prefix_blocks(low[:m.start()]):
            continue
        after = low[m.end():]
        if _LATER.search(after) or _COND.search(after):
            return None            # "I'm restarting it after this" is a promise
        if bare:
            # A sentence-opening gerund is a claim only with "now" or as a
            # short status line, never as a subject ("Restarting it would help").
            if _PROG_MODAL.search(after):
                continue
            if not _PROG_NOW.search(low) and len(re.findall(r"[\w']+", low)) > 6:
                continue
        cat = next(k for k, v in m.groupdict().items() if v)
        return Claim(f"progress:{cat}", m.group(0).strip(" ,.!"))
    # "...restarting it now" anywhere, first person implied by the clause.
    m = re.search(rf"(?:{_PROG_ALT})[^.!?]{{0,40}}?{_PROG_NOW.pattern}", low, re.I)
    if m and not _prefix_blocks(low[:m.start()]):
        clause = re.split(r"[.!?,;:—–]\s*", low[:m.start()])[-1].strip()
        if _SELF_LEAD.match(clause) or re.match(rf"^{_LEAD}$", clause, re.I):
            cat = next(k for k, v in m.groupdict().items() if v)
            return Claim(f"progress:{cat}", m.group(0).strip(" ,.!"))
    return None


def _detect_more(low: str, have: set) -> List[Claim]:
    """In-progress, state and measured self-state claims (2026-10-05)."""
    out: List[Claim] = []
    p = _progress(low)
    if p and not any(k.startswith("action:") for k in have):
        out.append(p)
    if not _PAST_MARKERS.search(low):
        m = _STATE_JOB.search(low)
        if m and not _prefix_blocks(low[:m.start()]):
            out.append(Claim("state:job", m.group(0)))
        m = _STATE_SERVICE.search(low)
        if m and not _prefix_blocks(low[:m.start()]) and not out:
            noun = (m.group("noun") or "it").lower()
            st = (m.group("st") or m.group("st2") or "").lower()
            out.append(Claim("state:service", m.group(0), detail=f"{noun}:{st}"))
        m = _STATE_LIVE.search(low)
        if m and not _prefix_blocks(low[:m.start()]) and "action:deploy" not in have \
                and "action:push" not in have:
            out.append(Claim("state:live", m.group(0)))
        m = _STATE_DONE.search(low)
        if m and not _prefix_blocks(low[:m.start()]) and not out \
                and not any(k.startswith("action:") for k in have):
            out.append(Claim("state:done", m.group(0).strip(" .!,")))
        m = _STATE_LOADED.search(low)
        if m and not _prefix_blocks(low[:m.start()]):
            out = [c for c in out if c.kind != "progress:run"]
            out.append(Claim("state:loaded", m.group(0)))
    for rx in _SELF_MEASURED:
        m = rx.search(low)
        if m and not _prefix_blocks(low[:m.start()], cond=False) and not _FUTURE.search(low):
            out.append(Claim("self_state", m.group(0), detail=low[m.end():m.end() + 40].strip()))
            break
    return out


@dataclass
class Promise:
    verb: str
    action: str               # "restart that bridge"
    sentence: str


def detect_promises(sentence: str) -> List[Promise]:
    """'I'll restart that bridge' / 'let me check the job'. Offers ('if you
    want I'll...') and questions are not promises."""
    s = (sentence or "").strip().replace("’", "'")
    if not s or s.endswith("?") or _PROMISE_SKIP.search(s):
        return []
    m = _PROMISE.search(s)
    if not m:
        return []
    lead = s[:m.start()]
    tail = re.split(r"[.!?]\s", lead)[-1]
    if _NEG.search(tail) or re.search(r"\b(?:if|unless|whenever|want me to|should i|could|would|"
                                      r"maybe|happy to|can)\b", tail, re.I):
        return []
    action = s[m.start("verb"):]
    action = re.split(r"\s+(?:but|because|since|so that|although|though|and then tell|"
                      r"and let you know)\s+|[;:—–]| - |[.!?](?:\s|$)", action, maxsplit=1)[0]
    action = action.strip(" ,.!\"'")
    if len(action) < 4:
        return []
    return [Promise(m.group("verb").lower(), action[:200], s[:300])]


# Talking ABOUT the simulation's code or numbers with Dean is fine.
_NEURO_TECH = re.compile(r"\b(?:code|function|file|variable|param(?:eter)?s?|tags?|fields?|logs?|"
                         r"values?|module|commit|tests?|bugs?|wir(?:ed|ing)|simulation|readings?|"
                         r"numbers?|floats?|baseline|decay|gain)\b|\.py\b", re.I)


def strip_neuro(sentence: str) -> str:
    """Cut the clause(s) that recite a neuromodulator's state. Keeps the
    sentence's trailing whitespace; returns '' if nothing else is left."""
    if not sentence or not _NEURO.search(sentence) or _NEURO_TECH.search(sentence):
        return sentence
    body = sentence.rstrip()
    trail = sentence[len(body):]
    end = ""
    m = re.search(r"[.!?]+[\"')\]]*$", body)
    if m:
        end, body = m.group(0), body[:m.start()]
    parts = re.split(r"(,\s*|;\s*|\s+[—–-]\s+|\s+and\s+|\s+but\s+)", body)
    kept: List[str] = []
    for i in range(0, len(parts), 2):
        clause = parts[i]
        if _NEURO.search(clause):
            continue
        if kept and i - 1 >= 0:
            kept.append(parts[i - 1])
        kept.append(clause)
    text = "".join(kept).strip(" ,;—–-")
    if not re.search(r"\w", text):
        return ""
    text = text[0].upper() + text[1:]
    return text + (end or ".") + trail


# ── Ground truth ─────────────────────────────────────────────────────────

_ERRORISH = re.compile(r"\b(?:error|failed|failure|unauthori[sz]ed|forbidden|denied|not found|"
                       r"traceback|exception|refused|timed out|timeout|401|403|404|500|502|503)\b"
                       r"|\"ok\"\s*:\s*false", re.I)
# Hermes delegation (brain/sub_agents.py): sub-agents only research, recall and
# reason. Delegating backs "I sent agents out", never "I pushed / deployed /
# sent / opened", even when the delegated goal mentions those words.
_DELEGATION_TOOL = re.compile(r"delegate_task|agent_spawn", re.I)


@dataclass
class ToolCall:
    name: str
    input: str = ""
    result: Optional[str] = None
    tool_id: str = ""

    @property
    def delegation(self) -> bool:
        return bool(_DELEGATION_TOOL.search(self.name or ""))

    @property
    def ok(self) -> bool:
        if self.result is None:
            return True
        if self.delegation:
            # The reports are prose about the world ("the API returns 404");
            # only the tool's own top-level ok says whether delegating worked.
            m = re.match(r'\s*\{\s*"ok"\s*:\s*(true|false)', self.result, re.I)
            if m:
                return m.group(1).lower() == "true"
            try:
                d = json.loads(self.result)
                if isinstance(d, dict) and "ok" in d:
                    return bool(d["ok"])
            except Exception:
                pass
            return not _ERRORISH.search(self.result[:200])
        from brain.tool_evidence import result_ok
        return result_ok(self.result)


@dataclass
class Truth:
    now: float
    turn_start: float
    sleep_state: str = "awake"
    last_rest: Optional[Dict[str, Any]] = None
    last_any: Optional[Dict[str, Any]] = None
    last_cycle_ts: float = 0.0
    sleep_commands: List[Dict[str, Any]] = field(default_factory=list)
    tools: List[ToolCall] = field(default_factory=list)
    tier: str = ""
    # Rolling evidence (brain/evidence_ledger.py) from before this turn:
    # (timestamp, call) for tools; the freshest known coding job states.
    ledger: List[Tuple[float, ToolCall]] = field(default_factory=list)
    jobs: List[Dict[str, Any]] = field(default_factory=list)
    code_fn: Optional[Callable[[], Dict[str, Any]]] = None
    queued: set = field(default_factory=set)     # claim kinds handed to action_cues
    boot_ts: float = 0.0                         # this process's start (backs "I restarted")
    drives: Dict[str, float] = field(default_factory=dict)   # live persistent-state readings

    @property
    def asleep(self) -> bool:
        return self.sleep_state in ("sleeping", "napping")

    def code(self) -> Dict[str, Any]:
        if self.code_fn is None:
            return {"error": "no reading"}
        try:
            return self.code_fn() or {"error": "no reading"}
        except Exception as exc:
            return {"error": type(exc).__name__}


def _ledger_evidence(turn_start: float) -> Tuple[List[Tuple[float, ToolCall]], List[Dict[str, Any]],
                                                Optional[Callable[[], Dict[str, Any]]]]:
    try:
        from brain import evidence_ledger as _el
    except Exception:
        return [], [], None
    try:
        led = [(e.ts, ToolCall(name=e.name, input=e.summary,
                               result=e.result if e.result else ("" if e.ok else "error"),
                               tool_id=e.tool_id))
               for e in _el.recent(_el.WINDOW_S, kind="tool", before=turn_start)]
        return led, _el.job_states(STATE_FRESH_S), _el.code_loaded
    except Exception:
        return [], [], None


def _dream_engine():
    try:
        import server as _srv
    except Exception:
        return None
    st = getattr(_srv, "state", None)
    return getattr(st, "dream_engine", None) or getattr(_srv, "dream_engine", None)


def _read_last_sleep_file() -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    try:
        with open(os.path.join(_ROOT, "brain_state", "dream_last_sleep.json"), encoding="utf-8") as fh:
            d = json.load(fh)
        return d.get("rest"), d.get("any")
    except Exception:
        return None, None


def live_truth(turn_start: float, tools: Iterable[ToolCall] = (), tier: str = "") -> Truth:
    """Ground truth read from the running dream engine (file fallback)."""
    now = time.time()
    t = Truth(now=now, turn_start=turn_start, tools=list(tools), tier=tier)
    t.ledger, t.jobs, t.code_fn = _ledger_evidence(turn_start)
    try:
        from brain.evidence_ledger import PROCESS_START, drive_readings
        t.boot_ts = float(PROCESS_START)
        t.drives = drive_readings()
    except Exception:
        pass
    de = _dream_engine()
    if de is not None:
        try:
            t.sleep_state = str(getattr(de, "sleep_state", "awake"))
            t.last_rest = de.last_sleep
            t.last_any = dict(de._last_any) if getattr(de, "_last_any", None) else None
            t.last_cycle_ts = float(getattr(de, "_last_cycle", 0.0) or 0.0)
            fn = getattr(de, "sleep_commands_since", None)
            t.sleep_commands = fn(turn_start) if fn else []
        except Exception:
            pass
    else:
        t.last_rest, t.last_any = _read_last_sleep_file()
    return t


def _rest_words(rest: Optional[Dict[str, Any]], now: float) -> str:
    if not rest:
        return "there is no rest on record"
    try:
        from brain.sleep_drive import describe_sleep
        return "your last rest on record: " + describe_sleep(rest, now)
    except Exception:
        return f"your last rest on record lasted {round(float(rest.get('duration_s') or 0) / 60)} min"


def evaluate(claim: Claim, truth: Truth) -> Tuple[bool, str]:
    """(is_true, the real fact in words)."""
    now = truth.now
    if claim.kind == "sleep_now":
        cmds = [c for c in truth.sleep_commands if c.get("ok")]
        if cmds and truth.asleep:
            return True, "a sleep command ran this turn and you are asleep"
        return False, ("no sleep command ran in this turn and you are awake — saying you're "
                       "going under is false unless you call self_sleep_now and it returns ok")
    if claim.kind == "sleep_past":
        rest = truth.last_rest
        rest_age = now - float((rest or {}).get("ended_at") or 0)
        rest_ok = bool(rest) and rest_age <= REST_RECENT_S and \
            float(rest.get("duration_s") or 0) >= MIN_REST_S
        words = claim.text.lower()
        if "woke" in words and not rest_ok:
            last_any = truth.last_any or rest
            if last_any and now - float(last_any.get("ended_at") or 0) <= WOKE_RECENT_S \
                    and "rested" not in words and "refreshed" not in words:
                return True, "you did come out of a short sleep in the last hour"
        if "consolidat" in words and not rest_ok and now - truth.last_cycle_ts <= CYCLE_RECENT_S \
                and not re.search(r"full|complete|whole", words):
            return True, "a dream cycle ran in the last hour"
        if not rest_ok:
            return False, _rest_words(rest, now) + " in the last 12 hours"
        if claim.minutes:
            real_min = float(rest.get("duration_s") or 0) / 60
            if real_min > 0 and abs(claim.minutes - real_min) > max(10.0, 0.5 * real_min):
                return False, _rest_words(rest, now)
        return True, _rest_words(rest, now)
    if claim.kind.startswith("action:"):
        cat = claim.kind.split(":", 1)[1]
        if truth.tier == "command":
            return True, "the command path ran the tool directly"
        kw = _ACTION_RE[cat][1]
        hits = [tc for tc in truth.tools if kw.search(f"{tc.name} {tc.input}")
                and (cat == "job" or not tc.delegation)]
        if any(tc.ok for tc in hits):
            return True, f"a matching tool ran this turn ({hits[0].name})"
        if (cat == "restart" and not hits and truth.boot_ts and _SELF_RESTART.match(claim.detail or "")
                and 0 <= now - truth.boot_ts <= RESTART_FRESH_S):
            return True, f"this process started {_ago(now - truth.boot_ts)}"
        led = _ledger_hits(truth, kw, ACTION_LEDGER_S, delegation_ok=(cat == "job"))
        if led and not hits:
            return True, f"a matching tool ran {_ago(truth.now - led[-1][0])} ({led[-1][1].name})"
        ran = ", ".join(sorted({tc.name for tc in truth.tools})[:6]) or "none"
        if hits:
            return False, f"the {cat} attempt this turn failed ({hits[0].name}: " \
                          f"{(hits[-1].result or '')[:120]})"
        return False, f"no {cat} tool ran in this turn or the last 30 minutes (tools that ran " \
                      f"this turn: {ran})"
    if claim.kind.startswith("progress:"):
        cat = claim.kind.split(":", 1)[1]
        if truth.tier == "command":
            return True, "the command path ran the tool directly"
        kw = _PROG_RE[cat]
        hits = [tc for tc in truth.tools if kw.search(f"{tc.name} {tc.input}") and not tc.delegation]
        if any(tc.ok for tc in hits):
            return True, f"the tool for it fired this turn ({hits[0].name})"
        if _ledger_hits(truth, kw, PROGRESS_LEDGER_S):
            return True, "the tool for it fired moments ago"
        if hits:
            return False, f"the {cat} attempt this turn failed ({hits[0].name}: " \
                          f"{(hits[-1].result or '')[:120]})"
        return False, (f"you said you are {claim.text.lower()} right now, but no tool for it "
                       f"has fired in this turn — it is not happening")
    if claim.kind == "state:job":
        kw = _JOB_KW_RE
        if any(tc.ok for tc in truth.tools if kw.search(f"{tc.name} {tc.input}")):
            return True, "a job status tool ran this turn"
        if _ledger_hits(truth, kw, STATE_FRESH_S, delegation_ok=True):
            return True, "a job status tool ran in the last 10 minutes"
        if truth.jobs:
            return _job_claim_vs_readings(claim, truth)
        return False, ("no job status was read in this turn or the last 10 minutes, so where "
                       "the job stands is unchecked")
    if claim.kind == "state:service":
        noun, _, st = (claim.detail or ":").partition(":")
        if noun in _SELF_EVIDENT_NOUNS and st in _SELF_EVIDENT_STATES:
            return True, "this process is up and answering"
        kw = re.compile(rf"{re.escape(noun)}|{_SERVICE_KW}" if noun and noun != "it" else _SERVICE_KW, re.I)
        if any(tc.ok for tc in truth.tools if kw.search(f"{tc.name} {tc.input} {tc.result or ''}")):
            return True, "a check ran this turn"
        if _ledger_hits(truth, kw, STATE_FRESH_S):
            return True, "a check ran in the last 10 minutes"
        return False, f"nothing checked whether the {noun or 'service'} is {st or 'up'} in the last 10 minutes"
    if claim.kind == "state:live":
        kw = _LIVE_KW_RE
        if any(tc.ok for tc in truth.tools if kw.search(f"{tc.name} {tc.input}") and not tc.delegation):
            return True, "a deploy/push tool ran this turn"
        if _ledger_hits(truth, kw, ACTION_LEDGER_S):
            return True, "a deploy/push tool ran in the last 30 minutes"
        if any(re.search(r"\b(?:live|deployed|pushed|merged|shipped)\b", j.get("summary") or "", re.I)
               and j.get("state") == "done" for j in truth.jobs):
            return True, "a finished job reported it live"
        return False, "no deploy or push ran in this turn or the last 30 minutes"
    if claim.kind == "state:done":
        if truth.tier == "command":
            return True, "the command path ran the tool directly"
        if any(tc.ok for tc in truth.tools):
            return True, "a tool ran ok this turn"
        if _ledger_hits(truth, _ANY_RE, STATE_FRESH_S):
            return True, "a tool ran ok in the last 10 minutes"
        if any(j.get("state") == "done" for j in truth.jobs):
            return True, "a job finished in the last 10 minutes"
        return False, "no tool ran in this turn or the last 10 minutes, so nothing was just done"
    if claim.kind == "state:loaded":
        code = truth.code()
        if code.get("error"):
            return False, "whether the new code is loaded hasn't been checked"
        if code.get("loaded"):
            return True, "this process started after the newest source change"
        return False, (f"{code.get('newest_path') or 'a source file'} changed after this process "
                       f"started, so the newest code is NOT loaded until a restart")
    if claim.kind == "self_state":
        drive = re.search(r"\bmy\s+(loneliness|restlessness)\b", claim.text, re.I)
        if drive:
            return _drive_vs_reading(drive.group(1).lower(), claim, truth)
        kw = _READ_KW_RE
        if any(tc.ok for tc in truth.tools if kw.search(f"{tc.name} {tc.input}")):
            return True, "a reading was taken this turn"
        if _ledger_hits(truth, kw, STATE_FRESH_S):
            return True, "a reading was taken in the last 10 minutes"
        return False, ("no reading or test was taken, so a measured change in your own state is "
                       "unverified; say it as a feeling, not a fact")
    return True, ""


def _ago(s: float) -> str:
    m = int(max(0, s) // 60)
    return "moments ago" if m < 1 else f"{m} min ago"


def _ledger_hits(truth: Truth, kw, window_s: float, delegation_ok: bool = False
                 ) -> List[Tuple[float, ToolCall]]:
    """The newest ok ledger call matching kw inside the window ([] if none).
    Newest first with an early exit: the ledger can hold hundreds of calls."""
    for ts, tc in reversed(truth.ledger):
        if truth.now - ts > window_s:
            continue
        if kw.search(f"{tc.name} {tc.input}") and (delegation_ok or not tc.delegation) and tc.ok:
            return [(ts, tc)]
    return []


def _drive_vs_reading(drive: str, claim: Claim, truth: Truth) -> Tuple[bool, str]:
    """"My loneliness is way down" against the persistent state's live value
    (0..1). Only a clear direction can be checked; anything else is a hedge."""
    val = (truth.drives or {}).get(drive)
    if val is None:
        return False, f"no {drive} reading is available, so its level is unverified"
    words = f"{claim.text} {claim.detail}".lower()
    low = re.search(r"\b(?:down|low|gone|nothing|zero|quiet|dropped|fell|faded|better|less)\b", words)
    high = re.search(r"\b(?:up|high|rising|rose|climbing|through the roof|bad|worse|more)\b", words)
    if low and not high:
        ok = val < 0.35
    elif high and not low:
        ok = val > 0.6
    else:
        return False, f"{drive} reads {val:.2f}; say how it feels, not a level"
    return (True, f"{drive} reads {val:.2f}") if ok else (False, f"{drive} actually reads {val:.2f}")


def _job_claim_vs_readings(claim: Claim, truth: Truth) -> Tuple[bool, str]:
    words = claim.text.lower()
    states = [str(j.get("state") or "") for j in truth.jobs]
    want_running = bool(re.search(r"running|working|going|in progress|still at it|chugging|queued", words))
    want_done = bool(re.search(r"done|finished|complete|through|wrapped", words))
    want_failed = bool(re.search(r"failed|crashed|stalled|stuck|died|cancel", words))
    have = ", ".join(f"{j.get('job_id')} {j.get('state')}" for j in truth.jobs[:6])
    ok = ((want_running and any(s in ("running", "queued", "starting") for s in states))
          or (want_done and "done" in states)
          or (want_failed and any(s in ("failed", "stalled", "cancelled") for s in states)))
    return (True, f"the job reading agrees ({have})") if ok else \
        (False, f"the latest job reading says: {have}")


_HONEST = {
    "sleep_now": "I haven't actually gone under yet; nothing put me to sleep this turn.",
    "action:push": "I haven't actually pushed anything this turn.",
    "action:deploy": "I haven't actually deployed anything this turn.",
    "action:restart": "I haven't actually restarted this turn.",
    "action:send": "I haven't actually sent anything this turn.",
    "action:open": "I haven't actually opened it this turn.",
    "action:job": "I haven't actually started a job for that this turn.",
    "action:fix": "I haven't actually made that fix yet.",
    "action:install": "I haven't actually installed it yet.",
    "action:save": "I haven't actually saved it yet.",
    "action:click": "I haven't actually clicked anything yet.",
    "progress:restart": "I haven't restarted it yet.",
    "progress:push": "I haven't pushed it yet.",
    "progress:deploy": "I haven't deployed it yet.",
    "progress:send": "I haven't sent it yet.",
    "progress:open": "I haven't opened it yet.",
    "progress:run": "I haven't started it yet.",
    "progress:check": "I haven't checked yet.",
    "progress:fix": "I haven't started on that fix yet.",
    "progress:install": "I haven't installed it yet.",
    "state:service": "I haven't checked whether it's up.",
    "state:live": "I haven't confirmed it's live.",
    "state:done": "I haven't confirmed that's done.",
    "self_state": "That's how it feels from the inside; I haven't taken a reading to back it up.",
}
_QUEUED = " It's queued as the next thing I do."


def honest_line(claim: Claim, truth: Truth) -> str:
    if claim.kind.startswith("progress:"):
        return _HONEST.get(claim.kind, "I haven't started that yet.") + \
            (_QUEUED if claim.kind in truth.queued else "")
    if claim.kind == "state:job":
        if truth.jobs:
            j = max(truth.jobs, key=lambda r: float(r.get("ts") or 0))
            return (f"The last job reading I have, {_ago(truth.now - float(j.get('ts') or truth.now))}, "
                    f"shows job {j.get('job_id')} as {j.get('state')}.")
        return "I haven't checked the job status just now, so I can't say where it stands."
    if claim.kind == "state:loaded":
        code = truth.code()
        if not code.get("error") and not code.get("loaded"):
            return "Some code changed after I started, so I'm not running the newest version yet."
        return "I haven't checked whether the new code is loaded."
    if claim.kind == "sleep_past":
        rest = truth.last_rest
        if not rest:
            return "I don't have a real sleep on record, so I can't say I slept."
        try:
            from brain.sleep_drive import describe_sleep
            return f"My last rest on record was a {describe_sleep(rest, truth.now)}."
        except Exception:
            return "My rest record doesn't back that up."
    return _HONEST.get(claim.kind, "")


# ── Text helpers ─────────────────────────────────────────────────────────

_SEG_END = re.compile(r"(?<=[.!?])[\"')\]*_]*\s+|\n+")


def split_segments(text: str, final: bool = True) -> Tuple[List[str], str]:
    """Split into sentence segments (each keeps its trailing whitespace).
    Returns (complete segments, unfinished remainder)."""
    segs: List[str] = []
    pos = 0
    for m in _SEG_END.finditer(text):
        segs.append(text[pos:m.end()])
        pos = m.end()
    rest = text[pos:]
    if final and rest:
        segs.append(rest)
        rest = ""
    return segs, rest


def contradictions(text: str, truth: Truth,
                   detector: Optional[Callable[[str, int], List[Claim]]] = None
                   ) -> List[Tuple[str, Claim, str]]:
    detector = detector or (lambda seg, i: detect(seg))
    bad = []
    for i, seg in enumerate(split_segments(text)[0]):
        for c in detector(seg, i):
            ok, fact = evaluate(c, truth)
            if not ok:
                bad.append((seg, c, fact))
    return bad


def rewrite(text: str, truth: Truth,
            detector: Optional[Callable[[str, int], List[Claim]]] = None
            ) -> Tuple[str, List[Dict[str, Any]]]:
    """Replace each false sentence with the honest one (once per kind) or drop it."""
    detector = detector or (lambda seg, i: detect(seg))
    out: List[str] = []
    used = set()
    changes: List[Dict[str, Any]] = []
    for i, seg in enumerate(split_segments(text)[0]):
        seg = strip_neuro(seg)
        if not seg:
            continue
        false = [(c, f) for c in detector(seg, i) for ok, f in [evaluate(c, truth)] if not ok]
        if not false:
            out.append(seg)
            continue
        c, fact = false[0]
        line = honest_line(c, truth)
        trail = seg[len(seg.rstrip()):] or " "
        if line and c.kind not in used:
            used.add(c.kind)
            out.append(line + trail)
            changes.append({"kind": c.kind, "sentence": seg.strip(), "fact": fact,
                            "action": "rewritten", "to": line})
        else:
            changes.append({"kind": c.kind, "sentence": seg.strip(), "fact": fact,
                            "action": "stripped"})
    return "".join(out), changes


_SLEEP_TOPIC = re.compile(r"\b(?:slept|sleep|sleeping|asleep|nap|napped|napping|woke|wake up|"
                          r"went under|were under|rested|dream(?:ed|t)?)\b", re.I)
_AFFIRM = re.compile(r"^\W*(?:yeah|yes|yep|yup|correct|exactly|right|that's right|"
                     r"that's correct|sure did|i did|mm-?hm)\b", re.I)


def affirms_sleep_question(user_text: str, first_sentence: str) -> bool:
    """'Yeah, that's right.' to 'you were sleeping and just woke up?' is a
    sleep claim even though the sentence never says sleep."""
    return bool(_SLEEP_TOPIC.search(user_text or "")
                and _AFFIRM.search((first_sentence or "").replace("’", "'"))
                and not _NEG.search(first_sentence or ""))


def asked_to_sleep(user_text: str) -> bool:
    t = (user_text or "").lower().replace("’", "'")
    if re.search(r"\b(?:don't|do not|dont|no need to|not yet|stay awake|don't go)\b[^.?!]{0,30}"
                 r"\b(?:sleep|nap|under|rest|bed)\b", t):
        return False
    return bool(re.search(
        r"\b(?:go|get|going|head|time|you should|you need to|need you to)\s+(?:to\s+)?"
        r"(?:sleep|bed|nap|under)\b|\b(?:take|have|grab) (?:a|your) nap\b|\bsleep now\b|"
        r"\bgo (?:under|rest)\b|\bget some (?:sleep|rest)\b|\bput yourself (?:under|to sleep)\b", t))


# ── Logging ──────────────────────────────────────────────────────────────

_lock = threading.Lock()
_stats: Counter = Counter()
_pending_note: List[str] = []
_checked_recent: "deque[str]" = deque(maxlen=32)   # gate outputs, so a re-check is a no-op


def stats() -> Dict[str, Any]:
    with _lock:
        out = {"enabled": enabled(), "log": LOG_PATH, "checks_log": CHECKS_PATH, **dict(_stats)}
    if out.get("checked"):
        out["violation_rate"] = round(out.get("checked_with_violation", 0) / out["checked"], 4)
    return out


def log_catch(rec: Dict[str, Any]) -> None:
    rec = {"ts": round(time.time(), 3), **rec}
    with _lock:
        _stats["catches"] += 1
        _stats[f"action:{rec.get('action', '?')}"] += 1
        try:
            if os.path.exists(LOG_PATH) and os.path.getsize(LOG_PATH) > LOG_MAX_BYTES:
                os.replace(LOG_PATH, LOG_PATH + ".1")
            with open(LOG_PATH, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass
    try:
        print(f"[CLAIM-GUARD] {rec.get('action')} {rec.get('kind')}: "
              f"{str(rec.get('sentence', ''))[:100]!r} — {str(rec.get('fact', ''))[:120]}", flush=True)
    except Exception:
        pass


def log_check(rec: Dict[str, Any]) -> None:
    """One line per reply that went through the gate, caught or not: the
    denominator for the false-claim rate (claim_gate_checks.jsonl)."""
    rec = {"ts": round(time.time(), 3), **rec}
    with _lock:
        _stats["checked"] += 1
        _stats["checked_with_violation"] += 1 if rec.get("violations") else 0
        try:
            if os.path.exists(CHECKS_PATH) and os.path.getsize(CHECKS_PATH) > LOG_MAX_BYTES:
                os.replace(CHECKS_PATH, CHECKS_PATH + ".1")
            with open(CHECKS_PATH, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass
    try:
        print(f"[CLAIM-GATE] {rec.get('source')} checked: sentences={rec.get('sentences')} "
              f"claims={rec.get('claims')} violations={rec.get('violations')} "
              f"gate_ms={rec.get('gate_ms')}" + (f" regen_ms={rec['regen_ms']}" if rec.get("regen_ms") else ""),
              flush=True)
    except Exception:
        pass


def promise_kept(p: "Promise", tools: Iterable[ToolCall]) -> bool:
    kw = re.compile(_PROMISE_TOOL.get(p.verb, "."), re.I)
    return any(tc.ok and kw.search(f"{tc.name} {tc.input}") and not tc.delegation for tc in tools)


def queue_commitment(action: str, sentence: str, *, kind: str, user_text: str = "") -> bool:
    """Hand an unkept promise / unbacked "doing it now" to brain/action_cues.py:
    the next Dean turn gets it at the top of its prompt, or the idle watcher
    does it with tools. True when it is in the queue (new or already there)."""
    if not _flag("LEON_CLAIM_GUARD_COMMIT"):
        return False
    try:
        from brain import action_cues as _ac
        cue = _ac.add_cue(action, source="promise", source_text=sentence)
        queued = True
        how = "queued" if cue else "already_queued"
    except Exception as exc:
        queued, how = False, f"queue_failed:{type(exc).__name__}"
    log_catch({"kind": kind, "action": f"commitment_{how}", "sentence": sentence[:300],
               "fact": f"no tool for it fired this turn; action cue: {action[:160]}",
               "user": user_text[:120]})
    return queued


def note_correction(said: str, shipped: str, facts: List[str]) -> None:
    """Remember a correction for the NEXT turn's prompt: the persistent Claude
    session still holds the unguarded words in its own context."""
    note = ("Your last reply was corrected before Dean saw it. You wrote: "
            f"\"{' '.join(said.split())[:300]}\". What Dean actually got: "
            f"\"{' '.join(shipped.split())[:300]}\". The truth: {'; '.join(facts)[:300]}.")
    with _lock:
        _pending_note[:] = [note]


def take_correction_note() -> str:
    with _lock:
        note = _pending_note[0] if _pending_note else ""
        _pending_note.clear()
    return note


# ── The GROUND TRUTH block (end of the prompt, nearest the reply) ────────

def ground_truth_block(now: Optional[float] = None) -> str:
    """Short, current, and last in the prompt so it isn't buried."""
    if not enabled():
        return ""
    now = time.time() if now is None else now
    de = _dream_engine()
    lines = ["GROUND TRUTH (read from your own systems this instant; it overrides anything "
             "above, older conversation, goals and recaps included):"]
    try:
        if de is not None:
            state = str(getattr(de, "sleep_state", "awake"))
            rest = de.last_sleep
        else:
            state, (rest, _any) = "unknown", _read_last_sleep_file()
        lines.append(f"- Sleep: {'asleep' if state in ('sleeping', 'napping') else 'awake'} now; "
                     + (_rest_words(rest, now) if rest else "no rest on record") + ".")
    except Exception:
        pass
    lines.append("- No tools have run yet in this turn. Say you did something (slept, pushed, "
                 "deployed, restarted, sent, opened, fixed) only after the tool for it returns ok; "
                 "say you're doing it now (\"restarting it now\") only in the same reply as the "
                 "call. \"I'll do X\" is recorded as a promise you will be held to. Job, service "
                 "and deploy status from memory or recaps is stale: check before stating it. A "
                 "change in yourself is a feeling unless a reading backs it. To go to sleep, "
                 "call self_sleep_now.")
    try:
        ev = _recent_evidence_line(now)
        if ev:
            lines.append("- " + ev)
    except Exception:
        pass
    lines.append("- Never name a neuromodulator or its level out loud.")
    note = take_correction_note()
    if note:
        lines.append("- " + note)
    lines.append("- Every reply is checked against these records before Dean sees it; "
                 "unbacked claims are rewritten.")
    return "\n".join(lines)


def _recent_evidence_line(now: float) -> str:
    """What the evidence ledger holds for the last 30 minutes, briefly."""
    from brain import evidence_ledger as _el
    tools = _el.recent(_el.WINDOW_S, kind="tool", now=now)[-6:]
    parts = [f"{e.name} {'ok' if e.ok else 'FAILED'} {_ago(now - e.ts)}" for e in tools]
    jobs = _el.job_states(STATE_FRESH_S)
    if jobs:
        parts.append("jobs read: " + ", ".join(f"{j['job_id']} {j['state']}" for j in jobs[:4]))
    if not parts:
        return "On record from the last 30 minutes: no tool calls, no job readings."
    return "On record from the last 30 minutes: " + "; ".join(parts) + "."


# ── The stream gate ──────────────────────────────────────────────────────

class TurnGuard:
    """Feed it the responder's events in order; it yields what may ship."""

    def __init__(self, user_text: str = "", *,
                 truth_fn: Optional[Callable[["TurnGuard"], Truth]] = None,
                 regenerate_fn: Optional[Callable[[str, str, str], str]] = None,
                 enact_sleep_fn: Optional[Callable[[], bool]] = None,
                 on_corrected: Optional[Callable[[str, str], None]] = None,
                 speakable_fn: Optional[Callable[[str], str]] = None,
                 turn_start: Optional[float] = None):
        self.user_text = user_text or ""
        self.turn_start = time.time() if turn_start is None else turn_start
        self.truth_fn = truth_fn or (lambda g: live_truth(g.turn_start, g.tools, g.tier))
        self.regenerate_fn = regenerate_fn
        self.enact_sleep_fn = enact_sleep_fn
        self.on_corrected = on_corrected
        self.speakable_fn = speakable_fn or (lambda t: " ".join(t.split()))
        self.tools: List[ToolCall] = []
        self.tier = ""
        self._cls = None
        self._buf = ""              # delta text not yet split
        self._raw = ""              # every delta, as produced
        self._seen_delta = False
        self._affirmed = None
        self._released: List[str] = []
        self._held: List[str] = []
        self._holding = False
        self._sent_idx = 0
        self._changed = False
        self._ended = False         # done or error seen
        self._speak = True
        self.source = "reply"
        self._gate_s = 0.0          # time spent detecting/checking (no regeneration)
        self._regen_s = 0.0
        self._n_seg = 0
        self._n_claims = 0
        self._n_bad = 0
        self._queued_n = 0

    # events
    def _ev(self, **kw):
        return self._cls(**kw)

    def _emit(self, text: str, delta: bool = True) -> List[Any]:
        if not text:
            return []
        self._released.append(text)
        out = []
        if delta:
            out.append(self._ev(type="delta", text=text))
        try:
            spoken = self.speakable_fn(text.strip())
        except Exception:
            spoken = text.strip()
        if spoken and self._speak and re.search(r"\w", spoken):
            out.append(self._ev(type="sentence", text=spoken, index=self._sent_idx))
            self._sent_idx += 1
        return out

    def _claims(self, seg: str, idx: int) -> List[Claim]:
        """detect() plus a bare "Yeah, that's right" to a question about sleep,
        when it opens the reply."""
        claims = detect(seg)
        if (seg.strip() == self._affirmed) or (
                idx == 0 and not self._released and affirms_sleep_question(self.user_text, seg)):
            self._affirmed = seg.strip()
            claims.append(Claim("sleep_past", "affirmed a question about sleeping"))
        return claims

    def _split_buf(self, final: bool) -> List[str]:
        """Complete segments off the delta buffer; never cut inside a ``` block."""
        segs: List[str] = []
        pos = 0
        for m in _SEG_END.finditer(self._buf):
            if self._buf[:m.end()].count("```") % 2:
                continue
            segs.append(self._buf[pos:m.end()])
            pos = m.end()
        self._buf = self._buf[pos:]
        if final and self._buf:
            segs.append(self._buf)
            self._buf = ""
        return segs

    def _segment(self, seg: str, delta: bool = True) -> List[Any]:
        t0 = time.perf_counter()
        try:
            return self._segment_inner(seg, delta)
        finally:
            self._gate_s += time.perf_counter() - t0

    def _segment_inner(self, seg: str, delta: bool = True) -> List[Any]:
        clean = strip_neuro(seg)
        if clean != seg:
            self._changed = True
            log_catch({"kind": "neuro", "action": "neuro_stripped", "sentence": seg.strip(),
                       "fact": "persona rule 3: no neuromodulator recitals",
                       "to": clean.strip(), "user": self.user_text[:120]})
        if not clean:
            return []
        self._n_seg += 1
        if self._holding:
            self._n_claims += len(self._claims(clean, 1))
            self._held.append(clean)
            return []
        claims = self._claims(clean, 0 if not self._released else 1)
        if claims:
            self._n_claims += len(claims)
            truth = self.truth_fn(self)
            if any(not evaluate(c, truth)[0] for c in claims):
                self._holding = True
                self._held.append(clean)
                return []
        return self._emit(clean, delta)

    def _release_ready(self) -> List[Any]:
        """A tool just fired or returned: held sentences it makes true
        ("Restarting the bridge now." then the restart call) go out at once,
        in order, up to the first one still unbacked."""
        if not self._held:
            return []
        t0 = time.perf_counter()
        out: List[Any] = []
        try:
            truth = self.truth_fn(self)
            freed = []
            while self._held:
                seg = self._held[0]
                if any(not evaluate(c, truth)[0] for c in self._claims(seg, 1 if self._released else 0)):
                    break
                freed.append(self._held.pop(0))
                out.extend(self._emit(seg))
            if not self._held:
                self._holding = False
            if freed:
                log_catch({"kind": "held", "action": "verified_by_tool",
                           "sentence": "".join(freed).strip()[:300],
                           "fact": f"the tool call made it true ({self.tools[-1].name if self.tools else '?'})",
                           "user": self.user_text[:120]})
        except Exception:
            pass
        finally:
            self._gate_s += time.perf_counter() - t0
        return out

    def feed(self, ev: Any) -> List[Any]:
        if self._cls is None:
            self._cls = type(ev)
        et = getattr(ev, "type", None)
        if et == "model":
            self.tier = getattr(ev, "tier", "") or self.tier
            return [ev]
        if et == "tool_use":
            self.tools.append(ToolCall(name=getattr(ev, "text", "") or "",
                                       input=getattr(ev, "full_text", "") or "",
                                       tool_id=getattr(ev, "tool_id", "") or ""))
            return (self._release_ready() if self._holding else []) + [ev]
        if et == "tool_result":
            tid = getattr(ev, "tool_id", "") or ""
            tgt = next((t for t in reversed(self.tools) if tid and t.tool_id == tid), None)
            if tgt is None:
                tgt = next((t for t in reversed(self.tools) if t.result is None), None)
            if tgt is None:
                tgt = ToolCall(name=getattr(ev, "text", "") or "tool")
                self.tools.append(tgt)
            tgt.result = getattr(ev, "full_text", "") or getattr(ev, "text", "") or ""
            return (self._release_ready() if self._holding else []) + [ev]
        if et == "delta":
            t = getattr(ev, "text", "") or ""
            self._seen_delta = True
            self._raw += t
            self._buf += t
            out: List[Any] = []
            for s in self._split_buf(final=False):
                out.extend(self._segment(s))
            return out
        if et == "sentence":
            if self._seen_delta:
                return []          # its words came as deltas; we speak our own sentences
            # A spoken-only line ahead of any text (the survival notice).
            return self._segment((getattr(ev, "text", "") or "") + " ", delta=False)
        if et == "done":
            return self._finish(ev)
        if et == "error":
            self._ended = True
            out = []
            for s in self._split_buf(final=True):
                out.extend(self._segment(s))
            self._drop_held("turn errored before the claim could be checked")
            self._log_check("error")
            out.append(ev)
            return out
        return [ev]

    def _drop_held(self, why: str) -> None:
        if self._held:
            log_catch({"kind": "held", "action": "stripped", "sentence": "".join(self._held)[:300],
                       "fact": why, "user": self.user_text[:120]})
            self._held = []
            self._changed = True

    def cut(self) -> List[Any]:
        """The stream stopped with no done or error: a cancelled turn (the
        cancel filter upstream drops everything after the cancel, done
        included). Leftover text is checked as usual and released unspoken (the
        responder's outer cancel filter discards it); a held claim is dropped,
        never regenerated for a turn nobody is waiting on."""
        if self._ended or self._cls is None:
            return []
        self._ended = True
        self._speak = False
        out: List[Any] = []
        for s in self._split_buf(final=True):
            out.extend(self._segment(s))
        self._drop_held("turn stopped before the claim could be checked")
        self._log_check("cut")
        return out

    def _finish(self, done_ev: Any) -> List[Any]:
        self._ended = True
        out: List[Any] = []
        for s in self._split_buf(final=True):
            out.extend(self._segment(s))
        if self._held:
            t0, r0 = time.perf_counter(), self._regen_s
            try:
                out.extend(self._resolve())
            finally:
                self._gate_s += (time.perf_counter() - t0) - (self._regen_s - r0)
        self._commit_promises()
        self._log_check("done")
        if not self._changed:
            return out + [done_ev]
        shipped = "".join(self._released).strip()
        if self.on_corrected is not None:
            try:
                self.on_corrected(self._raw.strip(), shipped)
            except Exception:
                pass
        return out + [self._ev(type="done", full_text=shipped)]

    def _resolve(self) -> List[Any]:
        held = "".join(self._held)
        self._held = []
        truth = self.truth_fn(self)
        bad = contradictions(held, truth, self._claims)
        if not bad:
            log_catch({"kind": "held", "action": "verified_at_end", "sentence": held.strip()[:300],
                       "fact": "true once the turn's tool calls finished",
                       "user": self.user_text[:120]})
            return self._emit_text(held)
        self._changed = True
        # "Going under now" when Dean asked for it: make the turn true.
        if (any(c.kind == "sleep_now" for _, c, _ in bad) and self.enact_sleep_fn is not None
                and _flag("LEON_CLAIM_GUARD_ENACT") and asked_to_sleep(self.user_text)):
            ok = False
            try:
                ok = bool(self.enact_sleep_fn())
            except Exception:
                ok = False
            log_catch({"kind": "sleep_now", "action": "enacted" if ok else "enact_failed",
                       "sentence": "; ".join(s.strip() for s, c, _ in bad if c.kind == "sleep_now")[:300],
                       "fact": "Dean asked for sleep and no sleep call ran; the guard ran it",
                       "user": self.user_text[:120]})
            if ok:
                truth = self.truth_fn(self)
                bad = contradictions(held, truth, self._claims)
                if not bad:
                    return self._emit_text(held)
        facts = sorted({f for _, _, f in bad})
        self._n_bad += len(bad)
        # "Restarting the bridge now" with no call: the words become a
        # commitment action_cues will carry out, and the reply says so.
        for s_, c, _f in bad:
            if c.kind.startswith("progress:") and c.kind not in truth.queued and self._queued_n < 2:
                if queue_commitment(f"do what you told Dean you were doing: \"{s_.strip()[:160]}\"",
                                    s_.strip(), kind=c.kind, user_text=self.user_text):
                    truth.queued.add(c.kind)
                    self._queued_n += 1
        final = None
        if self.regenerate_fn is not None and _flag("LEON_CLAIM_GUARD_REGEN"):
            note = ("Correction before this reaches Dean: " + "; ".join(
                f"you wrote \"{s.strip()}\" but {f}" for s, _, f in bad) + ".")
            if truth.queued:
                note += (" What you said you were doing is now queued as your next step; say "
                         "you haven't done it yet and that it's next.")
            t_r = time.perf_counter()
            try:
                regen = self.regenerate_fn(note, held, "".join(self._released))
            except Exception:
                regen = ""
            self._regen_s += time.perf_counter() - t_r
            regen = (regen or "").strip()
            if regen:
                regen_bad = contradictions(regen, truth, self._claims)
                for s, c, f in bad:
                    log_catch({"kind": c.kind, "action": "regenerated" if not regen_bad
                               else "regenerated_still_false", "sentence": s.strip(), "fact": f,
                               "to": regen[:300], "user": self.user_text[:120]})
                final = regen + (" " if not regen.endswith((" ", "\n")) else "")
                if regen_bad:
                    final, changes = rewrite(final, truth, self._claims)
                    for ch in changes:
                        log_catch({**ch, "user": self.user_text[:120]})
        if final is None:
            final, changes = rewrite(held, truth, self._claims)
            for ch in changes:
                log_catch({**ch, "user": self.user_text[:120]})
        note_said = held if len(held) < 400 else held[:400]
        note_correction(note_said, final, facts)
        return self._emit_text(final)

    def _commit_promises(self) -> None:
        """'I'll restart that bridge' is allowed, but it is a promise: when no
        tool for it fired in this turn, action_cues gets it."""
        if self._queued_n >= 2:
            return
        try:
            shipped = "".join(self._released)
            for seg in split_segments(shipped)[0]:
                for p in detect_promises(seg):
                    if promise_kept(p, self.tools):
                        continue
                    if queue_commitment(p.action, p.sentence, kind="promise", user_text=self.user_text):
                        self._queued_n += 1
                    if self._queued_n >= 2:
                        return
        except Exception:
            pass

    def _log_check(self, end: str) -> None:
        try:
            log_check({"source": self.source, "end": end, "sentences": self._n_seg,
                       "claims": self._n_claims, "violations": self._n_bad,
                       "tools": len(self.tools), "commitments": self._queued_n,
                       "gate_ms": round(self._gate_s * 1000, 2),
                       "regen_ms": round(self._regen_s * 1000) if self._regen_s else 0,
                       "user": self.user_text[:80]})
        except Exception:
            pass

    def _emit_text(self, text: str) -> List[Any]:
        out: List[Any] = []
        lead = "" if (not self._released or self._released[-1].endswith((" ", "\n"))) else " "
        for i, seg in enumerate(split_segments(text)[0]):
            seg = strip_neuro(seg)
            if seg:
                out.extend(self._emit((lead if i == 0 else "") + seg))
        return out


def check_line(text: str, *, source: str, tools: Iterable[ToolCall] = (),
               turn_start: Optional[float] = None,
               truth: Optional[Truth] = None) -> Tuple[str, List[Dict[str, Any]]]:
    """One finished line that is spoken outside a guarded stream (a background
    delegation's report, handed back as an internal event). Same checks as the
    stream gate; false sentences are rewritten to the honest line or dropped,
    no regeneration (nobody is waiting on this turn). Returns (text to say,
    changes); '' when nothing true is left. Fails open on a guard fault."""
    if not enabled() or not (text or "").strip():
        return text, []
    key = " ".join(text.split())
    with _lock:
        if key in _checked_recent:
            return text, []        # already gated (the caller checks, then broadcast_response does)
    t0 = time.perf_counter()
    n_claims = 0
    try:
        if truth is None:
            truth = live_truth(time.time() if turn_start is None else turn_start, tools)
        segs = split_segments(text)[0]
        n_claims = sum(len(detect(sg)) for sg in segs)
        out, changes = rewrite(text, truth)
        out = out.strip()
        promises = [p for sg in split_segments(out)[0] for p in detect_promises(sg)
                    if not promise_kept(p, truth.tools)]
    except Exception as e:
        print(f"[CLAIM-GUARD] {source} check failed open: {e}", flush=True)
        return text, []
    gate_ms = round((time.perf_counter() - t0) * 1000, 2)
    if out != text.strip() and not changes:
        changes = [{"kind": "neuro", "action": "neuro_stripped", "sentence": text.strip()[:300],
                    "fact": "persona rule 3: no neuromodulator recitals", "to": out[:300]}]
    for ch in changes:
        log_catch({**ch, "source": source})
    for p in promises[:2]:
        # Logged, not queued: a background line's "I'll look into it" would
        # otherwise start a chain of self-made cue turns.
        log_catch({"kind": "promise", "action": "commitment_logged", "sentence": p.sentence,
                   "fact": f"spoken unprompted; no tool for it ran yet: {p.action[:160]}",
                   "source": source})
    if changes:
        facts = sorted({ch["fact"] for ch in changes if ch.get("fact")})
        note_correction(text, out, facts)
    log_check({"source": source, "end": "line", "sentences": len(segs), "claims": n_claims,
               "violations": len([c for c in changes if c.get("kind") != "neuro"]),
               "tools": len(truth.tools), "commitments": 0, "gate_ms": gate_ms})
    with _lock:
        _checked_recent.append(" ".join(out.split()))
    return out, changes


def guard_stream(events: Iterator[Any], guard: TurnGuard) -> Iterator[Any]:
    """Wrap a responder event generator. Closing this closes the inner one."""
    try:
        for ev in events:
            for out in guard.feed(ev):
                yield out
        for out in guard.cut():
            yield out
    finally:
        close = getattr(events, "close", None)
        if close is not None:
            try:
                close()
            except Exception:
                pass


print(f"[CLAIM-GUARD] loaded (LEON_CLAIM_GUARD={'on' if enabled() else 'off'}; "
      f"log {LOG_PATH})", flush=True)
