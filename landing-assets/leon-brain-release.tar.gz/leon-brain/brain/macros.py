"""High-level macros — multi-step routines triggered by a name.

A macro is a named sequence of tool calls. Different from `home.scene_*`
which is smart-home-specific; macros span everything (smart-home + voice
+ apps + memory + presence + comms). Examples shipped:

  - macro:good_morning      → wake routine: weather brief, lights, music, briefing
  - macro:focus_mode        → DND notifications, close distractions, dim lights
  - macro:movie_time        → dim lights, pause notifications, Spotify off
  - macro:leaving_house     → lights off, set away mode
  - macro:home_arrival      → welcome lights, replay missed messages
  - macro:sleep_mode        → all lights off, do-not-disturb, sleep_log entry
  - macro:deep_work_block   → 90min pomodoro start, focus playlist, notify start
  - macro:end_of_day_close  → save state, end-of-day report, dim lights

The macro definitions live in code (BUILTIN_MACROS) and on disk
(`brain_state/macros.json`). Disk macros override builtins by name.

Public tools:
  - macro.list                 list builtin + custom macro names
  - macro.run                  execute a macro by name
  - macro.define               save a custom macro (or override builtin)
  - macro.delete               remove a custom macro
  - macro.last_runs            audit of recent runs
  - macro.dry_run              show steps a macro would execute, no calls
  - macro.run_if_present       no-op if macro missing (for routines/external triggers)
"""

from __future__ import annotations

import json
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_STATE_DIR.mkdir(exist_ok=True)
_MACRO_FILE = _STATE_DIR / "macros.json"
_AUDIT_FILE = _STATE_DIR / "macros-audit.jsonl"


# ── Built-in macros ────────────────────────────────────────────────────
# Each macro is a list of steps; each step is:
#   {"tool": "<dotted-name>", "args": {...}, "optional": bool, "if_creds": "<env_var>"}
# - optional=True → step failure does NOT abort the macro (logged + continue)
# - if_creds="X"  → step is silently skipped if env var X is unset

BUILTIN_MACROS: Dict[str, List[Dict[str, Any]]] = {
    "good_morning": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "Good morning routine starting", "icon": "☀️"}},
        {"tool": "presence.tts_say",
         "args": {"text": "Good morning, Sir. Let me prepare your briefing."},
         "optional": True},
        {"tool": "home.lights_scene", "args": {"name": "morning"},
         "optional": True, "if_creds": "HASS_TOKEN"},
        {"tool": "report.daily_briefing", "args": {"location": "Los Angeles", "max_news": 3}},
        {"tool": "presence.dashboard_event",
         "args": {"kind": "success", "message": "Morning routine complete", "icon": "✓"}},
    ],
    "focus_mode": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "Focus mode ON", "icon": "🎯"}},
        {"tool": "home.lights_dim", "args": {"area": "office", "percent": 60},
         "optional": True, "if_creds": "HASS_TOKEN"},
        {"tool": "spotify.play_pause", "args": {}, "optional": True},
        {"tool": "presence.set_status_message",
         "args": {"message": "Focus mode active — DND on", "icon": "🎯", "severity": "info"}},
        {"tool": "presence.voice_tone_set", "args": {"tone": "quiet"}},
    ],
    "movie_time": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "Movie mode", "icon": "🎬"}},
        {"tool": "home.lights_dim", "args": {"area": "living_room", "percent": 15},
         "optional": True, "if_creds": "HASS_TOKEN"},
        {"tool": "spotify.play_pause", "args": {}, "optional": True},
        {"tool": "presence.voice_tone_set", "args": {"tone": "quiet"}},
        {"tool": "presence.set_status_message",
         "args": {"message": "Enjoy. Leon is on standby.", "icon": "🎬"}},
    ],
    "leaving_house": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "Goodbye routine", "icon": "👋"}},
        {"tool": "presence.tts_say",
         "args": {"text": "Have a good one, Sir."},
         "optional": True},
        {"tool": "home.lights_off", "args": {},
         "optional": True, "if_creds": "HASS_TOKEN"},
        {"tool": "home.ha_call_service",
         "args": {"domain": "alarm_control_panel", "service": "alarm_arm_away",
                  "service_data": {}},
         "optional": True, "if_creds": "HASS_TOKEN"},
    ],
    "home_arrival": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "Welcome home", "icon": "🏠"}},
        {"tool": "home.lights_scene", "args": {"name": "welcome"},
         "optional": True, "if_creds": "HASS_TOKEN"},
        {"tool": "comms.list_all_unread", "args": {}, "optional": True},
        {"tool": "presence.tts_say",
         "args": {"text": "Welcome back, Sir. I have your updates ready."},
         "optional": True},
    ],
    "sleep_mode": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "Sleep mode", "icon": "🌙"}},
        {"tool": "report.end_of_day", "args": {}},
        {"tool": "memory.episode_log",
         "args": {"event": "Dean went to bed", "tags": ["sleep", "routine"]}},
        {"tool": "home.lights_off", "args": {},
         "optional": True, "if_creds": "HASS_TOKEN"},
        {"tool": "spotify.play_pause", "args": {}, "optional": True},
        {"tool": "presence.voice_tone_set", "args": {"tone": "quiet"}},
        {"tool": "presence.tts_say",
         "args": {"text": "Goodnight, Sir."},
         "optional": True},
    ],
    "deep_work_block": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "Deep work block — 90 minutes", "icon": "⏱️"}},
        {"tool": "presence.voice_tone_set", "args": {"tone": "quiet"}},
        {"tool": "presence.set_status_message",
         "args": {"message": "Deep work • 90 minutes", "icon": "⏱️", "ttl_seconds": 5400}},
    ],
    "end_of_day_close": [
        {"tool": "presence.dashboard_event",
         "args": {"kind": "action", "message": "End-of-day wrap", "icon": "📝"}},
        {"tool": "report.end_of_day", "args": {}},
        {"tool": "meta.snapshot_brain_state", "args": {"label": "auto-eod"}, "optional": True},
        {"tool": "presence.voice_tone_set", "args": {"tone": "casual"}},
    ],
    "panic_quiet": [
        # Instant silence — Dean is in a meeting/call. Stops everything noisy.
        {"tool": "spotify.play_pause", "args": {}, "optional": True},
        {"tool": "presence.voice_tone_set", "args": {"tone": "quiet"}},
        {"tool": "presence.set_status_message",
         "args": {"message": "QUIET MODE", "icon": "🤫", "severity": "warn"}},
    ],
    "weather_brief": [
        {"tool": "info.weather_now", "args": {"location": "Los Angeles"}},
        {"tool": "info.weather_forecast", "args": {"location": "Los Angeles", "days": 3},
         "optional": True},
    ],
    "news_brief": [
        {"tool": "info.news_hackernews_top", "args": {"limit": 5}},
    ],
    "status_report": [
        {"tool": "report.status_pulse", "args": {}},
        {"tool": "report.project_status_roundup", "args": {}},
        {"tool": "presence.dashboard_log_recent", "args": {"limit": 10}},
    ],
}


def _load_custom() -> Dict[str, List[Dict[str, Any]]]:
    if not _MACRO_FILE.exists():
        return {}
    try:
        return json.loads(_MACRO_FILE.read_text())
    except Exception:
        return {}


def _save_custom(data: Dict[str, List[Dict[str, Any]]]) -> None:
    _MACRO_FILE.write_text(json.dumps(data, indent=2))


def _resolve_macro(name: str) -> Optional[List[Dict[str, Any]]]:
    """Disk overrides builtins."""
    custom = _load_custom()
    if name in custom:
        return custom[name]
    return BUILTIN_MACROS.get(name)


def _list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all available macros (builtins + custom). Custom overrides builtins."""
    custom = _load_custom()
    builtins = list(BUILTIN_MACROS.keys())
    return {
        "ok": True,
        "macros": sorted(set(builtins + list(custom.keys()))),
        "builtins": builtins,
        "custom": list(custom.keys()),
        "count": len(set(builtins) | set(custom.keys())),
    }


def _resolve_tool_callable(dotted_name: str):
    """Look up a callable for a dotted tool name across local-tool registries
    and the actuator. Returns a (fn_or_None, kind) tuple where kind is
    'local' | 'actuator' | None."""
    # Brain-local registries
    for mod_path in (
        "brain.memory_extras",
        "brain.introspection",
        "brain.tentacle_orchestration",
        "brain.reports",
        "brain.presence",
        "brain.self_improve",
        "brain.integrations.comms",
        "brain.integrations.smart_home",
        "brain.integrations.phone",
    ):
        try:
            m = __import__(mod_path, fromlist=["EXTRA_TOOLS"])
            et = getattr(m, "EXTRA_TOOLS", {})
            if dotted_name in et:
                return et[dotted_name], "local"
        except Exception:
            continue
    # Fall through to actuator
    return None, "actuator"


def _call_step(step: Dict[str, Any]) -> Dict[str, Any]:
    import os
    tool = step.get("tool")
    args = step.get("args", {}) or {}
    creds_var = step.get("if_creds")
    if creds_var and not os.environ.get(creds_var):
        return {"ok": True, "skipped": True, "reason": f"missing {creds_var}", "tool": tool}
    fn, kind = _resolve_tool_callable(tool)
    try:
        if fn is not None:
            r = fn(args)
        else:
            # actuator dispatch
            from brain.actuator_client import call as _act_call
            r = _act_call(tool, args)
        if not isinstance(r, dict):
            r = {"ok": True, "result": r}
        r["__tool"] = tool
        r["__kind"] = kind
        return r
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "__tool": tool, "__kind": kind}


def _audit(entry: Dict[str, Any]) -> None:
    try:
        with _AUDIT_FILE.open("a") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass


def _run(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run a macro by name.

    Args:
      name: macro name (required)
      stop_on_error: abort on first non-optional failure (default True)
    """
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    steps = _resolve_macro(name)
    if steps is None:
        return {"ok": False, "error": f"unknown macro: {name}"}
    stop_on_error = bool(args.get("stop_on_error", True))

    results = []
    started = time.time()
    aborted = False
    for i, step in enumerate(steps):
        r = _call_step(step)
        results.append(r)
        if not r.get("ok") and not step.get("optional") and stop_on_error:
            aborted = True
            break
    finished = time.time()

    payload = {
        "ok": not aborted,
        "macro": name,
        "steps": len(steps),
        "ran": len(results),
        "aborted": aborted,
        "duration_s": round(finished - started, 3),
        "results": results,
    }
    _audit({
        "ts": started,
        "macro": name,
        "duration_s": payload["duration_s"],
        "aborted": aborted,
        "step_count": len(results),
        "step_oks": sum(1 for r in results if r.get("ok")),
        "step_failures": sum(1 for r in results if not r.get("ok") and not r.get("skipped")),
    })
    return payload


def _run_if_present(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run a macro if defined, otherwise return a no-op success. Useful for
    routines + external triggers that shouldn't fail because of a missing
    macro definition."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    if _resolve_macro(name) is None:
        return {"ok": True, "skipped": True, "reason": f"macro '{name}' not defined"}
    return _run(args)


def _define(args: Dict[str, Any]) -> Dict[str, Any]:
    """Save a custom macro to disk (or override a builtin).

    Args:
      name: macro name (required)
      steps: list of {tool, args, optional?, if_creds?} (required)
    """
    name = args.get("name")
    steps = args.get("steps")
    if not name or not isinstance(steps, list):
        return {"ok": False, "error": "name + steps (list) required"}
    # Light validation: each step must be a dict with 'tool'
    for s in steps:
        if not isinstance(s, dict) or "tool" not in s:
            return {"ok": False, "error": "each step must be a dict with a 'tool' key"}
    custom = _load_custom()
    custom[name] = steps
    _save_custom(custom)
    return {"ok": True, "macro": name, "steps_count": len(steps), "overrides_builtin": name in BUILTIN_MACROS}


def _delete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a custom macro (does NOT delete builtins).

    Args:
      name: macro name (required)
    """
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    custom = _load_custom()
    if name not in custom:
        return {"ok": False, "error": f"no custom macro '{name}' (builtins can't be deleted, only overridden)"}
    del custom[name]
    _save_custom(custom)
    return {"ok": True, "deleted": name}


def _dry_run(args: Dict[str, Any]) -> Dict[str, Any]:
    """Show the steps a macro would execute without running them.

    Args:
      name: macro name (required)
    """
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    steps = _resolve_macro(name)
    if steps is None:
        return {"ok": False, "error": f"unknown macro: {name}"}
    out = []
    for i, s in enumerate(steps):
        fn, kind = _resolve_tool_callable(s.get("tool", ""))
        out.append({
            "step": i + 1,
            "tool": s.get("tool"),
            "args_keys": list((s.get("args") or {}).keys()),
            "optional": s.get("optional", False),
            "if_creds": s.get("if_creds"),
            "resolvable": fn is not None or kind == "actuator",
            "kind": kind,
        })
    return {"ok": True, "macro": name, "steps_count": len(out), "steps": out}


def _last_runs(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read the macro audit log — recent macro runs.

    Args:
      limit: how many recent runs (default 20)
    """
    limit = min(200, max(1, int(args.get("limit", 20))))
    if not _AUDIT_FILE.exists():
        return {"ok": True, "runs": [], "count": 0}
    lines = _AUDIT_FILE.read_text().strip().split("\n")
    runs = []
    for line in lines[-limit:]:
        try:
            runs.append(json.loads(line))
        except Exception:
            continue
    return {"ok": True, "runs": runs, "count": len(runs)}


EXTRA_TOOLS = {
    "macro.list":           _list,
    "macro.run":            _run,
    "macro.run_if_present": _run_if_present,
    "macro.define":         _define,
    "macro.delete":         _delete,
    "macro.dry_run":        _dry_run,
    "macro.last_runs":      _last_runs,
}
