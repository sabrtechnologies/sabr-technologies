"""Core facts first: query-aware recall over the seeded core facts.

Why this exists (Dean, item 6, 2026-10-16): facts Dean told once were known
in some replies and missing in others. Three separate causes:

  * The CLI prompt injects brain_state/core_facts.md cut at 12,000 chars, but
    the owner facts run past 100,000 chars, so any fact past the cut never
    reached the model unless something else happened to recall it.
  * knowledge_search ranks core facts against every other row; an older
    distilled or conversation row that says something different could outrank
    the curated fact, or push it out of the top-k entirely.
  * The two recall paths (tool vs prompt) used different code.

This module is the ONE place both paths ask "which core facts are about this
message?". It reads the rows seed_core_facts.py wrote (source=core_fact_seed)
from the knowledge DB, so it holds no facts itself and returns nothing on a
client build (whose DB has no seeded owner facts).

Matching is IDF-weighted term overlap over each fact's text AND tags, with
name aliases taken from the facts themselves (two capitalised spellings
joined by a slash, e.g. "Jon/John", make either spelling find the fact).
Rare words (names) dominate the score.
"""
from __future__ import annotations

import math
import re
import sqlite3
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set

SOURCE_TAG = "core_fact_seed"

_STOP = set("""a an the and or but if of in on at by to for from with into about as is are was
were be been being do does did done has have had what who whom whose which when where why how
that this these those it its he she him her his hers they them their we us our you your i me my
mine not no yes so than then there here just also very can could would should will shall may
might must leon dean tell know knows remember say said says thing things anything something""".split())

_SUFFIXES = ("ing", "ers", "er", "ed", "s")


def _stem(word: str) -> str:
    for suf in _SUFFIXES:
        if word.endswith(suf) and len(word) - len(suf) >= 3:
            return word[: -len(suf)]
    return word


def _terms(text: str) -> Set[str]:
    words = re.findall(r"[a-z0-9]+", (text or "").lower().replace("’", "'"))
    return {_stem(w) for w in words if len(w) > 1 and w not in _STOP}


def _alias_groups(facts: Iterable[dict]) -> Dict[str, Set[str]]:
    """Name spellings joined by a slash in a fact ("Jon/John") are the
    same entity."""
    groups: Dict[str, Set[str]] = {}
    for f in facts:
        for a, b in re.findall(r"\b([A-Z][A-Za-z]{2,})/([A-Z][A-Za-z]{2,})\b", f.get("text") or ""):
            a, b = _stem(a.lower()), _stem(b.lower())
            merged = groups.get(a, {a}) | groups.get(b, {b})
            for w in merged:
                groups[w] = merged
    return groups


def _fact_terms(f: dict) -> Set[str]:
    tags = f.get("tags") or ""
    if not isinstance(tags, str):
        tags = ",".join(tags)
    return _terms(f.get("text") or "") | _terms(tags.replace(",", " "))


def rank(query: str, facts: List[dict], limit: int = 5) -> List[dict]:
    """Return the core facts about `query`, best first (each a copy of the
    input dict plus a 'score'). Empty when nothing in the query is specific
    enough to anchor on."""
    q = _terms(query)
    if not q or not facts or limit <= 0:
        return []
    groups = _alias_groups(facts)
    expanded = {t: groups.get(t, {t}) for t in q}
    term_sets = [_fact_terms(f) for f in facts]
    n = len(facts)
    scored = []
    for f, ft in zip(facts, term_sets):
        score = 0.0
        for t, forms in expanded.items():
            if forms & ft:
                df = sum(1 for other in term_sets if forms & other)
                score += math.log(1 + n / df)
        if score > 0:
            # Shorter facts that cover the query are more on-topic than long
            # ones that brush past it (mild, never dominates the names).
            score /= 1 + len(f.get("text") or "") / 6000
            scored.append((score, f))
    if not scored:
        return []
    scored.sort(key=lambda x: -x[0])
    best = scored[0][0]
    out = []
    for score, f in scored[:limit]:
        if score < 0.45 * best:
            break
        out.append(dict(f, score=round(score, 4)))
    return out


def load_core_facts(db_path: Optional[str]) -> List[dict]:
    """The seeded core-fact rows. Read-only; [] when the DB or table is absent."""
    if not db_path or not Path(db_path).exists():
        return []
    try:
        conn = sqlite3.connect(Path(db_path).resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT id, text, source, tags, timestamp FROM knowledge "
                                "WHERE source = ? ORDER BY id", (SOURCE_TAG,)).fetchall()
        finally:
            conn.close()
    except sqlite3.Error:
        return []
    return [dict(r) for r in rows]


def core_fact_hits(query: str, db_path: Optional[str], limit: int = 5) -> List[dict]:
    return rank(query, load_core_facts(db_path), limit=limit)


def prompt_block(query: str, db_path: Optional[str], limit: int = 5,
                 max_chars: int = 4000) -> str:
    """The [CORE FACTS ABOUT THIS] block for a turn, or ""."""
    try:
        from brain.identity import is_client_si
        if is_client_si():
            return ""
    except Exception:
        pass
    hits = core_fact_hits(query, db_path, limit=limit)
    if not hits:
        return ""
    lines, used = [], 0
    for h in hits:
        line = "- " + (h.get("text") or "").strip()
        if used + len(line) > max_chars:
            line = line[: max(0, max_chars - used - 3)] + "..."
        lines.append(line)
        used += len(line)
        if used >= max_chars:
            break
    return ("[CORE FACTS ABOUT THIS — permanent memory, authoritative. If an older "
            "memory or recalled message says something different, these win:]\n"
            + "\n".join(lines))


def merge_into_matches(query: str, db_path: Optional[str], matches: List[dict],
                       limit: int) -> List[dict]:
    """knowledge_search: core facts about the query first, then the other
    matches minus duplicates of those facts, capped at `limit` (plus room
    for the core facts themselves, so they never push everything out)."""
    core = core_fact_hits(query, db_path, limit=min(limit, 5))
    if not core:
        return matches
    ids = {c["id"] for c in core}
    norm = {re.sub(r"\W+", " ", (c.get("text") or "").lower()).strip()[:160] for c in core}
    out = []
    for c in core:
        tags = c.get("tags") or ""
        out.append({
            "id": c["id"], "source": SOURCE_TAG,
            "tags": [t for t in tags.split(",") if t] if isinstance(tags, str) else list(tags),
            "text": (c.get("text") or "")[:2000], "timestamp": c.get("timestamp"),
            "core_fact": True,
        })
    for m in matches:
        if m.get("id") in ids:
            continue
        if re.sub(r"\W+", " ", (m.get("text") or "").lower()).strip()[:160] in norm:
            continue
        out.append(m)
    return out[: max(limit, len(core))]
