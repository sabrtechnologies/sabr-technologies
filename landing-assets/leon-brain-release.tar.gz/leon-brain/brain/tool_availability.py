"""Credential-aware tool catalog and fail-once integration errors.

Catalog reads never contact providers. An observed authorization failure stays
unavailable until credentials change; transient failures have a short cooldown.
No tokens or provider response bodies are written to disk or returned here.
"""
from functools import wraps
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time

_FAILURES = {}
_LOCKS = {name: threading.RLock() for name in ('calendar', 'gmail')}
_BROWSER_FAILURE = ('', 0.0)


def browser_result(result):
    """Keep transport errors honest without masking argument/selector errors."""
    global _BROWSER_FAILURE
    error = str(result.get('error', '')) if isinstance(result, dict) else ''
    if result.get('ok'):
        _BROWSER_FAILURE = ('', 0.0)
    elif any(word in error.lower() for word in ('cdpunreachable', 'cdp unreachable', 'cdp not available')):
        reason = ('Browser DOM unavailable: no reachable browser debugging endpoint through '
                  'the bridge. Use desktop_state or the configured screen agent; '
                  'no separate browser or logged-in session is assumed.')
        _BROWSER_FAILURE = (reason, time.monotonic() + 30)
        return {**result, 'error': reason, 'unavailable': True}
    return result


def _config(service):
    # Respect the integrations' paths, including test/install overrides.
    if service == 'calendar':
        from brain.integrations import calendar_power as module
        env_name = 'GCAL_ACCESS_TOKEN'
    else:
        from brain.integrations import email_power as module
        env_name = 'GMAIL_ACCESS_TOKEN'
    env = os.environ.get(env_name, '').strip()
    digest = hashlib.sha256(env.encode())
    files = []
    for path in (module._TOKENS_PATH, module._CREDS_PATH):
        try:
            data = Path(path).read_bytes()
        except OSError:
            data = b''
        digest.update(data)
        try:
            value = json.loads(data)
            files.append(value if isinstance(value, dict) else {})
        except (ValueError, UnicodeError):
            files.append({})
    tokens, creds = files
    configured = bool(env or tokens.get('access_token') or
                      (tokens.get('refresh_token') and creds))
    return digest.hexdigest(), configured


def integration_unavailable(service):
    fingerprint, configured = _config(service)
    if not configured:
        return f'{service.title()} unavailable: Google authorization is not configured.'
    with _LOCKS[service]:
        failed = _FAILURES.get(service)
        if failed and failed[0] == fingerprint and time.monotonic() < failed[2]:
            return failed[1]
        _FAILURES.pop(service, None)
    return ''


def integration_call(service):
    """Guard direct and dispatcher callers, not only the advertised catalog."""
    def decorate(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            with _LOCKS[service]:
                reason = integration_unavailable(service)
                if reason:
                    return {'ok': False, 'error': reason, 'unavailable': True}
                result = fn(*args, **kwargs)
                if isinstance(result, dict) and result.get('ok') is False:
                    error = str(result.get('error', ''))
                    auth = any(word in error.lower() for word in
                               ('401', 'invalid_grant', 'invalid_client', 're-authorization',
                                'not configured', 'credentials', 'no token'))
                    reason = (f'{service.title()} unavailable: Google re-authorization is required.'
                              if auth else f'{service.title()} request failed; retry after 30 seconds.')
                    _FAILURES[service] = (_config(service)[0], reason,
                                         float('inf') if auth else time.monotonic() + 30)
                    if auth:
                        return {'ok': False, 'error': reason, 'unavailable': True}
                return result
        return wrapped
    return decorate


def tentacle_unavailable():
    try:
        result = subprocess.run(
            ['tmux', 'list-panes', '-s', '-t', 'agents', '-F', '#{pane_current_command}'],
            capture_output=True, text=True, timeout=2)
        if result.returncode == 0 and any(
                Path(line.strip()).name.lower() in ('claude', 'codex')
                for line in result.stdout.splitlines()):
            return ''
    except (OSError, subprocess.TimeoutExpired):
        pass
    return ('Tentacle delegation unavailable: no recognized coding CLI is running '
            'in the agents tmux session. Use the configured coding-job tool.')


def unavailable_reason(name):
    name = name.replace('.', '_')
    if name.startswith('browser_dom_') or name == 'browser_cdp':
        reason, until = _BROWSER_FAILURE
        return reason if time.monotonic() < until else ''
    if name.startswith('email_gmail_'):
        return integration_unavailable('gmail')
    if name.startswith('cal_') and not name.startswith(('cal_caldav_', 'cal_local_')):
        return integration_unavailable('calendar')
    if name in ('tentacle_delegate_task', 'tentacle_broadcast'):
        return tentacle_unavailable()
    return ''


def available_tools(tools):
    # Compute each service once per catalog, including the bounded tmux query.
    reasons = {}
    out = []
    for tool in tools:
        name = tool.get('name', '').replace('.', '_')
        group = ('gmail' if name.startswith('email_gmail_') else
                 'calendar' if name.startswith('cal_') and not name.startswith(('cal_caldav_', 'cal_local_')) else
                 'tentacle' if name in ('tentacle_delegate_task', 'tentacle_broadcast') else
                 'browser' if name.startswith('browser_dom_') else '')
        if group and group not in reasons:
            reasons[group] = unavailable_reason(name)
        if not group or not reasons[group]:
            out.append(tool)
    return out
