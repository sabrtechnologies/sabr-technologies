"""Pure pacing policy; simulation_loop retains exclusive ownership of step().

No timers, threads, Brain construction, persistence, or neuron skipping. The
integrator enables this policy behind its activity flag and supplies the SAME
has_input observation used by the old loop. Compatibility mode preserves the
existing 20/60 Hz targets and overrun yield exactly, including for BURST labels.
"""
from dataclasses import dataclass
from enum import Enum
import math
import threading
import time


class Activity(str, Enum):
    REST = "REST"
    ATTEND = "ATTEND"
    BURST = "BURST"


def _positive(value, name, *, zero=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0 or (not zero and value == 0):
        raise ValueError(name + " must be finite and " + ("nonnegative" if zero else "positive"))
    return float(value)


@dataclass(frozen=True)
class ActivityDecision:
    state: Activity
    hz: float
    experimental: bool

    @property
    def target_seconds(self):
        return 1.0 / self.hz


class BrainActivityController:
    def __init__(self, *, enabled=False, idle_hz=20, active_hz=60,
                 experimental=False, rest_hz=None, attend_hz=None, burst_hz=None,
                 max_burst_seconds=1.0, yield_floor_seconds=.020, yield_fraction=.35,
                 clock=time.monotonic):
        self.enabled, self.experimental = bool(enabled), bool(experimental)
        self.idle_hz = _positive(idle_hz, "idle_hz")
        self.active_hz = _positive(active_hz, "active_hz")
        self.rest_hz = _positive(self.idle_hz if rest_hz is None else rest_hz, "rest_hz")
        self.attend_hz = _positive(self.active_hz if attend_hz is None else attend_hz, "attend_hz")
        self.burst_hz = _positive(self.active_hz if burst_hz is None else burst_hz, "burst_hz")
        self.max_burst_seconds = _positive(max_burst_seconds, "max_burst_seconds")
        self.yield_floor_seconds = _positive(yield_floor_seconds, "yield_floor_seconds", zero=True)
        self.yield_fraction = _positive(yield_fraction, "yield_fraction", zero=True)
        self._clock, self._burst_until, self._lock = clock, float("-inf"), threading.Lock()

    def request_burst(self, seconds=None):
        duration = self.max_burst_seconds if seconds is None else _positive(seconds, "burst seconds")
        if not self.enabled:
            return False
        now = self._clock()
        if not math.isfinite(now):
            raise ValueError("clock must be finite")
        with self._lock:
            self._burst_until = max(self._burst_until, now + min(duration, self.max_burst_seconds))
        return True

    def decide(self, has_input):
        now = self._clock()
        if not math.isfinite(now):
            raise ValueError("clock must be finite")
        with self._lock:
            burst = self.enabled and now < self._burst_until
        state = Activity.BURST if burst else Activity.ATTEND if has_input else Activity.REST
        experimental = self.enabled and self.experimental
        if experimental:
            hz = {Activity.REST: self.rest_hz, Activity.ATTEND: self.attend_hz, Activity.BURST: self.burst_hz}[state]
        else:
            hz = self.active_hz if has_input else self.idle_hz
        return ActivityDecision(state, hz, experimental)

    def sleep_seconds(self, elapsed_seconds, decision):
        elapsed = _positive(elapsed_seconds, "elapsed_seconds", zero=True)
        remaining = decision.target_seconds - elapsed
        return remaining if remaining > 0 else max(self.yield_floor_seconds, elapsed * self.yield_fraction)

    def clear_burst(self):
        with self._lock:
            self._burst_until = float("-inf")
