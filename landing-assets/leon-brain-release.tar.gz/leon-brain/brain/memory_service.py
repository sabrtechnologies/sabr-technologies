"""Unified access to Leon's existing memories, with explicit write authority.

Adapters read canonical files without constructing/migrating existing stores.
The optional writers are already-running canonical store instances. No private
memory database, identity synthesis, inference provider, or background thread is
created here. Integration starts in SHADOW and must explicitly enable writes.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from enum import Enum
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import threading
import time
import uuid


class MemoryType(str, Enum):
    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    PERCEPTUAL = "perceptual"
    SELF = "self"
    PROSPECTIVE = "prospective"
    VALUE = "value"


@dataclass(frozen=True)
class CanonicalRecord:
    store: str
    record_id: str
    memory_type: MemoryType
    text: str
    source: str
    created_ts: float
    salience: float = 0.0
    metadata: dict = field(default_factory=dict)
    state_vector: tuple = ()


@dataclass(frozen=True)
class MemoryHit:
    store: str
    record_id: str
    memory_type: MemoryType
    text: str
    semantic_score: float
    lexical_score: float
    authority_score: float
    recency_score: float
    salience_score: float
    state_match_score: float
    final_score: float
    metadata: dict = field(default_factory=dict)


@dataclass(frozen=True)
class WriteReceipt:
    store: str
    record_id: str
    canonical_written: bool
    indexed: bool
    detail: str = ""


@dataclass(frozen=True)
class ThoughtIntentWriteCapability:
    """Trusted startup capability for one already-owned canonical writer.

    Never deserialize this from a request or model output. This capability does
    not enable MemoryService: its mode and principal policy must also be ON.
    """
    writer: object
    principal: str
    identity_id: str
    producer: str
    max_snapshots: int = 4096
    max_total_bytes: int = 16 * 1024 * 1024
    max_realization_attempts: int = 4096
    max_realization_bytes: int = 16 * 1024 * 1024
    canonical_path: str = field(init=False)
    database_identity: tuple = field(init=False)

    def __post_init__(self):
        from .knowledge_store import KnowledgeStore, _thought_ref
        if type(self.writer) is not KnowledgeStore:
            raise TypeError('existing canonical KnowledgeStore owner required')
        for value in (self.principal, self.identity_id, self.producer):
            _thought_ref(value)
        if (type(self.max_snapshots) is not int or not 1 <= self.max_snapshots <= 100000
                or type(self.max_total_bytes) is not int or not 1 <= self.max_total_bytes <= 64 * 1024 * 1024
                or type(self.max_realization_attempts) is not int or not 1 <= self.max_realization_attempts <= 100000
                or type(self.max_realization_bytes) is not int or not 1 <= self.max_realization_bytes <= 64 * 1024 * 1024):
            raise ValueError('finite thought snapshot quotas required')
        object.__setattr__(self, 'canonical_path', str(Path(self.writer.db_path).resolve()))
        object.__setattr__(self, 'database_identity', self.writer.thought_intent_database_identity())


@dataclass(frozen=True)
class ThoughtIntentReceipt:
    """Confirmed canonical storage only; no inference/action/identity authority."""
    thought_id: str
    snapshot_sha256: str
    principal: str
    identity_id: str
    producer: str
    persisted_wall: float
    replayed: bool
    journal_mode: str
    synchronous: str = 'FULL'
    store: str = 'knowledge'

    @property
    def record_id(self):
        return 'thought_intent:' + self.thought_id


@dataclass(frozen=True)
class StoredThoughtIntent:
    intent: object
    snapshot_sha256: str
    principal: str
    identity_id: str
    producer: str
    persisted_wall: float


@dataclass(frozen=True)
class ThoughtRealizationRequest:
    """Finalized private request metadata; no raw prompt or provider credential."""
    caller: str
    channel: str
    prompt_sha256: str
    configuration_sha256: str
    priority: int
    max_output_tokens: int
    deadline_wall: float
    schema_version: int = 1
    tools_allowed: bool = False
    persist_history: bool = False

    def __post_init__(self):
        self.canonical_dict()

    def canonical_dict(self):
        from .knowledge_store import _realization_descriptor
        value = asdict(self)
        _realization_descriptor(value)
        return value

    def sha256(self):
        from .knowledge_store import _realization_descriptor
        return _realization_descriptor(self.canonical_dict())[1]


@dataclass(frozen=True)
class ThoughtRealizationReceipt:
    """Private durable attempt state; no provider/effect authorization by itself."""
    attempt_id: str
    thought_id: str
    snapshot_sha256: str
    request_sha256: str
    request: ThoughtRealizationRequest
    state: str
    text: str
    reason_code: str
    admitted_wall: float
    finished_wall: object
    result_sha256: object
    principal: str
    identity_id: str
    producer: str
    freshly_admitted: bool
    journal_mode: str
    schema_version: int = 1
    store: str = 'knowledge'

    @property
    def record_id(self):
        return 'thought_realization:' + self.attempt_id

    @property
    def terminal(self):
        return self.state != 'ADMITTED'


def _clip(value):
    try:
        x = float(value)
        return max(0.0, min(1.0, x)) if math.isfinite(x) else 0.0
    except (TypeError, ValueError):
        return 0.0


def _number(value):
    try:
        x = float(value or 0.0)
        return x if math.isfinite(x) else 0.0
    except (TypeError, ValueError):
        return 0.0


def _tokens(text):
    return set(re.findall(r"\w+", str(text).casefold())[:128])


def _lexical(query, text):
    words = _tokens(query)
    return len(words & _tokens(text)) / max(1, len(words))


def _metadata(value):
    try:
        result = json.loads(value) if isinstance(value, str) else (value or {})
        return dict(result) if isinstance(result, dict) else {"_invalid_metadata": True}
    except (TypeError, ValueError):
        return {"_invalid_metadata": True}


class SourcePolicy:
    """Read ACL and trust are separate; source labels do not authenticate anyone.

    Registering a canonical adapter grants access to its legacy unscoped rows.
    Restricted rows require an explicitly supplied principal; malformed policy
    metadata, denied sources and cross-identity records always fail closed.
    Authority weights must be supplied by the integrator's trusted policy.
    """

    def __init__(self, *, principal=None, identity_id=None, allowed_sources=None,
                 denied_sources=(), authority_by_source=None, authorize=None):
        self.principal = principal
        self.identity_id = identity_id
        self.allowed_sources = None if allowed_sources is None else frozenset(allowed_sources)
        self.denied_sources = frozenset(denied_sources)
        self.authority_by_source = dict(authority_by_source or {})
        self.authorize = authorize

    def accepts(self, record):
        m = record.metadata
        for key in ("authorized", "revoked", "unverified"):
            if key in m and not isinstance(m[key], bool):
                return False
        if m.get("_invalid_metadata") or m.get("authorized") is False or m.get("revoked") or m.get("superseded_by"):
            return False
        if record.source in self.denied_sources:
            return False
        if self.allowed_sources is not None and record.source not in self.allowed_sources:
            return False
        for key in ("owner_id", "principal_id"):
            if key in m and (self.principal is None or str(m[key]) != str(self.principal)):
                return False
        if "allowed_principals" in m:
            if not isinstance(m["allowed_principals"], list) or self.principal not in m["allowed_principals"]:
                return False
        if "identity_id" in m and (self.identity_id is None or str(m["identity_id"]) != str(self.identity_id)):
            return False
        if record.memory_type == MemoryType.SELF and (m.get("unverified") or record.source in
                {"vision_daemon", "screen_observer", "audio_daemon"}):
            return False
        try:
            return self.authorize(record) is True if self.authorize else True
        except Exception:
            return False

    def authority(self, record):
        value = _clip(self.authority_by_source.get(record.source, 0.0))
        unverified = record.metadata.get("unverified") or record.source in {
            "vision_daemon", "screen_observer", "audio_daemon"}
        return min(value, 0.1) if unverified else value


class SQLiteAdapter:
    """Read-only, keyset-paged adapters for the four canonical SQLite stores."""

    TABLES = {"knowledge": "knowledge", "episodes": "episodes",
              "graph": "entities", "skills": "skills"}
    SEARCH_FIELDS = {
        "knowledge": ("text", "tags"), "episodes": ("action_name", "action_args_json", "error_text"),
        "graph": ("name", "type", "metadata_json"), "skills": ("name", "steps_json", "notes")}

    def __init__(self, name, path, *, writer=None, query_timeout=0.10):
        if name not in self.TABLES:
            raise ValueError("unknown canonical SQLite store")
        self.name, self.path, self.writer = name, Path(path).resolve(), writer
        self.query_timeout = max(0.01, float(query_timeout))

    @contextmanager
    def _read(self):
        # mode=ro prevents a missing canonical database from being created.
        db = sqlite3.connect(self.path.as_uri() + "?mode=ro", uri=True, timeout=0.1)
        try:
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA query_only=ON")
            deadline = time.monotonic() + self.query_timeout
            db.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
            yield db
        finally:
            db.close()

    def _record(self, row):
        r = dict(row)
        name = self.name
        metadata = _metadata(r.get("metadata", r.get("metadata_json")))
        state = ()
        if name == "knowledge":
            text, source, ts = r["text"], r.get("source") or "unknown", r.get("timestamp")
            kind, salience = MemoryType.SEMANTIC, r.get("strength")
            tags = (r.get("tags") or "").split(",")
            metadata["tags"] = tags
            if source in {"vision_daemon", "screen_observer", "audio_daemon"} or "unverified" in tags:
                metadata["unverified"] = True
            try:
                values = json.loads(r.get("neural_fingerprint") or "[]")
                if isinstance(values, list) and len(values) == 18:
                    state = tuple(float(x) for x in values)
            except (ValueError, TypeError):
                pass
        elif name == "episodes":
            text = " ".join(str(r.get(k) or "") for k in
                            ("action_kind", "action_name", "action_args_json", "error_text", "side_effects_json"))
            # Outcome is essential; actions with opposite results are distinct memories.
            text += " outcome=" + ("open" if r.get("success") is None else str(bool(r["success"])))
            source, ts, kind, salience = "episodes", r.get("ts"), MemoryType.EPISODIC, r.get("salience")
            metadata.update({k: r.get(k) for k in ("session_id", "parent_id", "success", "reward", "surprise")})
        elif name == "graph":
            text = str(r.get("type", "")) + ": " + str(r.get("name", ""))
            source, ts, kind, salience = str(metadata.get("source", "graph")), r.get("first_seen"), MemoryType.SEMANTIC, r.get("salience")
            metadata.update(canonical_key=r.get("canonical_key"), entity_type=r.get("type"))
        else:
            text = " ".join(str(r.get(k) or "") for k in ("name", "steps_json", "notes"))
            source, ts, kind, salience = "skills", r.get("last_seen_ts"), MemoryType.PROCEDURAL, r.get("reinforcement")
            metadata.update(state=r.get("state"), signature=r.get("signature"),
                            runs=r.get("runs"), success_runs=r.get("success_runs"))
        requested_type = metadata.get("memory_type")
        if requested_type:
            try:
                kind = MemoryType(requested_type)
            except ValueError:
                metadata["_invalid_metadata"] = True
        return CanonicalRecord(name, str(r["id"]), kind, str(text), source,
                               _number(ts), _clip(salience), metadata, state)

    def get(self, record_id):
        try:
            key = int(record_id)
        except (TypeError, ValueError):
            return None
        with self._read() as db:
            row = db.execute("SELECT * FROM " + self.TABLES[self.name] + " WHERE id=?", (key,)).fetchone()
        return self._record(row) if row else None

    def batch(self, cursor=None, limit=50):
        limit = max(1, min(500, int(limit)))
        with self._read() as db:
            rows = db.execute("SELECT * FROM " + self.TABLES[self.name] + " WHERE id>? ORDER BY id LIMIT ?",
                              (int(cursor or 0), limit)).fetchall()
        return [self._record(r) for r in rows], (rows[-1]["id"] if rows else cursor), len(rows) < limit

    def search(self, query, limit=50):
        words = sorted(_tokens(query))[:16]
        if not words:
            return []
        rows = []
        if self.name == "knowledge":
            # Same canonical FTS source as KnowledgeStore.search, without the
            # mutating semantic_search/associate or lossy _format_results.
            match = " OR ".join('"' + word.replace('"', '""') + '"*' for word in words)
            try:
                with self._read() as db:
                    rows = db.execute("""SELECT k.* FROM knowledge_fts f JOIN knowledge k
                        ON k.id=f.rowid WHERE knowledge_fts MATCH ? ORDER BY rank LIMIT ?""",
                                      (match, min(50, int(limit)))).fetchall()
            except sqlite3.OperationalError:
                pass
        if not rows:
            fields = self.SEARCH_FIELDS[self.name]
            clauses, args = [], []
            for word in words:
                for column in fields:
                    clauses.append("COALESCE(" + column + ",'') LIKE ? ESCAPE '\\'")
                    args.append("%" + word.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
            args.append(min(50, max(1, int(limit))))
            with self._read() as db:
                rows = db.execute("SELECT * FROM " + self.TABLES[self.name] + " WHERE " +
                                  " OR ".join(clauses) + " ORDER BY id DESC LIMIT ?", args).fetchall()
        if self.name == "knowledge":
            from brain.durable_facts import merge_results
            rows = merge_results(self.path, query, [dict(r) for r in rows], limit)
        return [self._record(r) for r in rows]

    def write(self, text, source, metadata, payload):
        if self.writer is None:
            raise RuntimeError("no canonical writer attached")
        if self.name == "knowledge":
            return str(self.writer.store(text, source=source, tags=payload.get("tags"), metadata=metadata))
        if self.name == "episodes":
            required = ("action_kind", "action_name", "action_args", "prediction", "context")
            args = {key: payload[key] for key in required}
            return str(self.writer.record(**args, salience=payload.get("salience", 1.0),
                                          parent_id=payload.get("parent_id")))
        if self.name == "graph":
            return str(self.writer.entity_get_or_create(payload["entity_type"], payload["name"],
                                                        salience=payload.get("salience", 1.0), metadata=metadata))
        if payload.get("approved") is not True or not payload.get("steps"):
            raise ValueError("procedural writes require an approved canonical step chain")
        result = self.writer.add_from_chain(steps=payload["steps"], name=text,
                                            runs=payload.get("runs", 1), success_runs=payload.get("success_runs", 0))
        return str(result.id if hasattr(result, "id") else result)


class AutobiographyAdapter:
    """Stable offset+digest references over the full append-only JSONL file."""
    name = "autobiography"
    MAX_LINE = 1024 * 1024

    def __init__(self, path, *, writer=None):
        self.path, self.writer = Path(path).resolve(), writer

    def _record(self, offset, raw):
        try:
            value = json.loads(raw)
            if not isinstance(value, dict) or not isinstance(value.get("summary"), str):
                return None
        except (ValueError, UnicodeDecodeError):
            return None
        key = str(offset) + ":" + hashlib.sha256(raw).hexdigest()
        details = _metadata(value.get("details"))
        details["category"] = value.get("category")
        kind = MemoryType(details.get("memory_type", "self"))
        return CanonicalRecord(self.name, key, kind, value["summary"],
                               str(details.get("source", "autobiography")), _number(value.get("ts")),
                               _clip(details.get("salience", .5)), details)

    def get(self, record_id):
        try:
            offset, digest = str(record_id).split(":", 1)
            with self.path.open("rb") as stream:
                stream.seek(int(offset))
                raw = stream.readline(self.MAX_LINE + 1)
            if not raw.endswith(b"\n") or len(raw) > self.MAX_LINE or hashlib.sha256(raw).hexdigest() != digest:
                return None
            return self._record(int(offset), raw)
        except (ValueError, OSError):
            return None

    def batch(self, cursor=None, limit=50):
        records, offset = [], int(cursor or 0)
        scanned = 0
        with self.path.open("rb") as stream:
            boundary = self.path.stat().st_size
            if offset > boundary:
                raise ValueError("autobiography shrank; canonical reference audit required")
            stream.seek(offset)
            while scanned < max(1, min(500, int(limit))) and stream.tell() < boundary:
                start = stream.tell()
                raw = stream.readline(self.MAX_LINE + 1)
                if len(raw) > self.MAX_LINE:
                    raise ValueError("autobiography line exceeds bounded reader")
                if not raw.endswith(b"\n") or stream.tell() > boundary:
                    return records, start, False  # Retry a writer's incomplete tail.
                offset = stream.tell()
                scanned += 1
                try:
                    record = self._record(start, raw)
                except ValueError:
                    record = None
                if record:
                    records.append(record)
        return records, offset, offset >= boundary

    def search(self, query, limit=50):
        # Bounded tail fallback before full backfill. Full indexed candidates
        # are rehydrated by get; old history is enumerated by batch, not cache.
        with self.path.open("rb") as stream:
            start = max(0, self.path.stat().st_size - self.MAX_LINE)
            stream.seek(start)
            if start:
                stream.readline(self.MAX_LINE + 1)
            records = []
            while True:
                offset = stream.tell()
                raw = stream.readline(self.MAX_LINE + 1)
                if not raw or not raw.endswith(b"\n") or len(raw) > self.MAX_LINE:
                    break
                try:
                    record = self._record(offset, raw)
                except ValueError:
                    record = None
                if record and _lexical(query, record.text):
                    records.append(record)
        return sorted(records, key=lambda r: (-_lexical(query, r.text), -r.created_ts))[:limit]

    def write(self, text, source, metadata, payload):
        if self.writer is None:
            raise RuntimeError("no canonical writer attached")
        marker = uuid.uuid4().hex
        details = dict(metadata, source=source, memory_service_event_id=marker)
        offset = self.path.stat().st_size if self.path.exists() else 0
        self.writer.record(payload.get("category", "memory"), text, details=details)
        # Canonical record() swallows disk errors: verify the append, never retry.
        records, _, _ = self.batch(offset, 100)
        for record in records:
            if record.metadata.get("memory_service_event_id") == marker:
                return record.record_id
        raise RuntimeError("canonical autobiography persistence not confirmed; do not retry automatically")


class GoalsAdapter:
    name = "goals"

    def __init__(self, path, *, writer=None, max_bytes=16 * 1024 * 1024):
        self.path, self.writer, self.max_bytes = Path(path).resolve(), writer, int(max_bytes)

    def _records(self):
        with self.path.open("rb") as stream:
            raw = stream.read(self.max_bytes + 1)
        if len(raw) > self.max_bytes:
            raise ValueError("goals file exceeds bounded reader")
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError("goals must be a canonical object")
        found = {}
        for bucket in ("goals", "completed", "abandoned"):
            for goal in value.get(bucket, []):
                if not isinstance(goal, dict) or not goal.get("id") or not isinstance(goal.get("description"), str):
                    continue
                key = str(goal["id"])
                if key in found:
                    continue
                metadata = _metadata(goal.get("metadata"))
                metadata.update(status=goal.get("status", "active" if bucket == "goals" else bucket),
                                goal_type=goal.get("type", goal.get("category")), progress=goal.get("progress", 0))
                found[key] = CanonicalRecord(self.name, key, MemoryType.PROSPECTIVE,
                    goal["description"] + (" " + str(goal["notes"]) if goal.get("notes") else ""),
                    str(goal.get("source", "self")), _number(goal.get("created_ts", goal.get("created_at"))),
                    _clip(goal.get("priority", .5)), metadata)
        return found

    def get(self, record_id):
        return self._records().get(str(record_id))

    def batch(self, cursor=None, limit=50):
        records = self._records()
        ids = [key for key in sorted(records) if key > str(cursor or "")][:max(1, min(500, int(limit)))]
        return [records[key] for key in ids], (ids[-1] if ids else cursor), len(ids) < limit

    def search(self, query, limit=50):
        records = [r for r in self._records().values() if _lexical(query, r.text)]
        return sorted(records, key=lambda r: (-_lexical(query, r.text), -r.created_ts))[:limit]

    def write(self, text, source, metadata, payload):
        if self.writer is None:
            raise RuntimeError("no canonical writer attached")
        if metadata:
            raise ValueError("GoalSystem cannot persist per-record policy metadata")
        result = self.writer.add(payload.get("goal_type", "task"), text,
                                 source=source, priority=payload.get("priority", .5))
        # GoalSystem save errors are swallowed and duplicate adds return old IDs.
        record = self.get(result.id)
        if record is None:
            raise RuntimeError("canonical goal persistence not confirmed; do not retry automatically")
        return record.record_id


def canonical_adapters(state_dir, *, skills_path=None, writers=None):
    """Discover existing paths only; absent stores are not silently created."""
    root, writers = Path(state_dir), writers or {}
    specs = [("knowledge", root / "knowledge.db"), ("episodes", root / "episodes.db"),
             ("graph", root / "cognition_graph.db")]
    if skills_path is not None:
        specs.append(("skills", Path(skills_path)))
    adapters = [SQLiteAdapter(name, path, writer=writers.get(name)) for name, path in specs if path.is_file()]
    for name, filename, cls in (("autobiography", "autobiography.jsonl", AutobiographyAdapter),
                                ("goals", "goals.json", GoalsAdapter)):
        path = root / filename
        if path.is_file():
            adapters.append(cls(path, writer=writers.get(name)))
    return adapters


class MemoryService:
    WEIGHTS = {"semantic": .50, "lexical": .20, "authority": .10,
               "salience": .08, "recency": .07, "state_match": .05}

    def __init__(self, adapters, index=None, *, mode="shadow", policy=None, shadow_log=None,
                 thought_intent_capability=None):
        if mode not in {"off", "shadow", "on"}:
            raise ValueError("mode must be off, shadow or on")
        self.adapters = {adapter.name: adapter for adapter in adapters}
        if index is not None and index.path in {adapter.path for adapter in self.adapters.values()}:
            raise ValueError("sidecar aliases canonical store")
        self.index, self.mode, self.policy = index, mode, policy or SourcePolicy()
        self.shadow_log = shadow_log
        if thought_intent_capability is not None and type(thought_intent_capability) is not ThoughtIntentWriteCapability:
            raise TypeError('typed canonical thought write capability required')
        self._thought_intent_capability = thought_intent_capability
        self._lock = threading.RLock()
        self._stats = {"retrievals": 0, "rejected": 0, "stale": 0, "errors": 0}

    def index_record(self, record):
        if not self.policy.accepts(record):
            if self.index:
                self.index.forget_ref(record.store, record.record_id)
            return {"rejected": True}
        if self.index is None:
            return {"indexed": False}
        return self.index.upsert_source_ref(store=record.store, record_id=record.record_id,
            text=record.text, created_ts=record.created_ts, source=record.source,
            authority=self.policy.authority(record), memory_type=record.memory_type.value,
            state_vector=record.state_vector or None)

    def _get(self, store, record_id):
        adapter = self.adapters.get(store)
        if not adapter:
            return None
        try:
            record = adapter.get(record_id)
        except (OSError, ValueError, sqlite3.Error):
            self._stats["errors"] += 1
            return None
        if record and self.policy.accepts(record):
            return record
        self._stats["rejected"] += 1
        return None

    def _legacy(self, query):
        candidates = {}
        for adapter in self.adapters.values():
            try:
                for record in adapter.search(query, 50):
                    if self.policy.accepts(record):
                        candidates[(record.store, record.record_id)] = record
                    else:
                        self._stats["rejected"] += 1
            except (OSError, ValueError, sqlite3.Error):
                self._stats["errors"] += 1
        return sorted(candidates.values(), key=lambda r: (-_lexical(query, r.text), -r.created_ts,
                                                          r.store, r.record_id))[:50]

    def _indexed_lexical(self, query):
        records = []
        if self.index is None:
            return records
        try:
            candidates = self.index.search_lexical(query, limit=50)
        except (OSError, ValueError, sqlite3.Error):
            self._stats["errors"] += 1
            return records
        for candidate in candidates:
            record = self._get(candidate["store"], candidate["record_id"])
            if record and hashlib.sha256(record.text.encode("utf-8")).hexdigest() == candidate["text_hash"]:
                records.append(record)
        return records

    @staticmethod
    def _state_match(a, b):
        if not a or not b or len(a) != len(b):
            return 0.0
        try:
            if not all(math.isfinite(float(x)) for x in tuple(a) + tuple(b)):
                return 0.0
            norm = math.sqrt(sum(float(x)**2 for x in a) * sum(float(x)**2 for x in b))
            return _clip(sum(float(x)*float(y) for x, y in zip(a, b)) / norm) if norm else 0.0
        except (ValueError, TypeError):
            return 0.0

    def _hit(self, record, query, semantic=0.0, state=(), now=None):
        now = time.time() if now is None else now
        age = max(0.0, now - record.created_ts)
        scores = dict(semantic=_clip(semantic), lexical=_lexical(query, record.text),
                      authority=self.policy.authority(record), salience=_clip(record.salience),
                      recency=math.exp(-age / (30 * 86400)),
                      state_match=self._state_match(record.state_vector, state))
        final = sum(scores[k] * v for k, v in self.WEIGHTS.items())
        metadata = dict(record.metadata, source=record.source, created_ts=record.created_ts,
                        canonical_ref={"store": record.store, "record_id": record.record_id},
                        score_weights=dict(self.WEIGHTS), score_components=scores)
        return MemoryHit(record.store, record.record_id, record.memory_type, record.text,
                         scores["semantic"], scores["lexical"], scores["authority"], scores["recency"],
                         scores["salience"], scores["state_match"], final, metadata)

    def retrieve(self, query, *, limit=10, state_vector=(), trace_id=None):
        """SHADOW/OFF and missing semantic model preserve lexical result order.

        SHADOW compares the proposed rerank but returns the canonical legacy
        candidates. Semantic candidates are never trusted without rehydration.
        """
        started = time.monotonic()
        limit = min(50, max(0, int(limit)))
        legacy = self._legacy(query)
        canonical = {(r.store, r.record_id): r for r in legacy}
        semantic = {}
        if self.mode != "off" and self.index:
            for record in self._indexed_lexical(query):
                canonical[(record.store, record.record_id)] = record
            try:
                results = self.index.search(query, limit=50)
            except (OSError, ValueError, sqlite3.Error):
                results = []
                self._stats["errors"] += 1
            for candidate in results:
                key = (candidate["store"], candidate["record_id"])
                record = self._get(*key)
                if not record:
                    continue
                digest = hashlib.sha256(record.text.encode("utf-8")).hexdigest()
                if candidate["text_hash"] != digest:
                    self._stats["stale"] += 1
                    continue
                canonical[key], semantic[key] = record, candidate["score"]
        now = time.time()
        ranked = [self._hit(r, query, semantic.get(key, 0), state_vector, now)
                  for key, r in canonical.items()]
        ranked.sort(key=lambda h: (-h.final_score, h.store, h.record_id))
        legacy_hits = [self._hit(r, query, semantic.get((r.store, r.record_id), 0), state_vector, now)
                       for r in legacy[:limit]]
        self._stats["retrievals"] += 1
        if self.mode == "shadow" and self.shadow_log:
            old = [(h.store, h.record_id) for h in legacy_hits]
            new = [(h.store, h.record_id) for h in ranked[:limit]]
            self._log({"kind": "memory_retrieval", "trace_id": trace_id,
                       "legacy": old, "v2": new, "overlap": len(set(old) & set(new)) / max(1, len(old)),
                       "latency_ms": (time.monotonic() - started) * 1000,
                       "semantic_candidates": len(semantic)})
        return ranked[:limit] if self.mode == "on" and semantic else legacy_hits

    def _log(self, event):
        try:
            self.shadow_log(dict(event))
        except Exception:
            self._stats["errors"] += 1

    def record_outcome(self, trace_id, *, verified_success, outcome=None):
        if self.shadow_log:
            self._log({"kind": "memory_outcome", "trace_id": trace_id,
                       "verified_success": verified_success is True, "outcome": outcome})

    def remember(self, text, *, store="knowledge", source=None, metadata=None,
                 memory_type=None, payload=None):
        if self.mode != "on":
            raise PermissionError("canonical writes require explicitly enabled ON mode")
        adapter = self.adapters.get(store)
        if adapter is None:
            raise ValueError("canonical store is not registered")
        metadata, payload = dict(metadata or {}), dict(payload or {})
        source = source or ("unknown" if store == "knowledge" else "self" if store == "goals" else store)
        if store in {"episodes", "skills"} and source != store:
            raise ValueError("canonical store cannot persist supplied source")
        if store == "graph":
            metadata["source"] = source
        kind = MemoryType(memory_type or ("prospective" if store == "goals" else
                          "self" if store == "autobiography" else "procedural" if store == "skills" else
                          "episodic" if store == "episodes" else "semantic"))
        if memory_type is not None:
            metadata["memory_type"] = kind.value
        proposal = CanonicalRecord(store, "pending", kind, text, source, time.time(), metadata=metadata)
        if not self.policy.accepts(proposal):
            raise PermissionError("source policy rejected canonical write")
        # Some canonical APIs cannot persist policy metadata. Never drop ACLs.
        if store in {"episodes", "skills"} and metadata:
            raise ValueError("canonical store cannot persist supplied policy metadata")
        with self._lock:
            record_id = adapter.write(text, source, metadata, payload)
            record = self._get(store, record_id)
            if record is None:
                return WriteReceipt(store, record_id, True, False, "canonical result not readable/authorized; do not retry")
            try:
                self.index_record(record)
                return WriteReceipt(store, record_id, True, self.index is not None)
            except Exception as exc:
                # Canonical commit already happened. Backfill repairs the index;
                # never repeat a canonical write because its sidecar failed.
                return WriteReceipt(store, record_id, True, False, "index_pending:" + type(exc).__name__)

    def _thought_writer(self):
        # Initial OFF/SHADOW and absent capability return before any DB open.
        if self.mode != 'on':
            raise PermissionError('canonical thought snapshots require explicit ON mode')
        capability = self._thought_intent_capability
        if type(capability) is not ThoughtIntentWriteCapability:
            raise PermissionError('owned thought snapshot write capability required')
        from .knowledge_store import KnowledgeStore
        adapter = self.adapters.get('knowledge')
        if (type(adapter) is not SQLiteAdapter or adapter.writer is not capability.writer
                or type(adapter.writer) is not KnowledgeStore
                or str(adapter.path) != capability.canonical_path
                or str(Path(adapter.writer.db_path).resolve()) != capability.canonical_path
                or self.policy.principal != capability.principal
                or self.policy.identity_id != capability.identity_id):
            raise PermissionError('canonical thought owner or principal differs')
        adapter.writer._check_thought_database(capability.database_identity)
        return capability

    def _thought_policy(self, found):
        record = CanonicalRecord('knowledge', 'thought_intent:' + found['thought_id'],
            MemoryType.WORKING, '', 'internal_state_snapshot', found.get('persisted_wall', 0),
            metadata=found['metadata'])
        if not self.policy.accepts(record):
            raise PermissionError('private thought snapshot policy denied')

    @contextmanager
    def _thought_access(self, capability):
        from .knowledge_store import ThoughtSnapshotBusy, _THOUGHT_TIMEOUT
        if not self._lock.acquire(timeout=_THOUGHT_TIMEOUT):
            raise ThoughtSnapshotBusy('canonical memory service busy')
        try:
            if self._thought_writer() is not capability:
                raise PermissionError('canonical thought owner changed')
            yield
        finally:
            self._lock.release()

    def remember_thought_intent(self, intent):
        """Store a complete private intent before any language realization.

        This specialized remember path neither indexes nor embeds private state.
        Only an exact committed readback returns a receipt. Exceptions prohibit
        treating the operation as persistence; recover using the original ID.
        The eventual executive still owns inference admission independently.
        """
        capability = self._thought_writer()
        from .knowledge_store import _thought_snapshot
        identity, payload, digest, metadata, _ = _thought_snapshot(intent,
            principal=capability.principal, identity_id=capability.identity_id, producer=capability.producer)
        self._thought_policy({'thought_id': identity, 'metadata': json.loads(metadata)})
        with self._thought_access(capability):
            found = capability.writer.store_thought_intent_snapshot(intent,
                principal=capability.principal, identity_id=capability.identity_id, producer=capability.producer,
                database_identity=capability.database_identity,
                max_snapshots=capability.max_snapshots, max_total_bytes=capability.max_total_bytes)
            # Recheck publication after I/O: retirement/selection changes may
            # preserve the snapshot but must not release a stale success receipt.
            if self._thought_writer() is not capability:
                raise PermissionError('canonical thought owner changed after commit')
            if (found['thought_id'] != identity or found['snapshot_sha256'] != digest
                    or found['payload'] != payload or found['metadata'] != json.loads(metadata)):
                raise RuntimeError('canonical thought readback differs')
            self._thought_policy(found)
            return ThoughtIntentReceipt(identity, digest, capability.principal, capability.identity_id,
                capability.producer, found['persisted_wall'], found['replayed'], found['journal_mode'])

    def recall_thought_intent(self, thought_id):
        """Exact private canonical lookup, separate from generic search/indexing."""
        capability = self._thought_writer()
        from .cognition.thought_intent import ThoughtIntent
        with self._thought_access(capability):
            found = capability.writer.read_thought_intent_snapshot(thought_id,
                principal=capability.principal, identity_id=capability.identity_id, producer=capability.producer,
                database_identity=capability.database_identity)
            if self._thought_writer() is not capability:
                raise PermissionError('canonical thought owner changed during lookup')
            if found is None:
                return None
            self._thought_policy(found)
            return StoredThoughtIntent(ThoughtIntent(**json.loads(found['payload'])), found['snapshot_sha256'],
                capability.principal, capability.identity_id, capability.producer, found['persisted_wall'])

    def _realization_policy(self, metadata):
        record = CanonicalRecord('knowledge', 'thought_realization:pending', MemoryType.WORKING,
                                 '', 'language_realization', 0, metadata=metadata)
        if not self.policy.accepts(record):
            raise PermissionError('private realization policy denied')

    def _realization_receipt(self, found, capability):
        if self._thought_writer() is not capability:
            raise PermissionError('canonical realization owner changed')
        if found is None:
            return None
        self._realization_policy(json.loads(found['metadata']))
        return ThoughtRealizationReceipt(found['attempt_id'], found['thought_id'], found['snapshot_sha256'],
            found['request_sha256'], ThoughtRealizationRequest(**json.loads(found['request_json'])),
            found['state'], found['text'], found['reason_code'], found['admitted_wall'], found['finished_wall'],
            found['result_sha256'], capability.principal, capability.identity_id, capability.producer,
            found['freshly_admitted'], found['journal_mode'])

    def admit_thought_realization(self, thought_id, *, snapshot_sha256, attempt_id,
                                  request_sha256, request_descriptor):
        """Checkpoint before scheduler submission; replay never creates a new ticket.

        Only freshly_admitted=True identifies this call's confirmed fresh insert.
        ADMITTED retained after restart/unknown commit is ambiguous and must not
        be dispatched again. Current executive/scheduler authority is separate.
        """
        capability = self._thought_writer()
        if type(request_descriptor) is not ThoughtRealizationRequest:
            raise TypeError('typed finalized realization descriptor required')
        descriptor = request_descriptor.canonical_dict()
        from .knowledge_store import _realization_metadata
        self._realization_policy(json.loads(_realization_metadata(
            capability.principal, capability.identity_id, capability.producer)))
        with self._thought_access(capability):
            found = capability.writer.admit_thought_realization(thought_id,
                snapshot_sha256=snapshot_sha256, attempt_id=attempt_id, request_sha256=request_sha256,
                request_descriptor=descriptor, principal=capability.principal,
                identity_id=capability.identity_id, producer=capability.producer,
                database_identity=capability.database_identity, max_attempts=capability.max_realization_attempts,
                max_total_bytes=capability.max_realization_bytes)
            return self._realization_receipt(found, capability)

    def finish_thought_realization(self, attempt_id, *, thought_id, snapshot_sha256,
                                   request_sha256, outcome, text='', reason_code=''):
        """Persist private final output after provider cleanup, never partial text.

        A retained facade lease may call this after its public owner quiesces;
        this captured service/capability remains ON until that lease drains.
        No new admission or effect dispatch is implied by this terminal write.
        """
        capability = self._thought_writer()
        from .knowledge_store import _realization_metadata
        self._realization_policy(json.loads(_realization_metadata(
            capability.principal, capability.identity_id, capability.producer)))
        with self._thought_access(capability):
            found = capability.writer.finish_thought_realization(attempt_id, thought_id=thought_id,
                snapshot_sha256=snapshot_sha256, request_sha256=request_sha256, outcome=outcome,
                text=text, reason_code=reason_code, principal=capability.principal,
                identity_id=capability.identity_id, producer=capability.producer,
                database_identity=capability.database_identity)
            return self._realization_receipt(found, capability)

    def recall_thought_realization(self, attempt_id):
        capability = self._thought_writer()
        with self._thought_access(capability):
            found = capability.writer.read_thought_realization(attempt_id, principal=capability.principal,
                identity_id=capability.identity_id, producer=capability.producer,
                database_identity=capability.database_identity)
            return self._realization_receipt(found, capability)

    def reinforce(self, store, record_id, *, verified_success=False, latency_ms=None):
        if self.mode != "on" or verified_success is not True:
            return False
        record = self._get(store, record_id)
        adapter = self.adapters.get(store)
        if record is None or adapter.writer is None:
            return False
        # KnowledgeStore has no dedicated safe strength API. Graph chain
        # reinforcement requires verified entity chains, not a single hit.
        if store != "skills":
            return False
        result = adapter.writer.reinforce(int(record_id), True, latency_ms=latency_ms)
        if result is not None:
            refreshed = self._get(store, record_id)
            if refreshed:
                self.index_record(refreshed)
        return result is not None

    def consolidate_candidate(self, text, *, evidence_refs, verified=False, **kwargs):
        """Explicit caller-approved canonical consolidation; no autonomous belief edit."""
        if verified is not True or not evidence_refs:
            raise PermissionError("consolidation requires verified canonical evidence")
        for store, record_id in evidence_refs:
            if self._get(store, record_id) is None:
                raise PermissionError("consolidation evidence unavailable/unauthorized")
        metadata = dict(kwargs.pop("metadata", {}) or {}, evidence_refs=[list(r) for r in evidence_refs])
        return self.remember(text, metadata=metadata, **kwargs)

    def stats(self):
        return dict(self._stats, mode=self.mode, stores=sorted(self.adapters),
                    index=self.index.stats() if self.index else None)
