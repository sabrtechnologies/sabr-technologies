"""
Phase 14 — Reflection.

Lightweight self-observation. Runs every ~30 minutes (LEON_REFLECTION_TICK_S),
reads what's happened operationally, and writes a small structured "insight"
record. Over time these insights become the basis for Leon noticing its own
patterns — recurring failures, latency regressions, overused Claude calls.

This is NOT analytics. It's NOT a dashboard. It's a *durable thought stream*:

  • "knowledge_search has been slow this hour (p95 1100ms vs baseline 200ms)"
  • "browser.cdp_click failed 4 times in last 30min — same selector each time"
  • "screen.capture invoked 32× this session — possibly too aggressive"
  • "successful chain pattern detected: open_app → focus_window → click"
  • "no claude_deep route fired today — all turns were short"

The reflection module does NOT take action. It surfaces insights to:
  • the suggestions queue (so Dean sees them)
  • the skills miner (so successful patterns get reinforced)
  • the executive (so it can adjust routing biases)

Storage: ~/.leon/reflection.db (sqlite, WAL).

Periodic structure:
  - episodes table → daily/hourly tool stats
  - tool_health → degradation deltas
  - executive history → routing distribution
  - skills → state churn

Cheap: each tick is ~50ms, runs every 30min by default.
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.reflection")


_SCHEMA = """
CREATE TABLE IF NOT EXISTS insights (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           REAL NOT NULL,
    kind         TEXT NOT NULL,
    severity     TEXT NOT NULL DEFAULT 'info',
    text         TEXT NOT NULL,
    detail_json  TEXT,
    seen         INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_insights_ts   ON insights(ts DESC);
CREATE INDEX IF NOT EXISTS idx_insights_kind ON insights(kind, ts DESC);

-- Phase 15 — supervised adaptation proposals
CREATE TABLE IF NOT EXISTS proposals (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           REAL NOT NULL,
    kind         TEXT NOT NULL,                  -- add_reflex / demote_tool / crystallize_skill / routing_adjust
    title        TEXT NOT NULL,
    rationale    TEXT,                            -- one-paragraph "why"
    payload_json TEXT,                            -- structured data (pattern, tool name, chain steps, etc.)
    status       TEXT NOT NULL DEFAULT 'open',    -- open / approved / rejected / applied / failed
    decided_ts   REAL,
    decided_by   TEXT,                            -- 'dean' / 'auto' / 'expired'
    apply_note   TEXT
);
CREATE INDEX IF NOT EXISTS idx_proposals_status ON proposals(status, ts DESC);
CREATE INDEX IF NOT EXISTS idx_proposals_kind   ON proposals(kind, ts DESC);

-- Phase 15 — daily ops metrics snapshot
CREATE TABLE IF NOT EXISTS ops_metrics (
    day              TEXT PRIMARY KEY,            -- 'YYYY-MM-DD'
    ts               REAL NOT NULL,
    plan_calls       INTEGER NOT NULL DEFAULT 0,
    claude_calls     INTEGER NOT NULL DEFAULT 0,
    reflex_calls     INTEGER NOT NULL DEFAULT 0,
    canned_calls     INTEGER NOT NULL DEFAULT 0,
    tool_calls       INTEGER NOT NULL DEFAULT 0,
    autopilot_calls  INTEGER NOT NULL DEFAULT 0,
    local_share      REAL,
    claude_share     REAL,
    episode_count    INTEGER NOT NULL DEFAULT 0,
    skills_total     INTEGER NOT NULL DEFAULT 0,
    skills_reinforced INTEGER NOT NULL DEFAULT 0,
    skills_optimized  INTEGER NOT NULL DEFAULT 0,
    tools_active     INTEGER NOT NULL DEFAULT 0,
    tools_dormant    INTEGER NOT NULL DEFAULT 0,
    tools_broken     INTEGER NOT NULL DEFAULT 0,
    insights_today   INTEGER NOT NULL DEFAULT 0,
    proposals_open   INTEGER NOT NULL DEFAULT 0,
    proposals_approved_today INTEGER NOT NULL DEFAULT 0
);
"""

# Phase 15 — proposal kind constants
PROPOSAL_ADD_REFLEX        = "add_reflex"
PROPOSAL_DEMOTE_TOOL       = "demote_tool"
PROPOSAL_CRYSTALLIZE_SKILL = "crystallize_skill"
PROPOSAL_ROUTING_ADJUST    = "routing_adjust"

# Status constants
PROPOSAL_OPEN     = "open"
PROPOSAL_APPROVED = "approved"
PROPOSAL_REJECTED = "rejected"
PROPOSAL_APPLIED  = "applied"
PROPOSAL_FAILED   = "failed"


@dataclass
class Insight:
    id: int
    ts: float
    kind: str            # tool_degradation / latency_regression / chain_pattern /
                          # claude_overuse / routing_skew / correction_pattern / etc.
    severity: str        # info | hint | warn
    text: str
    detail: Dict[str, Any]
    seen: bool = False

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d


@dataclass
class Proposal:
    id: int
    ts: float
    kind: str
    title: str
    rationale: str
    payload: Dict[str, Any]
    status: str
    decided_ts: Optional[float]
    decided_by: Optional[str]
    apply_note: Optional[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class Reflection:
    """Periodic operational self-observer."""

    def __init__(
        self,
        *,
        episodes=None,
        tool_health=None,
        executive=None,
        skills=None,
        lessons=None,
        suggestions=None,
        tool_classifier=None,
        path: Optional[str] = None,
        interval_s: Optional[float] = None,
    ):
        self.episodes = episodes
        self.tool_health = tool_health
        self.executive = executive
        self.skills = skills
        self.lessons = lessons
        self.suggestions = suggestions
        # Phase 15
        self.tool_classifier = tool_classifier
        # In-memory rolling baselines for cross-tick metrics
        self._last_counter_snapshot: Dict[str, int] = {}
        # Chain detection window for workflow crystallization
        self._chain_window_s: float = float(
            os.environ.get("LEON_WORKFLOW_WINDOW_S", "1800"))
        self.path = path or os.path.expanduser("~/.leon/reflection.db")
        if interval_s is None:
            interval_s = float(os.environ.get("LEON_REFLECTION_TICK_S", "1800"))
        self.interval_s = max(60.0, interval_s)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            self.path, check_same_thread=False, isolation_level=None,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        # Baselines tracked across ticks (in-memory)
        self._baseline_latency: Dict[str, float] = {}
        self._baseline_set_at: float = 0.0
        self._last_tick_ts: Optional[float] = None

    # -- lifecycle -----------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="leon-reflection", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t is not None:
            t.join(timeout=2.0)

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    # -- public --------------------------------------------------------

    def tick_now(self) -> List[Insight]:
        """Run one reflection pass synchronously. Returns insights written."""
        out: List[Insight] = []
        for fn in (self._reflect_tool_health,
                    self._reflect_latency,
                    self._reflect_routing,
                    self._reflect_claude_usage,
                    self._reflect_skill_formation,
                    self._reflect_correction_patterns):
            try:
                for ins in (fn() or []):
                    written = self._write(ins)
                    if written:
                        out.append(written)
            except Exception as e:
                log.warning("reflection fn %s failed: %s", fn.__name__, e)
        self._last_tick_ts = time.time()
        # Auto-decay skills + drift-detect against broken tools
        try:
            if self.skills is not None and hasattr(self.skills, "decay_all"):
                self.skills.decay_all()
            if self.skills is not None and hasattr(self.skills, "detect_tool_drift"):
                self.skills.detect_tool_drift(self.tool_health)
        except Exception as e:
            log.warning("reflection auto-decay failed: %s", e)
        return out

    def recent(self, limit: int = 30,
                kind: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._lock:
            if kind:
                rows = self._conn.execute(
                    "SELECT * FROM insights WHERE kind=? ORDER BY ts DESC LIMIT ?",
                    (kind, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM insights ORDER BY ts DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [_row(r).to_dict() for r in rows]

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            n = self._conn.execute(
                "SELECT COUNT(*) AS n FROM insights").fetchone()["n"]
            by_kind = self._conn.execute(
                "SELECT kind, COUNT(*) AS n FROM insights GROUP BY kind"
            ).fetchall()
        return {
            "total": n,
            "by_kind": {r["kind"]: r["n"] for r in by_kind},
            "last_tick_ts": self._last_tick_ts,
            "interval_s": self.interval_s,
        }

    # -- internals -----------------------------------------------------

    def _run(self) -> None:
        try:
            self.tick_now()
        except Exception as e:
            log.warning("initial reflection tick failed: %s", e)
        while not self._stop.is_set():
            self._stop.wait(self.interval_s)
            if self._stop.is_set():
                break
            try:
                self.tick_now()
            except Exception as e:
                log.warning("reflection tick failed: %s", e)

    def _write(self, insight_dict: Dict[str, Any]) -> Optional[Insight]:
        """Insert a new insight if it isn't a duplicate of the last hour."""
        kind = insight_dict.get("kind", "info")
        text = insight_dict.get("text", "")
        severity = insight_dict.get("severity", "info")
        detail = insight_dict.get("detail", {})
        if not text:
            return None
        # Dedup by exact-text in last hour
        cutoff = time.time() - 3600
        with self._lock:
            dup = self._conn.execute(
                "SELECT id FROM insights WHERE kind=? AND text=? AND ts>=?",
                (kind, text, cutoff),
            ).fetchone()
            if dup:
                return None
            cur = self._conn.execute(
                "INSERT INTO insights (ts, kind, severity, text, detail_json) VALUES (?,?,?,?,?)",
                (time.time(), kind, severity, text,
                 json.dumps(detail, default=str)[:6000]),
            )
            row = self._conn.execute(
                "SELECT * FROM insights WHERE id=?", (cur.lastrowid,),
            ).fetchone()
        log.info("[reflection] [%s] %s", severity, text[:100])
        # Optionally emit as a suggestion too
        if self.suggestions is not None and severity in ("hint", "warn"):
            try:
                from brain.cognition.suggestions import Suggestion
                self.suggestions._history.append(Suggestion(
                    ts=time.time(),
                    key=f"reflection:{kind}:{text[:60]}",
                    source="reflection",
                    severity=severity,
                    text=text,
                    detail=detail,
                    cooldown_s=3600.0,
                ))
            except Exception as e:
                log.warning("reflection→suggestion forward failed: %s", e)
        return _row(row)

    # -- reflection passes (each returns list[dict-shaped-insight]) ----

    def _reflect_tool_health(self) -> List[Dict[str, Any]]:
        if self.tool_health is None:
            return []
        out = []
        try:
            broken = self.tool_health.broken(limit=20)
        except Exception:
            broken = []
        if broken:
            names = [s.tool for s in broken[:5]]
            out.append({
                "kind": "tool_degradation", "severity": "warn",
                "text": f"{len(broken)} tool(s) BROKEN: {', '.join(names)}",
                "detail": {"tools": [s.to_dict() for s in broken]},
            })
        try:
            degraded = self.tool_health.degraded(limit=20)
        except Exception:
            degraded = []
        if len(degraded) >= 3:
            names = [s.tool for s in degraded[:5]]
            out.append({
                "kind": "tool_degradation", "severity": "hint",
                "text": f"{len(degraded)} tool(s) degraded: {', '.join(names)}",
                "detail": {"count": len(degraded)},
            })
        return out

    def _reflect_latency(self) -> List[Dict[str, Any]]:
        """Compare per-tool current p95 against tracked baseline.
        Baseline is set the first time we see a tool with 5+ calls and
        re-set on a weekly cadence."""
        if self.tool_health is None:
            return []
        out = []
        try:
            stats = self.tool_health.all_stats(limit=500)
        except Exception:
            return []
        now = time.time()
        # Re-baseline weekly
        if (now - self._baseline_set_at) > 7 * 86400:
            self._baseline_latency.clear()
            self._baseline_set_at = now
        for s in stats:
            if s.calls_total < 5:
                continue
            cur = s.latency_p95_ms or 0
            base = self._baseline_latency.get(s.tool)
            if base is None:
                self._baseline_latency[s.tool] = cur
                continue
            # 2× slowdown vs baseline AND baseline was non-trivial → flag
            if base > 50 and cur > base * 2.0:
                out.append({
                    "kind": "latency_regression", "severity": "hint",
                    "text": (f"{s.tool} latency regressed: "
                              f"p95 {base:.0f}→{cur:.0f}ms"),
                    "detail": {"tool": s.tool, "baseline_ms": base,
                                "current_ms": cur},
                })
                # update baseline so we don't re-emit every tick
                self._baseline_latency[s.tool] = cur
        return out

    def _reflect_routing(self) -> List[Dict[str, Any]]:
        """Look at executive history — flag skewed routing."""
        if self.executive is None:
            return []
        try:
            hist = self.executive.history(n=100)
        except Exception:
            return []
        if len(hist) < 10:
            return []
        counts = Counter(p.get("strategy") for p in hist)
        total = sum(counts.values())
        out = []
        # If 80%+ of recent turns are claude_* and reflex/canned exist, flag
        claude_share = (counts.get("claude_fast", 0) + counts.get("claude_deep", 0)) / total
        if claude_share > 0.85 and total >= 20:
            out.append({
                "kind": "routing_skew", "severity": "hint",
                "text": (f"{claude_share*100:.0f}% of recent turns went to Claude — "
                         "reflex/canned paths under-utilized; consider expanding "
                         "reflex patterns"),
                "detail": {"counts": dict(counts), "sample_size": total},
            })
        # If autopilot fires too often
        autop = counts.get("autopilot", 0) / total
        if autop > 0.3 and total >= 20:
            out.append({
                "kind": "routing_skew", "severity": "info",
                "text": f"autopilot fired in {autop*100:.0f}% of recent turns — "
                          "may indicate misclassification of strategic intent",
                "detail": {"counts": dict(counts)},
            })
        return out

    def _reflect_claude_usage(self) -> List[Dict[str, Any]]:
        """Read episode store; flag if claude.response episodes dominate
        and are mostly short turns (which suggests waste)."""
        if self.episodes is None:
            return []
        try:
            rows = self.episodes.recent(limit=500)
        except Exception:
            return []
        if not rows:
            return []
        cutoff = time.time() - 3600
        recent = [r for r in rows if r.get("ts", 0) >= cutoff]
        if len(recent) < 10:
            return []
        claude_calls = sum(1 for r in recent
                            if (r.get("action_name") or "") == "claude.response")
        if claude_calls == 0:
            return []
        # If >70% of last hour was Claude and avg latency_ms tiny (cheap turn),
        # that's exactly the waste pattern reflex should absorb.
        if claude_calls / len(recent) > 0.7:
            return [{
                "kind": "claude_overuse", "severity": "hint",
                "text": (f"{claude_calls}/{len(recent)} recent episodes were "
                         "claude.response — reflex layer may be missing patterns "
                         "for the most common short turns"),
                "detail": {"claude_calls": claude_calls,
                            "total_recent": len(recent)},
            }]
        return []

    def _reflect_skill_formation(self) -> List[Dict[str, Any]]:
        if self.skills is None:
            return []
        out = []
        try:
            summary = self.skills.state_summary()
        except Exception:
            summary = {}
        opt = summary.get("optimized", 0)
        rein = summary.get("reinforced", 0)
        dep = summary.get("deprecated", 0)
        if opt + rein >= 3:
            out.append({
                "kind": "skill_formation", "severity": "info",
                "text": (f"skill memory growing: {opt} optimized + "
                         f"{rein} reinforced ({dep} deprecated)"),
                "detail": summary,
            })
        return out

    def _reflect_correction_patterns(self) -> List[Dict[str, Any]]:
        """Surface lessons that have been re-confirmed multiple times —
        these are durable preferences we should make sure the executive
        respects."""
        if self.lessons is None:
            return []
        try:
            top = self.lessons.all(limit=200)
        except Exception:
            return []
        # Lessons with hit_count >= 3 AND weight > 0.7 are deeply held
        deep = [L for L in top if L.hit_count >= 3 and L.weight > 0.7]
        if not deep:
            return []
        return [{
            "kind": "correction_pattern", "severity": "info",
            "text": (f"{len(deep)} lesson(s) deeply reinforced (hit_count≥3, "
                     "weight>0.7) — strongly held preferences"),
            "detail": {"lesson_ids": [L.id for L in deep],
                        "examples": [L.text[:80] for L in deep[:3]]},
        }]


def _row(row) -> Insight:
    detail = {}
    try:
        if row["detail_json"]:
            detail = json.loads(row["detail_json"])
    except Exception:
        detail = {}
    return Insight(
        id=row["id"], ts=float(row["ts"] or 0.0),
        kind=row["kind"] or "info",
        severity=row["severity"] or "info",
        text=row["text"] or "",
        detail=detail,
        seen=bool(row["seen"]),
    )


__all__ = ["Reflection", "Insight"]


# ── Phase 15 — proposal + workflow + ops_metrics extensions ───────────────


def _row_to_proposal(row) -> Proposal:
    try:
        payload = json.loads(row["payload_json"]) if row["payload_json"] else {}
    except Exception:
        payload = {}
    return Proposal(
        id=row["id"], ts=float(row["ts"] or 0.0),
        kind=row["kind"] or "?",
        title=row["title"] or "",
        rationale=row["rationale"] or "",
        payload=payload,
        status=row["status"] or PROPOSAL_OPEN,
        decided_ts=row["decided_ts"],
        decided_by=row["decided_by"],
        apply_note=row["apply_note"],
    )


def _propose(self, *, kind: str, title: str, rationale: str,
              payload: Dict[str, Any]) -> Optional[Proposal]:
    """Insert a proposal — dedup by (kind, title)."""
    with self._lock:
        # dedup: same kind+title in last 7 days, status=open → skip
        cutoff = time.time() - 7 * 86400
        dup = self._conn.execute(
            "SELECT id FROM proposals WHERE kind=? AND title=? AND status=? AND ts>=?",
            (kind, title, PROPOSAL_OPEN, cutoff),
        ).fetchone()
        if dup:
            return None
        cur = self._conn.execute(
            """INSERT INTO proposals (ts, kind, title, rationale, payload_json, status)
                VALUES (?,?,?,?,?,?)""",
            (time.time(), kind, title, rationale,
              json.dumps(payload or {}, default=str)[:4000], PROPOSAL_OPEN),
        )
        row = self._conn.execute("SELECT * FROM proposals WHERE id=?",
                                   (cur.lastrowid,)).fetchone()
    log.info("[proposal] [%s] %s", kind, title[:80])
    return _row_to_proposal(row)


def proposals(self, *, status: Optional[str] = None,
               limit: int = 50) -> List[Dict[str, Any]]:
    with self._lock:
        if status:
            rows = self._conn.execute(
                "SELECT * FROM proposals WHERE status=? ORDER BY ts DESC LIMIT ?",
                (status, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM proposals ORDER BY ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
    return [_row_to_proposal(r).to_dict() for r in rows]


def proposal(self, proposal_id: int) -> Optional[Proposal]:
    with self._lock:
        row = self._conn.execute(
            "SELECT * FROM proposals WHERE id=?", (proposal_id,),
        ).fetchone()
    return _row_to_proposal(row) if row else None


def proposal_stats(self) -> Dict[str, Any]:
    with self._lock:
        rows = self._conn.execute(
            "SELECT status, COUNT(*) AS n FROM proposals GROUP BY status"
        ).fetchall()
        kinds = self._conn.execute(
            "SELECT kind, COUNT(*) AS n FROM proposals GROUP BY kind"
        ).fetchall()
    return {
        "by_status": {r["status"]: r["n"] for r in rows},
        "by_kind":   {r["kind"]: r["n"]   for r in kinds},
    }


def approve_proposal(self, proposal_id: int, *,
                      by: str = "dean") -> Dict[str, Any]:
    """Mark proposal approved, then attempt to apply.

    Apply behavior is kind-specific. Anything risky is no-op-with-note
    (Dean still has the rationale and can apply manually).
    """
    p = self.proposal(proposal_id)
    if p is None:
        return {"ok": False, "error": f"no proposal #{proposal_id}"}
    if p.status != PROPOSAL_OPEN:
        return {"ok": False, "error": f"already {p.status}"}
    # Mark approved first
    now = time.time()
    with self._lock:
        self._conn.execute(
            "UPDATE proposals SET status=?, decided_ts=?, decided_by=? WHERE id=?",
            (PROPOSAL_APPROVED, now, by, proposal_id),
        )
    # Then attempt apply
    try:
        apply_result = self._apply_proposal(p)
    except Exception as e:
        apply_result = {"ok": False, "note": f"apply raised: {e}"}
    final_status = PROPOSAL_APPLIED if apply_result.get("ok") else PROPOSAL_FAILED
    with self._lock:
        self._conn.execute(
            "UPDATE proposals SET status=?, apply_note=? WHERE id=?",
            (final_status, (apply_result.get("note") or "")[:600], proposal_id),
        )
    return {"ok": apply_result.get("ok", False),
             "status": final_status,
             "note": apply_result.get("note", "")}


def reject_proposal(self, proposal_id: int, *,
                     by: str = "dean", note: str = "") -> Dict[str, Any]:
    p = self.proposal(proposal_id)
    if p is None:
        return {"ok": False, "error": f"no proposal #{proposal_id}"}
    if p.status != PROPOSAL_OPEN:
        return {"ok": False, "error": f"already {p.status}"}
    with self._lock:
        self._conn.execute(
            "UPDATE proposals SET status=?, decided_ts=?, decided_by=?, apply_note=? WHERE id=?",
            (PROPOSAL_REJECTED, time.time(), by, note[:600], proposal_id),
        )
    return {"ok": True, "status": PROPOSAL_REJECTED}


def _apply_proposal(self, p: Proposal) -> Dict[str, Any]:
    """Kind-specific application. Returns {ok, note}."""
    kind = p.kind
    payload = p.payload or {}
    if kind == PROPOSAL_CRYSTALLIZE_SKILL:
        # payload: {"chain": [{"tool":..., "args_keys":[...]}, ...],
        #           "runs": N, "success_rate": x, "name": "...optional..."}
        if self.skills is None:
            return {"ok": False, "note": "skills module not available"}
        steps = payload.get("chain") or []
        if not steps:
            return {"ok": False, "note": "empty chain"}
        try:
            sk = self.skills.add_from_chain(
                steps=steps,
                name=payload.get("name") or " → ".join(
                    s.get("tool", "?").split(".")[-1] for s in steps[:4]),
                runs=int(payload.get("runs", 1)),
                success_runs=int(payload.get("runs", 1)),
            )
            return {"ok": sk is not None,
                     "note": f"skill #{sk.id} created" if sk else "could not create"}
        except Exception as e:
            return {"ok": False, "note": f"add_from_chain failed: {e}"}
    if kind == PROPOSAL_DEMOTE_TOOL:
        # payload: {"tool": "...", "scope": "global|app:..."}
        # Apply by adding a lesson "don't use <tool>" — the executive's
        # vetoes machinery will pick it up.
        tool = payload.get("tool")
        if not tool or self.lessons is None:
            return {"ok": False, "note": "no tool or lessons unavailable"}
        try:
            L = self.lessons.add(text=f"avoid using {tool}",
                                   polarity="dont",
                                   scope=f"tool:{tool}",
                                   source="reflection_proposal")
            return {"ok": L is not None, "note": f"lesson #{L.id if L else '?'} added"}
        except Exception as e:
            return {"ok": False, "note": f"lesson add failed: {e}"}
    if kind == PROPOSAL_ADD_REFLEX:
        # payload: {"pattern": "regex", "answer_kind": "static|stub"}
        # We do NOT modify source code. Instead we add a config file
        # ~/.leon/reflex_patterns.json that the reflex layer can read
        # on next boot (extension to reflex.py would consume this).
        pattern = payload.get("pattern")
        if not pattern:
            return {"ok": False, "note": "no pattern"}
        try:
            cfg_path = os.path.expanduser("~/.leon/reflex_patterns.json")
            existing: List[Dict[str, Any]] = []
            if os.path.exists(cfg_path):
                try:
                    with open(cfg_path) as f:
                        existing = json.load(f) or []
                except Exception:
                    existing = []
            existing.append({
                "pattern": pattern,
                "answer": payload.get("answer", ""),
                "source": f"proposal#{p.id}",
                "added_ts": time.time(),
            })
            with open(cfg_path, "w") as f:
                json.dump(existing, f, indent=2)
            return {"ok": True,
                     "note": f"appended to {cfg_path} (effective after restart)"}
        except Exception as e:
            return {"ok": False, "note": f"write failed: {e}"}
    if kind == PROPOSAL_ROUTING_ADJUST:
        # payload: {"adjustment": "...free-text..."}
        # We don't try to auto-patch routing — just log so Dean can act.
        return {"ok": True,
                 "note": "routing adjustment is advisory — manual change required"}
    return {"ok": False, "note": f"unknown proposal kind: {kind}"}


def detect_workflows(self, *, min_runs: int = 3,
                      min_chain: int = 2,
                      max_chain: int = 6) -> List[Proposal]:
    """Phase 15 — repeated-chain detector.

    Looks at recent episodes within self._chain_window_s, segments into
    chains (gap > 8s breaks), counts identical (tool-name, arg-keys)
    signatures. Any signature appearing min_runs+ times generates a
    crystallize_skill proposal — UNLESS the skills miner already has it.
    """
    if self.episodes is None or self.skills is None:
        return []
    cutoff = time.time() - self._chain_window_s
    try:
        rows = self.episodes.recent(limit=2000)
    except Exception:
        return []
    rows = [r for r in rows if r.get("ts", 0) >= cutoff
             and r.get("action_name")
             and r.get("action_kind") == "tool"]
    rows.sort(key=lambda r: r.get("ts", 0))
    # Greedy chain segmenter
    chains: List[List[Dict[str, Any]]] = []
    cur: List[Dict[str, Any]] = []
    last_ts = 0.0
    for r in rows:
        ts = float(r.get("ts", 0))
        if cur and (ts - last_ts > 8.0):
            chains.append(cur); cur = []
        cur.append(r); last_ts = ts
    if cur:
        chains.append(cur)
    # Keep all-success chains within size bounds
    candidates = [c for c in chains
                   if min_chain <= len(c) <= max_chain
                   and all(int(r.get("success") or 0) == 1 for r in c)]
    # Signature aggregator
    sigs: Dict[str, Dict[str, Any]] = {}
    for c in candidates:
        sig_parts = []
        chain_steps = []
        for r in c:
            tool = r.get("action_name") or "?"
            try:
                args = json.loads(r.get("action_args_json") or "{}")
            except Exception:
                args = {}
            arg_keys = sorted(args.keys()) if isinstance(args, dict) else []
            sig_parts.append(f"{tool}({','.join(arg_keys)})")
            chain_steps.append({"tool": tool, "args_keys": arg_keys})
        sig = "|".join(sig_parts)
        agg = sigs.setdefault(sig, {"runs": 0, "chain": chain_steps,
                                       "name_hint": chain_steps[0]["tool"]})
        agg["runs"] += 1
    # Promote ones above threshold
    out: List[Proposal] = []
    try:
        existing = {s.signature for s in self.skills.all(limit=200)}
    except Exception:
        existing = set()
    for sig, agg in sigs.items():
        if agg["runs"] < min_runs:
            continue
        # Hash the signature to compare with what skills.signature() uses
        import hashlib
        skill_sig = hashlib.sha1(sig.encode("utf-8")).hexdigest()[:16]
        if skill_sig in existing:
            continue
        name = " → ".join(s["tool"].split(".")[-1] for s in agg["chain"][:4])
        prop = self._propose(
            kind=PROPOSAL_CRYSTALLIZE_SKILL,
            title=f"crystallize workflow: {name}",
            rationale=(f"Tool chain {name!r} observed {agg['runs']} times in "
                        f"the last {int(self._chain_window_s/60)} min, all successful. "
                        "Approving will create a reusable skill so future "
                        "invocations can fire as a single procedure."),
            payload={"chain": agg["chain"], "runs": agg["runs"],
                      "name": name, "signature": skill_sig},
        )
        if prop:
            out.append(prop)
    return out


def _emit_adaptation_proposals_from_insights(self, insights):
    """For each new insight, see if it warrants a proposal."""
    out = []
    for ins in insights:
        kind = ins.kind if hasattr(ins, "kind") else ins.get("kind")
        text = ins.text if hasattr(ins, "text") else ins.get("text", "")
        detail = ins.detail if hasattr(ins, "detail") else ins.get("detail", {})
        if kind == "claude_overuse":
            prop = self._propose(
                kind=PROPOSAL_ROUTING_ADJUST,
                title="expand reflex to cover frequent short turns",
                rationale=(
                    "Reflection detected >70% of recent turns went to Claude. "
                    "Most common turns may have local-answerable patterns. "
                    "Approving signals intent; new patterns must still be added "
                    "manually to reflex.py or via add_reflex proposals."),
                payload={"insight": detail},
            )
            if prop: out.append(prop)
        elif kind == "tool_degradation":
            # Only auto-propose a demote for tools that are flat-out broken
            tools = (detail or {}).get("tools") or []
            for t in tools:
                # t comes from tool_health.broken(); it's a dict via to_dict()
                tname = t.get("tool") if isinstance(t, dict) else None
                if not tname:
                    continue
                prop = self._propose(
                    kind=PROPOSAL_DEMOTE_TOOL,
                    title=f"demote broken tool {tname}",
                    rationale=(f"Tool {tname} is classified BROKEN by tool_health "
                               f"(sr={t.get('success_rate',0):.2f}, "
                               f"n={t.get('calls_total',0)}). Approving will add "
                               "a 'don't use this tool' lesson so the executive vetoes it."),
                    payload={"tool": tname, "stats": t},
                )
                if prop: out.append(prop)
    return out


def record_daily_metrics(self) -> Dict[str, Any]:
    """Snapshot today's operational metrics into ops_metrics. Idempotent
    per day — overwrites the row if it exists."""
    now = time.time()
    day = time.strftime("%Y-%m-%d", time.localtime(now))
    snap = {"day": day, "ts": now}
    # Executive counters (cumulative since process start)
    if self.executive is not None:
        try:
            c = self.executive.counters()
            snap.update({k: int(c.get(k, 0)) for k in (
                "plan_calls", "claude_calls", "reflex_calls",
                "canned_calls", "tool_calls", "autopilot_calls")})
            snap["local_share"] = float(c.get("local_share", 0))
            snap["claude_share"] = float(c.get("claude_share", 0))
        except Exception:
            pass
    # Episode count (7d)
    if self.episodes is not None:
        try:
            stats = self.episodes.stats()
            snap["episode_count"] = int(stats.get("total_7d", 0))
        except Exception:
            pass
    # Skill counts
    if self.skills is not None and hasattr(self.skills, "state_summary"):
        try:
            ss = self.skills.state_summary()
            snap["skills_total"] = sum(ss.values())
            snap["skills_reinforced"] = ss.get("reinforced", 0)
            snap["skills_optimized"] = ss.get("optimized", 0)
        except Exception:
            pass
    # Tool classifier
    if self.tool_classifier is not None:
        try:
            tc = self.tool_classifier.classify_all()
            tsum = tc.get("summary", {})
            snap["tools_active"] = tsum.get("ACTIVE", 0)
            snap["tools_dormant"] = tsum.get("DORMANT", 0)
            snap["tools_broken"] = tsum.get("BROKEN", 0)
        except Exception:
            pass
    # Insights today + proposals
    cutoff = now - 86400
    try:
        with self._lock:
            n = self._conn.execute(
                "SELECT COUNT(*) AS n FROM insights WHERE ts>=?",
                (cutoff,)).fetchone()["n"]
            snap["insights_today"] = n
            po = self._conn.execute(
                "SELECT COUNT(*) AS n FROM proposals WHERE status=?",
                (PROPOSAL_OPEN,)).fetchone()["n"]
            snap["proposals_open"] = po
            pa = self._conn.execute(
                "SELECT COUNT(*) AS n FROM proposals WHERE status IN (?,?) AND ts>=?",
                (PROPOSAL_APPROVED, PROPOSAL_APPLIED, cutoff)).fetchone()["n"]
            snap["proposals_approved_today"] = pa
    except Exception:
        pass
    # Upsert
    with self._lock:
        cols = ", ".join(snap.keys())
        placeholders = ", ".join(["?"] * len(snap))
        updates = ", ".join(f"{k}=excluded.{k}" for k in snap if k != "day")
        self._conn.execute(
            f"INSERT INTO ops_metrics ({cols}) VALUES ({placeholders}) "
            f"ON CONFLICT(day) DO UPDATE SET {updates}",
            list(snap.values()),
        )
    return snap


def soak_summary(self, days: int = 7) -> Dict[str, Any]:
    """Aggregate ops_metrics over the last N days for the weekly summary."""
    with self._lock:
        rows = self._conn.execute(
            "SELECT * FROM ops_metrics ORDER BY day DESC LIMIT ?", (days,)
        ).fetchall()
    if not rows:
        return {"days": 0, "summary": "no data yet — wait for first daily tick"}
    rows = [dict(r) for r in rows]
    rows.reverse()  # chronological
    def col_sum(k): return sum(int(r.get(k) or 0) for r in rows)
    def col_avg(k):
        vs = [float(r[k]) for r in rows if r.get(k) is not None]
        return sum(vs) / len(vs) if vs else 0.0
    return {
        "days": len(rows),
        "first_day": rows[0]["day"], "last_day": rows[-1]["day"],
        "plan_calls_total": col_sum("plan_calls"),
        "claude_calls_total": col_sum("claude_calls"),
        "reflex_calls_total": col_sum("reflex_calls"),
        "local_share_avg": round(col_avg("local_share"), 3),
        "claude_share_avg": round(col_avg("claude_share"), 3),
        "insights_total": col_sum("insights_today"),
        "proposals_open_today": int(rows[-1].get("proposals_open") or 0),
        "proposals_approved_total": col_sum("proposals_approved_today"),
        "skills_total_latest": int(rows[-1].get("skills_total") or 0),
        "skills_reinforced_latest": int(rows[-1].get("skills_reinforced") or 0),
        "tools_dormant_latest": int(rows[-1].get("tools_dormant") or 0),
        "tools_active_latest": int(rows[-1].get("tools_active") or 0),
        "tools_broken_latest": int(rows[-1].get("tools_broken") or 0),
        "rows": rows,
    }


# Attach to Reflection class
Reflection._propose = _propose
Reflection.proposals = proposals
Reflection.proposal = proposal
Reflection.proposal_stats = proposal_stats
Reflection.approve_proposal = approve_proposal
Reflection.reject_proposal = reject_proposal
Reflection._apply_proposal = _apply_proposal
Reflection.detect_workflows = detect_workflows
Reflection._emit_adaptation_proposals_from_insights = \
    _emit_adaptation_proposals_from_insights
Reflection.record_daily_metrics = record_daily_metrics
Reflection.soak_summary = soak_summary


# Wrap original tick_now so each tick now ALSO:
#   • runs workflow detection
#   • emits adaptation proposals from any new insights
#   • records daily metrics
_orig_tick_now = Reflection.tick_now

def _tick_now_phase15(self) -> List[Insight]:
    insights = _orig_tick_now(self)
    try:
        wf_props = self.detect_workflows()
    except Exception as e:
        log.warning("reflection.detect_workflows failed: %s", e)
        wf_props = []
    try:
        adapt_props = self._emit_adaptation_proposals_from_insights(insights)
    except Exception as e:
        log.warning("reflection adaptation proposals failed: %s", e)
        adapt_props = []
    try:
        self.record_daily_metrics()
    except Exception as e:
        log.warning("reflection record_daily_metrics failed: %s", e)
    if wf_props or adapt_props:
        log.info("[reflection] generated %d workflow + %d adaptation proposals",
                  len(wf_props), len(adapt_props))
    return insights

Reflection.tick_now = _tick_now_phase15
