"""Private intent facade owned by MemoryShadow; no worker, model or store owner.

Trusted startup configuration is never deserialized from model/request data.
An operation lease spans storage, executive admission, inference and terminal
storage. Quiescence forbids new work while already admitted terminal writes
retain their exact canonical capability until the caller closes its lease.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
import threading


class ThoughtIntentUnavailable(RuntimeError):
    """The selected path cannot proceed; never permission for legacy fallback."""


def _reference(value):
    if type(value) is not str or not value.strip() or len(value.encode('utf-8')) > 200:
        raise ValueError('bounded explicit thought binding required')
    return value


@dataclass(frozen=True)
class CanonicalThoughtIdentity:
    name: str
    version: int
    born_ts: float

    def __post_init__(self):
        _reference(self.name)
        if type(self.version) is not int or not 1 <= self.version <= 1000000:
            raise ValueError('canonical identity version required')
        if (type(self.born_ts) not in (float, int) or not math.isfinite(self.born_ts)
                or self.born_ts <= 0):
            raise ValueError('canonical identity birth timestamp required')
        object.__setattr__(self, 'born_ts', float(self.born_ts))

    @classmethod
    def from_identity(cls, identity):
        """Pure conversion of trusted stable fields, not a new identity issuer."""
        if type(identity) is not dict:
            raise ValueError('canonical identity mapping required')
        return cls(identity['name'], identity['version'], identity['born_ts'])

    @property
    def identity_id(self):
        encoded = json.dumps({'name': self.name, 'version': self.version, 'born_ts': self.born_ts},
                             sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                             allow_nan=False).encode('utf-8')
        return 'self-model:v1:' + hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True)
class ThoughtIntentRuntimeConfig:
    principal: str
    identity: CanonicalThoughtIdentity
    policy_revision: str
    producer: str = 'inner_voice'
    max_snapshots: int = 4096
    max_total_bytes: int = 16 * 1024 * 1024
    max_realization_attempts: int = 4096
    max_realization_bytes: int = 16 * 1024 * 1024
    max_leases: int = 4

    def __post_init__(self):
        for value in (self.principal, self.policy_revision, self.producer):
            _reference(value)
        if type(self.identity) is not CanonicalThoughtIdentity:
            raise TypeError('full canonical identity binding required')
        for value in (self.max_snapshots, self.max_realization_attempts):
            if type(value) is not int or not 1 <= value <= 100000:
                raise ValueError('finite thought row quota required')
        for value in (self.max_total_bytes, self.max_realization_bytes):
            if type(value) is not int or not 1 <= value <= 64 * 1024 * 1024:
                raise ValueError('finite thought byte quota required')
        if type(self.max_leases) is not int or not 1 <= self.max_leases <= 16:
            raise ValueError('bounded operation leases required')


class ThoughtIntentRuntime:
    """A capability/lifetime extension of the existing memory lifecycle owner.

    Captures handles, never constructs KnowledgeStore or SelfModel. The only
    private MemoryService is created lazily after explicit selection. Callback
    contracts are bounded, side-effect-free and must not re-enter this facade.
    """
    def __init__(self, *, state, config, requested, principal):
        if type(config) is not ThoughtIntentRuntimeConfig:
            raise TypeError('typed thought configuration required')
        if not callable(requested) or not callable(principal):
            raise TypeError('explicit thought selection and principal callbacks required')
        self._state, self._config = state, config
        self._requested, self._principal = requested, principal
        self._writer = getattr(getattr(state, 'claude_bridge', None), 'knowledge', None)
        self._identity_owner = getattr(getattr(state, 'cognition', None), 'self_model', None)
        self._quiet = threading.Event()
        self._mu, self._prepare_mu = threading.Lock(), threading.Lock()
        self._leases = set()
        self._service = None
        self._retired = False
        self._snapshot = {'configured': True, 'active_leases': 0, 'prepared': False,
                          'stopping': False, 'retired': False}

    def _publish(self):
        self._snapshot = {'configured': True, 'active_leases': len(self._leases),
                          'prepared': self._service is not None,
                          'stopping': self._quiet.is_set(), 'retired': self._retired}

    def stats(self):
        result = dict(self._snapshot)
        if self._quiet.is_set():
            result['stopping'] = True
        return result

    @property
    def retired(self):
        return self._retired

    def _identity_matches(self):
        # Stable identity fields only. No snapshot(), lock, path or DB access on
        # the model preflight path. Missing/malformed/drifting fields deny.
        try:
            identity = getattr(self._identity_owner, 'identity', None)
            return CanonicalThoughtIdentity.from_identity(identity) == self._config.identity
        except (KeyError, TypeError, ValueError, OverflowError):
            return False

    def _binding_matches(self):
        try:
            principal = self._principal()
            return (type(principal) is str and principal == self._config.principal
                    and getattr(getattr(self._state, 'claude_bridge', None), 'knowledge', None) is self._writer
                    and getattr(getattr(self._state, 'cognition', None), 'self_model', None) is self._identity_owner
                    and self._identity_matches())
        except Exception:
            return False

    def current(self):
        """Cheap current selection; never opens SQLite or takes an owner lock."""
        if self._quiet.is_set() or self._retired:
            return False
        try:
            return self._requested() is True and self._binding_matches()
        except Exception:
            return False

    def configuration_matches(self, config):
        """Installer reuse check. Never swaps a capability under a live lease."""
        return (type(config) is ThoughtIntentRuntimeConfig and config == self._config
                and not self._quiet.is_set() and not self._retired and self._binding_matches())

    def _prepare(self):
        if not self._prepare_mu.acquire(timeout=.05):
            raise ThoughtIntentUnavailable('thought capability preparation busy')
        try:
            if not self.current():
                raise ThoughtIntentUnavailable('thought binding unavailable')
            if self._service is None:
                from ..knowledge_store import KnowledgeStore
                from .self_model import SelfModel
                from ..memory_service import MemoryService, SQLiteAdapter, SourcePolicy, ThoughtIntentWriteCapability
                if type(self._writer) is not KnowledgeStore or type(self._identity_owner) is not SelfModel:
                    raise ThoughtIntentUnavailable('existing canonical owners required')
                cfg = self._config
                capability = ThoughtIntentWriteCapability(self._writer, cfg.principal,
                    cfg.identity.identity_id, cfg.producer, max_snapshots=cfg.max_snapshots,
                    max_total_bytes=cfg.max_total_bytes,
                    max_realization_attempts=cfg.max_realization_attempts,
                    max_realization_bytes=cfg.max_realization_bytes)
                self._service = MemoryService([SQLiteAdapter('knowledge', self._writer.db_path,
                    writer=self._writer)], mode='on',
                    policy=SourcePolicy(principal=cfg.principal, identity_id=cfg.identity.identity_id),
                    thought_intent_capability=capability)
                self._snapshot = dict(self._snapshot, prepared=True)
            if not self.current():
                raise ThoughtIntentUnavailable('thought binding changed during preparation')
        finally:
            self._prepare_mu.release()

    def open(self):
        if not self.current():
            raise ThoughtIntentUnavailable('thought intent path unavailable')
        if not self._mu.acquire(timeout=.05):
            raise ThoughtIntentUnavailable('thought intent owner busy')
        try:
            if self._quiet.is_set() or self._retired or len(self._leases) >= self._config.max_leases:
                raise ThoughtIntentUnavailable('thought intent admission unavailable')
            lease = ThoughtIntentLease(self)
            self._leases.add(lease)
            self._publish()
        finally:
            self._mu.release()
        try:
            # The registered lease retains this owner across all preparation
            # I/O too. Neither lifecycle mutex is held across canonical access.
            self._prepare()
            lease._require_current()
            return lease
        except BaseException:
            lease.close()
            raise

    def _release(self, lease):
        if not self._mu.acquire(timeout=.05):
            raise ThoughtIntentUnavailable('thought lease release pending')
        try:
            self._leases.discard(lease)
            self._publish()
        finally:
            self._mu.release()

    def quiesce(self):
        # Effect-free, lock-free cutoff. Do not set service.mode OFF: admitted
        # callers still own the capability for durable terminal bookkeeping.
        self._quiet.set()

    def stop(self):
        self.quiesce()
        if not self._mu.acquire(blocking=False):
            return False
        try:
            if self._leases:
                self._publish()
                return False
            self._service = None
            self._retired = True
            self._publish()
            return True
        finally:
            self._mu.release()


class ThoughtIntentLease:
    """One thought and at most one provider attempt; keep until it is drained.

    Callers must not close while provider work is still active. A leaked lease
    deliberately blocks retirement rather than falsely reporting completion.
    Methods are serialized with a bounded lock; callers cannot race a close
    against canonical storage and release ownership before that write drains.
    """
    def __init__(self, owner):
        self._owner = owner
        self._closed = False
        self._revoked = threading.Event()
        self._mu = threading.Lock()
        self._thought = None
        self._confirmed = False
        self._attempt = None

    def __enter__(self):
        self._require_current()
        return self

    def __exit__(self, *unused):
        self.close()

    def current(self):
        if self._closed or self._revoked.is_set():
            return False
        if not self._owner.current():
            self._revoked.set()
            return False
        return True

    def _require_current(self):
        if not self.current():
            raise ThoughtIntentUnavailable('thought operation no longer current')

    def _locked(self):
        if not self._mu.acquire(timeout=.05):
            raise ThoughtIntentUnavailable('thought operation busy')
        if self._closed:
            self._mu.release()
            raise ThoughtIntentUnavailable('thought operation closed')

    def _bind_thought(self, thought_id, digest):
        binding = (thought_id, digest)
        if self._thought is not None and self._thought != binding:
            raise ThoughtIntentUnavailable('thought lease binding differs')
        self._thought = binding

    def remember_thought_intent(self, intent):
        self._locked()
        try:
            self._require_current()
            from ..knowledge_store import _thought_snapshot
            cfg = self._owner._config
            thought_id, _, digest, _, _ = _thought_snapshot(intent, principal=cfg.principal,
                identity_id=cfg.identity.identity_id, producer=cfg.producer)
            self._bind_thought(thought_id, digest)  # Pin even a lost commit reply.
            receipt = self._owner._service.remember_thought_intent(intent)
            self._require_current()  # A row may commit; stale success cannot escape.
            self._confirmed = True
            return receipt
        finally:
            self._mu.release()

    def recall_thought_intent(self, thought_id):
        self._locked()
        try:
            self._require_current()
            if self._thought is not None and self._thought[0] != thought_id:
                raise ThoughtIntentUnavailable('thought lease binding differs')
            found = self._owner._service.recall_thought_intent(thought_id)
            if found is not None:
                self._bind_thought(found.intent.thought_id, found.snapshot_sha256)
            self._require_current()
            if found is not None:
                self._confirmed = True
            return found
        finally:
            self._mu.release()

    def admit_thought_realization(self, thought_id, snapshot_sha256, attempt_id, request_sha256,
                                  *, request_descriptor):
        self._locked()
        try:
            self._require_current()
            if not self._confirmed or self._thought != (thought_id, snapshot_sha256):
                raise ThoughtIntentUnavailable('persisted thought binding required')
            binding = (attempt_id, thought_id, snapshot_sha256, request_sha256)
            if self._attempt is not None and self._attempt != binding:
                raise ThoughtIntentUnavailable('thought attempt binding differs')
            self._attempt = binding  # Pin a potentially committed lost reply too.
            receipt = self._owner._service.admit_thought_realization(thought_id,
                snapshot_sha256=snapshot_sha256, attempt_id=attempt_id, request_sha256=request_sha256,
                request_descriptor=request_descriptor)
            self._require_current()
            return receipt
        finally:
            self._mu.release()

    def finish_thought_realization(self, attempt_id, thought_id, snapshot_sha256, request_sha256,
                                   outcome, text='', reason_code=''):
        self._locked()
        try:
            if self._attempt != (attempt_id, thought_id, snapshot_sha256, request_sha256):
                raise ThoughtIntentUnavailable('admitted thought attempt binding required')
            # Terminal bookkeeping uses the captured capability, including when
            # live selection/principal/current state changed. It transfers no
            # authority to the successor and cannot admit or replay inference.
            return self._owner._service.finish_thought_realization(attempt_id, thought_id=thought_id,
                snapshot_sha256=snapshot_sha256, request_sha256=request_sha256, outcome=outcome,
                text=text, reason_code=reason_code)
        finally:
            self._mu.release()

    def recall_thought_realization(self, attempt_id):
        self._locked()
        try:
            if self._attempt is None or self._attempt[0] != attempt_id:
                raise ThoughtIntentUnavailable('admitted thought attempt binding required')
            return self._owner._service.recall_thought_realization(attempt_id)
        finally:
            self._mu.release()

    def close(self):
        if not self._mu.acquire(timeout=.05):
            raise ThoughtIntentUnavailable('thought operation still draining')
        try:
            if not self._closed:
                self._owner._release(self)
                self._closed = True
        finally:
            self._mu.release()
