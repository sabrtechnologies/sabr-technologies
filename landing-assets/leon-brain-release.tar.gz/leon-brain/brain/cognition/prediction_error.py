"""Bounded prediction/outcome alignment for existing models and the event fabric.

No predictor, executive, worker, canonical store, or neuron owner is created.
OFF by default. SHADOW computes observable errors and proposes learning events;
the existing ExecutiveController and inference/action gates remain authoritative.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import threading
import time
from collections import Counter, deque
from dataclasses import asdict, dataclass, field, replace
from typing import Any, Mapping

from .events import EventType, new_event

DOMAINS = frozenset({"world", "self", "scene", "tool", "goal"})
EVIDENCE = frozenset({"measured", "simulated", "unverified"})
INVESTIGATION_ORDER = ("memory_logs_local_state", "cheap_tools", "model_reasoning", "external_research")
MAX_METRICS = 32


def _number(value, *, low=0.0, high=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError("expected finite numeric value")
    if value < low or (high is not None and value > high):
        raise ValueError("numeric value outside allowed range")
    return float(value)


def _name(value, *, optional=False):
    if optional and value is None:
        return None
    if not isinstance(value, str) or not value.strip() or len(value) > 128:
        raise ValueError("expected nonempty identifier of at most 128 characters")
    return value


def _scalar(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return _number(value, low=-1e100, high=1e100)
    if isinstance(value, str) and len(value) <= 128:
        return value
    raise ValueError("measurement must be a bounded scalar, never raw media or text")


@dataclass(frozen=True)
class Metric:
    name: str
    predicted: Any
    kind: str = "numeric"  # numeric, bernoulli, categorical
    scale: float = 1.0     # explicit native-unit normalization for numeric error
    weight: float = 1.0

    def __post_init__(self):
        _name(self.name)
        _number(self.scale, low=1e-12, high=1e100)
        _number(self.weight, low=1e-12, high=1e6)
        if self.kind == "bernoulli":
            _number(self.predicted, high=1.0)
        elif self.kind == "numeric":
            _number(self.predicted, low=-1e100, high=1e100)
        elif self.kind == "categorical":
            object.__setattr__(self, "predicted", _scalar(self.predicted))
        else:
            raise ValueError("unknown comparison metric")


@dataclass(frozen=True)
class PredictionRecord:
    prediction_id: str
    request_id: str
    action_id: str
    trace_id: str
    clock_id: str
    domain: str
    source_model: str
    metrics: tuple[Metric, ...]
    predicted_mono: float
    deadline_mono: float
    confidence_before: float
    uncertainty: float
    expected_information_gain: float = 0.0
    salience: float = 0.0
    reversible: bool = False
    prospective: bool = False
    evidence: str = "unverified"
    skill_id: str | None = None
    prediction_method: str = "unspecified"

    def __post_init__(self):
        for value in (self.prediction_id, self.request_id, self.action_id, self.trace_id, self.clock_id, self.source_model):
            _name(value)
        _name(self.skill_id, optional=True)
        _name(self.prediction_method)
        if self.domain not in DOMAINS or self.evidence not in EVIDENCE:
            raise ValueError("unknown prediction domain/evidence provenance")
        _number(self.predicted_mono)
        _number(self.deadline_mono, low=self.predicted_mono)
        for value in (self.confidence_before, self.uncertainty, self.expected_information_gain, self.salience):
            _number(value, high=1.0)
        if type(self.reversible) is not bool or type(self.prospective) is not bool:
            raise ValueError("prediction policy markers must be booleans")
        metrics = tuple(self.metrics)
        if not 1 <= len(metrics) <= MAX_METRICS or any(not isinstance(m, Metric) for m in metrics):
            raise ValueError("prediction requires a bounded set of metrics")
        if len({m.name for m in metrics}) != len(metrics):
            raise ValueError("duplicate metric name")
        object.__setattr__(self, "metrics", metrics)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data):
        data = dict(data)
        data["metrics"] = tuple(Metric(**m) for m in data["metrics"])
        return cls(**data)


@dataclass(frozen=True)
class OutcomeRecord:
    prediction_id: str
    request_id: str
    action_id: str
    trace_id: str
    clock_id: str
    observed_mono: float
    observed: Mapping[str, Any] = field(default_factory=dict)
    status: str = "completed"  # completed includes a measured success=False
    evidence: str = "unverified"
    evidence_ref: str | None = None
    parent_event_id: str | None = None
    action_started_mono: float | None = None

    def __post_init__(self):
        for value in (self.prediction_id, self.request_id, self.action_id, self.trace_id, self.clock_id):
            _name(value)
        _name(self.evidence_ref, optional=True)
        _name(self.parent_event_id, optional=True)
        _number(self.observed_mono)
        if self.action_started_mono is not None:
            _number(self.action_started_mono, high=self.observed_mono)
        if self.status not in {"completed", "cancelled", "missing"} or self.evidence not in EVIDENCE:
            raise ValueError("unknown outcome status/evidence provenance")
        if not isinstance(self.observed, Mapping) or len(self.observed) > MAX_METRICS:
            raise ValueError("outcome requires bounded scalar measurements")
        # Immutable-by-interface, detached from the producer; use to_dict at boundaries.
        values = {_name(k): _scalar(v) for k, v in self.observed.items()}
        object.__setattr__(self, "observed", values)

    def to_dict(self):
        return asdict(self)


@dataclass(frozen=True)
class PredictionErrorPayload:
    domain: str
    predicted: dict
    observed: dict
    error: float
    confidence_before: float
    salience: float
    reversible: bool
    source_model: str
    prediction_id: str
    request_id: str
    action_id: str
    trace_id: str
    clock_id: str
    predicted_mono: float
    action_started_mono: float | None
    observed_mono: float
    uncertainty: float
    expected_information_gain: float
    metric_errors: dict
    prospective: bool
    evidence: str
    evidence_ref: str | None
    calibration_eligible: bool
    skill_id: str | None = None
    prediction_method: str = "unspecified"

    def to_dict(self):
        return asdict(self)


def compare(prediction: PredictionRecord, outcome: OutcomeRecord):
    """Pure comparison. Missing/cancelled/invalid observations are not failures."""
    identity = ("prediction_id", "request_id", "action_id", "trace_id", "clock_id")
    if any(getattr(prediction, k) != getattr(outcome, k) for k in identity):
        return "identity_mismatch", None
    if outcome.status != "completed":
        return outcome.status, None
    if outcome.observed_mono < prediction.predicted_mono:
        return "outcome_before_prediction", None
    if outcome.observed_mono > prediction.deadline_mono:
        return "late_outcome", None
    metrics, predicted, observed = {}, {}, {}
    total, weight = 0.0, 0.0
    for metric in prediction.metrics:
        if metric.name not in outcome.observed:
            return "incomplete_outcome", None
        actual = outcome.observed[metric.name]
        try:
            if metric.kind == "bernoulli":
                if type(actual) is not bool:
                    return "invalid_outcome", None
                absolute = abs(metric.predicted - float(actual))
                detail = {"absolute_error": absolute, "normalized_error": absolute, "brier": absolute ** 2}
            elif metric.kind == "numeric":
                actual = _number(actual, low=-1e100, high=1e100)
                absolute = abs(metric.predicted - actual)
                detail = {"absolute_error": absolute, "normalized_error": min(1.0, absolute / metric.scale),
                          "scale": metric.scale}
            else:
                same = type(metric.predicted) is type(actual) and metric.predicted == actual
                detail = {"normalized_error": 0.0 if same else 1.0}
        except ValueError:
            return "invalid_outcome", None
        metrics[metric.name] = detail
        predicted[metric.name], observed[metric.name] = metric.predicted, actual
        total += detail["normalized_error"] * metric.weight
        weight += metric.weight
    measured = prediction.evidence == outcome.evidence == "measured" and bool(outcome.evidence_ref)
    prospective = (prediction.prospective and outcome.action_started_mono is not None
                   and prediction.predicted_mono <= outcome.action_started_mono)
    evidence = "measured" if measured else "simulated" if "simulated" in {prediction.evidence, outcome.evidence} else "unverified"
    return "compared", PredictionErrorPayload(
        domain=prediction.domain, predicted=predicted, observed=observed, error=total / weight,
        confidence_before=prediction.confidence_before, salience=prediction.salience,
        reversible=prediction.reversible, source_model=prediction.source_model,
        prediction_id=prediction.prediction_id, request_id=prediction.request_id, action_id=prediction.action_id,
        trace_id=prediction.trace_id, clock_id=prediction.clock_id,
        predicted_mono=prediction.predicted_mono, action_started_mono=outcome.action_started_mono,
        observed_mono=outcome.observed_mono, uncertainty=prediction.uncertainty,
        expected_information_gain=prediction.expected_information_gain, metric_errors=metrics,
        prospective=prospective, evidence=evidence, evidence_ref=outcome.evidence_ref,
        calibration_eligible=measured and prospective, skill_id=prediction.skill_id,
        prediction_method=prediction.prediction_method)


def from_world_prediction(prediction, *, latency_scale_ms, **identity):
    """Project an already captured WorldModel Prediction, never call/train it.

    The producer must capture BEFORE dispatch and supply its clock domain/times.
    Source confidence is data-depth metadata, not a measured calibration score.
    """
    return PredictionRecord(source_model="world_model", domain="tool",
        metrics=(Metric("success", prediction.p_success, "bernoulli"),
                 Metric("latency_ms", prediction.latency_ms, scale=latency_scale_ms)),
        confidence_before=prediction.confidence, uncertainty=1.0 - prediction.confidence,
        prediction_method=prediction.method, **identity)


def from_state_prediction(predicted, *, scales, domain, source_model, **identity):
    """Project an existing SNN/scene/active-inference forecast without mutating it."""
    if set(predicted) != set(scales):
        raise ValueError("each numeric feature requires an explicit scale")
    return PredictionRecord(domain=domain, source_model=source_model,
        metrics=tuple(Metric(name, value, scale=scales[name]) for name, value in predicted.items()), **identity)


class PredictionErrorObserver:
    """Single-process bounded alignment and advisory feedback, not an executive.

    Retain tombstones for the complete acceptance window; capacity rejects new
    IDs rather than evicting a live/deduplicating slot. No implicit threads/I/O.
    Inject the existing runtime.publish and budget.available methods explicitly.
    """
    def __init__(self, *, mode="off", clock_id, publish=None, budget=None, capacity=1024,
                 retention_s=3600.0, horizon_s=300.0, arrival_grace_s=None, curiosity_threshold=0.25,
                 failure_threshold=3, clock=time.monotonic):
        if mode not in {"off", "shadow"}:
            raise ValueError("prediction observer supports off/shadow only")
        _name(clock_id)
        if type(capacity) is not int or not 1 <= capacity <= 10000:
            raise ValueError("invalid retention capacity")
        _number(retention_s, low=1, high=86400)
        _number(horizon_s, low=0.001, high=retention_s)
        if arrival_grace_s is None:
            arrival_grace_s = min(30.0, retention_s - horizon_s)
        _number(arrival_grace_s, high=retention_s - horizon_s)
        _number(curiosity_threshold, high=1)
        if type(failure_threshold) is not int or not 1 <= failure_threshold <= 32:
            raise ValueError("invalid failure threshold")
        self.mode, self.clock_id, self.publish, self.budget = mode, clock_id, publish, budget
        self.capacity, self.retention_s, self.horizon_s = capacity, retention_s, horizon_s
        self.arrival_grace_s = arrival_grace_s
        self.curiosity_threshold, self.failure_threshold, self.clock = curiosity_threshold, failure_threshold, clock
        self._lock = threading.RLock()
        self._entries, self._skills = {}, {}
        self._counts, self._history = Counter(), deque(maxlen=min(capacity, 256))
        self._skill_saturated = False

    def _time_ok(self, record, stamp, now):
        return record.clock_id == self.clock_id and now - self.retention_s < stamp <= now

    def _entry(self, record, stamp, now):
        if not self._time_ok(record, stamp, now):
            self._counts["stale_or_foreign_clock"] += 1
            return None, "stale_or_foreign_clock"
        key = record.prediction_id
        entry = self._entries.get(key)
        if entry is not None:
            identity = (record.request_id, record.action_id, record.trace_id, record.clock_id)
            if entry["identity"] != identity:
                self._counts["identity_mismatch"] += 1
                return None, "identity_mismatch"
            return entry, None
        if len(self._entries) >= self.capacity:
            self._counts["capacity_rejected"] += 1
            return None, "capacity_rejected"
        entry = {"identity": (record.request_id, record.action_id, record.trace_id, record.clock_id),
                 "prediction": None, "outcome": None, "status": "pending", "payload": None,
                 "expires": stamp + self.retention_s, "first_seen": now, "pending_events": {},
                 "investigation": [], "curiosity_proposed": False}
        self._entries[key] = entry
        return entry, None

    def observe_prediction(self, prediction):
        if self.mode == "off":
            return {"status": "off"}
        if not isinstance(prediction, PredictionRecord):
            raise ValueError("expected PredictionRecord")
        if prediction.deadline_mono - prediction.predicted_mono > self.horizon_s:
            raise ValueError("prediction horizon exceeds configured bound")
        with self._lock:
            now = self.clock()
            self._sweep(now)
            entry, refusal = self._entry(prediction, prediction.predicted_mono, now)
            if refusal:
                return {"status": refusal}
            if entry["prediction"] is not None:
                status = "duplicate" if entry["prediction"] == prediction else "conflicting_prediction"
                self._counts[status] += 1
                return {"status": status}
            if entry["status"] != "pending":
                self._counts["late_prediction"] += 1
                return {"status": "late_prediction"}
            entry["prediction"] = copy.deepcopy(prediction)
            entry["expires"] = max(entry["expires"], prediction.predicted_mono + self.retention_s)
            return self._align(entry)

    def observe_outcome(self, outcome):
        if self.mode == "off":
            return {"status": "off"}
        if not isinstance(outcome, OutcomeRecord):
            raise ValueError("expected OutcomeRecord")
        with self._lock:
            now = self.clock()
            self._sweep(now)
            entry, refusal = self._entry(outcome, outcome.observed_mono, now)
            if refusal:
                return {"status": refusal}
            if entry["outcome"] is not None:
                # Parent event ID can differ when the transport redelivers.
                prior, current = entry["outcome"].to_dict(), outcome.to_dict()
                prior.pop("parent_event_id", None)
                current.pop("parent_event_id", None)
                status = "duplicate" if prior == current else "conflicting_outcome"
                self._counts[status] += 1
                return {"status": status}
            if entry["status"] != "pending":
                self._counts["late_outcome"] += 1
                return {"status": "late_outcome"}
            entry["outcome"] = copy.deepcopy(outcome)
            entry["expires"] = max(entry["expires"], outcome.observed_mono + self.retention_s)
            return self._align(entry)

    def _terminal(self, entry, status):
        entry["status"] = status
        self._counts[status] += 1
        self._history.append({"status": status, "prediction_id": self._key(entry)})
        return {"status": status}

    @staticmethod
    def _key(entry):
        return (entry["prediction"] or entry["outcome"]).prediction_id

    def _align(self, entry):
        prediction, outcome = entry["prediction"], entry["outcome"]
        if outcome is not None and outcome.status in {"cancelled", "missing"}:
            return self._terminal(entry, outcome.status)
        if prediction is None or outcome is None:
            return {"status": "awaiting_prediction" if prediction is None else "awaiting_outcome"}
        status, payload = compare(prediction, outcome)
        self._terminal(entry, status)
        if payload is None:
            return {"status": status}
        entry["payload"] = payload
        self._update_skill(entry)
        self._queue(entry, EventType.PREDICTION_ERROR, payload.to_dict())
        self._propose_curiosity(entry)
        self._flush(entry)
        return {"status": status, "payload": payload.to_dict()}

    def _queue(self, entry, kind, payload):
        prediction, outcome = entry["prediction"], entry["outcome"]
        stable_id = self._event_id(prediction, kind)
        event = new_event(kind, "prediction_error.observer", {**payload, "mode": "shadow"},
            trace_id=prediction.trace_id, parent=(self._event_id(prediction, EventType.PREDICTION_ERROR)
                if kind == EventType.LEARNING_INTENT else outcome.parent_event_id),
            salience=payload.get("salience", prediction.salience), created_mono=self.clock())
        entry["pending_events"][kind.value] = replace(event, event_id=stable_id)

    @staticmethod
    def _event_id(prediction, kind):
        identity = [prediction.clock_id, prediction.trace_id, prediction.request_id,
                    prediction.action_id, prediction.prediction_id, kind.value]
        return hashlib.sha256(json.dumps(identity).encode()).hexdigest()

    def _flush(self, entry):
        if self.publish is None:
            return
        for key, event in list(entry["pending_events"].items()):
            try:
                accepted = self.publish(event) is True
            except Exception:
                accepted = False
            if accepted:
                entry["pending_events"].pop(key, None)
                self._counts["events_accepted"] += 1

    def _propose_curiosity(self, entry):
        payload = entry["payload"]
        score = payload.error * payload.uncertainty * payload.expected_information_gain
        if entry["curiosity_proposed"] or score < self.curiosity_threshold:
            return
        try:
            available = self.budget is not None and self.budget.available("curiosity") is True
        except Exception:
            available = False
        if not available:
            return
        entry["curiosity_proposed"] = True
        self._queue(entry, EventType.LEARNING_INTENT, {
            "kind": "prediction_investigation", "prediction_id": payload.prediction_id,
            "request_id": payload.request_id, "action_id": payload.action_id,
            "source_model": payload.source_model, "domain": payload.domain,
            "curiosity_score": score, "uncertainty_before": payload.uncertainty,
            "expected_information_gain": payload.expected_information_gain,
            "next_step": INVESTIGATION_ORDER[0], "investigation_order": list(INVESTIGATION_ORDER),
            "requires_executive": True, "requires_inference_admission": True,
            "dry_run": True, "salience": payload.salience})

    def retry_publications(self):
        """Retry advisory events only; never repeat prediction, learning or actions."""
        with self._lock:
            self._sweep(self.clock())
            for entry in list(self._entries.values()):
                if entry["payload"] is not None:
                    self._propose_curiosity(entry)
                self._flush(entry)

    def _sweep(self, now):
        for key, entry in list(self._entries.items()):
            if now >= entry["expires"]:
                self._counts["expired_pending_publications"] += len(entry["pending_events"])
                del self._entries[key]
                continue
            if entry["status"] == "pending":
                prediction = entry["prediction"]
                if prediction is not None and now > prediction.deadline_mono + self.arrival_grace_s:
                    self._terminal(entry, "missing_outcome")
                elif prediction is None and now - entry["first_seen"] > self.horizon_s:
                    self._terminal(entry, "orphan_outcome")

    def sweep(self):
        with self._lock:
            self._sweep(self.clock())

    def observe_event(self, event):
        """Fail-open observer hook for the existing runtime's sole consumer.

        Explicit versioned annotations only: never infer joins from tool names,
        temporal proximity, or retrospective legacy surprise. Do not drain the bus.
        """
        if self.mode == "off":
            return {"status": "off"}
        try:
            if event.source == "prediction_error.observer":
                return {"status": "self_event_ignored"}
            fields = event.payload
            if fields.get("pe_child") is True and "outcome_v1" in fields:
                return {"status": "legacy_prediction_error_owner"}
            results = []
            if "prediction_v1" in fields:
                prediction = PredictionRecord.from_dict(fields["prediction_v1"])
                if prediction.trace_id != event.trace_id:
                    raise ValueError("event trace and prediction trace differ")
                results.append(self.observe_prediction(prediction))
            if "outcome_v1" in fields:
                outcome = OutcomeRecord(**dict(fields["outcome_v1"]))
                if outcome.trace_id != event.trace_id:
                    raise ValueError("event trace and outcome trace differ")
                outcome = replace(outcome, parent_event_id=event.event_id)
                results.append(self.observe_outcome(outcome))
            return {"status": "observed" if results else "unannotated", "results": results}
        except Exception as exc:
            with self._lock:
                self._counts["invalid_event"] += 1
            return {"status": "invalid_event", "error_type": type(exc).__name__}

    def calibration(self):
        """Descriptive scores from retained prospective measured pairs only.

        Brier is predictive accuracy, not by itself proof of calibration or gain.
        Never mix a source-model prior/confidence with empirical reliability.
        """
        with self._lock:
            self._sweep(self.clock())
            groups = {}
            for entry in self._entries.values():
                payload = entry["payload"]
                if payload is None or not payload.calibration_eligible:
                    continue
                for metric in entry["prediction"].metrics:
                    if metric.kind != "bernoulli":
                        continue
                    key = (payload.domain, payload.source_model, payload.prediction_method, metric.name)
                    group = groups.setdefault(key, [])
                    group.append((float(payload.predicted[metric.name]), float(payload.observed[metric.name])))
            reports = []
            for (domain, model, method, metric), samples in sorted(groups.items()):
                bins = []
                for index in range(10):
                    values = [(p, y) for p, y in samples if min(9, int(p * 10)) == index]
                    if values:
                        bins.append({"lower": index / 10, "upper": (index + 1) / 10, "n": len(values),
                            "mean_probability": sum(p for p, _ in values) / len(values),
                            "observed_rate": sum(y for _, y in values) / len(values)})
                reports.append({"domain": domain, "source_model": model, "prediction_method": method,
                    "metric": metric, "n": len(samples),
                    "brier": sum((p-y)**2 for p, y in samples) / len(samples), "reliability_bins": bins})
            return {"evidence": "retained_prospective_measured_pairs", "groups": reports,
                    "n": sum(r["n"] for r in reports), "retention_s": self.retention_s,
                    "calibrated": None, "improvement_established": False}

    def _update_skill(self, entry):
        payload, prediction = entry["payload"], entry["prediction"]
        if not payload.skill_id or not payload.calibration_eligible:
            return
        success_metric = next((m for m in prediction.metrics if m.name == "success" and m.kind == "bernoulli"), None)
        if success_metric is None:
            return
        state = self._skills.get(payload.skill_id)
        if state is None:
            if len(self._skills) >= self.capacity:
                self._skill_saturated = True
                return
            state = self._skills[payload.skill_id] = {"failures": 0, "successes": 0, "failure_streak": 0,
                "requires_deliberation": False, "last_observed_mono": -1.0, "recent": []}
        stamp = entry["outcome"].observed_mono
        state["last_observed_mono"] = max(stamp, state["last_observed_mono"])
        state["recent"].append((stamp, payload.prediction_id, payload.observed["success"]))
        state["recent"] = sorted(state["recent"])[-32:]
        if payload.observed["success"] is True:
            state["successes"] += 1
        else:
            state["failures"] += 1
        state["failure_streak"] = 0
        for _, _, success in reversed(state["recent"]):
            if success:
                break
            state["failure_streak"] += 1
        if state["failure_streak"] >= self.failure_threshold:
            state["requires_deliberation"] = True

    def skill_guard(self, skill_id, confidence):
        """Read-only decompilation advice; root applies it through existing owners."""
        _name(skill_id)
        _number(confidence, high=1)
        with self._lock:
            state = self._skills.get(skill_id)
            deliberate = bool(state and state["requires_deliberation"]) or (state is None and self._skill_saturated)
            failures = state["failures"] if state else 0
            return {"skill_id": skill_id, "requires_deliberation": deliberate,
                "confidence_ceiling": min(confidence, confidence / (1 + failures)) if deliberate else confidence,
                "advisory_only": True, "tracked": state is not None, "evidence": copy.deepcopy(state)}

    def acknowledge_skill_review(self, skill_id, *, evidence_ref):
        """Clear only a specifically reviewed advisory guard; never auto-reenable.

        Root's existing skill/planning owner must decide whether relearning or
        correction warrants this acknowledgment and persist its own decision.
        """
        _name(skill_id)
        _name(evidence_ref)
        with self._lock:
            state = self._skills.get(skill_id)
            if state is None:
                return False
            state.update(requires_deliberation=False, failures=0, successes=0, failure_streak=0,
                         recent=[], review_evidence_ref=evidence_ref)
            return True

    def record_investigation(self, prediction_id, *, step, uncertainty_after, evidence_ref):
        """Record authorized investigation results, never perform the investigation."""
        _number(uncertainty_after, high=1)
        _name(evidence_ref)
        with self._lock:
            self._sweep(self.clock())
            entry = self._entries.get(prediction_id)
            if not entry or not entry["curiosity_proposed"]:
                raise ValueError("no curiosity proposal for prediction")
            history = entry["investigation"]
            if len(history) >= len(INVESTIGATION_ORDER) or step != INVESTIGATION_ORDER[len(history)]:
                raise ValueError("investigation must follow local-to-external order")
            before = history[-1]["uncertainty_after"] if history else entry["payload"].uncertainty
            if before == 0:
                raise ValueError("uncertainty already resolved")
            result = {"step": step, "uncertainty_before": before, "uncertainty_after": uncertainty_after,
                "uncertainty_reduction": before - uncertainty_after, "uncertainty_fell": uncertainty_after < before,
                "evidence_ref": evidence_ref}
            history.append(result)
            return copy.deepcopy(result)

    def stats(self):
        with self._lock:
            return {"mode": self.mode, "retained": len(self._entries), "capacity": self.capacity,
                "pending_publications": sum(len(e["pending_events"]) for e in self._entries.values()),
                "counts": dict(self._counts), "history": list(self._history),
                "tracked_skills": len(self._skills), "skill_tracking_saturated": self._skill_saturated}
