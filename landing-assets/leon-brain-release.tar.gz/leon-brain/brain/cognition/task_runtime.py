"""Single approved-check service beneath the existing executive.

No planning/model/speech loop. The existing runtime tick consumes durable
receipts; the finite TaskWorker pool owns committed actions. Configuration and
installation principal are trusted startup inputs, never request body fields.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import os
import sqlite3
import stat
import threading
import time


class TaskUnavailable(RuntimeError):
    pass


class TaskAccessDenied(RuntimeError):
    pass


class TaskSubmissionConflict(RuntimeError):
    pass


def _text(value, maximum=200):
    if (not isinstance(value, str) or not value.strip() or len(value) > maximum
            or any(ord(c) < 32 for c in value)):
        raise ValueError('bounded identifier required')
    return value


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()


_SCHEMA = '''
CREATE TABLE IF NOT EXISTS task_submissions (
 submission_id TEXT PRIMARY KEY, principal TEXT NOT NULL,
 fingerprint TEXT NOT NULL, scope TEXT NOT NULL, check_name TEXT NOT NULL,
 spec_sha256 TEXT NOT NULL, grant_ref TEXT UNIQUE NOT NULL,
 approval_ref TEXT NOT NULL, expires_wall REAL NOT NULL,
 authorization_revision INTEGER NOT NULL, task_id TEXT UNIQUE, action_id TEXT,
 created_wall REAL NOT NULL);
'''


@dataclass(frozen=True)
class TaskExecutionConfig:
    """Trusted startup output of the confinement/configuration verifier."""
    operational_dir: str
    workspaces: tuple
    containment_authority: object
    containment_preview: object = None
    containment_wrapper: object = None
    check_handler_factory: object = None
    planner_configuration: object = None
    improvement_configuration: object = None
    proof_check_handler_factory: object = None


@dataclass(frozen=True)
class ProofCheckBindings:
    """Trusted parent-side execution and receipt verification capabilities."""
    handler: object
    resolve_input_proof: object

    def __post_init__(self):
        if not callable(self.handler) or not callable(self.resolve_input_proof):
            raise TypeError('explicit proof execution and receipt capabilities required')


class TaskRuntime:
    """Explicit startup/retirement owner. OFF does not open any store.

    Single checks, supervised plans and optional development proposals share
    the same worker pool and durable receipts. No ingress accepts a shell,
    model-produced permission or unconfigured workspace. Check commands,
    environment and containment belong to trusted startup configuration.
    """
    def __init__(self, *, operational_dir=None, workspaces=(), installation_principal=None,
                 configured_mode='off', live_mode=lambda: 'off', containment_authority=None,
                 containment_preview=None, containment_wrapper=None, check_handler_factory=None,
                 planner_configuration=None, improvement_configuration=None,
                 proof_check_handler_factory=None, clock=time.time):
        self._directory = operational_dir
        self._workspaces = tuple(workspaces)
        self._principal = installation_principal
        self._configured, self._live_mode, self._clock = configured_mode, live_mode, clock
        self._containment_authority = containment_authority
        self._containment_preview = containment_preview
        self._containment_wrapper = containment_wrapper
        if sum(value is not None for value in
               (containment_wrapper, check_handler_factory, proof_check_handler_factory)) > 1:
            raise ValueError('choose one check execution boundary')
        if check_handler_factory is not None and not callable(check_handler_factory):
            raise ValueError('trusted check handler factory required')
        self._check_handler_factory = check_handler_factory
        if (proof_check_handler_factory is not None
                and (not callable(proof_check_handler_factory) or improvement_configuration is None)):
            raise ValueError('proof check factory requires an owned improvement registry')
        self._proof_check_handler_factory = proof_check_handler_factory
        self._planner_configuration = planner_configuration
        self._planner_owner = self._planner_ingress = None
        if improvement_configuration is not None and planner_configuration is None:
            raise ValueError('improvement requires owned planner configuration')
        if improvement_configuration is not None and proof_check_handler_factory is None:
            raise ValueError('installed improvement requires an owned proof check factory')
        self._improvement_configuration = improvement_configuration
        self._improvement_owner = None
        self._lock = threading.RLock()
        self._started = self._stopping = self._retired = False
        self._activation_thread = None
        self._activation_error = None
        self._store = self._policy = self._registry = self._backend = self._worker = None
        self._cached = {'installed': False, 'mode': 'off', 'retired': False,
                        'tasks': 0, 'actions': 0, 'outbox': 0, 'failures': 0}

    def _enabled(self):
        try:
            # Canary action admission needs an explicit scope cohort contract.
            return (not self._stopping and self._configured == 'on'
                    and self._live_mode() == 'on' and self._worker_healthy())
        except Exception:
            return False

    def _worker_healthy(self):
        if not self._started:
            return True
        health = self._worker.stats()
        return (health['started'] and not health['stopping'] and not health['drained']
                and health['fault'] is None and health['alive'] == health['workers'])

    @contextmanager
    def _access(self, principal, *, active=False):
        if not self._lock.acquire(timeout=.25):
            raise TaskUnavailable('task service busy')
        try:
            if self._stopping or not self._started:
                raise TaskUnavailable('task service unavailable')
            if not isinstance(principal, str) or principal != self._principal:
                raise TaskAccessDenied('installation principal required')
            if active and not self._enabled():
                raise TaskUnavailable('task action admission disabled')
            yield
        finally:
            self._lock.release()

    def start(self):
        with self._lock:
            if self._stopping:
                raise TaskUnavailable('retiring task owner')
            if self._started:
                return self
            if not self._enabled():
                return self
            _text(self._principal)
            path = os.fspath(self._directory) if self._directory is not None else ''
            if not os.path.isabs(path) or os.path.realpath(path) != os.path.normpath(path):
                raise ValueError('explicit unaliased operational directory required')
            if not os.path.isdir(path) or not self._workspaces:
                raise ValueError('existing operational directory and configured workspaces required')
            info = os.stat(path)
            if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o022:
                raise ValueError('operational directory must have exclusive write ownership')
            leaves = (base + suffix for base in ('tasks.sqlite', 'task_policy.sqlite')
                      for suffix in ('', '-wal', '-shm', '-journal'))
            for leaf in leaves:
                # Validate the leaf before TaskStore's legacy realpath normalization.
                # Metadata must not be redirected into an action workspace.
                database = os.path.join(path, leaf)
                if os.path.lexists(database):
                    info = os.lstat(database)
                    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                            or info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o077):
                        raise ValueError('private unaliased operational database required')
            for workspace in self._workspaces:
                root = os.path.realpath(workspace.root)
                if os.path.commonpath((path, root)) in (path, root):
                    raise ValueError('task metadata and action workspaces must be disjoint')
            from .task_lifecycle import TaskStore
            from .task_policy import TaskPolicy
            from .task_project_actions import ProjectActions
            from .task_worker import TaskWorker
            try:
                self._store = TaskStore(os.path.join(path, 'tasks.sqlite'), clock=self._clock)
                # Same operational DB, separately owned immutable ingress table.
                self._registry = sqlite3.connect(self._store.path, timeout=.25,
                    check_same_thread=False, isolation_level=None)
                self._registry.row_factory = sqlite3.Row
                self._registry.execute('PRAGMA synchronous=FULL')
                self._registry.executescript(_SCHEMA)
                self._policy = TaskPolicy(os.path.join(path, 'task_policy.sqlite'),
                    resolve_context=self._resolve_context, clock=self._clock)
                self._backend = ProjectActions(self._workspaces, authority=self._authorize)
                if self._planner_configuration is not None:
                    from .task_planner_runtime import PlannerRuntime
                    self._planner_owner = PlannerRuntime(self, self._planner_configuration)
                    self._planner_ingress = self._planner_owner.ingress
                    self._planner_owner.prepare()
                if self._improvement_configuration is not None:
                    from .improvement_runtime import ImprovementRuntime
                    self._improvement_owner = ImprovementRuntime(self, self._planner_owner,
                                                                  self._improvement_configuration)
                    # Reserve-parent constraints must exist before retained
                    # children can be claimed, including after a restart.
                    self._improvement_owner.prepare()
                handlers = dict(self._backend.handlers)
                if self._proof_check_handler_factory is not None:
                    bindings = self._proof_check_handler_factory(self._parent_effect_authority,
                        self._improvement_owner.proof_required, self._improvement_owner.check_material)
                    if type(bindings) is not ProofCheckBindings:
                        raise ValueError('typed immutable check bindings required')
                    self._improvement_owner.bind_input_proof_resolver(bindings.resolve_input_proof)
                    handlers["project.run_check"] = bindings.handler
                elif callable(self._check_handler_factory):
                    # Remote service rechecks this parent-only callback after
                    # its authenticated handshake, immediately before send.
                    # It must never recursively call bridge RPC on that socket.
                    handlers["project.run_check"] = self._check_handler_factory(self._parent_effect_authority)
                    if not callable(handlers["project.run_check"]):
                        raise ValueError("verified remote check handler required")
                elif callable(self._containment_wrapper):
                    handlers["project.run_check"] = self._containment_wrapper(handlers["project.run_check"])
                    if not callable(handlers["project.run_check"]):
                        raise ValueError("containment result wrapper required")
                else:
                    # Missing proof cannot fall through to the raw backend,
                    # even if a stale action existed before this restart.
                    handlers.pop("project.run_check", None)
                self._worker = TaskWorker(self._store, handlers=handlers,
                    policy=self._backend.policy, workers=2, max_background=1, start_paused=True)
                worker = self._worker
                if self._stopping:
                    raise TaskUnavailable('retiring task owner')
                self._worker.start()
                self._started = True
                if self._stopping:
                    self._worker.stop(0)
                self._refresh_stats()
            except BaseException:
                self._stopping = True
                self.stop(join_timeout=.25)
                raise
        # A retained action may otherwise be claimed before this startup lock
        # is released, making its .25s authority timeout a permanent denial.
        # Publish readiness first; retirement still closes the pool's gate.
        if self._worker is worker and self._started and not self._stopping:
            worker.release_startup()
        return self

    def _resolve_context(self, task_id):
        # The registry is integrator-owned, not the model's mutable checkpoint.
        from .task_policy import TrustedTaskContext
        with self._lock:
            if self._registry is None or self._stopping:
                return None
            row = self._registry.execute('SELECT * FROM task_submissions WHERE task_id=?',
                                         (task_id,)).fetchone()
            if row is None:
                return (self._planner_ingress.resolve_child(task_id, active=True)
                        if self._planner_ingress is not None else None)
            if row['principal'] != self._principal:
                return None
            return TrustedTaskContext(row['principal'], task_id, row['submission_id'],
                                      row['authorization_revision'], row['scope'])

    def _historical_context(self, task_id):
        # Expiry/revocation denies future effects, never destroys ownership of
        # retained receipts. This path is used only after authenticated access.
        from .task_policy import TrustedTaskContext
        with self._lock:
            if self._registry is None or self._stopping:
                return None
            row = self._registry.execute('SELECT * FROM task_submissions WHERE task_id=?',
                                         (task_id,)).fetchone()
            if row is not None and row['principal'] == self._principal:
                return TrustedTaskContext(row['principal'], task_id, row['submission_id'],
                                          row['authorization_revision'], row['scope'])
            return (self._planner_ingress.resolve_child(task_id, active=False)
                    if self._planner_ingress is not None else None)

    def planner_runtime(self, *, principal):
        with self._access(principal):
            if self._planner_owner is None:
                raise TaskUnavailable('supervised planner is not configured')
            return self._planner_owner

    def improvement_runtime(self, *, principal):
        with self._access(principal):
            if self._improvement_owner is None:
                raise TaskUnavailable('development proposals are not configured')
            return self._improvement_owner

    def _authorize(self, action, task, spec):
        if not self._enabled():
            return False
        if spec.name == 'project.run_check':
            if not self._containment_verified(spec):
                return False
            try:
                if self._containment_authority(action, task, spec) is not True:
                    return False
            except Exception:
                return False
        return self._parent_effect_authority(action, task, spec)

    def _parent_effect_authority(self, action, task, spec):
        """Fresh durable action/grant authority, with no execution-service RPC.

        IPC setup may outlive cancellation, revocation or flag changes. Read
        the retained attempt again at the actual dispatch boundary. Approval
        cannot be supplied by a mutable checkpoint or a service response.
        """
        if not self._lock.acquire(timeout=.25):
            return False
        try:
            if not self._enabled() or self._store is None or self._policy is None:
                return False
            current_action = self._store.get_action(action.get('action_id'))
            current_task = self._store.get_task(task.get('task_id'))
            if current_action is None or current_task is None:
                return False
            for key in ('action_id', 'task_id', 'idem_key', 'name', 'arguments',
                        'resources', 'tier', 'fingerprint', 'state', 'dispatched'):
                if action.get(key) != current_action.get(key):
                    return False
            for key in ('task_id', 'idem_key', 'project_scope', 'authorization_ref',
                        'state', 'cancel_requested', 'deadline_wall', 'priority'):
                if task.get(key) != current_task.get(key):
                    return False
            canonical = self._backend.canonical_resource_spec(current_action['name'],
                current_action['arguments'], current_task)
            if canonical != spec:
                return False
            return self._policy.authorize(current_action, current_task, canonical) is True
        except Exception:
            return False
        finally:
            self._lock.release()

    def _containment_verified(self, spec):
        try:
            return (callable(self._containment_authority)
                    and callable(self._containment_preview)
                    and sum(callable(value) for value in (self._containment_wrapper,
                        self._check_handler_factory, self._proof_check_handler_factory)) == 1
                    and self._containment_preview(spec) is True)
        except Exception:
            return False

    def preview_check(self, *, principal, scope, check):
        """Reviewable exact configured check; this does not create a grant/task."""
        with self._access(principal, active=True):
            spec = self._backend.canonical_resource_spec('project.run_check',
                {'check': _text(check)}, {'project_scope': _text(scope, 1000)})
        # The service owns one protocol connection at a time. Never retain
        # the parent lock over IPC: an executing action needs that same lock
        # for its final authority callback before the service can serve us.
        if not self._containment_verified(spec):
            raise TaskUnavailable('configured check containment is unverified')
        with self._access(principal, active=True):
            current = self._backend.canonical_resource_spec('project.run_check',
                {'check': check}, {'project_scope': scope})
            if current != spec:
                raise TaskSubmissionConflict('configured check changed during preview')
            workspace = next(w for w in self._workspaces if w.scope == scope)
            command = next(c for c in workspace.checks if c.name == check)
            return {'scope': spec.scope, 'check': check, 'action': spec.name,
                    'tier': spec.minimum_tier, 'approval_sha256': _digest(asdict(spec)),
                    'configuration_sha256': spec.configuration_sha256,
                    'command': list(command.argv), 'working_directory': command.cwd,
                    'timeout_s': command.timeout_s, 'containment_ref': command.containment_ref,
                    'environment_keys': [key for key, _ in command.env],
                    'single_action': True, 'approval_lifetime_s': 900}

    def submit_approved_check(self, *, principal, scope, check, idempotency_key,
                              approval_sha256, approved):
        """Executive-only ingress after explicit approval of preview_sha256.

        Principal is supplied by verified server authentication. The HTTP/model
        payload cannot choose a principal, resource set, tier, root or command.
        Partial submission is recovered by replaying the same idempotency key;
        each stage is durable before the next, and action replay is forbidden.
        """
        def retained_submission():
            row = self._registry.execute('SELECT * FROM task_submissions WHERE submission_id=?',
                                         (submission,)).fetchone()
            if row is not None:
                if row['fingerprint'] != fingerprint or row['principal'] != principal:
                    raise TaskSubmissionConflict('submission key has different approved input')
                prior = self._store.action_for_step(row['task_id'], 'check:1') if row['task_id'] else None
                if prior is not None:
                    # Read-only recovery grants no new effect, even after OFF,
                    # expiry, configuration changes or service unavailability.
                    task = self._store.get_task(row['task_id'])
                    return row, {'task_id': row['task_id'], 'action_id': prior['action_id'],
                                 'state': task['state'], 'accepted': True}
            return row, None

        with self._access(principal):
            if approved is not True:
                raise TaskAccessDenied('explicit finalized check approval required')
            _text(idempotency_key)
            _text(scope, 1000); _text(check); _text(approval_sha256, 64)
            submission = 'submission:' + _digest([principal, idempotency_key])
            fingerprint = _digest([scope, check, approval_sha256])
            row, accepted = retained_submission()
            if accepted is not None:
                return accepted
            if not self._enabled():
                raise TaskUnavailable('task action admission disabled')
        preview = self.preview_check(principal=principal, scope=scope, check=check)
        with self._access(principal, active=True):
            # Another admission may have finished while the service replied.
            row, accepted = retained_submission()
            if accepted is not None:
                return accepted
            current = self._backend.canonical_resource_spec('project.run_check',
                {'check': check}, {'project_scope': scope})
            if (approval_sha256 != preview['approval_sha256']
                    or approval_sha256 != _digest(asdict(current))):
                raise TaskSubmissionConflict('configured check changed since review')
            if row is None:
                if self._registry.execute('SELECT count(*) FROM task_submissions').fetchone()[0] >= 256:
                    raise TaskUnavailable('retained submission capacity exhausted')
                now = float(self._clock())
                if not math.isfinite(now):
                    raise ValueError('finite clock required')
                self._registry.execute('INSERT INTO task_submissions VALUES (?,?,?,?,?,?,?,?,?,1,NULL,NULL,?)',
                    (submission, principal, fingerprint, scope, check, approval_sha256,
                     'grant:' + _digest([submission]), 'approval:' + _digest([submission, fingerprint]),
                     now + 900, now))
                row = self._registry.execute('SELECT * FROM task_submissions WHERE submission_id=?',
                                             (submission,)).fetchone()
            task = self._store.create_task(idempotency_key=submission, project_scope=scope,
                authorization_ref=row['grant_ref'], priority=70, deadline_wall=row['expires_wall'],
                checkpoint={'schema': 1, 'kind': 'approved_single_check', 'step_key': 'check:1',
                            'result_seq': 0})
            if row['task_id'] not in (None, task['task_id']):
                raise TaskSubmissionConflict('submission task identity differs')
            self._registry.execute('UPDATE task_submissions SET task_id=? WHERE submission_id=?',
                                   (task['task_id'], submission))
            spec = self._backend.canonical_resource_spec('project.run_check', {'check': check}, task)
            self._policy.create_grant(grant_ref=row['grant_ref'], context=self._resolve_context(task['task_id']),
                action_key='check:1', spec=spec, tier=spec.minimum_tier,
                approval_ref=row['approval_ref'], expires_wall=row['expires_wall'])
            action = self._store.enqueue_action(task['task_id'], idempotency_key='check:1',
                name=spec.name, arguments=dict(spec.arguments), resources=list(spec.resources),
                tier=spec.minimum_tier, expected_revision=task['revision'])
            self._registry.execute('UPDATE task_submissions SET action_id=? WHERE submission_id=?',
                                   (action['action_id'], submission))
            self._worker.notify()
            return {'task_id': task['task_id'], 'action_id': action['action_id'],
                    'state': self._store.get_task(task['task_id'])['state'], 'accepted': True}

    def task(self, task_id, *, principal, after_seq=0, limit=100):
        """Authorized reconnect view; reads never acknowledge the runtime outbox."""
        with self._access(principal):
            context = self._historical_context(_text(task_id))
            if context is None or context.principal != principal:
                raise TaskAccessDenied('task unavailable for this principal')
            task = self._store.get_task(task_id)
            receipts = self._store.receipts_after(task_id, after_seq=after_seq, limit=limit)
            return {'task_id': task_id, 'state': task['state'], 'revision': task['revision'],
                    'cancel_requested': task['cancel_requested'],
                    'receipts': [{'action_id': a['action_id'], 'seq': a['result_seq'],
                                  'outcome': a['state'], 'result': a['result']} for a in receipts]}

    def cancel(self, task_id, *, principal):
        """Stop future steps. An already committed check drains and keeps its receipt."""
        with self._access(principal):
            context = self._historical_context(_text(task_id))
            if context is None or context.principal != principal:
                raise TaskAccessDenied('task unavailable for this principal')
            task = self._store.cancel_task(task_id)
            self._worker.notify()
            return {'task_id': task_id, 'state': task['state'],
                    'cancel_requested': task['cancel_requested']}

    def tick(self):
        """Activate cold owners, then checkpoint durable results before ack.

        SQLite initialization must not run on the event consumer. At most one
        owned, one-shot starter exists; it is part of the retirement barrier.
        """
        if not self._lock.acquire(blocking=False):
            return
        try:
            if self._stopping:
                return
            if not self._started:
                if self._enabled() and not self._activation_alive():
                    self._activation_thread = threading.Thread(target=self._activate,
                        name='leon-task-activate', daemon=True)
                    try:
                        self._activation_thread.start()
                    except BaseException as exc:
                        self._activation_error = type(exc).__name__
                        self.quiesce()
                        raise
                return
            for result in self._store.pending_results(consumer='runtime', limit=8):
                if (self._planner_ingress is not None
                        and self._planner_ingress.checkpoint_result(result) is True):
                    self._store.acknowledge_result(result['seq'], consumer='runtime')
                    continue
                context = self._resolve_context(result['task_id'])
                if context is None:
                    continue
                task = self._store.get_task(result['task_id'])
                receipt = self._store.get_action(result['action_id'])
                if receipt is None or receipt['result_seq'] != result['seq']:
                    continue
                if result['outcome'] == 'SUCCEEDED' and task['state'] == 'READY':
                    checkpoint = dict(task['checkpoint'])
                    if checkpoint.get('kind') != 'approved_single_check':
                        continue
                    checkpoint.update(result_seq=result['seq'], action_id=result['action_id'])
                    task = self._store.checkpoint(task['task_id'], checkpoint,
                        expected_revision=task['revision'], state='SUCCEEDED')
                if task['state'] == 'SUCCEEDED':
                    if task['checkpoint'].get('result_seq') != result['seq']:
                        continue
                elif task['state'] not in ('FAILED', 'CANCELLED', 'NEEDS_REVIEW'):
                    continue
                # Failed/unknown/cancelled terminal state and receipt were already
                # committed atomically by TaskStore. No learning/action follows.
                self._store.acknowledge_result(result['seq'], consumer='runtime')
            self._refresh_stats()
        except Exception:
            self._cached['failures'] += 1
        finally:
            self._lock.release()

    def _activation_alive(self):
        return self._activation_thread is not None and self._activation_thread.is_alive()

    def _activate(self):
        try:
            self.start()
        except BaseException as exc:
            if not (isinstance(exc, TaskUnavailable) and self._stopping):
                self._activation_error = type(exc).__name__
                self._cached['failures'] += 1
            self.quiesce()
        finally:
            if self._stopping:
                self.stop()

    def _refresh_stats(self):
        counts = self._store.stats()
        self._cached.update({k: counts[k] for k in ('tasks', 'actions', 'outbox')})
        self._cached.update(installed=True, mode='on' if self._enabled() else 'off')
        health = self._worker.stats()
        self._cached['worker'] = {k: health[k] for k in ('alive', 'workers', 'fault', 'stopping', 'drained')}

    def quiesce(self):
        self._stopping = True
        if self._improvement_owner is not None:
            self._improvement_owner.quiesce()
        if self._planner_owner is not None:
            self._planner_owner.quiesce()
        if self._worker is not None:
            self._worker.stop(0)

    def stop(self, *, join_timeout=0):
        if (isinstance(join_timeout, bool) or not isinstance(join_timeout, (int, float))
                or not math.isfinite(join_timeout) or join_timeout < 0):
            raise ValueError('join_timeout')
        deadline = time.monotonic() + join_timeout
        self.quiesce()
        starter = self._activation_thread
        if starter is not threading.current_thread() and self._activation_alive():
            starter.join(max(0, deadline - time.monotonic()))
            if starter.is_alive():
                return False
        if self._worker is not None and not self._worker.stop(max(0, deadline - time.monotonic())):
            return False
        if self._planner_owner is not None and not self._planner_owner.drained:
            return False
        if self._improvement_owner is not None and not self._improvement_owner.drained:
            return False
        if not self._lock.acquire(blocking=False):
            return False
        try:
            if self._retired:
                return True
            if self._policy is not None:
                self._policy.close()
            if self._registry is not None:
                self._registry.close()
                self._registry = None
            if self._store is not None:
                self._store.close()
            self._retired = True
            self._cached.update(installed=False, mode='off', retired=True)
            return True
        finally:
            self._lock.release()

    @property
    def retired(self):
        return self._retired and not self._activation_alive()

    def stats(self):
        return {**self._cached, 'stopping': self._stopping,
                'retired': self.retired, 'activating': self._activation_alive(),
                'activation_error': self._activation_error,
                'scope': 'approved_single_check', 'automatic_planning': False}
