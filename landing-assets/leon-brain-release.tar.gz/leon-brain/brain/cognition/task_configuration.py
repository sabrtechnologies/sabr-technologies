"""Explicit private operator configuration for fixed checks, without launch.

This loader is called only on opted-in task startup. It cannot invent a
workspace, canonical root, command, principal or process-containment proof.
"""
from __future__ import annotations

from dataclasses import replace
import json
import os
from pathlib import Path
import stat

from .task_check_containment import CheckContainment, ContainedCommand
from .task_runtime import TaskExecutionConfig, ProofCheckBindings
from .task_worker import ActionResult


def _absolute(value):
    if (type(value) is not str or not os.path.isabs(value) or '\0' in value
            or os.path.realpath(value) != value or os.path.normpath(value) != value):
        raise ValueError('explicit unaliased absolute task path required')
    return value


def _unique(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('duplicate task configuration key')
        out[key] = value
    return out


def _nonfinite(_):
    raise ValueError('nonfinite task configuration number')


def _private_json(path):
    path = _absolute(path)
    parent = os.stat(os.path.dirname(path), follow_symlinks=False)
    if not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.geteuid() or parent.st_mode & 0o022:
        raise ValueError('exclusive task configuration directory required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_uid != os.geteuid()
                or before.st_mode & 0o077 or before.st_size > 65536):
            raise ValueError('private bounded regular task configuration required')
        raw = os.read(fd, 65537)
        after, current = os.fstat(fd), os.stat(path, follow_symlinks=False)
        identity = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
        if len(raw) > 65536 or identity(before) != identity(after) or identity(before) != identity(current):
            raise ValueError('task configuration changed during read')
        return json.loads(raw.decode('utf-8'), object_pairs_hook=_unique, parse_constant=_nonfinite)
    finally:
        os.close(fd)


class _ConfiguredChecks:
    """One retained bundle supplies every part of the execution boundary."""
    def __init__(self, guards):
        self._guards = {guard.workspace.scope: guard for guard in guards}

    def preview(self, spec):
        guard = self._guards.get(spec.scope)
        return guard is not None and guard.validate_spec(spec) is True

    def authorize(self, action, task, spec):
        guard = self._guards.get(spec.scope)
        return guard is not None and guard.authorize(action, task, spec) is True

    def wrap(self, handler):
        wrapped = {scope: guard.wrap_handler(handler) for scope, guard in self._guards.items()}
        def run(action, task):
            execute = wrapped.get(task.get('project_scope'))
            if execute is None:
                return ActionResult('FAILED', {'ok': False, 'executed': False,
                                              'reason': 'unconfigured_containment_scope'})
            return execute(action, task)
        return run


def load_task_execution_config(path, *, canonical_roots):
    """Read an explicit operator file; no model, network, probe or effect call."""
    if type(canonical_roots) is not tuple or not 1 <= len(canonical_roots) <= 6:
        raise ValueError('actual canonical persistence roots required')
    canonical = tuple(_absolute(root) for root in canonical_roots)
    document = _private_json(path)
    if (type(document) is not dict or type(document.get('schema')) is not int
            or document['schema'] not in (1, 2, 3, 4)
            or set(document) != ({'schema', 'operational_dir', 'workspaces'} if document['schema'] == 1
                                 else {'schema', 'operational_dir', 'check_service'} if document['schema'] == 2
                                 else {'schema', 'operational_dir', 'check_service', 'planner'} if document['schema'] == 3
                                 else {'schema', 'operational_dir', 'check_service', 'planner', 'improvement'})):
        raise ValueError('exact task configuration schema required')
    operational = _absolute(document['operational_dir'])
    if any(os.path.commonpath((operational, root)) in (operational, root) for root in canonical):
        raise ValueError('task metadata overlaps canonical persistence')
    info = os.stat(operational, follow_symlinks=False)
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
        raise ValueError('private existing operational directory required')
    if document['schema'] in (2, 3, 4):
        config = _service_execution_config(document['check_service'], operational, _absolute(path), canonical,
                                           immutable_checks=document['schema'] == 4)
        if document['schema'] in (3, 4):
            config = replace(config, planner_configuration=_planner_configuration(document['planner'], config))
        if document['schema'] == 4:
            config = replace(config, improvement_configuration=_improvement_configuration(
                document['improvement'], config, _absolute(path), canonical))
        return config
    rows = document['workspaces']
    if type(rows) is not list or not 1 <= len(rows) <= 8:
        raise ValueError('bounded explicit workspace configuration required')
    guards, scopes, roots = [], set(), []
    for row in rows:
        if type(row) is not dict or set(row) != {'scope', 'root', 'checks'}:
            raise ValueError('exact workspace configuration required')
        scope, root = row['scope'], _absolute(row['root'])
        if type(scope) is not str or not scope.startswith('workspace:') or len(scope) > 1000 or scope in scopes:
            raise ValueError('unique explicit workspace scope required')
        blocked = (operational, _absolute(path), *canonical, *roots)
        if any(os.path.commonpath((root, other)) in (root, other) for other in blocked):
            raise ValueError('workspace overlaps private state or another workspace')
        checks = row['checks']
        if type(checks) is not list or not 1 <= len(checks) <= 16:
            raise ValueError('bounded fixed checks required')
        commands = []
        for check in checks:
            if type(check) is not dict or set(check) != {'name', 'argv', 'cwd', 'timeout_s'} or type(check['argv']) is not list:
                raise ValueError('exact fixed check configuration required')
            commands.append(ContainedCommand(check['name'], tuple(check['argv']), check['cwd'], check['timeout_s']))
        guard = CheckContainment(scope=scope, root=root, checks=tuple(commands),
                                 forbidden_roots=(operational, _absolute(path), *canonical))
        guards.append(guard); scopes.add(scope); roots.append(root)
    bundle = _ConfiguredChecks(tuple(guards))
    return TaskExecutionConfig(operational, tuple(g.workspace for g in guards),
                               bundle.authorize, bundle.preview, bundle.wrap)


def _planner_configuration(value, config):
    """Private startup allowlists only; no request-derived paths or commands."""
    from .task_planner_runtime import TaskPlannerOperatorConfig
    from .task_planner_ingress import PlanScope, _scope
    from .task_project_actions import ProjectActions
    if (type(value) is not dict or set(value) != {'enabled', 'scopes'}
            or type(value['enabled']) is not bool or type(value['scopes']) is not list
            or not 1 <= len(value['scopes']) <= 16):
        raise ValueError('explicit bounded planner configuration required')
    fields = {'project_scope', 'allowed_actions', 'allowed_paths', 'allowed_checks',
              'max_steps', 'max_rounds', 'lifetime_s', 'authorization_revision'}
    backend = ProjectActions(workspaces=config.workspaces)
    scopes = []
    for row in value['scopes']:
        if type(row) is not dict or set(row) != fields:
            raise ValueError('exact operator scope configuration required')
        if any(type(row[key]) is not list or any(type(item) is not str for item in row[key])
               for key in ('allowed_actions', 'allowed_paths', 'allowed_checks')):
            raise ValueError('explicit scope lists required')
        scope = PlanScope(**{key: tuple(item) if key.startswith('allowed_') else item
                             for key, item in row.items()})
        try:
            _scope(scope, scope.project_scope)
            if (set(scope.allowed_actions).intersection(('project.read_text', 'project.replace_text'))
                    and not scope.allowed_paths):
                raise ValueError('file actions require explicit paths')
            if 'project.run_check' in scope.allowed_actions and not scope.allowed_checks:
                raise ValueError('check action requires explicit names')
            if scope.project_scope not in {workspace.scope for workspace in config.workspaces}:
                raise ValueError('planner scope has no configured workspace')
            for path in scope.allowed_paths:
                backend.canonical_resource_spec('project.read_text', {'path': path},
                                                {'project_scope': scope.project_scope})
            for check in scope.allowed_checks:
                backend.canonical_resource_spec('project.run_check', {'check': check},
                                                {'project_scope': scope.project_scope})
        except Exception as exc:
            raise ValueError('invalid operator scope configuration') from exc
        scopes.append(scope)
    # Freeze the selected value; changing a request or the caller's dictionary
    # cannot change this installed authority. Live task admission remains separate.
    enabled = value['enabled']
    try:
        return TaskPlannerOperatorConfig(tuple(scopes), enabled=lambda: enabled)
    except TypeError as exc:
        raise ValueError('unique typed operator scopes required') from exc


def _improvement_configuration(value, config, parent_config, canonical):
    """Explicit private development allowlists, never model-selected roots."""
    from .improvement_runtime import ImprovementWorkspace, ImprovementRuntimeConfig
    from .improvement_artifacts import InputFile, _path
    import re
    if (type(value) is not dict or set(value) != {'enabled', 'workspaces'}
            or type(value['enabled']) is not bool or type(value['workspaces']) is not list
            or not 1 <= len(value['workspaces']) <= 4):
        raise ValueError('explicit bounded improvement configuration required')
    fields = {'key', 'project_scope', 'source_revision', 'isolation_ref', 'input_files',
              'editable_paths', 'protected_paths', 'required_checks'}
    forbidden = (config.operational_dir, parent_config, str(Path(__file__).resolve().parents[2]), *canonical)
    selected, keys, scopes = [], set(), set()
    planner_scopes = {scope.project_scope: scope for scope in config.planner_configuration.scopes}
    for row in value['workspaces']:
        if type(row) is not dict or set(row) != fields:
            raise ValueError('exact improvement workspace configuration required')
        for name in ('key', 'project_scope', 'isolation_ref'):
            if type(row[name]) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}', row[name]):
                raise ValueError('bounded trusted improvement reference required')
        if (row['key'] in keys or row['project_scope'] in scopes
                or row['project_scope'] not in planner_scopes
                or type(row['source_revision']) is not str
                or not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', row['source_revision'])):
            raise ValueError('unique planner-bound development identity required')
        files = row['input_files']
        if type(files) is not list or not 1 <= len(files) <= 128:
            raise ValueError('bounded complete input inventory required')
        paths, inputs = set(), []
        for item in files:
            if (type(item) is not dict or set(item) != {'path', 'mode'}
                    or type(item['path']) is not str or item['path'] in paths
                    or type(item['mode']) is not int or item['mode'] not in (0o600, 0o644, 0o700, 0o755)):
                raise ValueError('unique explicit input path and mode required')
            _path(item['path'])
            paths.add(item['path']); inputs.append(InputFile(item['path'], item['mode']))
        for name, maximum in (('editable_paths', 16), ('protected_paths', 32), ('required_checks', 3)):
            items = row[name]
            if (type(items) is not list or not 1 <= len(items) <= maximum
                    or any(type(item) is not str for item in items) or len(set(items)) != len(items)):
                raise ValueError('bounded explicit development policy required')
            for item in items:
                if name == 'required_checks':
                    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}', item):
                        raise ValueError('bounded check reference required')
                else:
                    _path(item)
        scope = planner_scopes[row['project_scope']]
        if (not set(row['editable_paths']) <= paths.intersection(scope.allowed_paths)
                or not set(row['required_checks']) <= set(scope.allowed_checks)
                or not {'project.replace_text', 'project.run_check'} <= set(scope.allowed_actions)
                or scope.max_steps < 1 + 2 * len(row['required_checks'])
                or any(path == protected or path.startswith(protected + '/')
                       for path in row['editable_paths'] for protected in row['protected_paths'])):
            raise ValueError('improvement policy exceeds planner authority')
        selected.append(ImprovementWorkspace(key=row['key'], project_scope=row['project_scope'],
            source_revision=row['source_revision'], isolation_ref=row['isolation_ref'],
            input_files=tuple(inputs), editable_paths=tuple(row['editable_paths']),
            protected_paths=tuple(row['protected_paths']), required_checks=tuple(row['required_checks']),
            forbidden_roots=forbidden))
        keys.add(row['key']); scopes.add(row['project_scope'])
    enabled = value['enabled']
    return ImprovementRuntimeConfig(tuple(selected), enabled=lambda: enabled)


def _service_execution_config(value, operational, parent_config, canonical, *, immutable_checks=False):
    """Pin explicit service configuration without connecting or starting it."""
    from .task_check_bridge import VerifiedServiceEndpoint, CheckServiceBridge
    from .task_check_service import load_operator_configuration, build_guard
    fields = {'socket_path', 'service_uid', 'cgroup_path', 'config_path',
              'configuration_sha256', 'entrypoint', 'python_path'}
    if type(value) is not dict or set(value) != fields:
        raise ValueError('exact check-service endpoint configuration required')
    endpoint = VerifiedServiceEndpoint.from_operator_configuration(**value)
    service, pin, sources = load_operator_configuration(endpoint.config_path,
                                                       endpoint.configuration_sha256)
    if (pin != dict(endpoint.config_pin) or sources != endpoint.source_manifest
            or service['socket_path'] != endpoint.socket_path
            or service['client_uid'] != os.geteuid()):
        raise ValueError('parent and service configuration identity differ')
    if immutable_checks and type(service.get('immutable_runtime')) is not dict:
        raise ValueError('improvement checks require an explicit pinned immutable runtime')
    source_root = str(Path(__file__).resolve().parents[2])
    required = (operational, parent_config, endpoint.config_path, source_root, *canonical)
    forbidden = service['forbidden_roots']
    if (type(forbidden) is not list or not forbidden
            or any(not any(os.path.commonpath((root, _absolute(blocked))) == blocked
                           for blocked in forbidden) for root in required)):
        raise ValueError('service configuration omits actual private or application roots')
    root = _absolute(service['root'])
    if any(os.path.commonpath((root, other)) in (root, other) for other in required):
        raise ValueError('service workspace overlaps private or application roots')
    for other in (str(Path(service['broker_path']).parent), str(Path(service['socket_path']).parent)):
        if any(os.path.commonpath((blocked, other)) in (blocked, other)
               for blocked in required):
            raise ValueError('service metadata overlaps private, canonical or application roots')
    # The factory computes canonical wrapper argv from the same pinned source
    # objects as the service. Its local availability is never execution proof.
    guard = build_guard(service)
    bridge = CheckServiceBridge(endpoint=endpoint, workspaces=(guard.workspace,))
    if immutable_checks:
        def bind_proof_boundary(authority, required, material):
            owned = CheckServiceBridge(endpoint=endpoint, workspaces=(guard.workspace,),
                proof_required=required, resolve_check_material=material)
            return ProofCheckBindings(owned.bind_handler(authority), owned.resolve_input_proof)
        return TaskExecutionConfig(operational, (guard.workspace,), bridge.authorize,
            bridge.validate_spec, proof_check_handler_factory=bind_proof_boundary)
    return TaskExecutionConfig(operational, (guard.workspace,), bridge.authorize,
        bridge.validate_spec, check_handler_factory=bridge.bind_handler)
