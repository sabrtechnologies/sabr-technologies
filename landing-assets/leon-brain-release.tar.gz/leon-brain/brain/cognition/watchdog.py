"""
Phase 13 — Watchdog.

Background monitor that watches Leon's own health. Read-only by default.
Emits dashboard events on degradation. Never restarts anything without
operator approval — that's the self_repair queue's job.

Checks (run on ~15s tick):

  service_alive       — `systemctl is-active leon` (best-effort)
  duplicate_brains    — pgrep for multiple `python3 run.py` instances
                        (known footgun: kill+nohup leaves two brains fighting
                        for VRAM)
  port_8000_listening — `ss -ltn` for the API port
  endpoint_up         — http://127.0.0.1:8000/health 2s probe
  brave_cdp           — 127.0.0.1:9222 probe
  actuator_socket     — checks brain.actuator_client.is_alive() if importable
  claude_session_warm — checks brain.claude_api_responder._LEON_SESSION
  resource_pressure   — load_avg_1m, mem_pct (from awareness if available)
  recent_journal      — systemd journal head, error-level only, last 5min
                        (only if journalctl available)
  cognition_loop      — alive + last_tick_age < 30s

Events emitted: each transition healthy→degraded or degraded→broken triggers
.emit("watchdog.degradation", {...}) via the optional emit_fn.

This module is intentionally cheap. Each check is wrapped, has its own
timeout, and is rate-limited so a stuck check can't block the loop.
"""

from __future__ import annotations

import logging
import os
import socket
import subprocess
import threading
import time
import urllib.request
from dataclasses import dataclass, asdict, field
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("leon.cognition.watchdog")


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""
    ts: float = 0.0
    duration_ms: float = 0.0


@dataclass
class WatchdogReport:
    ts: float
    overall: str               # "healthy" | "degraded" | "broken"
    checks: List[Check] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ts": self.ts,
            "overall": self.overall,
            "checks": [asdict(c) for c in self.checks],
        }


class Watchdog:
    """Background process-health monitor."""

    def __init__(
        self,
        *,
        interval_s: Optional[float] = None,
        api_port: int = 8000,
        emit_fn: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        awareness=None,
        tool_health=None,
        cognition_loop=None,
    ):
        if interval_s is None:
            interval_s = float(os.environ.get("LEON_WATCHDOG_TICK_S", "15.0"))
        self.interval_s = max(5.0, interval_s)
        self.api_port = api_port
        self.emit_fn = emit_fn
        self.awareness = awareness
        self.tool_health = tool_health
        self.cognition_loop = cognition_loop

        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_report: Optional[WatchdogReport] = None
        self._prev_overall: Optional[str] = None
        self._prev_check_states: Dict[str, bool] = {}

    # -- lifecycle -----------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="leon-watchdog", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t is not None:
            t.join(timeout=2.0)

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    # -- public --------------------------------------------------------

    def report(self) -> Optional[Dict[str, Any]]:
        return self._last_report.to_dict() if self._last_report else None

    def tick_now(self) -> WatchdogReport:
        rep = self._run_checks()
        self._publish(rep)
        return rep

    # -- loop ----------------------------------------------------------

    def _run(self) -> None:
        try:
            self._publish(self._run_checks())
        except Exception as e:
            log.warning("initial watchdog tick failed: %s", e)
        while not self._stop.is_set():
            self._stop.wait(self.interval_s)
            if self._stop.is_set():
                break
            try:
                self._publish(self._run_checks())
            except Exception as e:
                log.warning("watchdog tick failed: %s", e)

    def _publish(self, rep: WatchdogReport) -> None:
        # Diff vs previous → emit transitions
        if self.emit_fn is not None:
            try:
                # Per-check transitions
                for c in rep.checks:
                    prev = self._prev_check_states.get(c.name)
                    if prev is not None and prev != c.ok:
                        self.emit_fn("watchdog.transition", {
                            "check": c.name, "from": prev, "to": c.ok,
                            "detail": c.detail,
                        })
                    self._prev_check_states[c.name] = c.ok
                # Overall transition
                if self._prev_overall and self._prev_overall != rep.overall:
                    self.emit_fn("watchdog.overall_change", {
                        "from": self._prev_overall, "to": rep.overall,
                    })
            except Exception as e:
                log.warning("watchdog emit failed: %s", e)
        self._prev_overall = rep.overall
        self._last_report = rep

    # -- check runner --------------------------------------------------

    def _run_checks(self) -> WatchdogReport:
        now = time.time()
        checks: List[Check] = []
        checks.append(self._check("port_listening", self._check_port_listening))
        checks.append(self._check("endpoint_up", self._check_endpoint_up))
        checks.append(self._check("duplicate_brains", self._check_duplicate_brains))
        checks.append(self._check("brave_cdp", self._check_brave_cdp))
        checks.append(self._check("actuator_socket", self._check_actuator))
        checks.append(self._check("claude_session", self._check_claude_session))
        checks.append(self._check("cognition_loop", self._check_cognition_loop))
        checks.append(self._check("resource_pressure", self._check_resources))

        # Roll up
        broken_count = sum(1 for c in checks if not c.ok)
        critical_broken = any(
            (not c.ok) and c.name in ("port_listening", "endpoint_up")
            for c in checks
        )
        if critical_broken:
            overall = "broken"
        elif broken_count >= 3:
            overall = "broken"
        elif broken_count > 0:
            overall = "degraded"
        else:
            overall = "healthy"

        return WatchdogReport(ts=now, overall=overall, checks=checks)

    def _check(self, name: str, fn: Callable[[], Check]) -> Check:
        t0 = time.monotonic()
        try:
            c = fn()
        except Exception as e:
            c = Check(name=name, ok=False, detail=f"check raised: {e}")
        c.name = name  # ensure
        c.ts = time.time()
        c.duration_ms = round((time.monotonic() - t0) * 1000.0, 1)
        return c

    # -- individual checks --------------------------------------------

    def _check_port_listening(self) -> Check:
        # Cheap: try to connect — if the server is up, this succeeds
        try:
            with socket.create_connection(("127.0.0.1", self.api_port), timeout=0.6):
                return Check("port_listening", True, f"127.0.0.1:{self.api_port}")
        except Exception as e:
            return Check("port_listening", False, str(e))

    def _check_endpoint_up(self) -> Check:
        """Probe /api/state via HTTP. Generous timeout — this runs INSIDE
        the same uvicorn process, so a single tick can be slow if the
        event loop is busy handling a Claude call. Only mark FAIL after
        N consecutive failures so transient loop pressure doesn't trip it."""
        try:
            import os
            _hdrs = {}
            _tok = os.environ.get("LEON_API_KEY", "")
            if _tok:
                _hdrs["Authorization"] = f"Bearer {_tok}"
            req = urllib.request.Request(
                f"http://127.0.0.1:{self.api_port}/api/state",
                method="GET",
                headers=_hdrs,
            )
            with urllib.request.urlopen(req, timeout=10.0) as resp:
                ok = 200 <= resp.status < 400
                if ok:
                    self._endpoint_consec_fail = 0
                return Check("endpoint_up", ok, f"http {resp.status}")
        except Exception as e:
            # Tolerate momentary blockage — need 3 consecutive misses
            # before reporting fail. Matches how real uptime monitors behave.
            n = getattr(self, "_endpoint_consec_fail", 0) + 1
            self._endpoint_consec_fail = n
            if n < 3:
                return Check("endpoint_up", True,
                             f"transient: {str(e)[:80]} (miss {n}/3)")
            return Check("endpoint_up", False,
                         f"{str(e)[:80]} ({n} consecutive)")

    def _check_duplicate_brains(self) -> Check:
        try:
            r = subprocess.run(
                ["pgrep", "-fa", "run.py"],
                capture_output=True, text=True, timeout=1.0,
            )
            lines = [ln for ln in r.stdout.splitlines()
                     if "run.py" in ln and "grep" not in ln]
            # We expect ONE run.py — ours.
            n = len(lines)
            ok = n <= 1
            return Check("duplicate_brains", ok,
                         f"{n} run.py instance(s)" + (
                             "" if ok else " — kill duplicates"
                         ))
        except Exception as e:
            return Check("duplicate_brains", True, f"probe skipped: {e}")

    def _check_brave_cdp(self) -> Check:
        try:
            with socket.create_connection(("127.0.0.1", 9222), timeout=0.5):
                return Check("brave_cdp", True, "9222 open")
        except Exception as e:
            return Check("brave_cdp", False, f"closed: {e}")

    def _check_actuator(self) -> Check:
        try:
            from brain import actuator_client
            alive_fn = getattr(actuator_client, "is_alive", None)
            if alive_fn is None:
                return Check("actuator_socket", True, "no is_alive() probe")
            ok = bool(alive_fn())
            return Check("actuator_socket", ok,
                         "alive" if ok else "socket dead")
        except Exception as e:
            return Check("actuator_socket", False, str(e)[:120])

    def _check_claude_session(self) -> Check:
        try:
            from brain import claude_api_responder as r
            sess = getattr(r, "_LEON_SESSION", None)
            if sess is None:
                return Check("claude_session", True, "session not started yet")
            alive = bool(getattr(sess, "alive", lambda: False)())
            return Check("claude_session", alive,
                         "warm" if alive else "cold/dead")
        except Exception as e:
            return Check("claude_session", True, f"probe skipped: {e}")

    def _check_cognition_loop(self) -> Check:
        if self.cognition_loop is None:
            return Check("cognition_loop", True, "no loop handle")
        try:
            status = self.cognition_loop.status()
            running = bool(status.get("running"))
            ticks = int(status.get("tick_count") or 0)
            # We track tick deltas across watchdog calls; if running but
            # ticks haven't advanced in two watchdog cycles, the loop is wedged.
            prev = getattr(self, "_last_loop_tick_count", None)
            self._last_loop_tick_count = ticks
            if not running:
                return Check("cognition_loop", False, "loop not running")
            if prev is not None and ticks == prev and ticks > 0:
                return Check("cognition_loop", False,
                             f"wedged — tick_count stuck at {ticks}")
            interval = status.get("interval_s") or 0
            return Check("cognition_loop", True,
                         f"running ticks={ticks} interval={interval}s")
        except Exception as e:
            return Check("cognition_loop", True, f"probe skipped: {e}")

    def _check_resources(self) -> Check:
        load = None
        mem = None
        try:
            with open("/proc/loadavg") as f:
                load = float(f.read().split()[0])
        except Exception:
            pass
        if self.awareness is not None:
            try:
                snap = self.awareness.snapshot_dict() or {}
                if snap.get("load_avg_1m") is not None:
                    load = snap["load_avg_1m"]
                if snap.get("mem_pct") is not None:
                    mem = snap["mem_pct"]
            except Exception:
                pass
        # Heuristic thresholds
        bad = (load is not None and load > 12.0) or (mem is not None and mem > 95.0)
        detail = []
        if load is not None:
            detail.append(f"load={load:.2f}")
        if mem is not None:
            detail.append(f"mem={mem:.1f}%")
        return Check("resource_pressure", not bad,
                     " ".join(detail) if detail else "no signal")


__all__ = ["Watchdog", "WatchdogReport", "Check"]
