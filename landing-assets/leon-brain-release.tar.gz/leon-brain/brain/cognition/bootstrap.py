"""
Cognition bootstrap — wires the cognition layer into the existing brain.

One public function: install(brain, *, server=None, proactive=None) → Cognition

What install() does:
  1. Constructs EpisodeStore, WorldModel, SNNGates, DriveSystem, Rollout,
     CognitionLoop with sensible defaults.
  2. Wraps brain.actuator_client.call so every actuator-routed tool dispatch
     writes a closed episode automatically. (Idempotent — re-installing is a
     no-op.)
  3. Wraps brain_api_responder.local_tools so in-process tool calls also
     write episodes. Optional — only happens if `server.brain_api_responder`
     exposes a local_tools dict.
  4. Exposes the whole thing as `server.cognition` for API endpoints / WS.
  5. Starts the cognition loop in SHADOW mode (no autonomous actions).

What install() does NOT do:
  - Doesn't change any responder logic.
  - Doesn't change any tool behavior.
  - Doesn't touch the brain simulation loop.

Toggle behavior at runtime:
  cognition.loop.set_mode("active")   # enable autonomous actions
  cognition.loop.set_mode("shadow")   # observational only
  cognition.loop.set_mode("paused")   # halt drives + autonomous actions

Env flags read at install time:
  LEON_COGNITION=off       → install returns None, no wrapping
  LEON_COGNITION_MODE=...  → starting mode (default 'shadow')
  LEON_COGNITION_TICK_S=2  → loop tick interval
"""

from __future__ import annotations

import functools
import logging
import os
import time
from types import SimpleNamespace
from typing import Any, Optional

from brain.cognition.episodes import EpisodeStore
from brain.cognition.world_model import WorldModel
from brain.cognition.snn_gating import SNNGates
from brain.cognition.drives import DriveSystem
from brain.cognition.rollout import Rollout
from brain.cognition.loop import CognitionLoop
# Phase 2 — persistent identity layer
from brain.cognition.graph import GraphMemory
from brain.cognition.self_model import SelfModel
from brain.cognition.consolidation import CognitionConsolidator
# Phase 3 — hierarchical control + cognition-aware prompts
from brain.cognition.hierarchy import HierarchyRouter
from brain.cognition.prompt_builder import CognitionPromptBuilder
# Phase 11C — active mode safety
from brain.cognition.active_mode_safety import ActiveModeSafety, classify_tier, is_state_changing
# Self-model bridge — unifies SNN + cognition self-models
from brain.cognition.self_model_bridge import SelfModelBridge

log = logging.getLogger("leon.cognition.bootstrap")


# Sentinel attribute name used to mark wrapped functions so repeat installs
# don't stack wrappers.
_WRAPPED_MARKER = "_cognition_wrapped"


def _wrap_actuator_call(cognition: SimpleNamespace) -> None:
    """Monkey-patch brain.actuator_client.call so every socket-routed tool
    dispatch logs an episode.

    Idempotent: checks _WRAPPED_MARKER before patching.
    """
    try:
        from brain import actuator_client
    except Exception as e:
        log.warning("could not import actuator_client to wrap: %s", e)
        return

    if getattr(actuator_client.call, _WRAPPED_MARKER, False):
        log.info("actuator_client.call already wrapped — skipping")
        return

    original_call = actuator_client.call

    @functools.wraps(original_call)
    def wrapped(tool: str, args=None, timeout: float = 15.0):
        args = args or {}
        t0 = time.monotonic()
        result = None
        error_text: Optional[str] = None
        try:
            result = original_call(tool, args, timeout)
            return result
        except Exception as e:
            error_text = str(e)
            raise
        finally:
            latency_ms = (time.monotonic() - t0) * 1000.0
            try:
                # Use dotted tool name; record_tool_call infers success from result shape.
                cognition.loop.record_tool_call(
                    tool, args, result, latency_ms,
                    kind="tool", error=error_text,
                )
            except Exception as e:
                log.warning("cognition record_tool_call failed for %s: %s", tool, e)

    setattr(wrapped, _WRAPPED_MARKER, True)
    actuator_client.call = wrapped
    log.info("wrapped brain.actuator_client.call for episode logging")


def _wrap_local_tools(cognition: SimpleNamespace, responder: Any) -> None:
    """Wrap each callable in responder.local_tools so in-process tool calls
    also log episodes. Skips already-wrapped entries.

    The responder.local_tools dict is populated incrementally during
    init_brain(); we wrap whatever is present at install time AND install
    a setdefault interceptor so later additions are auto-wrapped.
    """
    if responder is None:
        log.info("no responder provided — skipping local_tools wrap")
        return
    local_tools = getattr(responder, "local_tools", None)
    if not isinstance(local_tools, dict):
        log.info("responder.local_tools not a dict — skipping wrap")
        return

    def _make_wrapper(name: str, fn):
        if getattr(fn, _WRAPPED_MARKER, False):
            return fn

        @functools.wraps(fn)
        def wrapped(args):
            t0 = time.monotonic()
            result = None
            error_text: Optional[str] = None
            try:
                result = fn(args)
                return result
            except Exception as e:
                error_text = str(e)
                raise
            finally:
                latency_ms = (time.monotonic() - t0) * 1000.0
                try:
                    cognition.loop.record_tool_call(
                        name, args if isinstance(args, dict) else {}, result,
                        latency_ms, kind="tool", error=error_text,
                    )
                except Exception as e:
                    log.warning("cognition record_tool_call failed for %s: %s",
                                name, e)

        setattr(wrapped, _WRAPPED_MARKER, True)
        return wrapped

    wrapped_count = 0
    for name, fn in list(local_tools.items()):
        if callable(fn) and not getattr(fn, _WRAPPED_MARKER, False):
            local_tools[name] = _make_wrapper(name, fn)
            wrapped_count += 1
    log.info("wrapped %d local_tools for episode logging", wrapped_count)

    # Install an interceptor so later additions are wrapped automatically.
    # We replace the dict with a subclass that wraps on __setitem__.
    #
    # IMPORTANT: if the existing dict has __missing__ (e.g. _LazyToolDict in
    # server/init_brain.py — the lazy-import wrapper for 1,000+ integration
    # tools), we must preserve that behavior. dict.__init__(initial) copies
    # only the currently-loaded keys; it does NOT carry __missing__ semantics.
    # Without delegating, every lazy-loadable tool (cal_*, email_*, finance_*,
    # smart_home_*, …) becomes permanently unreachable from this point on.
    # Observed 2026-06-09 audit-log flood: "unknown tool: cal_next_event"
    # etc. on every routine tick.
    if not isinstance(local_tools, _AutoWrapDict):
        # Capture the pre-wrap dict so __missing__ can delegate the lazy load.
        # Only meaningful when the source has __missing__ logic of its own.
        # NB: base `dict` has NO `__missing__` attribute, so `dict.__missing__`
        # raised AttributeError and crashed the ENTIRE cognition install
        # (state.cognition=None, active inference + self-model dashboard all
        # silently off — found 2026-06-13). Probe via getattr instead: the
        # base-dict sentinel is None, so "defines its own __missing__" is
        # simply "the attribute is present".
        _src_missing = getattr(type(local_tools), "__missing__", None)
        fallback = local_tools if _src_missing is not None else None
        new_dict = _AutoWrapDict(local_tools, _make_wrapper, fallback=fallback)
        responder.local_tools = new_dict


class _AutoWrapDict(dict):
    """Dict that wraps callable values on insert.

    M3 fix: override `update` AND `setdefault` in addition to `__setitem__`.
    Without these, future code using `local_tools.update({...})` or
    `local_tools.setdefault(name, fn)` would bypass the wrapper and silently
    leave holes in episode logging.
    """

    def __init__(self, initial: dict, wrapper_factory, fallback: Optional[dict] = None):
        super().__init__(initial)
        self._wrapper_factory = wrapper_factory
        # When the source dict has __missing__ (lazy-load) semantics, keep a
        # reference so we can delegate misses to it. dict.__init__ wouldn't
        # carry that behavior otherwise.
        self._fallback = fallback

    def _wrap_if_needed(self, key, value):
        if callable(value) and not getattr(value, _WRAPPED_MARKER, False):
            return self._wrapper_factory(key, value)
        return value

    def __setitem__(self, key, value):
        super().__setitem__(key, self._wrap_if_needed(key, value))

    def __missing__(self, key):
        # Delegate to the captured _LazyToolDict (or any other dict subclass
        # with __missing__) so e.g. cal_next_event triggers the integration
        # module import on first access. Mirror the loaded function into self
        # — wrapped via __setitem__ — so subsequent calls hit the fast path.
        if self._fallback is None:
            raise KeyError(key)
        fn = self._fallback[key]   # raises KeyError if truly absent
        self[key] = fn             # routes through __setitem__ → wraps once
        return self[key]

    def update(self, *args, **kwargs):
        # dict.update accepts a positional mapping/iterable + kwargs.
        if args:
            other = args[0]
            if hasattr(other, "items"):
                for k, v in other.items():
                    super().__setitem__(k, self._wrap_if_needed(k, v))
            else:
                for k, v in other:
                    super().__setitem__(k, self._wrap_if_needed(k, v))
        for k, v in kwargs.items():
            super().__setitem__(k, self._wrap_if_needed(k, v))

    def setdefault(self, key, default=None):
        if key in self:
            return self[key]
        wrapped = self._wrap_if_needed(key, default)
        super().__setitem__(key, wrapped)
        return wrapped


def _wrap_episode_close(episodes: EpisodeStore, graph, self_model) -> None:
    """Wrap EpisodeStore.close so each closed episode also updates the
    Phase 2 graph + self_model. Idempotent."""
    if graph is None and self_model is None:
        return
    if getattr(episodes.close, _WRAPPED_MARKER, False):
        return

    original_close = episodes.close

    @functools.wraps(original_close)
    def wrapped_close(ep_id, *args, **kwargs):
        closed = original_close(ep_id, *args, **kwargs)
        if closed is None:
            return closed
        # Build a dict view matching what we'd get from .recent() rows
        row = {
            "id": closed.id,
            "ts": closed.ts,
            "session_id": closed.session_id,
            "action_kind": closed.action_kind,
            "action_name": closed.action_name,
            "action_args_json": __import__("json").dumps(closed.action_args, default=str)[:8000],
            "arg_signature": closed.arg_signature,
            "active_app": closed.context.active_app if closed.context else None,
            "bucket": closed.context.bucket if closed.context else "",
            "hour_of_day": closed.context.hour if closed.context else 0,
            "day_of_week": closed.context.dow if closed.context else 0,
            "salience": closed.salience,
            "success": 1 if closed.success else 0,
            "reward": closed.reward,
            "surprise": closed.surprise,
            "latency_ms": closed.latency_ms,
            "nm_dopamine": closed.context.nm.get("dopamine") if closed.context else None,
            "nm_acetylcholine": closed.context.nm.get("acetylcholine") if closed.context else None,
            "nm_norepinephrine": closed.context.nm.get("norepinephrine") if closed.context else None,
            "nm_serotonin": closed.context.nm.get("serotonin") if closed.context else None,
        }
        if graph is not None:
            try:
                graph.record_episode(row)
            except Exception as e:
                log.warning("graph.record_episode failed: %s", e)
        if self_model is not None:
            try:
                self_model.update_from_episode(row)
            except Exception as e:
                log.warning("self_model.update_from_episode failed: %s", e)
        return closed

    setattr(wrapped_close, _WRAPPED_MARKER, True)
    episodes.close = wrapped_close
    log.info("wrapped EpisodeStore.close for Phase 2 graph + self_model updates")


def install(
    brain,
    *,
    server: Any = None,
    proactive=None,
) -> Optional[SimpleNamespace]:
    """Wire the cognition layer into a running Brain.

    Returns a SimpleNamespace bundle with .episodes / .world_model / .gates /
    .drives / .rollout / .loop, or None if disabled by env.

    Re-installation is safe — wrappers carry a marker so they aren't stacked.
    """
    if os.environ.get("LEON_COGNITION", "on").lower() in ("off", "0", "false"):
        log.info("LEON_COGNITION=off — cognition layer disabled")
        return None

    db_path = os.environ.get("LEON_COGNITION_DB") or None
    mode = os.environ.get("LEON_COGNITION_MODE", "shadow")
    interval_s = float(os.environ.get("LEON_COGNITION_TICK_S", "2.0"))

    log.info("installing cognition layer (mode=%s, tick=%.1fs)", mode, interval_s)

    episodes = EpisodeStore(path=db_path)
    world_model = WorldModel(episodes)
    gates = SNNGates(brain)
    drives = DriveSystem()
    rollout = Rollout(world_model, drives, gates)

    # Best-effort active-app detection: try the actuator's window.list
    def _active_app():
        try:
            from brain import actuator_client
            # bypass our own wrapper to avoid recursion if active mode fires
            raw = getattr(actuator_client.call, "__wrapped__", actuator_client.call)
            r = raw("window.list", {}, 1.0)
            wins = (r or {}).get("windows") or []
            for w in wins:
                if w.get("active"):
                    return w.get("class") or w.get("title", "")[:32]
        except Exception:
            return None
        return None

    # User presence from brain.presence if available
    def _user_present():
        try:
            from brain import presence
            return bool(getattr(presence, "is_present", lambda: True)())
        except Exception:
            return True

    # Phase 11C — instantiate the safety guard EARLY so _fire_autonomous can use it.
    safety = ActiveModeSafety()

    # Phase 7+11C — active-mode action firing with multi-layer safety guard.
    # Layered defense:
    #   1. CognitionLoop._is_safe_for_active (whitelist floor, Phase 7)
    #   2. ActiveModeSafety.check (kill switch + tier + rate limit + budget + cooldown, Phase 11C)
    # If either rejects, the candidate is BLOCKED and audit-logged.
    def _fire_autonomous(candidate):
        """Execute an autonomous candidate. Multi-layer safety must approve."""
        from brain.cognition.loop import CognitionLoop as _CL

        # Layer 1 — hard whitelist (Phase 7)
        if not _CL._is_safe_for_active(candidate.name):
            return {"ok": False, "error": "blocked by safety whitelist",
                    "tool": candidate.name, "block_layer": "whitelist"}

        # Layer 2 — full safety check (Phase 11C)
        # Pull NM snapshot for audit
        try:
            nm = getattr(brain, "neuromodulators", {}) or {}
        except Exception:
            nm = {}
        # State-changing actions need an undo_note. For autonomous firing we
        # synthesize a default note (the action_args + timestamp form the trail).
        undo_note = None
        if is_state_changing(candidate.name):
            undo_note = (
                f"autonomous fire of {candidate.name} at ts={time.time():.0f}; "
                f"args_keys={list((candidate.args or {}).keys())}"
            )
        decision = safety.check(
            candidate.name, candidate.args or {},
            undo_note=undo_note,
            source=getattr(candidate, "source", "loop"),
            nm_snapshot={k: round(v, 3) for k, v in nm.items()},
        )
        if not decision.allowed:
            return {"ok": False, "error": decision.reason,
                    "tool": candidate.name,
                    "block_layer": decision.block_layer,
                    "tier": decision.tier,
                    "audit_id": decision.audit_id}

        # All gates passed — fire through actuator
        try:
            from brain import actuator_client
            args = dict(candidate.args or {})
            args["__autonomous"] = True
            args["__audit_id"] = decision.audit_id
            result = actuator_client.call(candidate.name, args, timeout=5.0)
            # Tell safety the outcome for cooldown bookkeeping
            success = bool(isinstance(result, dict) and result.get("ok") is not False)
            safety.mark_outcome(candidate.name, success=success,
                                 error=(result or {}).get("error") if isinstance(result, dict) else None)
            return result
        except Exception as e:
            safety.mark_outcome(candidate.name, success=False, error=str(e))
            return {"ok": False, "error": f"actuator call failed: {e}",
                    "tool": candidate.name}

    loop = CognitionLoop(
        brain=brain,
        episodes=episodes,
        world_model=world_model,
        gates=gates,
        drives=drives,
        rollout=rollout,
        interval_s=interval_s,
        active_app_fn=_active_app,
        user_present_fn=_user_present,
        # Phase 7 — autonomous firing wired (still inert in shadow mode)
        active_action_fn=_fire_autonomous,
        # Phase 3 — pull-through providers (set below after Phase 2 init)
        consolidator=None,
        graph=None,
    )
    loop.set_mode(mode)

    # ── Phase 2 — persistent identity layer ─────────────────────────────
    # Built BEFORE the wrap so the close-hook below can reference them.
    graph_db = os.environ.get("LEON_COGNITION_GRAPH_DB") or None
    knowledge_db = os.environ.get("LEON_COGNITION_KNOWLEDGE_DB") or None
    self_model_path = os.environ.get("LEON_COGNITION_SELFMODEL") or None
    do_backfill = os.environ.get("LEON_COGNITION_BACKFILL", "1").lower() not in ("0", "off", "false")
    try:
        graph = GraphMemory(episodes, db_path=graph_db,
                             knowledge_db_path=knowledge_db)
        if do_backfill:
            bf_report = graph.backfill_from_knowledge(max_rows=2000)
            log.info("graph backfill: %s", bf_report)
    except Exception as e:
        log.warning("Phase 2 graph init failed: %s", e)
        graph = None
    try:
        self_model = SelfModel(brain=brain, path=self_model_path)
    except Exception as e:
        log.warning("Phase 2 self_model init failed: %s", e)
        self_model = None
    consolidator = None
    if graph is not None and self_model is not None:
        try:
            # The SleepConsolidator handle is on the server module — try
            # to grab it for the sleep-hook install.
            sleep = getattr(server, "sleep_consolidator", None) if server else None
            consolidator = CognitionConsolidator(
                episodes=episodes, graph=graph, self_model=self_model,
                world_model=world_model, drives=drives,
                sleep_consolidator=sleep,
            )
            if sleep is not None:
                consolidator.install_sleep_hook()
        except Exception as e:
            log.warning("Phase 2 consolidator init failed: %s", e)

    # ── Phase 3 — hierarchical control + cognition-aware prompts ─────────
    hierarchy = HierarchyRouter(
        gates=gates, drives=drives, world_model=world_model,
        graph=graph, self_model=self_model,
    )
    prompt_builder = CognitionPromptBuilder(
        self_model=self_model, drives=drives, gates=gates,
        graph=graph, world_model=world_model, episodes=episodes,
        # verifier attached below after Phase 12A init
    )

    # Now that Phase 2 components exist, give the loop pull-through access
    # so active-mode candidate generation can pull from consolidator + graph.
    loop._consolidator = consolidator
    loop._graph = graph

    # ── Phase 12A — hypothesis corroboration ─────────────────────────────
    try:
        from brain.cognition.hypothesis_verify import HypothesisVerifier
        verifier = HypothesisVerifier(episodes=episodes)
    except Exception as e:
        log.warning("Phase 12A verifier init failed: %s", e)
        verifier = None

    # ── Self-Model Bridge — unify SNN + cognition self-models ──────────
    snn_self_model = getattr(brain, 'self_model', None)
    try:
        self_model_bridge = SelfModelBridge(
            snn_self_model=snn_self_model,
            cognition_self_model=self_model,
            brain=brain,
        ) if snn_self_model is not None and self_model is not None else None
    except Exception as e:
        log.warning("SelfModelBridge init failed: %s", e)
        self_model_bridge = None

    bundle = SimpleNamespace(
        episodes=episodes,
        world_model=world_model,
        gates=gates,
        drives=drives,
        rollout=rollout,
        loop=loop,
        # Phase 2
        graph=graph,
        self_model=self_model,
        consolidator=consolidator,
        # Phase 3
        hierarchy=hierarchy,
        prompt_builder=prompt_builder,
        # Phase 11C
        safety=safety,
        # Phase 12A
        verifier=verifier,
        # Self-model bridge
        self_model_bridge=self_model_bridge,
    )

    # Hand the verifier to the consolidator so consolidate_pass can run it.
    if consolidator is not None and verifier is not None:
        try:
            consolidator.verifier = verifier
        except Exception as e:
            log.warning("consolidator.verifier wire failed: %s", e)
    # Attach verifier to prompt_builder so corroborated rules show up in the
    # cognition addendum.
    if verifier is not None:
        try:
            prompt_builder.verifier = verifier
        except Exception as e:
            log.warning("prompt_builder.verifier wire failed: %s", e)

    # ── Phase 12B — auto-promote gate ───────────────────────────────────
    try:
        from brain.cognition.auto_promote import AutoPromoter
        bundle.promoter = AutoPromoter(cognition_bundle=bundle)
    except Exception as e:
        log.warning("Phase 12B promoter init failed: %s", e)
        bundle.promoter = None

    # ── Hook EpisodeStore.close so every closed episode feeds Phase 2 ──
    # We wrap once at install time. The wrapper is small + try/excepts every
    # update so failures in graph/self_model NEVER break tool dispatch.
    _wrap_episode_close(episodes, graph, self_model)

    # Wrap the actuator chokepoint
    _wrap_actuator_call(bundle)

    # Wrap in-process tools on the API responder (if provided)
    if server is not None:
        responder = getattr(server, "brain_api_responder", None)
        _wrap_local_tools(bundle, responder)

    # ── Phase 13 — persistent cognitive OS layer ────────────────────────
    # Opt-in via LEON_PHASE13=on (default off). All components are shadow
    # mode by default and never block the existing responder path.
    _install_phase13(brain, bundle, server)

    if server is not None:
        # Expose for endpoints / WS (AFTER phase 13 attaches its handles)
        try:
            setattr(server, "cognition", bundle)
        except Exception:
            log.warning("could not attach cognition to server module")

    # Start loop thread
    loop.start()
    log.info("cognition layer installed")
    return bundle


# ── Phase 13 installer ──────────────────────────────────────────────────


def _install_phase13(brain, bundle, server) -> None:
    """Wire Phase 13 components onto the cognition bundle.

    Each component is built behind try/except so a single failure can't
    take down the whole cognition layer.
    """
    enabled = os.environ.get("LEON_PHASE13", "on").lower() not in ("off", "0", "false")
    if not enabled:
        log.info("LEON_PHASE13=off — skipping phase 13 install")
        return

    # 1) Tool immune system + self-repair (foundational)
    try:
        from brain.cognition.tool_health import ToolHealth
        bundle.tool_health = ToolHealth()
        log.info("phase 13: tool_health initialized at %s", bundle.tool_health.path)
    except Exception as e:
        log.warning("phase 13: tool_health init failed: %s", e)
        bundle.tool_health = None

    try:
        from brain.cognition.self_repair import SelfRepair
        # Phase 15 — self_repair will get the executive handle later (after
        # ExecutiveController is constructed) so simulate() can pre-flight repairs.
        bundle.self_repair = SelfRepair()
    except Exception as e:
        log.warning("phase 13: self_repair init failed: %s", e)
        bundle.self_repair = None

    # Wrap EpisodeStore.close one more time so closed episodes also feed
    # tool_health + self_repair. This is additive: the prior wrapper still
    # runs (graph/self_model) — we just chain a new finalizer.
    if bundle.tool_health is not None:
        try:
            _chain_episode_close_for_tool_health(
                bundle.episodes, bundle.tool_health, bundle.self_repair,
            )
        except Exception as e:
            log.warning("phase 13: episode close chain failed: %s", e)

    # 2) Awareness loop
    try:
        from brain.cognition.awareness import AwarenessLoop
        bundle.awareness = AwarenessLoop()
        bundle.awareness.start()
        log.info("phase 13: awareness loop started")
    except Exception as e:
        log.warning("phase 13: awareness init failed: %s", e)
        bundle.awareness = None

    # 3) Lessons + skills (persistent stores)
    try:
        from brain.cognition.lessons import LessonStore
        bundle.lessons = LessonStore()
    except Exception as e:
        log.warning("phase 13: lessons init failed: %s", e)
        bundle.lessons = None

    try:
        from brain.cognition.skills import SkillMemory
        bundle.skills = SkillMemory(episodes=bundle.episodes)
    except Exception as e:
        log.warning("phase 13: skills init failed: %s", e)
        bundle.skills = None

    # 4) Reflex layer
    try:
        from brain.cognition.reflex import ReflexLayer
        bundle.reflex = ReflexLayer(
            brain=brain,
            awareness=bundle.awareness,
            tool_health=bundle.tool_health,
            drives=bundle.drives,
            gates=bundle.gates,
        )
    except Exception as e:
        log.warning("phase 13: reflex init failed: %s", e)
        bundle.reflex = None

    # 5) Tool classifier (Phase 14) — built BEFORE the executive so it
    # can pass the classifier in as a tools_to_consider source.
    try:
        from brain.cognition.tool_classifier import ToolClassifier
        # Build a registry provider that returns known tools from
        # actuator_client.TOOL_RISK (the full statically-declared surface).
        def _registry_provider():
            try:
                from brain.actuator_client import TOOL_RISK
                return list(TOOL_RISK.keys()) if isinstance(TOOL_RISK, dict) else []
            except Exception:
                return []
        bundle.tool_classifier = ToolClassifier(
            episodes=bundle.episodes,
            tool_health=bundle.tool_health,
            registry_provider=_registry_provider,
        )
    except Exception as e:
        log.warning("phase 14: tool_classifier init failed: %s", e)
        bundle.tool_classifier = None

    # Executive — needs canned/command matchers from the responder
    try:
        canned_fn = None
        cmd_fn = None
        try:
            from brain import claude_api_responder as r
            canned_fn = getattr(r, "_maybe_canned_reply", None)
            cmd_fn = getattr(r, "_maybe_command_action", None)
        except Exception:
            pass
        from brain.cognition.executive import ExecutiveController
        bundle.executive = ExecutiveController(
            hierarchy=getattr(bundle, "hierarchy", None),
            gates=bundle.gates,
            drives=bundle.drives,
            awareness=bundle.awareness,
            tool_health=bundle.tool_health,
            lessons=bundle.lessons,
            skills=bundle.skills,
            reflex=bundle.reflex,
            canned_match_fn=canned_fn,
            command_match_fn=cmd_fn,
            prompt_builder=getattr(bundle, "prompt_builder", None),
            # Phase 14
            world_model=getattr(bundle, "world_model", None),
            tool_classifier=getattr(bundle, "tool_classifier", None),
        )
    except Exception as e:
        log.warning("phase 13: executive init failed: %s", e)
        bundle.executive = None

    # 6) Hook lessons + awareness + skills + tool_health onto the existing
    # prompt_builder so dynamic prompt sections work.
    pb = getattr(bundle, "prompt_builder", None)
    if pb is not None:
        if bundle.lessons is not None and pb.lessons is None:
            pb.lessons = bundle.lessons
        if bundle.awareness is not None and pb.awareness is None:
            pb.awareness = bundle.awareness
        if bundle.skills is not None and pb.skills is None:
            pb.skills = bundle.skills
        if bundle.tool_health is not None and pb.tool_health is None:
            pb.tool_health = bundle.tool_health

    # 7) Watchdog — needs an emit_fn that the server module owns.
    # server._broadcast_event takes a single dict (goes to all WS clients).
    # We adapt our (channel, payload) signature to that shape.
    emit_fn = None
    if server is not None:
        raw_broadcast = getattr(server, "_broadcast_event", None)
        if callable(raw_broadcast):
            def emit_fn(channel, payload, _bcast=raw_broadcast):
                try:
                    msg = {"type": channel, "ts": time.time(),
                            "payload": payload}
                    _bcast(msg)
                except Exception as e:
                    log.warning("phase13 emit adapter failed: %s", e)
    try:
        from brain.cognition.watchdog import Watchdog
        bundle.watchdog = Watchdog(
            emit_fn=emit_fn,
            awareness=bundle.awareness,
            tool_health=bundle.tool_health,
            cognition_loop=bundle.loop,
        )
        bundle.watchdog.start()
        log.info("phase 13: watchdog started")
    except Exception as e:
        log.warning("phase 13: watchdog init failed: %s", e)
        bundle.watchdog = None

    # 8) Safe tool probes
    try:
        from brain.cognition.tool_probes import ProbeRunner
        bundle.probes = ProbeRunner(
            tool_health=bundle.tool_health, brain=brain,
        )
        bundle.probes.start()
        log.info("phase 13: tool probes started (%d probes)",
                  len(bundle.probes.list_probes()))
    except Exception as e:
        log.warning("phase 13: tool_probes init failed: %s", e)
        bundle.probes = None

    # 9) Suggestions
    try:
        from brain.cognition.suggestions import Suggestions
        bundle.suggestions = Suggestions(
            emit_fn=emit_fn,
            tool_health=bundle.tool_health,
            watchdog=bundle.watchdog,
            awareness=bundle.awareness,
            lessons=bundle.lessons,
            drives=bundle.drives,
            self_repair=bundle.self_repair,
        )
        bundle.suggestions.start()
        log.info("phase 13: suggestions started")
    except Exception as e:
        log.warning("phase 13: suggestions init failed: %s", e)
        bundle.suggestions = None

    # 10) Reflection (Phase 14, extended Phase 15) — periodic self-observation
    # + workflow detection + proposal queue + ops metrics
    try:
        from brain.cognition.reflection import Reflection
        bundle.reflection = Reflection(
            episodes=bundle.episodes,
            tool_health=bundle.tool_health,
            executive=bundle.executive,
            skills=bundle.skills,
            lessons=bundle.lessons,
            suggestions=bundle.suggestions,
            tool_classifier=getattr(bundle, "tool_classifier", None),  # Phase 15
        )
        bundle.reflection.start()
        log.info("phase 14: reflection started")
    except Exception as e:
        log.warning("phase 14: reflection init failed: %s", e)
        bundle.reflection = None

    # 11) Phase 15 — provider registry
    try:
        from brain.cognition.providers import ProviderRegistry
        bundle.providers = ProviderRegistry()
        log.info("phase 15: provider registry initialized "
                  "(fallback_enabled=%s)", bundle.providers.fallback_enabled())
    except Exception as e:
        log.warning("phase 15: provider registry init failed: %s", e)
        bundle.providers = None

    # 12) Phase 15 — back-wire executive into self_repair so simulate()
    # can pre-flight repairs.
    if getattr(bundle, "self_repair", None) is not None \
            and getattr(bundle, "executive", None) is not None:
        try:
            bundle.self_repair.executive = bundle.executive
            log.info("phase 15: self_repair ↔ executive wired for simulate gating")
        except Exception as e:
            log.warning("phase 15: self_repair executive wiring failed: %s", e)

    log.info("phase 13/14/15: install complete")


def _chain_episode_close_for_tool_health(episodes, tool_health, self_repair) -> None:
    """Additive wrapper on EpisodeStore.close — feeds tool_health and
    files self-repair proposals on failures.

    The Phase 2 wrapper (graph + self_model) already exists. We chain
    AFTER it by re-wrapping with our own marker so we don't double-wrap.
    """
    marker = "_phase13_tool_health_wrapped"
    if getattr(episodes.close, marker, False):
        return
    original_close = episodes.close
    import functools

    @functools.wraps(original_close)
    def wrapped(ep_id, *args, **kwargs):
        closed = original_close(ep_id, *args, **kwargs)
        if closed is None:
            return closed
        # Only meaningful for 'tool' kind actions
        try:
            if closed.action_kind == "tool":
                tname = closed.action_name or "<unknown>"
                lat = float(closed.latency_ms or 0.0)
                ok = bool(closed.success)
                err = getattr(closed, "error", "") or ""
                tool_health.observe(
                    tname, success=ok, latency_ms=lat,
                    exception_text=(None if ok else err),
                )
                if (not ok) and self_repair is not None:
                    try:
                        self_repair.on_failure(
                            tname, exception_text=err,
                            latency_ms=lat, auto_apply=True,
                        )
                    except Exception as e:
                        log.warning("self_repair.on_failure failed: %s", e)
        except Exception as e:
            log.warning("phase13 close-chain failed: %s", e)
        return closed

    setattr(wrapped, marker, True)
    episodes.close = wrapped
