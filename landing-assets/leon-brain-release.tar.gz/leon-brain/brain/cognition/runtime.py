"""
CognitiveRuntime — Leon V2 Phase 2 (SHADOW only).

The single consumer of the cognitive event bus (runbook 6.3). One daemon
thread, ``cognitive-runtime``, takes events off the bus in priority order and
asks the *existing* ExecutiveController what it would do with each one, via
``executive.plan_event(event, dry_run=True)``. The decision is recorded
(in-memory rings, a bounded sidecar JSONL under /var/log/leon/v2, a compact
5-minute heartbeat line) and nothing else happens: in Phase 2 the legacy path
stays authoritative for every response, tool call and model call.

Hard rules
----------
* The only executive method ever called is ``plan_event(..., dry_run=True)``.
  ``plan()`` without ``dry_run`` and ``route()`` are never called. If the
  running executive lacks the dry-run API (a partial rollback), every event is
  recorded as ``interlock`` and the executive is not touched.
* A text event (USER_MESSAGE, VOICE_FINAL) is never planned while a user turn
  could be running: a dry-run plan still takes the graph/lessons/skills
  locks, and background cognition must never block a user turn (runbook 0).
  Text events are *parked* (non-blocking; the consumer keeps draining other
  events) and released one at a time only when every turn signal has been
  quiet for 3 s, at least 10 s after the newest text arrived, and either the
  turn was seen running or 120 s have passed. A fresh probe runs immediately
  before planning and again right after (``overlap_suspected``). A parked
  event older than 900 s is recorded as ``deferred_expired`` and never
  planned; parking overflow (32) records the oldest as ``deferred_overflow``.
* Never raises into anyone. Failures are counted, logged at most once per
  minute per subsystem with trace_id, subsystem, exception type and recovery
  action (runbook 0.2), and recorded as ``error`` decisions. The worker
  survives isolated failures and dies only after 5 consecutive ones; a worker
  that has not beaten for 120 s makes ``accepting`` false for every type.
* Owns no canonical state. ``brain`` is held as a weak reference and never
  used. Nothing is written under the brain state directory.
* Decisions are allow-listed (D19): no user text, lesson text, reflex/canned
  text, skill names or strategic route reasoning ever reach a decision, the
  sidecar, the heartbeat or a log line.

Imports: the standard library and the V2 event modules only.
"""
from __future__ import annotations

import inspect
import json
import logging
import os
import re
import sys
import threading
import time
import weakref
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Callable, Deque, Dict, List, Mapping, Optional, Tuple

from .events import CognitiveEvent, EventType
from .event_bus import EventBus as CognitiveEventBus

log = logging.getLogger("leon.v2.runtime")

__all__ = ["CognitiveRuntime", "RuntimeDecision", "MODE_SHADOW", "sanitize_plan"]

MODE_SHADOW = "shadow"
TEXT_EVENT_TYPES = frozenset({EventType.USER_MESSAGE, EventType.VOICE_FINAL})
GET_TIMEOUT_S = 0.5
PARKED_POLL_S = 0.25
PARK_MAX = 32
TEXT_SETTLE_S = 10.0
QUIET_HOLD_S = 3.0
TEXT_START_GRACE_S = 120.0
TEXT_DEFER_CEILING_S = 900.0
HEARTBEAT_INTERVAL_S = 300.0
SWEEP_INTERVAL_S = 15.0
SENSORY_TICK_INTERVAL_S = 1.0
CONSUMER_STALE_S = 10.0
STALL_REFUSE_S = 120.0
MAX_CONSECUTIVE_FAILURES = 5
DECISION_RING = 2000
LATENCY_WINDOW = 2048
FAILURE_LOG_INTERVAL_S = 60.0
MAX_KEYS = 64
SIDECAR_DIR_DEFAULT = "/var/log/leon/v2"
SIDECAR_FILE = "runtime_decisions.jsonl"
SIDECAR_MAX_BYTES = 8 * 1024 * 1024
SIDECAR_KEEP = 3                 # live + .1 .. .3 -> <= 32 MiB
SIDECAR_PAUSE_S = 600.0
HEARTBEAT_STDOUT_MAX = 300

#: handling values that mean "the executive was not consulted"
_NOT_PLANNED = frozenset({"no_executive", "interlock", "error", "skipped_shutdown",
                          "deferred_expired", "deferred_overflow"})
_ERROR_HANDLING = frozenset({"no_executive", "interlock", "error"})

# -- D19 allow-lists ----------------------------------------------------------
_NOTE_KEYS = frozenset({
    "reflex_ms", "command", "event_id", "trace_id", "event_type", "priority", "source",
    "may_block_user", "dry_run", "handling", "llm_policy", "would_emit",
    "defer_reason", "curiosity", "never_block_user", "user_path_model",
    "safety_authorization", "llm_default", "error", "prediction_error", "episode",
    "bucket_unknown", "coerced", "bucket"})
_PAYLOAD_REF_KEYS: Dict[str, Tuple[str, ...]] = {
    "user_message": ("channel", "chars", "text_sha1", "truncated", "received_wall",
                     "has_attachment", "ws_client", "lossy"),
    "voice_final": ("voice_source", "path", "chars", "text_sha1", "received_wall",
                    "captured_ts", "gate_reason", "lossy"),
    "tool_result": ("episode_id", "tool", "ok", "bypass", "episode_recorded", "pe_child",
                    "surprise"),
    "prediction_error": ("episode_id", "tool", "surprise", "persistent"),
    "sleep_event": ("kind", "cycle_id", "old", "new", "transition", "pass_no_first",
                    "pass_no_last", "passes_covered", "counter_reset"),
    "goal_event": ("change", "goal_id", "status"),
    "perception_change": ("kind", "frame_id", "width", "height", "ready_clients",
                          "observation_id", "modality", "changes_count"),
    "resource_event": ("bucket", "signal"),
    "background_thought": ("kind",),
    "learning_intent": ("kind",),
}
_VOICE_KEYS = ("voice_source", "path", "captured_ts", "gate_reason", "gate_overlap",
               "stt_confidence", "wake_word", "duration_s", "push_to_talk")
_LESSON_RX = re.compile(r"lesson #(\d+)")


def _scalar(v: Any) -> Any:
    if isinstance(v, bool) or v is None or isinstance(v, int):
        return v
    if isinstance(v, float):
        return v if v == v and v not in (float("inf"), float("-inf")) else None
    if isinstance(v, str):
        return v[:80]
    return None


def sanitize_plan(plan: Any) -> Dict[str, Any]:
    """Allow-list an ExecutivePlan into a JSON dict with no private text (D19)."""
    try:
        d = plan.to_dict() if hasattr(plan, "to_dict") else dict(plan or {})
    except Exception:
        return {"unserializable": True}
    out: Dict[str, Any] = {}
    for k in ("strategy", "confidence", "budget_ms", "retrieval_depth"):
        if k in d:
            out[k] = _scalar(d[k])
    reasoning = d.get("reasoning")
    if isinstance(reasoning, str):
        out["reasoning"] = reasoning.split(" — ", 1)[0][:80]
    pf = d.get("prompt_flags") or {}
    if isinstance(pf, dict):
        out["prompt_flags"] = {str(k)[:40]: v for k, v in list(pf.items())[:32]
                               if isinstance(k, str) and isinstance(v, (bool, int, float))}
    ttc = d.get("tools_to_consider") or []
    if isinstance(ttc, (list, tuple)):
        out["tools_to_consider"] = [t[:80] for t in list(ttc)[:10] if isinstance(t, str)]
    vetoes = []
    for v in list(d.get("vetoes") or [])[:10]:
        try:
            tool, why = v[0], v[1]
            m = _LESSON_RX.search(str(why))
            vetoes.append([str(tool)[:80], f"lesson#{m.group(1)}" if m else "lesson#?"])
        except Exception:
            continue
    out["vetoes"] = vetoes
    notes_in = d.get("notes") or {}
    notes: Dict[str, Any] = {}
    if isinstance(notes_in, dict):
        for k, v in notes_in.items():
            if k in _NOTE_KEYS:
                if isinstance(v, list):
                    notes[k] = [_scalar(x) for x in v[:16]]
                elif isinstance(v, dict):
                    notes[k] = {str(a)[:40]: _scalar(b) for a, b in list(v.items())[:16]}
                else:
                    notes[k] = _scalar(v)
            elif k in ("reflex_text", "canned_text"):
                notes[k + "_chars"] = len(v) if isinstance(v, str) else None
            elif k == "voice" and isinstance(v, dict):
                notes["voice"] = {a: _scalar(v[a]) for a in _VOICE_KEYS if a in v}
            elif k == "skill_match" and isinstance(v, dict):
                notes["skill_match"] = {a: _scalar(v.get(a)) for a in ("skill_id", "success_rate", "steps")}
    out["notes"] = notes
    try:
        return json.loads(json.dumps(out, default=str))
    except Exception:
        return {"unserializable": True}


def payload_ref(event: CognitiveEvent) -> Dict[str, Any]:
    keys = _PAYLOAD_REF_KEYS.get(event.type.value, ())
    p = event.payload
    return {k: _scalar(p.get(k)) for k in keys if k in p}


@dataclass(frozen=True)
class RuntimeDecision:
    event_id: str
    trace_id: str
    parent_event_id: Optional[str]
    event_type: str
    source: str
    priority: int
    mode: str
    dry_run: bool
    handling: str
    strategy: Optional[str]
    llm_policy: Optional[str]
    would_emit: Tuple[str, ...]
    confidence: Optional[float]
    budget_ms: Optional[int]
    plan: Mapping[str, Any]
    payload_ref: Mapping[str, Any]
    user_turn_active: bool
    turn_active_after_plan: bool
    queue_wait_ms: float
    defer_ms: float
    latency_ms: float
    decided_wall: float
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["would_emit"] = list(self.would_emit)
        d["plan"] = dict(self.plan) if self.plan else {}
        d["payload_ref"] = dict(self.payload_ref) if self.payload_ref else {}
        return d


def _pct(values: List[float]) -> Dict[str, Any]:
    if not values:
        return {"n": 0, "p50": None, "p95": None, "p99": None, "max": None}
    v = sorted(values)
    n = len(v)

    def at(q: float) -> float:
        return round(v[min(n - 1, int(q * (n - 1) + 0.5))], 3)
    return {"n": n, "p50": at(0.50), "p95": at(0.95), "p99": at(0.99),
            "max": round(v[-1], 3)}


_SIDECAR_LOCKS: Dict[str, threading.Lock] = {}
_SIDECAR_LOCKS_MU = threading.Lock()


class _Sidecar:
    """Bounded, self-rotating JSONL writer. Never raises.

    One process-wide lock per path serializes writes and rotation across
    runtime instances (an init_brain re-entry); the inode is re-checked
    before each write so an instance never writes into a rotated file.
    """

    def __init__(self, directory: str) -> None:
        self.dir = directory
        self.path = os.path.join(directory, SIDECAR_FILE)
        with _SIDECAR_LOCKS_MU:
            self._mu = _SIDECAR_LOCKS.setdefault(self.path, threading.Lock())
        self.fh = None
        self.bytes = 0
        self.rotations = 0
        self.write_errors = 0
        self.paused_until = 0.0
        self.enabled = False
        self.closed = False

    def open(self) -> None:
        parent = os.path.dirname(self.dir.rstrip("/")) or "/"
        if not os.path.isdir(parent):
            return          # no /var/log/leon (Windows, customer installs): disabled
        try:
            os.makedirs(self.dir, mode=0o750, exist_ok=True)
            self.enabled = True
        except Exception as exc:
            self._fail("-", exc)

    def _fail(self, trace: str, exc: BaseException) -> None:
        self.write_errors += 1
        self.paused_until = time.monotonic() + SIDECAR_PAUSE_S
        log.warning("[V2] sidecar failed trace_id=%s subsystem=v2.runtime.sidecar "
                    "exc=%s recovery=sidecar paused 10 min; in-memory ring continues",
                    trace, type(exc).__name__)
        self._close_fh()

    def _close_fh(self) -> None:
        try:
            if self.fh:
                self.fh.close()
        except Exception:
            pass
        self.fh = None

    def write(self, rec: Dict[str, Any], trace: str = "-") -> None:
        if not self.enabled or self.closed or time.monotonic() < self.paused_until:
            return
        with self._mu:
            try:
                if self.fh is not None:
                    try:
                        if os.fstat(self.fh.fileno()).st_ino != os.stat(self.path).st_ino:
                            self._close_fh()
                    except FileNotFoundError:
                        self._close_fh()
                if self.fh is None:
                    self.fh = open(self.path, "a", encoding="utf-8")
                    self.bytes = self.fh.tell()
                line = json.dumps(rec, separators=(",", ":"), default=str) + "\n"
                self.fh.write(line)
                self.fh.flush()
                self.bytes += len(line.encode("utf-8", "replace"))
                if self.bytes > SIDECAR_MAX_BYTES:
                    self._rotate()
            except Exception as exc:
                self._fail(trace, exc)

    def _rotate(self) -> None:
        self._close_fh()
        for i in range(SIDECAR_KEEP, 0, -1):
            src = self.path if i == 1 else f"{self.path}.{i - 1}"
            dst = f"{self.path}.{i}"
            if os.path.exists(src):
                os.replace(src, dst)
        self.rotations += 1
        self.bytes = 0

    def close(self) -> None:
        self.closed = True
        with self._mu:
            self._close_fh()

    def stats(self) -> Dict[str, Any]:
        return {"enabled": self.enabled, "path": self.path if self.enabled else None,
                "bytes": self.bytes, "rotations": self.rotations,
                "write_errors": self.write_errors,
                "paused": time.monotonic() < self.paused_until}


class CognitiveRuntime:
    """Single consumer of the cognitive event bus, SHADOW mode only."""

    def __init__(self, *, cognition: Any, brain: Any, bus: CognitiveEventBus,
                 mode: str = MODE_SHADOW,
                 inference_scheduler: Any = None,
                 user_turn_probe: Optional[Callable[[], bool]] = None,
                 sweep_fn: Optional[Callable[[], None]] = None,
                 live_mode_fn: Optional[Callable[[], str]] = None,
                 sidecar_dir: Optional[str] = SIDECAR_DIR_DEFAULT,
                 clock: Callable[[], float] = time.monotonic,
                 wall: Callable[[], float] = time.time) -> None:
        if mode != MODE_SHADOW:
            raise ValueError(f"CognitiveRuntime mode {mode!r} is not implemented in "
                             f"Phase 2 (shadow only)")
        self.mode = mode
        self.requested_mode = mode
        self._cognition = cognition
        try:
            self._brain = weakref.ref(brain) if brain is not None else None
        except TypeError:
            self._brain = None                    # never used in Phase 2
        self._bus = bus
        self._scheduler = inference_scheduler     # Phase 3; accepted, unused
        self._probe = user_turn_probe
        self._sweep_fn = sweep_fn
        self._live_mode_fn = live_mode_fn
        self.sensory = None  # Installed before start(); no independent bus consumer.
        self.memory = None   # Attached after late canonical owners initialize.
        self.prediction = None  # Existing sole consumer observes each dequeued event.
        self.tasks = None       # Finite action workers; no model or planning loop.
        self.speech = None  # Existing synthesis queue; cached arbitration selection.
        self.providers = None  # Uses the existing admitted inference worker.
        self._provider_release = None
        self._provider_released = True
        self._provider_retire_lock = threading.Lock()
        self._prediction_release = None
        self._prediction_released = True
        self._owned_lock = threading.Lock()
        self._clock = clock
        self._wall = wall
        self._sidecar = _Sidecar(sidecar_dir) if sidecar_dir else None

        self._lock = threading.Lock()
        self._stop_evt = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._started = False
        self._stopping = False
        self._dead = False
        self._started_wall: Optional[float] = None
        self._beat = clock()
        self._next_sweep = 0.0
        self._next_sensory_tick = 0.0
        self._next_heartbeat = 0.0

        # text parking: [event, dequeued_mono, saw_busy]
        self._parked: List[list] = []
        self._quiet_since: Optional[float] = None
        self._last_text_created_mono: float = -1e18

        self._decisions: Deque[Dict[str, Any]] = deque(maxlen=DECISION_RING)
        self._n = {k: 0 for k in ("decided", "planned", "errors", "deferred_expired",
                                  "deferred_overflow", "skipped_shutdown",
                                  "overlap_suspected", "parked_total")}
        self._by_type: Dict[str, Dict[str, Any]] = {}
        self._by_source: Dict[str, int] = {}
        self._lat: Dict[str, Deque[float]] = {
            k: deque(maxlen=LATENCY_WINDOW)
            for k in ("text_plan", "event_rule", "queue_wait", "defer")}
        self._fail_counts: Dict[str, int] = {}
        self._fail_last: Dict[str, float] = {}
        self._fail_suppressed: Dict[str, int] = {}
        self._interlock_cache: Dict[int, Optional[str]] = {}

    # -- lifecycle -------------------------------------------------------

    @property
    def stalled(self) -> bool:
        return bool(self._started and not self._stopping
                    and (self._clock() - self._beat) >= STALL_REFUSE_S)

    @property
    def accepting(self) -> bool:
        if not self._started or self._stopping or self._dead or self.stalled:
            return False
        if self._live_mode_fn is not None:
            try:
                if self._live_mode_fn() == "off":
                    return False
            except Exception:
                return False
        return True

    def start(self) -> bool:
        with self._lock:
            if self._started:
                return True
            self._started = True
            self._started_wall = self._wall()
        self._beat = self._clock()
        if self._sidecar is not None:
            self._sidecar.open()
        now = self._clock()
        self._next_sweep = now + SWEEP_INTERVAL_S
        self._next_heartbeat = now + HEARTBEAT_INTERVAL_S
        self._thread = threading.Thread(target=self._run, name="cognitive-runtime",
                                        daemon=True)
        self._thread.start()
        return True

    def attach_memory(self, owner: Any) -> bool:
        """Bind a late lifecycle owner; shutdown and replacement cannot overlap."""
        with self._owned_lock:
            if self._stopping or self._dead:
                return False
            if self.memory is owner:
                return True
            if self.memory is not None and not self.memory.retired:
                return False
            self.memory = owner
            return True

    def attach_tasks(self, owner: Any) -> bool:
        with self._owned_lock:
            if self._stopping or self._dead:
                return False
            if self.tasks is owner:
                return True
            if self.tasks is not None and not self.tasks.retired:
                return False
            self.tasks = owner
            return True

    def attach_speech(self, owner: Any) -> bool:
        """Own the cold queue binding before startup can publish it."""
        with self._owned_lock:
            if self._stopping or self._dead:
                return False
            if self.speech is owner:
                return True
            if self.speech is not None and not self.speech.retired:
                return False
            self.speech = owner
            return True

    def attach_prediction(self, owner: Any, *, release: Callable[[], bool]) -> bool:
        """Bind a cold owner before start; retain its callback until retirement."""
        with self._owned_lock:
            if self._stopping or self._dead:
                return False
            if self.prediction is owner:
                return True
            if self.prediction is not None or not callable(release):
                return False
            self.prediction = owner
            self._prediction_release = release
            self._prediction_released = False
            return True

    def attach_providers(self, owner: Any, *, publish: Callable[[], None],
                         release: Callable[[], bool]) -> bool:
        """Own before exposing the responder hook, atomically with shutdown."""
        with self._owned_lock:
            if self._stopping or self._dead or not callable(publish) or not callable(release):
                return False
            if self.providers is owner:
                return not self._provider_released
            if self.providers is not None and (not self.providers.retired or not self._provider_released):
                return False
            self.providers = owner
            self._provider_release, self._provider_released = release, False
            try:
                publish()
            except Exception:
                # Keep ownership even if publication partially changed state.
                owner.quiesce()
                return False
            return True

    def retire_providers(self) -> bool:
        """Nonblocking; retain binding through facade drain and ledger closure."""
        if not self._provider_retire_lock.acquire(False):
            return False
        try:
            owner = self.providers
            if owner is None:
                return True
            owner.quiesce()
            if not owner.stop(timeout=0) or not owner.retired:
                return False
            with self._owned_lock:
                if self.providers is not owner:
                    return False
                if not self._provider_released:
                    self._provider_released = self._provider_release() is True
                return self._provider_released
        finally:
            self._provider_retire_lock.release()

    def _retire_prediction(self) -> None:
        owner = self.prediction
        if owner is None:
            return
        if not owner.retired:
            owner.stop()
        if owner.retired and not self._prediction_released:
            self._prediction_released = self._prediction_release() is True

    def record_memory_telemetry(self, record: Dict[str, Any]) -> None:
        """Existing runtime-thread sidecar; no queries, references or text."""
        safe = {"kind": "memory_shadow", "wall": round(self._wall(), 3)}
        for key in ("offered", "queued", "submitted", "completed", "dropped",
                    "expired", "failures", "references", "pending"):
            value = record.get(key)
            if type(value) is int and 0 <= value <= 1000000000:
                safe[key] = value
        for key in ("mode", "status"):
            value = record.get(key)
            if value in ("off", "shadow", "pending", "completed", "expired", "unavailable"):
                safe[key] = value
        if record.get("scope") == "unscoped_legacy":
            safe["scope"] = "unscoped_legacy"
        if record.get("metadata_only") is True:
            safe["metadata_only"] = True
        if self._sidecar is not None:
            self._sidecar.write(safe)

    def stop(self, join_timeout: float = 0.0) -> None:
        """Idempotent, non-blocking by default, never raises."""
        try:
            with self._owned_lock:
                first_stop = not self._stopping
                self._stopping = True
                if self.tasks is not None:
                    self.tasks.quiesce()
                if self.prediction is not None:
                    self.prediction.quiesce()
                if self.memory is not None:
                    self.memory.quiesce()
                if self.providers is not None:
                    self.providers.quiesce()
                if self.speech is not None:
                    self.speech.quiesce()
            if self.sensory is not None:
                self.sensory.quiesce()
            self._stop_evt.set()
            self._bus.stop()
            self._cognition = None
            self._brain = None
            self._probe = None
            self._sweep_fn = None
            if join_timeout > 0 and self._thread is not None:
                if self._thread is not threading.current_thread():
                    self._thread.join(join_timeout)
            # A zero-time shutdown never performs scene I/O. The worker finally
            # owns the first drain; a later explicit retirement retry can finish
            # a previous persister timeout/save failure while retaining ownership.
            if join_timeout > 0 and (self._thread is None or not self._thread.is_alive()):
                self._safe(self._retire_prediction, "v2.runtime.prediction_stop")
                self._safe(self.retire_providers, "v2.runtime.provider_stop")
                if self.speech is not None and not self.speech.retired:
                    self.speech.stop(join_timeout=min(0.25, join_timeout))
                if self.tasks is not None and not self.tasks.retired:
                    self.tasks.stop(join_timeout=min(0.25, join_timeout))
                if self.sensory is not None and not self.sensory.retired:
                    self.sensory.stop(join_timeout=min(0.25, join_timeout))
                if self.memory is not None and not self.memory.retired:
                    self.memory.stop(join_timeout=min(0.25, join_timeout))
            if first_stop:
                print("[V2] cognitive runtime stopped " + self._compact_stats(), flush=True)
        except Exception as exc:
            self._report("-", "v2.runtime.stop", exc, "daemon thread ends with the process")

    def retirement_complete(self) -> bool:
        """True only after the actual worker and its derived-state owner retired."""
        return (self._stopping and (self._thread is None or not self._thread.is_alive())
                and (self.sensory is None or self.sensory.retired)
                and (self.memory is None or self.memory.retired)
                and (self.tasks is None or self.tasks.retired)
                and (self.speech is None or self.speech.retired)
                and (self.providers is None or (self.providers.retired and self._provider_released))
                and (self.prediction is None or (self.prediction.retired and self._prediction_released)))

    def publish(self, event: CognitiveEvent) -> bool:
        if not self.accepting:
            return False
        return self._bus.publish(event)

    def bus_depth(self) -> int:
        return len(self._bus)

    def consumer_alive(self) -> bool:
        t = self._thread
        return bool(t is not None and t.is_alive()
                    and (self._clock() - self._beat) < CONSUMER_STALE_S)

    # -- worker ----------------------------------------------------------

    def _run(self) -> None:
        consecutive = 0
        try:
            while not self._stop_evt.is_set():
                self._beat = self._clock()
                ev = None
                try:
                    ev = self._bus.get(timeout=PARKED_POLL_S if self._parked else GET_TIMEOUT_S)
                    if ev is not None:
                        self._dispatch(ev)
                    if self._parked:
                        self._service_parked()
                    self._periodic()
                    consecutive = 0
                except Exception as exc:
                    consecutive += 1
                    self._report(getattr(ev, "trace_id", "-"), "v2.runtime.worker_iteration", exc,
                                 f"iteration skipped ({consecutive}/{MAX_CONSECUTIVE_FAILURES}); "
                                 f"worker continues")
                    if consecutive >= MAX_CONSECUTIVE_FAILURES:
                        raise
                    self._stop_evt.wait(min(2.0, 0.1 * (2 ** consecutive)))
            for item in list(self._parked):
                self._record(self._skip(item[0], "skipped_shutdown", item[1]))
            self._parked.clear()
        except BaseException as exc:
            self._dead = True
            self._report("-", "v2.runtime.worker", exc,
                         "worker stopped; bus stopped and drained; publishers now no-ops; "
                         "legacy unaffected")
            try:
                self._bus.stop()
                self._bus.drain_abandon()
                for item in list(self._parked):
                    self._record(self._skip(item[0], "skipped_shutdown", item[1]))
                self._parked.clear()
            except Exception as exc2:
                self._report("-", "v2.runtime.worker_cleanup", exc2, "pending events left for GC")
        finally:
            with self._owned_lock:
                if self.tasks is not None:
                    self.tasks.quiesce()
                if self.prediction is not None:
                    self.prediction.quiesce()
                if self.memory is not None:
                    self.memory.quiesce()
                if self.providers is not None:
                    self.providers.quiesce()
                if self.speech is not None:
                    self.speech.quiesce()
            self._safe(self._retire_prediction, "v2.runtime.prediction_stop")
            self._safe(self.retire_providers, "v2.runtime.provider_stop")
            if self.speech is not None:
                self._safe(self.speech.stop, "v2.runtime.speech_stop")
            if self.tasks is not None:
                self._safe(self.tasks.stop, "v2.runtime.task_stop")
            if self.memory is not None:
                self._safe(self.memory.stop, "v2.runtime.memory_stop")
            if self.sensory is not None:
                self._safe(self.sensory.stop, "v2.runtime.sensory_stop")
            if self._sidecar is not None:
                self._sidecar.close()
            print("[V2] cognitive runtime worker exited " + self._compact_stats(), flush=True)

    def _dispatch(self, ev: CognitiveEvent) -> None:
        if self.prediction is not None:
            self._safe(lambda: self.prediction.observe_event(ev), "v2.runtime.prediction_observe")
        if ev.type in TEXT_EVENT_TYPES:
            now = self._clock()
            self._last_text_created_mono = max(self._last_text_created_mono, ev.created_mono)
            if len(self._parked) >= PARK_MAX:
                oldest = self._parked.pop(0)
                self._record(self._skip(oldest[0], "deferred_overflow", oldest[1]))
            self._parked.append([ev, now, False])
            with self._lock:
                self._n["parked_total"] += 1
            return
        self._record(self.route_shadow(ev))

    def _service_parked(self) -> None:
        now = self._clock()
        busy = self._probe_safe()
        if busy:
            for item in self._parked:
                item[2] = True
            self._quiet_since = None
        elif self._quiet_since is None:
            self._quiet_since = now
        for item in list(self._parked):
            if now - item[1] >= TEXT_DEFER_CEILING_S:
                self._parked.remove(item)
                self._record(self._skip(item[0], "deferred_expired", item[1]))
        if not self._parked or busy:
            return
        head = self._parked[0]
        ev, deq, saw_busy = head
        if now - self._last_text_created_mono < TEXT_SETTLE_S:
            return
        if self._quiet_since is None or now - self._quiet_since < QUIET_HOLD_S:
            return
        if not saw_busy and now - ev.created_mono < TEXT_START_GRACE_S:
            return
        if self._probe_safe():                        # fresh probe right before planning
            self._quiet_since = None
            return
        self._parked.pop(0)
        self._record(self.route_shadow(ev, deferred_ms=(now - deq) * 1000.0))

    def _periodic(self) -> None:
        now = self._clock()
        if not self._stopping and now >= self._next_sensory_tick:
            self._next_sensory_tick = now + SENSORY_TICK_INTERVAL_S
            if self.sensory is not None:
                self._safe(self.sensory.tick, "v2.runtime.sensory_tick")
            if self.memory is not None:
                self._safe(self.memory.tick, "v2.runtime.memory_tick")
            if self.prediction is not None:
                self._safe(self.prediction.tick, "v2.runtime.prediction_tick")
            if self.tasks is not None:
                self._safe(self.tasks.tick, "v2.runtime.task_tick")
            if self.providers is not None:
                self._safe(self.providers.tick, "v2.runtime.provider_tick")
            if self.speech is not None:
                self._safe(self.speech.tick, "v2.runtime.speech_tick")
        if now >= self._next_sweep:
            self._next_sweep = now + SWEEP_INTERVAL_S
            if self._sweep_fn is not None and self.accepting:
                self._safe(self._sweep_fn, "v2.runtime.sweep")
        if now >= self._next_heartbeat:
            self._next_heartbeat = now + HEARTBEAT_INTERVAL_S
            self._safe(self._heartbeat, "v2.runtime.heartbeat")

    def _safe(self, fn: Callable[[], Any], subsystem: str) -> None:
        try:
            fn()
        except Exception as exc:
            self._report("-", subsystem, exc, "skipped this cycle; runtime continues")

    def _probe_safe(self) -> bool:
        probe = self._probe
        if probe is None:
            return False
        try:
            return bool(probe())
        except Exception as exc:
            self._report("-", "v2.runtime.user_turn_probe", exc, "treated as turn active")
            return True

    # -- routing ---------------------------------------------------------

    def _executive(self) -> Any:
        cog = self._cognition
        return getattr(cog, "executive", None) if cog is not None else None

    def _interlock(self, exe: Any) -> Optional[str]:
        key = id(exe)
        if key in self._interlock_cache:
            return self._interlock_cache[key]
        reason: Optional[str] = None
        pe = getattr(exe, "plan_event", None)
        pl = getattr(exe, "plan", None)
        if pe is None or not callable(pe):
            reason = "executive_lacks_plan_event"
        else:
            try:
                if ("dry_run" not in inspect.signature(pe).parameters
                        or pl is None
                        or "dry_run" not in inspect.signature(pl).parameters):
                    reason = "executive_lacks_dry_run"
            except (TypeError, ValueError):
                reason = "executive_lacks_dry_run"
        self._interlock_cache = {key: reason}      # one executive at a time
        return reason

    def _decision(self, ev: CognitiveEvent, *, handling: str, plan: Any = None,
                  user_turn_active: bool = False, turn_active_after_plan: bool = False,
                  queue_wait_ms: float = 0.0, defer_ms: float = 0.0,
                  latency_ms: float = 0.0, error: Optional[str] = None) -> RuntimeDecision:
        sanitized = sanitize_plan(plan) if plan is not None else {}
        notes = sanitized.get("notes") or {}
        return RuntimeDecision(
            event_id=ev.event_id, trace_id=ev.trace_id,
            parent_event_id=ev.parent_event_id, event_type=ev.type.value,
            source=ev.source[:64], priority=ev.priority, mode=self.mode, dry_run=True,
            handling=str(notes.get("handling") or handling),
            strategy=sanitized.get("strategy"),
            llm_policy=notes.get("llm_policy"),
            would_emit=tuple(str(x) for x in (notes.get("would_emit") or ()) if x),
            confidence=sanitized.get("confidence"),
            budget_ms=sanitized.get("budget_ms"),
            plan=sanitized, payload_ref=payload_ref(ev),
            user_turn_active=bool(user_turn_active),
            turn_active_after_plan=bool(turn_active_after_plan),
            queue_wait_ms=round(queue_wait_ms, 3), defer_ms=round(defer_ms, 3),
            latency_ms=round(latency_ms, 3), decided_wall=self._wall(),
            error=error if error is None else str(error)[:80])

    def _skip(self, ev: CognitiveEvent, handling: str, dequeued_mono: float) -> RuntimeDecision:
        return self._decision(ev, handling=handling,
                              queue_wait_ms=max(0.0, (dequeued_mono - ev.created_mono) * 1000.0),
                              defer_ms=max(0.0, (self._clock() - dequeued_mono) * 1000.0))

    def route_shadow(self, event: CognitiveEvent, *, deferred_ms: float = 0.0) -> RuntimeDecision:
        """What the executive would do with ``event``. Never raises."""
        try:
            queue_wait_ms = max(0.0, (self._clock() - event.created_mono) * 1000.0 - deferred_ms)
            exe = self._executive()
            if exe is None:
                return self._decision(event, handling="no_executive", queue_wait_ms=queue_wait_ms,
                                      defer_ms=deferred_ms, error="no_executive")
            reason = self._interlock(exe)
            if reason is not None:
                return self._decision(event, handling="interlock", queue_wait_ms=queue_wait_ms,
                                      defer_ms=deferred_ms, error=reason)
            active = self._probe_safe() if event.type in TEXT_EVENT_TYPES else False
            ctx = {"user_turn_active": active, "budget_available": False}
            t0 = self._clock()
            plan = exe.plan_event(event, ctx=ctx, dry_run=True)
            latency_ms = (self._clock() - t0) * 1000.0
            after = self._probe_safe() if event.type in TEXT_EVENT_TYPES else False
            err = (getattr(plan, "notes", None) or {}).get("error")
            return self._decision(event, handling="decided", plan=plan,
                                  user_turn_active=active, turn_active_after_plan=after,
                                  queue_wait_ms=queue_wait_ms, defer_ms=deferred_ms,
                                  latency_ms=latency_ms, error=err)
        except Exception as exc:
            self._report(getattr(event, "trace_id", "-"), "v2.runtime.route_shadow", exc,
                         "decision recorded as error; legacy path untouched")
            return self._decision(event, handling="error", error=type(exc).__name__,
                                  defer_ms=deferred_ms)

    # -- recording -------------------------------------------------------

    def _record(self, decision: RuntimeDecision) -> None:
        d = decision.to_dict()
        with self._lock:
            self._decisions.append(d)
            n = self._n
            n["decided"] += 1
            planned = decision.handling not in _NOT_PLANNED
            if planned:
                n["planned"] += 1
            is_err = decision.handling in _ERROR_HANDLING or (planned and bool(decision.error))
            n["errors"] += int(is_err)
            for k in ("deferred_expired", "deferred_overflow", "skipped_shutdown"):
                if decision.handling == k:
                    n[k] += 1
            if decision.turn_active_after_plan:
                n["overlap_suspected"] += 1
            t = decision.event_type if (decision.event_type in self._by_type
                                        or len(self._by_type) < MAX_KEYS) else "_other"
            bt = self._by_type.setdefault(t, {"decided": 0, "errors": 0,
                                              "handling": {}, "strategy": {}})
            bt["decided"] += 1
            bt["errors"] += int(is_err)
            h = bt["handling"]
            if decision.handling in h or len(h) < 16:
                h[decision.handling] = h.get(decision.handling, 0) + 1
            st = bt["strategy"]
            sk = str(decision.strategy)
            if sk in st or len(st) < 16:
                st[sk] = st.get(sk, 0) + 1
            src = decision.source if (decision.source in self._by_source
                                      or len(self._by_source) < MAX_KEYS) else "_other"
            self._by_source[src] = self._by_source.get(src, 0) + 1
            if planned:
                key = "text_plan" if decision.event_type in ("user_message", "voice_final") else "event_rule"
                self._lat[key].append(decision.latency_ms)
            self._lat["queue_wait"].append(decision.queue_wait_ms)
            if decision.defer_ms > 0:
                self._lat["defer"].append(decision.defer_ms)
        if self._sidecar is not None and not self._stopping:
            self._sidecar.write({"kind": "decision", **d}, decision.trace_id)

    def _report(self, trace_id: str, subsystem: str, exc: BaseException, recovery: str) -> None:
        now = self._clock()
        self._fail_counts[subsystem] = self._fail_counts.get(subsystem, 0) + 1
        last = self._fail_last.get(subsystem)
        if last is None or now - last >= FAILURE_LOG_INTERVAL_S:
            n = self._fail_suppressed.pop(subsystem, 0)
            self._fail_last[subsystem] = now
            log.warning("[V2] %s failed trace_id=%s subsystem=%s exc=%s recovery=%s (suppressed=%d)",
                        subsystem, trace_id, subsystem, type(exc).__name__, recovery, n)
        else:
            self._fail_suppressed[subsystem] = self._fail_suppressed.get(subsystem, 0) + 1

    # -- introspection ---------------------------------------------------

    def _publish_stats(self) -> Dict[str, Any]:
        mod = sys.modules.get("brain.cognition.v2_publish")
        if mod is None:
            return {}
        try:
            return mod.stats()
        except Exception:
            return {"error": True}

    def _compact_stats(self) -> str:
        try:
            b = self._bus.stats()
            n = self._n
            p = self._publish_stats()
            c = p.get("counters") or {}
            skips = sum(v for k, v in c.items() if k.startswith("skipped"))
            tp = _pct(list(self._lat["text_plan"]))["p95"]
            emit_p99 = p.get("emit_p99_us")
            up = int(self._wall() - (self._started_wall or self._wall()))
            return (f"up={up}s alive={int(self.consumer_alive())} depth={b['current_depth']} "
                    f"maxd={b['max_depth']} pub={b['published']} dlv={b['delivered']} "
                    f"coal={b['coalesced']} evict={b['evicted']} drop={b['dropped']} "
                    f"pdrop={b['protected_dropped']} lockto={b['lock_timeouts']} "
                    f"dec={n['decided']} err={n['errors']} parked={len(self._parked)} "
                    f"exp={n['deferred_expired']} ovf={n['deferred_overflow']} "
                    f"ovl={n['overlap_suspected']} skip={skips} "
                    f"text_p95={tp}ms emit_p99={emit_p99}us")[:HEARTBEAT_STDOUT_MAX]
        except Exception as exc:
            return f"stats_unavailable exc={type(exc).__name__}"

    def _heartbeat(self) -> None:
        print("[V2] heartbeat " + self._compact_stats(), flush=True)
        if self._sidecar is not None and not self._stopping:
            self._sidecar.write({"kind": "heartbeat", "wall": self._wall(), **self.stats()})

    def stats(self) -> Dict[str, Any]:
        exe = self._executive()
        with self._lock:
            out = {
                "mode": self.mode, "requested_mode": self.requested_mode, "phase": 2,
                "started_wall": self._started_wall,
                "uptime_s": (round(self._wall() - self._started_wall, 1)
                             if self._started_wall else None),
                "thread_alive": bool(self._thread and self._thread.is_alive()),
                "accepting": self.accepting, "stalled": self.stalled, "dead": self._dead,
                "consumer_idle_s": round(self._clock() - self._beat, 3),
                "executive_present": exe is not None,
                "executive_dry_run_supported": (exe is not None and self._interlock(exe) is None),
                **dict(self._n),
                "parked_now": len(self._parked),
                "by_type": json.loads(json.dumps(self._by_type)),
                "by_source": dict(self._by_source),
                "latency_ms": {k: _pct(list(v)) for k, v in self._lat.items()},
                "decision_ring": {"size": len(self._decisions), "capacity": DECISION_RING},
                "errors_by_subsystem": dict(self._fail_counts),
            }
        out["sidecar"] = self._sidecar.stats() if self._sidecar else {"enabled": False}
        out["bus"] = self._bus.stats()
        out["publish"] = self._publish_stats()
        out["sensory"] = self.sensory.stats() if self.sensory is not None else None
        out["memory"] = self.memory.stats() if self.memory is not None else None
        out["prediction"] = self.prediction.stats() if self.prediction is not None else None
        out["providers"] = self.providers.stats() if self.providers is not None else None
        out["speech"] = self.speech.stats() if self.speech is not None else None
        out["tasks"] = self.tasks.stats() if self.tasks is not None else None
        out["retirement_complete"] = self.retirement_complete()
        return out

    def decisions(self, limit: int = 100, event_type: Optional[str] = None) -> List[Dict[str, Any]]:
        limit = max(1, min(int(limit), DECISION_RING))
        with self._lock:
            items = list(self._decisions)
        if event_type:
            items = [d for d in items if d.get("event_type") == event_type]
        return [dict(d) for d in items[-limit:]]
