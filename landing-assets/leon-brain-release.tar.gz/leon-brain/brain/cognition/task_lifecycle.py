"""Durable operational task records. No model, memory, tool or brain ownership.

An action reserves a result-outbox slot at enqueue time. RUNNING is a durable
claim, not evidence of success. UNKNOWN retains its resource fence indefinitely:
losing the worker or acknowledging a receipt does not prove the effect stopped.
Recovery never repeats a claimed action.
Only a process holding the exclusive worker lease may claim/finish actions.
"""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
import math
import os
import sqlite3
import stat
import threading
import time
import uuid
from typing import Any, Mapping


class TaskError(RuntimeError):
    pass


class CapacityExceeded(TaskError):
    pass


class Conflict(TaskError):
    pass


class WorkerBusy(TaskError):
    pass


TERMINAL_TASKS = frozenset({"SUCCEEDED", "FAILED", "CANCELLED", "NEEDS_REVIEW"})
TERMINAL_ACTIONS = frozenset({"SUCCEEDED", "FAILED", "CANCELLED", "UNKNOWN"})


def _text(value, name, limit=200):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(name)
    return value


def _json(value, limit):
    if not isinstance(value, Mapping):
        raise ValueError("object required")
    data = json.dumps(dict(value), sort_keys=True, separators=(",", ":"), allow_nan=False)
    if len(data.encode("utf-8")) > limit:
        raise ValueError("payload too large")
    return data


def _hash(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


class WorkerLease:
    """OS-held exclusivity survives threads; process death releases the lock."""
    def __init__(self, store, handle):
        self.store, self.handle = store, handle
        self.owner = uuid.uuid4().hex
        self.closed = False

    def close(self):
        self.store.release_worker(self)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS task_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks (
 task_id TEXT PRIMARY KEY, idem_key TEXT UNIQUE NOT NULL, fingerprint TEXT NOT NULL,
 project_scope TEXT NOT NULL, authorization_ref TEXT NOT NULL, priority INTEGER NOT NULL,
 deadline_wall REAL, state TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0,
 checkpoint TEXT NOT NULL, cancel_requested INTEGER NOT NULL DEFAULT 0,
 created_wall REAL NOT NULL, updated_wall REAL NOT NULL);
CREATE TABLE IF NOT EXISTS task_actions (
 action_id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(task_id),
 idem_key TEXT NOT NULL, fingerprint TEXT NOT NULL, name TEXT NOT NULL,
 arguments TEXT NOT NULL, resources TEXT NOT NULL, tier INTEGER NOT NULL,
 state TEXT NOT NULL, owner TEXT, dispatched INTEGER NOT NULL DEFAULT 0,
 result TEXT, result_seq INTEGER, created_wall REAL NOT NULL, completed_wall REAL,
 UNIQUE(task_id, idem_key));
CREATE TABLE IF NOT EXISTS task_results (
 seq INTEGER PRIMARY KEY AUTOINCREMENT, action_id TEXT UNIQUE NOT NULL,
 task_id TEXT NOT NULL, outcome TEXT NOT NULL, payload TEXT NOT NULL,
 created_wall REAL NOT NULL);
CREATE INDEX IF NOT EXISTS task_actions_pending ON task_actions(state,created_wall);
"""


class TaskStore:
    """Explicit path only; use an operational DB, never a private memory store.

    A fixed logical consumer acknowledges the outbox. Acknowledgment releases
    delivery capacity, but action receipts remain available for reconnects.
    Quotas reject new work; this version never deletes idempotency records.
    """
    def __init__(self, path, *, max_tasks=256, max_actions=2048, max_outbox=128,
                 max_payload_bytes=16384, result_consumer="runtime", clock=time.time):
        self.path = os.path.realpath(os.path.abspath(os.fspath(path)))
        if self.path == ":memory:" or os.fspath(path) == ":memory:":
            raise ValueError("a durable file path is required")
        for value in (max_tasks, max_actions, max_outbox, max_payload_bytes):
            if type(value) is not int or value < 1:
                raise ValueError("positive integer limit required")
        if max_payload_bytes < 256:
            raise ValueError("payload limit must fit recovery receipts")
        self.max_tasks, self.max_actions, self.max_outbox = max_tasks, max_actions, max_outbox
        self.max_payload_bytes = max_payload_bytes
        self.result_consumer = _text(result_consumer, "result consumer")
        self._clock, self._lock, self._lease = clock, threading.RLock(), None
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        except FileExistsError:
            info = os.stat(self.path)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise ValueError("regular unaliased database file required")
        else:
            os.close(fd)
        self._conn = sqlite3.connect(self.path, timeout=5, check_same_thread=False,
                                     isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_SCHEMA)
        config = json.dumps([1, max_tasks, max_actions, max_outbox,
                             max_payload_bytes, result_consumer])
        try:
            with self._tx() as db:
                old = db.execute("SELECT value FROM task_meta WHERE key='config'").fetchone()
                if old and old[0] != config:
                    raise Conflict("store configuration differs")
                db.execute("INSERT OR IGNORE INTO task_meta VALUES ('config',?)", (config,))
        except BaseException:
            self._conn.close()
            raise

    @contextmanager
    def _tx(self):
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def close(self):
        with self._lock:
            if self._lease is not None:
                raise WorkerBusy("worker still owns store")
            self._conn.close()

    @staticmethod
    def _task(row):
        if row is None:
            return None
        data = dict(row)
        data["checkpoint"] = json.loads(data["checkpoint"])
        data["cancel_requested"] = bool(data["cancel_requested"])
        return data

    @staticmethod
    def _action(row):
        if row is None:
            return None
        data = dict(row)
        for name in ("arguments", "resources", "result"):
            data[name] = json.loads(data[name]) if data[name] is not None else None
        data["dispatched"] = bool(data["dispatched"])
        return data

    def get_task(self, task_id):
        with self._lock:
            return self._task(self._conn.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone())

    def get_action(self, action_id):
        with self._lock:
            return self._action(self._conn.execute("SELECT * FROM task_actions WHERE action_id=?", (action_id,)).fetchone())

    def action_for_step(self, task_id, idempotency_key):
        """Read a retained attempt by its exact task/step key; never re-enqueue."""
        _text(task_id, "task id")
        _text(idempotency_key, "action idempotency key")
        with self._lock:
            return self._action(self._conn.execute(
                "SELECT * FROM task_actions WHERE task_id=? AND idem_key=?",
                (task_id, idempotency_key)).fetchone())

    def create_task(self, *, idempotency_key, project_scope, authorization_ref,
                    checkpoint=None, priority=70, deadline_wall=None):
        key = _text(idempotency_key, "idempotency key")
        scope = _text(project_scope, "project scope", 1000)
        auth = _text(authorization_ref, "authorization reference", 1000)
        if type(priority) is not int or not 1 <= priority <= 100:
            raise ValueError("priority")
        if deadline_wall is not None and (isinstance(deadline_wall, bool) or
                not isinstance(deadline_wall, (int, float)) or not math.isfinite(deadline_wall)):
            raise ValueError("deadline")
        checkpoint = _json({} if checkpoint is None else checkpoint, self.max_payload_bytes)
        fingerprint = _hash(json.dumps([scope, auth, checkpoint, priority, deadline_wall]))
        with self._tx() as db:
            old = db.execute("SELECT * FROM tasks WHERE idem_key=?", (key,)).fetchone()
            if old:
                if old["fingerprint"] != fingerprint:
                    raise Conflict("task idempotency key has different input")
                return self._task(old)
            if db.execute("SELECT count(*) FROM tasks").fetchone()[0] >= self.max_tasks:
                raise CapacityExceeded("task capacity")
            task_id, now = uuid.uuid4().hex, self._clock()
            db.execute("INSERT INTO tasks(task_id,idem_key,fingerprint,project_scope,authorization_ref,priority,deadline_wall,state,checkpoint,created_wall,updated_wall) VALUES (?,?,?,?,?,?,?,'READY',?,?,?)",
                       (task_id,key,fingerprint,scope,auth,priority,deadline_wall,checkpoint,now,now))
            return self._task(db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone())

    def _capacity(self, db):
        actions = db.execute("SELECT count(*) FROM task_actions").fetchone()[0]
        reserved = db.execute("SELECT count(*) FROM task_actions WHERE state IN ('QUEUED','RUNNING')").fetchone()[0]
        outbox = db.execute("SELECT count(*) FROM task_results").fetchone()[0]
        if actions >= self.max_actions or reserved + outbox >= self.max_outbox:
            raise CapacityExceeded("action or reserved result capacity")

    def enqueue_action(self, task_id, *, idempotency_key, name, arguments,
                       resources, tier, expected_revision):
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("expected revision")
        key, name = _text(idempotency_key, "action idempotency key"), _text(name, "action name")
        args = _json(arguments, self.max_payload_bytes)
        if not isinstance(resources, (list, tuple)) or not 1 <= len(resources) <= 16:
            raise ValueError("explicit resource keys required")
        resource_list = sorted({_text(r, "resource", 500) for r in resources})
        resource_json = json.dumps(resource_list, separators=(",", ":"))
        if type(tier) is not int or tier not in (1,2,3,4):
            raise ValueError("tier")
        fingerprint = _hash(json.dumps([name,args,resource_list,tier]))
        with self._tx() as db:
            old = db.execute("SELECT * FROM task_actions WHERE task_id=? AND idem_key=?", (task_id,key)).fetchone()
            if old:
                if old["fingerprint"] != fingerprint:
                    raise Conflict("action idempotency key has different input")
                return self._action(old)
            task = db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if not task or task["revision"] != expected_revision or task["state"] != "READY" or task["cancel_requested"]:
                raise Conflict("task is not ready at requested revision")
            self._capacity(db)
            action_id, now = uuid.uuid4().hex, self._clock()
            db.execute("INSERT INTO task_actions(action_id,task_id,idem_key,fingerprint,name,arguments,resources,tier,state,created_wall) VALUES (?,?,?,?,?,?,?,?,'QUEUED',?)",
                       (action_id,task_id,key,fingerprint,name,args,resource_json,tier,now))
            db.execute("UPDATE tasks SET state='WAITING_ACTION',revision=revision+1,updated_wall=? WHERE task_id=?", (now,task_id))
            return self._action(db.execute("SELECT * FROM task_actions WHERE action_id=?", (action_id,)).fetchone())

    def checkpoint(self, task_id, data, *, expected_revision, state="WAITING_INFERENCE"):
        """Executive-owned safe checkpoint; never executes or submits inference."""
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("expected revision")
        if state not in ("READY", "WAITING_INFERENCE", "PAUSED", "SUCCEEDED"):
            raise ValueError("checkpoint state")
        payload = _json(data, self.max_payload_bytes)
        with self._tx() as db:
            task = db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if not task or task["revision"] != expected_revision or task["state"] not in ("READY","WAITING_INFERENCE","PAUSED") or task["cancel_requested"]:
                raise Conflict("task cannot checkpoint at requested revision")
            db.execute("UPDATE tasks SET checkpoint=?,state=?,revision=revision+1,updated_wall=? WHERE task_id=?", (payload,state,self._clock(),task_id))
            return self._task(db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone())

    def cancel_task(self, task_id):
        """Cancel future units. A dispatched action retains its result slot."""
        with self._tx() as db:
            task = db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
            if not task:
                raise Conflict("unknown task")
            if task["state"] in TERMINAL_TASKS:
                return self._task(task)
            db.execute("UPDATE tasks SET cancel_requested=1,revision=revision+1,updated_wall=? WHERE task_id=?", (self._clock(),task_id))
            for action in db.execute("SELECT * FROM task_actions WHERE task_id=? AND state='QUEUED'", (task_id,)).fetchall():
                self._finish(db, action, "CANCELLED", {"reason":"cancelled_before_claim"})
            running = db.execute("SELECT 1 FROM task_actions WHERE task_id=? AND state='RUNNING'", (task_id,)).fetchone()
            if not running:
                db.execute("UPDATE tasks SET state='CANCELLED' WHERE task_id=?", (task_id,))
            return self._task(db.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone())

    def acquire_worker(self):
        """Single worker pool per DB; Linux/POSIX only, fail closed otherwise.

        Lock is never stolen by timeout. Only after exclusive acquisition are
        abandoned RUNNING rows marked UNKNOWN with durable result receipts.
        """
        import fcntl
        with self._lock:
            if self._lease is not None:
                raise WorkerBusy("worker already active")
            # Lock the DB inode, not a pathname sidecar: symlink/hardlink aliases
            # must not create a second action pool for the same database.
            fd = os.open(self.path, os.O_RDWR | os.O_NOFOLLOW)
            handle = os.fdopen(fd, "a+b")
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                handle.close()
                raise WorkerBusy("another worker owns this store") from None
            lease = WorkerLease(self, handle)
            self._lease = lease
            try:
                with self._tx() as db:
                    for action in db.execute("SELECT * FROM task_actions WHERE state='RUNNING'").fetchall():
                        self._finish(db, action, "UNKNOWN", {"reason":"worker_lost_after_claim","replay_allowed":False})
            except BaseException:
                self._lease = None
                handle.close()
                raise
            return lease

    def _check_lease(self, lease):
        if not isinstance(lease, WorkerLease) or lease is not self._lease or lease.closed or lease.store is not self:
            raise WorkerBusy("valid worker lease required")

    def release_worker(self, lease):
        with self._lock:
            self._check_lease(lease)
            if self._conn.execute("SELECT 1 FROM task_actions WHERE state='RUNNING' AND owner=?", (lease.owner,)).fetchone():
                raise WorkerBusy("committed work still draining")
            lease.closed = True
            lease.handle.close()
            self._lease = None

    def claim(self, lease, *, max_background=1):
        if type(max_background) is not int or max_background < 1:
            raise ValueError("max background")
        with self._tx() as db:
            self._check_lease(lease)
            # Retained UNKNOWN actions are the durable fence, including rows
            # written by earlier versions. Do not derive this from the outbox:
            # acknowledgment only confirms delivery, not external termination.
            # There is no implicit expiry or reconciliation/release operation.
            occupied = db.execute("SELECT a.state,a.resources,t.priority FROM task_actions a JOIN tasks t USING(task_id) WHERE a.state IN ('RUNNING','UNKNOWN')").fetchall()
            held = {r for row in occupied for r in json.loads(row["resources"])}
            bg_running = sum(row["state"] == "RUNNING" and row["priority"] < 100 for row in occupied)
            candidates = db.execute("SELECT a.*,t.priority FROM task_actions a JOIN tasks t USING(task_id) WHERE a.state='QUEUED' AND t.state='WAITING_ACTION' ORDER BY t.priority DESC,a.created_wall,a.action_id").fetchall()
            for row in candidates:
                if held.intersection(json.loads(row["resources"])) or (row["priority"] < 100 and bg_running >= max_background):
                    continue
                db.execute("UPDATE task_actions SET state='RUNNING',owner=? WHERE action_id=? AND state='QUEUED'", (lease.owner,row["action_id"]))
                db.execute("UPDATE tasks SET state='RUNNING',revision=revision+1,updated_wall=? WHERE task_id=?", (self._clock(),row["task_id"]))
                return self._action(db.execute("SELECT * FROM task_actions WHERE action_id=?", (row["action_id"],)).fetchone())
            return None

    def authorize_dispatch(self, lease, action_id):
        """Commit boundary after policy, before handler. Cancellation cannot undo it."""
        with self._tx() as db:
            self._check_lease(lease)
            action = db.execute("SELECT * FROM task_actions WHERE action_id=?", (action_id,)).fetchone()
            if not action or action["state"] != "RUNNING" or action["owner"] != lease.owner or action["dispatched"]:
                raise Conflict("action is not an undispatched claim")
            task = db.execute("SELECT * FROM tasks WHERE task_id=?", (action["task_id"],)).fetchone()
            if task["cancel_requested"]:
                self._finish(db, action, "CANCELLED", {"reason":"cancelled_before_dispatch"})
                return False
            if task["deadline_wall"] is not None and self._clock() >= task["deadline_wall"]:
                self._finish(db, action, "FAILED", {"reason":"deadline_before_dispatch","executed":False})
                return False
            db.execute("UPDATE task_actions SET dispatched=1 WHERE action_id=?", (action_id,))
            return True

    def finish(self, lease, action_id, outcome, result):
        if outcome not in TERMINAL_ACTIONS:
            raise ValueError("terminal action outcome")
        # Validate before transaction. Worker converts oversized/invalid results
        # to bounded UNKNOWN evidence, never to false success.
        payload = _json(result, self.max_payload_bytes)
        with self._tx() as db:
            self._check_lease(lease)
            row = db.execute("SELECT * FROM task_actions WHERE action_id=?", (action_id,)).fetchone()
            if not row or row["state"] != "RUNNING" or row["owner"] != lease.owner:
                raise Conflict("action is not this worker's active claim")
            if outcome == "SUCCEEDED" and not row["dispatched"]:
                raise Conflict("cannot succeed before dispatch")
            if outcome == "CANCELLED" and row["dispatched"]:
                raise Conflict("cannot erase dispatched action with cancellation")
            self._finish(db, row, outcome, json.loads(payload))

    def _finish(self, db, row, outcome, result):
        payload = _json(result, self.max_payload_bytes)
        now = self._clock()
        cur = db.execute("INSERT INTO task_results(action_id,task_id,outcome,payload,created_wall) VALUES (?,?,?,?,?)", (row["action_id"],row["task_id"],outcome,payload,now))
        db.execute("UPDATE task_actions SET state=?,result=?,result_seq=?,completed_wall=? WHERE action_id=?", (outcome,payload,cur.lastrowid,now,row["action_id"]))
        task = db.execute("SELECT cancel_requested FROM tasks WHERE task_id=?", (row["task_id"],)).fetchone()
        state = "NEEDS_REVIEW" if outcome == "UNKNOWN" else ("CANCELLED" if task[0] or outcome == "CANCELLED" else ("READY" if outcome == "SUCCEEDED" else "FAILED"))
        db.execute("UPDATE tasks SET state=?,revision=revision+1,updated_wall=? WHERE task_id=?", (state,now,row["task_id"]))

    def pending_results(self, *, consumer, limit=100):
        if consumer != self.result_consumer:
            raise Conflict("unknown result consumer")
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise ValueError("limit")
        with self._lock:
            rows = self._conn.execute("SELECT * FROM task_results ORDER BY seq LIMIT ?", (limit,)).fetchall()
            return [{**dict(row), "payload":json.loads(row["payload"])} for row in rows]

    def acknowledge_result(self, seq, *, consumer):
        if consumer != self.result_consumer:
            raise Conflict("unknown result consumer")
        if type(seq) is not int or seq < 1:
            raise ValueError("result sequence")
        with self._tx() as db:
            return db.execute("DELETE FROM task_results WHERE seq=?", (seq,)).rowcount == 1

    def receipts_after(self, task_id, *, after_seq=0, limit=100):
        """Reconnect reads are side-effect-free and survive outbox acknowledgments."""
        if type(limit) is not int or not 1 <= limit <= 1000 or type(after_seq) is not int or after_seq < 0:
            raise ValueError("cursor or limit")
        with self._lock:
            rows = self._conn.execute("SELECT * FROM task_actions WHERE task_id=? AND result_seq>? ORDER BY result_seq LIMIT ?", (task_id,after_seq,limit)).fetchall()
            return [self._action(row) for row in rows]

    def stats(self):
        with self._lock:
            return {"tasks":self._conn.execute("SELECT count(*) FROM tasks").fetchone()[0],
                    "actions":self._conn.execute("SELECT count(*) FROM task_actions").fetchone()[0],
                    "outbox":self._conn.execute("SELECT count(*) FROM task_results").fetchone()[0],
                    "reserved":self._conn.execute("SELECT count(*) FROM task_actions WHERE state IN ('QUEUED','RUNNING')").fetchone()[0]}
