"""Owned supervised development proposals on the existing task registry.

Private artifacts describe captured inputs; they are never execution evidence.
Root installs this owner before TaskWorker construction. No worker, database,
model transport, event loop, deployment or promotion capability is created.
"""
from contextlib import contextmanager
from dataclasses import asdict, dataclass, fields
import hashlib
import json
import os
from pathlib import Path
import threading

from .improvement_artifacts import (DevelopmentBinding, ImprovementArtifacts, InputFile,
    PrivateArtifact, Replacement, validate_bundle, MAX_BUNDLE_BYTES, _binding)
from .improvement_pipeline import (Change, ImprovementApproval, ImprovementDenied,
    ImprovementPipeline, ImprovementRegistration, CheckEvidence, CheckInputProof, digest, _ref, _sha, _path)
from .task_planner_ingress import ParentConstraint, PlanStepApproval
from .task_planner import goal_digest, StepIdentity


@dataclass(frozen=True)
class ImprovementWorkspace:
    key: str
    project_scope: str
    source_revision: str
    isolation_ref: str
    input_files: tuple
    editable_paths: tuple
    protected_paths: tuple
    required_checks: tuple
    forbidden_roots: tuple


@dataclass(frozen=True)
class RetainedImprovementTrigger:
    kind: str
    reference: str
    principal: str


@dataclass(frozen=True)
class ImprovementRuntimeConfig:
    workspaces: tuple
    enabled: object = lambda: False
    resolve_check_evidence: object = None
    resolve_trigger: object = None
    max_registrations: int = 8
    max_artifact_bytes: int = 16 * 1024 * 1024
    max_approvals: int = 128

    def __post_init__(self):
        if (type(self.workspaces) is not tuple or not 1 <= len(self.workspaces) <= 8
                or any(type(x) is not ImprovementWorkspace for x in self.workspaces)
                or len({x.key for x in self.workspaces}) != len(self.workspaces)
                or not callable(self.enabled)
                or any(value is not None and not callable(value) for value in
                       (self.resolve_check_evidence, self.resolve_trigger))):
            raise TypeError('explicit typed improvement configuration required')
        for value, low, high in ((self.max_registrations,1,32),
            (self.max_artifact_bytes,MAX_BUNDLE_BYTES,32*1024*1024),(self.max_approvals,1,1024)):
            if type(value) is not int or not low <= value <= high:
                raise ValueError('bounded improvement quotas required')
        for workspace in self.workspaces:
            _ref(workspace.key); _ref(workspace.project_scope); _ref(workspace.isolation_ref)
            if (type(workspace.forbidden_roots) is not tuple or not workspace.forbidden_roots
                    or len(workspace.forbidden_roots) > 16):
                raise ValueError('explicit canonical/source/private forbidden roots required')
            _binding(DevelopmentBinding('validate','validate','proposal','parent',workspace.project_scope,
                '/registered',(0,0),0,'0'*64,workspace.isolation_ref,'validate',workspace.source_revision,
                workspace.input_files,workspace.editable_paths,workspace.protected_paths,workspace.required_checks))


@dataclass(frozen=True)
class ImprovementCheckMaterial:
    """Trusted captured material only, explicitly not CheckInputProof."""
    registration: ImprovementRegistration
    development_binding: DevelopmentBinding
    bundle: bytes
    step_key: str
    planner_proposal_sha256: str
    role: str


_SCHEMA = """
CREATE TABLE IF NOT EXISTS improvement_owner_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS improvement_registrations(
 reference TEXT PRIMARY KEY,principal TEXT NOT NULL,fingerprint TEXT NOT NULL,
 workspace_key TEXT NOT NULL,pin_sha256 TEXT NOT NULL,request_json TEXT NOT NULL,
 parent_id TEXT UNIQUE,proposal_id TEXT UNIQUE,development_binding TEXT,registration TEXT,
 artifact BLOB,artifact_sha256 TEXT,state TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS improvement_check_evidence(
 proposal_id TEXT NOT NULL,step_key TEXT NOT NULL,evidence_json TEXT NOT NULL,verification_json TEXT NOT NULL,
 PRIMARY KEY(proposal_id,step_key));
CREATE TABLE IF NOT EXISTS improvement_approvals(
 approval_ref TEXT PRIMARY KEY,submission TEXT UNIQUE NOT NULL,principal TEXT NOT NULL,
 proposal_id TEXT NOT NULL,fingerprint TEXT NOT NULL,combined_review_sha256 TEXT NOT NULL,
 operator_review_sha256 TEXT NOT NULL,summary_json TEXT NOT NULL,approval_json TEXT NOT NULL,
 operator_receipt TEXT NOT NULL,UNIQUE(proposal_id,combined_review_sha256));
"""


_ROW_COLUMNS = ('reference,principal,fingerprint,workspace_key,pin_sha256,request_json,parent_id,'
                'proposal_id,development_binding,registration,artifact_sha256,state')


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _development(value):
    row = json.loads(value)
    row['root_identity'] = tuple(row['root_identity'])
    row['input_files'] = tuple(InputFile(**item) for item in row['input_files'])
    for key in ('editable_paths','protected_paths','required_checks'): row[key] = tuple(row[key])
    return DevelopmentBinding(**row)


def _registration(value):
    row = json.loads(value)
    row['root_identity'] = tuple(row['root_identity'])
    row['changes'] = tuple(Change(**item) for item in row['changes'])
    for key in ('editable_paths','protected_paths','required_checks'): row[key] = tuple(row[key])
    return ImprovementRegistration(**row)


def _absolute(value):
    if (type(value) is not str or not os.path.isabs(value) or os.path.realpath(value) != value
            or os.path.normpath(value) != value or '\0' in value):
        raise ImprovementDenied('explicit unaliased configured root required')
    return value


class ImprovementRuntime:
    def __init__(self, runtime, planner_runtime, configuration):
        if type(configuration) is not ImprovementRuntimeConfig:
            raise TypeError('typed improvement owner configuration required')
        self.runtime, self.planner_runtime, self.configuration = runtime, planner_runtime, configuration
        self._lock = threading.RLock()
        self._stopping, self._calls, self._prepared, self._initialized = False, 0, False, False
        self._pins, self.pipeline, self.artifacts = {}, None, None
        self._pin_hashes = {}
        self._input_proof_resolver = None
        self._constraint_callback = self.approval_constraint

    def selected(self):
        # Pure selector only: never call worker health while ingress owns store locks.
        try:
            return (not self._stopping and not self.runtime._stopping
                    and self.configuration.enabled() is True)
        except Exception:
            return False

    @contextmanager
    def _registry(self):
        with self.runtime._lock:
            if self.runtime._registry is None or self.runtime._store is None or self.runtime._stopping:
                raise ImprovementDenied('existing registry unavailable')
            with self.runtime._store._lock:
                yield self.runtime._registry

    def prepare(self):
        # Root assigns the exact planner owner first, under its startup lock.
        with self.runtime._lock:
            if (getattr(self.runtime, '_improvement_owner', None) is not self
                    or self.runtime._planner_owner is not self.planner_runtime
                    or self.planner_runtime.runtime is not self.runtime
                    or self.planner_runtime.approval_authority is None
                    or self.runtime._started or self.runtime._worker is not None or self._stopping):
                raise ImprovementDenied('exact pre-worker operator planner required')
            self.planner_runtime.ingress.bind_approval_constraint(self._constraint_callback)
            self._prepared = True
            if self.selected(): self._initialize()
            else:
                # Retained metadata remains readable after OFF/restart. This
                # bounded read never creates a schema, artifact or approval.
                with self._registry() as db:
                    retained = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='improvement_owner_meta'").fetchone()
                if retained is not None: self._setup_core()
        return self

    def _pin(self, workspace):
        backend = self.runtime._backend
        found = backend._workspaces.get(workspace.project_scope)
        if found is None: raise ImprovementDenied('configured development workspace required')
        root = _absolute(found[0].root)
        forbidden = tuple(_absolute(x) for x in workspace.forbidden_roots)
        required = (_absolute(os.fspath(self.runtime._directory)),
                    _absolute(str(Path(__file__).resolve().parents[2])))
        if any(not any(os.path.commonpath((target, blocked)) == blocked for blocked in forbidden)
               for target in required):
            raise ImprovementDenied('forbidden roots omit actual private or application source')
        if any(os.path.commonpath((root, blocked)) in (root, blocked) for blocked in forbidden):
            raise ImprovementDenied('development workspace aliases protected state')
        specs = [backend.canonical_resource_spec('project.read_text', {'path': path},
                    {'project_scope': workspace.project_scope}) for path in workspace.editable_paths]
        specs += [backend.canonical_resource_spec('project.run_check', {'check': check},
                    {'project_scope': workspace.project_scope}) for check in workspace.required_checks]
        if not specs or len({(spec.root_identity,spec.configuration_sha256) for spec in specs}) != 1:
            raise ImprovementDenied('exact configured development identity required')
        info = os.stat(root, follow_symlinks=False)
        if (info.st_dev,info.st_ino) != specs[0].root_identity or info.st_uid != os.geteuid():
            raise ImprovementDenied('development root identity or owner changed')
        return {'workspace':asdict(workspace),'root':root,'root_identity':list(specs[0].root_identity),
                'owner_uid':info.st_uid,'configuration_sha256':specs[0].configuration_sha256}

    def _initialize(self):
        with self._lock:
            if self._initialized and self._pins: return
            if not self._prepared or not self.selected():
                raise ImprovementDenied('improvement selection disabled')
            pins = {item.key:self._pin(item) for item in self.configuration.workspaces}
            with self._registry() as db:
                db.executescript(_SCHEMA)
                limits = _json([1,self.configuration.max_registrations,
                    self.configuration.max_artifact_bytes,self.configuration.max_approvals])
                old = db.execute("SELECT value FROM improvement_owner_meta WHERE key='limits'").fetchone()
                if old is not None and old[0] != limits:
                    raise ImprovementDenied('retained improvement limits changed')
                db.execute("INSERT OR IGNORE INTO improvement_owner_meta VALUES ('limits',?)",(limits,))
            self._pins = pins
            self._pin_hashes = {key:digest(pin) for key,pin in pins.items()}
            self._setup_core()

    def _setup_core(self):
        if self.pipeline is not None:
            return
        self.artifacts = ImprovementArtifacts(resolve_binding=self._resolve_binding, enabled=self.selected)
        self.pipeline = ImprovementPipeline(store=self.runtime._store,
            planner=self.planner_runtime.planner, ingress=self.planner_runtime.ingress,
            resolve_registration=self._resolve_registration,
            resolve_plan_context=self.planner_runtime.ingress.resolve_context,
            resolve_approval=self._resolve_approval, resolve_check_evidence=self._resolve_evidence,
            enabled=self.selected, clock=self.runtime._clock)
        self._initialized = True

    @contextmanager
    def _operation(self, principal, *, active=False):
        with self._lock:
            if self._stopping or not self._prepared: raise ImprovementDenied('improvement owner unavailable')
            self._calls += 1
        try:
            with self.planner_runtime._operation(principal, active=active):
                if active:
                    if not self.selected(): raise ImprovementDenied('improvement selection disabled')
                    self._initialize()
                if not self._initialized: raise ImprovementDenied('improvement registry unavailable')
                yield
        finally:
            with self._lock: self._calls -= 1

    def _row(self, task_id, principal):
        with self._registry() as db:
            row = db.execute('SELECT '+_ROW_COLUMNS+' FROM improvement_registrations WHERE proposal_id=? AND principal=?',
                             (task_id,principal)).fetchone()
            if row is None or row['state'] != 'READY': raise ImprovementDenied('ready registered proposal required')
            return dict(row)

    def _resolve_binding(self, reference):
        with self._registry() as db:
            row = db.execute('SELECT development_binding FROM improvement_registrations WHERE reference=?',(reference,)).fetchone()
            return _development(row[0]) if row is not None and row[0] is not None else None

    def _resolve_registration(self, task_id):
        with self._registry() as db:
            row = db.execute("SELECT registration FROM improvement_registrations WHERE proposal_id=? AND state='READY'",(task_id,)).fetchone()
            return _registration(row[0]) if row is not None else None

    def _resolve_approval(self, reference):
        with self._registry() as db:
            row = db.execute('SELECT approval_json FROM improvement_approvals WHERE approval_ref=?',(reference,)).fetchone()
            return ImprovementApproval(**json.loads(row[0])) if row is not None else None

    def _resolve_evidence(self, task_id, step_key):
        # Historical pipeline reads are offline and never invoke proof services.
        with self._registry() as db:
            row = db.execute('SELECT evidence_json FROM improvement_check_evidence WHERE proposal_id=? AND step_key=?',
                             (task_id,step_key)).fetchone()
            if row is None: return None
            value = json.loads(row[0])
            from .improvement_pipeline import CheckInputProof
            value['input_proof'] = CheckInputProof(**value['input_proof'])
            return CheckEvidence(**value)

    def bind_input_proof_resolver(self, resolver):
        with self.runtime._lock:
            if (not callable(resolver) or not self._prepared or self._stopping or self.runtime._stopping
                    or getattr(self.runtime, '_improvement_owner', None) is not self
                    or self.runtime._started or self.runtime._worker is not None):
                raise ImprovementDenied('exact prepared pre-worker proof binding required')
            if self._input_proof_resolver is not None and self._input_proof_resolver is not resolver:
                raise ImprovementDenied('input proof resolver already bound')
            if self.configuration.resolve_check_evidence is not None:
                raise ImprovementDenied('choose one trusted proof resolver')
            self._input_proof_resolver = resolver
        return self

    def _trigger(self, kind, reference, principal):
        _ref(reference)
        if kind == 'executive_request': return
        expected = RetainedImprovementTrigger(kind,reference,principal)
        if (kind not in ('failure_event','maintenance_event') or self.configuration.resolve_trigger is None
                or self.configuration.resolve_trigger(kind,reference,principal) != expected):
            raise ImprovementDenied('actual retained executive event required')

    def register(self, *, principal, workspace_key, goal, replacements, idempotency_key,
                 trigger_kind='executive_request', trigger_ref, approved):
        if approved is not True: raise ImprovementDenied('explicit development proposal authorization required')
        _ref(idempotency_key); _ref(workspace_key)
        with self._operation(principal, active=True):
            self._trigger(trigger_kind,trigger_ref,principal)
            configured = next((x for x in self.configuration.workspaces if x.key == workspace_key),None)
            if configured is None or self._pin(configured) != self._pins[workspace_key]:
                raise ImprovementDenied('configured development binding changed')
            if type(replacements) is not tuple or not 1 <= len(replacements) <= 4:
                raise ImprovementDenied('bounded exact replacements required')
            changes = []
            for item in replacements:
                if type(item) is not Replacement or type(item.content) is not bytes or len(item.content)>8192:
                    raise ImprovementDenied('bounded private replacement bytes required')
                _path(item.path); changes.append([item.path,hashlib.sha256(item.content).hexdigest()])
            pin = self._pins[workspace_key]
            request = {'workspace_key':workspace_key,'pin_sha256':digest(pin),
                'goal_sha256':goal_digest(goal),
                'replacements':changes,'trigger_kind':trigger_kind,'trigger_ref':trigger_ref}
            fingerprint = digest(request)
            reference = 'improvement:'+digest([principal,idempotency_key])
            constraint = ParentConstraint('development_improvement',reference,fingerprint)
            retained_task_id = None
            with self._registry() as db:
                row = db.execute('SELECT '+_ROW_COLUMNS+' FROM improvement_registrations WHERE reference=?',(reference,)).fetchone()
                if row is not None and (row['principal'] != principal or row['fingerprint'] != fingerprint):
                    raise ImprovementDenied('development submission conflicts with retained input')
                if row is None:
                    if db.execute('SELECT count(*) FROM improvement_registrations').fetchone()[0] >= self.configuration.max_registrations:
                        raise ImprovementDenied('development registration quota exhausted')
                    db.execute('INSERT INTO improvement_registrations VALUES (?,?,?,?,?,?,NULL,NULL,NULL,NULL,NULL,NULL,?)',
                        (reference,principal,fingerprint,workspace_key,digest(pin),_json(request),'INTENT'))
                elif row['state'] == 'READY':
                    retained_task_id = row['proposal_id']
            if retained_task_id is not None:
                self.pipeline.offer(retained_task_id,principal=principal)
                return self._status(retained_task_id,principal)
            ingress = self.planner_runtime.ingress
            context = ingress.register_plan(principal=principal,scope=configured.project_scope,goal=goal,
                idempotency_key=reference,authorization_ref='improvement-plan:'+digest(reference),
                approved=True,constraint=constraint)
            self.planner_runtime.planner.initialize(context.task_id,principal=principal,goal=goal)
            submission = 'improvement-task:'+digest(reference)
            task = self.runtime._store.create_task(idempotency_key=submission,project_scope=context.project_scope,
                authorization_ref=reference,priority=70,deadline_wall=context.deadline_wall)
            binding = DevelopmentBinding(reference,principal,task['task_id'],context.task_id,context.project_scope,
                pin['root'],tuple(pin['root_identity']),pin['owner_uid'],pin['configuration_sha256'],
                configured.isolation_ref,reference,configured.source_revision,configured.input_files,
                configured.editable_paths,configured.protected_paths,configured.required_checks)
            with self._registry() as db:
                row = db.execute('SELECT '+_ROW_COLUMNS+' FROM improvement_registrations WHERE reference=?',(reference,)).fetchone()
                if row['parent_id'] not in (None,context.task_id) or row['proposal_id'] not in (None,task['task_id']):
                    raise ImprovementDenied('retained development identity changed')
                if row['development_binding'] not in (None,_json(asdict(binding))):
                    raise ImprovementDenied('retained development source binding changed')
                db.execute('UPDATE improvement_registrations SET parent_id=?,proposal_id=?,development_binding=? WHERE reference=? AND state=?',
                    (context.task_id,task['task_id'],_json(asdict(binding)),reference,'INTENT'))
            artifact = self.artifacts.capture(reference,principal=principal,replacements=replacements)
            metadata = artifact.metadata()
            reg = ImprovementRegistration(principal,task['task_id'],submission,reference,context.task_id,
                digest(asdict(context)),context.project_scope,tuple(pin['root_identity']),pin['configuration_sha256'],
                configured.isolation_ref,configured.source_revision,metadata['source_tree_sha256'],
                metadata['candidate_tree_sha256'],metadata['diff_sha256'],'artifact:'+metadata['artifact_sha256'],
                metadata['artifact_sha256'],tuple(Change(**x) for x in metadata['changes']),
                configured.editable_paths,configured.protected_paths,configured.required_checks,
                trigger_kind,trigger_ref,context.issued_wall,context.deadline_wall)
            if not self.selected() or self._pin(configured) != pin:
                raise ImprovementDenied('development selection or binding changed during capture')
            with self._registry() as db:
                row = db.execute('SELECT '+_ROW_COLUMNS+' FROM improvement_registrations WHERE reference=?',(reference,)).fetchone()
                if (row['fingerprint'] != fingerprint or row['development_binding'] != _json(asdict(binding))
                        or row['parent_id'] != context.task_id or row['proposal_id'] != task['task_id']):
                    raise ImprovementDenied('staged source binding changed during capture')
                if row['state'] == 'READY':
                    if row['artifact_sha256'] != metadata['artifact_sha256']:
                        raise ImprovementDenied('concurrent source capture differs')
                else:
                    used = db.execute('SELECT coalesce(sum(length(artifact)),0) FROM improvement_registrations').fetchone()[0]
                    if used+len(artifact.bundle)>self.configuration.max_artifact_bytes:
                        raise ImprovementDenied('private artifact byte quota exhausted')
                    db.execute("UPDATE improvement_registrations SET registration=?,artifact=?,artifact_sha256=?,state='READY' WHERE reference=? AND state='INTENT'",
                        (_json(asdict(reg)),artifact.bundle,metadata['artifact_sha256'],reference))
            self.pipeline.offer(task['task_id'],principal=principal)
            return self._status(task['task_id'],principal)

    def _status(self, task_id, principal):
        value = self.pipeline.status(task_id,principal=principal)
        if any(step.get('status') == 'EVIDENCE_REQUIRED' for step in value['steps']):
            return {**value,'pipeline_phase':value['phase'],'phase':'EVIDENCE_REQUIRED'}
        return value

    def proposal(self, task_id, *, principal):
        with self._operation(principal): return self._status(task_id,principal)

    def advance(self, task_id, *, principal, retry_interrupted=False):
        with self._operation(principal,active=True):
            row = self._row(task_id,principal)
            status = self.pipeline.status(task_id,principal=principal)
            if status['phase'] in ('READY_FOR_REVIEW','NEEDS_REVIEW') or any(s.get('outcome') != 'SUCCEEDED' for s in status['steps']):
                raise ImprovementDenied('retained receipt or immutable evidence required before inference')
            self.planner_runtime.advance(row['parent_id'],principal=principal,retry_interrupted=retry_interrupted)
            self.pipeline.review_step(task_id,principal=principal)
            return self._status(task_id,principal)

    def _review(self, task_id, principal):
        row = self._row(task_id,principal)
        value = self.pipeline.review_step(task_id,principal=principal)
        operator = self.planner_runtime.review(row['parent_id'],principal=principal)
        summary = value['review']
        if operator['proposal_sha256'] != summary['planner_proposal_sha256']:
            raise ImprovementDenied('operator and development proposals differ')
        combined = digest([value['registration_sha256'],summary['review_sha256'],operator['review_sha256']])
        return {'task_id':task_id,'registration_sha256':value['registration_sha256'],
            'artifact_sha256':value['manifest']['artifact_sha256'],'pipeline_review':summary,
            'operator_review':operator,'review_sha256':combined,'promotion_allowed':False}

    def review(self, task_id, *, principal):
        with self._operation(principal,active=True): return self._review(task_id,principal)

    def approve(self, task_id, *, principal, review_sha256, idempotency_key, validity_s, approved):
        if approved is not True: raise ImprovementDenied('explicit combined reviewed approval required')
        _sha(review_sha256); _ref(idempotency_key)
        if type(validity_s) is not int or not 1 <= validity_s <= 900:
            raise ImprovementDenied('bounded approval lifetime required')
        with self._operation(principal):
            self._row(task_id,principal)
            submission = 'improvement-approval:'+digest([principal,idempotency_key])
            fingerprint = digest([task_id,review_sha256,validity_s])
            with self._registry() as db:
                prior = db.execute('SELECT * FROM improvement_approvals WHERE submission=?',(submission,)).fetchone()
                prior = dict(prior) if prior is not None else None
            if prior is not None:
                if prior['fingerprint'] != fingerprint or prior['principal'] != principal:
                    raise ImprovementDenied('approval key conflicts with reviewed input')
                reference = prior['approval_ref']
                reg = self._resolve_registration(task_id)
                context = self.planner_runtime.ingress.resolve_context(reg.parent_task_id)
                step = json.loads(prior['summary_json'])
                retained = self.planner_runtime.ingress.lookup_step(context=context,step_key=step['step_key'])
                if retained is not None:
                    self._hydrate(task_id,principal)
                    self.pipeline.reconcile(task_id,principal=principal)
                    return {**self._status(task_id,principal),'recovered_approval':True,'child':asdict(retained)}
            else:
                with self.planner_runtime._operation(principal,active=True):
                    if not self.selected(): raise ImprovementDenied('improvement selection disabled')
                    review = self._review(task_id,principal)
                    if review['review_sha256'] != review_sha256:
                        raise ImprovementDenied('combined review changed')
                    operator = review['operator_review']
                    receipt = self.planner_runtime.approval_authority.approve(operator['task_id'],principal=principal,
                        proposal_sha256=operator['proposal_sha256'],review_sha256=operator['review_sha256'],
                        idempotency_key=submission,validity_s=validity_s,approved=True)
                    reference = receipt.approval_ref
                    approval = ImprovementApproval(reference,principal,task_id,review['registration_sha256'],
                        review['pipeline_review']['review_sha256'],receipt.proposal_sha256,receipt.expires_wall,True)
                    values = (reference,submission,principal,task_id,fingerprint,review_sha256,
                        operator['review_sha256'],_json(review['pipeline_review']),_json(asdict(approval)),_json(asdict(receipt)))
                    with self._registry() as db:
                        prior = db.execute('SELECT * FROM improvement_approvals WHERE submission=?',(submission,)).fetchone()
                        if prior is None:
                            if db.execute('SELECT count(*) FROM improvement_approvals').fetchone()[0] >= self.configuration.max_approvals:
                                raise ImprovementDenied('combined approval quota exhausted')
                            db.execute('INSERT INTO improvement_approvals VALUES (?,?,?,?,?,?,?,?,?,?)',values)
                        elif tuple(prior) != values:
                            raise ImprovementDenied('concurrent approval input differs')
            self.pipeline.approve_step(task_id,principal=principal,approval_ref=reference)
            self._hydrate(task_id,principal)
            self.pipeline.reconcile(task_id,principal=principal)
            return self._status(task_id,principal)

    def approval_constraint(self, context, constraint, operator):
        """Pure local registry/store check, called under the ingress locks."""
        if not self._initialized or not self.selected(): return False
        db = self.runtime._registry
        row = db.execute('SELECT '+_ROW_COLUMNS+' FROM improvement_registrations WHERE reference=?',(constraint.reference,)).fetchone()
        if (row is None or row['state'] != 'READY' or row['fingerprint'] != constraint.binding_sha256
                or row['parent_id'] != context.task_id or row['principal'] != context.principal
                or row['pin_sha256'] != self._pin_hashes.get(row['workspace_key'])): return False
        reg = _registration(row['registration'])
        if digest(asdict(context)) != reg.parent_context_sha256: return False
        approved = db.execute('SELECT * FROM improvement_approvals WHERE approval_ref=?',(operator.approval_ref,)).fetchone()
        if (approved is None or approved['proposal_id'] != reg.proposal_task_id
                or approved['operator_receipt'] != _json(asdict(operator))): return False
        authority = ImprovementApproval(**json.loads(approved['approval_json']))
        if (authority.registration_sha256 != digest(asdict(reg))
                or authority.planner_proposal_sha256 != operator.proposal_sha256
                or authority.expires_wall != operator.expires_wall): return False
        task = self.runtime._store.get_task(reg.proposal_task_id)
        if task is None or task['cancel_requested']: return False
        checkpoint = task['checkpoint']
        if (checkpoint.get('registration_sha256') != authority.registration_sha256
                or checkpoint.get('cancel_requested') is not False): return False
        summary = json.loads(approved['summary_json'])
        steps = checkpoint.get('steps')
        if type(steps) is not list or len(steps)>8: return False
        return any(type(step) is dict and step.get('approval_ref') == operator.approval_ref
            and all(step.get(key) == value for key,value in summary.items())
            and step.get('status') in ('DISPATCH_INTENT','QUEUED','RUNNING','EVIDENCE_REQUIRED','SUCCEEDED','FAILED','CANCELLED','UNKNOWN')
            for step in steps)

    def reconcile(self, task_id, *, principal):
        with self._operation(principal):
            self._hydrate(task_id,principal)
            self.pipeline.reconcile(task_id,principal=principal)
            return self._status(task_id,principal)

    def cancel(self, task_id, *, principal):
        with self._operation(principal):
            row = self._row(task_id,principal)
            self.planner_runtime.cancel(row['parent_id'],principal=principal)
            self.pipeline.cancel(task_id,principal=principal)
            return self._status(task_id,principal)

    def _artifact(self, row):
        # The existing SQLite connection is serialized by SQLite itself; this
        # immutable LOB read intentionally holds no runtime/store/pipeline lock.
        # The enclosing operation keeps its connection alive through retirement.
        db = self.runtime._registry
        value = db.execute('SELECT artifact FROM improvement_registrations WHERE reference=? AND artifact_sha256=?',
                           (row['reference'],row['artifact_sha256'])).fetchone()
        if value is None or type(value[0]) is not bytes:
            raise ImprovementDenied('retained private artifact unavailable')
        bundle = value[0]
        if hashlib.sha256(bundle).hexdigest() != row['artifact_sha256']:
            raise ImprovementDenied('private artifact integrity differs')
        artifact = validate_bundle(_development(row['development_binding']),bundle)
        if self._row(row['proposal_id'],row['principal']) != row:
            raise ImprovementDenied('artifact binding changed during validation')
        return artifact

    def artifact(self, task_id, *, principal):
        with self._operation(principal): return self._artifact(self._row(task_id,principal))

    def _material_rows(self, action, task, spec, *, ordinary=False):
        with self._registry() as db:
            saved = self.runtime._store.get_action(action.get('action_id'))
            child = self.runtime._store.get_task(task.get('task_id'))
            if saved != action or child != task or spec.name != 'project.run_check':
                raise ImprovementDenied('exact actual check dispatch required')
            step = db.execute('SELECT * FROM planner_steps WHERE child_id=? AND action_id=?',
                (task['task_id'],action['action_id'])).fetchone()
            if step is None:
                if ordinary and db.execute('SELECT 1 FROM task_submissions WHERE task_id=? AND principal=?',
                    (task['task_id'],self.runtime._principal)).fetchone() is not None:
                    return None
                raise ImprovementDenied('immutable planner child required')
            parent = db.execute('SELECT * FROM planner_plans WHERE task_id=?',(step['parent'],)).fetchone()
            constraint = self.planner_runtime.ingress._registered_constraint(parent)
            if constraint is None and ordinary: return None
            if not self._initialized:
                raise ImprovementDenied('reserved improvement policy unavailable')
            row = db.execute("SELECT "+_ROW_COLUMNS+" FROM improvement_registrations WHERE parent_id=? AND state='READY'",(step['parent'],)).fetchone()
            if row is None or constraint is None or row['reference'] != constraint.reference or row['fingerprint'] != constraint.binding_sha256:
                raise ImprovementDenied('ready reserved development binding required')
            row = dict(row)
            approved = db.execute('SELECT * FROM improvement_approvals WHERE approval_ref=?',(step['approval_ref'],)).fetchone()
            if approved is None: raise ImprovementDenied('combined reviewed approval required')
            summary = json.loads(approved['summary_json'])
            if (summary['role'] not in ('baseline','candidate') or summary['step_key'] != step['step_key']
                    or summary['planner_proposal_sha256'] != step['proposal_sha256']
                    or digest(asdict(spec)) != digest(json.loads(step['spec']))):
                raise ImprovementDenied('exact approved check material differs')
            return row,dict(step),summary

    def proof_required(self, action, task, spec):
        # Classification does not require selection: an OFF/missing owner must
        # never turn a retained reserved child into an ordinary writable check.
        with self.planner_runtime._operation(self.runtime._principal):
            result = self._material_rows(action,task,spec,ordinary=True)
            if result is None: return False
            if not self.selected() or self.planner_runtime.ingress.resolve_child(task['task_id'],active=True) is None:
                raise ImprovementDenied('reserved check authority unavailable')
            return True

    def _check_material(self, action, task, spec, *, active):
        with self._operation(self.runtime._principal,active=active):
            row,step,summary = self._material_rows(action,task,spec)
            if active and self.planner_runtime.ingress.resolve_child(task['task_id'],active=True) is None:
                raise ImprovementDenied('current check authority unavailable')
            artifact = self._artifact(row)
            if self._material_rows(action,task,spec) != (row,step,summary):
                raise ImprovementDenied('retained check binding changed during artifact validation')
            reg = _registration(row['registration'])
            if artifact.metadata()['artifact_sha256'] != reg.artifact_sha256:
                raise ImprovementDenied('registered private artifact differs')
            return ImprovementCheckMaterial(reg,_development(row['development_binding']),
                artifact.bundle,step['step_key'],step['proposal_sha256'],summary['role'])

    def check_material(self, action, task, spec):
        """Root pre-dispatch seam: current authority, captured material, no proof."""
        return self._check_material(action,task,spec,active=True)

    def historical_check_material(self, action, task, spec):
        """Retained receipt verification only; grants no fresh effect authority."""
        return self._check_material(action,task,spec,active=False)

    def _hydrate(self, task_id, principal):
        resolver = self.configuration.resolve_check_evidence
        if resolver is None and self._input_proof_resolver is None: return
        reg = self._resolve_registration(task_id)
        status = self.pipeline.status(task_id,principal=principal)
        for step in status['steps']:
            if step['role'] not in ('baseline','candidate') or self._resolve_evidence(task_id,step['step_key']) is not None:
                continue
            identity = self.planner_runtime.ingress.lookup_step(
                context=self.planner_runtime.ingress.resolve_context(reg.parent_task_id),step_key=step['step_key'])
            if identity is None: continue
            action = self.runtime._store.get_action(identity.action_id)
            if action['state'] != 'SUCCEEDED': continue
            task = self.runtime._store.get_task(identity.task_id)
            spec = self.runtime._backend.canonical_resource_spec(action['name'],action['arguments'],task)
            material = self.historical_check_material(action,task,spec)
            if resolver is not None:
                evidence = resolver(action,task,spec,material)
                verification = {"source":"trusted_external_resolver"}
            else:
                evidence, verification = self._service_evidence(action,task,spec,material)
            if evidence is None: continue
            receipt = {'outcome':action['state'],'result_seq':action['result_seq'],'result_sha256':digest(action['result'])}
            value = ImprovementPipeline._validated_evidence(reg,step,identity,receipt,evidence)
            encoded = _json(value)
            if len(encoded.encode()) > 8192: raise ImprovementDenied('bounded proof evidence required')
            with self._registry() as db:
                if self.runtime._store.get_action(identity.action_id) != action or self._resolve_registration(task_id) != reg:
                    raise ImprovementDenied('persisted result or registration changed during proof lookup')
                old = db.execute('SELECT evidence_json,verification_json FROM improvement_check_evidence WHERE proposal_id=? AND step_key=?',
                                 (task_id,step['step_key'])).fetchone()
                verified = _json(verification)
                if old is not None and tuple(old) != (encoded,verified):
                    raise ImprovementDenied('immutable proof evidence differs')
                db.execute('INSERT OR IGNORE INTO improvement_check_evidence VALUES (?,?,?,?)',(task_id,step['step_key'],encoded,verified))

    def _service_evidence(self, action, task, spec, material):
        proof = self._input_proof_resolver(action,task,spec)
        if proof is None: return None, None
        from .task_check_snapshot import VerifiedInputProof
        if type(proof) is not VerifiedInputProof:
            raise ImprovementDenied('exact verified broker proof required')
        _sha(proof.request_sha256); _sha(proof.runtime_sha256)
        receipt = action['result'].get('immutable_receipt')
        if (type(receipt) is not dict or receipt.get('action_id') != action['action_id']
                or receipt.get('request_sha256') != proof.request_sha256):
            raise ImprovementDenied('proof differs from persisted broker receipt')
        _sha(receipt.get('proof_sha256'))
        value = asdict(proof)
        input_proof = CheckInputProof(**{field.name:value[field.name] for field in fields(CheckInputProof)})
        reg = material.registration
        evidence = CheckEvidence(proof.reference,reg.proposal_task_id,reg.parent_task_id,
            material.step_key,action['action_id'],material.planner_proposal_sha256,
            reg.configuration_sha256,reg.source_tree_sha256 if material.role == 'baseline' else reg.candidate_tree_sha256,
            action['result_seq'],digest(action['result']),input_proof)
        return evidence, {'source':'verified_broker','request_sha256':proof.request_sha256,
                          'runtime_sha256':proof.runtime_sha256,'proof_sha256':receipt['proof_sha256'],
                          'reference':proof.reference}

    def quiesce(self):
        self._stopping = True
        if self.pipeline is not None: self.pipeline.quiesce()
        if self.artifacts is not None: self.artifacts.quiesce()
        return self.drained

    @property
    def drained(self):
        if not self._lock.acquire(blocking=False): return False
        try: return self._calls == 0
        finally: self._lock.release()
