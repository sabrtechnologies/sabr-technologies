"""
Closed-loop cognition runner.

Runs Observe → Predict → Plan → Simulate → Act → Evaluate → Learn → Consolidate
on a background thread, independent of user prompts.

Two modes:

  shadow (default):
    Every reactive tool dispatch (from the responder, autopilot, routines)
    still flows through the existing code unchanged. The cognition loop
    OBSERVES every dispatch via record_tool_call() and writes a closed
    episode with prediction-vs-actual. The loop ITSELF does not pick
    autonomous actions — it only learns.

  active:
    Same observational learning PLUS: the loop generates its own action
    candidates each tick, ranks them by world-model utility × drives × NM
    gates, simulates the top, and fires it through the existing dispatch
    paths. Drive-driven proactive behavior.

We default to shadow because (a) we have no episode data yet so the world
model is just prior, (b) it lets Dean watch behavior change as data
accumulates without surprise actions firing in the meantime.

Candidate generation in active mode pulls from a small set of safe
observation actions: screen_capture, window_list, vision_describe, plus
the routines that are already wired (which already have their own
periodicity). Tool selection is intentionally conservative until the world
model has Brier <0.18 calibration.
"""

from __future__ import annotations

import datetime
import logging
import os
import random
import threading
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from brain.cognition.episodes import Context, EpisodeStore, Prediction
from brain.cognition.snn_gating import SNNGates
from brain.cognition.drives import DriveSystem
from brain.cognition.world_model import WorldModel
from brain.cognition.rollout import Rollout

log = logging.getLogger("leon.cognition.loop")


@dataclass
class ActionCandidate:
    """A potential action the loop is considering for autonomous firing."""
    kind: str               # "tool" | "observe" | "idle"
    name: str
    args: Dict[str, Any] = field(default_factory=dict)
    source: str = "loop"    # who generated this candidate (loop / drive / routine)


# -- Safe autonomous-mode candidate pool. These are all read-only or
# trivially-reversible actions. We never autonomously fire HIGH-risk tools.
_SAFE_AUTONOMOUS_CANDIDATES: List[ActionCandidate] = [
    ActionCandidate("observe", "screen.capture", {}, "loop"),
    ActionCandidate("observe", "window.list", {}, "loop"),
    ActionCandidate("observe", "info.weather_now", {}, "loop"),
    ActionCandidate("idle",    "idle.tick", {}, "loop"),
]


class CognitionLoop:
    """The autonomous cognition runner.

    Thread-safe. Start once at boot via .start(); stop via .stop().
    Even in shadow mode the loop thread runs — it ticks drives, refreshes
    SNN gate cache, and computes calibration metrics periodically.
    """

    def __init__(
        self,
        *,
        brain,
        episodes: EpisodeStore,
        world_model: WorldModel,
        gates: SNNGates,
        drives: DriveSystem,
        rollout: Rollout,
        interval_s: float = 2.0,
        active_action_fn: Optional[Callable[[ActionCandidate], Any]] = None,
        active_app_fn: Optional[Callable[[], Optional[str]]] = None,
        user_present_fn: Optional[Callable[[], bool]] = None,
        # Phase 3 — optional providers from Phase 2 modules
        consolidator: Optional[Any] = None,
        graph: Optional[Any] = None,
    ):
        self.brain = brain
        self.episodes = episodes
        self.world_model = world_model
        self.gates = gates
        self.drives = drives
        self.rollout = rollout
        self.interval_s = interval_s

        # callbacks for active mode
        self._fire = active_action_fn      # how to execute an ActionCandidate
        self._get_active_app = active_app_fn or (lambda: None)
        self._is_user_present = user_present_fn or (lambda: True)

        # Phase 3 — pull-through providers for richer candidate generation
        self._consolidator = consolidator
        self._graph = graph

        # runtime
        self._mode = "shadow"  # 'shadow' | 'active' | 'paused'
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._tick_count = 0
        self._tick_times_ms: List[float] = []
        self._last_recent_action: Optional[str] = None
        self._last_brier: Optional[float] = None
        self._cooldown_until = 0.0  # when active mode may next fire

    # ── lifecycle ────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run, name="cognition-loop", daemon=True,
        )
        self._thread.start()
        log.info("CognitionLoop started in %s mode", self._mode)

    def stop(self) -> None:
        if not self._running:
            return
        self._stop_event.set()
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=5)
        log.info("CognitionLoop stopped")

    def set_mode(self, mode: str) -> None:
        assert mode in ("shadow", "active", "paused"), mode
        log.info("CognitionLoop mode %s → %s", self._mode, mode)
        self._mode = mode

    def mode(self) -> str:
        return self._mode

    # ── observational API (called from tool dispatch path) ───────────────

    def record_tool_call(
        self,
        tool_name: str,
        tool_args: Dict[str, Any],
        result: Any,
        latency_ms: float,
        *,
        kind: str = "tool",
        success_override: Optional[bool] = None,
        error: Optional[str] = None,
    ) -> Optional[int]:
        """Called by the actuator wrapper or in-process tool dispatch.

        Builds context, asks world model to predict (so we capture pred-vs-actual),
        records episode pre+post in one shot. Returns episode id.

        Does NOT execute the tool — that's the caller's job. We just write
        the episode after the caller has the result.
        """
        try:
            context = self._build_context()
            salience = self.gates.current().memory_salience
            pred = self.world_model.predict(kind, tool_name, tool_args, context)

            ep_id = self.episodes.record(
                action_kind=kind,
                action_name=tool_name,
                action_args=tool_args,
                prediction=pred,
                context=context,
                salience=salience,
            )

            success = self._infer_success(result) if success_override is None else success_override
            side_effects = self._infer_side_effects(tool_name, tool_args, result)
            error_text = error or self._infer_error_text(result)

            self.episodes.close(
                ep_id,
                success=bool(success),
                latency_ms=float(latency_ms),
                error=error_text,
                side_effects=side_effects,
                post_nm=self._current_nm(),
            )

            # Reuse the just-closed episode dict for learning signals
            closed = {
                "action_name": tool_name,
                "arg_signature": "",  # invalidator doesn't need exact sig for action_name match
                "bucket": context.bucket,
            }
            self.world_model.update(closed)
            self.drives.on_episode(
                action_name=tool_name,
                success=bool(success),
                surprise=abs(pred.p_success - (1.0 if success else 0.0)),
                prediction_confidence=pred.confidence,
            )

            # Causal SNN reward: surprise on failure → small negative pulse,
            # surprise on success → small positive pulse. The brain already
            # handles dopamine folding so we just call reward_pulse.
            try:
                surprise = abs(pred.p_success - (1.0 if success else 0.0))
                if surprise > 0.25:
                    pulse = (0.25 + 0.4 * surprise) if success else -(0.15 + 0.3 * surprise)
                    pulse *= salience  # ACh weights how much this episode "matters"
                    self.brain.reward_pulse(pulse, source=f"cognition.{tool_name}")
            except Exception:
                pass

            self._last_recent_action = tool_name
            return ep_id
        except Exception as e:
            log.warning("record_tool_call failed: %s", e)
            return None

    # ── loop thread ──────────────────────────────────────────────────────

    def _run(self) -> None:
        while not self._stop_event.wait(self.interval_s):
            tick_start = time.monotonic()
            try:
                self._tick()
            except Exception:
                log.error("tick failed: %s", traceback.format_exc())
            tick_ms = (time.monotonic() - tick_start) * 1000.0
            self._tick_times_ms.append(tick_ms)
            if len(self._tick_times_ms) > 100:
                self._tick_times_ms.pop(0)
            self._tick_count += 1
            # Refresh calibration every ~50 ticks (~100s at default interval)
            if self._tick_count % 50 == 0:
                cal = self.episodes.calibration(hours=24)
                if cal.get("brier") is not None:
                    self._last_brier = cal["brier"]

    def _tick(self) -> None:
        # 1. Decay drives
        self.drives.tick()

        if self._mode == "paused":
            return

        # 2. Refresh gates by reading once
        gates = self.gates.current()

        if self._mode == "shadow":
            # In shadow we don't act autonomously; observational learning
            # happens via record_tool_call() from the dispatch path.
            return

        # 3. Active mode: cooldown so we don't spam actions
        now = time.monotonic()
        if now < self._cooldown_until:
            return

        # 4. Build context and generate candidates
        context = self._build_context()
        candidates = self._generate_candidates(context, gates)
        if not candidates:
            return

        # 5. Simulate each → pick best executable
        explore = random.random() < gates.exploration_rate
        sims = [
            self.rollout.simulate(c.kind, c.name, c.args, context, explore=explore)
            for c in candidates
        ]
        sims.sort(key=lambda s: -s.utility)
        choice = sims[0]

        if choice.recommendation != "execute":
            # Loud feedback to drives — we observed and chose not to act
            self.drives.on_prediction(choice.prediction.p_success, choice.prediction.confidence)
            return

        # 6. Fire
        if self._fire is None:
            # No execution callback wired — this is a dry-run active mode.
            log.info("[active dry-run] would fire %s util=%.2f", choice.action_name, choice.utility)
            self._cooldown_until = now + 10.0
            return

        candidate = ActionCandidate(
            kind=choice.action_kind, name=choice.action_name, args=choice.action_args,
            source="cognition_loop",
        )
        try:
            t_act = time.monotonic()
            result = self._fire(candidate)
            latency_ms = (time.monotonic() - t_act) * 1000.0
            self.record_tool_call(
                candidate.name, candidate.args, result, latency_ms,
                kind=candidate.kind,
            )
            self._cooldown_until = now + max(5.0, choice.prediction.latency_ms / 1000.0)
        except Exception as e:
            self.record_tool_call(
                candidate.name, candidate.args, None, 0.0,
                kind=candidate.kind, success_override=False, error=str(e),
            )
            self._cooldown_until = now + 15.0

    # ── context + candidate helpers ──────────────────────────────────────

    def _build_context(self) -> Context:
        now = time.time()
        nm = self._current_nm()
        ctx = Context(
            ts=now,
            nm=nm,
            dev_stage=getattr(self.brain, "development_stage", "UNKNOWN"),
            active_app=self._safe_active_app(),
            hour=datetime.datetime.now().hour,
            dow=datetime.datetime.now().weekday(),
            recent_action=self._last_recent_action,
            user_present=self._safe_user_present(),
        )
        ctx.compute_bucket()
        return ctx

    def _current_nm(self) -> Dict[str, float]:
        try:
            nm = getattr(self.brain, "neuromodulators", None) or {}
            return {k: float(v) for k, v in nm.items()}
        except Exception:
            return {}

    def _safe_active_app(self) -> Optional[str]:
        try:
            return self._get_active_app()
        except Exception:
            return None

    def _safe_user_present(self) -> bool:
        try:
            return bool(self._is_user_present())
        except Exception:
            return True

    def _generate_candidates(
        self, context: Context, gates,
    ) -> List[ActionCandidate]:
        """Active-mode candidate generation.

        Conservative: starts with safe observation tools, biased by loudest
        drive, then augmented with Phase 3 sources when available:
          - Phase 2 consolidator hypotheticals (predicted-utility ranked)
          - Phase 2 graph: what usually follows the last successful action

        All non-whitelist candidates are still filtered by Rollout against
        the gate's confidence_threshold — so the safety floor holds even
        when external sources inject creative suggestions.
        """
        if not self._is_user_present():
            return [
                ActionCandidate("tool", "self_state.save", {}, "loop"),
                ActionCandidate("idle", "idle.tick", {}, "loop"),
            ]

        loudest = self.drives.loudest()
        out = list(_SAFE_AUTONOMOUS_CANDIDATES)

        # Drive-biased prepends
        if loudest == "anomaly":
            out.insert(0, ActionCandidate("observe", "screen.capture", {}, "drive:anomaly"))
        elif loudest == "uncertainty":
            out.insert(0, ActionCandidate("tool", "knowledge.search",
                                          {"query": context.active_app or ""},
                                          "drive:uncertainty"))
        elif loudest == "continuity":
            out.insert(0, ActionCandidate("tool", "self_state.save", {}, "drive:continuity"))

        # Phase 3 — consolidator hypotheticals
        if self._consolidator is not None:
            try:
                last = self._consolidator.last_pass() or {}
                hyps = last.get("hypotheticals") or []
                for h in hyps[:3]:
                    name = h.get("action")
                    if not name:
                        continue
                    # Only safe (low-side-effect, observation-shaped) actions
                    if self._is_safe_for_active(name):
                        out.append(ActionCandidate("tool", name, {}, "consolidator"))
            except Exception:
                pass

        # Phase 3 — graph: what usually follows the last successful action
        if self._graph is not None and self._last_recent_action:
            try:
                ent = self._graph.find_entity("action", self._last_recent_action)
                if ent:
                    for nxt in self._graph.neighbors(int(ent["id"]),
                                                     relation="precedes", limit=3):
                        name = nxt.get("name")
                        if name and self._is_safe_for_active(name):
                            out.append(ActionCandidate("tool", name, {},
                                                       "graph:precedes"))
            except Exception:
                pass

        return out

    # Hardcoded whitelist of action prefixes that are always safe to fire
    # autonomously. The Rollout still gets a vote via confidence_threshold,
    # but this is the hard floor — we never auto-fire anything outside this.
    _ACTIVE_SAFE_PREFIXES = (
        "screen.capture", "screen_capture",
        "window.list", "window_list",
        "info.", "knowledge.search", "knowledge_search",
        "browser.dom_state", "browser_dom_state",
        "browser.dom_extract", "browser_dom_extract",
        "vision.describe", "vision_describe",
        "webcam.capture", "webcam_capture",
        "memory.recall", "memory_recall",
        "research.",
        "self_state.save",
        "idle.tick",
    )

    @classmethod
    def _is_safe_for_active(cls, action_name: str) -> bool:
        n = (action_name or "").lower()
        return any(n.startswith(p) for p in cls._ACTIVE_SAFE_PREFIXES)

    @staticmethod
    def _infer_success(result: Any) -> bool:
        """Best-effort success extraction from heterogeneous result shapes."""
        if result is None:
            return False
        if isinstance(result, bool):
            return result
        if isinstance(result, dict):
            if "ok" in result:
                return bool(result["ok"])
            if "error" in result and result["error"]:
                return False
            if "success" in result:
                return bool(result["success"])
            return True
        return True

    @staticmethod
    def _infer_error_text(result: Any) -> Optional[str]:
        if isinstance(result, dict):
            err = result.get("error")
            if err:
                return str(err)[:500]
        return None

    @staticmethod
    def _infer_side_effects(tool_name: str, args: Dict[str, Any], result: Any) -> List[str]:
        """Lightweight tagging of side-effects from tool name shape."""
        tags: List[str] = []
        n = tool_name.lower()
        # Network call
        if any(x in n for x in ("http", "fetch", "request", "search", "browser", "gmail",
                                "calendar", "discord", "slack", "twilio")):
            tags.append("network")
        # State change on host
        if any(x in n for x in ("file_write", "code_edit", "app_launch", "app_close",
                                "shell_exec", "keyboard_type", "clipboard_copy", "mouse_click",
                                "keyboard_hotkey", "window_move", "macro", "scene")):
            tags.append("state-change")
        # Persistence
        if any(x in n for x in ("knowledge", "memory", "save", "checkpoint", "store")):
            tags.append("persistence")
        # Sensor / observation
        if any(x in n for x in ("capture", "list", "extract", "describe", "read", "state")):
            tags.append("observation")
        return tags

    # ── introspection ────────────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        avg_tick_ms = (sum(self._tick_times_ms) / len(self._tick_times_ms)) \
            if self._tick_times_ms else 0.0
        p95_tick_ms = (sorted(self._tick_times_ms)[int(len(self._tick_times_ms) * 0.95)]) \
            if len(self._tick_times_ms) >= 20 else avg_tick_ms
        return {
            "mode": self._mode,
            "running": self._running,
            "tick_count": self._tick_count,
            "interval_s": self.interval_s,
            "avg_tick_ms": round(avg_tick_ms, 1),
            "p95_tick_ms": round(p95_tick_ms, 1),
            "last_brier_24h": self._last_brier,
            "cooldown_remaining_s": max(0, round(self._cooldown_until - time.monotonic(), 1)),
        }
