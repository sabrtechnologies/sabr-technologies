"""Tick-owned, content-free memory SHADOW bridge; importing performs no I/O.

The context path may only call offer()/stats(). Canonical path inspection,
submission and polling belong to the existing cognition tick. No extra loop is
created here; MemoryRuntime owns the sole retrieval worker.
"""
from collections import deque
import math
import threading
import time


class MemoryShadow:
    """Every enabled mode is SHADOW, with explicit unscoped legacy policy.

    Callbacks must be bounded. Tick-owned lifecycle callbacks may inspect flag
    metadata; telemetry may write the root's bounded diagnostic sidecar. Neither
    is called by offer()/stats(). authorize(record) must preserve the root's
    existing autobiography filter, without network or canonical write effects;
    SourcePolicy separately rejects restricted rows without a trusted binding.
    A changed authorization policy requires a new owner after stop() succeeds.
    """

    def __init__(self, *, state, configured_mode, live_mode, runtime_accepting,
                 authorize, telemetry=None, policy_revision="legacy-shadow-v1",
                 offer_limit=16, pending_limit=8, submit_budget=2, poll_budget=4,
                 request_ttl=15.0, clock=time.monotonic,
                 thought_intent_config=None, thought_intent_requested=None,
                 thought_principal=None):
        self._state = state
        self._configured_mode = configured_mode
        self._live_mode = live_mode
        self._runtime_accepting = runtime_accepting
        self._authorize = authorize
        self._telemetry = telemetry
        self._revision = policy_revision
        self._clock = clock
        self._offer_limit = max(1, min(64, int(offer_limit)))
        self._pending_limit = max(1, min(32, int(pending_limit)))
        self._submit_budget = max(1, min(8, int(submit_budget)))
        self._poll_budget = max(1, min(16, int(poll_budget)))
        self._ttl = float(request_ttl)
        if not math.isfinite(self._ttl) or not 0 < self._ttl <= 60:
            raise ValueError("request_ttl must be finite and within (0, 60]")
        if not isinstance(policy_revision, str) or not policy_revision or len(policy_revision) > 128:
            raise ValueError("explicit bounded policy revision required")
        self._mailbox = threading.Lock()
        self._lifecycle = threading.Lock()
        self._disabled = threading.Event()
        self._stopping = False
        self._retired = False
        self._accepting = False
        self._offers = deque()
        self._pending = deque()
        self._owner = None
        self._policy = None
        self._reason = "off"
        self._counts = {"offered": 0, "dropped": 0, "submitted": 0,
                        "completed": 0, "references": 0, "expired": 0,
                        "discarded": 0, "failures": 0}
        self._snapshot = self._view()
        # Independent explicit thought_intents selection. Retrieval modes above
        # remain SHADOW; no generic canonical writer or second lifecycle slot.
        self._thought_intents = None
        if thought_intent_config is not None:
            from .thought_intent_runtime import ThoughtIntentRuntime
            if not callable(thought_intent_requested):
                raise TypeError('explicit thought intent selection callback required')
            self._thought_intents = ThoughtIntentRuntime(state=state,
                config=thought_intent_config,
                requested=lambda: (not self._stopping and self._runtime_accepting() is True
                                   and thought_intent_requested() is True),
                principal=thought_principal)

    def _requested(self):
        try:
            return (not self._stopping and self._configured_mode in ("shadow", "canary", "on")
                    and callable(self._authorize) and self._runtime_accepting()
                    and self._live_mode() in ("shadow", "canary", "on"))
        except Exception:
            return False

    def _view(self):
        # No identifiers, paths, digests, trace IDs, source values or query text.
        active = self._reason == "shadow" and not self._stopping and not self._disabled.is_set()
        return {"mode": "shadow" if active else "off", "reason": self._reason,
                "scope": "unscoped_legacy" if active else "inactive",
                "metadata_only": True, "embeddings_enabled": False,
                "canonical_writes": False, "has_owner": self._owner is not None,
                "stopping": self._stopping, "retired": self._retired,
                "queued": len(self._offers), "pending": len(self._pending),
                **self._counts}

    def _publish_snapshot(self):
        self._snapshot = self._view()

    def stats(self):
        """Cached public metadata only: no callbacks, runtime calls or I/O."""
        snapshot = dict(self._snapshot)
        if self._stopping or self._disabled.is_set():
            snapshot.update(mode="off", scope="inactive", stopping=self._stopping)
        intent_owner = self._thought_intents
        snapshot['thought_intents'] = (intent_owner.stats() if intent_owner is not None else
            {'configured': False, 'active_leases': 0, 'prepared': False,
             'stopping': self._stopping, 'retired': self._retired})
        return snapshot

    def thought_configuration_matches(self, config):
        """Installer must check before reusing this exact lifecycle owner."""
        if self._stopping or self._retired:
            return False
        if self._thought_intents is None:
            return config is None
        return self._thought_intents.configuration_matches(config)

    def open_thought_intent(self):
        """Capture one private operation lifetime; selected errors never fall back."""
        from .thought_intent_runtime import ThoughtIntentUnavailable
        if self._stopping or self._retired or self._thought_intents is None:
            raise ThoughtIntentUnavailable('configured thought intent owner required')
        return self._thought_intents.open()

    def offer(self, query, trace_id=""):
        """Use tick-cached admission; no flag, owner or policy callbacks here."""
        if not self._accepting or self._stopping:
            return False
        if (not isinstance(query, str) or len(query) > 4096 or not query.strip()
                or len(query.encode("utf-8")) > 4096
                or not isinstance(trace_id, str) or len(trace_id) > 128):
            return False
        if self._disabled.is_set() or not self._mailbox.acquire(blocking=False):
            return False
        try:
            if not self._accepting or self._stopping or self._disabled.is_set():
                return False
            if len(self._offers) >= self._offer_limit:
                self._counts["dropped"] += 1
                self._publish_snapshot()
                return False
            self._offers.append((query, trace_id, self._clock() + self._ttl))
            self._counts["offered"] += 1
            self._publish_snapshot()
            return True
        finally:
            self._mailbox.release()

    def _clear(self):
        self._accepting = False
        with self._mailbox:
            self._counts["discarded"] += len(self._offers) + len(self._pending)
            self._offers.clear()
            self._pending.clear()
            self._publish_snapshot()

    def _drain_owner(self, timeout):
        if self._owner is None:
            return True
        if not self._owner.close(timeout=timeout):
            self._reason = "worker_retirement_pending"
            return False
        self._owner = None
        return True

    def tick(self):
        """Called by the existing cognition loop; bounded submits/polls only."""
        if not self._lifecycle.acquire(blocking=False):
            return
        completed = expired = references = 0
        try:
            requested = self._requested()
            if not requested or self._disabled.is_set():
                self._disabled.set()
                self._reason = "stopping" if self._stopping else "off"
                self._clear()
                if not self._drain_owner(0):
                    return
                if not requested:
                    return
                self._disabled.clear()
            if self._stopping:
                return
            if self._owner is None:
                # Relative imports preserve hermetic package loading in tests.
                from ..memory_runtime import MemoryRuntime
                from ..memory_service import SourcePolicy
                if self._policy is None:
                    self._policy = SourcePolicy(principal=None, identity_id=None,
                                                authorize=self._authorize)
                self._owner = MemoryRuntime(self._state, mode="shadow", policy=self._policy,
                    policy_revision=self._revision, sidecar_path=None,
                    queue_limit=self._pending_limit, cache_limit=self._pending_limit,
                    ttl_s=self._ttl)
            if not self._requested() or self._disabled.is_set():
                self._disabled.set()
                self._reason = "off"
                self._clear()
                self._drain_owner(0)
                return
            self._reason = "shadow"
            self._accepting = True
            scope = dict(principal=None, identity_id=None, policy_revision=self._revision)
            # Rotate pending tickets for fairness; never poll unbounded backlog.
            for _ in range(min(self._poll_budget, len(self._pending))):
                if not self._requested() or self._disabled.is_set():
                    break
                ticket, deadline = self._pending.popleft()
                if deadline <= self._clock():
                    expired += 1
                    continue
                result = self._owner.poll(ticket, **scope)
                if result is None:
                    self._pending.append((ticket, deadline))
                else:
                    completed += 1
                    references += len(result.references)
                    result = None  # Do not retain internal references in the wrapper.
            for _ in range(self._submit_budget):
                if (len(self._pending) >= self._pending_limit or not self._requested()
                        or self._disabled.is_set()):
                    break
                with self._mailbox:
                    if not self._offers:
                        break
                    query, trace_id, deadline = self._offers.popleft()
                try:
                    if deadline <= self._clock():
                        expired += 1
                        continue
                    ticket = self._owner.submit(query, trace_id=trace_id, **scope)
                    if ticket is not None:
                        self._pending.append((ticket, deadline))
                        self._counts["submitted"] += 1
                    else:
                        self._counts["dropped"] += 1
                finally:
                    query = trace_id = None
            # Revocation observed during a metadata read suppresses this batch.
            if not self._requested() or self._disabled.is_set():
                self._disabled.set()
                self._reason = "off"
                self._clear()
                self._drain_owner(0)
                return
            self._counts["completed"] += completed
            self._counts["references"] += references
            self._counts["expired"] += expired
            if (completed or expired) and self._telemetry is not None:
                # Injected callback receives fixed scalar keys only. Root chooses
                # its destination; exceptions and record data are never logged.
                self._telemetry({"mode": "shadow", "scope": "unscoped_legacy",
                    "completed": completed, "references": references,
                    "expired": expired, "metadata_only": True})
        except Exception:
            self._accepting = False
            self._counts["failures"] += 1
            self._reason = "tick_failed"
            self._disabled.set()
        finally:
            self._publish_snapshot()
            self._lifecycle.release()

    def quiesce(self):
        """Immediate cutoff without waiting for tick, a worker, or metadata I/O."""
        self._stopping = True
        self._accepting = False
        self._disabled.set()
        if self._thought_intents is not None:
            self._thought_intents.quiesce()

    def stop(self, *, join_timeout=0.25):
        """Retain this owner until True; retry while an owned read is draining."""
        self.quiesce()
        if not self._lifecycle.acquire(blocking=False):
            return False
        try:
            self._reason = "stopping"
            self._clear()
            if not self._drain_owner(max(0.0, min(5.0, float(join_timeout)))):
                return False
            if self._thought_intents is not None and not self._thought_intents.stop():
                self._reason = 'thought_retirement_pending'
                return False
            self._retired = True
            self._reason = "retired"
            return True
        except Exception:
            self._counts["failures"] += 1
            self._reason = "retirement_failed"
            return False
        finally:
            self._publish_snapshot()
            self._lifecycle.release()

    @property
    def retired(self):
        return self._retired
