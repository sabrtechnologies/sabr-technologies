"""
Episode log — the cognitive substrate.

Every action Leon takes (tool call, response, observation, idle decision) is
recorded as an Episode with: pre-state context, the action, the prediction
made BEFORE the action, the actual outcome, and learning signals derived
from the prediction-vs-actual gap (surprise, reward, salience).

This is the table that world_model.py learns from, that drives.py reads to
detect failure streaks, and that future graph-memory / self-model layers
will mine for entities, recurrence, and continuity.

Design notes
------------
* SQLite with WAL mode — concurrent readers don't block the cognition loop.
* Append-only writes; updates only touch one row to close it.
* All time is unix-seconds. All NM values are 0..1.
* The DB lives in brain_state/episodes.db so it survives restarts.
* check_same_thread=False because the cognition loop, the actuator wrapper
  in the tool-dispatch path, and the API endpoints will all hit it.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


# ── Data classes ────────────────────────────────────────────────────────────

@dataclass
class Prediction:
    """What the world model thought would happen before the action ran."""
    p_success: float = 0.5          # 0..1 probability of success
    latency_ms: float = 500.0       # expected wall time
    confidence: float = 0.0         # how trustworthy p_success is (data depth, 0..1)
    p_side_effects: float = 0.0     # estimated probability of irreversible side-effects
    method: str = "prior"           # "prior" | "freq" | "context_knn" | "blend"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Context:
    """Pre-action environmental snapshot. Used as the key for retrieval."""
    ts: float = 0.0
    nm: Dict[str, float] = field(default_factory=lambda: {
        "dopamine": 0.5, "acetylcholine": 0.3,
        "norepinephrine": 0.1, "serotonin": 0.5,
    })
    dev_stage: str = "UNKNOWN"
    active_app: Optional[str] = None
    hour: int = 0                   # 0..23
    dow: int = 0                    # 0=Mon..6=Sun
    recent_action: Optional[str] = None  # name of the previous action this session
    user_present: bool = False
    bucket: str = ""                # combined coarse key for frequency grouping

    def compute_bucket(self) -> str:
        """Coarse context key — small alphabet so frequency tables don't fragment."""
        hour_band = "night" if self.hour < 7 or self.hour >= 22 else \
                    "morn" if self.hour < 12 else \
                    "aft"  if self.hour < 18 else "eve"
        nm_band = "".join(
            "h" if self.nm.get(k, 0.5) > 0.66 else
            "l" if self.nm.get(k, 0.5) < 0.34 else "m"
            for k in ("dopamine", "norepinephrine", "acetylcholine", "serotonin")
        )
        app = (self.active_app or "?")[:16]
        pres = "p" if self.user_present else "a"
        self.bucket = f"{hour_band}|{nm_band}|{app}|{pres}"
        return self.bucket

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Episode:
    """One open-then-closed action with its prediction and outcome."""
    id: int = 0
    ts: float = 0.0
    context: Context = field(default_factory=Context)
    action_kind: str = "tool"       # "tool" | "response" | "observe" | "idle" | "shadow"
    action_name: str = ""
    action_args: Dict[str, Any] = field(default_factory=dict)
    arg_signature: str = ""
    prediction: Prediction = field(default_factory=Prediction)

    # outcome (None until closed)
    success: Optional[bool] = None
    latency_ms: Optional[float] = None
    error: Optional[str] = None
    side_effects: List[str] = field(default_factory=list)

    # learning signals
    surprise: float = 0.0           # |p_success_predicted - actual_outcome|
    reward: float = 0.0             # derived; positive = good, negative = bad
    salience: float = 1.0           # weighted by ACh at encoding time

    # post-state delta (NM drift over the action; small but informative)
    post_nm: Dict[str, float] = field(default_factory=dict)

    parent_id: Optional[int] = None
    session_id: str = ""

    def is_open(self) -> bool:
        return self.success is None and self.latency_ms is None


# ── Arg signature normalization ─────────────────────────────────────────────

_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")
_URL_RE = re.compile(r"https?://[^\s\"]+")
_PATH_RE = re.compile(r"(?:/[\w.\-]+){2,}")


def arg_signature(args: Dict[str, Any]) -> str:
    """Normalize args into a pattern string — same shape ↔ same signature.

    "browser.goto(url=https://soundcloud.com)" and
    "browser.goto(url=https://gmail.com)" both → "url=<url>".

    The signature is what the world model groups by, so it should be
    coarse enough to aggregate sensibly but fine enough to separate truly
    different call patterns.
    """
    if not args:
        return "()"
    parts = []
    for k in sorted(args.keys()):
        v = args[k]
        if isinstance(v, str):
            if _URL_RE.match(v):
                pat = "<url>"
            elif _PATH_RE.match(v):
                pat = "<path>"
            elif _NUM_RE.fullmatch(v):
                pat = "<numstr>"
            elif len(v) > 40:
                pat = "<longstr>"
            elif len(v) == 0:
                pat = "<empty>"
            else:
                pat = "<str>"
        elif isinstance(v, bool):
            pat = "<bool>"
        elif isinstance(v, (int, float)):
            pat = "<num>"
        elif isinstance(v, list):
            pat = f"<list:{len(v)}>"
        elif isinstance(v, dict):
            pat = f"<dict:{len(v)}>"
        elif v is None:
            pat = "<null>"
        else:
            pat = f"<{type(v).__name__}>"
        parts.append(f"{k}={pat}")
    return "(" + ",".join(parts) + ")"


# ── The store ───────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS episodes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              REAL NOT NULL,
    session_id      TEXT,
    parent_id       INTEGER,
    -- context (pre-state)
    nm_dopamine     REAL,
    nm_acetylcholine REAL,
    nm_norepinephrine REAL,
    nm_serotonin    REAL,
    dev_stage       TEXT,
    active_app      TEXT,
    hour_of_day     INTEGER,
    day_of_week     INTEGER,
    bucket          TEXT,
    recent_action   TEXT,
    user_present    INTEGER,
    -- action
    action_kind     TEXT,
    action_name     TEXT,
    action_args_json TEXT,
    arg_signature   TEXT,
    -- prediction
    pred_success    REAL,
    pred_latency_ms REAL,
    pred_confidence REAL,
    pred_side_eff   REAL,
    pred_method     TEXT,
    -- outcome
    success         INTEGER,
    latency_ms      REAL,
    error_text      TEXT,
    side_effects_json TEXT,
    -- learning
    surprise        REAL,
    reward          REAL,
    salience        REAL,
    -- post-state
    post_nm_json    TEXT
);

CREATE INDEX IF NOT EXISTS idx_episodes_action
    ON episodes(action_name, arg_signature);
CREATE INDEX IF NOT EXISTS idx_episodes_ts
    ON episodes(ts);
CREATE INDEX IF NOT EXISTS idx_episodes_bucket
    ON episodes(bucket, action_name);
CREATE INDEX IF NOT EXISTS idx_episodes_app
    ON episodes(active_app, action_name);
CREATE INDEX IF NOT EXISTS idx_episodes_success
    ON episodes(action_name, success);
"""


def _default_db_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "episodes.db")


class EpisodeStore:
    """Thread-safe append-only episode log on SQLite with WAL."""

    def __init__(self, path: Optional[str] = None):
        self.path = path or _default_db_path()
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False, timeout=5.0)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.commit()
        self.session_id = f"sess_{int(time.time())}_{os.getpid()}"
        self._open_episodes: Dict[int, Episode] = {}  # id → open Episode in memory

    # -- write path --------------------------------------------------------

    def record(
        self,
        action_kind: str,
        action_name: str,
        action_args: Dict[str, Any],
        prediction: Prediction,
        context: Context,
        *,
        salience: float = 1.0,
        parent_id: Optional[int] = None,
    ) -> int:
        """Open an episode. Returns id; pass to close() with outcome."""
        if not context.bucket:
            context.compute_bucket()
        sig = arg_signature(action_args)
        with self._lock:
            cur = self._conn.execute(
                """
                INSERT INTO episodes (
                    ts, session_id, parent_id,
                    nm_dopamine, nm_acetylcholine, nm_norepinephrine, nm_serotonin,
                    dev_stage, active_app, hour_of_day, day_of_week, bucket,
                    recent_action, user_present,
                    action_kind, action_name, action_args_json, arg_signature,
                    pred_success, pred_latency_ms, pred_confidence,
                    pred_side_eff, pred_method,
                    salience
                ) VALUES (?,?,?, ?,?,?,?, ?,?,?,?,?, ?,?, ?,?,?,?, ?,?,?, ?,?, ?)
                """,
                (
                    context.ts or time.time(), self.session_id, parent_id,
                    context.nm.get("dopamine", 0.5),
                    context.nm.get("acetylcholine", 0.3),
                    context.nm.get("norepinephrine", 0.1),
                    context.nm.get("serotonin", 0.5),
                    context.dev_stage, context.active_app, context.hour, context.dow,
                    context.bucket, context.recent_action, int(context.user_present),
                    action_kind, action_name,
                    json.dumps(action_args, default=str)[:8000], sig,
                    prediction.p_success, prediction.latency_ms,
                    prediction.confidence, prediction.p_side_effects, prediction.method,
                    salience,
                ),
            )
            self._conn.commit()
            ep_id = cur.lastrowid
            ep = Episode(
                id=ep_id, ts=context.ts or time.time(), context=context,
                action_kind=action_kind, action_name=action_name,
                action_args=action_args, arg_signature=sig, prediction=prediction,
                salience=salience, parent_id=parent_id, session_id=self.session_id,
            )
            self._open_episodes[ep_id] = ep
        return ep_id

    def close(
        self,
        ep_id: int,
        *,
        success: bool,
        latency_ms: float,
        error: Optional[str] = None,
        side_effects: Optional[List[str]] = None,
        post_nm: Optional[Dict[str, float]] = None,
    ) -> Optional[Episode]:
        """Close an open episode with its outcome. Returns the closed Episode."""
        with self._lock:
            ep = self._open_episodes.pop(ep_id, None)
        side_effects = side_effects or []
        # surprise: how wrong was the prediction?
        actual = 1.0 if success else 0.0
        surprise = float(abs((ep.prediction.p_success if ep else 0.5) - actual))
        # reward: success gets +1 weighted by surprise (unexpected wins reward more);
        # failure gets -1 weighted by surprise (unexpected failures hurt more);
        # confident-and-right gets a small positive (learning is consolidating).
        if success:
            reward = 0.3 + 0.7 * surprise
        else:
            reward = -(0.3 + 0.7 * surprise)
        # multiply by salience so high-ACh episodes count more downstream
        reward *= (ep.salience if ep else 1.0)

        with self._lock:
            self._conn.execute(
                """
                UPDATE episodes SET
                    success = ?, latency_ms = ?, error_text = ?,
                    side_effects_json = ?, surprise = ?, reward = ?,
                    post_nm_json = ?
                WHERE id = ?
                """,
                (
                    int(success), float(latency_ms), error,
                    json.dumps(side_effects)[:4000],
                    surprise, reward,
                    json.dumps(post_nm or {}),
                    ep_id,
                ),
            )
            self._conn.commit()
        if ep:
            ep.success = success
            ep.latency_ms = latency_ms
            ep.error = error
            ep.side_effects = side_effects
            ep.surprise = surprise
            ep.reward = reward
            ep.post_nm = post_nm or {}
            return ep
        return None

    # -- read path ---------------------------------------------------------

    def recent(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM episodes ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def by_action(
        self,
        action_name: str,
        arg_sig: Optional[str] = None,
        *,
        hours: int = 168,
        limit: int = 200,
    ) -> List[Dict[str, Any]]:
        since = time.time() - hours * 3600
        with self._lock:
            if arg_sig:
                rows = self._conn.execute(
                    """SELECT * FROM episodes WHERE action_name=? AND arg_signature=?
                       AND ts > ? AND success IS NOT NULL
                       ORDER BY id DESC LIMIT ?""",
                    (action_name, arg_sig, since, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    """SELECT * FROM episodes WHERE action_name=?
                       AND ts > ? AND success IS NOT NULL
                       ORDER BY id DESC LIMIT ?""",
                    (action_name, since, limit),
                ).fetchall()
        return [dict(r) for r in rows]

    def by_bucket(
        self,
        bucket: str,
        action_name: Optional[str] = None,
        *,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        with self._lock:
            if action_name:
                rows = self._conn.execute(
                    """SELECT * FROM episodes WHERE bucket=? AND action_name=?
                       AND success IS NOT NULL ORDER BY id DESC LIMIT ?""",
                    (bucket, action_name, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    """SELECT * FROM episodes WHERE bucket=?
                       AND success IS NOT NULL ORDER BY id DESC LIMIT ?""",
                    (bucket, limit),
                ).fetchall()
        return [dict(r) for r in rows]

    def success_rate(
        self,
        action_name: str,
        arg_sig: Optional[str] = None,
        *,
        hours: int = 168,
    ) -> Dict[str, float]:
        """Beta-posterior success rate with sample count + 90% interval edges."""
        since = time.time() - hours * 3600
        with self._lock:
            if arg_sig:
                row = self._conn.execute(
                    """SELECT COUNT(*) AS n, SUM(success) AS s
                       FROM episodes WHERE action_name=? AND arg_signature=?
                       AND ts > ? AND success IS NOT NULL""",
                    (action_name, arg_sig, since),
                ).fetchone()
            else:
                row = self._conn.execute(
                    """SELECT COUNT(*) AS n, SUM(success) AS s
                       FROM episodes WHERE action_name=?
                       AND ts > ? AND success IS NOT NULL""",
                    (action_name, since),
                ).fetchone()
        n = int(row["n"] or 0)
        s = int(row["s"] or 0)
        # Beta(1, 1) prior → posterior mean = (s+1)/(n+2)
        mean = (s + 1) / (n + 2)
        # confidence rises with n; ~0 at n=0, ~0.9 at n=20
        conf = 1.0 - (1.0 / (1.0 + n / 5.0))
        return {"n": n, "mean": float(mean), "confidence": float(conf)}

    def latency_p50(
        self,
        action_name: str,
        arg_sig: Optional[str] = None,
        *,
        hours: int = 168,
    ) -> Optional[float]:
        since = time.time() - hours * 3600
        with self._lock:
            if arg_sig:
                rows = self._conn.execute(
                    """SELECT latency_ms FROM episodes
                       WHERE action_name=? AND arg_signature=?
                       AND ts > ? AND latency_ms IS NOT NULL
                       ORDER BY id DESC LIMIT 200""",
                    (action_name, arg_sig, since),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    """SELECT latency_ms FROM episodes
                       WHERE action_name=? AND ts > ? AND latency_ms IS NOT NULL
                       ORDER BY id DESC LIMIT 200""",
                    (action_name, since),
                ).fetchall()
        if not rows:
            return None
        vals = sorted(r["latency_ms"] for r in rows)
        return float(vals[len(vals) // 2])

    def side_effects_for(
        self,
        action_name: str,
        *,
        hours: int = 168,
    ) -> Dict[str, int]:
        """Count distinct side-effect tags seen for an action."""
        since = time.time() - hours * 3600
        with self._lock:
            rows = self._conn.execute(
                """SELECT side_effects_json FROM episodes
                   WHERE action_name=? AND ts > ?
                   AND side_effects_json IS NOT NULL""",
                (action_name, since),
            ).fetchall()
        out: Dict[str, int] = {}
        for r in rows:
            try:
                tags = json.loads(r["side_effects_json"] or "[]")
                for t in tags:
                    out[t] = out.get(t, 0) + 1
            except (json.JSONDecodeError, TypeError):
                pass
        return out

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            row = self._conn.execute(
                """SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN success IS NOT NULL THEN 1 ELSE 0 END) AS closed,
                    SUM(success) AS successes,
                    AVG(surprise) AS avg_surprise,
                    AVG(reward) AS avg_reward
                   FROM episodes WHERE ts > ?""",
                (time.time() - 7 * 86400,),
            ).fetchone()
        return {
            "total_7d": int(row["total"] or 0),
            "closed_7d": int(row["closed"] or 0),
            "successes_7d": int(row["successes"] or 0),
            "avg_surprise_7d": float(row["avg_surprise"] or 0),
            "avg_reward_7d": float(row["avg_reward"] or 0),
            "session_id": self.session_id,
            "db_path": self.path,
        }

    def calibration(self, hours: int = 24) -> Dict[str, Any]:
        """Brier score (mean squared error of probabilistic forecasts).

        Lower is better. 0 = perfect calibration. 0.25 = coin flip.
        This is the headline 'is the world model getting better?' metric.
        """
        since = time.time() - hours * 3600
        with self._lock:
            rows = self._conn.execute(
                """SELECT pred_success, success FROM episodes
                   WHERE ts > ? AND success IS NOT NULL AND pred_success IS NOT NULL""",
                (since,),
            ).fetchall()
        n = len(rows)
        if n == 0:
            return {"n": 0, "brier": None}
        brier = sum((r["pred_success"] - r["success"]) ** 2 for r in rows) / n
        return {"n": n, "brier": float(brier), "hours": hours}

    def prune_older_than(self, *, days: int = 30) -> int:
        """H1 fix: delete episodes older than N days. Returns rows deleted.

        Called periodically by consolidation. Without rotation, episodes.db
        grows ~megabytes/day at Phase 11 cadence and full-table scans
        (calibration, success_rate) get slower over time.
        """
        cutoff = time.time() - days * 86400
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM episodes WHERE ts < ?", (cutoff,)
            )
            deleted = cur.rowcount or 0
            self._conn.commit()
        return int(deleted)

    def close_db(self) -> None:
        with self._lock:
            self._conn.close()
