"""
World model — predicts what will happen before Leon acts.

Lightweight predictor that returns estimates of:
  - p_success     probability the action will return ok=True / not raise
  - latency_ms    expected wall-clock time
  - p_side_effects probability of irreversible / hard-to-undo consequences
  - confidence    how much data backs the above (0..1)

Three signal sources, blended:

1. PRIOR — hand-coded prior per tool family based on risk tier (low/med/high
   from actuator_client.TOOL_RISK) and action kind. Used when no episodes
   exist for this (action, signature, bucket).
2. FREQUENCY — Beta-posterior success rate over closed episodes filtered
   by (action_name, arg_signature). Grows confidence as data accrues.
3. CONTEXT k-NN — same as frequency but filtered also by context bucket
   (hour band × NM band × app × user-presence). Lets us say
   "browser_dom_click usually works during day with high ACh but fails at
   night when serotonin is low."

The blend weights itself by confidence: when context-specific data exists
in volume, lean on it; when it's thin, fall back to global frequency or
prior. No external ML deps — everything is closed-form arithmetic over
SQLite rows.

Cached: a small LRU on (action_name, arg_signature, bucket) → Prediction
flushed every 60s so repeated predictions in a tick don't re-query SQLite.
"""

from __future__ import annotations

import time
import math
from collections import OrderedDict
from dataclasses import dataclass
from threading import Lock
from typing import Any, Dict, Optional, Tuple

from brain.cognition.episodes import (
    Context, EpisodeStore, Prediction, arg_signature,
)


# ── Priors ──────────────────────────────────────────────────────────────────
# Used when no episodes exist yet for an action. Roughly: cheap+local tools
# are reliable, network tools have moderate failure rate, browser tools are
# the flakiest (CDP drops, page loads, race conditions), shell is risky.
_RISK_PRIOR_P_SUCCESS = {
    "low":    0.92,
    "medium": 0.78,
    "high":   0.65,
}
_RISK_PRIOR_LATENCY = {
    "low":    150.0,
    "medium": 600.0,
    "high":   2000.0,
}
_RISK_PRIOR_SIDE_EFFECTS = {
    "low":    0.02,
    "medium": 0.10,
    "high":   0.45,
}

# Action-kind overrides — generic patterns that beat the per-tool prior
_KIND_PRIORS = {
    "observe": Prediction(p_success=0.95, latency_ms=120, confidence=0.2,
                          p_side_effects=0.0, method="prior"),
    "idle":    Prediction(p_success=1.00, latency_ms=0,   confidence=1.0,
                          p_side_effects=0.0, method="prior"),
    "response": Prediction(p_success=0.92, latency_ms=2500, confidence=0.3,
                           p_side_effects=0.0, method="prior"),
}


def _tool_risk(action_name: str) -> str:
    """Look up risk tier from actuator_client.TOOL_RISK, fallback to medium."""
    try:
        from brain.actuator_client import TOOL_RISK
        # Tools are stored both as 'screen_capture' and 'screen.capture' in
        # different places — try both forms.
        if action_name in TOOL_RISK:
            return TOOL_RISK[action_name]
        alt = action_name.replace(".", "_")
        if alt in TOOL_RISK:
            return TOOL_RISK[alt]
        alt2 = action_name.replace("_", ".", 1)
        if alt2 in TOOL_RISK:
            return TOOL_RISK[alt2]
    except Exception:
        pass
    return "medium"


@dataclass(frozen=True)
class CachedForecast:
    """Detached cache observation; confidence remains source data-depth metadata."""
    p_success: float
    latency_ms: float
    confidence: float
    p_side_effects: float
    method: str
    cached_mono: float


class WorldModel:
    """Outcome predictor with online updates; empirical calibration is separate."""

    def __init__(self, episodes: EpisodeStore, cache_ttl_s: float = 60.0,
                 cache_size: int = 512):
        self.episodes = episodes
        self._cache_ttl_s = cache_ttl_s
        self._cache_size = cache_size
        self._cache: "OrderedDict[Tuple[str, str, str], Tuple[float, Prediction]]" = OrderedDict()
        self._lock = Lock()
        # rolling counters for the metric endpoint
        self._predictions_made = 0
        self._cache_hits = 0

    # -- public predict ---------------------------------------------------

    def predict(
        self,
        action_kind: str,
        action_name: str,
        action_args: Dict[str, Any],
        context: Context,
    ) -> Prediction:
        """Return a Prediction for this (kind, name, args, context).

        Blends prior + global frequency + context-specific frequency. The
        blend weights itself by data depth — thin data → lean on prior.
        """
        self._predictions_made += 1
        if not context.bucket:
            context.compute_bucket()
        sig = arg_signature(action_args)
        cache_key = (action_name, sig, context.bucket)

        with self._lock:
            cached = self._cache.get(cache_key)
            if cached is not None:
                ts, pred = cached
                if (time.monotonic() - ts) < self._cache_ttl_s:
                    self._cache.move_to_end(cache_key)
                    self._cache_hits += 1
                    return pred

        prior = self._prior(action_kind, action_name)

        # Global frequency for this exact (action, sig)
        global_rate = self.episodes.success_rate(action_name, sig)
        # Context-bucketed: just this action in this bucket
        ctx_rows = self.episodes.by_bucket(context.bucket, action_name, limit=50)
        ctx_rate = self._rate_from_rows(ctx_rows)

        # Blend
        w_prior = 1.0
        w_global = global_rate["n"]              # raw count
        w_ctx = ctx_rate["n"]
        wsum = w_prior + w_global + w_ctx
        p_success = (
            w_prior * prior.p_success
            + w_global * global_rate["mean"]
            + w_ctx * ctx_rate["mean"]
        ) / wsum

        # Latency: prefer context median, then global median, then prior
        latency = self._best_latency(action_name, sig, context.bucket) or prior.latency_ms

        # Side effects: count distinct reversibility-tagged events
        p_side = self._side_effect_prob(action_name) or prior.p_side_effects

        # Confidence: rises with total data depth, soft-saturating at n=20
        n_total = global_rate["n"]
        confidence = 1.0 - (1.0 / (1.0 + n_total / 5.0))
        if ctx_rate["n"] >= 5:
            # context-specific data raises confidence further
            confidence = min(1.0, confidence + 0.1)

        method = "prior" if n_total == 0 else \
                 "context_knn" if ctx_rate["n"] >= 5 else \
                 "freq" if n_total >= 3 else "blend"

        pred = Prediction(
            p_success=float(p_success),
            latency_ms=float(latency),
            confidence=float(confidence),
            p_side_effects=float(p_side),
            method=method,
        )

        with self._lock:
            self._cache[cache_key] = (time.monotonic(), pred)
            if len(self._cache) > self._cache_size:
                self._cache.popitem(last=False)

        return pred

    # -- update (called after each closed episode) ------------------------

    def peek_cached(self, action_name, action_args, *, context_bucket, max_age_s,
                    now_mono=None):
        """Strict read-only lookup, never predict/build context/query/invalidate.

        Uses the model's exact existing (name, normalized signature, bucket)
        key. The signature is deliberately coarse: this is not a claim of exact
        raw argument equality. No counters, LRU position or cache bytes change.
        Unknown, expired, contended or malformed inputs return None.
        """
        if (type(action_name) is not str or not action_name or len(action_name) > 128
                or type(context_bucket) is not str or not context_bucket or len(context_bucket) > 512
                or type(action_args) is not dict or len(action_args) > 64
                or type(max_age_s) not in (int, float) or not math.isfinite(max_age_s)
                or not 0 < max_age_s <= self._cache_ttl_s):
            return None
        for key, value in action_args.items():
            if type(key) is not str or len(key) > 128 or type(value) not in (str, bool, int, float, list, dict, type(None)):
                return None
            if type(value) is str and len(value) > 4096:
                return None
        now = time.monotonic() if now_mono is None else now_mono
        if type(now) not in (int, float) or not math.isfinite(now) or now < 0:
            return None
        signature = arg_signature(action_args)
        if not self._lock.acquire(blocking=False):
            return None
        try:
            entry = self._cache.get((action_name, signature, context_bucket))
            if type(entry) is not tuple or len(entry) != 2:
                return None
            stamp, prediction = entry
            if (type(stamp) not in (int, float) or not math.isfinite(stamp)
                    or not 0 <= now - stamp < max_age_s or type(prediction) is not Prediction):
                return None
            values = (prediction.p_success, prediction.confidence, prediction.p_side_effects)
            if any(type(v) not in (int, float) or not math.isfinite(v) or not 0 <= v <= 1 for v in values):
                return None
            if (type(prediction.latency_ms) not in (int, float) or not math.isfinite(prediction.latency_ms)
                    or prediction.latency_ms < 0 or type(prediction.method) is not str
                    or not prediction.method or len(prediction.method) > 100):
                return None
            return CachedForecast(float(prediction.p_success), float(prediction.latency_ms),
                float(prediction.confidence), float(prediction.p_side_effects),
                "cached_" + prediction.method, float(stamp))
        finally:
            self._lock.release()

    def update(self, episode_dict_or_id: Any) -> None:
        """Invalidate cached predictions touched by a new episode.

        Frequency tables are computed live from SQLite so we just bust the
        relevant cache entries — no separate model to retrain.
        """
        if isinstance(episode_dict_or_id, dict):
            action_name = episode_dict_or_id.get("action_name", "")
            sig = episode_dict_or_id.get("arg_signature", "")
            bucket = episode_dict_or_id.get("bucket", "")
        else:
            return  # nothing to invalidate
        with self._lock:
            stale_keys = [k for k in self._cache
                          if k[0] == action_name and (k[1] == sig or k[2] == bucket)]
            for k in stale_keys:
                self._cache.pop(k, None)

    # -- internals --------------------------------------------------------

    def _prior(self, action_kind: str, action_name: str) -> Prediction:
        if action_kind in _KIND_PRIORS:
            return _KIND_PRIORS[action_kind]
        risk = _tool_risk(action_name)
        return Prediction(
            p_success=_RISK_PRIOR_P_SUCCESS[risk],
            latency_ms=_RISK_PRIOR_LATENCY[risk],
            confidence=0.0,
            p_side_effects=_RISK_PRIOR_SIDE_EFFECTS[risk],
            method="prior",
        )

    @staticmethod
    def _rate_from_rows(rows: list) -> Dict[str, Any]:
        n = len(rows)
        if n == 0:
            return {"n": 0, "mean": 0.5}
        s = sum(1 for r in rows if r.get("success"))
        mean = (s + 1) / (n + 2)
        return {"n": n, "mean": mean}

    def _best_latency(self, action_name: str, sig: str, bucket: str) -> Optional[float]:
        # Try context-specific first
        ctx_rows = self.episodes.by_bucket(bucket, action_name, limit=50)
        latencies = [r["latency_ms"] for r in ctx_rows
                     if r.get("latency_ms") is not None]
        if len(latencies) >= 5:
            return float(sorted(latencies)[len(latencies) // 2])
        # Fall back to action+sig global
        return self.episodes.latency_p50(action_name, sig)

    def _side_effect_prob(self, action_name: str) -> float:
        rows = self.episodes.by_action(action_name, limit=200)
        if not rows:
            return 0.0
        with_effects = sum(1 for r in rows
                           if r.get("side_effects_json") and r["side_effects_json"] != "[]")
        return with_effects / len(rows)

    # -- introspection ----------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "predictions_made": self._predictions_made,
                "cache_hits": self._cache_hits,
                "cache_size": len(self._cache),
                "cache_hit_rate": (self._cache_hits / max(1, self._predictions_made)),
            }
