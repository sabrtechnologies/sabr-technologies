"""Bounded caller-facing retirement of the already installed V2 owners.

One finite daemon helper performs existing stop methods outside signal/ASGI
callers. It owns no model, action, database or replacement runtime. A stuck
owner call remains explicitly pending and retains this helper and its handles.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import math
import sys
import threading
import time


DEFAULT_TIMEOUT_S = 5.0
_BEGIN_LOCK = threading.Lock()
_MODULE = "brain.cognition.inference_scheduler"
_OWNERS = ("tasks", "speech", "providers", "prediction", "memory", "sensory")
_ALIASES = (("task_runtime", "tasks"), ("speech_runtime", "speech"),
            ("provider_hooks", "providers"), ("memory_shadow", "memory"))


def _seconds(value, maximum=12.0):
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= maximum:
        raise ValueError("finite shutdown budget required")
    return float(value)


@dataclass(frozen=True)
class ShutdownReceipt:
    selected: bool
    complete: bool
    timed_out: bool
    helper_alive: bool
    attempts: int
    pending: tuple[str, ...]
    errors: tuple[str, ...]
    elapsed_s: float

    def log_line(self):
        return ("[V2] shutdown retirement=" + ("COMPLETE" if self.complete else "PENDING")
                + f" selected={self.selected} timed_out={self.timed_out}"
                + f" helper_alive={self.helper_alive} attempts={self.attempts}"
                + f" pending={','.join(self.pending) or '-'}"
                + f" errors={','.join(self.errors) or '-'} elapsed_s={self.elapsed_s:.3f}")


class ShutdownRetirement:
    """Captured identities live until actual retirement, including after timeout."""
    def __init__(self, state, *, timeout_s):
        self.state = state
        self.runtime = getattr(state, "cognitive_runtime", None)
        self.owners = tuple((name, getattr(self.runtime, name, None)) for name in _OWNERS)
        self.provider_binding = getattr(state, "v2_provider_binding", None)
        self.facade = sys.modules.get(_MODULE)
        self.scheduler = getattr(state, "inference_scheduler", None)
        self.ledger = None
        self._errors = ()
        self._identity_failed = False
        if self.facade is not None:
            try:
                published = self.facade.get_scheduler()
                self.ledger = self.facade.get_ledger()
                if self.scheduler is not None and published is not self.scheduler:
                    self._identity_failed = True
                if self.scheduler is None:
                    self.scheduler = published
            except Exception as exc:
                self._error("capture", exc)
                self._identity_failed = True
        elif self.scheduler is not None:
            self._identity_failed = True
        self._same_runtime()
        if self.provider_binding is not None and (
                getattr(self.provider_binding, "runtime", None) is not self.runtime
                or getattr(self.provider_binding, "scheduler", None) is not self.scheduler
                or getattr(self.provider_binding, "owner", None) is not dict(self.owners)["providers"]):
            self._identity_failed = True
        self.selected = (self.runtime is not None or self.scheduler is not None
                         or self.ledger is not None or self._identity_failed)
        self._runtime_complete = self.runtime is None
        self._scheduler_complete = self.scheduler is None and self.ledger is None and not self._identity_failed
        self._started = time.monotonic()
        self._deadline = self._started + _seconds(timeout_s)
        self._attempts = 0
        self._complete = not self.selected
        self._done = threading.Event()
        self._thread = None
        if self._complete:
            self._done.set()

    def _error(self, stage, error):
        item = stage + ":" + type(error).__name__
        if item not in self._errors and len(self._errors) < 8:
            self._errors = self._errors + (item,)

    def start(self):
        if self._thread is None and not self._done.is_set():
            self._thread = threading.Thread(target=self._run, name="v2-shutdown-retirement", daemon=True)
            self._thread.start()
        return self

    def _same_runtime(self):
        if getattr(self.state, "cognitive_runtime", None) is not self.runtime:
            self._identity_failed = True
            return False
        for name, owner in self.owners:
            if getattr(self.runtime, name, None) is not owner:
                self._identity_failed = True
                return False
        owners = dict(self.owners)
        for alias, name in _ALIASES:
            exposed = getattr(self.state, alias, None)
            if exposed is not None and exposed is not owners[name]:
                self._identity_failed = True
                return False
        binding = getattr(self.state, "v2_provider_binding", None)
        if binding is not None and binding is not self.provider_binding:
            self._identity_failed = True
            return False
        return True

    def _stop_runtime(self, seconds):
        if self.runtime is None or not self._same_runtime():
            return
        try:
            self.runtime.stop(join_timeout=seconds)
            self._runtime_complete = self.runtime.retirement_complete() is True
        except Exception as exc:
            self._runtime_complete = False
            self._error("runtime", exc)

    def _stop_scheduler(self, seconds):
        if self.facade is None:
            # Missing facade is never permission to infer ledger retirement.
            if self.scheduler is not None:
                try:
                    self.scheduler.stop(join_timeout=0)
                except Exception as exc:
                    self._error("scheduler", exc)
            return
        lock = getattr(self.facade, "_LIFECYCLE", None)
        if lock is None:
            self._identity_failed = True
            return
        if not lock.acquire(timeout=min(.025, seconds)):
            return
        try:
            current = self.facade.get_scheduler()
            ledger = self.facade.get_ledger()
            state_scheduler = getattr(self.state, "inference_scheduler", None)
            if (sys.modules.get(_MODULE) is not self.facade
                    or (state_scheduler is not None and state_scheduler is not self.scheduler)
                    or (current is not None and current is not self.scheduler)
                    or (ledger is not None and ledger is not self.ledger)):
                self._identity_failed = True
                return
            # None is allowed only after this exact captured owner has drained.
            if current is None and self.scheduler is not None and self.scheduler.worker_alive():
                self._identity_failed = True
                return
            if ledger is None and self.ledger is not None and self.ledger.alive():
                self._identity_failed = True
                return
            if self._identity_failed:
                return
            retired = self.facade.uninstall(join_timeout=seconds)
            self._scheduler_complete = (retired is True
                and self.facade.get_scheduler() is None and self.facade.get_ledger() is None
                and (self.scheduler is None or not self.scheduler.worker_alive())
                and (self.ledger is None or not self.ledger.alive()))
        except Exception as exc:
            self._scheduler_complete = False
            self._error("scheduler", exc)
        finally:
            lock.release()

    def _run(self):
        try:
            # Quiesce task/planner/provider selection before scheduler retirement.
            # Every potentially blocking owner operation stays on this helper.
            self._stop_runtime(0)
            self._stop_scheduler(0)
            if self._same_runtime() and self._runtime_complete and self._scheduler_complete and not self._identity_failed:
                self._complete = True
                return
            while not self._identity_failed:
                remaining = self._deadline - time.monotonic()
                if remaining <= 0:
                    break
                self._attempts += 1
                self._stop_scheduler(min(.025, remaining))
                remaining = self._deadline - time.monotonic()
                if remaining > 0:
                    self._stop_runtime(min(.025, remaining))
                if self._same_runtime() and self._runtime_complete and self._scheduler_complete:
                    self._complete = True
                    break
                remaining = self._deadline - time.monotonic()
                if remaining > 0:
                    self._done.wait(min(.025, remaining))
        except Exception as exc:
            self._error("retirement", exc)
        finally:
            self._done.set()

    def receipt(self):
        pending = []
        if not self._runtime_complete:
            pending.append("runtime")
        if not self._scheduler_complete:
            pending.append("scheduler_ledger")
        if self._identity_failed:
            pending.append("owner_identity")
        elapsed = time.monotonic() - self._started
        complete = self._complete and self._done.is_set() and not self._identity_failed
        return ShutdownReceipt(self.selected, complete,
            not complete and time.monotonic() >= self._deadline,
            self._thread is not None and self._thread.is_alive(), self._attempts,
            tuple(pending), self._errors, max(0.0, elapsed))

    def wait(self, timeout=None):
        remaining = max(0.0, self._deadline - time.monotonic())
        budget = remaining if timeout is None else min(remaining, _seconds(timeout))
        self._done.wait(budget)
        return self.receipt()

    async def wait_async(self, timeout=None):
        remaining = max(0.0, self._deadline - time.monotonic())
        budget = remaining if timeout is None else min(remaining, _seconds(timeout))
        deadline = time.monotonic() + budget
        while not self._done.is_set():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            await asyncio.sleep(min(.025, remaining))
        return self.receipt()


def begin_shutdown(state, *, timeout_s=DEFAULT_TIMEOUT_S):
    """Idempotent across ASGI and signal paths; never clear captured state refs."""
    _seconds(timeout_s)
    if not _BEGIN_LOCK.acquire(timeout=.025):
        raise RuntimeError("shutdown coordinator busy")
    try:
        existing = getattr(state, "_v2_shutdown_retirement", None)
        if existing is not None:
            if type(existing) is not ShutdownRetirement or existing.state is not state:
                raise RuntimeError("shutdown coordinator identity differs")
            if not existing._same_runtime():
                raise RuntimeError("shutdown owner identity changed")
            current = sys.modules.get(_MODULE)
            scheduler = getattr(state, "inference_scheduler", None)
            published = current.get_scheduler() if current is not None else None
            ledger = current.get_ledger() if current is not None else None
            if (getattr(state, "cognitive_runtime", None) is not existing.runtime
                    or (scheduler is not None and scheduler is not existing.scheduler)
                    or current is not existing.facade
                    or (published is not None and published is not existing.scheduler)
                    or (ledger is not None and ledger is not existing.ledger)):
                raise RuntimeError("shutdown owner identity changed")
            return existing
        session = ShutdownRetirement(state, timeout_s=timeout_s)
        state._v2_shutdown_retirement = session
        return session.start()
    finally:
        _BEGIN_LOCK.release()
