"""Supervised development proposals on existing TaskStore/planner ownership.

No scan, model, executor, worker, database connection, outbox consumer or promotion
is created here. Trusted registration/approval/source-attestation services remain
explicit integration dependencies. Checkpoints retain metadata, never source or
private tool output. Call methods from the existing executive's bounded work.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import math
import re
import threading
import time

from .task_planner import PlanContext, StepIdentity


class ImprovementDenied(RuntimeError):
    pass


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()


def _sha(value):
    if type(value) is not str or not re.fullmatch('[0-9a-f]{64}', value):
        raise ImprovementDenied('exact SHA256 required')


def _ref(value):
    if type(value) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}', value):
        raise ImprovementDenied('bounded operational reference required')


def _path(value):
    if (type(value) is not str or not 0 < len(value.encode('utf-8')) <= 256
            or '\\' in value or ':' in value or '\0' in value
            or any(part in ('', '.', '..', '.git', '.hg', '.svn') for part in value.split('/'))):
        raise ImprovementDenied('bounded relative source path required')


_SUMMARY_KEYS = ('step_key', 'step', 'planner_proposal_sha256', 'role', 'target',
                 'name', 'arguments_sha256', 'spec_sha256', 'resources_sha256', 'tier')


@dataclass(frozen=True)
class Change:
    path: str
    before_sha256: str
    after_sha256: str


@dataclass(frozen=True)
class ImprovementRegistration:
    """Resolved from trusted immutable registration, never a model checkpoint.

    editable_paths excludes canonical stores, identity and policy targets.
    protected_paths is the integrator's explicit deny list, checked independently.
    isolation_ref attests a managed development checkout with no live aliases.
    Artifact generation and verifying its exact diff/source are external gates.
    """
    principal: str
    proposal_task_id: str
    submission_id: str
    authorization_ref: str
    parent_task_id: str
    parent_context_sha256: str
    workspace_scope: str
    root_identity: tuple[int, int]
    configuration_sha256: str
    isolation_ref: str
    source_revision: str
    source_tree_sha256: str
    candidate_tree_sha256: str
    diff_sha256: str
    artifact_ref: str
    artifact_sha256: str
    changes: tuple[Change, ...]
    editable_paths: tuple[str, ...]
    protected_paths: tuple[str, ...]
    required_checks: tuple[str, ...]
    trigger_kind: str
    trigger_ref: str
    issued_wall: float
    deadline_wall: float


@dataclass(frozen=True)
class ImprovementApproval:
    reference: str
    principal: str
    proposal_task_id: str
    registration_sha256: str
    review_sha256: str
    planner_proposal_sha256: str
    expires_wall: float
    approved: bool


@dataclass(frozen=True)
class CheckInputProof:
    """Trusted execution-owner attestation, not caller-supplied hash assertions.

    The resolver must verify complete immutable check inputs and hold enforced
    mutation exclusion until all descendants drain. Equal before/after hashes
    alone cannot prove that the check did not transiently substitute its source.
    A normal writable project.run_check boundary cannot issue this proof.
    """
    reference: str
    snapshot_ref: str
    mode: str
    action_id: str
    planner_proposal_sha256: str
    configuration_sha256: str
    artifact_sha256: str
    input_tree_sha256: str
    completion_tree_sha256: str
    mutation_excluded: bool
    held_until_drain: bool
    namespace_drained: bool
    process_drained: bool


@dataclass(frozen=True)
class CheckEvidence:
    """Trusted same-attempt source, isolation and completion binding."""
    reference: str
    proposal_task_id: str
    parent_task_id: str
    step_key: str
    action_id: str
    planner_proposal_sha256: str
    configuration_sha256: str
    tree_sha256: str
    result_seq: int
    result_sha256: str
    input_proof: CheckInputProof


class ImprovementPipeline:
    def __init__(self, *, store, planner, ingress, resolve_registration,
                 resolve_plan_context, resolve_approval, resolve_check_evidence,
                 enabled=lambda: False, clock=time.time):
        if not all(callable(x) for x in (resolve_registration, resolve_plan_context,
                                        resolve_approval, resolve_check_evidence, enabled, clock)):
            raise TypeError('explicit trusted resolvers required')
        self.store, self.planner, self.ingress = store, planner, ingress
        self._registration, self._context = resolve_registration, resolve_plan_context
        self._approval, self._evidence = resolve_approval, resolve_check_evidence
        self._enabled, self._clock = enabled, clock
        self._lock, self._stopping = threading.RLock(), False

    def _access(self, task_id, principal, *, active=False):
        if active and (self._stopping or self._enabled() is not True):
            raise ImprovementDenied('improvement selection disabled')
        reg = self._registration(task_id)
        if type(reg) is not ImprovementRegistration or reg.principal != principal or reg.proposal_task_id != task_id:
            raise ImprovementDenied('trusted principal and proposal registration required')
        for name in ('principal', 'proposal_task_id', 'submission_id', 'authorization_ref',
                     'parent_task_id', 'workspace_scope', 'isolation_ref', 'artifact_ref', 'trigger_ref'):
            _ref(getattr(reg, name))
        for name in ('parent_context_sha256', 'configuration_sha256', 'source_tree_sha256',
                     'candidate_tree_sha256', 'diff_sha256', 'artifact_sha256'):
            _sha(getattr(reg, name))
        if (not reg.workspace_scope.startswith('workspace:') or reg.parent_task_id == task_id
                or reg.trigger_kind not in ('failure_event', 'maintenance_event', 'executive_request')
                or not re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}', reg.source_revision)
                or type(reg.root_identity) is not tuple or len(reg.root_identity) != 2
                or any(type(v) is not int or not 0 <= v < 2**64 for v in reg.root_identity)):
            raise ImprovementDenied('isolated development identity required')
        if (any(type(v) not in (int, float) or not math.isfinite(v) for v in (reg.issued_wall, reg.deadline_wall))
                or not 0 < reg.deadline_wall-reg.issued_wall <= 3600):
            raise ImprovementDenied('bounded registration lifetime required')
        for values, maximum in ((reg.changes, 4), (reg.editable_paths, 16),
                                (reg.protected_paths, 32), (reg.required_checks, 3)):
            if type(values) is not tuple or not 1 <= len(values) <= maximum or len(set(values)) != len(values):
                raise ImprovementDenied('immutable bounded development scope required')
        for path in (*reg.editable_paths, *reg.protected_paths): _path(path)
        for check in reg.required_checks: _ref(check)
        paths = []
        for change in reg.changes:
            if type(change) is not Change: raise ImprovementDenied('registered changes required')
            _path(change.path); _sha(change.before_sha256); _sha(change.after_sha256)
            if (change.path not in reg.editable_paths or change.before_sha256 == change.after_sha256
                    or any(change.path == p or change.path.startswith(p+'/') for p in reg.protected_paths)):
                raise ImprovementDenied('canonical, identity, policy or unregistered target denied')
            paths.append(change.path)
        if len(set(paths)) != len(paths): raise ImprovementDenied('duplicate change path')
        context = self._context(reg.parent_task_id)
        if (type(context) is not PlanContext or digest(asdict(context)) != reg.parent_context_sha256
                or context.principal != principal or context.project_scope != reg.workspace_scope
                or context.deadline_wall != reg.deadline_wall
                or not set(paths) <= set(context.allowed_paths)
                or not set(reg.required_checks) <= set(context.allowed_checks)
                or len(paths)+2*len(reg.required_checks) > context.max_steps):
            raise ImprovementDenied('trusted dedicated parent plan differs')
        task, parent = self.store.get_task(task_id), self.store.get_task(context.task_id)
        if (task is None or task['idem_key'] != reg.submission_id or task['project_scope'] != reg.workspace_scope
                or task['authorization_ref'] != reg.authorization_ref or task['priority'] != 70
                or task['deadline_wall'] != reg.deadline_wall or parent is None
                or parent['idem_key'] != context.submission_id or parent['authorization_ref'] != context.authorization_ref
                or parent['project_scope'] != context.project_scope):
            raise ImprovementDenied('operational task binding differs')
        if active:
            now = self._clock()
            if (type(now) not in (int, float) or not math.isfinite(now)
                    or not reg.issued_wall <= now < reg.deadline_wall
                    or task['cancel_requested'] or parent['cancel_requested']):
                raise ImprovementDenied('proposal expired or cancelled')
        return reg, context, task

    def _data(self, reg, task):
        data = task['checkpoint']
        if (data.get('schema') != 1 or data.get('kind') != 'development_improvement'
                or data.get('registration_sha256') != digest(asdict(reg))
                or data.get('manifest') != json.loads(_json(asdict(reg)))
                or type(data.get('steps')) is not list or len(data['steps']) > 8):
            raise ImprovementDenied('durable proposal registration differs')
        for index, step in enumerate(data['steps']):
            if (type(step) is not dict or step.get('step') != index
                    or step.get('step_key') != 'planner-step:'+str(index+1)):
                raise ImprovementDenied('bounded ordered step journal required')
            self._bound_approval(reg, step)
            if step.get('outcome') is not None:
                self._saved_receipt(reg, step)
        if data.get('phase') == 'READY_FOR_REVIEW' and (data.get('cancel_requested') or not self._ready(reg, data)):
            raise ImprovementDenied('review readiness requires retained evidence')
        return json.loads(_json(data))

    @staticmethod
    def _ready(reg, data):
        return (bool(data['steps']) and all(s.get('outcome') == 'SUCCEEDED' for s in data['steps'])
                and {s['target'] for s in data['steps'] if s['role'] == 'edit'} == {c.path for c in reg.changes}
                and {s['target'] for s in data['steps'] if s['role'] == 'baseline'} == set(reg.required_checks)
                and {s['target'] for s in data['steps'] if s['role'] == 'candidate'} == set(reg.required_checks))

    def _success_result(self, reg, step, result):
        if step['role'] in ('baseline', 'candidate'):
            if (type(result) is not dict or result.get('ok') is not True or result.get('check') != step['target']
                    or type(result.get('returncode')) is not int or result['returncode'] != 0
                    or result.get('process_drained') is not True):
                raise ImprovementDenied('successful contained check receipt required')
        elif step['role'] == 'edit':
            change = next(c for c in reg.changes if c.path == step['target'])
            if (type(result) is not dict or result.get('ok') is not True
                    or result.get('before_sha256') != change.before_sha256 or result.get('sha256') != change.after_sha256):
                raise ImprovementDenied('replacement receipt differs from exact manifest')

    def _saved_receipt(self, reg, step):
        """A mutable checkpoint cannot manufacture success or erase negatives."""
        context = self._context(reg.parent_task_id)
        identity = self.ingress.lookup_step(context=context, step_key=step['step_key'])
        if (type(identity) is not StepIdentity or asdict(identity) != step.get('child')
                or identity.proposal_sha256 != step['planner_proposal_sha256']):
            raise ImprovementDenied('saved child differs from immutable registration')
        action = self.store.get_action(identity.action_id)
        receipt = step.get('receipt')
        if (action is None or action['task_id'] != identity.task_id or action['name'] != step['name']
                or digest(action['arguments']) != step['arguments_sha256']
                or digest(action['resources']) != step['resources_sha256'] or action['tier'] != step['tier']
                or action['state'] != step['outcome'] or type(action['result_seq']) is not int
                or receipt != {'outcome': action['state'], 'result_seq': action['result_seq'],
                               'result_sha256': digest(action['result'])}):
            raise ImprovementDenied('saved outcome differs from retained receipt')
        if step['outcome'] == 'SUCCEEDED':
            self._success_result(reg, step, action['result'])
            if step['role'] in ('baseline', 'candidate'):
                evidence = self._evidence(reg.proposal_task_id, step['step_key'])
                if self._validated_evidence(reg, step, identity, receipt, evidence) != step.get('evidence'):
                    raise ImprovementDenied('saved check lacks immutable source attestation')

    @staticmethod
    def _validated_evidence(reg, step, identity, receipt, evidence):
        expected_tree = reg.source_tree_sha256 if step['role'] == 'baseline' else reg.candidate_tree_sha256
        if (type(evidence) is not CheckEvidence
                or evidence.proposal_task_id != reg.proposal_task_id or evidence.parent_task_id != reg.parent_task_id
                or evidence.step_key != step['step_key'] or evidence.action_id != identity.action_id
                or evidence.planner_proposal_sha256 != identity.proposal_sha256
                or evidence.configuration_sha256 != reg.configuration_sha256 or evidence.tree_sha256 != expected_tree
                or evidence.result_seq != receipt['result_seq'] or evidence.result_sha256 != receipt['result_sha256']):
            raise ImprovementDenied('check dispatch-source attestation differs')
        _ref(evidence.reference)
        proof = evidence.input_proof
        if (type(proof) is not CheckInputProof or proof.mode != 'immutable_readonly_snapshot'
                or proof.action_id != identity.action_id or proof.planner_proposal_sha256 != identity.proposal_sha256
                or proof.configuration_sha256 != reg.configuration_sha256
                or proof.artifact_sha256 != reg.artifact_sha256
                or proof.input_tree_sha256 != expected_tree or proof.completion_tree_sha256 != expected_tree
                or any(getattr(proof, name) is not True for name in
                       ('mutation_excluded', 'held_until_drain', 'namespace_drained', 'process_drained'))):
            raise ImprovementDenied('trusted immutable check input and completion proof required')
        _ref(proof.reference); _ref(proof.snapshot_ref)
        return asdict(evidence)

    def _bound_approval(self, reg, step):
        approval = self._approval(step.get('approval_ref'))
        summary = {key: step.get(key) for key in _SUMMARY_KEYS}
        review = digest([digest(asdict(reg)), summary])
        if (type(approval) is not ImprovementApproval or approval.approved is not True
                or approval.reference != step.get('approval_ref') or approval.principal != reg.principal
                or approval.proposal_task_id != reg.proposal_task_id
                or approval.registration_sha256 != digest(asdict(reg))
                or approval.review_sha256 != review or step.get('review_sha256') != review
                or approval.planner_proposal_sha256 != step.get('planner_proposal_sha256')):
            raise ImprovementDenied('journal differs from immutable reviewed approval')
        return approval

    def _active_approval(self, reg, data, approval_ref):
        approval = self._approval(approval_ref)
        now = self._clock()
        if (type(approval) is not ImprovementApproval or approval.approved is not True
                or approval.reference != approval_ref or approval.principal != reg.principal
                or approval.proposal_task_id != reg.proposal_task_id
                or approval.registration_sha256 != data['registration_sha256']
                or type(now) not in (int, float) or not math.isfinite(now)
                or type(approval.expires_wall) not in (int, float) or not math.isfinite(approval.expires_wall)
                or not now < approval.expires_wall <= reg.deadline_wall):
            raise ImprovementDenied('exact trusted approval required')
        _ref(approval_ref)
        return approval

    def _save(self, task, data):
        if len(_json(data).encode('utf-8')) > min(12288, self.store.max_payload_bytes):
            raise ImprovementDenied('bounded proposal capacity exhausted')
        return self.store.checkpoint(task['task_id'], data, expected_revision=task['revision'], state='PAUSED')

    def offer(self, task_id, *, principal):
        """Existing executive event handler, only after trusted registration."""
        with self._lock:
            reg, context, task = self._access(task_id, principal, active=True)
            if task['checkpoint']:
                self._data(reg, task)
                return self.status(task_id, principal=principal)
            view = self.planner.proposal(context.task_id, principal=principal)
            if view['step'] != 0 or view['phase'] not in ('READY', 'AWAIT_APPROVAL'):
                raise ImprovementDenied('dedicated unused parent plan required')
            self._save(task, {'schema': 1, 'kind': 'development_improvement',
                'registration_sha256': digest(asdict(reg)), 'manifest': asdict(reg),
                'phase': 'PROPOSED', 'steps': [], 'cancel_requested': False})
            return self.status(task_id, principal=principal)

    def status(self, task_id, *, principal):
        reg, _, task = self._access(task_id, principal)
        data = self._data(reg, task)
        return {'task_id': task_id, 'revision': task['revision'], **data,
                'metadata_only': True, 'promotion_allowed': False}

    def _describe(self, reg, data, view):
        proposal = view.get('proposal')
        if (view.get('phase') != 'AWAIT_APPROVAL' or type(proposal) is not dict
                or proposal.get('decision') != 'action' or view.get('step') != len(data['steps'])):
            raise ImprovementDenied('exact next planner action required')
        _sha(view.get('proposal_sha256'))
        name, args, spec = proposal.get('name'), proposal.get('arguments'), proposal.get('spec')
        if (type(args) is not dict or type(spec) is not dict or spec.get('scope') != reg.workspace_scope
                or tuple(spec.get('root_identity', ())) != reg.root_identity
                or spec.get('configuration_sha256') != reg.configuration_sha256
                or spec.get('input_sha256') != digest(args)):
            raise ImprovementDenied('reviewed workspace/spec differs')
        success = [s for s in data['steps'] if s.get('outcome') == 'SUCCEEDED']
        baseline = {s.get('target') for s in success if s['role'] == 'baseline'}
        edits = {s.get('target') for s in success if s['role'] == 'edit'}
        changed = {c.path: c for c in reg.changes}
        if name == 'project.read_text' and set(args) == {'path'} and args['path'] in changed:
            role, target, tier = 'read', args['path'], 1
        elif name == 'project.replace_text' and set(args) == {'path', 'expected_sha256', 'text'}:
            change = changed.get(args['path'])
            if (change is None or set(reg.required_checks) != baseline or args['path'] in edits
                    or type(args['text']) is not str or len(args['text'].encode('utf-8')) > 8192
                    or args['expected_sha256'] != change.before_sha256
                    or hashlib.sha256(args['text'].encode('utf-8')).hexdigest() != change.after_sha256):
                raise ImprovementDenied('exact approved replacement and baseline required')
            role, target, tier = 'edit', args['path'], 2
        elif name == 'project.run_check' and set(args) == {'check'} and args['check'] in reg.required_checks:
            if edits and edits != set(changed): raise ImprovementDenied('candidate edits incomplete')
            role, target, tier = ('candidate' if edits else 'baseline'), args['check'], 3
            if any(s['role'] == role and s['target'] == target for s in data['steps']):
                raise ImprovementDenied('check already attempted; no blind replay')
        else:
            raise ImprovementDenied('unregistered action denied')
        if spec.get('minimum_tier') != tier: raise ImprovementDenied('reviewed action tier differs')
        summary = {'step_key': 'planner-step:'+str(view['step']+1), 'step': view['step'],
            'planner_proposal_sha256': view['proposal_sha256'], 'role': role, 'target': target,
            'name': name, 'arguments_sha256': digest(args), 'spec_sha256': digest(spec),
            'resources_sha256': digest(spec.get('resources')), 'tier': tier}
        summary['review_sha256'] = digest([data['registration_sha256'], summary])
        return summary

    def review_step(self, task_id, *, principal):
        """Record exact metadata for human review; never approves or dispatches."""
        with self._lock:
            reg, context, task = self._access(task_id, principal, active=True)
            data = self._data(reg, task)
            if data['cancel_requested'] or data['phase'] in ('NEEDS_REVIEW', 'READY_FOR_REVIEW'):
                raise ImprovementDenied('proposal requires external review')
            if any(s.get('outcome') != 'SUCCEEDED' for s in data['steps']):
                raise ImprovementDenied('previous receipt/evidence unresolved')
            if len(data['steps']) >= context.max_steps: raise ImprovementDenied('step budget exhausted')
            summary = self._describe(reg, data, self.planner.proposal(context.task_id, principal=principal))
            if data.get('review') not in (None, summary): raise ImprovementDenied('reviewed proposal changed')
            if data.get('review') is None:
                data.update(phase='AWAIT_APPROVAL', review=summary)
                self._save(task, data)
            return self.status(task_id, principal=principal)

    def approve_step(self, task_id, *, principal, approval_ref):
        """Trusted approval-service call; never expose as a model tool."""
        with self._lock:
            reg, context, task = self._access(task_id, principal, active=True)
            data = self._data(reg, task)
            if data['cancel_requested'] or data['phase'] in ('NEEDS_REVIEW', 'READY_FOR_REVIEW'):
                raise ImprovementDenied('proposal requires external review')
            approval = self._active_approval(reg, data, approval_ref)
            old = next((s for s in data['steps'] if s['review_sha256'] == approval.review_sha256), None)
            if old is None:
                review = data.get('review')
                if (review is None or review['review_sha256'] != approval.review_sha256
                        or review['planner_proposal_sha256'] != approval.planner_proposal_sha256
                        or self._describe(reg, data, self.planner.proposal(context.task_id, principal=principal)) != review):
                    raise ImprovementDenied('review or planner proposal changed')
                old = {**review, 'approval_ref': approval_ref, 'status': 'DISPATCH_INTENT'}
                data['steps'].append(old); data.pop('review', None)
                data['phase'] = 'DISPATCH_INTENT'
                self._save(task, data)  # Durable before the existing planner/ingress boundary.
            elif old['approval_ref'] != approval_ref or old['planner_proposal_sha256'] != approval.planner_proposal_sha256:
                raise ImprovementDenied('existing approval identity differs')
            # A runtime poll may have advanced the planner after a lost reply.
            # Resolve retained child authority before invoking approval again.
            retained = self.ingress.lookup_step(context=context, step_key=old['step_key'])
            if old.get('outcome') is None and retained is None:
                # An approval reference is not a fresh TTL or a permission grant.
                # The ingress must resolve its trusted receipt, persist the exact
                # expiry and enforce it/revocation again at the effect boundary.
                fresh_reg, fresh_context, _ = self._access(task_id, principal, active=True)
                if ((fresh_reg, fresh_context) != (reg, context)
                        or self._active_approval(reg, data, approval_ref) != approval):
                    raise ImprovementDenied('approval changed before registration')
                record = getattr(self.ingress, 'record_approval', None)
                if not callable(record):
                    raise ImprovementDenied('durable expiry-bound approval ingress required')
                recorded = record(context.task_id, principal=principal,
                    proposal_sha256=approval.planner_proposal_sha256, approval_ref=approval_ref,
                    approved=True, expires_wall=approval.expires_wall)
                if recorded != {'step_key': old['step_key'], 'proposal_sha256': approval.planner_proposal_sha256}:
                    raise ImprovementDenied('durable approval identity differs')
                fresh_reg, fresh_context, _ = self._access(task_id, principal, active=True)
                if ((fresh_reg, fresh_context) != (reg, context)
                        or self._active_approval(reg, data, approval_ref) != approval):
                    raise ImprovementDenied('approval changed before delegation')
                self.planner.approve_step(context.task_id, principal=principal,
                    proposal_sha256=approval.planner_proposal_sha256, approval_ref=approval_ref, approved=True)
            return self.reconcile(task_id, principal=principal)

    def reconcile(self, task_id, *, principal):
        """Retain receipts after OFF/cancellation; never enqueue or replay."""
        with self._lock:
            reg, context, task = self._access(task_id, principal)
            data = self._data(reg, task)
            for step in data['steps']:
                identity = self.ingress.lookup_step(context=context, step_key=step['step_key'])
                if identity is None:
                    if step.get('child') is not None: raise ImprovementDenied('durable child registration disappeared')
                    continue
                if type(identity) is not StepIdentity or identity.proposal_sha256 != step['planner_proposal_sha256']:
                    raise ImprovementDenied('immutable child proposal differs')
                child, action = self.store.get_task(identity.task_id), self.store.get_action(identity.action_id)
                if (child is None or child['project_scope'] != reg.workspace_scope or action is None
                        or action['task_id'] != identity.task_id or action['name'] != step['name']
                        or digest(action['arguments']) != step['arguments_sha256']
                        or digest(action['resources']) != step['resources_sha256'] or action['tier'] != step['tier']):
                    raise ImprovementDenied('retained child action differs')
                if step.get('child') not in (None, asdict(identity)):
                    raise ImprovementDenied('child identity changed')
                step['child'] = asdict(identity)
                if action['state'] in ('QUEUED', 'RUNNING'):
                    if step.get('receipt') is not None: raise ImprovementDenied('terminal receipt regressed')
                    step['status'] = action['state']; continue
                if action['state'] not in ('SUCCEEDED', 'FAILED', 'CANCELLED', 'UNKNOWN') or type(action['result_seq']) is not int:
                    raise ImprovementDenied('durable terminal receipt required')
                receipt = {'outcome': action['state'], 'result_seq': action['result_seq'],
                           'result_sha256': digest(action['result'])}
                if step.get('receipt') not in (None, receipt): raise ImprovementDenied('retained receipt changed')
                step['receipt'] = receipt
                if action['state'] == 'SUCCEEDED': self._success_result(reg, step, action['result'])
                if action['state'] == 'SUCCEEDED' and step['role'] in ('baseline', 'candidate'):
                    evidence = self._evidence(task_id, step['step_key'])
                    if evidence is None:
                        if step.get('evidence') is not None: raise ImprovementDenied('retained attestation disappeared')
                        step['status'] = 'EVIDENCE_REQUIRED'; continue
                    value = self._validated_evidence(reg, step, identity, receipt, evidence)
                    if step.get('evidence') not in (None, value): raise ImprovementDenied('immutable evidence changed')
                    step['evidence'] = value
                step['outcome'] = step['status'] = action['state']
            if any(s.get('outcome') in ('FAILED', 'CANCELLED', 'UNKNOWN') for s in data['steps']):
                data['phase'] = 'NEEDS_REVIEW'
            elif data['cancel_requested']:
                data['phase'] = 'CANCEL_REQUESTED'
            elif data['steps'] and all(s.get('outcome') == 'SUCCEEDED' for s in data['steps']):
                data['phase'] = 'READY_FOR_REVIEW' if self._ready(reg, data) else 'PROPOSED'
            elif data['steps']:
                data['phase'] = 'WAITING_RECEIPT'
            if data != task['checkpoint']: self._save(task, data)
            self.planner.poll(context.task_id, principal=principal)
            return self.status(task_id, principal=principal)

    def cancel(self, task_id, *, principal):
        with self._lock:
            reg, context, task = self._access(task_id, principal)
            data = self._data(reg, task)
            if not data['cancel_requested']:
                data.update(cancel_requested=True, phase='CANCEL_REQUESTED')
                self._save(task, data)
            self.planner.cancel(context.task_id, principal=principal)
            return self.reconcile(task_id, principal=principal)

    def quiesce(self):
        self._stopping = True  # No worker, store or planner ownership to close.
