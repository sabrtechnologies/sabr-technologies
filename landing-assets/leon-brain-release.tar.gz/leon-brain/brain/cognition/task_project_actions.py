"""Narrow registered project actions, subordinate to TaskWorker and its policy.

Configuration and authority are trusted integrator inputs, never model output.
This is not a shell interface or an OS sandbox. Managed workspaces must exclude
uncoordinated writers; named checks require reviewed process/filesystem/network
containment. No installation, inference, grants or reconciliation happen here.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import copy
import hashlib
import json
import math
import os
import selectors
import signal
import stat
import subprocess
import time
import uuid
from typing import Mapping

from .task_worker import ActionResult, PolicyDecision


NAMES = ("project.read_text", "project.replace_text", "project.run_check")
MAX_FILE_BYTES = 65536
MAX_READ_BYTES = 2048
MAX_REPLACEMENT_BYTES = 8192
MAX_OUTPUT_BYTES = 2048


class Rejected(ValueError):
    """Validation failed before this backend performed an effect."""


class UncertainOutcome(RuntimeError):
    """Cleanup/durability could not be proved after a possible effect."""


def _digest(value):
    return hashlib.sha256(value).hexdigest()


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _identity(info):
    return info.st_dev, info.st_ino


def _ownership_mode(info):
    return info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode)


def _file_version(info):
    # Reading can change atime; it must not hide ownership, mode or content drift.
    return (_identity(info), info.st_mode, info.st_uid, info.st_gid, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _relative(path, *, directory=False):
    if directory and path == ".":
        return ()
    if (not isinstance(path, str) or not path or len(path) > 512 or
            "\\" in path or ":" in path or "\0" in path or path.startswith("/")):
        raise Rejected("relative_path_required")
    parts = tuple(path.split("/"))
    if any(not p or p in (".", "..", ".git", ".hg", ".svn") or
           len(p.encode("utf-8")) > 255 for p in parts):
        raise Rejected("invalid_path_component")
    return parts


def _open_absolute(path):
    """Walk every ancestor without following symlinks, including the root path."""
    if not isinstance(path, str) or not path.startswith("/") or "\0" in path:
        raise Rejected("absolute_configured_workspace_required")
    parts = path.split("/")[1:]
    if not parts or any(not p or p in (".", "..") for p in parts):
        raise Rejected("noncanonical_workspace")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open("/", flags)
    try:
        for part in parts:
            new = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = new
        return fd
    except BaseException:
        os.close(fd)
        raise


@dataclass(frozen=True)
class Check:
    """Trusted fixed command. No argument, cwd or environment substitution."""
    name: str
    argv: tuple[str, ...]
    cwd: str = "."
    env: tuple[tuple[str, str], ...] = ()
    timeout_s: float = 30.0
    # Versioned identity of the integrator's reviewed confinement configuration.
    # It is evidence for authority to validate, not permission by itself.
    containment_ref: str = ""


@dataclass(frozen=True)
class Workspace:
    scope: str
    root: str
    checks: tuple[Check, ...] = ()
    shared_resources: tuple[str, ...] = ()


@dataclass(frozen=True)
class CanonicalResourceSpec:
    name: str
    arguments: tuple[tuple[str, str], ...]
    resources: tuple[str, ...]
    minimum_tier: int
    scope: str
    root_identity: tuple[int, int]
    input_sha256: str
    configuration_sha256: str


class _Tree:
    def __init__(self, workspace, identity, parent_parts):
        self.workspace, self.identity, self.parts = workspace, identity, parent_parts
        self.fds = []
        try:
            root = _open_absolute(workspace.root)
            self.fds.append(root)
            if _identity(os.fstat(root)) != identity:
                raise Rejected("workspace_identity_changed")
            for part in parent_parts:
                self.fds.append(os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                        dir_fd=self.fds[-1]))
            self.identities = tuple(_identity(os.fstat(fd)) for fd in self.fds)
            self.verify()
        except BaseException:
            self.close()
            raise

    @property
    def parent_fd(self):
        return self.fds[-1]

    def verify(self):
        # Rewalk from the configured path, not only the already-open directory:
        # a parent/root rename must not silently redirect or detach an action.
        fd = _open_absolute(self.workspace.root)
        try:
            if _identity(os.fstat(fd)) != self.identities[0]:
                raise Rejected("workspace_identity_changed")
            for index, part in enumerate(self.parts, 1):
                new = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                              dir_fd=fd)
                os.close(fd); fd = new
                if _identity(os.fstat(fd)) != self.identities[index]:
                    raise Rejected("parent_identity_changed")
        finally:
            os.close(fd)

    def close(self):
        while self.fds:
            os.close(self.fds.pop())


@contextmanager
def _tree(workspace, identity, parts):
    value = _Tree(workspace, identity, parts)
    try:
        yield value
    finally:
        value.close()


def _read_file(tree, leaf):
    fd = os.open(leaf, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC,
                 dir_fd=tree.parent_fd)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > MAX_FILE_BYTES:
            raise Rejected("bounded_unaliased_regular_file_required")
        chunks, size = [], 0
        while size <= MAX_FILE_BYTES:
            data = os.read(fd, min(8192, MAX_FILE_BYTES + 1 - size))
            if not data:
                break
            chunks.append(data); size += len(data)
        after = os.fstat(fd)
        if size > MAX_FILE_BYTES or (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
                after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise Rejected("file_changed_or_too_large")
        current = os.stat(leaf, dir_fd=tree.parent_fd, follow_symlinks=False)
        if _identity(current) != _identity(before):
            raise Rejected("file_identity_changed")
        tree.verify()
        return b"".join(chunks), before
    finally:
        os.close(fd)


def _failed(reason, *, executed=False):
    return ActionResult("FAILED", {"ok":False, "reason":reason, "executed":executed})


def _unknown(reason, **details):
    return ActionResult("UNKNOWN", {"ok":False, "reason":reason, "uncertain":True,
                                   "replay_allowed":False, **details})


class ProjectActions:
    """One explicit registry. Missing authority always denies all actions.

    authority(action, task, canonical_spec) must return literal True and verify
    durable identity/scope/approval/revocation/configuration, on every invocation.
    check_abort(action_id) is a separate explicit check-stop authorization hook;
    never wire it to speech cancellation, UI disconnect or generic task cancel.
    """
    def __init__(self, workspaces, *, authority=None, check_abort=None):
        if os.name != "posix" or not hasattr(os, "O_NOFOLLOW"):
            raise ValueError("POSIX directory descriptors required")
        if authority is not None and not callable(authority):
            raise ValueError("authority")
        if check_abort is not None and not callable(check_abort):
            raise ValueError("check abort hook")
        self._authority, self._check_abort = authority, check_abort
        self._workspaces = {}
        for ws in workspaces:
            if not isinstance(ws, Workspace) or not isinstance(ws.scope, str) or not ws.scope.startswith("workspace:") or not ws.scope[10:] or len(ws.scope) > 200:
                raise ValueError("opaque configured workspace scope required")
            if ws.scope in self._workspaces or type(ws.checks) is not tuple or type(ws.shared_resources) is not tuple:
                raise ValueError("duplicate or mutable workspace configuration")
            if len(ws.shared_resources) > 15 or any(not isinstance(r, str) or not r or len(r) > 200 for r in ws.shared_resources):
                raise ValueError("shared resources")
            checks = {}
            for check in ws.checks:
                if not isinstance(check, Check) or not isinstance(check.name, str) or not check.name or len(check.name) > 100 or check.name in checks:
                    raise ValueError("named check")
                if (type(check.argv) is not tuple or not 1 <= len(check.argv) <= 32 or
                        any(not isinstance(a, str) or not a or "\0" in a or len(a) > 4096 for a in check.argv) or
                        not check.argv[0].startswith("/")):
                    raise ValueError("fixed absolute command required")
                _relative(check.cwd, directory=True)
                if type(check.env) is not tuple or len(check.env) > 32:
                    raise ValueError("fixed environment")
                env = {}
                for pair in check.env:
                    if (type(pair) is not tuple or len(pair) != 2 or any(not isinstance(x, str) or "\0" in x or len(x) > 4096 for x in pair) or
                            not pair[0] or "=" in pair[0] or pair[0] in env):
                        raise ValueError("fixed environment")
                    env[pair[0]] = pair[1]
                if (isinstance(check.timeout_s, bool) or not isinstance(check.timeout_s, (int,float)) or
                        not math.isfinite(check.timeout_s) or not 0 < check.timeout_s <= 120 or
                        not isinstance(check.containment_ref, str) or not check.containment_ref or len(check.containment_ref) > 200):
                    raise ValueError("bounded check and reviewed containment reference required")
                checks[check.name] = check
            fd = _open_absolute(ws.root)
            try: identity = _identity(os.fstat(fd))
            finally: os.close(fd)
            config = _digest(_json({"scope":ws.scope,"root":ws.root,"identity":identity,
                                   "shared":ws.shared_resources,
                                   "checks":[vars(c) for c in ws.checks]}).encode())
            self._workspaces[ws.scope] = ws, identity, checks, config
        self.handlers = {name:self._handle for name in NAMES}

    def canonical_resource_spec(self, name, arguments, task):
        if name not in NAMES or not isinstance(arguments, Mapping) or not isinstance(task, Mapping):
            raise Rejected("registered_action_required")
        scope = task.get("project_scope")
        if scope not in self._workspaces:
            raise Rejected("unconfigured_workspace")
        ws, identity, checks, config = self._workspaces[scope]
        args = dict(arguments)
        if name == "project.run_check":
            if set(args) != {"check"} or not isinstance(args["check"], str) or args["check"] not in checks:
                raise Rejected("configured_check_required")
            tier = 3
        else:
            expected_keys = {"path"} if name == "project.read_text" else {"path","expected_sha256","text"}
            if set(args) != expected_keys:
                raise Rejected("exact_arguments_required")
            _relative(args["path"])
            tier = 1
            if name == "project.replace_text":
                tier = 2
                expected = args["expected_sha256"]
                if not isinstance(expected, str) or len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
                    raise Rejected("expected_sha256_required")
                if not isinstance(args["text"], str) or len(args["text"].encode("utf-8")) > MAX_REPLACEMENT_BYTES:
                    raise Rejected("bounded_replacement_required")
        resources = tuple(sorted(set((f"workspace:{identity[0]}:{identity[1]}", *ws.shared_resources))))
        return CanonicalResourceSpec(name,tuple(sorted(args.items())),resources,tier,scope,identity,
                                     _digest(_json(args).encode()),config)

    def resources(self, name, arguments, task):
        return self.canonical_resource_spec(name,arguments,task).resources

    def _validate(self, action, task, *, dispatched):
        a, t = copy.deepcopy(dict(action)), copy.deepcopy(dict(task))
        spec = self.canonical_resource_spec(a.get("name"),a.get("arguments"),t)
        if (not isinstance(a.get("action_id"), str) or not a["action_id"] or
                not isinstance(t.get("task_id"), str) or not t["task_id"] or
                a.get("task_id") != t["task_id"] or not isinstance(t.get("authorization_ref"), str) or not t["authorization_ref"] or
                type(a.get("tier")) is not int or not spec.minimum_tier <= a["tier"] < 4 or
                tuple(a.get("resources", ())) != spec.resources or a.get("state") != "RUNNING" or
                a.get("dispatched") is not dispatched or t.get("state") != "RUNNING" or t.get("cancel_requested") is not False):
            raise Rejected("action_identity_or_policy_mismatch")
        args_json = _json(a["arguments"])
        fingerprint = _digest(json.dumps([a["name"],args_json,list(spec.resources),a["tier"]]).encode())
        if a.get("fingerprint") != fingerprint:
            raise Rejected("action_fingerprint_mismatch")
        deadline = t.get("deadline_wall")
        if deadline is not None and (isinstance(deadline, bool) or not isinstance(deadline, (int,float)) or
                not math.isfinite(deadline) or time.time() >= deadline):
            raise Rejected("deadline_before_effect")
        if self._authority is None or self._authority(copy.deepcopy(a),copy.deepcopy(t),spec) is not True:
            raise Rejected("authority_denied")
        return spec

    def policy(self, action, task):
        try:
            spec = self._validate(action,task,dispatched=False)
            # Resolve the configured workspace before committing dispatch too.
            ws = self._workspaces[spec.scope][0]
            with _tree(ws,spec.root_identity,()): pass
            return PolicyDecision(True,spec.resources)
        except Exception:
            return PolicyDecision(False,(),"project_policy_denied")

    def _handle(self, action, task):
        effects_possible = False
        try:
            spec = self._validate(action,task,dispatched=True)
            ws, identity, checks, _ = self._workspaces[spec.scope]
            args = dict(spec.arguments)
            if spec.name == "project.run_check":
                check = checks[args["check"]]
                with _tree(ws,identity,_relative(check.cwd,directory=True)) as tree:
                    effects_possible = True
                    return self._run_check(check,tree,action,task)
            parts = _relative(args["path"])
            with _tree(ws,identity,parts[:-1]) as tree:
                data, info = _read_file(tree,parts[-1])
                data.decode("utf-8")
                if spec.name == "project.read_text":
                    text = data[:MAX_READ_BYTES].decode("utf-8",errors="ignore")
                    return ActionResult("SUCCEEDED",{"ok":True,"text":text,"sha256":_digest(data),
                        "size":len(data),"truncated":len(text.encode("utf-8"))<len(data)})
                effects_possible = True
                return self._replace(tree,parts[-1],args,data,info,
                                     lambda:self._validate(action,task,dispatched=True))
        except UncertainOutcome as exc:
            return _unknown(str(exc))
        except Rejected as exc:
            return _failed(str(exc))
        except (OSError,UnicodeError):
            return _unknown("effect_cleanup_unverified") if effects_possible else _failed("path_or_encoding_rejected")
        except Exception:
            return _unknown("effect_completion_unverified") if effects_possible else _failed("authority_or_validation_error")

    def _replace(self, tree, leaf, args, data, info, authorize):
        if _digest(data) != args["expected_sha256"]:
            return _failed("stale_sha256")
        if stat.S_IMODE(info.st_mode) & 0o7000:
            return _failed("special_mode_rejected")
        metadata = _ownership_mode(info)
        replacement = args["text"].encode("utf-8")
        temp = ".leon-task-"+uuid.uuid4().hex
        fd, mutated, commit_attempted = None, False, False
        try:
            fd = os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=tree.parent_fd)
            view = memoryview(replacement)
            while view:
                written = os.write(fd,view)
                if written <= 0: raise OSError("short write")
                view = view[written:]
            # Atomic replacement creates a new inode. Preserve the target's
            # ownership, including a service UID or inherited group, rather than
            # silently replacing it with the parent process's UID/GID. Avoid a
            # privileged operation when the temporary inode already matches.
            temporary = os.fstat(fd)
            if (temporary.st_uid, temporary.st_gid) != metadata[:2]:
                os.fchown(fd,info.st_uid,info.st_gid)
            # chown can clear mode bits; apply permissions only after ownership.
            os.fchmod(fd,stat.S_IMODE(info.st_mode))
            os.fsync(fd)
            authorize()
            # No external authority callback may run after this last preimage
            # check: it could revoke access or change file metadata itself.
            current, current_info = _read_file(tree,leaf)
            if current != data or _file_version(current_info) != _file_version(info):
                return _failed("file_changed_before_replace")
            temporary = os.fstat(fd)
            named_temporary = os.stat(temp,dir_fd=tree.parent_fd,follow_symlinks=False)
            if (not stat.S_ISREG(temporary.st_mode) or temporary.st_nlink != 1 or
                    _ownership_mode(temporary) != metadata or
                    _identity(named_temporary) != _identity(temporary) or
                    _ownership_mode(named_temporary) != metadata):
                return _failed("replacement_metadata_unverified")
            tree.verify()
            commit_attempted = True
            os.replace(temp,leaf,src_dir_fd=tree.parent_fd,dst_dir_fd=tree.parent_fd)
            mutated = True
            os.fsync(tree.parent_fd)
            tree.verify()
            final, final_info = _read_file(tree,leaf)
            if (final != replacement or _identity(final_info) != _identity(os.fstat(fd)) or
                    _ownership_mode(final_info) != metadata):
                return _unknown("file_changed_after_replace")
            return ActionResult("SUCCEEDED",{"ok":True,"before_sha256":_digest(data),
                                              "sha256":_digest(replacement),"size":len(replacement)})
        except Exception:
            return _unknown("replace_outcome_unverified") if commit_attempted else _failed("replace_not_committed")
        finally:
            if fd is not None:
                try: os.close(fd)
                except OSError: raise UncertainOutcome("replacement_close_unverified") from None
            if not mutated:
                try: os.unlink(temp,dir_fd=tree.parent_fd)
                except FileNotFoundError: pass
                except OSError: raise UncertainOutcome("replacement_temp_cleanup_unverified") from None

    @staticmethod
    def _group_exists(pgid):
        try:
            os.killpg(pgid,0)
            return True
        except ProcessLookupError:
            return False

    def _drain_group(self, proc):
        """Bounded TERM/KILL of this new-session group; absence is mandatory."""
        try:
            for sig, grace in ((signal.SIGTERM,.25),(signal.SIGKILL,.5)):
                proc.poll()
                if not self._group_exists(proc.pid):
                    return proc.poll() is not None
                try: os.killpg(proc.pid,sig)
                except ProcessLookupError: pass
                end = time.monotonic()+grace
                while time.monotonic()<end:
                    proc.poll()
                    if not self._group_exists(proc.pid):
                        return proc.poll() is not None
                    time.sleep(.01)
            return proc.poll() is not None and not self._group_exists(proc.pid)
        except Exception:
            return False

    def _run_check(self, check, tree, action, task):
        proc = None
        selector = selectors.DefaultSelector()
        output = {"stdout":bytearray(),"stderr":bytearray()}
        reason, drained = None, False
        try:
            if self._check_abort is not None and self._check_abort(action["action_id"]) is True:
                return _failed("check_aborted_before_start")
            tree.verify()
            env = {"PATH":"/usr/bin:/bin","LANG":"C.UTF-8","LC_ALL":"C.UTF-8", **dict(check.env)}
            # /proc descriptor cwd keeps the child on the verified directory
            # object; no preexec_fn (unsafe in a multithreaded application).
            self._validate(action,task,dispatched=True)
            tree.verify()
            proc = subprocess.Popen(check.argv,cwd=f"/proc/self/fd/{tree.parent_fd}",
                pass_fds=(tree.parent_fd,),env=env,stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
            for label, pipe in (("stdout",proc.stdout),("stderr",proc.stderr)):
                os.set_blocking(pipe.fileno(),False)
                selector.register(pipe,selectors.EVENT_READ,label)
            deadline = time.monotonic()+check.timeout_s
            while True:
                if self._check_abort is not None and self._check_abort(action["action_id"]) is True:
                    reason = "check_aborted"; break
                if time.monotonic() >= deadline:
                    reason = "check_timeout"; break
                for key, _ in selector.select(.02):
                    chunk = os.read(key.fileobj.fileno(),4096)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    remaining = MAX_OUTPUT_BYTES-sum(map(len,output.values()))
                    output[key.data].extend(chunk[:remaining])
                    if len(chunk)>remaining:
                        reason = "check_output_limit"; break
                if reason: break
                if proc.poll() is not None and not selector.get_map():
                    break
            had_descendants = proc.poll() is not None and self._group_exists(proc.pid)
            drained = self._drain_group(proc)
            details = {"ok":False,"check":check.name,"returncode":proc.poll(),
                       "process_drained":drained,
                       **{key:value.decode("utf-8",errors="replace") for key,value in output.items()}}
            if not drained:
                return _unknown("check_process_drain_unverified",**details)
            try: tree.verify()
            except Exception: return _unknown("check_workspace_identity_changed",**details)
            if reason or had_descendants or proc.returncode != 0:
                return ActionResult("FAILED",{**details,"reason":reason or ("check_left_descendants" if had_descendants else "check_nonzero"),"executed":True})
            return ActionResult("SUCCEEDED",{**details,"ok":True})
        except Exception:
            if proc is None:
                return _failed("check_not_started")
            drained = self._drain_group(proc)
            return _unknown("check_interrupted_by_backend_error",process_drained=drained)
        finally:
            selector.close()
            if proc is not None:
                if not drained: self._drain_group(proc)
                for pipe in (proc.stdout,proc.stderr):
                    if pipe is not None: pipe.close()
