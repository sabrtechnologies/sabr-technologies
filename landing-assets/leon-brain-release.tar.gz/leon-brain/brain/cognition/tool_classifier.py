"""
Phase 14 — Tool classifier.

1,596 tools is too noisy. This module classifies every tool Leon has touched
(or knows about) into one of:

  ACTIVE     — used recently, healthy or untested-but-recent
  DORMANT    — registered but never called (or not in months)
  REDUNDANT  — duplicate capability of another, lower-usage tool
  BROKEN     — tool_health says broken AND >= 3 attempts
  LEGACY     — used historically but not in the last 30+ days

It also produces a PREFERRED-TOOL RANKING — the executive consults this to
bias suggestions toward what actually works for what Dean actually does.

Inputs:
  - tool_health.db (status, sr, latency, calls)
  - episodes.db (per-tool call timestamps, recency, count)
  - tool registry (optional — the full known surface)

This is a READ-ONLY analyzer. No SQLite writes. Snapshot is cached for
~60s so repeated /api/cognition/tools/classify calls don't hammer disk.

Used by:
  - Executive (bias tools_to_consider list toward ACTIVE+preferred)
  - Prompt builder (warn about BROKEN, prefer skills over raw tools)
  - Suggestions (surface DORMANT tools as candidates for cleanup)
"""

from __future__ import annotations

import logging
import os
import time
from collections import defaultdict, Counter
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

log = logging.getLogger("leon.cognition.tool_classifier")


CLASS_ACTIVE    = "ACTIVE"
CLASS_DORMANT   = "DORMANT"
CLASS_REDUNDANT = "REDUNDANT"
CLASS_BROKEN    = "BROKEN"
CLASS_LEGACY    = "LEGACY"

# Tunables
_RECENT_WINDOW_S       = 7 * 86400      # "recent" = touched in last 7d
_LEGACY_WINDOW_S       = 30 * 86400     # "legacy" = touched but not in 30+d
_MIN_CALLS_FOR_ACTIVE  = 1              # at least one call in recent window
_MIN_CALLS_FOR_BROKEN_CLASS = 3         # need samples before declaring broken


@dataclass
class ToolClass:
    tool: str
    classification: str
    calls_total: int          # all-time
    calls_7d: int             # last 7 days
    calls_30d: int            # last 30 days
    last_seen_ts: Optional[float]
    success_rate: float       # from tool_health or computed from episodes
    p95_latency_ms: float
    last_failure_kind: Optional[str]
    redundant_of: Optional[str] = None   # if REDUNDANT, which tool subsumes
    reasoning: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ToolClassifier:
    """Read-only analyzer. Builds a snapshot from episodes + tool_health."""

    def __init__(self, *, episodes=None, tool_health=None,
                  registry_provider=None, cache_ttl_s: float = 60.0):
        self.episodes = episodes
        self.tool_health = tool_health
        # callable that returns Iterable[str] of all known tool names; the
        # responder/actuator owns this; we accept any callable.
        self.registry_provider = registry_provider
        self.cache_ttl_s = cache_ttl_s
        self._cache: Optional[Dict[str, Any]] = None
        self._cache_ts: float = 0.0

    # -- public --------------------------------------------------------

    def classify_all(self, force: bool = False) -> Dict[str, Any]:
        """Return a snapshot with summary + per-tool classifications.

        Snapshot shape:
          {
            "ts": float,
            "summary": {"ACTIVE": N, "DORMANT": N, ...},
            "tools": [ ToolClass-as-dict, ... ],
            "preferred": [tool, tool, ...],   # ranked best-to-worst usable
          }
        """
        now = time.time()
        if (not force) and self._cache is not None \
                and (now - self._cache_ts) < self.cache_ttl_s:
            return self._cache

        # Gather raw signals
        usage = self._usage_from_episodes()
        health = self._health_map()
        registered = self._known_tools(usage, health)

        # Detect redundancy by family signature
        redundancy_map = self._detect_redundancy(usage)

        classes: List[ToolClass] = []
        for tool in sorted(registered):
            u = usage.get(tool, {})
            h = health.get(tool)
            calls_total = u.get("calls_total", 0)
            calls_7d    = u.get("calls_7d", 0)
            calls_30d   = u.get("calls_30d", 0)
            last_seen   = u.get("last_seen_ts")
            sr = (h.success_rate if h else u.get("sr_episode", 1.0))
            p95 = (h.latency_p95_ms if h else u.get("p95_episode", 0.0))
            last_kind = h.last_failure_kind if h else None
            redundant_of = redundancy_map.get(tool)

            cls, why = self._classify_one(
                calls_total=calls_total, calls_7d=calls_7d,
                calls_30d=calls_30d, last_seen=last_seen,
                health=h, redundant_of=redundant_of,
            )
            classes.append(ToolClass(
                tool=tool, classification=cls,
                calls_total=calls_total, calls_7d=calls_7d, calls_30d=calls_30d,
                last_seen_ts=last_seen, success_rate=sr, p95_latency_ms=p95,
                last_failure_kind=last_kind,
                redundant_of=redundant_of, reasoning=why,
            ))

        # Preferred ranking — ACTIVE only, ranked by (calls_7d * sr * speed)
        preferred = self._rank_preferred(classes)

        summary = Counter(c.classification for c in classes)
        snapshot = {
            "ts": now,
            "summary": dict(summary),
            "total_tools_known": len(classes),
            "tools": [c.to_dict() for c in classes],
            "preferred": preferred,
        }
        self._cache = snapshot
        self._cache_ts = now
        return snapshot

    def preferred_for(self, intent_text: str, *, limit: int = 5) -> List[str]:
        """Best tools for a given intent — preferred list filtered by name
        overlap with intent tokens. Cheap; reuses cached snapshot."""
        snap = self.classify_all()
        if not intent_text:
            return snap.get("preferred", [])[:limit]
        toks = {t.lower() for t in intent_text.split() if len(t) > 3}
        if not toks:
            return snap.get("preferred", [])[:limit]
        out: List[Tuple[int, str]] = []
        for t in snap.get("preferred", [])[:50]:
            shared = sum(1 for tok in toks if tok in t.lower())
            if shared > 0:
                out.append((shared, t))
        out.sort(key=lambda x: x[0], reverse=True)
        if out:
            return [t for _, t in out[:limit]]
        return snap.get("preferred", [])[:limit]

    def dormant(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Tools registered but never called — candidates for pruning."""
        snap = self.classify_all()
        return [t for t in snap["tools"]
                if t["classification"] == CLASS_DORMANT][:limit]

    def broken(self, limit: int = 50) -> List[Dict[str, Any]]:
        snap = self.classify_all()
        return [t for t in snap["tools"]
                if t["classification"] == CLASS_BROKEN][:limit]

    def redundant(self, limit: int = 100) -> List[Dict[str, Any]]:
        snap = self.classify_all()
        return [t for t in snap["tools"]
                if t["classification"] == CLASS_REDUNDANT][:limit]

    # -- internals -----------------------------------------------------

    def _usage_from_episodes(self) -> Dict[str, Dict[str, Any]]:
        """Aggregate per-tool usage from the episode store.

        Returns: tool_name → {calls_total, calls_7d, calls_30d,
                              last_seen_ts, sr_episode, p95_episode}
        """
        if self.episodes is None:
            return {}
        now = time.time()
        cutoff_7d  = now - _RECENT_WINDOW_S
        cutoff_30d = now - _LEGACY_WINDOW_S
        agg: Dict[str, Dict[str, Any]] = {}
        try:
            # Pull a large window — episodes table is small relative to
            # tool count. Recent() returns up to N latest; we want all-time
            # so use a high limit. If the table grows huge this can be
            # tightened to last-N-days only.
            rows = self.episodes.recent(limit=20000)
        except Exception as e:
            log.warning("tool_classifier: episodes.recent failed: %s", e)
            return {}
        latencies_by_tool: Dict[str, List[float]] = defaultdict(list)
        for r in rows:
            if r.get("action_kind") != "tool":
                continue
            tool = r.get("action_name")
            if not tool:
                continue
            ts = float(r.get("ts") or 0)
            ok = int(r.get("success") or 0)
            lat = r.get("latency_ms")
            a = agg.setdefault(tool, {
                "calls_total": 0, "calls_7d": 0, "calls_30d": 0,
                "successes": 0, "last_seen_ts": 0,
            })
            a["calls_total"] += 1
            a["successes"] += ok
            if ts > a["last_seen_ts"]:
                a["last_seen_ts"] = ts
            if ts >= cutoff_30d:
                a["calls_30d"] += 1
            if ts >= cutoff_7d:
                a["calls_7d"] += 1
            if lat is not None:
                latencies_by_tool[tool].append(float(lat))
        for tool, a in agg.items():
            a["sr_episode"] = a["successes"] / max(1, a["calls_total"])
            lats = sorted(latencies_by_tool.get(tool) or [])
            if lats:
                k = 0.95 * (len(lats) - 1)
                f = int(k); c = min(f+1, len(lats)-1)
                a["p95_episode"] = lats[f] + (lats[c]-lats[f]) * (k-f)
            else:
                a["p95_episode"] = 0.0
        return agg

    def _health_map(self) -> Dict[str, Any]:
        """tool_name → ToolStats from tool_health, if available."""
        if self.tool_health is None:
            return {}
        try:
            return {s.tool: s for s in self.tool_health.all_stats(limit=5000)}
        except Exception as e:
            log.warning("tool_classifier: tool_health.all_stats failed: %s", e)
            return {}

    def _known_tools(self, usage: Dict, health: Dict) -> set:
        """Union of: episodes-observed + tool_health-observed + registry."""
        out = set(usage.keys()) | set(health.keys())
        if callable(self.registry_provider):
            try:
                out |= set(self.registry_provider())
            except Exception as e:
                log.warning("tool_classifier: registry_provider failed: %s", e)
        return out

    def _classify_one(
        self, *, calls_total: int, calls_7d: int, calls_30d: int,
        last_seen: Optional[float], health, redundant_of: Optional[str],
    ) -> Tuple[str, str]:
        # BROKEN trumps everything
        if health is not None and health.status == "broken" \
                and health.calls_total >= _MIN_CALLS_FOR_BROKEN_CLASS:
            return CLASS_BROKEN, f"tool_health says broken (sr={health.success_rate:.2f}, n={health.calls_total})"
        # REDUNDANT — duplicate capability detected
        if redundant_of:
            return CLASS_REDUNDANT, f"duplicate-capability of {redundant_of}"
        # ACTIVE — touched recently
        if calls_7d >= _MIN_CALLS_FOR_ACTIVE:
            return CLASS_ACTIVE, f"{calls_7d} calls in last 7d"
        # LEGACY — touched in past but not recently
        if calls_total > 0 and calls_30d == 0:
            days = ((time.time() - (last_seen or 0)) / 86400) if last_seen else 999
            return CLASS_LEGACY, f"no calls in 30d (last seen {days:.0f}d ago)"
        # DORMANT — registered but never (or barely) called
        if calls_total == 0:
            return CLASS_DORMANT, "never called"
        # Edge: had calls in 30d but not 7d → DORMANT-ish, but call it ACTIVE
        # if there was any use in the last 30 days.
        if calls_30d > 0:
            return CLASS_ACTIVE, f"{calls_30d} calls in last 30d (none in last 7d)"
        return CLASS_DORMANT, "fallthrough"

    def _detect_redundancy(self, usage: Dict[str, Dict]) -> Dict[str, str]:
        """Detect duplicate-capability tools by name family.

        Heuristic: tools sharing the same first dotted segment (e.g.
        browser.click, browser_apps.click, browser_power.click) where the
        suffix is the same. The MOST-USED variant wins; the others are
        flagged REDUNDANT with redundant_of=winner.
        """
        family: Dict[str, List[Tuple[str, int]]] = defaultdict(list)
        for tool, u in usage.items():
            suffix = self._family_suffix(tool)
            if suffix is None:
                continue
            family[suffix].append((tool, u.get("calls_total", 0)))
        out: Dict[str, str] = {}
        for suffix, members in family.items():
            if len(members) < 2:
                continue
            members.sort(key=lambda x: x[1], reverse=True)
            winner = members[0][0]
            winner_calls = members[0][1]
            # Only mark losers redundant if winner has SOME usage
            if winner_calls == 0:
                continue
            for tool, _ in members[1:]:
                out[tool] = winner
        return out

    def _family_suffix(self, tool: str) -> Optional[str]:
        """Extract a 'capability' signature from a tool name.

        browser.click → click
        browser_power.click → click
        gmail.search → gmail.search (keep full when no obvious family)

        Returns the suffix to group by, or None if the tool is so unique
        it can't be confused with anything.
        """
        # Look for known "capability prefixes" — when the prefix is one of
        # these families AND the suffix is generic, group by suffix.
        FAMILY_PREFIXES = {
            "browser", "browser_apps", "browser_power", "browser_cdp",
            "actuator",
            "pc_control", "window", "audio", "audio_record",
            "info", "info_tools",
            "file_ops", "file_search",
            "notes", "memory_extras",
        }
        if "." in tool:
            prefix, _, rest = tool.partition(".")
            if prefix in FAMILY_PREFIXES and rest:
                return rest
            return None
        if "_" in tool:
            prefix, _, rest = tool.partition("_")
            if prefix in FAMILY_PREFIXES and rest:
                return rest
        return None

    def _rank_preferred(self, classes: List[ToolClass]) -> List[str]:
        """Rank ACTIVE tools by usefulness score."""
        actives = [c for c in classes if c.classification == CLASS_ACTIVE]
        def score(c: ToolClass) -> float:
            recency = c.calls_7d * 3 + c.calls_30d * 1
            quality = c.success_rate
            speed = 1.0 / max(50.0, c.p95_latency_ms) * 1000.0  # 0..20 typical
            return recency * quality + speed * 0.1
        actives.sort(key=score, reverse=True)
        return [c.tool for c in actives]


__all__ = [
    "ToolClassifier", "ToolClass",
    "CLASS_ACTIVE", "CLASS_DORMANT", "CLASS_REDUNDANT",
    "CLASS_BROKEN", "CLASS_LEGACY",
]


# ── Phase 15 — tool compression: soft-hide + grouping ───────────────────────

def _visible_tools(self, *, include_legacy: bool = False) -> List[str]:
    """Return the compressed tool surface — only what's worth surfacing
    to the prompt builder / suggestions / executive.

    By default: ACTIVE + (LEGACY if include_legacy). Excludes DORMANT,
    BROKEN, REDUNDANT. This is the "thinking in skills, not tools" path —
    we don't delete the 1574 dormant tools, we just stop reminding Claude
    about them every turn.
    """
    snap = self.classify_all()
    keep = {CLASS_ACTIVE}
    if include_legacy:
        keep.add(CLASS_LEGACY)
    return [t["tool"] for t in snap["tools"]
             if t["classification"] in keep]


def _hidden_count(self) -> Dict[str, int]:
    """How many tools the compression layer is currently soft-hiding."""
    snap = self.classify_all()
    out = {"DORMANT": 0, "LEGACY": 0, "REDUNDANT": 0, "BROKEN": 0}
    for t in snap["tools"]:
        c = t["classification"]
        if c in out:
            out[c] += 1
    out["total_hidden"] = sum(out.values())
    out["total_visible"] = snap.get("total_tools_known", 0) - out["total_hidden"]
    return out


def _skill_for(self, tool: str,
                skills_provider=None) -> Optional[Dict[str, Any]]:
    """If `tool` participates in any reinforced/optimized skill, return
    the highest-reinforcement skill that includes it. Callers can then
    suggest the SKILL instead of the raw tool — Phase 15's compression
    principle (think in capabilities, not raw tools)."""
    if skills_provider is None:
        return None
    try:
        cands = skills_provider.by_reinforcement(min_score=0.3, limit=50)
    except Exception:
        return None
    best = None
    best_score = 0.0
    for sk in cands:
        for st in sk.steps:
            if st.tool == tool:
                if sk.reinforcement > best_score:
                    best = sk
                    best_score = sk.reinforcement
                break
    if best is None:
        return None
    return {
        "skill_id": best.id, "name": best.name,
        "state": best.state, "reinforcement": best.reinforcement,
        "step_count": len(best.steps),
    }


def _group_dormant_by_family(self, *, limit_per_family: int = 10) -> Dict[str, List[str]]:
    """Group dormant tools by family prefix (the same one tool_classifier
    uses for redundancy detection). Useful for the dashboard: rather
    than show 1574 dormant tools individually, show ~80 families."""
    snap = self.classify_all()
    families: Dict[str, List[str]] = {}
    for t in snap["tools"]:
        if t["classification"] not in (CLASS_DORMANT, CLASS_LEGACY):
            continue
        name = t["tool"]
        if "." in name:
            fam = name.split(".", 1)[0]
        elif "_" in name:
            fam = name.split("_", 1)[0]
        else:
            fam = "_misc"
        families.setdefault(fam, []).append(name)
    # Trim
    return {k: sorted(v)[:limit_per_family] for k, v in
            sorted(families.items(), key=lambda kv: len(kv[1]), reverse=True)}


ToolClassifier.visible_tools = _visible_tools
ToolClassifier.hidden_count = _hidden_count
ToolClassifier.skill_for = _skill_for
ToolClassifier.group_dormant_by_family = _group_dormant_by_family
