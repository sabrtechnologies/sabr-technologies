"""
Phase 6 — graph-first retrieval integration.

When LEON_COGNITION_RETRIEVAL=on, knowledge_search results are augmented
with graph entity context: the query is matched against graph entity
names (substring + case-insensitive), and matching entities + their
top neighbors are returned alongside the standard FTS/neural-rank hits.

Behaviour:
  * Pass-through when env flag off
  * Pass-through when cognition graph unavailable
  * Never overrides the original search results — adds a 'graph_context'
    field with up to 5 matched entities and their top relations

This is the lightest integration: zero risk to existing search behavior,
opt-in additional structured context that the responder can consume.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.cognition.retrieval_integration")


def is_retrieval_integration_enabled() -> bool:
    return os.environ.get("LEON_COGNITION_RETRIEVAL", "off").lower() in (
        "on", "1", "true", "yes",
    )


def _get_cognition():
    try:
        import server  # type: ignore
        return getattr(server, "cognition", None)
    except Exception:
        return None


def maybe_augment_search_results(
    query: str,
    results: Dict[str, Any],
    *,
    force: bool = False,
    max_entities: int = 5,
    max_neighbors_per_entity: int = 3,
) -> Dict[str, Any]:
    """Add a 'graph_context' block to a knowledge_search result.

    Returns the same dict structure; just adds (or omits) graph_context.
    """
    if not (force or is_retrieval_integration_enabled()):
        return results
    cog = _get_cognition()
    if cog is None or getattr(cog, "graph", None) is None:
        return results
    if not query or not isinstance(results, dict):
        return results

    try:
        # Phase 11E — use the new fuzzy/acronym/type-weighted search instead
        # of the old substring-only loop. Falls back to substring if search
        # raises (e.g. older graph version).
        try:
            matched = cog.graph.search(query, limit=max_entities)
        except Exception:
            q_lower = query.lower()
            tops = cog.graph.top_entities(limit=120)
            matched = []
            for ent in tops:
                name = (ent.get("name") or "").lower()
                if len(name) < 3:
                    continue
                if name in q_lower or any(t in name for t in q_lower.split() if len(t) > 2):
                    matched.append(ent)
                    if len(matched) >= max_entities:
                        break
        if not matched:
            return results

        # For each matched entity, pull top neighbors
        graph_context: List[Dict[str, Any]] = []
        for ent in matched:
            try:
                nbrs = cog.graph.neighbors(int(ent["id"]),
                                            limit=max_neighbors_per_entity)
                graph_context.append({
                    "entity": {
                        "id": ent["id"],
                        "type": ent["type"],
                        "name": ent["name"],
                        "mention_count": ent.get("mention_count", 1),
                        "salience": ent.get("salience", 1.0),
                    },
                    "neighbors": [
                        {
                            "name": n["name"],
                            "type": n["type"],
                            "relation": n.get("relation"),
                            "weight": n.get("weight"),
                        } for n in nbrs
                    ],
                })
            except Exception:
                continue

        if graph_context:
            # Inject into the inner result dict if present, else top-level
            inner = results.get("result") if isinstance(results, dict) else None
            if isinstance(inner, dict):
                inner["graph_context"] = graph_context
            else:
                results["graph_context"] = graph_context

    except Exception as e:
        log.warning("maybe_augment_search_results failed: %s", e)

    return results
