"""
Phase 13 — Self-repair queue.

When a tool fails, the failure classifier picks a kind. For repairable
kinds, this module proposes a fix and either:

  • Auto-applies a tiny, reversible local fix (REPAIR_AUTO whitelist)
  • Or files an approval-required item to ~/.openclaw/agent-board/ for Dean

Auto-fix examples (each has a rollback or is naturally idempotent):
  • brave_cdp.reconnect      — re-fetch /json from 9222 (read-only)
  • actuator.restart_socket  — kick the actuator helper
  • cdp.refresh_tab          — re-open active tab (after stale_selector)
  • dns.flush                — `resolvectl flush-caches` (system-level; OFF by
                                default unless LEON_REPAIR_NETWORK=on)

Risky fixes that need Dean approval:
  • restart leon.service     — would interrupt active turn
  • kill duplicate brains    — destructive
  • pip install <pkg>        — modifies environment
  • re-auth flows            — requires Dean's hands

This module NEVER edits source code. Code repair is a Dean-approval-only
path (and is shipped as a suggestion, not an autonomous action).

Storage: ~/.leon/self_repair.db — proposals + decisions for audit.
"""

from __future__ import annotations

import logging
import os
import json
import sqlite3
import subprocess
import threading
import time
import urllib.request
from dataclasses import dataclass, asdict
from typing import Any, Callable, Dict, List, Optional

from brain.cognition import failure_classifier as fc

log = logging.getLogger("leon.cognition.self_repair")


_SCHEMA = """
CREATE TABLE IF NOT EXISTS proposals (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ts            REAL NOT NULL,
    tool          TEXT NOT NULL,
    kind          TEXT NOT NULL,         -- failure kind
    repair        TEXT NOT NULL,         -- repair handler name
    auto          INTEGER NOT NULL,      -- 0/1: auto-apply attempted?
    applied       INTEGER NOT NULL DEFAULT 0,
    applied_ts    REAL,
    outcome       TEXT,                  -- "ok" | "fail:<err>" | "skipped" | "pending_approval"
    detail        TEXT,
    args_json     TEXT,
    approval_id   TEXT                   -- agent-board file basename if filed
);
CREATE INDEX IF NOT EXISTS idx_proposals_tool ON proposals(tool);
CREATE INDEX IF NOT EXISTS idx_proposals_ts ON proposals(ts DESC);
"""


# ── Repair handlers (each: callable, returns dict {ok, detail}) ───────────


def _repair_brave_cdp_reconnect(args=None) -> Dict[str, Any]:
    try:
        req = urllib.request.Request("http://127.0.0.1:9222/json/version",
                                       method="GET")
        with urllib.request.urlopen(req, timeout=1.0) as resp:
            return {"ok": True, "detail": f"cdp version {resp.status}"}
    except Exception as e:
        return {"ok": False, "detail": f"cdp still unreachable: {e}"}


def _repair_actuator_restart(args=None) -> Dict[str, Any]:
    """Try to bounce the actuator socket. Idempotent."""
    try:
        from brain import actuator_client
        # Best-effort: many implementations expose a reset/ping.
        reset = (getattr(actuator_client, "reset", None)
                 or getattr(actuator_client, "reconnect", None))
        if reset is not None:
            try:
                reset()
            except Exception as e:
                return {"ok": False, "detail": f"reset raised: {e}"}
        alive = getattr(actuator_client, "is_alive", lambda: False)()
        return {"ok": bool(alive),
                "detail": "alive" if alive else "still dead — needs Dean"}
    except Exception as e:
        return {"ok": False, "detail": str(e)}


def _repair_dns_retry(args=None) -> Dict[str, Any]:
    if os.environ.get("LEON_REPAIR_NETWORK", "off").lower() not in ("on", "1", "true"):
        return {"ok": False, "detail": "network repairs disabled (set LEON_REPAIR_NETWORK=on)"}
    try:
        r = subprocess.run(["resolvectl", "flush-caches"],
                           capture_output=True, text=True, timeout=2.0)
        return {"ok": r.returncode == 0,
                "detail": (r.stdout + r.stderr)[:120]}
    except Exception as e:
        return {"ok": False, "detail": str(e)}


def _repair_stale_selector(args=None) -> Dict[str, Any]:
    # No actual side effect — just a hint. The next browser call will refetch.
    return {"ok": True, "detail": "selector cache will be rebuilt next call"}


# Map failure kinds → (repair_name, handler, auto_apply_safe)
# `auto_apply_safe` means: side-effects are confined + reversible + cheap.
REPAIR_TABLE: Dict[str, Dict[str, Any]] = {
    fc.KIND_NETWORK: {
        "name": "dns.retry",
        "fn":   _repair_dns_retry,
        "auto": True,
    },
    fc.KIND_STALE_SELECTOR: {
        "name": "selector.refresh_hint",
        "fn":   _repair_stale_selector,
        "auto": True,
    },
    fc.KIND_TIMEOUT: {
        "name": "noop.timeout_logged",
        "fn":   lambda args=None: {"ok": True, "detail": "logged for future budget tuning"},
        "auto": True,
    },
    # auth / dep / permission need Dean
}


# Per-tool overrides (more specific than kind-based)
TOOL_REPAIR_TABLE: Dict[str, Dict[str, Any]] = {
    "browser.cdp": {
        "name": "brave_cdp.reconnect",
        "fn":   _repair_brave_cdp_reconnect,
        "auto": True,
    },
    "actuator.socket": {
        "name": "actuator.restart_socket",
        "fn":   _repair_actuator_restart,
        "auto": True,
    },
}


# Risky proposals shipped to Dean rather than auto-applied
APPROVAL_REQUIRED = {
    "kill_duplicate_brains", "restart_leon_service",
    "pip_install", "apt_install", "reauth_google",
    "reauth_anthropic", "regenerate_token",
}


@dataclass
class Proposal:
    id: int
    ts: float
    tool: str
    kind: str
    repair: str
    auto: bool
    applied: bool
    applied_ts: Optional[float]
    outcome: Optional[str]
    detail: Optional[str]
    args: Dict[str, Any]
    approval_id: Optional[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class SelfRepair:
    """Queue + dispatcher for repair proposals."""

    def __init__(self, *, path: Optional[str] = None,
                 agent_board_dir: Optional[str] = None,
                 executive=None):  # Phase 15 — for simulate() pre-flight
        self.path = path or os.path.expanduser("~/.leon/self_repair.db")
        self.agent_board = (agent_board_dir
                            or os.path.expanduser("~/.openclaw/agent-board/requests"))
        # Phase 15 — when an executive is supplied, simulate() runs before
        # any auto-apply. Risky outcomes escalate to Dean approval instead.
        self.executive = executive
        # Phase 16 — cooldown guard. Without this, a tool stuck in a retry
        # loop (e.g. dns.retry against a dead connection) files a fresh
        # agent-board approval file on EVERY failure, forever, since nothing
        # ever reads/clears them. Found 10,560 stuck files 2026-08-20.
        self._approval_cooldown_s = 3600.0
        self._last_approval_ts: Dict[str, float] = {}
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            self.path, check_same_thread=False, isolation_level=None,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass

    # -- entry point ---------------------------------------------------

    def on_failure(
        self,
        tool: str,
        *,
        result: Any = None,
        exception_text: Optional[str] = None,
        latency_ms: float = 0.0,
        auto_apply: bool = True,
    ) -> Optional[Proposal]:
        """Called by tool_health (or close-wrap shim) on a failure.

        Picks a repair if one exists, optionally auto-applies, and records
        the proposal. Returns the Proposal row or None if no repair known.
        """
        failure = fc.classify(result, exception_text=exception_text, tool=tool)
        if failure.kind == fc.KIND_OK:
            return None

        # Tool-specific override wins
        entry = TOOL_REPAIR_TABLE.get(tool) or REPAIR_TABLE.get(failure.kind)
        if entry is None:
            return self._record_no_repair(tool, failure)

        repair_name = entry["name"]
        handler: Callable = entry["fn"]
        is_auto = bool(entry.get("auto", False)) and auto_apply

        if repair_name in APPROVAL_REQUIRED:
            return self._file_for_approval(tool, failure, repair_name)

        # Phase 15 — simulate() pre-flight. If the executive is available
        # AND the predicted outcome is risky, escalate instead of auto-applying.
        if is_auto and self.executive is not None:
            try:
                sim = self.executive.simulate(
                    strategy="reflex_tool",
                    tools=[tool],
                )
                if sim.p_success < 0.4 or sim.rollback_cost == "expensive":
                    # Too risky to auto-apply — file for Dean approval.
                    return self._file_for_approval_with_sim(
                        tool, failure, repair_name, sim)
            except Exception as e:
                log.warning("self_repair simulate() failed: %s", e)

        # Auto-apply path
        outcome = None
        detail = None
        applied = False
        applied_ts: Optional[float] = None
        if is_auto:
            try:
                r = handler({"failure": failure.to_dict()})
                applied = True
                applied_ts = time.time()
                ok = bool(r.get("ok"))
                outcome = "ok" if ok else f"fail:{(r.get('detail') or '')[:80]}"
                detail = r.get("detail") or ""
            except Exception as e:
                applied = True
                applied_ts = time.time()
                outcome = f"fail:exception:{e}"
                detail = str(e)
        else:
            outcome = "skipped"
            detail = "auto-apply disabled by policy"

        return self._record(tool, failure, repair_name, is_auto,
                            applied, applied_ts, outcome, detail)

    # -- inspection ---------------------------------------------------

    def recent(self, limit: int = 50) -> List[Proposal]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM proposals ORDER BY ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [_row_to_proposal(r) for r in rows]

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            n = self._conn.execute("SELECT COUNT(*) AS n FROM proposals").fetchone()["n"]
            ok = self._conn.execute(
                "SELECT COUNT(*) AS n FROM proposals WHERE outcome='ok'"
            ).fetchone()["n"]
            failed = self._conn.execute(
                "SELECT COUNT(*) AS n FROM proposals WHERE outcome LIKE 'fail%'"
            ).fetchone()["n"]
            pending = self._conn.execute(
                "SELECT COUNT(*) AS n FROM proposals WHERE outcome='pending_approval'"
            ).fetchone()["n"]
        return {"total": n, "ok": ok, "fail": failed, "pending_approval": pending}

    # -- internals ----------------------------------------------------

    def _record(self, tool: str, failure: fc.Failure, repair: str,
                auto: bool, applied: bool, applied_ts: Optional[float],
                outcome: Optional[str], detail: Optional[str],
                args: Optional[Dict[str, Any]] = None,
                approval_id: Optional[str] = None) -> Proposal:
        ts = time.time()
        with self._lock:
            cur = self._conn.execute(
                """INSERT INTO proposals
                    (ts, tool, kind, repair, auto, applied, applied_ts,
                     outcome, detail, args_json, approval_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (ts, tool, failure.kind, repair, 1 if auto else 0,
                 1 if applied else 0, applied_ts, outcome,
                 (detail or "")[:1000],
                 json.dumps(args or {}, default=str), approval_id),
            )
            row = self._conn.execute(
                "SELECT * FROM proposals WHERE id=?", (cur.lastrowid,),
            ).fetchone()
        log.info("[self_repair] %s — %s → %s", tool, repair, outcome)
        return _row_to_proposal(row)

    def _record_no_repair(self, tool: str, failure: fc.Failure) -> Proposal:
        return self._record(tool, failure, "no_handler", False, False, None,
                             "skipped", "no known repair for kind")

    def _file_for_approval(self, tool: str, failure: fc.Failure,
                            repair_name: str) -> Proposal:
        cd_key = f"{tool}:{repair_name}"
        now = time.time()
        last = self._last_approval_ts.get(cd_key, 0.0)
        if now - last < self._approval_cooldown_s:
            return self._record(tool, failure, repair_name, False, False, None,
                                 "skipped", "approval already pending (cooldown)",
                                 approval_id=None)
        approval_id = None
        try:
            os.makedirs(self.agent_board, exist_ok=True)
            fname = f"{int(time.time())}-leon-repair-{repair_name}.json"
            req = {
                "id": fname,
                "from": "leon-cognition",
                "type": "approval",
                "description": (
                    f"Leon proposes repair `{repair_name}` for tool `{tool}` "
                    f"(failure: {failure.kind}). Awaiting Dean approval."
                ),
                "tool": tool,
                "failure": failure.to_dict(),
                "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "status": "pending",
            }
            with open(os.path.join(self.agent_board, fname), "w") as f:
                json.dump(req, f, indent=2)
            approval_id = fname
            self._last_approval_ts[cd_key] = now
        except Exception as e:
            log.warning("self_repair agent-board write failed: %s", e)
        return self._record(tool, failure, repair_name, False, False, None,
                             "pending_approval", "filed for Dean approval",
                             approval_id=approval_id)


def _row_to_proposal(row) -> Proposal:
    return Proposal(
        id=row["id"], ts=row["ts"], tool=row["tool"],
        kind=row["kind"], repair=row["repair"],
        auto=bool(row["auto"]), applied=bool(row["applied"]),
        applied_ts=row["applied_ts"], outcome=row["outcome"],
        detail=row["detail"],
        args=json.loads(row["args_json"] or "{}") if row["args_json"] else {},
        approval_id=row["approval_id"],
    )


__all__ = ["SelfRepair", "Proposal"]


# ── Phase 15 — simulate-aware approval helper ───────────────────────────

def _file_for_approval_with_sim(self, tool: str, failure,
                                  repair_name: str, sim) -> Proposal:
    """Like _file_for_approval but includes simulation rationale."""
    cd_key = f"{tool}:{repair_name}:sim"
    now = time.time()
    last = self._last_approval_ts.get(cd_key, 0.0)
    if now - last < self._approval_cooldown_s:
        detail_text = (f"sim p_success={sim.p_success} "
                        f"rollback={sim.rollback_cost} "
                        f"dep_risk={sim.dependency_risk} (cooldown, no new file)")
        return self._record(
            tool, failure, repair_name, False, False, None,
            "skipped", detail_text, approval_id=None,
        )
    approval_id = None
    try:
        os.makedirs(self.agent_board, exist_ok=True)
        fname = f"{int(time.time())}-leon-repair-sim-{repair_name}.json"
        req = {
            "id": fname,
            "from": "leon-cognition",
            "type": "approval",
            "description": (
                f"Leon proposes repair `{repair_name}` for tool `{tool}` "
                f"(failure: {failure.kind}), but pre-action simulate() flagged "
                f"this as risky — p_success={sim.p_success}, "
                f"rollback={sim.rollback_cost}, "
                f"dep_risk={sim.dependency_risk}. Awaiting Dean approval."
            ),
            "tool": tool,
            "failure": failure.to_dict(),
            "simulation": sim.to_dict(),
            "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "status": "pending",
        }
        with open(os.path.join(self.agent_board, fname), "w") as f:
            json.dump(req, f, indent=2)
        approval_id = fname
        self._last_approval_ts[cd_key] = now
    except Exception as e:
        log.warning("self_repair sim-approval write failed: %s", e)
    detail_text = (f"sim p_success={sim.p_success} "
                    f"rollback={sim.rollback_cost} "
                    f"dep_risk={sim.dependency_risk}")
    return self._record(
        tool, failure, repair_name, False, False, None,
        "pending_approval_sim", detail_text,
        approval_id=approval_id,
    )

SelfRepair._file_for_approval_with_sim = _file_for_approval_with_sim
