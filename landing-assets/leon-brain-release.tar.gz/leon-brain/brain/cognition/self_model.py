"""
Persistent self-model — identity that survives restarts.

Replaces "identity reconstructed each turn from prompts/files" with a
durable representation of who Leon is: long-window NM averages, action
preferences ranked by reward, archetype scores, calibration history,
and an identity hash that lets us detect when the model has drifted.

Persistence: JSON at brain_state/self_model.json. Auto-saved every N
episode updates or M seconds, whichever comes first. Loaded at install
time so the very first prediction/decision starts from yesterday's self.

Data model (all serialized to JSON):
  identity        — name, birth_ts, version, hash
  nm_averages     — rolling means per window: 1h / 24h / 7d / lifetime
  preferences     — tools_preferred (top reward), tools_avoided (worst),
                    active_hours histogram, app_focus histogram
  archetypes      — derived float scores: observer, doer, patient,
                    exploratory, cautious, consolidator
  confidence_history — list of {ts, brier, n} snapshots
  drives_avg      — long-window mean of each drive (what's chronic vs spikes)
  milestones      — episode milestones (first ts, count, big numbers)

Updated on every episode close. Cheap — all updates are O(1) accumulators.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.cognition.self_model")


def _default_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "self_model.json")


# Window sizes in seconds for the rolling NM averages.
_WINDOWS = {
    "1h":   3600,
    "24h":  86_400,
    "7d":   604_800,
}

# Auto-save cadence
_SAVE_EVERY_N_EPISODES = 25
_SAVE_EVERY_S = 300.0  # 5 min


class _ExpWindowAverage:
    """Exponentially-weighted average with time-window half-life.

    Cheap to update; resistant to bursts. Stored as a single float per
    NM × window combination instead of keeping the full episode tail.
    """

    def __init__(self, half_life_s: float, initial: float = 0.5):
        self.half_life_s = half_life_s
        self.value = initial
        self.last_update = time.time()

    def update(self, new_value: float, now: Optional[float] = None) -> float:
        now = now if now is not None else time.time()
        dt = max(0.0, now - self.last_update)
        # Exponential decay weight
        if self.half_life_s > 0:
            alpha = 1.0 - 0.5 ** (dt / self.half_life_s)
        else:
            alpha = 1.0
        # Clamp alpha to keep the update smooth
        alpha = max(0.001, min(1.0, alpha))
        self.value = (1.0 - alpha) * self.value + alpha * float(new_value)
        self.last_update = now
        return self.value

    def to_dict(self) -> Dict[str, Any]:
        return {"value": round(self.value, 4), "half_life_s": self.half_life_s,
                "last_update": self.last_update}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "_ExpWindowAverage":
        inst = cls(half_life_s=float(d.get("half_life_s", 3600)),
                   initial=float(d.get("value", 0.5)))
        inst.last_update = float(d.get("last_update", time.time()))
        return inst


class SelfModel:
    """Persistent identity model. Thread-safe, JSON-backed."""

    def __init__(self, *, brain=None, path: Optional[str] = None):
        self.brain = brain
        self.path = path or _default_path()
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()
        self._dirty = False
        self._episodes_since_save = 0
        self._last_save_ts = 0.0

        # State
        self.identity = {
            "name": "Leon",
            "born_ts": time.time(),
            "version": 2,  # bumped from Phase 1 → 2
            "hash": "",
        }
        # NM rolling means: {nm_key: {window_key: _ExpWindowAverage}}
        self.nm_windows: Dict[str, Dict[str, _ExpWindowAverage]] = {
            nm: {win: _ExpWindowAverage(half_life_s=sec) for win, sec in _WINDOWS.items()}
            for nm in ("dopamine", "acetylcholine", "norepinephrine", "serotonin")
        }
        # Preferences: action_name → {reward_sum, count, last_seen}
        self.action_stats: Dict[str, Dict[str, Any]] = {}
        # Hour-of-day activity histogram
        self.active_hours: Dict[str, int] = {f"{h:02d}": 0 for h in range(24)}
        # Active-app focus histogram
        self.app_focus: Dict[str, int] = {}
        # Confidence history
        self.confidence_history: List[Dict[str, Any]] = []
        # Drive averages (running)
        self.drives_avg: Dict[str, _ExpWindowAverage] = {
            d: _ExpWindowAverage(half_life_s=86_400)
            for d in ("uncertainty", "anomaly", "friction", "continuity", "curiosity")
        }
        # Milestones
        self.milestones = {
            "first_episode_ts": None,
            "episode_count": 0,
            "milestones_hit": [],
        }

        # M4 fix: on a fresh install (file does not exist yet), load() returns
        # False and `born_ts` stays at the live time.time() from __init__.
        # If Leon crashes before the auto-save fires (25 episodes OR 5 min,
        # whichever first), the next boot gets a NEW born_ts → identity hash
        # drifts. Force a save right now so the very first boot's born_ts
        # is durable from second 0.
        loaded = self.load()
        if not loaded:
            self._dirty = True
            try:
                self.save(force=True)
            except Exception as e:
                log.warning("self_model: initial save failed: %s", e)
        self._refresh_identity_hash()

    # ── persistence -----------------------------------------------------

    def load(self) -> bool:
        try:
            with open(self.path) as f:
                d = json.load(f)
        except FileNotFoundError:
            log.info("self_model: no existing file at %s — starting fresh", self.path)
            return False
        except Exception as e:
            # NEVER let a file we could not read get silently overwritten.
            # __init__ responds to load()==False by calling save(force=True),
            # which os.replace()s this exact path — so a recoverable
            # truncation (power cut mid-write, half-flushed page) became
            # PERMANENT on the very next boot, and the only trace was this
            # one warning line in a log nobody reads. Move it aside first;
            # then a bad read costs a restart, not a life.
            try:
                quarantine = "%s.corrupt-%s" % (
                    self.path, time.strftime("%Y%m%d-%H%M%S", time.gmtime()))
                os.replace(self.path, quarantine)
                log.error("self_model: load failed (%s) — could NOT parse %s. "
                          "Moved it to %s and started fresh; the old state is "
                          "still on disk and recoverable.", e, self.path,
                          quarantine)
            except Exception as move_err:
                log.error("self_model: load failed (%s) AND could not preserve "
                          "%s (%s) — starting fresh, prior state may be lost.",
                          e, self.path, move_err)
            return False
        with self._lock:
            self.identity.update(d.get("identity", {}))
            for nm, wins in d.get("nm_windows", {}).items():
                if nm in self.nm_windows:
                    for win, payload in wins.items():
                        if win in self.nm_windows[nm]:
                            self.nm_windows[nm][win] = _ExpWindowAverage.from_dict(payload)
            self.action_stats = d.get("action_stats", {})
            self.active_hours = d.get("active_hours", self.active_hours)
            self.app_focus = d.get("app_focus", {})
            self.confidence_history = d.get("confidence_history", [])
            for drv, payload in d.get("drives_avg", {}).items():
                if drv in self.drives_avg:
                    self.drives_avg[drv] = _ExpWindowAverage.from_dict(payload)
            self.milestones.update(d.get("milestones", {}))
        log.info("self_model: loaded from %s (episode_count=%d)",
                 self.path, self.milestones.get("episode_count", 0))
        return True

    def save(self, *, force: bool = False) -> bool:
        if not (force or self._dirty):
            return False
        with self._lock:
            payload = {
                "identity": self.identity,
                "nm_windows": {
                    nm: {win: w.to_dict() for win, w in wins.items()}
                    for nm, wins in self.nm_windows.items()
                },
                "action_stats": self.action_stats,
                "active_hours": self.active_hours,
                "app_focus": self.app_focus,
                "confidence_history": self.confidence_history[-200:],  # cap
                "drives_avg": {k: v.to_dict() for k, v in self.drives_avg.items()},
                "milestones": self.milestones,
            }
            tmp = self.path + ".tmp"
            try:
                with open(tmp, "w") as f:
                    json.dump(payload, f, indent=2)
                os.replace(tmp, self.path)
                self._dirty = False
                self._episodes_since_save = 0
                self._last_save_ts = time.time()
                return True
            except Exception as e:
                log.warning("self_model: save failed: %s", e)
                return False

    # ── update path -----------------------------------------------------

    def update_from_episode(self, episode_row: Dict[str, Any]) -> None:
        """Hook called by EpisodeStore.close → update all aggregates."""
        ts = float(episode_row.get("ts") or time.time())
        with self._lock:
            if self.milestones["first_episode_ts"] is None:
                self.milestones["first_episode_ts"] = ts
            self.milestones["episode_count"] += 1

            # Milestone fanfare on round numbers
            n = self.milestones["episode_count"]
            for m in (10, 100, 500, 1000, 5000, 10000, 50000):
                if n == m and m not in self.milestones["milestones_hit"]:
                    self.milestones["milestones_hit"].append(m)

            # NM rolling averages (over all 3 windows)
            for nm in self.nm_windows:
                v = episode_row.get(f"nm_{nm}")
                if v is None:
                    continue
                for win in self.nm_windows[nm].values():
                    win.update(float(v), now=ts)

            # Hour-of-day histogram
            hour = episode_row.get("hour_of_day")
            if hour is not None:
                key = f"{int(hour):02d}"
                self.active_hours[key] = self.active_hours.get(key, 0) + 1

            # App focus histogram
            app = episode_row.get("active_app")
            if app:
                self.app_focus[app] = self.app_focus.get(app, 0) + 1

            # Action stats — accumulator with reward
            action = episode_row.get("action_name") or ""
            reward = float(episode_row.get("reward") or 0.0)
            if action:
                a = self.action_stats.get(action, {"reward_sum": 0.0, "count": 0,
                                                    "successes": 0, "last_seen": 0.0})
                a["reward_sum"] += reward
                a["count"] += 1
                if episode_row.get("success"):
                    a["successes"] += 1
                a["last_seen"] = ts
                self.action_stats[action] = a

            self._dirty = True
            self._episodes_since_save += 1
        # Auto-save outside the lock to avoid I/O while holding it
        now = time.time()
        if (self._episodes_since_save >= _SAVE_EVERY_N_EPISODES
                or now - self._last_save_ts > _SAVE_EVERY_S):
            self.save()

    def update_from_drives(self, drives_snapshot: Dict[str, Any]) -> None:
        """Periodic call to push drive levels into long-window averages."""
        drv = drives_snapshot.get("drives", {})
        with self._lock:
            for name, payload in drv.items():
                if name in self.drives_avg:
                    self.drives_avg[name].update(float(payload.get("value", 0.0)))
            self._dirty = True

    def append_calibration(self, *, brier: float, n: int, ts: Optional[float] = None) -> None:
        ts = ts if ts is not None else time.time()
        with self._lock:
            self.confidence_history.append({
                "ts": round(ts, 1), "brier": round(brier, 4), "n": n,
            })
            self.confidence_history = self.confidence_history[-200:]
            self._dirty = True

    # ── derived metrics -------------------------------------------------

    def _refresh_identity_hash(self) -> str:
        """Hash a stable subset of identity-defining fields. Used for drift detection."""
        with self._lock:
            material = json.dumps({
                "name": self.identity.get("name"),
                "version": self.identity.get("version"),
                "born_ts": round(float(self.identity.get("born_ts", 0)), 0),
            }, sort_keys=True).encode("utf-8")
            h = hashlib.sha256(material).hexdigest()[:12]
            self.identity["hash"] = h
        return h

    def archetypes(self) -> Dict[str, float]:
        """Derived archetype scores in [0,1]."""
        with self._lock:
            da = self.nm_windows["dopamine"]["24h"].value
            sr = self.nm_windows["serotonin"]["24h"].value
            ach = self.nm_windows["acetylcholine"]["24h"].value
            ne = self.nm_windows["norepinephrine"]["24h"].value

            # Observation vs action ratio from action_stats
            obs_count = sum(a["count"] for n, a in self.action_stats.items()
                            if any(k in n for k in ("capture", "list", "extract",
                                                     "describe", "state", "search")))
            act_count = sum(a["count"] for a in self.action_stats.values())
            obs_ratio = (obs_count / act_count) if act_count else 0.5

            # Consolidator: how often consolidate / save actions fire
            cons_count = sum(a["count"] for n, a in self.action_stats.items()
                             if any(k in n for k in ("consolidate", "save", "checkpoint")))
            cons_ratio = (cons_count / act_count) if act_count else 0.0

            return {
                "observer":     round(obs_ratio, 3),
                "doer":         round(1.0 - obs_ratio, 3),
                "patient":      round(sr, 3),
                "exploratory":  round(da, 3),
                "cautious":     round(ne, 3),
                "focused":      round(ach, 3),
                "consolidator": round(min(1.0, cons_ratio * 5), 3),
            }

    def preferred_actions(self, n: int = 10) -> List[Dict[str, Any]]:
        """Top-N actions by mean reward (min 3 trials)."""
        with self._lock:
            ranked = []
            for name, stats in self.action_stats.items():
                if stats["count"] < 3:
                    continue
                mean_r = stats["reward_sum"] / stats["count"]
                ranked.append({
                    "action": name,
                    "mean_reward": round(mean_r, 3),
                    "count": stats["count"],
                    "success_rate": round(stats["successes"] / stats["count"], 3),
                    "last_seen": stats["last_seen"],
                })
            ranked.sort(key=lambda x: -x["mean_reward"])
        return ranked[:n]

    def avoided_actions(self, n: int = 10) -> List[Dict[str, Any]]:
        with self._lock:
            ranked = []
            for name, stats in self.action_stats.items():
                if stats["count"] < 3:
                    continue
                mean_r = stats["reward_sum"] / stats["count"]
                if mean_r >= 0:
                    continue
                ranked.append({
                    "action": name,
                    "mean_reward": round(mean_r, 3),
                    "count": stats["count"],
                    "success_rate": round(stats["successes"] / stats["count"], 3),
                })
            ranked.sort(key=lambda x: x["mean_reward"])
        return ranked[:n]

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "identity": dict(self.identity),
                "nm_averages": {
                    nm: {win: round(w.value, 3) for win, w in wins.items()}
                    for nm, wins in self.nm_windows.items()
                },
                "drives_avg": {k: round(v.value, 3) for k, v in self.drives_avg.items()},
                "archetypes": self.archetypes(),
                "preferred_actions": self.preferred_actions(5),
                "avoided_actions": self.avoided_actions(5),
                "active_hours": dict(self.active_hours),
                "app_focus_top": dict(sorted(
                    self.app_focus.items(), key=lambda kv: -kv[1])[:10]),
                "milestones": dict(self.milestones),
                "confidence_recent": self.confidence_history[-10:],
                "path": self.path,
            }

    def identity_drift_score(self, *, window_s: float = 3600) -> float:
        """Quick measure of how much identity has 'moved' in window_s.

        Uses NM 1h average vs 24h average — divergence = recent shift.
        Returns 0..1+ (1.0 ≈ moderate drift).
        """
        with self._lock:
            total = 0.0
            for nm, wins in self.nm_windows.items():
                diff = abs(wins["1h"].value - wins["24h"].value)
                total += diff
        return round(total, 4)
