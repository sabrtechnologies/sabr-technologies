"""Explicit private operator configuration for the selected inner-voice path.

Loading validates one bounded existing file and creates immutable policy values.
It does not select a live feature, construct a canonical owner, or issue a grant.
Importing this module is cold; the typed owners are imported only after parsing.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
import os
import stat
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .thought_execution import ThoughtArticulationPolicy
    from .thought_intent_runtime import ThoughtIntentRuntimeConfig


_MAX_FILE_BYTES = 16384
_QUOTAS = frozenset(('max_snapshots', 'max_total_bytes',
                    'max_realization_attempts', 'max_realization_bytes', 'max_leases'))
_ARTICULATION = frozenset(('local_model', 'min_urgency', 'deadline_s', 'max_output_tokens', 'max_output_bytes'))


def _reference(value):
    if (type(value) is not str or not value.strip() or len(value.encode('utf-8')) > 200
            or any(ord(ch) < 32 or ord(ch) == 127 for ch in value)):
        raise ValueError('bounded explicit thought configuration reference required')
    return value


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate thought configuration key')
        result[key] = value
    return result


def _nonfinite(_):
    raise ValueError('nonfinite thought configuration number')


def _file_identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_ctime_ns, info.st_mode, info.st_uid, info.st_nlink)


def _directory_identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid)


def _private_json(path):
    """Read without following aliases and reject replacement or mutation.

    Directory-relative opens pin every component during traversal; the final
    directory must be operator-owned and not writable by group/other. POSIX
    ownership/no-follow guarantees are required, rather than approximated.
    """
    if (os.name != 'posix' or not all(hasattr(os, key) for key in
                                    ('O_NOFOLLOW', 'O_CLOEXEC', 'O_DIRECTORY', 'geteuid'))):
        raise ValueError('private thought configuration requires POSIX file ownership')
    if (type(path) is not str or not path or '\0' in path or not os.path.isabs(path)
            or os.path.normpath(path) != path or os.path.realpath(path) != path):
        raise ValueError('explicit unaliased absolute thought configuration path required')
    directory, filename = os.path.split(path)
    if not filename:
        raise ValueError('explicit thought configuration file required')
    directory_fd = file_fd = None
    try:
        directory_flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_DIRECTORY
        directory_fd = os.open('/', directory_flags)
        for part in directory.split('/')[1:]:
            if not part:
                continue
            next_fd = os.open(part, directory_flags, dir_fd=directory_fd)
            os.close(directory_fd)
            directory_fd = next_fd
        parent = os.fstat(directory_fd)
        if (not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.geteuid()
                or parent.st_mode & 0o022):
            raise ValueError('exclusive thought configuration directory required')
        file_fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                          dir_fd=directory_fd)
        before = os.fstat(file_fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or before.st_uid != os.geteuid() or before.st_mode & 0o077
                or not 0 < before.st_size <= _MAX_FILE_BYTES):
            raise ValueError('private bounded regular thought configuration required')
        chunks, size = [], 0
        while size <= _MAX_FILE_BYTES:
            piece = os.read(file_fd, min(4096, _MAX_FILE_BYTES + 1 - size))
            if not piece:
                break
            chunks.append(piece)
            size += len(piece)
        after = os.fstat(file_fd)
        current = os.stat(filename, dir_fd=directory_fd, follow_symlinks=False)
        current_parent = os.stat(directory, follow_symlinks=False)
        if (size > _MAX_FILE_BYTES or size != before.st_size
                or _file_identity(before) != _file_identity(after)
                or _file_identity(before) != _file_identity(current)
                or _directory_identity(parent) != _directory_identity(os.fstat(directory_fd))
                or _directory_identity(parent) != _directory_identity(current_parent)
                or os.path.realpath(path) != path):
            raise ValueError('thought configuration changed during read')
        try:
            return json.loads(b''.join(chunks).decode('utf-8'), object_pairs_hook=_unique,
                              parse_constant=_nonfinite)
        except (UnicodeError, RecursionError) as error:
            raise ValueError('bounded UTF-8 thought configuration required') from error
    finally:
        if file_fd is not None:
            os.close(file_fd)
        if directory_fd is not None:
            os.close(directory_fd)


@dataclass(frozen=True)
class ThoughtConfiguration:
    intent: ThoughtIntentRuntimeConfig
    articulation: ThoughtArticulationPolicy

    def __post_init__(self):
        from .thought_execution import ThoughtArticulationPolicy
        from .thought_intent_runtime import ThoughtIntentRuntimeConfig
        if (type(self.intent) is not ThoughtIntentRuntimeConfig
                or type(self.articulation) is not ThoughtArticulationPolicy):
            raise TypeError('exact typed thought configuration required')

    def sha256(self):
        """Bind the exact private policy; never publish this as telemetry."""
        cfg, policy = self.intent, self.articulation
        descriptor = {'schema': 1, 'principal': cfg.principal,
            'expected_identity': {'name': cfg.identity.name, 'version': cfg.identity.version,
                                  'born_ts': cfg.identity.born_ts},
            'producer': cfg.producer, 'policy_revision': cfg.policy_revision,
            'quotas': {key: getattr(cfg, key) for key in sorted(_QUOTAS)},
            'articulation': {key: getattr(policy, key) for key in sorted(_ARTICULATION)}}
        raw = json.dumps(descriptor, sort_keys=True, separators=(',', ':'),
                         ensure_ascii=False, allow_nan=False).encode('utf-8')
        return hashlib.sha256(raw).hexdigest()


def load_thought_configuration(path, *, installation_principal):
    """Load exact schema 1, binding the principal supplied by trusted startup.

    The optional expected principal is only an equality guard. The expected
    identity remains an operator declaration until the installed memory owner
    independently compares the existing canonical SelfModel and store handles.
    No JSON field can choose a provider, writer path, credential, or live mode.
    """
    principal = _reference(installation_principal)
    document = _private_json(path)
    required = {'schema', 'expected_identity', 'policy_revision', 'quotas', 'articulation'}
    if (type(document) is not dict or set(document) not in (required, required | {'expected_principal'})
            or type(document.get('schema')) is not int or document['schema'] != 1):
        raise ValueError('exact thought configuration schema required')
    if 'expected_principal' in document and _reference(document['expected_principal']) != principal:
        raise ValueError('thought configuration installation principal mismatch')
    identity = document['expected_identity']
    if type(identity) is not dict or set(identity) != {'name', 'version', 'born_ts'}:
        raise ValueError('exact expected canonical thought identity required')
    _reference(identity['name'])
    born = identity['born_ts']
    if (type(identity['version']) is not int or not 1 <= identity['version'] <= 1000000
            or type(born) not in (int, float) or not born > 0):
        raise ValueError('exact expected canonical thought identity required')
    try:
        if not math.isfinite(born):
            raise ValueError('finite canonical identity birth timestamp required')
    except OverflowError as error:
        raise ValueError('finite canonical identity birth timestamp required') from error
    revision = _reference(document['policy_revision'])
    quotas = document['quotas']
    if type(quotas) is not dict or set(quotas) != _QUOTAS:
        raise ValueError('exact thought quotas required')
    for key, value in quotas.items():
        maximum = (16 if key == 'max_leases' else 100000 if key in
                   ('max_snapshots', 'max_realization_attempts') else 64 * 1024 * 1024)
        if type(value) is not int or not 1 <= value <= maximum:
            raise ValueError('bounded thought quota required')
    articulation = document['articulation']
    if type(articulation) is not dict or set(articulation) != _ARTICULATION:
        raise ValueError('exact thought articulation policy required')
    model = articulation['local_model']
    if type(model) is not str or not 1 <= len(model) <= 128 or not model.isascii():
        raise ValueError('explicit bounded local thought model required')
    urgency, deadline = articulation['min_urgency'], articulation['deadline_s']
    if (type(urgency) not in (int, float) or not 0 <= urgency <= 1 or not math.isfinite(urgency)
            or type(deadline) not in (int, float) or not 0 < deadline <= 15 or not math.isfinite(deadline)):
        raise ValueError('bounded thought urgency and deadline required')
    for key, maximum in (('max_output_tokens', 256), ('max_output_bytes', 8192)):
        if type(articulation[key]) is not int or not 1 <= articulation[key] <= maximum:
            raise ValueError('bounded thought output policy required')
    from .thought_execution import ThoughtArticulationPolicy
    from .thought_intent_runtime import CanonicalThoughtIdentity, ThoughtIntentRuntimeConfig
    cfg = ThoughtIntentRuntimeConfig(principal=principal,
        identity=CanonicalThoughtIdentity(**identity), policy_revision=revision,
        producer='inner_voice', **quotas)
    policy = ThoughtArticulationPolicy(local_model=model,
        min_urgency=float(urgency), deadline_s=float(deadline),
        max_output_tokens=articulation['max_output_tokens'],
        max_output_bytes=articulation['max_output_bytes'])
    return ThoughtConfiguration(cfg, policy)
