"""Optional supervised planner owned by the existing TaskRuntime.

No loop, worker, database, direct provider or automatic approval is created.
Blocking advance calls belong on an existing executive executor, never ticks.
"""
from contextlib import contextmanager
from dataclasses import asdict, dataclass
import threading

from . import inference_scheduler as scheduling
from .task_planner import TaskPlanner, PlannerDenied
from .task_planner_ingress import PlannerIngress, PlanScope


@dataclass(frozen=True)
class TaskPlannerRuntimeConfig:
    """Trusted installation capabilities, never deserialized from a request."""
    resolve_scope: object
    resolve_approval: object
    enabled: object = lambda: False

    def __post_init__(self):
        if not all(callable(value) for value in
                   (self.resolve_scope, self.resolve_approval, self.enabled)):
            raise TypeError('trusted planner resolvers and selector required')


@dataclass(frozen=True)
class TaskPlannerOperatorConfig:
    """Explicit operator scopes with durable authenticated approval ownership."""
    scopes: tuple
    enabled: object = lambda: False

    def __post_init__(self):
        if (type(self.scopes) is not tuple or not 1 <= len(self.scopes) <= 16
                or any(type(scope) is not PlanScope for scope in self.scopes)
                or len({scope.project_scope for scope in self.scopes}) != len(self.scopes)
                or not callable(self.enabled)):
            raise TypeError('explicit typed operator scopes and selector required')


class PlannerRuntime:
    def __init__(self, runtime, configuration):
        if type(configuration) not in (TaskPlannerRuntimeConfig, TaskPlannerOperatorConfig):
            raise TypeError('typed trusted planner configuration required')
        self.runtime, self.configuration = runtime, configuration
        self._lock = threading.Lock()
        self._stopping, self._calls = False, 0
        self.scheduler = self.planner = None
        self.approval_authority = None
        if type(configuration) is TaskPlannerOperatorConfig:
            from .task_planner_authority import PlannerAuthority
            self.approval_authority = PlannerAuthority(runtime, configuration.scopes, enabled=self.selected)
            scope, approval = self.approval_authority.resolve_scope, self.approval_authority.resolve_approval
        else:
            scope, approval = configuration.resolve_scope, configuration.resolve_approval
        self.ingress = PlannerIngress(runtime, resolve_scope=scope,
            resolve_approval=approval, enabled=self.selected)

    def selected(self):
        """Pure selection; ingress already checks health before its store lock."""
        try:
            return (not self._stopping and not self.runtime._stopping
                    and self.configuration.enabled() is True
                    and self.scheduler is not None
                    and scheduling.get_scheduler() is self.scheduler)
        except Exception:
            return False

    def enabled(self):
        return self.selected() and self.runtime._enabled()

    def prepare(self):
        # Root assigns this owner before preparation, and assigns the ingress
        # resolver before any retained child can be claimed by TaskWorker.
        if self.approval_authority is not None:
            self.approval_authority.prepare()
        self.ingress.prepare()
        if self.approval_authority is not None:
            self.approval_authority.bind_ingress(self.ingress)
        self.planner = TaskPlanner(store=self.runtime._store, scheduler=None,
            backend=self.runtime._backend, resolve_context=self.ingress.resolve_context,
            ingress=self.ingress, enabled=self.enabled, clock=self.runtime._clock)
        # Startup is already trusted and authenticated by TaskRuntime. Bind an
        # available scheduler before workers can claim retained approved children.
        # Missing/OFF optional scheduler still leaves single checks usable.
        self._bind_scheduler()
        return self

    def _bind_scheduler(self):
        # A cold optional planner cannot disable independently approved checks.
        # Bind only once when explicitly selected and an installed owner exists.
        with self._lock:
            if self.scheduler is None and not self._stopping and self.configuration.enabled() is True:
                scheduler = scheduling.get_scheduler()
                if scheduler is not None:
                    self.scheduler = self.planner.scheduler = scheduler

    @contextmanager
    def _operation(self, principal, *, active=False):
        with self._lock:
            if self._stopping or self.planner is None:
                raise PlannerDenied('planner owner unavailable')
            self._calls += 1
        try:
            # Authentication/availability check only. Never retain this lock
            # while acquiring planner locks or waiting for scheduler output.
            with self.runtime._access(principal, active=active):
                pass
            if active:
                self._bind_scheduler()
                if not self.enabled():
                    raise PlannerDenied('planner admission disabled')
            yield
        finally:
            with self._lock:
                self._calls -= 1

    def register(self, *, principal, scope, goal, idempotency_key, authorization_ref, approved):
        with self._operation(principal, active=True):
            context = self.ingress.register_plan(principal=principal, scope=scope, goal=goal,
                idempotency_key=idempotency_key, authorization_ref=authorization_ref, approved=approved)
            return self.planner.initialize(context.task_id, principal=principal, goal=goal)

    def advance(self, task_id, *, principal, retry_interrupted=False):
        with self._operation(principal, active=True):
            self.ingress.require_active_parent(task_id, principal=principal)
            return self.planner.advance(task_id, principal=principal, retry_interrupted=retry_interrupted)

    def proposal(self, task_id, *, principal):
        with self._operation(principal):
            return self.planner.proposal(task_id, principal=principal)

    def review(self, task_id, *, principal):
        with self._operation(principal, active=True):
            if self.approval_authority is None:
                raise PlannerDenied('operator approval authority not configured')
            return self.approval_authority.review(task_id, principal=principal)

    def approve_review(self, task_id, *, principal, proposal_sha256, review_sha256,
                       idempotency_key, validity_s, approved):
        with self._operation(principal):
            if self.approval_authority is None:
                raise PlannerDenied('operator approval authority not configured')
            self._bind_scheduler()
            approval = self.approval_authority.approve(task_id, principal=principal,
                proposal_sha256=proposal_sha256, review_sha256=review_sha256,
                idempotency_key=idempotency_key, validity_s=validity_s, approved=approved)
            # Timestamp/reference are produced by the owned registry, never by
            # an HTTP/model caller. Existing children are historical recovery.
            return self.approve(task_id, principal=principal, proposal_sha256=approval.proposal_sha256,
                approval_ref=approval.approval_ref, expires_wall=approval.expires_wall, approved=True)

    def approve(self, task_id, *, principal, proposal_sha256, approval_ref, approved, expires_wall):
        with self._operation(principal):
            if approved is not True:
                raise PlannerDenied('explicit exact approval required')
            context = self.ingress.resolve_context(task_id)
            if context is None or context.principal != principal:
                raise PlannerDenied('registered plan principal required')
            view = self.planner.proposal(task_id, principal=principal)
            recovered = self.ingress.lookup_approved_step(task_id, principal=principal,
                proposal_sha256=proposal_sha256, approval_ref=approval_ref, expires_wall=expires_wall)
            if recovered is not None:
                return {**view, 'child': asdict(recovered), 'recovered_approval': True}
            identity = self.ingress.lookup_step(context=context,
                step_key='planner-step:'+str(view['step']+1))
            # Existing committed children are read-only recovery. Never issue
            # a new grant or extend expiry merely to reconstruct a lost reply.
            if identity is None:
                self._bind_scheduler()
                if not self.enabled():
                    raise PlannerDenied('planner admission disabled')
                self.ingress.record_approval(task_id, principal=principal,
                    proposal_sha256=proposal_sha256, approval_ref=approval_ref,
                    approved=approved, expires_wall=expires_wall)
            return self.planner.approve_step(task_id, principal=principal,
                proposal_sha256=proposal_sha256, approval_ref=approval_ref, approved=approved)

    def poll(self, task_id, *, principal):
        with self._operation(principal):
            return self.planner.poll(task_id, principal=principal)

    def acknowledge_completion(self, task_id, *, principal, proposal_sha256, approved):
        with self._operation(principal, active=True):
            self.ingress.require_active_parent(task_id, principal=principal)
            return self.planner.acknowledge_completion(task_id, principal=principal,
                proposal_sha256=proposal_sha256, approved=approved)

    def cancel(self, task_id, *, principal):
        with self._operation(principal):
            self.ingress.cancel_plan(task_id, principal=principal)
            return self.planner.cancel(task_id, principal=principal)

    def quiesce(self):
        self._stopping = True
        return self.planner is None or self.planner.quiesce()

    @property
    def drained(self):
        if not self._lock.acquire(blocking=False):
            return False
        try:
            if self._calls:
                return False
        finally:
            self._lock.release()
        return self.planner is None or self.planner.drained
