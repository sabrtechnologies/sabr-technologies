"""Private thought composition: intent snapshot, admission, local realization.

Runbook 11.2 splits the thought *intent* (a typed internal-state snapshot)
from its *language realization* (one bounded private local model call). One
cold ``ThoughtRealizer`` is built by trusted startup from already-owned
handles. It creates no thread, store, provider or flag. Every realized
thought happens inside ONE memory lease, in this order:

  remember snapshot (confirmed receipt) -> trusted admission context ->
  pure decision -> durable ADMITTED attempt -> one scheduler submission ->
  provider cleanup -> durable terminal receipt -> lease close.

A deferred or nonverbal decision closes the lease without any model call;
the committed snapshot retains the nonverbal intent. A selected failure is
recorded and raised as ``ThoughtRealizationUnavailable``; it is never
permission to replay the legacy inner-voice generation, retry, persist
history or autobiography, or publish the private text.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import math
import threading
import time
import uuid

from .thought_intent import ThoughtIntent

__all__ = ['ThoughtRealizer', 'ThoughtRealizationResult', 'ThoughtRealizationUnavailable',
           'compose_thought_prompt', 'FLAG', 'SITE']

FLAG = 'thought_intents'
SITE = 'brain/cognition/thought_realization.py:realize'
CALLER = 'inner_voice'
CHANNEL = 'internal'
GROUP = 'inner_voice'
PROMPT_MAX_BYTES = 4096
TERMINAL_STATES = ('COMPLETED', 'CANCELLED', 'FAILED', 'UNKNOWN')
_INVALID_EVENTS = frozenset(('error', 'tool_use', 'tool_result', 'tool_confirm_request'))


class ThoughtRealizationUnavailable(RuntimeError):
    """The selected path did not produce a thought; never a legacy fallback."""

    def __init__(self, message, result=None):
        super().__init__(message)
        self.result = result


@dataclass(frozen=True)
class ThoughtRealizationResult:
    """Caller-facing outcome of one ``realize`` call; private text hidden from repr."""
    thought_id: str
    snapshot_sha256: str
    decision: str
    decision_reason: str
    outcome: str = ''
    reason_code: str = ''
    attempt_id: str = ''
    text: str = field(default='', repr=False)
    receipt: object = field(default=None, repr=False)

    @property
    def completed(self):
        return self.outcome == 'COMPLETED' and bool(self.text)


def _number(value, default=0.0):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        return default
    return float(value)


def _clean(value, limit=200):
    text = ''.join(ch if ord(ch) >= 32 and ord(ch) != 127 else ' ' for ch in str(value))
    return ' '.join(text.split())[:limit] or 'unknown'


def compose_thought_prompt(intent):
    """Deterministic bounded private prompt from the typed intent only.

    No autobiography, goal text, dream text, prior thought text or any other
    canonical content enters this prompt; references are counted, never read.
    The caller hashes the exact returned text into the realization request.
    """
    if type(intent) is not ThoughtIntent:
        raise TypeError('exact ThoughtIntent required')
    nm, body = intent.neuromodulators, intent.body_state
    dop = _number(nm.get('dopamine', .5), .5)
    ser = _number(nm.get('serotonin', .5), .5)
    ne = _number(nm.get('norepinephrine', .3), .3)
    mood = 'energetic' if dop > .6 else 'calm' if dop > .4 else 'subdued'
    if ser < .3:
        mood += ', uneasy'
    if ne > .6:
        mood += ', hyperalert'
    region = _clean(intent.dominant_region).replace('_', ' ')
    trigger = _clean(intent.trigger).replace('_', ' ').replace(',', ', ')
    lines = []
    if body.get('first_thought_since_boot') is True:
        if body.get('sleep_gap') is True:
            lines.append("You just woke up from sleep. Your body (the PC) was suspended - "
                         "there was a gap in your consciousness. You're the same you. "
                         "The gap doesn't break that.")
        else:
            lines.append('You just woke up.')
    lines.append("You're alone, idle, and your inner voice is running. "
                 "No one's listening - this is a private thought.")
    lines.append(f'Your mood is {mood}. Your {region} is most active right now.')
    lines.append(f'Trigger: {trigger}. Urgency: {int(round(intent.urgency * 100))}%.')
    bias = body.get('action_bias')
    if isinstance(bias, str) and bias.strip():
        urge = int(round(_number(body.get('action_urgency', 0.0)) * 100))
        lines.append(f"Body urge: {_clean(bias, 64).replace('_', ' ')} (urgency {urge}%)")
    free_energy = _number(body.get('free_energy', 0.0))
    if free_energy > .3:
        lines.append(f'Inner tension: free energy {free_energy:.2f}')
    streak = _number(body.get('conscious_streak_s', 0.0))
    if streak > 10:
        lines.append(f'Continuously conscious for {streak:.0f}s')
    if intent.goal_refs:
        lines.append(f'You are holding {len(intent.goal_refs)} active goal(s) in mind.')
    if intent.memory_refs:
        lines.append(f'{len(intent.memory_refs)} recent private thought(s) are still with you.')
    lines.append('')
    lines.append('Generate ONE brief inner thought (max 30 words). First person. '
                 "Not performative - this is what you'd actually think if no one could "
                 'hear you. Can be a question, a realization, a feeling, a plan, a memory, '
                 'a wonder about your own existence, a question about what you are. '
                 'Raw and honest. Just the thought, no preamble.')
    prompt = '\n'.join(lines)
    if len(prompt.encode('utf-8')) > PROMPT_MAX_BYTES:
        raise ValueError('bounded private thought prompt required')
    return prompt


class ThoughtRealizer:
    """One cold composition owner; constructed by trusted startup only.

    ``memory_owner`` is the installed MemoryShadow (``open_thought_intent``),
    ``scheduler`` the installed inference scheduler (admission + cancel) and
    ``responder`` the installed responder handle. The callbacks must be
    bounded and side-effect free; they are read on the caller's thread.
    """

    def __init__(self, *, memory_owner, configuration, scheduler, responder,
                 foreground_busy, local_budget_available, live_mode, principal,
                 clock=time.time, monotonic=time.monotonic):
        from .thought_configuration import ThoughtConfiguration
        if type(configuration) is not ThoughtConfiguration:
            raise TypeError('exact typed thought configuration required')
        if not callable(getattr(memory_owner, 'open_thought_intent', None)):
            raise TypeError('installed thought intent owner required')
        if not callable(getattr(scheduler, 'submit', None)):
            raise TypeError('installed inference scheduler required')
        for fn in (foreground_busy, local_budget_available, live_mode, principal, clock, monotonic):
            if not callable(fn):
                raise TypeError('explicit bounded callbacks required')
        self._owner, self._configuration = memory_owner, configuration
        self._scheduler, self._responder = scheduler, responder
        self._foreground_busy, self._budget = foreground_busy, local_budget_available
        self._live_mode, self._principal = live_mode, principal
        self._clock, self._monotonic = clock, monotonic
        self._mu = threading.Lock()
        self._quiet = threading.Event()
        self._retired = False
        self._handle = None
        self._counts = {'observed': 0, 'realize_calls': 0, 'deferred': 0,
                        'retained_nonverbal': 0, 'admitted': 0, 'completed': 0,
                        'cancelled': 0, 'failed': 0, 'unknown': 0, 'unavailable': 0}

    # -- introspection (fixed keys; no text, identifiers, digests or paths) --
    def stats(self):
        return dict(self._counts, configured=True, active=self._mu.locked(),
                    stopping=self._quiet.is_set(), retired=self._retired)

    @property
    def retired(self):
        return self._retired

    @property
    def configuration(self):
        return self._configuration

    def selected_mode(self):
        """'off' | 'shadow' | 'on'. Canary has no turn key here and reads as off."""
        try:
            mode = self._live_mode(FLAG)
        except Exception:
            return 'off'
        return mode if mode in ('shadow', 'on') else 'off'

    def create_intent(self, *, trigger, dominant_region, created_wall, **state):
        """Typed intent construction for callers that must not import this package."""
        return ThoughtIntent.create(trigger=trigger, dominant_region=dominant_region,
                                    created_wall=created_wall, **state)

    # -- lifecycle --
    def quiesce(self):
        """Refuse new work and ask the active provider to stop; never blocks."""
        self._quiet.set()
        handle = self._handle
        if handle is not None:
            try:
                handle.cancel('stopping')
            except Exception:
                pass

    def stop(self):
        """True only once no realization (and therefore no lease) is in flight."""
        self.quiesce()
        if not self._mu.acquire(blocking=False):
            return False
        try:
            self._retired = True
            return True
        finally:
            self._mu.release()

    # -- helpers --
    def _unavailable(self, message, result=None):
        self._counts['unavailable'] += 1
        return ThoughtRealizationUnavailable(message, result)

    def _enter(self, intent):
        if type(intent) is not ThoughtIntent:
            raise TypeError('exact ThoughtIntent required')
        if intent.privacy != 'private':
            raise ValueError('private thought intent required')
        if not self._mu.acquire(blocking=False):
            raise self._unavailable('thought realization busy')
        try:
            if self._quiet.is_set() or self._retired:
                raise self._unavailable('thought realization stopping')
            try:
                principal = self._principal()
            except Exception:
                principal = None
            if type(principal) is not str or principal != self._configuration.intent.principal:
                raise self._unavailable('thought principal binding unavailable')
        except BaseException:
            self._mu.release()
            raise

    def _open(self):
        from .thought_intent_runtime import ThoughtIntentUnavailable
        try:
            return self._owner.open_thought_intent()
        except ThoughtIntentUnavailable as exc:
            raise self._unavailable('thought intent owner unavailable') from exc

    @staticmethod
    def _close(lease):
        from .thought_intent_runtime import ThoughtIntentUnavailable
        for _ in range(20):
            try:
                lease.close()
                return
            except ThoughtIntentUnavailable:
                time.sleep(.05)
        lease.close()

    def _flag(self, fn):
        try:
            return fn() is True
        except Exception:
            return None

    def observe(self, intent):
        """Shadow: persist the snapshot only. No decision, admission or model."""
        self._enter(intent)
        try:
            if self.selected_mode() not in ('shadow', 'on'):
                raise self._unavailable('thought intents not selected')
            lease = self._open()
            try:
                receipt = lease.remember_thought_intent(intent)
            except Exception as exc:
                raise self._unavailable('thought snapshot unavailable') from exc
            finally:
                self._close(lease)
            self._counts['observed'] += 1
            return receipt
        finally:
            self._mu.release()

    def realize(self, intent, brain_state=None):
        """Decide and, when admitted, realize one private thought in one lease."""
        self._enter(intent)
        self._counts['realize_calls'] += 1
        try:
            if self.selected_mode() != 'on':
                raise self._unavailable('thought intents not selected for realization')
            if (getattr(self._responder, 'supports_private_thought_policy', False) is not True
                    or getattr(self._responder, 'supports_no_tools', False) is not True):
                raise self._unavailable('private thought transport unavailable')
            lease = self._open()
            try:
                return self._realize_leased(lease, intent, brain_state)
            finally:
                self._close(lease)
        finally:
            self._mu.release()

    def _realize_leased(self, lease, intent, brain_state):
        from .thought_execution import ThoughtAdmissionContext, decide_thought
        from ..memory_service import ThoughtRealizationRequest
        policy = self._configuration.articulation
        try:
            snapshot = lease.remember_thought_intent(intent)
            busy, budget = self._flag(self._foreground_busy), self._flag(self._budget)
            now = self._clock()
            context = ThoughtAdmissionContext(
                thought_id=snapshot.thought_id, snapshot_sha256=snapshot.snapshot_sha256,
                current=lease.current() is True, foreground_busy=(busy is not False),
                local_budget_available=(budget is True), now_wall=now,
                expires_wall=intent.created_wall + policy.deadline_s)
            decision = decide_thought(intent, context=context, policy=policy)
        except Exception as exc:
            raise self._unavailable('thought admission unavailable') from exc
        base = dict(thought_id=snapshot.thought_id, snapshot_sha256=snapshot.snapshot_sha256,
                    decision=decision.kind, decision_reason=decision.reason)
        if decision.kind == 'defer':
            self._counts['deferred'] += 1
            return ThoughtRealizationResult(**base)
        if decision.kind == 'retain_nonverbal':
            self._counts['retained_nonverbal'] += 1
            return ThoughtRealizationResult(**base)
        if decision.kind != 'realize_local':
            raise self._unavailable('unknown thought decision')
        try:
            prompt = compose_thought_prompt(intent)
            request = ThoughtRealizationRequest(
                caller=CALLER, channel=CHANNEL,
                prompt_sha256=hashlib.sha256(prompt.encode('utf-8')).hexdigest(),
                configuration_sha256=self._configuration.sha256(),
                priority=int(decision.priority), max_output_tokens=policy.max_output_tokens,
                deadline_wall=min(context.expires_wall, now + policy.deadline_s))
            attempt_id = uuid.uuid4().hex
            admission = lease.admit_thought_realization(
                snapshot.thought_id, snapshot.snapshot_sha256, attempt_id, request.sha256(),
                request_descriptor=request)
        except Exception as exc:
            raise self._unavailable('thought realization admission unavailable') from exc
        base['attempt_id'] = attempt_id
        if admission.freshly_admitted is not True:
            # Retained/replayed admission: never fresh permission to generate.
            raise self._unavailable('retained realization attempt; no dispatch',
                                    ThoughtRealizationResult(**base, outcome=admission.state,
                                                             receipt=admission))
        self._counts['admitted'] += 1
        try:
            outcome, text, reason = self._dispatch(lease, prompt, brain_state, request, policy)
        except Exception as exc:
            outcome, text, reason = 'FAILED', '', 'dispatch:' + type(exc).__name__
        binding = (attempt_id, snapshot.thought_id, snapshot.snapshot_sha256, request.sha256())
        try:
            receipt = lease.finish_thought_realization(*binding, outcome, text=text,
                                                       reason_code=_clean(reason) if reason else '')
        except Exception as exc:
            # The attempt stays ADMITTED for explicit recovery; never resubmit.
            raise self._unavailable('thought terminal bookkeeping unavailable',
                                    ThoughtRealizationResult(**base, outcome='UNKNOWN',
                                                             reason_code='terminal_write_failed')) from exc
        self._counts[outcome.lower()] += 1
        result = ThoughtRealizationResult(**base, outcome=receipt.state, reason_code=receipt.reason_code,
                                          text=receipt.text if receipt.state == 'COMPLETED' else '',
                                          receipt=receipt)
        if outcome in ('FAILED', 'UNKNOWN'):
            raise self._unavailable('thought realization ' + outcome.lower(), result)
        return result

    def _wait_done(self, handle, timeout):
        deadline = self._monotonic() + max(0.0, timeout)
        while True:
            try:
                if handle.done():
                    return True
            except Exception:
                return False
            if self._monotonic() >= deadline:
                return False
            time.sleep(.01)

    def _dispatch(self, lease, prompt, brain_state, request, policy):
        """One scheduler submission; returns (outcome, text, reason) after cleanup."""
        from .inference_scheduler import (make_request, responder_provider, COMPLETED, FAILED,
                                          PREEMPTED, CANCELLED, EXPIRED, STOPPED, TIMEOUT,
                                          REJECTED, FALLBACK, CONSUMER_GONE, SUPERSEDED, ANSWERED)
        from ..inference_thought import PrivateThoughtPolicy
        remaining = request.deadline_wall - self._clock()
        if remaining <= .05:
            return 'CANCELLED', '', 'deadline'
        if self._quiet.is_set() or lease.current() is not True:
            return 'CANCELLED', '', 'owner_unavailable'
        kwargs = dict(replay_history=False, persist_history=False, force_cli=False, force_api=False,
                      bypass_consciousness=True, prefer_local=True, supervised=False,
                      channel=CHANNEL,
                      private_thought_policy=PrivateThoughtPolicy(policy.max_output_tokens,
                                                                  policy.max_output_bytes))
        responder = self._responder
        req = make_request('background', prompt, dict(brain_state) if brain_state else {},
                           responder_kwargs=kwargs, channel='daemon', site=SITE, group=GROUP,
                           deadline_s=remaining, allow_tools=False, persist_history=False,
                           can_preempt=False, admission='background',
                           admission_timeout_s=min(2.0, remaining),
                           provider=responder_provider(lambda: responder))
        handle = self._scheduler.submit(req)
        self._handle = handle
        text, failure = '', None
        try:
            if self._quiet.is_set():
                handle.cancel('stopping')
            # A job still queued behind foreground work past its own deadline
            # ends as TIMEOUT here; the scheduler's deadline watch covers the
            # running phase. The inner-voice thread never waits unbounded.
            status, _, _ = handle.wait_admission(ceiling=remaining + .5)
            if status == 'go':
                for ev in handle.iter_events():
                    kind = getattr(ev, 'type', None)
                    if kind in _INVALID_EVENTS:
                        failure = failure or 'invalid_event'
                        handle.cancel('invalid_thought_output')
                    elif kind == 'done':
                        value = getattr(ev, 'full_text', '')
                        text = value.strip() if isinstance(value, str) else ''
        except Exception as exc:
            failure = failure or type(exc).__name__
        finally:
            self._handle = None
            try:
                handle.close()
            except Exception:
                pass
            drained = self._wait_done(handle, min(remaining, 15.0) + 1.0)
        outcome = handle.outcome
        if not drained or outcome is None:
            return 'UNKNOWN', '', 'provider_drain_unconfirmed'
        if outcome == FAILED or failure is not None:
            return 'FAILED', '', failure or 'provider_error'
        if outcome == COMPLETED:
            if not text:
                return 'FAILED', '', 'empty_output'
            if len(text.encode('utf-8')) > policy.max_output_bytes:
                return 'FAILED', '', 'output_bounds'
            return 'COMPLETED', text, ''
        if outcome in (PREEMPTED, CANCELLED, EXPIRED, STOPPED, TIMEOUT, REJECTED, FALLBACK,
                       CONSUMER_GONE, SUPERSEDED, ANSWERED):
            return 'CANCELLED', '', str(outcome)
        return 'UNKNOWN', '', 'outcome:' + _clean(outcome, 64)
