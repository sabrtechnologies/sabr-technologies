"""Durable grants for exact project actions; no authentication or action owner.

The integrator supplies trusted task context resolved outside model/transport
payloads. This module never guesses a principal, executes a handler or starts a
thread. A successful check permits the existing TaskWorker dispatch boundary;
it is not permission to replay an already attempted action.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sqlite3
import stat
import threading
import time
from typing import Callable, Mapping


class PolicyError(RuntimeError):
    """Sanitized policy/configuration failure."""


class PolicyConflict(PolicyError):
    pass


class PolicyCapacity(PolicyError):
    pass


@dataclass(frozen=True)
class TrustedTaskContext:
    """Server-established identity, not an object accepted from a request body.

    submission_id is TaskStore's namespaced task idempotency key. Revision is
    the immutable approval/scope revision, NOT TaskStore's mutable revision.
    resolve_context must load this from the integrator's trusted task registry.
    """
    principal: str
    task_id: str
    submission_id: str
    authorization_revision: int
    project_scope: str


@dataclass(frozen=True)
class GrantLimits:
    max_dispatches: int = 1
    max_argument_bytes: int = 16384
    maximum_tier: int = 3


_FLOORS = {"project.read_text": 1, "project.replace_text": 2, "project.run_check": 3}
_ARGUMENTS = {"project.read_text": {"path"},
              "project.replace_text": {"path", "expected_sha256", "text"},
              "project.run_check": {"check"}}
_HEX = re.compile(r"[0-9a-f]{64}\Z")


def _text(value, limit=200):
    if (not isinstance(value, str) or not value.strip() or len(value) > limit
            or any(ord(c) < 32 for c in value)):
        raise PolicyError("invalid bounded identifier")
    return value


def _integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise PolicyError("invalid bounded integer")
    return value


def _number(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise PolicyError("invalid finite time")
    return float(value)


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _context(context):
    if type(context) is not TrustedTaskContext:
        raise PolicyError("trusted task context required")
    return {"principal": _text(context.principal), "task_id": _text(context.task_id),
            "submission_id": _text(context.submission_id),
            "authorization_revision": _integer(context.authorization_revision, 0, 2**63-1),
            "project_scope": _text(context.project_scope, 1000)}


def _spec(spec):
    """Snapshot ProjectActions.CanonicalResourceSpec without importing its owner."""
    name = spec.name
    if name not in _FLOORS:
        raise PolicyError("unregistered project action")
    arguments = spec.arguments
    if (not isinstance(arguments, tuple) or len(arguments) != len(_ARGUMENTS[name])
            or any(not isinstance(row, tuple) or len(row) != 2
                   or any(not isinstance(v, str) for v in row) for row in arguments)
            or tuple(sorted(arguments)) != arguments):
        raise PolicyError("finalized canonical arguments required")
    args = dict(arguments)
    if len(args) != len(arguments) or set(args) != _ARGUMENTS[name]:
        raise PolicyError("exact project action arguments required")
    if "path" in args:
        path = _text(args["path"], 4096)
        if (any(c in path for c in ("\\", ":")) or any(part in ("", ".", "..", ".git", ".hg", ".svn")
                for part in path.split("/"))):
            raise PolicyError("canonical relative project path required")
    if name == "project.replace_text":
        if not _HEX.fullmatch(args["expected_sha256"]) or len(args["text"].encode("utf-8")) > 8192:
            raise PolicyError("bounded expected-hash replacement required")
    if name == "project.run_check":
        _text(args["check"])
    resources = spec.resources
    if (not isinstance(resources, tuple) or not 1 <= len(resources) <= 16
            or tuple(sorted(set(resources))) != resources):
        raise PolicyError("exact canonical resource tuple required")
    resources = [_text(r, 500) for r in resources]
    minimum_tier = _integer(spec.minimum_tier, 1, 3)
    if minimum_tier != _FLOORS[name]:
        raise PolicyError("project action risk floor differs")
    root = spec.root_identity
    if not isinstance(root, tuple) or len(root) != 2:
        raise PolicyError("canonical workspace identity required")
    root = [_integer(root[0], 0, 2**64-1), _integer(root[1], 1, 2**64-1)]
    for value in (spec.input_sha256, spec.configuration_sha256):
        if not isinstance(value, str) or not _HEX.fullmatch(value):
            raise PolicyError("canonical digest required")
    if spec.input_sha256 != _digest(args):
        raise PolicyError("canonical input digest differs")
    return {"name": name, "arguments": args, "resources": resources,
            "minimum_tier": minimum_tier, "scope": _text(spec.scope, 1000),
            "root_identity": root, "input_sha256": spec.input_sha256,
            "configuration_sha256": spec.configuration_sha256}


_SCHEMA = """
CREATE TABLE IF NOT EXISTS policy_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS task_grants (
 grant_ref TEXT PRIMARY KEY, principal TEXT NOT NULL, task_id TEXT NOT NULL,
 submission_id TEXT NOT NULL, action_key TEXT NOT NULL, fingerprint TEXT NOT NULL,
 payload TEXT NOT NULL, issued_wall REAL NOT NULL, expires_wall REAL NOT NULL,
 revoked_wall REAL, revocation_ref TEXT,
 UNIQUE(task_id,action_key));
CREATE TABLE IF NOT EXISTS grant_claims (
 grant_ref TEXT PRIMARY KEY REFERENCES task_grants(grant_ref),
 action_id TEXT UNIQUE NOT NULL, binding_sha256 TEXT NOT NULL,
 first_checked_wall REAL NOT NULL, last_checked_wall REAL NOT NULL,
 dispatch_seen INTEGER NOT NULL DEFAULT 0);
"""


class TaskPolicy:
    """Explicit operational SQLite path and a mandatory trusted resolver.

    create_grant is a trusted approval-service API, never an HTTP/model method.
    Supply authorize as ProjectActions' authority callback. It consumes at most
    one unique action atomically, and every recheck still honors scope, deadline,
    revocation and expiry. TaskStore owns action attempts and result receipts.
    """
    def __init__(self, path, *, resolve_context: Callable[[str], TrustedTaskContext | None],
                 max_grants=2048, max_payload_bytes=32768,
                 max_validity_s=86400, clock=time.time):
        if not callable(resolve_context) or not callable(clock):
            raise PolicyError("trusted resolver and clock required")
        _integer(max_grants, 1, 100000)
        _integer(max_payload_bytes, 1024, 131072)
        validity = _number(max_validity_s)
        if not 0 < validity <= 604800:
            raise PolicyError("bounded grant lifetime required")
        raw = os.fspath(path)
        if not Path(raw).is_absolute():
            raise PolicyError("explicit absolute operational path required")
        self.path = os.path.abspath(raw)
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        except FileExistsError:
            info = os.lstat(self.path)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                raise PolicyError("regular unaliased operational database required")
        else:
            os.close(fd)
        self._lock, self._closed = threading.RLock(), False
        self._resolver, self._clock = resolve_context, clock
        self._max_grants, self._max_payload = max_grants, max_payload_bytes
        self._max_validity = validity
        self._conn = sqlite3.connect(self.path, timeout=0.2, check_same_thread=False,
                                     isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=FULL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.executescript(_SCHEMA)
            config = _json([1, max_grants, max_payload_bytes, validity])
            with self._tx() as db:
                old = db.execute("SELECT value FROM policy_meta WHERE key='config'").fetchone()
                if old and old[0] != config:
                    raise PolicyConflict("policy store configuration differs")
                db.execute("INSERT OR IGNORE INTO policy_meta VALUES ('config',?)", (config,))
        except BaseException:
            self._conn.close()
            raise

    @contextmanager
    def _tx(self):
        with self._lock:
            if self._closed:
                raise PolicyError("policy store closed")
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield self._conn
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def close(self):
        with self._lock:
            if not self._closed:
                self._conn.close()
                self._closed = True

    def create_grant(self, *, grant_ref, context, action_key, spec, tier,
                     approval_ref, expires_wall, limits=GrantLimits()):
        """Persist the exact finalized approval; same reference/input is idempotent.

        A caller must already have verified explicit approval for this finalized
        spec. There is no approval inferred from text, UUIDs or legacy booleans.
        Changed input/reference reuse conflicts; expiry never frees capacity.
        """
        grant_ref, action_key = _text(grant_ref), _text(action_key)
        trusted, canonical = _context(context), _spec(spec)
        # Issuance also checks the caller's server-established task registration.
        if _context(self._resolver(trusted["task_id"])) != trusted:
            raise PolicyError("trusted task registration differs")
        if trusted["project_scope"] != canonical["scope"]:
            raise PolicyError("approved workspace differs")
        tier = _integer(tier, canonical["minimum_tier"], 3)
        if type(limits) is not GrantLimits:
            raise PolicyError("explicit grant limits required")
        maximum = _integer(limits.maximum_tier, tier, 3)
        if type(limits.max_dispatches) is not int or limits.max_dispatches != 1:
            raise PolicyError("one unique dispatch per grant required")
        size = _integer(limits.max_argument_bytes, 1, 16384)
        if len(_json(canonical["arguments"]).encode("utf-8")) > size:
            raise PolicyError("approved argument byte limit exceeded")
        expiry = _number(expires_wall)
        payload = {"context": trusted, "action_key": action_key, "spec": canonical,
                   "tier": tier, "approval_ref": _text(approval_ref), "expires_wall": expiry,
                   "limits": {"max_dispatches": 1, "max_argument_bytes": size, "maximum_tier": maximum}}
        encoded, fingerprint = _json(payload), _digest(payload)
        if len(encoded.encode("utf-8")) > self._max_payload:
            raise PolicyError("grant payload limit exceeded")
        with self._tx() as db:
            old = db.execute("SELECT * FROM task_grants WHERE grant_ref=?", (grant_ref,)).fetchone()
            if old:
                if old["fingerprint"] != fingerprint:
                    raise PolicyConflict("grant reference has different finalized approval")
                return grant_ref
            now = _number(self._clock())
            if not now < expiry <= now + self._max_validity:
                raise PolicyError("grant expiry outside approved lifetime")
            if db.execute("SELECT count(*) FROM task_grants").fetchone()[0] >= self._max_grants:
                raise PolicyCapacity("retained grant quota exhausted")
            if db.execute("SELECT 1 FROM task_grants WHERE task_id=? AND action_key=?",
                          (trusted["task_id"], action_key)).fetchone():
                raise PolicyConflict("task step already has an immutable grant")
            db.execute("INSERT INTO task_grants(grant_ref,principal,task_id,submission_id,action_key,fingerprint,payload,issued_wall,expires_wall) VALUES (?,?,?,?,?,?,?,?,?)",
                (grant_ref, trusted["principal"], trusted["task_id"], trusted["submission_id"],
                 action_key, fingerprint, encoded, now, expiry))
        return grant_ref

    def authorize(self, action: Mapping, task: Mapping, spec) -> bool:
        """ProjectActions authority callback: exact literal True or fail closed.

        Call again immediately before effects. Revocation/expiry after a check
        cannot undo an already dispatched effect. This is an authorization
        transaction, not an exactly-once external action guarantee.
        """
        try:
            return self._authorize(action, task, spec) is True
        except Exception:
            return False

    def _authorize(self, action, task, spec):
        if not isinstance(action, Mapping) or not isinstance(task, Mapping):
            return False
        task_id, action_id = _text(task.get("task_id")), _text(action.get("action_id"))
        trusted = _context(self._resolver(task_id))
        canonical = _spec(spec)
        if (trusted["task_id"] != task_id or action.get("task_id") != task_id
                or task.get("idem_key") != trusted["submission_id"]
                or task.get("project_scope") != trusted["project_scope"]
                or canonical["scope"] != trusted["project_scope"]
                or task.get("state") != "RUNNING" or action.get("state") != "RUNNING"
                or task.get("cancel_requested") is not False
                or type(action.get("dispatched")) is not bool):
            return False
        tier = _integer(action.get("tier"), canonical["minimum_tier"], 3)
        if (action.get("name") != canonical["name"]
                or type(action.get("arguments")) is not dict or action["arguments"] != canonical["arguments"]
                or type(action.get("resources")) is not list or action["resources"] != canonical["resources"]):
            return False
        # Match TaskStore's persisted fingerprint exactly (args is itself JSON).
        expected = hashlib.sha256(json.dumps([canonical["name"], _json(canonical["arguments"]),
            canonical["resources"], tier]).encode("utf-8")).hexdigest()
        if action.get("fingerprint") != expected:
            return False
        action_key, reference = _text(action.get("idem_key")), _text(task.get("authorization_ref"))
        binding = _digest({"action_id": action_id, "task_id": task_id,
                           "action_key": action_key, "spec": canonical, "tier": tier,
                           "context": trusted})
        with self._tx() as db:
            row = db.execute("SELECT * FROM task_grants WHERE grant_ref=?", (reference,)).fetchone()
            if row is None or row["revoked_wall"] is not None:
                return False
            payload = json.loads(row["payload"])
            if (row["fingerprint"] != _digest(payload) or payload["context"] != trusted
                    or payload["action_key"] != action_key or payload["spec"] != canonical
                    or payload["tier"] != tier):
                return False
            now = _number(self._clock())
            deadline = task.get("deadline_wall")
            if (now < row["issued_wall"] or now >= row["expires_wall"]
                    or (deadline is not None and now >= _number(deadline))
                    or payload["limits"]["max_dispatches"] != 1
                    or len(_json(canonical["arguments"]).encode("utf-8")) > payload["limits"]["max_argument_bytes"]
                    or tier > payload["limits"]["maximum_tier"]):
                return False
            previous = db.execute("SELECT * FROM grant_claims WHERE grant_ref=?", (reference,)).fetchone()
            phase = int(action["dispatched"])
            if previous:
                if (previous["action_id"] != action_id or previous["binding_sha256"] != binding
                        or phase < previous["dispatch_seen"] or now < previous["last_checked_wall"]):
                    return False
                db.execute("UPDATE grant_claims SET last_checked_wall=?,dispatch_seen=? WHERE grant_ref=?",
                           (now, phase, reference))
            else:
                if phase:
                    # A direct handler call cannot skip the pre-dispatch policy
                    # reservation. Recovery of an abandoned action belongs to
                    # TaskStore, not to a fresh authorization attempt here.
                    return False
                # Another grant cannot authorize this same action under a new scope.
                if db.execute("SELECT 1 FROM grant_claims WHERE action_id=?", (action_id,)).fetchone():
                    return False
                db.execute("INSERT INTO grant_claims VALUES (?,?,?,?,?,?)",
                           (reference, action_id, binding, now, now, phase))
        return True

    def revoke(self, grant_ref, *, principal, revocation_ref):
        """Trusted caller identity required; revocation is durable and irreversible."""
        reference, who, reason = _text(grant_ref), _text(principal), _text(revocation_ref)
        with self._tx() as db:
            row = db.execute("SELECT principal,revoked_wall FROM task_grants WHERE grant_ref=?", (reference,)).fetchone()
            if row is None or row["principal"] != who:
                return False
            if row["revoked_wall"] is None:
                db.execute("UPDATE task_grants SET revoked_wall=?,revocation_ref=? WHERE grant_ref=?",
                           (_number(self._clock()), reason, reference))
            return True

    def receipt(self, grant_ref, *, principal):
        """Authorized metadata only; no arguments, text, credentials or approval text."""
        reference, who = _text(grant_ref), _text(principal)
        with self._lock:
            if self._closed:
                raise PolicyError("policy store closed")
            row = self._conn.execute("SELECT g.*,c.action_id,c.first_checked_wall,c.last_checked_wall,c.dispatch_seen FROM task_grants g LEFT JOIN grant_claims c USING(grant_ref) WHERE grant_ref=? AND principal=?",
                                     (reference, who)).fetchone()
            if row is None:
                return None
            data = json.loads(row["payload"])
            return {"grant_ref": reference, "task_id": row["task_id"],
                    "submission_id": row["submission_id"], "action_key": row["action_key"],
                    "action_id": row["action_id"], "action_name": data["spec"]["name"],
                    "scope": data["spec"]["scope"], "tier": data["tier"],
                    "resources": list(data["spec"]["resources"]),
                    "input_sha256": data["spec"]["input_sha256"],
                    "configuration_sha256": data["spec"]["configuration_sha256"],
                    "authorization_revision": data["context"]["authorization_revision"],
                    "issued_wall": row["issued_wall"], "expires_wall": row["expires_wall"],
                    "revoked": row["revoked_wall"] is not None,
                    "consumed": row["action_id"] is not None,
                    "dispatch_seen": bool(row["dispatch_seen"]),
                    "first_checked_wall": row["first_checked_wall"],
                    "last_checked_wall": row["last_checked_wall"]}
