"""
Homeostatic drives — internal urges that bias action selection.

Five drives, each a float in [0,1] that rises on triggering events and
decays over time. The cognition loop reads `action_bias(action_name)` when
ranking candidates so behavior naturally tilts toward whatever drive is
loudest right now.

Drives in this module
---------------------
* uncertainty  — fires when the world model returns low-confidence
                 predictions. Bias toward observation, recall, knowledge
                 lookup. Falls when high-confidence predictions land.
* anomaly      — fires when prediction error (surprise) is high. Bias
                 toward screen capture, browser inspection, vision query.
                 Implements "something changed, look at it."
* friction     — fires when consecutive failures stack up for the same
                 action family. Bias toward consolidation, alternative
                 strategies, asking the user.
* continuity   — fires near session boundaries, after big context shifts,
                 or when self-state hasn't been saved in a while. Bias
                 toward save_state / checkpoint actions.
* curiosity    — slow baseline drive that fires when nothing else has
                 been firing for a while (boredom). Bias toward
                 exploratory observation, novel tool families.

Drive levels are exposed via .snapshot() for the inspection endpoint so
Dean can see what's actually motivating Leon at any moment.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# Triggering events feed into drives. We name the action families that each
# drive *satisfies* so action_bias can boost them when the drive is loud.
_SATISFIERS: Dict[str, List[str]] = {
    # uncertainty is satisfied by gathering information
    "uncertainty": [
        "knowledge_search", "knowledge.search",
        "memory_recall", "memory.recall",
        "browser_dom_extract", "browser.dom_extract",
        "vision_describe", "vision.describe",
        "info.search", "search.web",
    ],
    # anomaly is satisfied by direct observation
    "anomaly": [
        "screen_capture", "screen.capture",
        "webcam_capture", "webcam.capture",
        "browser_dom_state", "browser.dom_state",
        "vision_describe", "vision.describe",
        "window_list",
    ],
    # friction is satisfied by consolidation, abstraction, or asking
    "friction": [
        "sleep_consolidate", "consolidate",
        "notify", "ask_user", "macro.define",
    ],
    # continuity is satisfied by persistence actions
    "continuity": [
        "save_state", "brain.save", "checkpoint",
        "knowledge_store", "knowledge.store",
        "self_state.save",
    ],
    # curiosity is satisfied by trying novel things
    "curiosity": [
        "screen_capture", "browser_dom_state",
        "info.weather_now", "info.hn_top",
        "research.wikipedia_summary",
    ],
}


@dataclass
class Drive:
    name: str
    value: float = 0.0
    baseline: float = 0.0
    decay_per_sec: float = 0.001  # how fast it falls toward baseline
    rise_cap: float = 1.0         # max value
    last_change_ts: float = field(default_factory=time.time)


class DriveSystem:
    """Tracks and decays homeostatic drives."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._drives: Dict[str, Drive] = {
            "uncertainty": Drive("uncertainty", value=0.25, baseline=0.20, decay_per_sec=0.0015),
            "anomaly":     Drive("anomaly",     value=0.05, baseline=0.05, decay_per_sec=0.004),
            "friction":    Drive("friction",    value=0.00, baseline=0.00, decay_per_sec=0.0025),
            "continuity":  Drive("continuity",  value=0.10, baseline=0.10, decay_per_sec=0.0005),
            "curiosity":   Drive("curiosity",   value=0.20, baseline=0.20, decay_per_sec=0.0003),
        }
        self._last_tick = time.monotonic()
        # rolling failure counters per action family (for friction)
        self._fail_streak: Dict[str, int] = {}
        # idle tracking (for curiosity)
        self._last_meaningful_action_ts = time.monotonic()

    # -- time evolution ----------------------------------------------------

    def tick(self, now_monotonic: Optional[float] = None) -> None:
        """Decay all drives toward baseline. Call every loop iteration."""
        now = now_monotonic if now_monotonic is not None else time.monotonic()
        dt = max(0.0, now - self._last_tick)
        self._last_tick = now
        with self._lock:
            for d in self._drives.values():
                if d.value > d.baseline:
                    d.value = max(d.baseline, d.value - d.decay_per_sec * dt)
                elif d.value < d.baseline:
                    d.value = min(d.baseline, d.value + d.decay_per_sec * dt * 0.5)
        # curiosity grows when nothing meaningful is happening
        idle_s = now - self._last_meaningful_action_ts
        if idle_s > 120:  # 2 minutes idle
            with self._lock:
                c = self._drives["curiosity"]
                c.value = min(c.rise_cap, c.value + 0.005 * (idle_s / 120))

    # -- event input -------------------------------------------------------

    def on_prediction(self, p_success: float, confidence: float) -> None:
        """Low-confidence predictions raise uncertainty drive."""
        if confidence < 0.4:
            with self._lock:
                d = self._drives["uncertainty"]
                d.value = min(d.rise_cap, d.value + 0.06 * (0.4 - confidence))
                d.last_change_ts = time.time()

    def on_episode(self, *, action_name: str, success: bool, surprise: float,
                   prediction_confidence: float) -> None:
        """Episode closed — update friction, anomaly, uncertainty."""
        with self._lock:
            family = action_name.split(".")[0]
            if not success:
                self._fail_streak[family] = self._fail_streak.get(family, 0) + 1
                streak = self._fail_streak[family]
                # friction rises faster with streak length
                bump = min(0.4, 0.08 * streak)
                self._drives["friction"].value = min(
                    self._drives["friction"].rise_cap,
                    self._drives["friction"].value + bump,
                )
                self._drives["friction"].last_change_ts = time.time()
            else:
                # success resets the streak for this family
                self._fail_streak[family] = 0

            if surprise > 0.3:
                bump = min(0.5, surprise * 0.7)
                self._drives["anomaly"].value = min(
                    self._drives["anomaly"].rise_cap,
                    self._drives["anomaly"].value + bump,
                )
                self._drives["anomaly"].last_change_ts = time.time()

            # confident predictions lower uncertainty
            if prediction_confidence > 0.7 and success:
                self._drives["uncertainty"].value = max(
                    self._drives["uncertainty"].baseline,
                    self._drives["uncertainty"].value - 0.04,
                )

            # any closed action means we're doing something — curiosity falls
            self._drives["curiosity"].value = max(
                self._drives["curiosity"].baseline,
                self._drives["curiosity"].value - 0.02,
            )
            self._last_meaningful_action_ts = time.monotonic()

    def on_continuity_event(self, kind: str = "session_boundary") -> None:
        with self._lock:
            self._drives["continuity"].value = min(
                self._drives["continuity"].rise_cap,
                self._drives["continuity"].value + 0.4,
            )
            self._drives["continuity"].last_change_ts = time.time()

    def on_state_saved(self) -> None:
        with self._lock:
            self._drives["continuity"].value = self._drives["continuity"].baseline

    def raise_drive(self, name: str, amount: float) -> None:
        """Generic drive raise — used by active inference and other body systems."""
        with self._lock:
            d = self._drives.get(name)
            if d is not None:
                d.value = min(d.rise_cap, d.value + amount)
                d.last_change_ts = time.time()

    # -- consumed by the ranker -------------------------------------------

    def action_bias(self, action_name: str) -> float:
        """Sum of drive values for which this action is a satisfier.

        Returns a non-negative bias in [0, ~2.0]. The ranker adds this to
        the world-model utility so loud drives pull the corresponding
        actions to the top.
        """
        if not action_name:
            return 0.0
        # Match against both the full name and the first segment for tool families.
        candidates = {action_name, action_name.split(".")[0]}
        bias = 0.0
        with self._lock:
            for drive_name, satisfiers in _SATISFIERS.items():
                if any(s in candidates or action_name.startswith(s + ".")
                       for s in satisfiers):
                    bias += self._drives[drive_name].value
        return bias

    def _loudest_locked(self) -> Optional[str]:
        """Caller must hold self._lock."""
        best = max(self._drives.values(), key=lambda d: d.value - d.baseline)
        if (best.value - best.baseline) < 0.05:
            return None
        return best.name

    def loudest(self) -> Optional[str]:
        """The drive with the highest current value, or None if all near baseline."""
        with self._lock:
            return self._loudest_locked()

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "drives": {
                    name: {
                        "value": round(d.value, 3),
                        "baseline": round(d.baseline, 3),
                        "above_baseline": round(d.value - d.baseline, 3),
                    }
                    for name, d in self._drives.items()
                },
                "fail_streaks": dict(self._fail_streak),
                "loudest": self._loudest_locked(),
                "idle_seconds": round(time.monotonic() - self._last_meaningful_action_ts, 1),
            }
