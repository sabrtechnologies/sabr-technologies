"""Cold, injected prospective observation around the actual dispatch wrappers.

Never builds context, predicts, reads a database, dispatches a tool, or invents
request/action identities. An exact root-supplied scope and existing cache entry
are required. Legacy canonical episode writes remain owned by bootstrap/loop.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
import math
import threading
import time


@dataclass(frozen=True)
class DispatchScope:
    request_id: str
    action_id: str
    prediction_id: str
    trace_id: str
    clock_id: str
    tool_name: str
    context_bucket: str
    deadline_mono: float
    latency_scale_ms: float
    max_cache_age_s: float
    cancel_token: object = field(default=None, repr=False)
    evidence: str = "unverified"
    evidence_ref: str | None = None

    def __post_init__(self):
        for name in ("request_id", "action_id", "prediction_id", "trace_id", "clock_id", "tool_name", "context_bucket"):
            value = getattr(self, name)
            if type(value) is not str or not value or len(value) > (512 if name == "context_bucket" else 128):
                raise ValueError("explicit bounded dispatch identity and known context required")
        for name in ("deadline_mono", "latency_scale_ms", "max_cache_age_s"):
            value = getattr(self, name)
            if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
                raise ValueError("explicit finite dispatch metric/time contract required")
        if self.evidence not in {"unverified", "simulated", "measured"}:
            raise ValueError("unknown evidence provenance")
        if self.evidence_ref is not None and (type(self.evidence_ref) is not str or not self.evidence_ref
                                             or len(self.evidence_ref) > 128):
            raise ValueError("invalid evidence reference")


@dataclass(eq=False)
class _Frame:
    owner: object
    scope: object = None
    ticket: object = None
    parent_ticket: object = None
    context_token: object = None
    marked: bool = False
    released: bool = False
    terminal_attempted: bool = False
    thread: int = 0


class PredictionDispatch:
    def __init__(self, *, world_model, clock_id, capture, mark_dispatched, terminal,
                 ready=lambda: False, enabled=False, clock=time.monotonic):
        if type(clock_id) is not str or not clock_id or len(clock_id) > 128:
            raise ValueError("explicit process clock domain required")
        self._world_model, self.clock_id = world_model, clock_id
        self._capture, self._mark, self._terminal = capture, mark_dispatched, terminal
        self._ready, self._enabled, self._clock = ready, enabled is True, clock
        self._scope = ContextVar("leon_prediction_dispatch_scope", default=None)
        self._frame = ContextVar("leon_prediction_dispatch_frame", default=None)
        self._lock = threading.Lock()
        self._active = set()
        self._stopping = False
        self._counts = {"captured": 0, "skipped": 0, "nested": 0, "failed": 0}

    @contextmanager
    def scope(self, scope):
        """Root enters on the actual dispatcher thread, once per authorized action."""
        if type(scope) is not DispatchScope or scope.clock_id != self.clock_id:
            raise ValueError("dispatch scope belongs to another clock domain")
        token = self._scope.set({"scope": scope, "claimed": False,
                                 "thread": threading.get_ident()})
        try:
            yield
        finally:
            self._scope.reset(token)

    def begin(self, tool_name, args):
        """No-I/O prelude. Callback contracts must themselves be bounded/no-I/O."""
        if not self._enabled:
            return None
        outer = self._frame.get()
        if outer is not None:
            if outer.released or outer.thread != threading.get_ident():
                self._counts["skipped"] += 1
                return None
            self._counts["nested"] += 1
            return _Frame(self, parent_ticket=outer.ticket or outer.parent_ticket)
        if self._stopping:
            return None
        lease = self._scope.get()
        if (lease is None or lease["claimed"] or lease["thread"] != threading.get_ident()
                or lease["scope"].tool_name != tool_name or not self._lock.acquire(False)):
            self._counts["skipped"] += 1
            return None
        try:
            if self._stopping or len(self._active) >= 32:
                return None
            lease["claimed"] = True
            frame = _Frame(self, scope=lease["scope"], thread=threading.get_ident())
            self._active.add(frame)
        finally:
            self._lock.release()
        frame.context_token = self._frame.set(frame)
        try:
            scope = frame.scope
            now = self._clock()
            if not self._ready() or now >= scope.deadline_mono or self._cancelled(scope):
                self._counts["skipped"] += 1
                return frame
            cached = self._world_model.peek_cached(tool_name, args,
                context_bucket=scope.context_bucket, max_age_s=scope.max_cache_age_s, now_mono=now)
            if cached is None:
                self._counts["skipped"] += 1
                return frame
            # The cached forecast creation timestamp is preserved. This can
            # correctly fail the observer's horizon bound rather than pretend
            # an old forecast was freshly computed at dispatch.
            frame.ticket = self._capture(cached, latency_scale_ms=scope.latency_scale_ms,
                prediction_id=scope.prediction_id, request_id=scope.request_id,
                action_id=scope.action_id, trace_id=scope.trace_id, clock_id=scope.clock_id,
                predicted_mono=cached.cached_mono, deadline_mono=scope.deadline_mono,
                evidence=scope.evidence)
            self._counts["captured" if frame.ticket is not None else "skipped"] += 1
        except Exception:
            self._counts["failed"] += 1
        except BaseException:
            self.release(frame)
            raise
        return frame

    @staticmethod
    def _cancelled(scope):
        return scope.cancel_token is not None and scope.cancel_token.is_set()

    def started(self, frame, started_mono):
        if frame.ticket is None or frame.released or self._stopping:
            return
        try:
            if not self._cancelled(frame.scope):
                frame.marked = self._mark(frame.ticket, action_started_mono=started_mono) is True
        except Exception:
            self._counts["failed"] += 1

    def record_fields(self, frame, *, observed_mono, exception=None):
        if frame.parent_ticket is not None:
            return {"prediction_parent_ticket": frame.parent_ticket}
        if frame.ticket is None:
            return {}
        scope = frame.scope
        try:
            cancelled = self._cancelled(scope)
            missing = (not frame.marked or self._stopping
                       or (exception is not None and not isinstance(exception, Exception)))
            if cancelled or missing:
                self._terminal_once(frame, "cancelled" if cancelled else "missing", observed_mono)
                return {"prediction_parent_ticket": frame.ticket}
            return {"prediction_ticket": frame.ticket, "prediction_observed_mono": observed_mono,
                    "prediction_evidence": scope.evidence, "prediction_evidence_ref": scope.evidence_ref}
        except Exception:
            self._counts["failed"] += 1
            return {"prediction_parent_ticket": frame.ticket}

    def release(self, frame):
        if frame.released:
            return
        frame.released = True
        if frame.context_token is not None:
            try:
                self._frame.reset(frame.context_token)
            finally:
                with self._lock:
                    self._active.discard(frame)

    def record_failed(self, frame, *, observed_mono):
        self._terminal_once(frame, "missing", observed_mono)

    def _terminal_once(self, frame, status, observed_mono):
        if frame.ticket is not None and not frame.terminal_attempted:
            frame.terminal_attempted = True
            try:
                self._terminal(frame.ticket, status=status, observed={},
                    observed_mono=observed_mono, evidence="unverified", evidence_ref=None)
            except Exception:
                self._counts["failed"] += 1

    def quiesce(self):
        self._stopping = True

    def stop(self):
        self.quiesce()
        with self._lock:
            return not self._active

    @property
    def retired(self):
        return self._stopping and not self._active

    def stats(self):
        return {"enabled": self._enabled, "stopping": self._stopping, "retired": self.retired,
                "active": len(self._active), "metadata_only": True, **self._counts}
