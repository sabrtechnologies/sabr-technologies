"""Structured thought before words. Pure snapshots; no inference or brain step."""
from __future__ import annotations

from dataclasses import dataclass, field
import json
import math
from types import MappingProxyType
from typing import Mapping
import uuid


def _freeze(value):
    if isinstance(value, dict):
        return MappingProxyType({k:_freeze(v) for k,v in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(v) for v in value)
    return value


def _plain(value):
    if isinstance(value, Mapping):
        return {k:_plain(v) for k,v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    return value


@dataclass(frozen=True)
class ThoughtIntent:
    thought_id: str
    trigger: str
    dominant_region: str
    goal_refs: tuple[str, ...] = ()
    memory_refs: tuple[str, ...] = ()
    body_state: Mapping = field(default_factory=dict)
    neuromodulators: Mapping = field(default_factory=dict)
    urgency: float = 0.0
    privacy: str = "private"
    created_wall: float = 0.0

    def __post_init__(self):
        for name in ("thought_id","trigger","dominant_region"):
            value = getattr(self,name)
            if not isinstance(value,str) or not value.strip() or len(value)>200:
                raise ValueError(name)
        for name in ("goal_refs","memory_refs"):
            value = getattr(self,name)
            if not isinstance(value,(list,tuple)) or len(value)>64 or any(not isinstance(x,str) or not x or len(x)>200 for x in value):
                raise ValueError(name)
            object.__setattr__(self,name,tuple(value))
        for name in ("body_state","neuromodulators"):
            value = getattr(self,name)
            if not isinstance(value,Mapping):
                raise ValueError(name)
            raw = json.dumps(_plain(value),allow_nan=False,separators=(",", ":"))
            if len(raw.encode("utf-8"))>8192:
                raise ValueError(name)
            object.__setattr__(self,name,_freeze(json.loads(raw)))
        for name in ("urgency","created_wall"):
            value = getattr(self,name)
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
                raise ValueError(name)
        if not 0 <= self.urgency <= 1 or self.created_wall < 0:
            raise ValueError("urgency or timestamp")
        if self.privacy not in ("private","user_visible"):
            raise ValueError("privacy")

    def to_dict(self):
        return {name:_plain(getattr(self,name)) for name in self.__dataclass_fields__}

    @classmethod
    def create(cls, *, trigger, dominant_region, created_wall, **state):
        return cls(thought_id=uuid.uuid4().hex, trigger=trigger,
                   dominant_region=dominant_region, created_wall=created_wall, **state)

    @classmethod
    def from_legacy(cls, intention, *, created_wall, goal_refs=(), memory_refs=(),
                    body_state=None, privacy="private"):
        """Adapt existing speech_intent.ThoughtIntention without calling to_prompt."""
        urgency = float(getattr(intention,"drive_strength",0.0))
        if not math.isfinite(urgency):
            raise ValueError("urgency")
        return cls.create(trigger=getattr(intention,"trigger","neural"),
                          dominant_region=getattr(intention,"workspace_region","") or "unknown",
                          goal_refs=goal_refs,memory_refs=memory_refs,
                          body_state=body_state or {},neuromodulators=getattr(intention,"mood",{}),
                          urgency=min(1.0,max(0.0,urgency)),
                          privacy=privacy,created_wall=created_wall)
