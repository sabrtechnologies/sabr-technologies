"""
Cognitive event bus — Leon V2 Phase 2 (shadow mode, additive only).

One bounded, priority-ordered, thread-safe mailbox between everything that
notices something (voice, perception, tools, goals, dreaming, resources) and
the one consumer, :class:`brain.cognition.runtime.CognitiveRuntime`. Importing
this module does nothing at all: no threads, no sockets, no files, no clock
reads, no singleton bus.

What this bus guarantees
------------------------

**A person is never made to wait behind the machinery.** Order is strictly by
priority (:data:`~brain.cognition.events.DEFAULT_PRIORITY`), and within one
priority it is FIFO: a fresh ``USER_MESSAGE`` jumps a thousand queued dream
fragments, but two dream fragments keep the order they arrived in.

**A full queue never silences the user.** The bound (:data:`MAX_PENDING`)
exists so a runaway producer cannot grow the queue until the box dies. Every
type belongs to an eviction class:

====  ===============================================  ==========================
class types                                            fate when the queue is full
====  ===============================================  ==========================
0     perception, background thought, sleep, learning, evicted first (lowest
      memory candidate, drive change, quantum          priority, then oldest)
1     tool result, goal, prediction error, reflex      evicted next
2     ``VOICE_PARTIAL`` (soft-protected)               evicted only when 0 and 1
                                                       are empty
3     ``USER_MESSAGE``, ``VOICE_FINAL``,               **never evicted**
      ``RESOURCE_EVENT`` (hard-protected)
====  ===============================================  ==========================

A hard-protected newcomer may evict from classes 0-2 at *any* priority. If the
queue is full of hard-protected events it is still accepted, into a fixed
headroom of :data:`PROTECTED_HEADROOM` slots above the bound; only past that is
it refused, counted as ``protected_dropped``. A class-0 newcomer may only evict
a class-0 event of no greater priority, so back-pressure lands on background
chatter, never on speech.

**Percept spam collapses instead of piling up.** A publisher that re-reports
the same fact sets ``payload["coalesce_key"]`` (a ``str`` or ``int``). A
pending event with the same ``(type, source, key)`` is replaced in place by
the newer one, keeping the older event's queue position. Coalescing never
evicts. Protected types (classes 2 and 3) are never coalesced: every word a
person says is its own event.

**Nothing in here can block or fail interestingly.** No model calls, no tool
calls, no I/O, no logging: one lock, heaps with lazy deletion, a ring buffer
and integer counters. Every operation is O(log n) amortized; stale heap
entries are compacted once they outnumber live ones by more than 1024.

Debugging surface: :meth:`EventBus.snapshot` returns the last
:data:`RING_CAPACITY` event *headers*: identity, type, source, priority,
timing, trace and up to :data:`MAX_HEADER_KEYS` payload key names, never the
payload's values (which may be large, private, or both).
:meth:`EventBus.stats` returns the counters.
"""
from __future__ import annotations

import heapq
import itertools
import queue
import time
from collections import deque
from typing import Any, Dict, List, Mapping, Optional, Tuple

from .events import CognitiveEvent, EventType

__all__ = [
    "EventBus",
    "MAX_PENDING",
    "RING_CAPACITY",
    "PROTECTED_HEADROOM",
    "PROTECTED_TYPES",
    "HARD_PROTECTED_TYPES",
    "SOFT_PROTECTED_TYPES",
    "DROPPABLE_TYPES",
    "WORK_TYPES",
    "COALESCE_KEY",
    "MAX_HEADER_KEYS",
    "header_of",
    "eviction_class",
]

#: Ceiling on pending (published but not yet delivered) events.
MAX_PENDING = 4096

#: Extra slots only hard-protected events may use once the bound is reached.
PROTECTED_HEADROOM = 256

#: How many recent event headers :meth:`EventBus.snapshot` keeps.
RING_CAPACITY = 1000

#: Payload key names kept per header.
MAX_HEADER_KEYS = 32

#: publish() never waits longer than this for the bus lock. A publisher may
#: be the main thread, which also runs the SIGUSR1 shutdown handler; a
#: blocking acquire there could deadlock. A timeout is counted, never silent.
PUBLISH_LOCK_TIMEOUT_S = 0.02

#: A person talking, or the machine telling us it is running out of
#: something. Never evicted, never coalesced.
HARD_PROTECTED_TYPES = frozenset({
    EventType.USER_MESSAGE,
    EventType.VOICE_FINAL,
    EventType.RESOURCE_EVENT,
})

#: Mid-sentence speech: kept ahead of all work, but a newer partial or a
#: finished utterance may displace it.
SOFT_PROTECTED_TYPES = frozenset({EventType.VOICE_PARTIAL})

#: Kept for callers and tests that ask "is this protected at all?".
PROTECTED_TYPES = HARD_PROTECTED_TYPES | SOFT_PROTECTED_TYPES

#: Class 0: evicted first.
DROPPABLE_TYPES = frozenset({
    EventType.PERCEPTION_CHANGE,
    EventType.BACKGROUND_THOUGHT,
    EventType.SLEEP_EVENT,
    EventType.LEARNING_INTENT,
    EventType.MEMORY_CANDIDATE,
    EventType.DRIVE_CHANGE,
    EventType.QUANTUM_RESULT,
})

#: Class 1: active work.
WORK_TYPES = frozenset({
    EventType.TOOL_RESULT,
    EventType.GOAL_EVENT,
    EventType.PREDICTION_ERROR,
    EventType.REFLEX_RESULT,
})

#: Payload key a producer sets to opt an event into coalescing.
COALESCE_KEY = "coalesce_key"

_COUNTERS = ("published", "delivered", "dropped", "coalesced", "evicted",
             "protected_dropped", "lock_timeouts", "abandoned")
_HARD = 3


def eviction_class(etype: EventType) -> int:
    """0 droppable, 1 work, 2 soft-protected, 3 hard-protected (never evicted)."""
    if etype in HARD_PROTECTED_TYPES:
        return _HARD
    if etype in SOFT_PROTECTED_TYPES:
        return 2
    if etype in WORK_TYPES:
        return 1
    return 0


def header_of(event: CognitiveEvent, outcome: Optional[str] = None) -> Dict[str, Any]:
    """Header form of ``event``: everything but the payload's values.

    Payload *key names* are kept (they are schema, and the whole point when
    reading a ring buffer back), capped at :data:`MAX_HEADER_KEYS`. Payload
    *values* are not: they can be large, can be private, and holding them
    would make the debug ring a second, invisible copy of the queue.
    """
    payload = event.payload if isinstance(event.payload, Mapping) else {}
    keys = sorted(str(k) for k in payload)
    return {
        "event_id": event.event_id,
        "type": event.type.value,
        "source": event.source[:64],
        "priority": event.priority,
        "created_wall": event.created_wall,
        "created_mono": event.created_mono,
        "trace_id": event.trace_id,
        "parent_event_id": event.parent_event_id,
        "deadline_mono": event.deadline_mono,
        "salience": event.salience,
        "requires_response": event.requires_response,
        "payload_keys": keys[:MAX_HEADER_KEYS],
        "payload_key_count": len(keys),
        "payload_size": len(payload),
        "outcome": outcome,
    }


class EventBus:
    """Bounded priority mailbox for :class:`CognitiveEvent`.

    Construct one per process (there is deliberately no module-level
    singleton; ``server/init_brain.py`` owns the one Leon uses).

    Threading: every public method is safe from any thread, including an
    audio callback. :meth:`get` is the only one that blocks.
    """

    def __init__(self, maxsize: int = MAX_PENDING,
                 ring_capacity: int = RING_CAPACITY,
                 protected_headroom: int = PROTECTED_HEADROOM) -> None:
        if maxsize < 1:
            raise ValueError("maxsize must be at least 1")
        if ring_capacity < 1:
            raise ValueError("ring_capacity must be at least 1")
        if protected_headroom < 0:
            raise ValueError("protected_headroom must be >= 0")

        # queue.PriorityQueue provides the heap list and the Condition. The
        # bus drives both directly: eviction, coalescing and lazy deletion
        # are edits the public Queue API cannot express.
        self._q: "queue.PriorityQueue[Any]" = queue.PriorityQueue()
        self._heap: List[Tuple[int, int, int, CognitiveEvent]] = self._q.queue
        self._lock = self._q.mutex
        self._not_empty = self._q.not_empty

        self._maxsize = int(maxsize)
        self._headroom = int(protected_headroom)
        self._seq = itertools.count()
        # Unique per heap push. A coalesced event is re-pushed under its old
        # seq, so (priority, seq) can repeat; this tiebreak guarantees tuple
        # comparison never reaches the (non-orderable) event.
        self._push = itertools.count()
        # Lazy deletion. An entry (in any heap) is live iff
        # self._live.get(seq) is its event (identity). _live keeps insertion
        # order, so its first value is the oldest pending event.
        self._live: Dict[int, CognitiveEvent] = {}
        self._class_heaps: Dict[int, List[Tuple[int, int, int, CognitiveEvent]]] = {
            0: [], 1: [], 2: []}
        self._ckey_index: Dict[Tuple[str, str, Any], int] = {}
        self._seq_ckey: Dict[int, Tuple[str, str, Any]] = {}
        self._pending_by_type: Dict[str, int] = {}

        self._ring: "deque[Dict[str, Any]]" = deque(maxlen=int(ring_capacity))
        self._stopped = False
        self._max_depth = 0
        self._headroom_accepts = 0
        self._last_get_mono: Optional[float] = None
        self._counts = {name: 0 for name in _COUNTERS}
        self._by_type: Dict[str, Dict[str, int]] = {}
        # Guards the counters only on the lock-timeout path (where _lock is
        # not held). Never held while waiting for anything.
        import threading as _threading
        self._fail_mu = _threading.Lock()
        self._timeouts_by_type: Dict[str, int] = {}
        self._timeouts_protected = 0

    # -- publish ---------------------------------------------------------

    def publish(self, event: CognitiveEvent) -> bool:
        """Offer ``event`` to the bus. True if it was accepted.

        Main-heap entries are ``(-priority, sequence, push_id, event)``: the
        negated priority serves the most urgent event first, the sequence
        keeps FIFO within a priority (a coalesced event keeps its original
        sequence), and the unique push id guarantees the tuple comparison
        stops before it reaches the (non-orderable) event.

        False means the event was refused (bus stopped, or full of work at
        least as urgent) and is counted under ``dropped``.
        """
        if not isinstance(event, CognitiveEvent):
            raise TypeError(
                f"publish expects a CognitiveEvent, got "
                f"{event.__class__.__name__}")
        hdr = header_of(event)
        etype = event.type
        cls = eviction_class(etype)

        if not self._lock.acquire(timeout=PUBLISH_LOCK_TIMEOUT_S):
            # _lock is not held here, so these counters are separate (merged in stats()).
            with self._fail_mu:
                t = self._timeouts_by_type
                t[etype.value] = t.get(etype.value, 0) + 1
                if cls >= 2:
                    self._timeouts_protected += 1
            return False
        try:
            return self._publish_locked(event, etype, cls, hdr)
        finally:
            self._lock.release()

    def _publish_locked(self, event: CognitiveEvent, etype: EventType, cls: int,
                        hdr: Dict[str, Any]) -> bool:
        # Runs with self._lock (== the Condition's mutex) held.
        if self._stopped:
            self._count("dropped", etype)
            self._ring_add(hdr, "dropped:stopped")
            return False

        # 1. coalesce, if the producer asked for it (never speech)
        if cls < 2:
            ckey = self._coalesce_key(event)
            if ckey is not None:
                old_seq = self._ckey_index.get(ckey)
                if old_seq is not None:
                    superseded = self._live.get(old_seq)
                    if superseded is not None:
                        # push first, then mutate: a failed push leaves state intact
                        heapq.heappush(self._heap, (-event.priority, old_seq,
                                                    next(self._push), event))
                        if cls in self._class_heaps:
                            heapq.heappush(self._class_heaps[cls],
                                           (event.priority, old_seq,
                                            next(self._push), event))
                        self._live[old_seq] = event   # dict position (age) kept
                        self._pending_dec(superseded.type)
                        self._pending_inc(etype)
                        self._count("coalesced", superseded.type)
                        self._count("published", etype)
                        self._ring_add(hdr, "coalesced")
                        self._maybe_compact()
                        self._not_empty.notify()
                        return True
                    # stale index entry
                    self._ckey_index.pop(ckey, None)
                    self._seq_ckey.pop(old_seq, None)
        else:
            ckey = None

        # 2. capacity
        depth = len(self._live)
        if depth >= self._maxsize:
            victim_seq = self._pick_victim(event, cls)
            if victim_seq is not None:
                victim = self._remove(victim_seq)
                self._count("evicted", victim.type)
                self._ring_add(header_of(victim), "evicted")
            elif cls == _HARD and depth < self._maxsize + self._headroom:
                self._headroom_accepts += 1
            else:
                self._count("dropped", etype)
                if cls >= 2:
                    self._count("protected_dropped", etype)
                self._ring_add(hdr, "dropped:full")
                return False

        # 3. enqueue
        seq = next(self._seq)
        heapq.heappush(self._heap, (-event.priority, seq, next(self._push), event))
        if cls in self._class_heaps:
            heapq.heappush(self._class_heaps[cls],
                           (event.priority, seq, next(self._push), event))
        self._live[seq] = event
        if ckey is not None:
            self._ckey_index[ckey] = seq
            self._seq_ckey[seq] = ckey
        self._pending_inc(etype)
        depth = len(self._live)
        if depth > self._max_depth:
            self._max_depth = depth
        self._count("published", etype)
        self._ring_add(hdr, "published")
        self._maybe_compact()
        self._not_empty.notify()
        return True

    # -- consume ---------------------------------------------------------

    def get(self, timeout: Optional[float] = None) -> Optional[CognitiveEvent]:
        """Take the most urgent pending event, blocking if the bus is empty.

        ``timeout=None`` waits indefinitely; ``timeout=0`` polls. Returns
        ``None`` on timeout, and ``None`` once the bus has been stopped *and*
        drained (see :attr:`closed`). Every call, including a timeout, marks
        the consumer heartbeat reported as ``consumer_idle_s``.
        """
        deadline = None if timeout is None else time.monotonic() + float(timeout)
        with self._not_empty:
            while True:
                self._last_get_mono = time.monotonic()
                while self._heap:
                    _negp, seq, _push, event = heapq.heappop(self._heap)
                    if self._live.get(seq) is not event:
                        continue   # stale (coalesced-over, evicted or delivered)
                    self._remove(seq)
                    self._count("delivered", event.type)
                    return event
                if self._stopped:
                    return None
                if deadline is None:
                    self._not_empty.wait()
                else:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return None
                    self._not_empty.wait(remaining)

    def stop(self) -> None:
        """Stop the bus: wake every blocked :meth:`get` and refuse new work.

        Idempotent. Already-queued events stay gettable until drained.
        """
        with self._not_empty:
            if self._stopped:
                return
            self._stopped = True
            self._not_empty.notify_all()

    def drain_abandon(self) -> int:
        """Discard everything pending (a dying consumer only). Returns the count."""
        with self._lock:
            n = 0
            for seq, event in list(self._live.items()):
                self._count("abandoned", event.type)
                n += 1
            self._live.clear()
            self._heap.clear()
            for h in self._class_heaps.values():
                h.clear()
            self._ckey_index.clear()
            self._seq_ckey.clear()
            self._pending_by_type.clear()
            return n

    @property
    def closed(self) -> bool:
        """True once :meth:`stop` has run (disambiguates ``get() -> None``)."""
        return self._stopped

    # -- introspection ---------------------------------------------------

    def snapshot(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """The most recent event headers, oldest first (see :func:`header_of`).

        Covers every outcome (published, coalesced, evicted, dropped), so the
        ring shows what the bus *did*, not only what it kept. ``limit`` keeps
        the last N. Returns copies; mutating them affects nothing.
        """
        with self._lock:
            items = list(self._ring)
        if limit is not None:
            items = items[-int(limit):] if limit > 0 else []
        return [dict(h) for h in items]

    def stats(self) -> Dict[str, Any]:
        """Counters: totals, depth, and the same counters split by event type."""
        now = time.monotonic()
        with self._lock:
            out: Dict[str, Any] = {name: self._counts[name] for name in _COUNTERS}
            out["current_depth"] = len(self._live)
            out["heap_len"] = len(self._heap)
            out["max_depth"] = self._max_depth
            out["maxsize"] = self._maxsize
            out["protected_headroom"] = self._headroom
            out["headroom_accepts"] = self._headroom_accepts
            out["stopped"] = self._stopped
            out["ring_size"] = len(self._ring)
            out["pending_by_type"] = dict(self._pending_by_type)
            oldest = next(iter(self._live.values()), None)
            out["oldest_pending_age_s"] = (
                None if oldest is None else round(now - oldest.created_mono, 3))
            out["consumer_idle_s"] = (
                None if self._last_get_mono is None
                else round(now - self._last_get_mono, 3))
            out["by_type"] = {t: dict(c) for t, c in self._by_type.items()}
        with self._fail_mu:
            to = dict(self._timeouts_by_type)
            out["lock_timeouts"] += sum(to.values())
            out["protected_dropped"] += self._timeouts_protected
        for t, n in to.items():
            out["by_type"].setdefault(t, {c: 0 for c in _COUNTERS})["lock_timeouts"] += n
        return out

    def __len__(self) -> int:
        with self._lock:
            return len(self._live)

    # -- internals (all called with the lock held) ------------------------

    @staticmethod
    def _coalesce_key(event: CognitiveEvent) -> Optional[Tuple[str, str, Any]]:
        payload = event.payload
        if not isinstance(payload, Mapping):
            return None
        key = payload.get(COALESCE_KEY)
        if isinstance(key, bool) or not isinstance(key, (str, int)):
            return None
        return (event.type.value, event.source, key)

    def _pick_victim(self, newcomer: CognitiveEvent, cls: int) -> Optional[int]:
        """Sequence of the pending event to evict for ``newcomer``, or None."""
        if cls == _HARD or cls == 2:
            for c in (0, 1, 2):
                seq = self._peek_class(c)
                if seq is not None:
                    return seq
            return None
        if cls == 1:
            seq = self._peek_class(0)
            if seq is not None:
                return seq
            return self._peek_class(1, max_priority=newcomer.priority)
        return self._peek_class(0, max_priority=newcomer.priority)

    def _peek_class(self, cls: int, max_priority: Optional[int] = None) -> Optional[int]:
        """Lowest (priority, seq) live entry of a class, dropping stale tops."""
        heap = self._class_heaps[cls]
        while heap:
            prio, seq, _push, event = heap[0]
            if self._live.get(seq) is not event:
                heapq.heappop(heap)
                continue
            if max_priority is not None and prio > max_priority:
                return None
            return seq
        return None

    def _remove(self, seq: int) -> CognitiveEvent:
        event = self._live.pop(seq)
        ckey = self._seq_ckey.pop(seq, None)
        if ckey is not None and self._ckey_index.get(ckey) == seq:
            del self._ckey_index[ckey]
        self._pending_dec(event.type)
        return event

    def _maybe_compact(self) -> None:
        live = len(self._live)
        if len(self._heap) > 2 * live + 1024:
            self._heap[:] = [(-e.priority, s, next(self._push), e)
                             for s, e in self._live.items()]
            heapq.heapify(self._heap)
        for c, heap in self._class_heaps.items():
            if len(heap) > 2 * live + 1024:
                heap[:] = [(e.priority, s, next(self._push), e)
                           for s, e in self._live.items()
                           if eviction_class(e.type) == c]
                heapq.heapify(heap)

    def _pending_inc(self, etype: EventType) -> None:
        self._pending_by_type[etype.value] = self._pending_by_type.get(etype.value, 0) + 1

    def _pending_dec(self, etype: EventType) -> None:
        n = self._pending_by_type.get(etype.value, 0) - 1
        if n > 0:
            self._pending_by_type[etype.value] = n
        else:
            self._pending_by_type.pop(etype.value, None)

    def _ring_add(self, hdr: Dict[str, Any], outcome: str) -> None:
        h = dict(hdr)
        h["outcome"] = outcome
        self._ring.append(h)

    def _count(self, name: str, etype: EventType) -> None:
        self._counts[name] += 1
        per_type = self._by_type.get(etype.value)
        if per_type is None:
            per_type = {c: 0 for c in _COUNTERS}
            self._by_type[etype.value] = per_type
        per_type[name] += 1
