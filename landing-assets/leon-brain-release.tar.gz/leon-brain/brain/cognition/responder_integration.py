"""
Responder integration — keep the diff to claude_api_responder.py tiny.

This module exposes a small set of "maybe_*" helpers that the responder
can call without ever directly importing the cognition layer. Each
helper:
  * Returns a sensible default if cognition is None
  * Returns a sensible default if LEON_COGNITION_PROMPT is not enabled
  * Wraps every internal call in try/except so cognition failures NEVER
    break the responder

The goal is that turning cognition on/off is a single env-var flip with
zero behavioral difference when off.

Env flag: LEON_COGNITION_PROMPT=on    (default: off)
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.responder_integration")


def is_cognition_prompt_enabled() -> bool:
    """Global on/off for cognition-aware prompt augmentation."""
    return os.environ.get("LEON_COGNITION_PROMPT", "off").lower() in (
        "on", "1", "true", "yes",
    )


def _get_cognition():
    """Lazy import of the live cognition bundle from server module.

    Returns None if cognition not installed, not loaded, or import failed.
    """
    try:
        import server  # type: ignore
        return getattr(server, "cognition", None)
    except Exception:
        return None


# ── Helpers consumed by the responder ──────────────────────────────────────

def maybe_classify_route(user_text: str) -> Optional[Dict[str, Any]]:
    """Return Route.to_dict() if cognition is enabled+available, else None.

    The responder can use this to skip cognition entirely on reactive-layer
    inputs (saves tokens) or to route strategic-layer through autopilot.
    """
    if not is_cognition_prompt_enabled():
        return None
    cog = _get_cognition()
    if cog is None or getattr(cog, "hierarchy", None) is None:
        return None
    try:
        route = cog.hierarchy.classify(user_text or "")
        return route.to_dict()
    except Exception as e:
        log.warning("maybe_classify_route failed: %s", e)
        return None


def maybe_augment_prompt(
    base_prompt: str,
    user_text: str = "",
    *,
    force: bool = False,
    flags: Optional[Dict[str, bool]] = None,
) -> str:
    """Return base_prompt with cognition addendum appended, or base_prompt
    unchanged if cognition is off/unavailable.

    `force=True` bypasses the env flag — used by /api/cognition/prompt/preview
    so the preview works even when the flag is off.

    `flags` overrides the default section toggle (typically supplied by
    the hierarchy router's suggested_cognition_flags).
    """
    if not (force or is_cognition_prompt_enabled()):
        return base_prompt
    cog = _get_cognition()
    if cog is None or getattr(cog, "prompt_builder", None) is None:
        return base_prompt
    try:
        kwargs: Dict[str, Any] = {}
        if flags:
            kwargs.update(flags)
        return cog.prompt_builder.build(base_prompt, user_text, **kwargs)
    except Exception as e:
        log.warning("maybe_augment_prompt failed: %s", e)
        return base_prompt


def maybe_get_retry_budget(default: int = 1) -> int:
    """Pull retry budget from SNN gates (serotonin → retries).

    Patient brain (high 5HT) → more retries. Impatient → fewer.
    Falls back to `default` if cognition unavailable.
    """
    if not is_cognition_prompt_enabled():
        return default
    cog = _get_cognition()
    if cog is None or getattr(cog, "gates", None) is None:
        return default
    try:
        return int(cog.gates.current().retry_budget)
    except Exception:
        return default


def maybe_get_memory_depth(default: int = 6) -> int:
    """Conversation-history depth, scaled by acetylcholine.

    High ACh (focused/attentive) → smaller relevant window (top-K),
    low ACh (diffuse) → wider context. Returns turns count.
    """
    if not is_cognition_prompt_enabled():
        return default
    cog = _get_cognition()
    if cog is None or getattr(cog, "gates", None) is None:
        return default
    try:
        g = cog.gates.current()
        # memory_salience is 0.5..2.0; map onto turn-count multiplier
        scaled = max(2, int(round(default * g.memory_salience)))
        return min(20, scaled)
    except Exception:
        return default


def maybe_capture_lessons(user_text: str) -> int:
    """Best-effort: extract any Dean-correction lessons from `user_text`
    and persist them. Returns count captured. No-op if Phase 13 lessons
    isn't installed."""
    cog = _get_cognition()
    if cog is None or getattr(cog, "lessons", None) is None:
        return 0
    try:
        return len(cog.lessons.capture_from_turn(user_text or "", source="user_turn"))
    except Exception as e:
        log.warning("maybe_capture_lessons failed: %s", e)
        return 0


def maybe_executive_plan(user_text: str) -> Optional[Dict[str, Any]]:
    """If Phase 13 executive is installed, return its plan for `user_text`.
    Shadow-mode by default — caller decides whether to act on it."""
    cog = _get_cognition()
    if cog is None or getattr(cog, "executive", None) is None:
        return None
    try:
        return cog.executive.plan(user_text or "").to_dict()
    except Exception as e:
        log.warning("maybe_executive_plan failed: %s", e)
        return None


def maybe_reflex_answer(user_text: str) -> Optional[Dict[str, Any]]:
    """If a high-confidence reflex matches, return its answer dict, else
    None. The responder can use this as a sub-250ms fast path."""
    cog = _get_cognition()
    if cog is None or getattr(cog, "reflex", None) is None:
        return None
    try:
        r = cog.reflex.respond(user_text or "")
        return r.to_dict() if r is not None else None
    except Exception as e:
        log.warning("maybe_reflex_answer failed: %s", e)
        return None


def maybe_augment_user_message(
    user_message: str,
    user_text: Optional[str] = None,
    *,
    force: bool = False,
    flags: Optional[Dict[str, bool]] = None,
) -> str:
    """For sessions where the system prompt is fixed at start (persistent
    `claude -p` session), inject the cognition addendum INTO the user
    message body, framed as Leon's own internal state.

    The message Claude sees becomes:
        [LEON COGNITIVE STATE (your own — informs reply, don't address):
        <addendum>
        ]
        <original user_message>

    If cognition is off or unavailable, returns user_message unchanged.
    """
    if not (force or is_cognition_prompt_enabled()):
        # Even when prompt augmentation is OFF, capture lessons from the
        # raw user turn so Phase 13 still learns.
        try:
            maybe_capture_lessons(user_text or user_message)
        except Exception:
            pass
        return user_message
    cog = _get_cognition()
    if cog is None or getattr(cog, "prompt_builder", None) is None:
        return user_message
    try:
        # Phase 13 — capture lessons before building (so the newest rule
        # can show up in the same turn's prompt).
        try:
            maybe_capture_lessons(user_text or user_message)
        except Exception:
            pass
        # `user_text` is the raw user input (without history/preamble) used
        # to ground entity/world-model section matching. If not passed, use
        # the full message body as the matching target.
        match_text = user_text if user_text is not None else user_message
        # Phase 13 — prefer build_for_plan when executive is available
        plan = None
        exe = getattr(cog, "executive", None)
        if exe is not None and not flags:  # explicit flags override the plan
            try:
                plan = exe.plan(match_text)
            except Exception:
                plan = None
        if plan is not None and hasattr(cog.prompt_builder, "build_for_plan"):
            addendum = cog.prompt_builder.build_for_plan(plan, "", match_text)
        else:
            kwargs: Dict[str, Any] = {}
            if flags:
                kwargs.update(flags)
            addendum = cog.prompt_builder.build("", match_text, **kwargs)
        if not addendum or len(addendum.strip()) < 10:
            return user_message
        return (
            "[LEON COGNITIVE STATE (your own — informs reply, don't address directly):\n"
            f"{addendum.strip()}\n]\n\n"
            f"{user_message}"
        )
    except Exception as e:
        log.warning("maybe_augment_user_message failed: %s", e)
        return user_message


def maybe_get_confidence_threshold(default: float = 0.5) -> float:
    """Confidence threshold from gates (norepinephrine-driven). The responder
    can use this to decide whether to fire a tool speculatively or ask Dean."""
    if not is_cognition_prompt_enabled():
        return default
    cog = _get_cognition()
    if cog is None or getattr(cog, "gates", None) is None:
        return default
    try:
        return float(cog.gates.current().confidence_threshold)
    except Exception:
        return default


def maybe_record_user_input(user_text: str) -> None:
    """Tell the cognition layer that a real user input just arrived.
    Boosts the curiosity-decay timer (user is present) and triggers a
    drives.tick so loud-drive readings stay fresh."""
    cog = _get_cognition()
    if cog is None:
        return
    try:
        # Just nudge the drive system so on_episode timing reflects activity
        if getattr(cog, "drives", None) is not None:
            cog.drives.tick()
        # Update self-model presence (no-op if not implemented)
        if getattr(cog, "self_model", None) is not None:
            # Save will happen on the auto-cadence
            pass
    except Exception:
        pass


def maybe_log_response_outcome(
    user_text: str,
    response_text: str,
    *,
    latency_ms: float,
    success: bool,
    tools_called: Optional[List[str]] = None,
) -> None:
    """After a full response cycle, log a 'response' episode so the
    world model learns response-time and success patterns over time.
    No-op if cognition is unavailable.
    """
    cog = _get_cognition()
    if cog is None or getattr(cog, "loop", None) is None:
        return
    try:
        cog.loop.record_tool_call(
            "claude.response",
            {
                "input_len": len(user_text or ""),
                "output_len": len(response_text or ""),
                "tools_called": tools_called or [],
            },
            {"ok": success, "output_chars": len(response_text or "")},
            latency_ms,
            kind="response",
            success_override=bool(success),
        )
    except Exception as e:
        log.warning("maybe_log_response_outcome failed: %s", e)
