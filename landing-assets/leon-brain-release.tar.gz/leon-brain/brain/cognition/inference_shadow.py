"""
Leon V2 Phase 3, SHADOW half of the inference scheduler: tickets and what the
scheduler WOULD have done.

Every inference call reports a content-free ticket (kind, priority, site,
channel, arrival, start, end, outcome, whether a model was actually used).
The legacy path stays authoritative; this module only watches it and
computes, off the caller's thread:

* queue wait per foreground (USER/VOICE) ticket, measured and would-be
  (under the scheduler's preempt-lower-priority rule);
* would-be preemptions: a foreground ticket arrived while lower-priority
  work was running (the scheduler would have recorded PREEMPTED);
* violations:
    - ``user_waited_behind_background``: a foreground ticket waited more
      than 250 ms and part of that wait overlapped lower-priority work;
    - ``model_jobs_overlapped``: two tickets that both reached a model ran
      at the same time (respond_streaming level);
    - ``slot_overlap``: two HTTP generations were in flight against the
      single local model slot at once (local_llm level, definitive);
* model residency as state, from the load time Ollama reports per request.

Rules (runbook section 0 and the Phase 3 brief)
-----------------------------------------------
* **Producers never block and never raise.** A producer call is one
  ``next()`` on an ``itertools.count`` and one ``deque.append`` (both atomic
  under the GIL); no lock, no I/O, no allocation beyond one tuple.
* **Content-free.** Sites are code locations, channels are channel names.
  No prompt, reply, transcript or user text is ever accepted here.
* **Bounded.** Pending events, rings and the sidecar all have hard limits.
  The sidecar (default ``/var/log/leon/v2/inference_tickets.jsonl``) rotates
  once at 8 MiB and pauses for 10 minutes after a write failure.
* Importing this module does nothing: no threads, no files.
"""
from __future__ import annotations

import itertools
import json
import math
import os
import threading
import time
from collections import deque
from typing import Any, Callable, Deque, Dict, List, Optional

__all__ = ["ShadowLedger", "ShadowTicket", "SIDECAR_DEFAULT", "USER_WAIT_BUDGET_S",
           "percentile"]

SIDECAR_DEFAULT = "/var/log/leon/v2/inference_tickets.jsonl"
SIDECAR_ENV = "LEON_V2_SCHED_SIDECAR"
SIDECAR_MAX_BYTES = 8 * 1024 * 1024
USER_WAIT_BUDGET_S = 0.25
FOREGROUND = 100
COLD_LOAD_S = 5.0
HISTORY_S = 600.0
STALE_OPEN_S = 3600.0
_MAX_SITES = 64
MAX_OPEN_TICKETS = 4096
MAX_OPEN_SLOTS = 1024


def percentile(values: List[float], q: float) -> Optional[float]:
    """Nearest-rank percentile; None for no data."""
    if not values:
        return None
    s = sorted(values)
    k = max(0, min(len(s) - 1, math.ceil(q / 100.0 * len(s)) - 1))
    return s[k]


def _wait_summary(values: Deque[float]) -> Dict[str, Any]:
    vals = list(values)
    if not vals:
        return {"n": 0}
    return {"n": len(vals), "p50_s": round(percentile(vals, 50), 4),
            "p95_s": round(percentile(vals, 95), 4), "max_s": round(max(vals), 4)}


class ShadowTicket:
    """Producer-side handle for one inference call. Every method is a no-op
    on failure; none of them blocks."""

    __slots__ = ("_led", "id", "_model", "_done", "_error", "_ended")

    def __init__(self, led: "ShadowLedger", tid: int) -> None:
        self._led, self.id = led, tid
        self._model = self._done = self._error = self._ended = False

    def event(self, ev_type: Any, tier: Any = None) -> None:
        try:
            if ev_type == "model":
                if not self._model and tier != "reflex":
                    self._model = True
                    self._led._put(("model", self.id, self._led._clock()))
            elif ev_type == "done":
                self._done = True
            elif ev_type == "error":
                self._error = True
        except Exception:
            pass

    def end(self, *, cancelled: bool = False, raised: bool = False) -> None:
        try:
            if self._ended:
                return
            self._ended = True
            if self._done:
                outcome = "done"
            elif self._error:
                outcome = "error"
            elif cancelled:
                outcome = "cancelled"
            elif raised:
                outcome = "exception"
            else:
                outcome = "closed"      # the consumer stopped early (Stop, break)
            self._led._put(("end", self.id, self._led._clock(), outcome))
        except Exception:
            pass


class _T:
    __slots__ = ("id", "kind", "priority", "site", "channel", "group", "source",
                 "arrival", "arrival_known", "start", "end", "model", "outcome", "wall")

    def __init__(self, **kw: Any) -> None:
        self.end = None
        self.model = False
        self.outcome = None
        for k, v in kw.items():
            setattr(self, k, v)


def _overlap(a0: float, a1: float, b0: float, b1: float) -> float:
    return max(0.0, min(a1, b1) - max(a0, b0))


class ShadowLedger:
    """Collects tickets without blocking anyone; analyzes on its own thread."""

    def __init__(self, *, clock: Callable[[], float] = time.monotonic,
                 wall: Callable[[], float] = time.time,
                 sidecar_path: Optional[str] = None,
                 mode_fn: Optional[Callable[[], str]] = None,
                 ring: int = 512, max_pending: int = 8192,
                 user_wait_budget_s: float = USER_WAIT_BUDGET_S,
                 interval_s: float = 1.0) -> None:
        self._clock, self._wall = clock, wall
        if max_pending <= 0 or ring <= 0 or interval_s <= 0:
            raise ValueError("pending, ring and interval limits must be positive")
        self._pending: Deque[tuple] = deque(maxlen=max_pending)
        self._seq = itertools.count(1)
        self._ids = itertools.count(1)
        self._alock = threading.Lock()          # analyzer and stats readers only
        self._mode_fn = mode_fn
        #: cached live-flag mode; producers read this attribute, never the flag file
        self.mode = "off" if mode_fn is not None else "shadow"
        self._interval = interval_s
        self._budget = user_wait_budget_s
        self._open: Dict[int, _T] = {}
        self._recent: Deque[_T] = deque(maxlen=4096)
        self._slots_open: Dict[int, _T] = {}
        self._slots_recent: Deque[_T] = deque(maxlen=1024)
        self.tickets: Deque[Dict[str, Any]] = deque(maxlen=ring)
        self.violations: Deque[Dict[str, Any]] = deque(maxlen=ring)
        self.preemptions: Deque[Dict[str, Any]] = deque(maxlen=ring)
        self.waits_actual: Deque[float] = deque(maxlen=512)
        self.waits_would: Deque[float] = deque(maxlen=512)
        self.counters: Dict[str, int] = {}
        self.violation_counts: Dict[str, int] = {}
        self.sites: Dict[str, Dict[str, int]] = {}
        self.residency: Dict[str, Any] = {"state": "unknown", "cold_loads": 0,
                                          "last_load_s": None, "last_cold_wall": None,
                                          "last_ok_wall": None}
        self._processed = 0
        self._max_seq = 0
        self._sidecar_path = sidecar_path
        self._sidecar_buf: List[Dict[str, Any]] = []
        self._sidecar_paused_until = 0.0
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    # ── producers (any thread; never block, never raise) ──────────────────
    def _put(self, item: tuple) -> None:
        self._pending.append((next(self._seq),) + item)

    def begin(self, *, kind: str, priority: int, site: str, channel: Optional[str],
              group: str = "", arrival_mono: Optional[float] = None) -> Optional[ShadowTicket]:
        try:
            tid = next(self._ids)
            now = self._clock()
            known = arrival_mono is not None
            self._put(("begin", tid, now, str(kind), int(priority), str(site)[:96],
                       str(channel or "-")[:32], str(group or "")[:32],
                       arrival_mono if known else now, known, self._wall()))
            return ShadowTicket(self, tid)
        except Exception:
            return None

    def record_job(self, rec: Dict[str, Any]) -> None:
        """A finished scheduler job (the ON path reports itself here)."""
        try:
            self._put(("job", dict(rec)))
        except Exception:
            pass

    def slot_begin(self, label: str) -> Optional[int]:
        try:
            sid = next(self._ids)
            self._put(("slot_begin", sid, self._clock(), str(label)[:32], self._wall()))
            return sid
        except Exception:
            return None

    def slot_end(self, sid: Optional[int], outcome: str,
                 stats: Optional[Dict[str, Any]] = None) -> None:
        if sid is None:
            return
        try:
            clean = {}
            for k, v in (stats or {}).items():
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    clean[str(k)[:24]] = v
            self._put(("slot_end", sid, self._clock(), str(outcome)[:24], clean))
        except Exception:
            pass

    # ── analyzer ──────────────────────────────────────────────────────────
    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="v2-inference-shadow")
        self._thread.start()

    def stop(self, join_timeout: float = 0.0) -> None:
        self._stop.set()
        t = self._thread
        if t is not None and join_timeout > 0:
            t.join(join_timeout)

    def alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def refresh_mode(self) -> str:
        if self._mode_fn is not None:
            try:
                m = self._mode_fn()
                self.mode = m if m in ("off", "shadow", "canary", "on") else "off"
            except Exception:
                self.mode = "off"
        return self.mode

    def _loop(self) -> None:
        self.refresh_mode()
        while not self._stop.wait(self._interval):
            try:
                self.refresh_mode()
                self.drain()
            except Exception:
                self._count("analyzer_errors")
        # Preserve tickets already accepted before shutdown.
        try:
            self.drain()
        except Exception:
            self._count("analyzer_errors")

    def _count(self, name: str, n: int = 1) -> None:
        self.counters[name] = self.counters.get(name, 0) + n

    def drain(self, now: Optional[float] = None) -> int:
        """Process one bounded batch. Analyzer thread (or tests) only."""
        n = 0
        with self._alock:
            for _ in range(len(self._pending)):
                try:
                    item = self._pending.popleft()
                except IndexError:
                    break
                self._max_seq = max(self._max_seq, item[0])
                self._processed += 1
                n += 1
                try:
                    self._apply(item[1], item[2:])
                except Exception:
                    self._count("analyzer_errors")
            self._expire(self._clock() if now is None else now)
            self._flush_sidecar()
        return n

    def _apply(self, op: str, a: tuple) -> None:
        if op == "begin":
            tid, start, kind, prio, site, channel, group, arrival, known, wall = a
            t = _T(id=tid, kind=kind, priority=prio, site=site, channel=channel, group=group,
                   source="wrapper", arrival=min(arrival, start), arrival_known=known,
                   start=start, wall=wall)
            if len(self._open) >= MAX_OPEN_TICKETS:
                self._open.pop(next(iter(self._open)))
                self._count("open_overflow")
            self._open[tid] = t
            self._site(site, "n")
            self._count(f"kind.{kind}")
            if prio >= FOREGROUND:
                self._evaluate_start(t)
        elif op == "model":
            t = self._open.get(a[0])
            if t is not None:
                t.model = True
                self._site(t.site, "model")
        elif op == "end":
            tid, end, outcome = a
            t = self._open.pop(tid, None)
            if t is not None:
                t.end, t.outcome = max(end, t.start), outcome
                self._close(t)
        elif op == "job":
            rec = a[0]
            lost = max(0, int(rec.get("undelivered_tool_results", 0)))
            if lost:
                self._count("undelivered_tool_results", lost)
                self._emit({"kind": "delivery_failure",
                            "request_id": str(rec.get("request_id", ""))[:64],
                            "site": str(rec.get("site", ""))[:96],
                            "channel": str(rec.get("channel", "-"))[:32],
                            "outcome": str(rec.get("outcome", ""))[:24],
                            "undelivered_tool_results": lost,
                            "consumer_closed": bool(rec.get("consumer_closed")),
                            "delivery_abandoned": bool(rec.get("delivery_abandoned")),
                            "wall": self._wall()})
            start = rec.get("started_mono")
            end = rec.get("ended_mono")
            created = rec.get("created_mono")
            if start is None or end is None or created is None:
                self._count("job_not_started")
                self._emit({"kind": "job", **_public_job(rec)})
                return
            t = _T(id=next(self._ids), kind=rec.get("kind", "?"),
                   priority=int(rec.get("priority", 0)), site=str(rec.get("site", ""))[:96],
                   channel=str(rec.get("channel", "-"))[:32], group=str(rec.get("group", ""))[:32],
                   source="scheduler", arrival=created, arrival_known=True, start=start,
                   wall=rec.get("created_wall"))
            t.model = bool(rec.get("model_used"))
            self._count(f"kind.{t.kind}")
            self._site(t.site, "n")
            if t.priority >= FOREGROUND:
                self._evaluate_start(t)
            t.end, t.outcome = max(end, start), rec.get("outcome")
            self._close(t)
        elif op == "slot_begin":
            sid, start, label, wall = a
            if len(self._slots_open) >= MAX_OPEN_SLOTS:
                self._slots_open.pop(next(iter(self._slots_open)))
                self._count("slot_open_overflow")
            self._slots_open[sid] = _T(id=sid, kind="slot", priority=0, site=label, channel="-",
                                       group="", source="slot", arrival=start,
                                       arrival_known=True, start=start, wall=wall)
        elif op == "slot_end":
            sid, end, outcome, stats = a
            s = self._slots_open.pop(sid, None)
            if s is None:
                return
            s.end, s.outcome = max(end, s.start), outcome
            self._close_slot(s, stats)

    def _others(self, t: _T):
        for o in list(self._open.values()):
            if o.id != t.id:
                yield o
        for o in self._recent:
            if o.id != t.id:
                yield o

    def _evaluate_start(self, t: _T) -> None:
        """A foreground ticket started: measure its wait and what the scheduler
        would have done at its arrival."""
        if not t.arrival_known:
            self._count("fg_no_arrival")
            return
        actual = max(0.0, t.start - t.arrival)
        behind, blockers, would, victims = 0.0, [], 0.0, []
        for o in self._others(t):
            o_end = o.end if o.end is not None else t.start
            if o.priority < t.priority:
                ov = _overlap(o.start, o_end, t.arrival, t.start)
                if ov > 0:
                    behind += ov
                    if len(blockers) < 4:
                        blockers.append({"kind": o.kind, "site": o.site, "model": o.model,
                                         "overlap_s": round(ov, 3)})
                if o.start <= t.arrival and (o.end is None or o.end > t.arrival):
                    victims.append(o)
            elif o.start <= t.arrival and (o.end is None or o.end > t.arrival):
                would = max(would, min(t.start, o_end) - t.arrival)
        behind = min(behind, actual)
        would = max(0.0, min(would, actual))
        self.waits_actual.append(actual)
        self.waits_would.append(would)
        if actual > self._budget and behind > 0:
            self._violation("user_waited_behind_background", {
                "ticket_kind": t.kind, "site": t.site, "channel": t.channel,
                "wait_s": round(actual, 3), "behind_s": round(behind, 3),
                "would_wait_s": round(would, 3), "blockers": blockers})
        for v in victims:
            rec = {"kind": "would_preempt", "victim_kind": v.kind, "victim_site": v.site,
                   "victim_ran_s": round(max(0.0, t.arrival - v.start), 3),
                   "victim_used_model": v.model, "by_kind": t.kind, "by_site": t.site,
                   "wall": self._wall()}
            self.preemptions.append(rec)
            self._count("would_preempt")
            self._emit(rec)

    def _close(self, t: _T) -> None:
        if t.model:
            for o in list(self._recent):
                if o.model and o.end is not None:
                    ov = _overlap(o.start, o.end, t.start, t.end)
                    if ov > 0:
                        self._violation("model_jobs_overlapped", {
                            "a_kind": t.kind, "a_site": t.site, "b_kind": o.kind,
                            "b_site": o.site, "overlap_s": round(ov, 3)})
        self._recent.append(t)
        self._count(f"outcome.{t.outcome}")
        rec = {"kind": "ticket", "ticket_kind": t.kind, "priority": t.priority,
               "site": t.site, "channel": t.channel, "group": t.group, "source": t.source,
               "wait_s": round(max(0.0, t.start - t.arrival), 4) if t.arrival_known else None,
               "run_s": round(t.end - t.start, 4), "model": t.model, "outcome": t.outcome,
               "wall": t.wall}
        self.tickets.append(rec)
        self._emit(rec)

    def _close_slot(self, s: _T, stats: Dict[str, Any]) -> None:
        for o in list(self._slots_recent):
            ov = _overlap(o.start, o.end, s.start, s.end)
            if ov > 0:
                self._violation("slot_overlap", {"a": s.site, "b": o.site,
                                                 "overlap_s": round(ov, 3)})
        self._slots_recent.append(s)
        self._count(f"slot.{s.outcome}")
        load_s = stats.get("load_s")
        r = self.residency
        if s.outcome in ("done", "ok"):
            r["state"] = "resident"
            r["last_ok_wall"] = self._wall()
        elif s.outcome == "unreachable":
            r["state"] = "unavailable"
        if isinstance(load_s, (int, float)):
            r["last_load_s"] = round(float(load_s), 3)
            if load_s >= COLD_LOAD_S:
                r["cold_loads"] += 1
                r["last_cold_wall"] = self._wall()
                fg_open = [t for t in self._open.values() if t.priority >= FOREGROUND]
                self._count("cold_load")
                if fg_open:
                    self._violation("cold_load_during_user_turn", {
                        "slot": s.site, "load_s": round(float(load_s), 3),
                        "ticket_kind": fg_open[0].kind})
        self._emit({"kind": "slot", "label": s.site, "run_s": round(s.end - s.start, 4),
                    "outcome": s.outcome, **{k: v for k, v in stats.items()}})

    def _violation(self, vtype: str, detail: Dict[str, Any]) -> None:
        rec = {"kind": "violation", "type": vtype, "wall": self._wall(), **detail}
        self.violations.append(rec)
        self.violation_counts[vtype] = self.violation_counts.get(vtype, 0) + 1
        self._emit(rec)

    def _site(self, site: str, key: str) -> None:
        d = self.sites.get(site)
        if d is None:
            if len(self.sites) >= _MAX_SITES:
                self._count("sites_overflow")
                return
            d = self.sites[site] = {"n": 0, "model": 0}
        d[key] = d.get(key, 0) + 1

    def _expire(self, now: float) -> None:
        while self._recent and self._recent[0].end is not None and now - self._recent[0].end > HISTORY_S:
            self._recent.popleft()
        while (self._slots_recent and self._slots_recent[0].end is not None
               and now - self._slots_recent[0].end > HISTORY_S):
            self._slots_recent.popleft()
        for tid, t in list(self._open.items()):
            if now - t.start > STALE_OPEN_S:
                self._open.pop(tid, None)
                self._count("stale_open")
        for sid, s in list(self._slots_open.items()):
            if now - s.start > STALE_OPEN_S:
                self._slots_open.pop(sid, None)
                self._count("stale_slot")

    # ── sidecar (analyzer thread only) ────────────────────────────────────
    def _emit(self, rec: Dict[str, Any]) -> None:
        if self._sidecar_path and len(self._sidecar_buf) < 4096:
            self._sidecar_buf.append(rec)

    def _flush_sidecar(self) -> None:
        if not self._sidecar_buf:
            return
        buf, self._sidecar_buf = self._sidecar_buf, []
        path = self._sidecar_path
        if not path or time.monotonic() < self._sidecar_paused_until:
            return
        try:
            d = os.path.dirname(path)
            if d and not os.path.isdir(d):
                if not os.path.isdir(os.path.dirname(d) or "/"):
                    return
                os.makedirs(d, mode=0o750, exist_ok=True)
            size = os.path.getsize(path) if os.path.exists(path) else 0
            fh = open(path, "ab")
            try:
                for rec in buf:
                    line = (json.dumps(rec, separators=(",", ":"), default=str) + "\n").encode("utf-8")
                    if len(line) > SIDECAR_MAX_BYTES:
                        self._count("sidecar_oversize_records")
                        continue
                    if size + len(line) > SIDECAR_MAX_BYTES:
                        fh.close()
                        os.replace(path, path + ".1")
                        fh = open(path, "ab")
                        size = 0
                    fh.write(line)
                    size += len(line)
            finally:
                fh.close()
        except Exception as exc:
            self._sidecar_paused_until = time.monotonic() + 600.0
            self._count("sidecar_failures")
            print(f"[V2] inference shadow sidecar failed exc={type(exc).__name__} "
                  f"subsystem=v2.inference_scheduler recovery=paused 10 min; rings continue",
                  flush=True)

    # ── readers (API threads) ─────────────────────────────────────────────
    def stats(self) -> Dict[str, Any]:
        with self._alock:
            produced = self._max_seq
            return {
                "mode": self.mode, "analyzer_alive": self.alive(),
                "pending": len(self._pending), "open": len(self._open),
                "processed": self._processed,
                "dropped_estimate": max(0, produced - self._processed - len(self._pending)),
                "counters": dict(self.counters),
                "violations": dict(self.violation_counts),
                "user_wait_actual": _wait_summary(self.waits_actual),
                "user_wait_would": _wait_summary(self.waits_would),
                "would_preempt": self.counters.get("would_preempt", 0),
                "residency": dict(self.residency),
                "sites": {k: dict(v) for k, v in self.sites.items()},
                "budget_s": self._budget,
                "sidecar": self._sidecar_path or None,
            }

    def recent(self, what: str = "tickets", limit: int = 100) -> List[Dict[str, Any]]:
        ring = {"tickets": self.tickets, "violations": self.violations,
                "preemptions": self.preemptions}.get(what)
        if ring is None:
            return []
        with self._alock:
            items = list(ring)
        return [dict(r) for r in items[-max(1, min(int(limit), len(items) or 1)):]]


def _public_job(rec: Dict[str, Any]) -> Dict[str, Any]:
    keep = ("priority", "site", "group", "channel", "admission", "outcome",
            "wait_s", "run_s", "events", "model_used", "created_wall")
    out = {k: rec.get(k) for k in keep}
    out["job_kind"] = rec.get("kind")
    return out
