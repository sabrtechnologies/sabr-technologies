"""Bounded private development artifacts, never check/source attestations.

Only an operator registry selects paths. Captures measure complete explicit input
trees; they detect observed changes but do not exclude writers. CheckEvidence
requires a separate enforced immutable execution boundary and retained receipt.
No process, database, grant, thread, filesystem write or promotion lives here.
"""
from __future__ import annotations

import base64
from dataclasses import asdict, dataclass
import hashlib
import json
import os
import re
import stat
import time

MAX_FILES = 128
MAX_DIRECTORIES = 64
MAX_FILE_BYTES = 65536
MAX_TOTAL_BYTES = 2 * 1024 * 1024
MAX_BUNDLE_BYTES = 6 * 1024 * 1024
MAX_CAPTURE_SECONDS = 2.0


class ArtifactDenied(ValueError):
    pass


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def _hash(value):
    return hashlib.sha256(value).hexdigest()


def _sha(value):
    if type(value) is not str or not re.fullmatch('[0-9a-f]{64}', value):
        raise ArtifactDenied('exact_digest_required')


def _ref(value):
    if type(value) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}', value):
        raise ArtifactDenied('bounded_reference_required')


def _path(value):
    if (type(value) is not str or not 0 < len(value.encode('utf-8')) <= 256
            or '\\' in value or ':' in value or '\0' in value):
        raise ArtifactDenied('bounded_relative_input_required')
    parts = value.split('/')
    if len(parts) > 8 or any(p in ('', '.', '..', '.git', '.hg', '.svn') for p in parts):
        raise ArtifactDenied('source_path_escape_or_metadata')
    return parts


@dataclass(frozen=True)
class InputFile:
    path: str
    mode: int


@dataclass(frozen=True)
class DevelopmentBinding:
    """Trusted operator/dev registry row, not a model-selected filesystem root.

    input_files covers EVERY input file in the existing tree. Dependencies outside
    it must be separately pinned by configuration; completeness is an operator
    contract, not inferred from an arbitrary test's imports. authorization_ref is
    permission to prepare this artifact, never permission to execute or promote.
    """
    registration_id: str
    principal: str
    proposal_task_id: str
    parent_task_id: str
    workspace_scope: str
    root: str
    root_identity: tuple[int, int]
    owner_uid: int
    configuration_sha256: str
    isolation_ref: str
    authorization_ref: str
    source_revision: str
    input_files: tuple[InputFile, ...]
    editable_paths: tuple[str, ...]
    protected_paths: tuple[str, ...]
    required_checks: tuple[str, ...]


@dataclass(frozen=True)
class Replacement:
    path: str
    content: bytes


@dataclass(frozen=True)
class PrivateArtifact:
    """Contains private file bytes. Persist only in reviewed private storage.

    Construction/deserialization does not confer authority or prove execution.
    metadata() is safe for the bounded operational artifact checkpoint, subject
    to the installation's ordinary path/reference privacy policy.
    """
    bundle: bytes

    def metadata(self):
        value = _decode(self.bundle)
        _metadata(value['metadata'])
        return dict(value['metadata'], artifact_sha256=_hash(self.bundle),
                    check_evidence=False, executed=False)


def _binding(value):
    if type(value) is not DevelopmentBinding:
        raise ArtifactDenied('trusted_development_binding_required')
    for name in ('registration_id', 'principal', 'proposal_task_id', 'parent_task_id',
                 'workspace_scope', 'isolation_ref', 'authorization_ref'):
        _ref(getattr(value, name))
    if (not value.workspace_scope.startswith('workspace:') or value.parent_task_id == value.proposal_task_id
            or type(value.root) is not str or not value.root.startswith('/') or '\0' in value.root
            or any(p in ('', '.', '..') for p in value.root.split('/')[1:])
            or type(value.root_identity) is not tuple or len(value.root_identity) != 2
            or any(type(v) is not int or not 0 <= v < 2**64 for v in value.root_identity)
            or type(value.owner_uid) is not int or value.owner_uid < 0
            or type(value.source_revision) is not str
            or not re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}', value.source_revision)):
        raise ArtifactDenied('exact_managed_development_identity_required')
    _sha(value.configuration_sha256)
    if type(value.input_files) is not tuple or not 1 <= len(value.input_files) <= MAX_FILES:
        raise ArtifactDenied('bounded_complete_input_inventory_required')
    files, directories = {}, set()
    for item in value.input_files:
        if type(item) is not InputFile or type(item.mode) is not int or item.mode not in (0o600, 0o644, 0o700, 0o755):
            raise ArtifactDenied('regular_private_input_mode_required')
        parts = _path(item.path)
        if item.path in files: raise ArtifactDenied('duplicate_input_path')
        files[item.path] = item.mode
        directories.update('/'.join(parts[:n]) for n in range(1, len(parts)))
    if files.keys() & directories or len(directories) > MAX_DIRECTORIES:
        raise ArtifactDenied('bounded_unambiguous_input_tree_required')
    for values, maximum in ((value.editable_paths, 16), (value.protected_paths, 32), (value.required_checks, 3)):
        if type(values) is not tuple or not 1 <= len(values) <= maximum or any(type(x) is not str for x in values):
            raise ArtifactDenied('immutable_development_policy_required')
        if len(set(values)) != len(values): raise ArtifactDenied('duplicate_policy_entry')
    for path in (*value.editable_paths, *value.protected_paths): _path(path)
    if not set(value.editable_paths) <= files.keys(): raise ArtifactDenied('editable_input_not_registered')
    for check in value.required_checks: _ref(check)
    return files, directories


def _fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _open_root(path):
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open('/', flags)
    try:
        for part in path.split('/')[1:]:
            child = os.open(part, flags, dir_fd=fd)
            os.close(fd); fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def _snapshot(binding, files, directories, deadline):
    contents, inventory, observed, total = {}, [], {}, 0

    def budget():
        if time.monotonic() > deadline: raise ArtifactDenied('capture_time_budget_exhausted')

    def walk(fd, prefix):
        nonlocal total
        budget()
        before = os.fstat(fd)
        if (before.st_dev != binding.root_identity[0] or before.st_uid != binding.owner_uid
                or not stat.S_ISDIR(before.st_mode) or stat.S_IMODE(before.st_mode) not in (0o700, 0o755)):
            raise ArtifactDenied('unmanaged_directory')
        observed[prefix] = _fingerprint(before)
        inventory.append({'path': prefix, 'kind': 'directory', 'mode': stat.S_IMODE(before.st_mode)})
        names = []
        with os.scandir(fd) as entries:
            for entry in entries:
                budget()
                names.append(entry.name)
                if len(names) > MAX_FILES + MAX_DIRECTORIES:
                    raise ArtifactDenied('input_entry_budget_exhausted')
        for name in sorted(names):
            path = prefix + '/' + name if prefix else name
            _path(path)
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if stat.S_ISDIR(info.st_mode):
                if path not in directories: raise ArtifactDenied('unknown_input_directory')
                child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                try:
                    if _fingerprint(os.fstat(child)) != _fingerprint(info): raise ArtifactDenied('directory_changed')
                    walk(child, path)
                finally: os.close(child)
            else:
                if (path not in files or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                        or info.st_dev != binding.root_identity[0] or info.st_uid != binding.owner_uid
                        or stat.S_IMODE(info.st_mode) != files[path] or not 0 <= info.st_size <= MAX_FILE_BYTES):
                    raise ArtifactDenied('unknown_aliased_or_changed_input')
                child = os.open(name, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                try:
                    if _fingerprint(os.fstat(child)) != _fingerprint(info): raise ArtifactDenied('input_changed_before_read')
                    chunks, size = [], 0
                    while True:
                        budget()
                        chunk = os.read(child, min(8192, MAX_FILE_BYTES + 1 - size))
                        if not chunk: break
                        size += len(chunk)
                        if size > MAX_FILE_BYTES or total + size > MAX_TOTAL_BYTES: raise ArtifactDenied('input_byte_budget_exhausted')
                        chunks.append(chunk)
                    if _fingerprint(os.fstat(child)) != _fingerprint(info): raise ArtifactDenied('input_changed_during_read')
                finally: os.close(child)
                if _fingerprint(os.stat(name, dir_fd=fd, follow_symlinks=False)) != _fingerprint(info):
                    raise ArtifactDenied('input_changed_after_read')
                data = b''.join(chunks)
                if len(data) != info.st_size: raise ArtifactDenied('input_size_changed')
                contents[path] = data; total += len(data); observed[path] = _fingerprint(info)
                inventory.append({'path': path, 'kind': 'file', 'mode': files[path],
                                  'size': len(data), 'sha256': _hash(data)})
        if _fingerprint(os.fstat(fd)) != _fingerprint(before): raise ArtifactDenied('directory_changed_during_read')

    root = _open_root(binding.root)
    try:
        if (os.fstat(root).st_dev, os.fstat(root).st_ino) != binding.root_identity:
            raise ArtifactDenied('workspace_identity_changed')
        walk(root, '')
        check = _open_root(binding.root)
        try:
            if _fingerprint(os.fstat(check)) != _fingerprint(os.fstat(root)):
                raise ArtifactDenied('workspace_path_changed')
        finally: os.close(check)
    finally: os.close(root)
    if contents.keys() != files.keys(): raise ArtifactDenied('missing_input_file')
    return contents, sorted(inventory, key=lambda x: x['path']), observed


def _build(binding, contents, inventory, replacements):
    if type(replacements) is not tuple or not 1 <= len(replacements) <= 4:
        raise ArtifactDenied('bounded_candidate_required')
    candidate, changes, seen = dict(contents), [], set()
    for replacement in replacements:
        if type(replacement) is not Replacement: raise ArtifactDenied('exact_replacement_required')
        _path(replacement.path)
        if (replacement.path in seen or replacement.path not in binding.editable_paths
                or any(replacement.path == p or replacement.path.startswith(p+'/') for p in binding.protected_paths)
                or type(replacement.content) is not bytes or len(replacement.content) > 8192):
            raise ArtifactDenied('replacement_scope_or_size_denied')
        before, after = contents[replacement.path], replacement.content
        try: before.decode('utf-8'); after.decode('utf-8')
        except UnicodeError: raise ArtifactDenied('replacement_requires_utf8') from None
        if before == after: raise ArtifactDenied('replacement_has_no_change')
        seen.add(replacement.path); candidate[replacement.path] = after
        changes.append({'path': replacement.path, 'before_sha256': _hash(before), 'after_sha256': _hash(after)})
    if sum(map(len, candidate.values())) > MAX_TOTAL_BYTES: raise ArtifactDenied('candidate_byte_budget_exhausted')
    candidate_inventory = [dict(row, size=len(candidate[row['path']]), sha256=_hash(candidate[row['path']]))
                           if row['kind'] == 'file' else dict(row) for row in inventory]
    # Byte-exact canonical replacement document, not a lossy rendered patch.
    patch = [{'path': p, 'before_base64': base64.b64encode(contents[p]).decode(),
              'after_base64': base64.b64encode(candidate[p]).decode()} for p in sorted(seen)]
    metadata = {'schema': 1, 'kind': 'development_artifact', 'binding_sha256': _hash(_json(asdict(binding))),
                'registration_id': binding.registration_id, 'proposal_task_id': binding.proposal_task_id,
                'parent_task_id': binding.parent_task_id, 'workspace_scope': binding.workspace_scope,
                'root_identity': list(binding.root_identity), 'configuration_sha256': binding.configuration_sha256,
                'isolation_ref': binding.isolation_ref, 'authorization_ref': binding.authorization_ref,
                'source_revision': binding.source_revision, 'source_tree_sha256': _hash(_json(inventory)),
                'candidate_tree_sha256': _hash(_json(candidate_inventory)), 'diff_sha256': _hash(_json(patch)),
                'changes': sorted(changes, key=lambda x: x['path']), 'input_count': len(contents),
                'source_bytes': sum(map(len, contents.values())), 'candidate_bytes': sum(map(len, candidate.values()))}
    bundle = _json({'metadata': metadata, 'source_inventory': inventory, 'candidate_inventory': candidate_inventory,
                    'source_files': {p: base64.b64encode(data).decode() for p, data in contents.items()}, 'patch': patch})
    if len(bundle) > MAX_BUNDLE_BYTES: raise ArtifactDenied('artifact_budget_exhausted')
    return PrivateArtifact(bundle)


def _metadata(value):
    references = ('registration_id', 'proposal_task_id', 'parent_task_id', 'workspace_scope',
                  'isolation_ref', 'authorization_ref')
    hashes = ('binding_sha256', 'configuration_sha256', 'source_tree_sha256',
              'candidate_tree_sha256', 'diff_sha256')
    keys = {'schema', 'kind', 'root_identity', 'source_revision', 'changes', 'input_count',
            'source_bytes', 'candidate_bytes', *references, *hashes}
    if type(value) is not dict or set(value) != keys or len(_json(value)) > 8192:
        raise ArtifactDenied('bounded_artifact_metadata_required')
    for name in references: _ref(value[name])
    for name in hashes: _sha(value[name])
    if (type(value['schema']) is not int or value['schema'] != 1 or value['kind'] != 'development_artifact'
            or type(value['root_identity']) is not list or len(value['root_identity']) != 2
            or any(type(v) is not int or not 0 <= v < 2**64 for v in value['root_identity'])
            or type(value['source_revision']) is not str
            or not re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}', value['source_revision'])
            or type(value['input_count']) is not int or not 1 <= value['input_count'] <= MAX_FILES
            or any(type(value[k]) is not int or not 0 <= value[k] <= MAX_TOTAL_BYTES
                   for k in ('source_bytes', 'candidate_bytes'))
            or type(value['changes']) is not list or not 1 <= len(value['changes']) <= 4):
        raise ArtifactDenied('exact_artifact_metadata_required')
    for row in value['changes']:
        if type(row) is not dict or set(row) != {'path', 'before_sha256', 'after_sha256'}:
            raise ArtifactDenied('exact_change_metadata_required')
        _path(row['path']); _sha(row['before_sha256']); _sha(row['after_sha256'])


def _decode(bundle):
    if type(bundle) is not bytes or len(bundle) > MAX_BUNDLE_BYTES:
        raise ArtifactDenied('bounded_private_bundle_required')
    try:
        value = json.loads(bundle)
        if type(value) is not dict or set(value) != {'metadata', 'source_inventory', 'candidate_inventory', 'source_files', 'patch'}:
            raise ValueError()
        if _json(value) != bundle: raise ValueError()
        return value
    except (ValueError, TypeError, RecursionError, UnicodeError):
        raise ArtifactDenied('canonical_artifact_required') from None


def validate_bundle(binding, bundle):
    """Pure integrity check. A valid artifact still proves no filesystem origin.

    Durable registry must bind the hash of an actual capture; caller-supplied
    bundles/hashes never become check evidence by passing this function.
    """
    files, directories = _binding(binding)
    value = _decode(bundle)
    try:
        if type(value['source_files']) is not dict or value['source_files'].keys() != files.keys(): raise ValueError()
        contents = {p: base64.b64decode(data, validate=True) for p, data in value['source_files'].items()}
        if any(len(x) > MAX_FILE_BYTES for x in contents.values()) or sum(map(len, contents.values())) > MAX_TOTAL_BYTES: raise ValueError()
        inventory = value['source_inventory']
        expected = [{'path': p, 'kind': 'file', 'mode': files[p], 'size': len(data), 'sha256': _hash(data)}
                    for p, data in contents.items()]
        if type(inventory) is not list or len(inventory) != len(files)+len(directories)+1: raise ValueError()
        for row in inventory:
            if type(row) is not dict: raise ValueError()
            if row.get('kind') == 'directory':
                if set(row) != {'path', 'kind', 'mode'} or row['path'] not in directories | {''} or type(row['mode']) is not int or row['mode'] not in (0o700, 0o755): raise ValueError()
                expected.append(row)
        if (len(expected) != len(files)+len(directories)+1 or len({r['path'] for r in expected}) != len(expected)
                or sorted(expected, key=lambda x: x['path']) != inventory): raise ValueError()
        patch = value['patch']
        if type(patch) is not list or not 1 <= len(patch) <= 4: raise ValueError()
        replacements = []
        for row in patch:
            if type(row) is not dict or set(row) != {'path', 'before_base64', 'after_base64'}: raise ValueError()
            if base64.b64decode(row['before_base64'], validate=True) != contents[row['path']]: raise ValueError()
            replacements.append(Replacement(row['path'], base64.b64decode(row['after_base64'], validate=True)))
        result = _build(binding, contents, inventory, tuple(replacements))
        if result.bundle != bundle: raise ValueError()
        return result
    except (ValueError, TypeError, KeyError, OverflowError):
        raise ArtifactDenied('artifact_integrity_or_binding_differs') from None


class ImprovementArtifacts:
    def __init__(self, *, resolve_binding, enabled=lambda: False):
        if not callable(resolve_binding) or not callable(enabled): raise TypeError('trusted registry required')
        self._resolve, self._enabled, self._stopping = resolve_binding, enabled, False

    def capture(self, registration_id, *, principal, replacements):
        if self._stopping or self._enabled() is not True: raise ArtifactDenied('artifact_capture_disabled')
        _ref(registration_id); _ref(principal)
        binding = self._resolve(registration_id)
        files, directories = _binding(binding)
        if binding.registration_id != registration_id or binding.principal != principal:
            raise ArtifactDenied('registered_principal_required')
        if os.name != 'posix' or not hasattr(os, 'O_NOFOLLOW'): raise ArtifactDenied('descriptor_platform_required')
        deadline = time.monotonic() + MAX_CAPTURE_SECONDS
        try:
            contents, inventory, observed = _snapshot(binding, files, directories, deadline)
            second = _snapshot(binding, files, directories, deadline)
            if (contents, inventory, observed) != second: raise ArtifactDenied('source_changed_between_reads')
        except OSError:
            raise ArtifactDenied('source_unavailable_or_changed') from None
        if self._stopping or self._enabled() is not True or self._resolve(registration_id) != binding:
            raise ArtifactDenied('capture_authority_changed')
        return _build(binding, contents, inventory, replacements)

    def quiesce(self):
        self._stopping = True
