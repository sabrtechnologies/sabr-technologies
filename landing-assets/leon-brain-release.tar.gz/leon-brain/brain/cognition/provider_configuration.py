"""Trusted startup configuration for hosted provider routes.

One private operator JSON file becomes the exact frozen ``ProviderHookConfig``
that ``install_provider_from_server_state`` consumes. Loading builds typed
policy, routes and one cold OpenAI adapter; it opens no ledger, sends nothing
and reads a credential only through the environment variable NAME the file
declares. No JSON field can carry a credential value, a callable, a tool
permission or a request scope the installed hook does not match exactly.
Importing this module is cold; typed owners are imported after parsing.
"""
from __future__ import annotations

import json
import math
import os
import re
import stat
import time
from typing import Mapping

_MAX_FILE_BYTES = 16384
_HOST = 'api.openai.com'
_BASE_URL = 'https://api.openai.com'
_TEXT_CAPABILITIES = ('fast_language', 'coding', 'deep_reasoning')
_TOP = frozenset(('schema', 'policy_revision', 'valid_until_wall', 'providers', 'routes',
                  'limits', 'ledger_path'))
_PROVIDER = frozenset(('provider_id', 'kind', 'model', 'credential_env', 'pricing', 'bounds',
                       'evidence_ref', 'verified'))
_PRICING = frozenset(('input_per_million_usd', 'output_per_million_usd'))
_BOUNDS = frozenset(('max_input_tokens', 'max_output_tokens', 'max_call_seconds'))
_VERIFIED = frozenset(('billing', 'full_call_bounds', 'transport_cancellation', 'no_tools',
                       'tool_drain'))
_ROUTE = frozenset(('site', 'group', 'channel', 'provider_id', 'capabilities',
                    'max_output_tokens', 'canary'))
_LIMITS = frozenset(('global_usd_per_day', 'per_capability_usd_per_day'))
_MAX_VALIDITY_S = 366 * 86400
_MAX_USD_PER_DAY = 10000
_MAX_PRICE_USD_PER_MILLION = 1000
_DAYS_PER_MONTH = 31  # Schema 1 has no monthly field; the monthly ceiling is 31 daily ceilings.
_LEDGER_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\.sqlite3')
_ENV_NAME = re.compile(r'[A-Z][A-Z0-9_]{0,63}')
_MODEL_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}')


def _reference(value, limit=200):
    if (type(value) is not str or not value.strip() or len(value.encode('utf-8')) > limit
            or any(ord(ch) < 32 or ord(ch) == 127 for ch in value)):
        raise ValueError('bounded explicit provider configuration reference required')
    return value


def _number(value, low, high):
    try:
        if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
            raise ValueError('bounded finite provider configuration number required')
    except OverflowError as error:
        raise ValueError('bounded finite provider configuration number required') from error
    return value


def _integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError('bounded provider configuration integer required')
    return value


def _absolute(value):
    if (type(value) is not str or not value or '\0' in value or not os.path.isabs(value)
            or os.path.normpath(value) != value or os.path.realpath(value) != value):
        raise ValueError('explicit unaliased absolute provider path required')
    return value


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate provider configuration key')
        result[key] = value
    return result


def _nonfinite(_):
    raise ValueError('nonfinite provider configuration number')


def _file_identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_ctime_ns, info.st_mode, info.st_uid, info.st_nlink)


def _directory_identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid)


def _private_json(path):
    """Read without following aliases and reject replacement or mutation.

    Same contract as the thought configuration loader: directory-relative
    opens pin every component, the final directory is operator-owned and not
    group/other writable, the file is a private single-link regular file of
    at most 16 KiB, and its identity is compared before and after the read.
    """
    if (os.name != 'posix' or not all(hasattr(os, key) for key in
                                    ('O_NOFOLLOW', 'O_CLOEXEC', 'O_DIRECTORY', 'geteuid'))):
        raise ValueError('private provider configuration requires POSIX file ownership')
    _absolute(path)
    directory, filename = os.path.split(path)
    if not filename:
        raise ValueError('explicit provider configuration file required')
    directory_fd = file_fd = None
    try:
        directory_flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_DIRECTORY
        directory_fd = os.open('/', directory_flags)
        for part in directory.split('/')[1:]:
            if not part:
                continue
            next_fd = os.open(part, directory_flags, dir_fd=directory_fd)
            os.close(directory_fd)
            directory_fd = next_fd
        parent = os.fstat(directory_fd)
        if (not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.geteuid()
                or parent.st_mode & 0o022):
            raise ValueError('exclusive provider configuration directory required')
        file_fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                          dir_fd=directory_fd)
        before = os.fstat(file_fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or before.st_uid != os.geteuid() or before.st_mode & 0o077
                or not 0 < before.st_size <= _MAX_FILE_BYTES):
            raise ValueError('private bounded regular provider configuration required')
        chunks, size = [], 0
        while size <= _MAX_FILE_BYTES:
            piece = os.read(file_fd, min(4096, _MAX_FILE_BYTES + 1 - size))
            if not piece:
                break
            chunks.append(piece)
            size += len(piece)
        after = os.fstat(file_fd)
        current = os.stat(filename, dir_fd=directory_fd, follow_symlinks=False)
        current_parent = os.stat(directory, follow_symlinks=False)
        if (size > _MAX_FILE_BYTES or size != before.st_size
                or _file_identity(before) != _file_identity(after)
                or _file_identity(before) != _file_identity(current)
                or _directory_identity(parent) != _directory_identity(os.fstat(directory_fd))
                or _directory_identity(parent) != _directory_identity(current_parent)
                or os.path.realpath(path) != path):
            raise ValueError('provider configuration changed during read')
        try:
            return json.loads(b''.join(chunks).decode('utf-8'), object_pairs_hook=_unique,
                              parse_constant=_nonfinite)
        except (UnicodeError, RecursionError) as error:
            raise ValueError('bounded UTF-8 provider configuration required') from error
    finally:
        if file_fd is not None:
            os.close(file_fd)
        if directory_fd is not None:
            os.close(directory_fd)


def _check_ledger_location(path):
    """The sidecar directory and any existing ledger file must stay private."""
    try:
        info = os.stat(os.path.dirname(path), follow_symlinks=False)
    except OSError as error:
        raise ValueError('existing operator-owned provider ledger directory required') from error
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
        raise ValueError('existing operator-owned provider ledger directory required')
    if os.path.lexists(path):
        current = os.lstat(path)
        if (not stat.S_ISREG(current.st_mode) or current.st_nlink != 1
                or current.st_uid != os.geteuid() or current.st_mode & 0o077):
            raise ValueError('existing provider ledger must be a private single-link regular file')


def _ledger_path(value, canonical):
    """A dedicated SQLite sidecar directly inside one canonical root's v2 directory.

    Canonical stores live at the root itself and in their own subdirectories;
    the ``v2`` directory holds migration sidecars. The ledger must be a new
    ``*.sqlite3`` name there, never a root, a store, or a nested path.
    """
    path = _absolute(value)
    directory, name = os.path.split(path)
    if not _LEDGER_NAME.fullmatch(name):
        raise ValueError('dedicated sqlite3 provider ledger file name required')
    if directory not in {os.path.join(root, 'v2') for root in canonical}:
        raise ValueError('provider ledger must be a sidecar directly inside the canonical v2 directory')
    if path in canonical or any(os.path.commonpath((path, root)) == path for root in canonical):
        raise ValueError('provider ledger cannot be a canonical persistence root')
    _check_ledger_location(path)
    return path


def _budget(usd, cheapest_usd_per_million):
    """USD/day to frozen Limits; the token ceiling cannot admit more than the USD one."""
    from ..providers.budget import Limits
    micro = int(math.floor(usd * 1000000))
    if micro < 1:
        raise ValueError('positive provider budget required')
    # USD per million tokens equals micro-USD per token, so this many tokens at
    # the cheapest configured price already reaches the USD ceiling.
    tokens = int(math.ceil(micro / cheapest_usd_per_million))
    return Limits(tokens, tokens * _DAYS_PER_MONTH, micro, micro * _DAYS_PER_MONTH)


def _limits(value, cheapest):
    if type(value) is not dict or set(value) not in (_LIMITS, _LIMITS | {'reserve_usd'}):
        raise ValueError('exact provider budget limits required')
    total = _number(value['global_usd_per_day'], 0, _MAX_USD_PER_DAY)
    reserve = _number(value.get('reserve_usd', 0), 0, _MAX_USD_PER_DAY)
    daily = total - reserve
    if total <= 0 or daily <= 0:
        raise ValueError('positive daily provider budget after reserve required')
    per = value['per_capability_usd_per_day']
    if (type(per) is not dict or len(per) > len(_TEXT_CAPABILITIES)
            or any(key not in _TEXT_CAPABILITIES for key in per)):
        raise ValueError('per-capability budgets must name supported text capabilities')
    per_capability = []
    for key in sorted(per):
        usd = _number(per[key], 0, _MAX_USD_PER_DAY)
        if not 0 < usd <= daily:
            raise ValueError('per-capability budget must be positive and within the daily budget')
        per_capability.append((key, _budget(usd, cheapest)))
    return _budget(daily, cheapest), tuple(per_capability)


def _credential(environ, name):
    """Read the credential by NAME only; never log, derive or invent it."""
    key = environ.get(name)
    if (type(key) is not str or not key
            or any(ch.isspace() or not ch.isprintable() for ch in key)):
        return None
    return key


def _provider_row(row):
    if type(row) is not dict or set(row) not in (_PROVIDER, _PROVIDER | {'base_url'}):
        raise ValueError('exact provider specification required')
    if row['kind'] != 'openai' or row['provider_id'] != 'openai':
        # The OpenAI adapter's spec identity is fixed to "openai"; one hosted
        # provider of this kind can exist per policy. Other kinds are not wired.
        raise ValueError('kind openai requires the adapter identity openai')
    if 'base_url' in row and row['base_url'] != _BASE_URL:
        raise ValueError('only the fixed OpenAI API host is supported by the transport')
    if type(row['model']) is not str or not _MODEL_NAME.fullmatch(row['model']):
        raise ValueError('explicit bounded provider model required')
    if type(row['credential_env']) is not str or not _ENV_NAME.fullmatch(row['credential_env']):
        raise ValueError('credential_env must name an environment variable')
    pricing = row['pricing']
    if type(pricing) is not dict or set(pricing) != _PRICING:
        raise ValueError('exact provider pricing required')
    for key in _PRICING:
        if not _number(pricing[key], 0, _MAX_PRICE_USD_PER_MILLION) > 0:
            raise ValueError('positive metered provider prices required')
    bounds = row['bounds']
    if type(bounds) is not dict or set(bounds) != _BOUNDS:
        raise ValueError('exact provider full-call bounds required')
    _integer(bounds['max_input_tokens'], 256, 2000000)
    _integer(bounds['max_output_tokens'], 16, 32768)
    _number(bounds['max_call_seconds'], 1, 120)
    _reference(row['evidence_ref'], 256)
    verified = row['verified']
    if (type(verified) is not dict or set(verified) != _VERIFIED
            or any(type(flag) is not bool for flag in verified.values())):
        raise ValueError('explicit boolean provider verification markers required')
    return row


def load_provider_configuration(path, *, environ, canonical_roots, opener=None):
    """Load exact schema 1 into the installer's frozen typed configuration.

    ``environ`` supplies only the credential named by each ``credential_env``;
    a missing or empty value yields an unconfigured (unavailable) adapter, not
    an error and never an invented key. ``canonical_roots`` are the actual
    persistence roots (``state.v2_canonical_roots``); the ledger must be a
    dedicated SQLite sidecar directly inside one root's ``v2`` directory and
    is opened only by the returned factory. ``opener`` is the JSON transport's
    test seam; production leaves it None so the shared cancellable HTTP owner
    is used. No model, network, ledger or canonical store is touched here.
    """
    if not isinstance(environ, Mapping):
        raise ValueError('explicit environment mapping required')
    if type(canonical_roots) is not tuple or not 1 <= len(canonical_roots) <= 6:
        raise ValueError('actual canonical persistence roots required')
    canonical = tuple(_absolute(root) for root in canonical_roots)
    document = _private_json(path)
    if (type(document) is not dict or set(document) != _TOP
            or type(document['schema']) is not int or document['schema'] != 1):
        raise ValueError('exact provider configuration schema required')
    revision = _reference(document['policy_revision'], 128)
    remaining = _number(document['valid_until_wall'], 0, 2 ** 53) - time.time()
    if not 0 < remaining <= _MAX_VALIDITY_S:
        raise ValueError('finite future provider policy validity required')
    valid_until_mono = time.monotonic() + remaining
    providers = document['providers']
    if type(providers) is not list or not 1 <= len(providers) <= 16:
        raise ValueError('bounded explicit provider list required')
    declared = {}
    for row in providers:
        row = _provider_row(row)
        if row['provider_id'] in declared:
            raise ValueError('duplicate provider identity')
        declared[row['provider_id']] = row
    routes = document['routes']
    if type(routes) is not list or not 1 <= len(routes) <= 128:
        raise ValueError('bounded explicit route list required')
    from ..providers.base import Capability
    from .provider_runtime import RequestScope
    scopes, parsed_routes, capabilities = [], [], {}
    for row in routes:
        if type(row) is not dict or set(row) != _ROUTE:
            raise ValueError('exact provider route required')
        scope = RequestScope(_reference(row['site'], 256), _reference(row['group'], 256),
                             _reference(row['channel'], 256))
        if scope in scopes:
            raise ValueError('duplicate provider route scope')
        provider = declared.get(row['provider_id'])
        if provider is None:
            raise ValueError('route names an undeclared provider')
        names = row['capabilities']
        if (type(names) is not list or not 1 <= len(names) <= len(_TEXT_CAPABILITIES)
                or any(type(name) is not str or name not in _TEXT_CAPABILITIES for name in names)
                or len(set(names)) != len(names)):
            raise ValueError('route capabilities must be supported text capabilities only')
        limit = _integer(row['max_output_tokens'], 16, provider['bounds']['max_output_tokens'])
        if type(row['canary']) is not bool:
            raise ValueError('explicit boolean canary marker required')
        scopes.append(scope)
        capabilities.setdefault(row['provider_id'], set()).update(Capability(n) for n in names)
        parsed_routes.append((scope, row['provider_id'], tuple(Capability(n) for n in names),
                              limit, row['canary']))
    cheapest = min(min(row['pricing']['input_per_million_usd'], row['pricing']['output_per_million_usd'])
                   for row in declared.values())
    limits, per_capability = _limits(document['limits'], cheapest)
    ledger_path = _ledger_path(document['ledger_path'], canonical)
    from ..providers.http_transport import JsonTransport
    from ..providers.openai_adapter import OpenAIAdapter
    from .provider_hooks import ProviderHookConfig, ProviderRoute
    from .provider_runtime import ProviderPolicy, ProviderRule
    adapters, rules = [], []
    for provider_id, row in declared.items():
        caps = capabilities.get(provider_id)
        if not caps:
            raise ValueError('every declared provider needs at least one route')
        key = _credential(environ, row['credential_env'])
        transport = JsonTransport(_HOST, timeout_s=float(row['bounds']['max_call_seconds']),
                                  opener=opener)
        adapter = OpenAIAdapter(model=row['model'], api_key=key, enabled=key is not None,
                                transport=transport, capabilities=frozenset(caps), tier=1,
                                input_usd_per_million=float(row['pricing']['input_per_million_usd']),
                                output_usd_per_million=float(row['pricing']['output_per_million_usd']))
        verified = row['verified']
        rules.append(ProviderRule(adapter.spec, row['bounds']['max_input_tokens'],
            row['bounds']['max_output_tokens'], evidence_ref=row['evidence_ref'],
            valid_until_mono=valid_until_mono, billing_kind='metered',
            billing_verified=verified['billing'],
            full_call_bounds_verified=verified['full_call_bounds'],
            transport_cancel_verified=verified['transport_cancellation'],
            no_tools_verified=verified['no_tools'], tool_drain_verified=verified['tool_drain']))
        adapters.append(adapter)
    policy = ProviderPolicy(revision, tuple(rules), tuple(scopes), limits, per_capability)
    typed_routes = tuple(ProviderRoute(scope, provider_id, caps, limit, canary=canary)
                         for scope, provider_id, caps, limit, canary in parsed_routes)

    def ledger_factory():
        """Opened only by the enabled lifecycle tick; closed by hook retirement."""
        from ..providers.budget import BudgetLedger
        _check_ledger_location(ledger_path)
        if not os.path.lexists(ledger_path):
            os.close(os.open(ledger_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL
                             | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600))
        return BudgetLedger(policy.limits, per_capability=dict(policy.per_capability),
                            path=ledger_path)

    return ProviderHookConfig(policy, tuple(adapters), typed_routes, ledger_factory=ledger_factory)


def describe_provider_configuration(config):
    """Content-free summary for startup logs and the probe; never a credential."""
    return {'revision': config.policy.revision, 'routes': len(config.routes),
            'scopes': [[scope.site, scope.group, scope.channel] for scope in config.policy.scopes],
            'providers': [{'provider_id': adapter.spec.provider_id, 'model': adapter.spec.model,
                           'credential_present': adapter.configured is True}
                          for adapter in config.adapters]}
