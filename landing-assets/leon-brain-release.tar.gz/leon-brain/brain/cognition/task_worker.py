"""Bounded action workers subordinate to the existing executive.

No planning loop and no inference threads: the executive checkpoints tasks,
submits scheduler requests, then enqueues one explicitly authorized action.
Handlers may run concurrently only under distinct verified resource keys.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
import math
import threading
import time
from typing import Mapping

from .task_lifecycle import TaskStore


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    resources: tuple[str, ...]
    reason: str = "policy_denied"


@dataclass(frozen=True)
class ActionResult:
    outcome: str
    details: Mapping


class TaskWorker:
    """One lease, finite action threads, no automatic action retry.

    With two workers and max_background=1, one lane remains available for
    priority-100 work. Shared resources still serialize; this is not a promise
    to interrupt an external action. Policy must validate scope, authorization,
    tier and exact resource keys independently for EVERY action.
    """
    def __init__(self, store: TaskStore, *, handlers, policy, workers=2,
                 max_background=1, on_result=None, start_paused=False):
        if type(workers) is not int or not 1 <= workers <= 8:
            raise ValueError("workers")
        if type(max_background) is not int or not 1 <= max_background <= workers:
            raise ValueError("max background")
        if not callable(policy) or any(not callable(h) for h in handlers.values()):
            raise ValueError("policy and handlers must be callable")
        if type(start_paused) is not bool:
            raise ValueError("start_paused")
        self.store, self._handlers, self._policy = store, dict(handlers), policy
        self._workers, self._max_background = workers, max_background
        self._on_result = on_result
        self._control = threading.RLock()
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._drained = threading.Event()
        self._threads, self._lease = [], None
        self._remaining = 0
        self._started = False
        self._fault = None
        self._notification_errors = 0
        self._admission_ready = not start_paused

    def start(self):
        with self._control:
            if self._started or self._stop.is_set():
                raise RuntimeError("worker cannot start twice")
            self._lease = self.store.acquire_worker()
            self._started = True
            self._remaining = self._workers
            self._threads = [threading.Thread(target=self._loop, name=f"leon-task-{i}", daemon=True)
                             for i in range(self._workers)]
            started = 0
            try:
                for thread in self._threads:
                    thread.start()
                    started += 1
            except BaseException:
                self._remaining -= self._workers - started
                self._stop.set()
                if not started:
                    self._release()
                raise
        return self

    def release_startup(self):
        """Open a paused pool only after its owning runtime is ready.

        This gate precedes durable claim; waiting never denies an action or
        changes its receipt. A stopped pool can never reopen admission.
        """
        with self._control:
            if not self._started or self._stop.is_set():
                return False
            self._admission_ready = True
            self._wake.set()
            return True

    def notify(self):
        self._wake.set()

    def stop(self, timeout=5.0):
        if isinstance(timeout, bool) or not isinstance(timeout, (int,float)) or not math.isfinite(timeout) or timeout < 0:
            raise ValueError("timeout")
        deadline = time.monotonic() + timeout
        self._stop.set()
        self._wake.set()
        # A claim may be waiting for SQLite while holding _control. Include
        # that wait in the bound rather than blocking before the timer starts.
        if not self._control.acquire(timeout=timeout):
            return self._drained.is_set()
        try:
            if not self._started:
                return True
        finally:
            self._control.release()
        # Keep the lease and reference while handlers drain, even after timeout.
        return self._drained.wait(max(0.0, deadline - time.monotonic()))

    def _release(self):
        try:
            self._lease.close()
        except Exception as exc:
            # Persistence failure leaves RUNNING evidence and locks replacement.
            self._fault = self._fault or type(exc).__name__
            return
        self._drained.set()

    def _loop(self):
        try:
            while True:
                with self._control:
                    if self._stop.is_set():
                        return
                    action = (self.store.claim(self._lease, max_background=self._max_background)
                              if self._admission_ready else None)
                if action is None:
                    self._wake.wait(0.05)
                    self._wake.clear()
                    continue
                self._execute(action)
        except BaseException as exc:
            with self._control:
                self._fault = type(exc).__name__
                self._stop.set()
                self._wake.set()
        finally:
            with self._control:
                self._remaining -= 1
                if self._remaining == 0:
                    self._release()

    def _complete(self, action, outcome, details):
        try:
            self.store.finish(self._lease, action["action_id"], outcome, details)
        except (TypeError, ValueError, OverflowError):
            # An action ran but its malformed/oversized receipt cannot be saved.
            self.store.finish(self._lease, action["action_id"], "UNKNOWN",
                              {"reason":"unrepresentable_result","replay_allowed":False})
        self._wake.set()
        self._notify_result(action)

    def _notify_result(self, action):
        if self._on_result is not None:
            try:
                self._on_result(action["action_id"])
            except Exception:
                with self._control:
                    self._notification_errors += 1

    def _execute(self, action):
        handler = self._handlers.get(action["name"])
        if handler is None:
            self._complete(action, "FAILED", {"reason":"missing_handler","executed":False})
            return
        if action["tier"] == 4:
            self._complete(action, "FAILED", {"reason":"blocked_tier","executed":False})
            return
        task = self.store.get_task(action["task_id"])
        try:
            decision = self._policy(copy.deepcopy(action), copy.deepcopy(task))
        except Exception:
            self._complete(action, "FAILED", {"reason":"policy_error","executed":False})
            return
        try:
            valid = (isinstance(decision, PolicyDecision) and decision.allowed is True
                     and isinstance(decision.resources, tuple)
                     and tuple(sorted(set(decision.resources))) == tuple(action["resources"]))
        except (TypeError, ValueError):
            valid = False
        if not valid:
            self._complete(action, "FAILED", {"reason":"policy_denied_or_resource_mismatch","executed":False})
            return
        if not self.store.authorize_dispatch(self._lease, action["action_id"]):
            self._wake.set()
            self._notify_result(action)
            return
        try:
            # Fresh immutable-authority snapshots: a policy callback cannot edit
            # the action arguments that were durably approved and claimed.
            result = handler(self.store.get_action(action["action_id"]),
                             self.store.get_task(action["task_id"]))
            if isinstance(result, ActionResult):
                outcome, details = result.outcome, result.details
                if outcome not in ("SUCCEEDED","FAILED","UNKNOWN") or not isinstance(details, Mapping):
                    raise ValueError("invalid action result")
                if outcome == "SUCCEEDED" and details.get("ok") is False:
                    raise ValueError("contradictory result")
                if outcome != "UNKNOWN" and details.get("uncertain") is True:
                    raise ValueError("contradictory uncertainty")
            elif isinstance(result, Mapping):
                details = dict(result)
                if details.get("uncertain") is True:
                    outcome = "UNKNOWN"
                elif details.get("ok") is True:
                    outcome = "SUCCEEDED"
                elif details.get("ok") is False:
                    outcome = "FAILED"
                else:
                    raise ValueError("result must declare outcome")
            else:
                raise ValueError("invalid action result")
        except Exception as exc:
            outcome, details = "UNKNOWN", {"reason":"exception_after_dispatch",
                                           "error_type":type(exc).__name__,"replay_allowed":False}
        self._complete(action, outcome, details)

    def stats(self):
        with self._control:
            return {"started":self._started,"stopping":self._stop.is_set(),
                    "drained":self._drained.is_set(),"alive":sum(t.is_alive() for t in self._threads),
                    "fault":self._fault,"notification_errors":self._notification_errors,
                    "workers":self._workers,"max_background":self._max_background}
