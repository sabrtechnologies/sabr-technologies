"""Cold lifecycle and admitted-call bridge into the existing responder.

Root supplies reviewed policy/adapters and an existing scheduler. Only its
existing runtime tick reads live flags or creates a budget ledger. Calls carry
an exact worker/request/token capability through the existing recorder/context
wrapper; only the explicit no-tools transport branch can consume it.

Selection applies to no-tools requests only. A tool-bearing request in a
routed scope, and a no-tools request whose provider cannot dispatch right now
(credential, policy, budget, open breaker, owner not ready), is the unchanged
baseline and a content-free counter records why. Once a selected call has
consumed its transport scope it never falls back or replays; a failure there
opens the provider's breaker so the following turns are baseline.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
import importlib
import json
import math
import sys
import threading
import time

#: Explicit model/route override prefixes (brain.claude_api_responder
#: _strip_override_prefix). Any leading "/" keeps the legacy path.
OVERRIDE_PREFIXES = ("/cli", "/free", "/max", "/api", "/tools", "/zoom", "/turbo",
                     "/fast", "/haiku", "/think", "/smart", "/deep", "/opus")
_BASELINE_REASONS = ("tools", "not_ready", "credential", "policy", "budget", "breaker",
                     "merged", "oversize", "retiring")


def plain_text_turn(text):
    """True only for a plain conversation turn that needs no tool, action or override.

    Pure: it matches text against the existing recognisers and executes
    nothing (no reflex handler, actuator call, command tool, car command or
    model). Conservative: an override prefix, a relay/system marker, any tool,
    sensory, command, reflex or fast-path match, a missing recogniser, any
    exception or any doubt answers False, which keeps the legacy path with
    tools. A merged multi-line turn is plain only when every line is.
    """
    try:
        if type(text) is not str:
            return False
        whole = text.strip()
        if not whole or len(whole) > 4000 or "\x00" in whole:
            return False
        lowered = whole.lower()
        if "[tesla fast-path" in lowered or "[attached" in lowered:
            return False
        local = importlib.import_module("brain.local_llm")
        responder = importlib.import_module("brain.claude_api_responder")
        reflexes = importlib.import_module("brain.reflexes")
        # The dashboard imports the fast path before every turn. Where it is
        # not loaded it cannot fire; this predicate never imports it itself
        # (its import reads the vehicle configuration).
        fastpath = sys.modules.get("brain.integrations.tesla_fastpath")
        lines = [line.strip() for line in whole.splitlines() if line.strip()]
        for part in [whole] + (lines if len(lines) > 1 else []):
            start = part.lower()
            if start.startswith(OVERRIDE_PREFIXES) or start.startswith(("/", "[")):
                return False
            if local.should_use_tools(part) is not False:
                return False
            if responder._maybe_command_action(part) is not None:
                return False
            if reflexes.would_reflex(part) is not False:
                return False
            if fastpath is not None and fastpath.match(part) is not None:
                return False
        return True
    except Exception:
        return False


@dataclass(frozen=True)
class ProviderRoute:
    scope: object
    provider_id: str
    capabilities: tuple
    max_output_tokens: int
    canary: bool = False

    def __post_init__(self):
        object.__setattr__(self, "capabilities", tuple(self.capabilities))
        if (type(self.provider_id) is not str or not self.provider_id or len(self.provider_id) > 128
                or type(self.max_output_tokens) is not int or not 16 <= self.max_output_tokens <= 32768
                or type(self.canary) is not bool):
            raise ValueError("explicit bounded provider route required")


@dataclass(frozen=True)
class ProviderHookConfig:
    policy: object
    adapters: tuple
    routes: tuple
    ledger: object = field(default=None, repr=False)
    ledger_factory: object = field(default=None, repr=False)
    #: Seconds a provider stays unselected after one failed dispatched call.
    #: Trusted code only: the operator file loader never sets this field.
    breaker_cooldown_s: float = 120.0

    def __post_init__(self):
        object.__setattr__(self, "adapters", tuple(self.adapters))
        object.__setattr__(self, "routes", tuple(self.routes))
        if (not 1 <= len(self.adapters) <= 16 or not 1 <= len(self.routes) <= 128
                or any(type(route) is not ProviderRoute for route in self.routes)
                or (self.ledger is None) == (self.ledger_factory is None)
                or (self.ledger_factory is not None and not callable(self.ledger_factory))):
            raise ValueError("explicit bounded bindings and one ledger source required")
        if (type(self.breaker_cooldown_s) not in (int, float) or not math.isfinite(self.breaker_cooldown_s)
                or not 1 <= self.breaker_cooldown_s <= 3600):
            raise ValueError("bounded provider breaker cooldown required")


@dataclass(frozen=True, eq=False)
class _Submission:
    owner: object
    responder: object
    identity: tuple
    route: ProviderRoute


@dataclass(eq=False)
class _Call:
    request: object
    token: object
    responder: object
    route: ProviderRoute
    runtime: object
    identity: tuple
    thread: int
    used: bool = False
    released: bool = False
    completed: bool = False  # The routed transport exhausted and settled.
    declined: bool = False   # Given back unused before any transport call.


class ProviderHooks:
    def __init__(self, *, scheduler, config=None, configured_mode="off",
                 live_mode=lambda: "off", runtime_accepting=lambda: False, clock=None):
        if configured_mode not in {"off", "shadow", "canary", "on"}:
            raise ValueError("invalid provider mode")
        if config is not None and type(config) is not ProviderHookConfig:
            raise ValueError("trusted frozen ProviderHookConfig required")
        from ..providers.health import ROUTE_BREAKER_COOLDOWN_S, route_breaker
        # One passive breaker for the hooks' lifetime, shared with every
        # router this owner builds. clock is a trusted test seam.
        self._health = route_breaker(
            cooldown_s=config.breaker_cooldown_s if config is not None else ROUTE_BREAKER_COOLDOWN_S,
            clock=clock or time.monotonic)
        self._scheduler, self._config = scheduler, config
        self._configured, self._live, self._accepting = configured_mode, live_mode, runtime_accepting
        self._lifecycle, self._lock = threading.Lock(), threading.RLock()
        self._call = ContextVar("leon_provider_admitted_call", default=None)
        self._runtime = self._ledger = None
        self._owns_ledger = False
        self._mode = "off"
        self._requested = "off"
        self._requested_routes = {}
        self._stopping = False
        self._frames = set()
        self._routes = {}
        self._reason = "off"
        self._counts = {"selected": 0, "baseline": 0, "transport": 0, "failed": 0,
                        "breaker_opened": 0}
        # Why a routed scope stayed on (or returned to) its baseline. Content-free.
        self._baseline = dict.fromkeys(_BASELINE_REASONS, 0)

    def _validate(self):
        from .inference_scheduler import InferenceScheduler
        from .provider_runtime import ProviderPolicy, ProviderRuntime, RequestScope
        from ..providers.base import Capability, UnsupportedPolicy
        config = self._config
        if (config is None or type(config.policy) is not ProviderPolicy
                or not isinstance(self._scheduler, InferenceScheduler)):
            raise UnsupportedPolicy("verified provider configuration unavailable")
        specs = {r.spec.provider_id: r.spec for r in config.policy.rules}
        adapters = {a.spec.provider_id: a for a in config.adapters}
        if len(adapters) != len(config.adapters):
            raise UnsupportedPolicy("duplicate adapter binding")
        routes = {}
        review = ProviderRuntime(policy=config.policy)
        for route in config.routes:
            key = (getattr(route.scope, "site", None), getattr(route.scope, "group", None),
                   getattr(route.scope, "channel", None))
            adapter = adapters.get(route.provider_id)
            caps = frozenset(Capability(c) for c in route.capabilities)
            if (type(route.scope) is not RequestScope or route.scope not in config.policy.scopes
                    or key in routes or adapter is None
                    or adapter.spec != specs.get(route.provider_id)
                    or getattr(adapter, "accepts_prepared_messages", False) is not True
                    or not caps or not caps <= {Capability.FAST_LANGUAGE, Capability.CODING, Capability.DEEP_REASONING}
                    or not caps <= adapter.spec.capabilities):
                raise UnsupportedPolicy("route lacks verified prepared-message text binding")
            review._rule(route.provider_id, False)
            routes[key] = route
        return routes

    def tick(self):
        """Existing lifecycle thread only; callbacks may do controlled flag I/O."""
        if not self._lifecycle.acquire(False):
            return self.stats()
        try:
            target = "off"
            if not self._stopping and self._configured != "off":
                try:
                    live = self._live()
                    if self._accepting() and live in {"shadow", "canary", "on"}:
                        target = ("shadow" if "shadow" in (self._configured, live)
                                  else "canary" if "canary" in (self._configured, live) else "on")
                except Exception:
                    self._reason = "lifecycle_unavailable"
            requested_routes = {}
            if target in {"canary", "on"} and self._config is not None:
                from .provider_runtime import RequestScope
                requested_routes = {(r.scope.site, r.scope.group, r.scope.channel): r
                    for r in self._config.routes if type(r.scope) is RequestScope}
            # Publish route authority together: a concurrent request must not
            # see an enabled mode paired with a transiently empty allowlist.
            with self._lock:
                if self._stopping:
                    # Retirement is not permission to select the baseline.
                    # Retain the last operator-selected scopes until detach.
                    target = "off"
                else:
                    self._requested, self._requested_routes = target, requested_routes
            if ((self._runtime is not None and (target != self._runtime.mode or self._mode == "off"))
                    or (self._runtime is None and self._ledger is not None)):
                self._mode = "off"
                if not self._retire():
                    self._reason = "draining"
                    return self.stats()
            if target not in {"canary", "on"}:
                self._mode, self._reason = target, target
                return self.stats()
            if self._runtime is None:
                from .provider_runtime import ProviderRuntime
                try:
                    routes = self._validate()
                    if self._stopping:
                        self._mode, self._reason = "off", "retiring"
                        return self.stats()
                    config = self._config
                    ledger = config.ledger if config.ledger is not None else config.ledger_factory()
                    self._ledger, self._owns_ledger = ledger, config.ledger is None
                    owner = ProviderRuntime(policy=config.policy, adapters=config.adapters,
                                            ledger=ledger, mode=target, health=self._health)
                    self._runtime = owner
                    owner._check_budget()
                    if not owner.install(self._scheduler):
                        raise RuntimeError("scheduler provider owner is still bound")
                    self._routes = routes
                except Exception:
                    self._counts["failed"] += 1
                    self._mode, self._reason = "off", "configuration_unavailable"
                    self._retire()
                    return self.stats()
            if self._stopping:
                self._mode, self._reason = "off", "retiring"
                self._retire()
                return self.stats()
            self._mode, self._reason = target, "ready"
            return self.stats()
        finally:
            self._lifecycle.release()

    def _retire(self):
        with self._lock:
            frames = tuple(self._frames)
        for frame in frames:
            frame.token.cancel("provider_hooks_retired")
        if self._runtime is not None:
            if not self._runtime.stop() or frames:
                return False
            # A failed install owns no registry slot and must not release another.
            if self._runtime.stats()["installed"] and not self._runtime.uninstall():
                return False
            self._runtime = None
        if self._owns_ledger and self._ledger is not None:
            try:
                self._ledger.close()
            except Exception:
                self._reason = "ledger_close_pending"
                return False
        self._ledger, self._owns_ledger = None, False
        self._routes = {}
        return not frames

    @staticmethod
    def _identity(req):
        return (req.request_id, req.trace_id, req.site, req.group, req.channel,
                req.allow_tools, req.persist_history, req.deadline_mono, req.kind)

    def _admitted(self, request, token):
        from . import inference_scheduler
        active = getattr(self._scheduler, "_active", None)
        return (threading.current_thread() is getattr(self._scheduler, "_thread", None)
                and inference_scheduler.in_worker_context() and active is not None
                and active.req is request and active.token is token and active.state == "running")

    def _selected_route(self, site, group, channel):
        """Cached operator route for this exact scope under the live mode; lock held."""
        key = (site, group, channel)
        route = self._requested_routes.get(key) if (all(type(v) is str for v in key)
            and self._requested in {"canary", "on"}) else None
        if route is None or (self._requested == "canary" and not route.canary):
            return None
        return route

    def _unavailable(self, route):
        """Why this route cannot dispatch right now, else None; lock held.

        Cached owner state and one read-only budget preview. Reserves nothing.
        """
        runtime = self._runtime
        if runtime is None or self._mode not in {"canary", "on"}:
            return "not_ready"
        try:
            return runtime.unavailable(route.provider_id, route.capabilities)
        except Exception:
            return "not_ready"

    def _note_baseline(self, reason):
        self._baseline[reason if reason in self._baseline else "not_ready"] += 1

    @staticmethod
    def _keep_local(request, kwargs):
        """A foreground turn is submitted without tools only to be routed. When
        it cannot be, it is answered on the local no-tools transport, never on
        another hosted or paid lane. Other callers keep their own baseline."""
        if request.channel == "user" and type(kwargs) is dict:
            kwargs["prefer_local"] = True

    def capture_submission(self, request, *, responder):
        """Cached route authority before admission; no flag reads, nothing reserved.

        Only a no-tools request can be selected. A tool-bearing request in a
        routed scope and a route that cannot dispatch right now are baseline
        (None). A retiring owner keeps its selected no-tools scopes terminal.
        """
        return self._capture(request, responder, note=True)

    def _capture(self, request, responder, *, note):
        with self._lock:
            route = self._selected_route(request.site, request.group, request.channel)
            if route is None:
                return None
            reason = "tools" if request.allow_tools else (
                None if self._stopping else self._unavailable(route))
            if reason is not None:
                if note:
                    self._note_baseline(reason)
                return None
            return _Submission(self, responder, self._identity(request), route)

    def selects_plain_turn(self, text, *, site, group, channel):
        """Would a no-tools request in this exact scope be selected and dispatchable
        right now, and is ``text`` a plain conversation turn?

        The foreground consumers ask this before submitting; only True makes
        them submit without tools. Never raises; any doubt answers False, which
        is the unchanged tool-bearing legacy request. Off/shadow, an unrouted
        scope and a non-canary route under canary answer False before the
        text is examined.
        """
        try:
            with self._lock:
                route = self._selected_route(site, group, channel)
            if route is None or not plain_text_turn(text):
                return False
            with self._lock:
                if self._selected_route(site, group, channel) is not route:
                    return False
                reason = "retiring" if self._stopping else self._unavailable(route)
                if reason is not None:
                    self._note_baseline(reason)
                    return False
                return True
        except Exception:
            return False

    def requires_admission(self, group, channel=None):
        """Keep a retiring scheduler reachable only for cached selected groups.

        Scheduler channels are user/daemon; the routing facade's voice/wake
        labels both map to user. Exact site selection still happens at submit.
        """
        with self._lock:
            selected = self._requested in {"canary", "on"}
            actual_channel = "user" if channel in {"voice", "wake"} else channel
            return selected and any(key[1] == group and (actual_channel is None or key[2] == actual_channel)
                and (self._requested != "canary" or route.canary)
                for key, route in self._requested_routes.items())

    @contextmanager
    def admitted(self, request, prompt, kwargs, token, *, responder, submission=None):
        """Called by actual responder_provider; never probes config/flags.

        Identity, admission, retirement and operator-revocation violations stay
        terminal. A selected submission whose provider became unavailable
        before dispatch (or whose admitted text is no longer plain after a
        newest-wins merge) runs the caller's no-tools baseline instead; a
        foreground turn stays on the local transport. A call that consumed its
        transport scope and did not complete opens the provider's breaker; it
        is never replayed.
        """
        from ..providers.base import Cancelled, Unavailable, UnsupportedPolicy, check_cancel
        frame = None
        merged_plain = True
        if submission is not None and prompt != request.prompt:
            merged_plain = plain_text_turn(prompt)
        with self._lock:
            # The submit-time capture already recorded why a routed scope is baseline.
            captured = submission or self._capture(request, responder, note=False)
            if captured is not None:
                if (type(captured) is not _Submission or captured.owner is not self
                        or captured.responder is not responder or captured.identity != self._identity(request)):
                    raise UnsupportedPolicy("provider submission identity changed")
                route = captured.route
                key = (request.site, request.group, request.channel)
                if self._stopping or self._requested_routes.get(key) is not route:
                    raise Unavailable("selected provider configuration or lifecycle unavailable")
                if (not self._admitted(request, token) or self._call.get() is not None
                        or request.allow_tools or len(self._frames) >= 1):
                    raise UnsupportedPolicy("provider routing requires this admitted no-tools call")
                check_cancel(token, request.deadline_mono)
                reason = self._unavailable(route) if merged_plain else "merged"
                if reason is None:
                    frame = _Call(request, token, responder, route, self._runtime,
                                  self._identity(request), threading.get_ident())
                    self._frames.add(frame)
                    self._counts["selected"] += 1
                else:
                    # Nothing was dispatched: the caller's no-tools baseline.
                    self._note_baseline(reason)
                    self._counts["baseline"] += 1
                    self._keep_local(request, kwargs)
            else:
                self._counts["baseline"] += 1
                if not request.allow_tools and self._selected_route(
                        request.site, request.group, request.channel) is not None:
                    # Routed scope, provider unavailable since before submission.
                    self._keep_local(request, kwargs)
        context = self._call.set(frame)
        error = None
        try:
            yield
        except BaseException as exc:
            error = exc
            raise
        finally:
            self._call.reset(context)
            if frame is not None:
                with self._lock:
                    frame.released = True
                    self._frames.discard(frame)
                    failed = (frame.used and not frame.completed and not frame.declined
                              and not token.is_set()
                              and not isinstance(error, (Cancelled, GeneratorExit)))
                    if failed:
                        # Terminal for this turn; following turns are baseline
                        # until the cooldown passes. Idempotent with the router.
                        self._counts["breaker_opened"] += 1
                        if self._health.available(frame.route.provider_id):
                            self._health.failure(frame.route.provider_id)

    def selection(self, *, responder, cancel_token):
        """Cold branch probe used by _respond_text_only, with no external reads."""
        frame = self._call.get()
        if frame is None:
            return None
        from ..providers.base import UnsupportedPolicy
        if (frame.released or frame.responder is not responder or frame.token is not cancel_token
                or frame.thread != threading.get_ident()
                or self._identity(frame.request) != frame.identity
                or not self._admitted(frame.request, cancel_token)):
            raise UnsupportedPolicy("foreign provider transport scope")
        return frame

    def fits(self, selection, *, system, messages):
        """Would transport() accept this rendered context? Pure size check, same bounds."""
        try:
            if type(system) is not str or type(messages) is not list or not messages:
                return False
            rule = next(rule for rule in selection.runtime.policy.rules
                        if rule.spec.provider_id == selection.route.provider_id)
            size = len(json.dumps(messages, ensure_ascii=False, allow_nan=False).encode("utf-8"))
            return size <= 60000 and size + len(system.encode("utf-8")) + 1024 <= rule.input_token_bound
        except Exception:
            return False

    def decline(self, selection, *, responder, cancel_token):
        """Give the unused scope back before any transport call.

        The caller's rendered context cannot fit the reviewed input bound, so
        it continues on its own no-tools baseline. The scope is consumed (it
        can never transport) and the route backs off for one cooldown, so the
        following turns are decided at submission and keep the legacy path.
        """
        from ..providers.base import UnsupportedPolicy
        frame = self.selection(responder=responder, cancel_token=cancel_token)
        if frame is None or selection is not frame or frame.used:
            raise UnsupportedPolicy("provider transport scope already used or absent")
        frame.used = frame.declined = True
        with self._lock:
            self._note_baseline("oversize")
            self._health.failure(frame.route.provider_id)

    def transport(self, selection, *, responder, prompt, system, messages, cancel_token):
        """Consume the exact scope once, after existing context/history rendering."""
        from ..providers.base import UnsupportedPolicy, check_cancel
        frame = self.selection(responder=responder, cancel_token=cancel_token)
        if frame is None or selection is not frame or frame.used:
            raise UnsupportedPolicy("provider transport scope already used or absent")
        frame.used = True
        check_cancel(cancel_token, frame.request.deadline_mono)
        if self._mode not in {"on", "canary"} or self._stopping or frame.runtime is not self._runtime:
            raise UnsupportedPolicy("provider owner is retiring")
        if type(prompt) is not str or type(system) is not str or type(messages) is not list:
            raise UnsupportedPolicy("prepared responder messages required")
        try:
            snapshot = json.dumps(messages, ensure_ascii=False, allow_nan=False)
            if len(snapshot.encode("utf-8")) > 60000:
                raise ValueError("prepared messages exceed bound")
            prepared = json.loads(snapshot)
        except (TypeError, ValueError):
            raise UnsupportedPolicy("prepared messages are not bounded JSON") from None
        options = {"prepared_messages": prepared, "channel": frame.request.channel,
                   "persist_history": frame.request.persist_history}
        route = frame.route
        rule = next(rule for rule in frame.runtime.policy.rules if rule.spec.provider_id == route.provider_id)
        if len(snapshot.encode("utf-8")) + len(system.encode("utf-8")) + 1024 > rule.input_token_bound:
            raise UnsupportedPolicy("prepared messages exceed approved full-call input bound")
        callback = frame.runtime.provider_for(frame.request, provider_id=route.provider_id,
            capabilities=route.capabilities, context=system, max_output_tokens=route.max_output_tokens,
            legacy_kwargs=options)
        self._counts["transport"] += 1
        yield from callback(frame.request, prompt, options, cancel_token)
        frame.completed = True

    def quiesce(self):
        with self._lock:
            self._stopping, self._mode = True, "off"

    def stop(self, timeout=0):
        """Nonblocking retirement; timeout is accepted for lifecycle uniformity."""
        self.quiesce()
        if not self._lifecycle.acquire(False):
            return False
        try:
            return self._retire()
        finally:
            self._lifecycle.release()

    @property
    def retired(self):
        return self._stopping and not self._frames and self._runtime is None and self._ledger is None

    def stats(self):
        return {"mode": self._mode, "reason": self._reason, "retired": self.retired,
                "active": len(self._frames), "installed": self._runtime is not None,
                "metadata_only": True, **self._counts,
                "baseline_reasons": dict(self._baseline)}
