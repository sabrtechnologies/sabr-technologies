"""
Phase 15 — Multi-provider resilience.

Claude is and remains Leon's primary language/reasoning cortex. This module
adds a SMALL fallback layer so Leon stays operational if Claude is
degraded, rate-limited, deprecated, or temporarily dead.

Design constraint (Dean's mandate): no big provider framework, no replacement
of Claude. Just enough to:

  1. Track per-provider health (alive / degraded / dead).
  2. Decide which provider should serve a given request based on
     strategy + provider availability.
  3. Expose a probe so the responder can ask "is Claude warm?" and
     fall back to local LLM only on confirmed failure.

The actual provider invocations stay in their respective modules
(`brain.claude_api_responder` for Claude CLI/API,
 `brain.local_llm` for Ollama). This module only TRACKS and ROUTES,
it does not own provider implementations.

Health states per provider:
  warm       — recent successful call within last 5 min
  cold       — has been called before but not recently (lazy)
  degraded   — recent failure or high latency
  dead       — multiple consecutive failures
  disabled   — not configured / env says off

Storage: in-memory only. State resets on process restart.
"""

from __future__ import annotations

import logging
import os
import socket
import threading
import time
import urllib.request
from dataclasses import dataclass, asdict, field
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("leon.cognition.providers")


STATUS_WARM      = "warm"
STATUS_COLD      = "cold"
STATUS_DEGRADED  = "degraded"
STATUS_DEAD      = "dead"
STATUS_DISABLED  = "disabled"


@dataclass
class ProviderState:
    name: str
    status: str = STATUS_COLD
    last_success_ts: Optional[float] = None
    last_failure_ts: Optional[float] = None
    last_failure_reason: Optional[str] = None
    consecutive_failures: int = 0
    calls_total: int = 0
    successes_total: int = 0
    avg_latency_ms: float = 0.0
    capabilities: List[str] = field(default_factory=list)  # e.g. ["chat","reasoning","fast"]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ProviderRegistry:
    """Tracks the health of every provider Leon can route through.

    Currently:
      • claude     — claude_api_responder.get_persistent_session().alive()
      • ollama     — local_llm.is_available()
      • (reserved) — slots for future providers (gemini/mistral) when added
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._providers: Dict[str, ProviderState] = {}
        # Built-ins
        self.register("claude", capabilities=["chat", "reasoning", "deep"])
        self.register("ollama", capabilities=["chat", "fast", "fallback"])
        # Env toggle to wire fallback at all
        self._fallback_enabled = os.environ.get(
            "LEON_FALLBACK_PROVIDER", ""
        ).strip().lower() not in ("", "off", "0", "false")

    # -- registration --------------------------------------------------

    def register(self, name: str, *, capabilities: Optional[List[str]] = None) -> None:
        with self._lock:
            if name in self._providers:
                return
            self._providers[name] = ProviderState(
                name=name, capabilities=capabilities or [],
            )

    # -- health updates ------------------------------------------------

    def mark_success(self, name: str, *, latency_ms: float = 0.0) -> None:
        with self._lock:
            p = self._providers.get(name)
            if p is None: return
            p.calls_total += 1
            p.successes_total += 1
            p.consecutive_failures = 0
            p.last_success_ts = time.time()
            if latency_ms > 0:
                # rolling avg toward latest
                p.avg_latency_ms = (p.avg_latency_ms * 0.7 + latency_ms * 0.3) \
                    if p.avg_latency_ms else latency_ms
            p.status = STATUS_WARM

    def mark_failure(self, name: str, *, reason: str = "") -> None:
        with self._lock:
            p = self._providers.get(name)
            if p is None: return
            p.calls_total += 1
            p.consecutive_failures += 1
            p.last_failure_ts = time.time()
            p.last_failure_reason = (reason or "")[:200]
            if p.consecutive_failures >= 3:
                p.status = STATUS_DEAD
            else:
                p.status = STATUS_DEGRADED

    def probe(self, name: str) -> str:
        """Run a lightweight liveness probe. Updates status in-place.
        Returns the new status."""
        if name == "claude":
            return self._probe_claude()
        if name == "ollama":
            return self._probe_ollama()
        return self.status_of(name)

    # -- queries -------------------------------------------------------

    def status_of(self, name: str) -> str:
        with self._lock:
            p = self._providers.get(name)
            if p is None: return STATUS_DISABLED
            # Cool warm → cold after 5 minutes
            if p.status == STATUS_WARM and p.last_success_ts \
                    and (time.time() - p.last_success_ts) > 300:
                p.status = STATUS_COLD
            return p.status

    def state(self, name: str) -> Optional[ProviderState]:
        with self._lock:
            return self._providers.get(name)

    def all(self) -> Dict[str, Dict[str, Any]]:
        with self._lock:
            return {name: p.to_dict() for name, p in self._providers.items()}

    def fallback_enabled(self) -> bool:
        return self._fallback_enabled

    def pick_provider(self, *, prefer: str = "claude",
                       capabilities: Optional[List[str]] = None) -> str:
        """Pick a provider for a request.

        Default: return `prefer` (claude) unless it's DEAD/DISABLED.
        If fallback is enabled and prefer is unhealthy, return the first
        alternative whose capabilities cover the requirement.
        """
        st = self.status_of(prefer)
        if st in (STATUS_WARM, STATUS_COLD, STATUS_DEGRADED):
            return prefer
        if not self._fallback_enabled:
            return prefer  # caller will fail; that's intended
        # Pick alternative
        with self._lock:
            for name, p in self._providers.items():
                if name == prefer: continue
                if p.status in (STATUS_DEAD, STATUS_DISABLED):
                    continue
                if capabilities and not (set(capabilities) & set(p.capabilities)):
                    continue
                return name
        return prefer  # nothing better; let it fail

    # -- probes --------------------------------------------------------

    def _probe_claude(self) -> str:
        try:
            from brain import claude_api_responder as r
            sessions = getattr(r, "_LEON_SESSIONS", None)
            if isinstance(sessions, dict):
                started = [v for v in sessions.values() if v is not None]
                if not started:
                    # Not started yet — neutral cold
                    with self._lock:
                        self._providers["claude"].status = STATUS_COLD
                    return STATUS_COLD
                alive = any(bool(getattr(s, "alive", lambda: False)())
                            for s in started)
            else:
                sess = getattr(r, "_LEON_SESSION", None)
                if sess is None:
                    with self._lock:
                        self._providers["claude"].status = STATUS_COLD
                    return STATUS_COLD
                alive = bool(getattr(sess, "alive", lambda: False)())
            if alive:
                self.mark_success("claude")
                return STATUS_WARM
            else:
                self.mark_failure("claude", reason="persistent session dead")
                return self.status_of("claude")
        except Exception as e:
            self.mark_failure("claude", reason=str(e))
            return self.status_of("claude")

    def _probe_ollama(self) -> str:
        try:
            with socket.create_connection(("127.0.0.1", 11434), timeout=0.6):
                self.mark_success("ollama")
                return STATUS_WARM
        except Exception as e:
            with self._lock:
                # Don't penalize hard — Ollama is optional
                p = self._providers["ollama"]
                if p.calls_total == 0:
                    p.status = STATUS_DISABLED
                else:
                    self.mark_failure("ollama", reason=str(e))
            return self.status_of("ollama")


__all__ = [
    "ProviderRegistry", "ProviderState",
    "STATUS_WARM", "STATUS_COLD", "STATUS_DEGRADED",
    "STATUS_DEAD", "STATUS_DISABLED",
]
