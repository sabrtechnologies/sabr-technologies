"""Durable operator approvals for the installed supervised planner.

This is trusted executive infrastructure, never a model tool. It shares the
existing task registry connection and opens no DB, worker or external service.
"""
from contextlib import contextmanager
from dataclasses import asdict
import json
import math
import os
import re

from .task_planner import PlannerDenied, _digest, _json
from .task_planner_ingress import PlanScope, PlanStepApproval, PlannerIngress, _scope
from .task_project_actions import _open_absolute, _identity


class AuthorityDenied(PlannerDenied):
    pass


class AuthorityConflict(AuthorityDenied):
    pass


class AuthorityCapacity(AuthorityDenied):
    pass


_HEX = re.compile(r'[0-9a-f]{64}\Z')
_SCHEMA = '''
CREATE TABLE IF NOT EXISTS planner_operator_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS planner_operator_scopes(
 binding_sha256 TEXT PRIMARY KEY,scope TEXT NOT NULL,scope_json TEXT NOT NULL,
 configuration_sha256 TEXT NOT NULL,created_wall REAL NOT NULL);
CREATE TABLE IF NOT EXISTS planner_operator_approvals(
 approval_ref TEXT PRIMARY KEY,submission TEXT UNIQUE NOT NULL,principal TEXT NOT NULL,
 parent_id TEXT NOT NULL,project_scope TEXT NOT NULL,proposal_sha256 TEXT NOT NULL,
 review_sha256 TEXT NOT NULL,fingerprint TEXT NOT NULL,binding_sha256 TEXT NOT NULL,
 validity_s INTEGER NOT NULL,issued_wall REAL NOT NULL,expires_wall REAL NOT NULL,
 revoked_wall REAL,UNIQUE(parent_id,proposal_sha256));
'''


def _text(value, limit=200):
    if (type(value) is not str or not value.strip() or len(value.encode('utf-8')) > limit
            or any(ord(c) < 32 for c in value)):
        raise AuthorityDenied('bounded identifier required')
    return value


class PlannerAuthority:
    def __init__(self, runtime, scopes, *, enabled=lambda: False,
                 max_approvals=1024, max_validity_s=900):
        if type(scopes) is not tuple or not 1 <= len(scopes) <= 16:
            raise ValueError('explicit bounded startup scope tuple required')
        selected = {}
        for scope in scopes:
            if type(scope) is not PlanScope:
                raise ValueError('typed startup PlanScope required')
            _scope(scope, scope.project_scope)
            if scope.project_scope in selected:
                raise ValueError('duplicate configured scope')
            if (set(scope.allowed_actions).intersection(('project.read_text', 'project.replace_text'))
                    and not scope.allowed_paths):
                raise ValueError('file actions require explicit paths')
            if 'project.run_check' in scope.allowed_actions and not scope.allowed_checks:
                raise ValueError('check action requires explicit names')
            selected[scope.project_scope] = scope
        if (not callable(enabled) or type(max_approvals) is not int or not 1 <= max_approvals <= 2048
                or type(max_validity_s) is not int or not 1 <= max_validity_s <= 900):
            raise ValueError('bounded operator authority configuration required')
        self.runtime, self._scopes, self._enabled = runtime, selected, enabled
        self._max_approvals, self._max_validity = max_approvals, max_validity_s
        self._prepared, self._bindings, self._ingress = False, {}, None

    @property
    def db(self):
        return self.runtime._registry

    @property
    def store(self):
        return self.runtime._store

    def _now(self):
        now = self.runtime._clock()
        if type(now) not in (int, float) or not math.isfinite(now):
            raise AuthorityDenied('finite clock required')
        return now

    def _configuration(self, scope):
        """Local configured metadata/directory identity only; never preview RPC."""
        backend = self.runtime._backend
        specs = []
        for path in scope.allowed_paths:
            specs.append(backend.canonical_resource_spec('project.read_text', {'path': path},
                                                         {'project_scope': scope.project_scope}))
        for check in scope.allowed_checks:
            specs.append(backend.canonical_resource_spec('project.run_check', {'check': check},
                                                         {'project_scope': scope.project_scope}))
        if not specs or len({spec.configuration_sha256 for spec in specs}) != 1:
            raise AuthorityDenied('actual configured workspace required')
        spec = specs[0]
        workspace = backend._workspaces[scope.project_scope][0]
        fd = _open_absolute(workspace.root)
        try:
            if _identity(os.fstat(fd)) != spec.root_identity:
                raise AuthorityDenied('configured workspace identity changed')
        finally:
            os.close(fd)
        payload = {'scope': asdict(scope), 'configuration_sha256': spec.configuration_sha256,
                   'root_identity': spec.root_identity}
        return _digest(payload), spec.configuration_sha256

    def prepare(self):
        """Cold root startup: existing registry/backend only, before workers."""
        with self.runtime._lock:
            if self.runtime._stopping or self.db is None or self.store is None or self.runtime._backend is None:
                raise AuthorityDenied('existing task owner required')
            with self.store._lock:
                bindings = {key: self._configuration(scope) for key, scope in self._scopes.items()}
                self.db.executescript(_SCHEMA)
                config = _json([1, self._max_approvals, self._max_validity])
                old = self.db.execute("SELECT value FROM planner_operator_meta WHERE key='config'").fetchone()
                if old is not None and old[0] != config:
                    raise AuthorityConflict('retained authority limits differ')
                missing = [(key, binding, configuration) for key, (binding, configuration) in bindings.items()
                           if not self.db.execute('SELECT 1 FROM planner_operator_scopes WHERE binding_sha256=?', (binding,)).fetchone()]
                if self.db.execute('SELECT count(*) FROM planner_operator_scopes').fetchone()[0] + len(missing) > 256:
                    raise AuthorityCapacity('retained scope binding quota exhausted')
                self.db.execute("INSERT OR IGNORE INTO planner_operator_meta VALUES ('config',?)", (config,))
                for key, binding, configuration in missing:
                    self.db.execute('INSERT INTO planner_operator_scopes VALUES (?,?,?,?,?)',
                                    (binding, key, _json(asdict(self._scopes[key])), configuration, self._now()))
                self._bindings = bindings
                self._prepared = True
        return self

    def bind_ingress(self, ingress):
        with self.runtime._lock:
            if (not self._prepared or type(ingress) is not PlannerIngress or ingress.runtime is not self.runtime
                    or not ingress._prepared or self.runtime._stopping):
                raise AuthorityDenied('exact prepared ingress owner required')
            if self._ingress is not None and self._ingress is not ingress:
                raise AuthorityConflict('authority already bound to another ingress')
            self._ingress = ingress
        return self

    @contextmanager
    def _locked(self, principal):
        # Also called by ingress while it holds these same reentrant locks.
        # Do not inspect worker health or invoke ingress here (lock inversion).
        with self.runtime._access(principal):
            if not self._prepared or not self.store._lock.acquire(timeout=.25):
                raise AuthorityDenied('operator authority unavailable or busy')
            try:
                yield
            finally:
                self.store._lock.release()

    def _selected(self):
        # Injected selector is a pure flag/owner predicate, never health/RPC.
        if self._enabled() is not True or self.runtime._stopping:
            raise AuthorityDenied('operator approval admission disabled')

    def _current_scope(self, scope_id):
        scope = self._scopes.get(scope_id)
        if scope is None or self._configuration(scope) != self._bindings.get(scope_id):
            raise AuthorityDenied('startup scope or workspace configuration changed')
        return scope

    def resolve_scope(self, principal, scope):
        """Trusted ingress callback: fixed startup permissions, never inferred."""
        try:
            with self._locked(principal):
                self._selected()
                return self._current_scope(scope)
        except Exception:
            return None

    @staticmethod
    def _receipt(row):
        return PlanStepApproval(row['principal'], row['parent_id'], row['project_scope'],
            row['proposal_sha256'], row['approval_ref'], row['issued_wall'], row['expires_wall'],
            row['revoked_wall'] is not None)

    def resolve_approval(self, approval_ref):
        """Current internal authority callback; historical lookup is separate."""
        try:
            with self._locked(self.runtime._principal):
                self._selected()
                row = self.db.execute('SELECT * FROM planner_operator_approvals WHERE approval_ref=?',
                                      (_text(approval_ref),)).fetchone()
                if row is None or row['principal'] != self.runtime._principal:
                    return None
                scope = self._current_scope(row['project_scope'])
                if self._bindings[scope.project_scope][0] != row['binding_sha256']:
                    return None
                return self._receipt(row)
        except Exception:
            return None

    def lookup(self, approval_ref, *, principal):
        """Authenticated historical receipt; no renewal or active effects."""
        with self._locked(principal):
            row = self.db.execute('SELECT * FROM planner_operator_approvals WHERE approval_ref=? AND principal=?',
                                  (_text(approval_ref), principal)).fetchone()
            return None if row is None else self._receipt(row)

    def _active_context(self, task_id, principal):
        # This ingress call reads worker health, so it must precede our store lock.
        with self.runtime._access(principal):
            if self._ingress is None:
                raise AuthorityDenied('operator authority is not bound')
        return self._ingress.require_active_parent(task_id, principal=principal)

    def _review_locked(self, task_id, context):
        self._selected()
        row, actual, parent = self._ingress._plan(task_id)
        if (actual != context or row['revoked_wall'] is not None or parent['cancel_requested']
                or parent['state'] not in ('READY', 'PAUSED')
                or not context.issued_wall <= self._now() < context.deadline_wall):
            raise AuthorityDenied('active parent registration changed')
        scope = self._current_scope(context.project_scope)
        if (scope.allowed_actions != context.allowed_actions or scope.allowed_paths != context.allowed_paths
                or scope.allowed_checks != context.allowed_checks or scope.max_steps != context.max_steps
                or scope.max_rounds != context.max_rounds or scope.authorization_revision != context.authorization_revision
                or scope.lifetime_s != context.deadline_wall-context.issued_wall):
            raise AuthorityDenied('parent startup scope differs')
        data, digest, _source = self._ingress._source(context, parent)
        if data['phase'] != 'AWAIT_APPROVAL':
            raise AuthorityDenied('no current action proposal awaiting review')
        proposal = data['proposal']
        if (proposal.get('name') not in scope.allowed_actions or type(proposal.get('arguments')) is not dict
                or (proposal['name'] == 'project.run_check' and proposal['arguments'].get('check') not in scope.allowed_checks)
                or (proposal['name'] != 'project.run_check' and proposal['arguments'].get('path') not in scope.allowed_paths)):
            raise AuthorityDenied('proposal exceeds startup scope')
        spec = self.runtime._backend.canonical_resource_spec(proposal['name'], proposal['arguments'], parent)
        metadata = {key: value for key, value in asdict(spec).items() if key not in ('name','arguments')}
        if (_json(metadata) != _json(proposal.get('spec'))
                or spec.configuration_sha256 != self._bindings[scope.project_scope][1]):
            raise AuthorityDenied('reviewed action configuration changed')
        review = {'task_id': task_id, 'proposal_sha256': digest, 'proposal': proposal,
            'canonical_spec': asdict(spec), 'project_scope': scope.project_scope,
            'scope_binding_sha256': self._bindings[scope.project_scope][0],
            'configuration_sha256': spec.configuration_sha256,
            'parent_deadline_wall': context.deadline_wall, 'parent_revision': parent['revision'],
            'max_validity_s': self._max_validity}
        if spec.name == 'project.run_check':
            check = self.runtime._backend._workspaces[spec.scope][2][proposal['arguments']['check']]
            # Containment argv may embed a launch manifest containing env
            # values. Bind it by digest; never return that opaque payload.
            review['check'] = {'name': check.name, 'executable': check.argv[0],
                'command_sha256': _digest(check.argv), 'argument_count': len(check.argv),
                'working_directory': check.cwd, 'timeout_s': check.timeout_s,
                'containment_ref': check.containment_ref, 'environment_keys': [key for key, _ in check.env]}
        review['review_sha256'] = _digest(review)
        return review

    def review(self, task_id, *, principal):
        """Exact human-review payload. Creates no approval, grant or action."""
        context = self._active_context(task_id, principal)
        with self._locked(principal):
            return self._review_locked(task_id, context)

    def approve(self, task_id, *, principal, proposal_sha256, review_sha256,
                idempotency_key, validity_s, approved):
        """Persist explicit exact approval; root separately delegates the step."""
        if approved is not True:
            raise AuthorityDenied('explicit operator approval required')
        for digest in (proposal_sha256, review_sha256):
            if type(digest) is not str or not _HEX.fullmatch(digest):
                raise AuthorityDenied('exact review and proposal digests required')
        if type(validity_s) is not int or not 1 <= validity_s <= self._max_validity:
            raise AuthorityDenied('bounded integer approval validity required')
        _text(task_id); _text(idempotency_key)
        submission = 'operator-submission:' + _digest([principal, idempotency_key])
        fingerprint = _digest([task_id, proposal_sha256, review_sha256, validity_s])
        with self._locked(principal):
            prior = self.db.execute('SELECT * FROM planner_operator_approvals WHERE submission=?', (submission,)).fetchone()
            if prior is not None:
                if prior['principal'] != principal or prior['fingerprint'] != fingerprint:
                    raise AuthorityConflict('idempotency key has different reviewed input')
                return self._receipt(prior)
        context = self._active_context(task_id, principal)
        with self._locked(principal):
            # Another authenticated request may have completed while locks were released.
            prior = self.db.execute('SELECT * FROM planner_operator_approvals WHERE submission=?', (submission,)).fetchone()
            if prior is not None:
                if prior['principal'] != principal or prior['fingerprint'] != fingerprint:
                    raise AuthorityConflict('idempotency key has different reviewed input')
                return self._receipt(prior)
            review = self._review_locked(task_id, context)
            if review['proposal_sha256'] != proposal_sha256 or review['review_sha256'] != review_sha256:
                raise AuthorityConflict('current proposal or review changed')
            if self.db.execute('SELECT 1 FROM planner_operator_approvals WHERE parent_id=? AND proposal_sha256=?',
                               (task_id, proposal_sha256)).fetchone():
                raise AuthorityConflict('proposal already has an immutable approval')
            if self.db.execute('SELECT count(*) FROM planner_operator_approvals').fetchone()[0] >= self._max_approvals:
                raise AuthorityCapacity('retained operator approval quota exhausted')
            now = self._now()
            expiry = min(now + validity_s, context.deadline_wall)
            if not now < expiry:
                raise AuthorityDenied('parent deadline reached')
            reference = 'operator-step:' + _digest([principal, idempotency_key])
            self.db.execute('INSERT INTO planner_operator_approvals VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NULL)',
                (reference, submission, principal, task_id, context.project_scope, proposal_sha256,
                 review_sha256, fingerprint, review['scope_binding_sha256'], validity_s, now, expiry))
            return self._receipt(self.db.execute('SELECT * FROM planner_operator_approvals WHERE approval_ref=?', (reference,)).fetchone())

    def revoke(self, approval_ref, *, principal):
        """Irreversible denial only; committed work retains its drain/receipt."""
        with self._locked(principal):
            row = self.db.execute('SELECT * FROM planner_operator_approvals WHERE approval_ref=? AND principal=?',
                                  (_text(approval_ref), principal)).fetchone()
            if row is None:
                raise AuthorityDenied('approval unavailable for this principal')
            self.db.execute('UPDATE planner_operator_approvals SET revoked_wall=? '
                            'WHERE approval_ref=? AND revoked_wall IS NULL', (self._now(), approval_ref))
            return self._receipt(self.db.execute('SELECT * FROM planner_operator_approvals WHERE approval_ref=?', (approval_ref,)).fetchone())
