"""Authenticated Unix bridge; no local execution or automatic action replay."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import secrets
import socket
import stat
import time

from .task_check_service import (CheckServiceUnavailable, VERSION, SERVICE_MODULES, _absolute,
    _identifier, _receive, _send, canonical, digest, peer_credentials,
    source_pin, source_snapshot, validate_request, wire_request)


class ExecutionNotSent(CheckServiceUnavailable):
    """This call failed before its execute sendall was attempted."""


@dataclass(frozen=True)
class VerifiedServiceEndpoint:
    """Trusted operator identity, never constructed from an IPC response."""
    socket_path: str
    service_uid: int
    cgroup_path: str
    python_path: str
    entrypoint: str
    config_path: str
    configuration_sha256: str
    loaded_sources: tuple
    python_pin: tuple
    config_pin: tuple

    def __post_init__(self):
        if type(self.service_uid) is not int or self.service_uid <= 0:
            raise CheckServiceUnavailable('dedicated_nonroot_service_uid_required')
        if not self.cgroup_path.startswith('/system.slice/') or not self.cgroup_path.endswith('.service'):
            raise CheckServiceUnavailable('exact_operator_service_cgroup_required')

    @classmethod
    def from_operator_configuration(cls, *, socket_path, service_uid, cgroup_path,
                                    config_path, configuration_sha256,
                                    entrypoint, python_path='/usr/bin/python3'):
        if type(service_uid) is not int or service_uid <= 0:
            raise CheckServiceUnavailable('dedicated_nonroot_service_uid_required')
        for path in (socket_path, config_path, entrypoint):
            _absolute(path)
        if (not isinstance(cgroup_path, str) or not cgroup_path.startswith('/system.slice/')
                or not cgroup_path.endswith('.service') or '..' in cgroup_path.split('/')
                or '\0' in cgroup_path):
            raise CheckServiceUnavailable('exact_operator_service_cgroup_required')
        if not os.path.isabs(python_path) or os.path.normpath(python_path) != python_path:
            raise CheckServiceUnavailable('fixed_python_command_required')
        python_executable = os.path.realpath(python_path)
        sources = source_snapshot(str(Path(entrypoint).parent))
        if entrypoint != sources['task_check_service.py']['path']:
            raise CheckServiceUnavailable('fixed_service_entrypoint_required')
        config = source_pin(config_path)
        if config['sha256'] != configuration_sha256:
            raise CheckServiceUnavailable('operator_configuration_changed')
        # These are immutable startup expectations. A later file replacement
        # cannot silently update an already-created bridge's trust decision.
        return cls(socket_path, service_uid, cgroup_path, python_path, entrypoint,
            config_path, configuration_sha256,
            tuple((name, tuple(sorted(pin.items()))) for name, pin in sorted(sources.items())),
            tuple(sorted(source_pin(python_executable).items())), tuple(sorted(config.items())))

    @property
    def source_manifest(self):
        return {name: dict(pin) for name, pin in self.loaded_sources}

    @property
    def command(self):
        return (self.python_path, '-I', '-S', self.entrypoint, '--config', self.config_path,
                '--config-sha256', self.configuration_sha256)


def _pid_start(pid):
    # comm may contain spaces/parentheses; fields following its final ')' begin at state.
    tail = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return int(tail[19])


def _effective_limits(pid, cgroup_path):
    rows = Path(f'/proc/{pid}/cgroup').read_text().splitlines()
    if [row for row in rows if row.startswith('0::')] != ['0::' + cgroup_path]:
        raise CheckServiceUnavailable('service_cgroup_mismatch')
    root = Path('/sys/fs/cgroup')
    if not any(' - cgroup2 ' in line and line.split()[4] == str(root)
               for line in Path('/proc/self/mountinfo').read_text().splitlines()):
        raise CheckServiceUnavailable('real_cgroup_v2_mount_required')
    directory = root / cgroup_path.lstrip('/')
    memory = pids = cpu = math.inf
    while True:
        for name in ('memory.max', 'pids.max', 'cpu.max'):
            path = directory / name
            if not path.exists():
                continue
            value = path.read_text().split()
            if not value or value[0] == 'max':
                continue
            if name == 'memory.max':
                memory = min(memory, int(value[0]))
            elif name == 'pids.max':
                pids = min(pids, int(value[0]))
            else:
                cpu = min(cpu, int(value[0]) / int(value[1]))
        if directory == root:
            break
        directory = directory.parent
        if root not in (directory, *directory.parents):
            raise CheckServiceUnavailable('invalid_service_cgroup')
    if not (0 < memory <= 768 * 1024 * 1024 and 0 < pids <= 64 and 0 < cpu <= 1):
        raise CheckServiceUnavailable('actual_service_resource_limits_required')
    return {'memory_bytes': int(memory), 'pids': int(pids), 'cpu_fraction': cpu}


def verify_peer(connection, endpoint):
    """Kernel identity + pinned entrypoint/loaded manifest + actual cgroup.

    This trusts operator-managed root-owned code and a dedicated service OS
    identity. It does not purport to attest against a malicious host root.
    """
    pid, uid, _ = peer_credentials(connection)
    if uid != endpoint.service_uid or pid <= 0:
        raise CheckServiceUnavailable('service_peer_uid_mismatch')
    start = _pid_start(pid)
    status = dict(line.split(':', 1) for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line)
    if ([int(n) for n in status['Uid'].split()] != [uid] * 4
            or int(status['CapEff'], 16) != 0 or int(status['CapPrm'], 16) != 0
            or int(status['NoNewPrivs']) != 1):
        raise CheckServiceUnavailable('unprivileged_service_process_required')
    cmd = tuple(part.decode() for part in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if part)
    if cmd != endpoint.command or os.path.realpath(f'/proc/{pid}/exe') != dict(endpoint.python_pin)['path']:
        raise CheckServiceUnavailable('fixed_isolated_service_entrypoint_required')
    if (source_pin(dict(endpoint.python_pin)['path']) != dict(endpoint.python_pin)
            or source_pin(endpoint.config_path) != dict(endpoint.config_pin)
            or source_snapshot(str(Path(endpoint.entrypoint).parent)) != endpoint.source_manifest):
        raise CheckServiceUnavailable('pinned_service_source_changed')
    # Ensure the peer's mount namespace sees those same objects, not aliases
    # underneath a private root. Bytes are pinned by the operator-owned objects.
    for pin in [dict(endpoint.python_pin), dict(endpoint.config_pin), *endpoint.source_manifest.values()]:
        info = os.stat(f'/proc/{pid}/root' + pin['path'])
        if (info.st_dev, info.st_ino) != (pin['dev'], pin['ino']):
            raise CheckServiceUnavailable('peer_source_namespace_mismatch')
    limits = _effective_limits(pid, endpoint.cgroup_path)
    if _pid_start(pid) != start:
        raise CheckServiceUnavailable('service_peer_replaced')
    return pid, start, limits


class CheckServiceBridge:
    """Parent policy owns grants; this object verifies the execution boundary."""
    def __init__(self, *, endpoint, workspaces, proof_required=None, resolve_check_material=None):
        from .task_project_actions import ProjectActions
        if not isinstance(endpoint, VerifiedServiceEndpoint):
            raise TypeError('verified operator endpoint required')
        self.endpoint = endpoint
        self.workspaces = tuple(workspaces)
        self._backend = ProjectActions(self.workspaces)
        if ((proof_required is None)!=(resolve_check_material is None)
                or (proof_required is not None and (not callable(proof_required) or not callable(resolve_check_material)))):
            raise TypeError('paired trusted proof classifier and material resolver required')
        self._proof_required,self._check_material=proof_required,resolve_check_material

    def _socket_identity(self):
        path = _absolute(self.endpoint.socket_path)
        parent = Path(path).parent
        info = parent.stat()
        leaf = os.lstat(path)
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid != self.endpoint.service_uid
                or info.st_mode & 0o077 or not stat.S_ISSOCK(leaf.st_mode)
                or leaf.st_uid != self.endpoint.service_uid or leaf.st_mode & 0o077):
            raise CheckServiceUnavailable('private_operator_socket_required')
        return leaf.st_dev, leaf.st_ino

    def _request(self, request, *, require_ready=False, before_send=None, descriptor=None):
        attempted = [False]
        try:
            return self._exchange(request, require_ready=require_ready,
                                  before_send=before_send, attempted=attempted,descriptor=descriptor)
        except Exception as exc:
            if request.get('op') == 'execute' and not attempted[0]:
                raise ExecutionNotSent('execution_denied_before_send') from exc
            raise

    def _exchange(self, request, *, require_ready, before_send, attempted, descriptor=None):
        socket_identity = self._socket_identity()
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
            connection.settimeout(3)
            connection.connect(self.endpoint.socket_path)
            before = verify_peer(connection, self.endpoint)
            if self._socket_identity() != socket_identity:
                raise CheckServiceUnavailable('service_socket_replaced')
            nonce = secrets.token_hex(16)
            _send(connection, {'op': 'hello', 'nonce': nonce})
            hello = _receive(connection, timeout=5)
            if (set(hello) != {'version', 'pid', 'configuration_sha256', 'loaded_sources', 'compiled_modules', 'nonce', 'ready'}
                    or hello['version'] != VERSION or hello['nonce'] != nonce
                    or hello['pid'] != before[0]
                    or hello['configuration_sha256'] != self.endpoint.configuration_sha256
                    or hello['loaded_sources'] != self.endpoint.source_manifest
                    or hello['compiled_modules'] != {name: self.endpoint.source_manifest[name]['sha256'] for name in SERVICE_MODULES}
                    or type(hello['ready']) is not bool):
                raise CheckServiceUnavailable('loaded_service_identity_mismatch')
            if require_ready and hello['ready'] is not True:
                raise CheckServiceUnavailable('service_containment_unavailable')
            if verify_peer(connection, self.endpoint) != before:
                raise CheckServiceUnavailable('service_peer_changed_before_request')
            executing = request.get('op') == 'execute'
            if executing and (before_send is None or before_send() is not True):
                raise ExecutionNotSent('parent_effect_authority_denied_before_send')
            def mark_attempt():
                attempted[0] = True
            if descriptor is None:
                _send(connection, request, on_attempt=mark_attempt if executing else None)
            else:
                _send(connection, request, on_attempt=mark_attempt if executing else None,descriptor=descriptor)
            response = _receive(connection, timeout=5)
            if verify_peer(connection, self.endpoint) != before:
                raise CheckServiceUnavailable('service_peer_changed_after_request')
            if type(response.get('ok')) is not bool:
                raise CheckServiceUnavailable('service_response_invalid')
            return response

    def _match(self, spec):
        if spec.name != 'project.run_check':
            return False
        expected = self._backend.canonical_resource_spec(spec.name, dict(spec.arguments),
                                                        {'project_scope': spec.scope})
        return expected == spec

    def validate_spec(self, spec):
        try:
            if not self._match(spec):
                return False
            response = self._request({'op': 'status', 'spec': asdict(spec)}, require_ready=True)
            return response == {'ok': True, 'value': {'ready': True}}
        except Exception:
            return False

    def authorize(self, action, task, spec):
        """Structural readiness only. Never calls the parent grant callback."""
        try:
            if (not action or not task or action.get('task_id') != task.get('task_id')
                    or not isinstance(action.get('action_id'), str)):
                return False
            expected = self._backend.canonical_resource_spec(action.get('name'), action.get('arguments'), task)
            return expected == spec and self.validate_spec(spec)
        except Exception:
            return False

    def bind_handler(self, parent_effect_authority):
        """Create the sole remote handler after TaskRuntime owns its grant store."""
        if not callable(parent_effect_authority):
            raise TypeError('explicit parent effect authority required')
        def handler(action, task):
            return self._handle(action, task, parent_effect_authority)
        return handler

    def _material(self,action,task,spec):
        if self._proof_required is None:
            return None
        required=self._proof_required(action,task,spec)
        if type(required) is not bool:
            raise CheckServiceUnavailable('literal_proof_requirement_required')
        if required is False:
            return None
        material=self._check_material(action,task,spec)
        if material is None:
            raise CheckServiceUnavailable('reserved_check_requires_immutable_material')
        from .task_check_snapshot import prepare_material
        return prepare_material(material,action,task,spec)

    def resolve_input_proof(self,action,task,spec):
        """Historical authenticated lookup only; never executes or renews a grant.

        Caller hydrates evidence outside ownership locks and must subsequently
        revalidate exact TaskStore result sequence/digest and immutable registry.
        No current active approval/material lookup is needed for retained history.
        """
        from .task_check_snapshot import VerifiedInputProof,validate_proof,sha,canonical as snapshot_json
        try:
            if (action.get('state')!='SUCCEEDED' or action.get('task_id')!=task.get('task_id')
                    or type(action.get('result_seq')) is not int or action['result_seq']<=0
                    or action.get('name')!='project.run_check' or action.get('arguments')!=dict(spec.arguments)
                    or type(action.get('tier')) is not int or action['tier']!=3
                    or task.get('project_scope')!=spec.scope
                    or list(spec.resources)!=list(action.get('resources',())) or not self._match(spec)):
                return None
            result=action.get('result')
            if (type(result) is not dict or result.get('ok') is not True
                    or result.get('check')!=dict(spec.arguments)['check']
                    or type(result.get('returncode')) is not int or result['returncode']!=0):
                return None
            ref=result.get('immutable_receipt')
            if type(ref) is not dict or set(ref)!={'action_id','request_sha256','proof_sha256'} or ref['action_id']!=action['action_id']:
                return None
            proof=result.get('input_proof')
            if type(proof) is not dict or sha(snapshot_json(proof))!=ref['proof_sha256']:
                return None
            binding={'action_id':action['action_id'],'planner_proposal_sha256':proof.get('planner_proposal_sha256'),
                'configuration_sha256':spec.configuration_sha256,'artifact_sha256':proof.get('artifact_sha256'),
                'input_tree_sha256':proof.get('input_tree_sha256'),'spec_sha256':sha(snapshot_json(asdict(spec)))}
            from .task_check_snapshot import _hash
            for value in (ref['request_sha256'],ref['proof_sha256'],proof.get('runtime_sha256'),
                          binding['planner_proposal_sha256'],binding['artifact_sha256'],binding['input_tree_sha256']): _hash(value)
            verified=validate_proof(proof,binding,runtime_sha256=proof['runtime_sha256'],request_sha256=ref['request_sha256'])
            response=self._request({'op':'lookup','action_id':action['action_id'],'request_sha256':ref['request_sha256']})
            if response.get('ok') is not True: return None
            answer=self._result(response.get('value',{}),action['action_id'],ref['request_sha256'])
            if answer is None or answer.outcome!='SUCCEEDED' or canonical(dict(answer.details))!=canonical(result): return None
            mapped={key:verified[key] for key in ('mode','action_id','planner_proposal_sha256','configuration_sha256',
                'artifact_sha256','input_tree_sha256','completion_tree_sha256','mutation_excluded','held_until_drain',
                'namespace_drained','process_drained','request_sha256','runtime_sha256')}
            return VerifiedInputProof(reference='check-proof:'+ref['proof_sha256'],
                snapshot_ref='check-snapshot:'+ref['request_sha256'],**mapped)
        except Exception:
            return None

    @staticmethod
    def _uncertain(reason):
        from .task_worker import ActionResult
        return ActionResult('UNKNOWN', {'ok': False, 'reason': reason,
                            'uncertain': True, 'replay_allowed': False})

    @staticmethod
    def _result(receipt, action_id, request_sha256):
        from .task_worker import ActionResult
        if (receipt.get('action_id') != action_id or receipt.get('request_sha256') != request_sha256
                or receipt.get('state') not in ('SUCCEEDED', 'FAILED', 'UNKNOWN')):
            return None
        result = receipt.get('result')
        if (type(result) is not dict or set(result) != {'outcome', 'details'}
                or result['outcome'] != receipt['state'] or type(result['details']) is not dict
                or len(canonical(result).encode()) > 8192):
            raise CheckServiceUnavailable('retained_receipt_invalid')
        if result['outcome'] == 'SUCCEEDED' and not all(result['details'].get(k) is True
                for k in ('ok', 'namespace_drained', 'process_drained')):
            raise CheckServiceUnavailable('receipt_lacks_execution_drain_proof')
        if result['outcome'] == 'FAILED' and (result['details'].get('ok') is not False or (
                result['details'].get('executed') is not False and not all(result['details'].get(k) is True
                for k in ('namespace_drained', 'process_drained')))):
            raise CheckServiceUnavailable('failed_receipt_lacks_execution_proof')
        return ActionResult(result['outcome'], result['details'])

    def _handle(self, action, task, authority):
        from .task_worker import ActionResult
        sent = False
        descriptor=None
        try:
            action, task = copy.deepcopy(dict(action)), copy.deepcopy(dict(task))
            spec = self._backend.canonical_resource_spec(action.get('name'), action.get('arguments'), task)
            request = wire_request(action, task, spec)
            validate_request(request, self._backend.canonical_resource_spec)
            material=self._material(action,task,spec)
            if material is not None:
                from .task_check_snapshot import sealed_fd
                request['immutable'],bundle=material
                descriptor=sealed_fd(bundle,label='leon-approved-artifact')
            if not self.authorize(action, task, spec) or authority(action, task, spec) is not True:
                return ActionResult('FAILED', {'ok': False, 'executed': False, 'reason': 'parent_effect_authority_denied'})
            if wire_request(action, task, spec) != {k:v for k,v in request.items() if k!='immutable'}:
                raise CheckServiceUnavailable('authority_changed_exact_request')
            action_id, fingerprint = action['action_id'], digest(request)
            timeout = next(check.timeout_s for workspace in self.workspaces if workspace.scope == spec.scope
                           for check in workspace.checks if check.name == dict(spec.arguments)['check'])
            end = time.monotonic() + min(125, float(timeout) + 5)
            # Exactly one execute request. After any ambiguous IPC, use lookup
            # only—even NOT_FOUND does not authorize a retry of the effect.
            def final_authority():
                validate_request(request, self._backend.canonical_resource_spec)
                try:
                    if self._material(action,task,spec)!=material:
                        return False
                except Exception:
                    return False
                # Material hashing/registry validation is bounded but may take
                # time. Re-read grant/revocation after that work, immediately
                # before sending; it must never precede a new material wait.
                if authority(action, task, spec) is not True or wire_request(action, task, spec) != {k:v for k,v in request.items() if k!='immutable'}:
                    return False
                # Deadline may have elapsed while the parent checked its durable grant.
                validate_request(request, self._backend.canonical_resource_spec)
                return True
            try:
                if descriptor is None:
                    response = self._request({'op': 'execute', 'request': request}, require_ready=True,
                                             before_send=final_authority)
                else:
                    response = self._request({'op': 'execute', 'request': request}, require_ready=True,
                                             before_send=final_authority,descriptor=descriptor)
                sent = True
            except ExecutionNotSent:
                return ActionResult('FAILED', {'ok': False, 'executed': False,
                                    'reason': 'execution_denied_before_send'})
            except Exception:
                sent = True
                response = None
            execute_reply = True
            while time.monotonic() < end:
                if response is not None:
                    if response.get('ok') is False:
                        if execute_reply and response.get('accepted') is False and response.get('reason') != 'attempt_identity_conflict':
                            return ActionResult('FAILED', {'ok': False, 'executed': False,
                                'reason': 'service_rejected_execution'})
                        return self._uncertain('service_acceptance_unverified')
                    if response.get('ok') is True:
                        receipt = response.get('value', {})
                        result = self._result(receipt, action_id, fingerprint)
                        if result is not None:
                            if material is not None and result.outcome=='SUCCEEDED':
                                from .task_check_snapshot import validate_proof,sha,canonical as snapshot_json
                                data=dict(result.details); proof=data.get('input_proof')
                                if type(proof) is not dict: return self._uncertain('immutable_receipt_proof_missing')
                                validate_proof(proof,material[0],runtime_sha256=proof.get('runtime_sha256'),request_sha256=fingerprint)
                                if data.get('immutable_receipt')!={'action_id':action_id,'request_sha256':fingerprint,'proof_sha256':sha(snapshot_json(proof))}:
                                    return self._uncertain('immutable_receipt_binding_differs')
                            return result
                        if receipt.get('state') == 'NOT_FOUND':
                            return self._uncertain('execution_request_not_recoverable')
                time.sleep(.05)
                execute_reply = False
                try:
                    response = self._request({'op': 'lookup', 'action_id': action_id,
                                              'request_sha256': fingerprint})
                except Exception:
                    response = None
            return self._uncertain('execution_receipt_wait_expired')
        except Exception:
            if sent:
                return self._uncertain('execution_transport_unverified')
            return ActionResult('FAILED', {'ok': False, 'executed': False, 'reason': 'execution_request_rejected'})
        finally:
            if descriptor is not None: os.close(descriptor)
