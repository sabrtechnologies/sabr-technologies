"""
Phase 13 — failure classifier.

Pure-function classifier. Takes the messy real-world outcome of a tool call
(result dict + optional exception text + tool name + args) and returns:

    FailureKind   — one of a small vocabulary (timeout/auth/network/...)
    repairability — 0..1, how likely a tiny safe fix can recover this
    suggestion    — short human-readable hint ("re-auth Brave CDP", etc.)

No I/O. No dependencies beyond stdlib. Safe to call from anywhere.

Design notes:
  • The vocabulary is deliberately small. New kinds add complexity without
    adding capability if there is no repair path for them.
  • We classify on text patterns because Leon's tool result schema is not
    uniform (actuator, registry, local_tools all produce slightly different
    shapes; some raise exceptions, some return {ok:False, error:"..."}).
  • repairability is conservative — only known recoverable kinds score >0.5.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional, Tuple


# ── Kind vocabulary ────────────────────────────────────────────────────────

KIND_OK              = "ok"
KIND_TIMEOUT         = "timeout"
KIND_AUTH            = "auth"
KIND_NETWORK         = "network"
KIND_DEPENDENCY      = "dependency"           # missing binary/package/service
KIND_SCHEMA_MISMATCH = "schema_mismatch"      # wrong args / unexpected fields
KIND_STALE_SELECTOR  = "stale_selector"       # element disappeared (browser, ui)
KIND_MISSING_TARGET  = "missing_target"       # file/url/app not found
KIND_PERMISSION      = "permission"
KIND_QUOTA           = "quota"                # rate limit, 429, billing
KIND_INTERNAL        = "internal"             # server/handler raised
KIND_UNKNOWN         = "unknown"


# ── Repairability table ─────────────────────────────────────────────────────
# How likely a tiny reversible local fix can recover this kind.
# Self-repair queue uses this to decide auto-apply vs. queue-for-Dean.
_REPAIRABILITY = {
    KIND_OK:              0.0,
    KIND_TIMEOUT:         0.6,
    KIND_AUTH:            0.2,    # often needs Dean (re-auth flow)
    KIND_NETWORK:         0.5,
    KIND_DEPENDENCY:      0.7,    # pip/apt install is often deterministic
    KIND_SCHEMA_MISMATCH: 0.4,
    KIND_STALE_SELECTOR:  0.8,    # rebuild selector / wait / retry usually works
    KIND_MISSING_TARGET:  0.1,
    KIND_PERMISSION:      0.1,
    KIND_QUOTA:           0.3,    # backoff and retry
    KIND_INTERNAL:        0.3,
    KIND_UNKNOWN:         0.2,
}

_SUGGESTION = {
    KIND_TIMEOUT:         "retry with longer timeout; check if upstream service is slow/dead",
    KIND_AUTH:            "re-auth: token may be expired (~/.openclaw/google-oauth, anthropic key, etc.)",
    KIND_NETWORK:         "check connectivity and retry; consider alternate tool if pattern persists",
    KIND_DEPENDENCY:      "missing binary or package — check install",
    KIND_SCHEMA_MISMATCH: "argument shape mismatch — verify tool signature and caller",
    KIND_STALE_SELECTOR:  "element vanished or page reloaded — refetch DOM and retry",
    KIND_MISSING_TARGET:  "target file/url/app not found — verify path/identifier",
    KIND_PERMISSION:      "permission denied — needs explicit grant",
    KIND_QUOTA:           "rate limited or over quota — back off, retry later",
    KIND_INTERNAL:        "internal error from tool handler — inspect logs",
    KIND_UNKNOWN:         "uncategorized failure — inspect manually",
}


# ── Pattern table ──────────────────────────────────────────────────────────
# Order matters: first match wins. Patterns are case-insensitive.
_PATTERNS: Tuple[Tuple[str, re.Pattern], ...] = (
    (KIND_TIMEOUT, re.compile(r"\btimed?\s*out\b|\btimeout\b|deadline\s+exceeded", re.I)),
    (KIND_AUTH,    re.compile(r"\b(401|403)\b|unauthor|forbidden|invalid\s+(api[\s_]?key|token|credential)|expired\s+token|re[-\s]?auth", re.I)),
    (KIND_QUOTA,   re.compile(r"\b429\b|rate[\s_-]?limit|too\s+many\s+requests|quota|over\s+limit|billing", re.I)),
    (KIND_NETWORK, re.compile(r"connection\s+refused|connection\s+reset|dns|name\s+or\s+service\s+not\s+known|unreachable|no\s+route\s+to\s+host|EHOSTUNREACH|ECONNREFUSED|ENETUNREACH|ssl\s+handshake|getaddrinfo", re.I)),
    (KIND_DEPENDENCY, re.compile(r"command\s+not\s+found|no\s+such\s+file\s+or\s+directory:.+/(bin|lib)|module(?:notfound)?error|cannot\s+import|missing\s+(dependency|module|package)|not\s+installed", re.I)),
    (KIND_STALE_SELECTOR, re.compile(r"element\s+not\s+found|no\s+such\s+element|stale\s+element|selector\s+(failed|not\s+found)|page\s+(closed|navigated)|target\s+closed", re.I)),
    (KIND_MISSING_TARGET, re.compile(r"\b(404|not\s+found)\b|no\s+such\s+file|file\s+does\s+not\s+exist|unknown\s+app|invalid\s+url", re.I)),
    (KIND_PERMISSION, re.compile(r"permission\s+denied|EACCES|EPERM|operation\s+not\s+permitted|access\s+denied|read[\s_-]?only\s+file", re.I)),
    (KIND_SCHEMA_MISMATCH, re.compile(r"missing\s+(required\s+)?(arg|field|parameter)|unexpected\s+keyword|invalid\s+argument|validation\s+error|schema|TypeError.*(unexpected|missing)", re.I)),
    (KIND_INTERNAL, re.compile(r"internal\s+server\s+error|\b500\b|traceback|RuntimeError|KeyError|ValueError|AttributeError", re.I)),
)


@dataclass
class Failure:
    kind: str
    repairability: float
    suggestion: str
    matched_text: str = ""   # short excerpt of what tripped the classifier

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def classify(
    result: Any = None,
    *,
    exception_text: Optional[str] = None,
    tool: Optional[str] = None,
    args: Optional[Dict[str, Any]] = None,
) -> Failure:
    """Classify a tool outcome.

    Inputs:
      result         — the dict the tool returned (or anything truthy on success)
      exception_text — str of an exception that bubbled out, if any
      tool           — tool name (used for tool-specific overrides)
      args           — args passed to the tool (used for schema-mismatch hints)
    """
    # 1) Success path — result is truthy and not explicitly {ok:False}
    if exception_text is None and _looks_successful(result):
        return Failure(kind=KIND_OK, repairability=0.0, suggestion="", matched_text="")

    # 2) Build a search blob from every signal we have
    blob = _build_blob(result, exception_text)

    # 3) Tool-specific overrides (cheap, optional)
    if tool:
        ov = _tool_override(tool, blob)
        if ov is not None:
            return _make(ov, blob)

    # 4) Pattern table
    for kind, pat in _PATTERNS:
        m = pat.search(blob)
        if m:
            return _make(kind, blob, matched=m.group(0)[:120])

    return _make(KIND_UNKNOWN, blob)


# ── Helpers ────────────────────────────────────────────────────────────────

def _looks_successful(result: Any) -> bool:
    if result is None:
        return False
    if isinstance(result, dict):
        # actuator/local_tools convention: {ok:bool, ...}
        if "ok" in result:
            return bool(result.get("ok"))
        # Some tools just return data dicts on success
        if "error" in result and result["error"]:
            return False
        return True
    return bool(result)


def _build_blob(result: Any, exception_text: Optional[str]) -> str:
    parts = []
    if exception_text:
        parts.append(str(exception_text))
    if isinstance(result, dict):
        for k in ("error", "message", "stderr", "detail", "reason"):
            v = result.get(k)
            if isinstance(v, str) and v:
                parts.append(v)
        # Some tools nest the failure in 'result' or 'data'
        for k in ("result", "data"):
            v = result.get(k)
            if isinstance(v, dict):
                for kk in ("error", "message"):
                    vv = v.get(kk)
                    if isinstance(vv, str) and vv:
                        parts.append(vv)
    elif isinstance(result, str):
        parts.append(result)
    return " | ".join(p for p in parts if p)[:2000]


def _tool_override(tool: str, blob: str) -> Optional[str]:
    """Tool-specific hints when patterns alone are ambiguous."""
    t = tool.lower()
    # Brave CDP: a generic "Connection refused" almost always = CDP not up
    if "browser." in t or "browser_" in t:
        if "9222" in blob or "remote-debugging" in blob.lower():
            return KIND_DEPENDENCY
    # actuator socket calls — "no actuator" means dep
    if "actuator" in blob.lower() and "no" in blob.lower():
        return KIND_DEPENDENCY
    return None


def _make(kind: str, blob: str, matched: str = "") -> Failure:
    return Failure(
        kind=kind,
        repairability=_REPAIRABILITY.get(kind, 0.0),
        suggestion=_SUGGESTION.get(kind, ""),
        matched_text=matched or blob[:120],
    )


__all__ = [
    "classify", "Failure",
    "KIND_OK", "KIND_TIMEOUT", "KIND_AUTH", "KIND_NETWORK",
    "KIND_DEPENDENCY", "KIND_SCHEMA_MISMATCH", "KIND_STALE_SELECTOR",
    "KIND_MISSING_TARGET", "KIND_PERMISSION", "KIND_QUOTA",
    "KIND_INTERNAL", "KIND_UNKNOWN",
]
