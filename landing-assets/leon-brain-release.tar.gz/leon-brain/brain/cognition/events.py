"""
Cognitive event fabric — Leon V2 Phase 2 (shadow mode, additive only).

The one shape every subsystem uses to tell the rest of the brain that
something happened: a user spoke, a percept changed, a drive moved, a tool
came back, a dream surfaced a candidate memory. Today nothing in Leon's live
path constructs these — Phase 2 lands the vocabulary and the transport
(``event_bus``) so later phases can route through them without a flag day.

Design rules this module exists to enforce
------------------------------------------

**Importing this module does nothing.** No I/O, no clocks started, no
singletons, no logging handlers, no background threads. It defines an Enum, a
frozen dataclass, a priority table and some pure functions. That is why it
lives beside ``brain/cognition/__init__.py`` without being imported by it: the
package ``__init__`` drags in NumPy and ~30 modules, and the event fabric must
stay loadable (and testable) on its own.

**Payloads are plain JSON, sealed at construction.** Every way of building
a :class:`CognitiveEvent` (``new_event``, ``from_dict``, direct construction,
``dataclasses.replace``) runs ``__post_init__``, which round-trips the payload
through ``json`` with ``allow_nan=False`` and a :data:`MAX_PAYLOAD_BYTES`
(64 KiB) cap and stores the decoded deep copy, read-only. So:

* raw frames, audio, ``bytes``/``bytearray``/``memoryview``, NumPy arrays,
  sets, NaN/inf, custom objects and reference cycles are refused with
  :class:`PayloadNotSerializable`. Media travels by *reference* (a frame id,
  a capture path, a ring-buffer index), never by value;
* an oversized payload is refused with :class:`PayloadTooLarge`;
* the producer keeps no handle on what a consumer sees (a deep copy, not a
  shared nested dict), and :func:`is_serializable` is true by construction.

JSON coerces shapes: non-string keys become strings and tuples become lists,
so consumers always see JSON-shaped data. Error messages never quote payload
values (they may be private).

**Events are immutable and never ordered by identity.** The dataclass is
frozen and deliberately has no ``__lt__``: the bus orders by
``(-priority, sequence)`` and must never fall through to comparing events.

Priority scale (higher wins), per the Phase 2 ordering requirement
``user input > urgent/safety > active work > prediction/curiosity >
background > dreams/consolidation``::

    100  USER_MESSAGE, VOICE_FINAL     a person is talking to Leon
     95  VOICE_PARTIAL                 a person is mid-sentence
     90  RESOURCE_EVENT                urgent/safety: disk, memory, thermal
     80  PERCEPTION_CHANGE             the world just changed
     75  TOOL_RESULT                   active work, unblocking a turn
     70  GOAL_EVENT, REFLEX_RESULT     active work
     50  PREDICTION_ERROR              learning signal
     40  MEMORY_CANDIDATE, DRIVE_CHANGE
     30  BACKGROUND_THOUGHT, LEARNING_INTENT, QUANTUM_RESULT
     10  SLEEP_EVENT                   dreams / consolidation, yields to all

Nothing here touches Leon's canonical state. It is pure data.
"""
from __future__ import annotations

import json
import math
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping, Optional

__all__ = [
    "EventType",
    "CognitiveEvent",
    "DEFAULT_PRIORITY",
    "MAX_PAYLOAD_BYTES",
    "MAX_SOURCE_CHARS",
    "USER_PRIORITY_FLOOR",
    "new_event",
    "seal_payload",
    "to_dict",
    "from_dict",
    "is_serializable",
    "PayloadRejected",
    "PayloadTooLarge",
    "PayloadNotSerializable",
]


class EventType(str, Enum):
    """Every kind of thing that can happen to Leon.

    A ``str`` mixin on purpose: ``event.type == "user_message"`` holds, the
    value survives JSON without a converter, and consumers that only know the
    wire string (the bus's protected-type set, a log filter) need not import
    this module.
    """

    USER_MESSAGE = "user_message"
    VOICE_PARTIAL = "voice_partial"
    VOICE_FINAL = "voice_final"
    PERCEPTION_CHANGE = "perception_change"
    MEMORY_CANDIDATE = "memory_candidate"
    PREDICTION_ERROR = "prediction_error"
    DRIVE_CHANGE = "drive_change"
    GOAL_EVENT = "goal_event"
    TOOL_RESULT = "tool_result"
    REFLEX_RESULT = "reflex_result"
    BACKGROUND_THOUGHT = "background_thought"
    LEARNING_INTENT = "learning_intent"
    SLEEP_EVENT = "sleep_event"
    QUANTUM_RESULT = "quantum_result"
    RESOURCE_EVENT = "resource_event"

    def __str__(self) -> str:  # stable across 3.11/3.12+ mixin-enum changes
        return self.value


#: Default priority per type. Higher is more urgent. See the module docstring
#: for the band each number belongs to.
DEFAULT_PRIORITY: Mapping[EventType, int] = MappingProxyType({
    # user input
    EventType.USER_MESSAGE: 100,
    EventType.VOICE_FINAL: 100,
    EventType.VOICE_PARTIAL: 95,
    # urgent / safety
    EventType.RESOURCE_EVENT: 90,
    # active work
    EventType.PERCEPTION_CHANGE: 80,
    EventType.TOOL_RESULT: 75,
    EventType.GOAL_EVENT: 70,
    EventType.REFLEX_RESULT: 70,
    # prediction / curiosity
    EventType.PREDICTION_ERROR: 50,
    EventType.MEMORY_CANDIDATE: 40,
    EventType.DRIVE_CHANGE: 40,
    # background
    EventType.BACKGROUND_THOUGHT: 30,
    EventType.LEARNING_INTENT: 30,
    EventType.QUANTUM_RESULT: 30,
    # dreams / consolidation
    EventType.SLEEP_EVENT: 10,
})

#: Largest payload accepted, as UTF-8 bytes of its compact JSON encoding.
#: Frames, audio chunks and images are far past this and must be passed by
#: reference (frame id, path, ring index) instead.
MAX_PAYLOAD_BYTES = 64 * 1024

#: Longest accepted ``source`` string.
MAX_SOURCE_CHARS = 128

#: Runbook 0: user speech/text is the highest normal priority. USER_MESSAGE
#: and VOICE_FINAL must be at or above this; every other type must be below.
USER_PRIORITY_FLOOR = 100
_USER_TYPES_WIRE = frozenset({"user_message", "voice_final"})

_BINARY_TYPES = (bytes, bytearray, memoryview)


class PayloadRejected(ValueError):
    """A payload was refused at the event boundary.

    A ``ValueError``, so callers that only guard ``except ValueError`` still
    catch it, while callers that care can tell it from a malformed-field error.
    """


class PayloadTooLarge(PayloadRejected):
    """The encoded payload exceeds :data:`MAX_PAYLOAD_BYTES`."""


class PayloadNotSerializable(PayloadRejected):
    """The payload is not plain JSON (bytes, ndarray, set, NaN, object, cycle...)."""


def _json_default(obj: Any) -> Any:
    if isinstance(obj, _BINARY_TYPES):
        raise PayloadNotSerializable(
            "event payload carries raw binary data; raw frames and audio must "
            "never enter the cognitive queue - pass a frame id, capture path "
            "or ring-buffer index")
    raise PayloadNotSerializable(
        f"event payload value of type {type(obj).__name__} is not "
        f"JSON-serializable")


def seal_payload(payload: Any) -> "MappingProxyType[str, Any]":
    """JSON round trip plus byte cap.

    Returns a read-only deep copy detached from the producer. Raises
    :class:`PayloadNotSerializable` or :class:`PayloadTooLarge` (both
    ``ValueError``); a non-mapping raises plain ``ValueError``.
    """
    if isinstance(payload, MappingProxyType):
        payload = dict(payload)
    if not isinstance(payload, Mapping):
        raise ValueError(
            f"event payload must be a mapping, got {payload.__class__.__name__}")
    try:
        raw = json.dumps(dict(payload), allow_nan=False, ensure_ascii=False,
                         separators=(",", ":"), default=_json_default)
        # surrogatepass: a lone surrogate in user text never raises here
        size = len(raw.encode("utf-8", "surrogatepass"))
    except PayloadRejected:
        raise
    except (TypeError, ValueError, RecursionError, UnicodeError) as exc:
        raise PayloadNotSerializable(
            f"event payload is not JSON-serializable ({type(exc).__name__})"
        ) from None
    if size > MAX_PAYLOAD_BYTES:
        raise PayloadTooLarge(
            f"event payload is {size} bytes of JSON (limit {MAX_PAYLOAD_BYTES}); "
            f"pass large content by reference")
    return MappingProxyType(json.loads(raw))


@dataclass(frozen=True)
class CognitiveEvent:
    """One thing that happened, as it travels between subsystems.

    Frozen: an event in flight is a historical fact and two consumers must
    never see different versions of it. ``payload`` is wrapped in a
    :class:`~types.MappingProxyType` over a JSON deep copy, so neither the
    producer nor another consumer can change what this consumer sees.

    Deliberately **not** orderable. ``EventBus`` sorts by
    ``(-priority, sequence)``; if a tie ever reached the event itself the
    ordering would become payload-dependent and non-deterministic, so ``<``
    raises ``TypeError`` by construction.
    """

    event_id: str
    type: EventType
    source: str
    priority: int
    created_wall: float
    created_mono: float
    trace_id: str
    parent_event_id: Optional[str]
    deadline_mono: Optional[float]
    salience: float
    requires_response: bool
    payload: Mapping[str, Any]

    def __post_init__(self) -> None:
        # Every construction path lands here: new_event, from_dict, direct
        # construction and dataclasses.replace. Validation cannot be skipped.
        try:
            etype = EventType(self.type)
        except ValueError:
            raise ValueError(
                f"unknown event type {self.type!r}; expected one of "
                f"{sorted(t.value for t in EventType)}") from None
        object.__setattr__(self, "type", etype)
        for name in ("event_id", "trace_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value:
                raise ValueError(f"{name} must be a non-empty string")
        if not isinstance(self.source, str) or not self.source:
            raise ValueError("event source must be a non-empty string")
        if len(self.source) > MAX_SOURCE_CHARS:
            raise ValueError(f"event source longer than {MAX_SOURCE_CHARS} chars")
        object.__setattr__(self, "priority", int(self.priority))
        if etype.value in _USER_TYPES_WIRE:
            if self.priority < USER_PRIORITY_FLOOR:
                raise ValueError(f"{etype.value} priority must be >= {USER_PRIORITY_FLOOR}")
        elif self.priority >= USER_PRIORITY_FLOOR:
            raise ValueError(f"{etype.value} priority must be < {USER_PRIORITY_FLOOR} "
                             f"(only user speech/text may reach user priority)")
        salience = float(self.salience)
        if not math.isfinite(salience):
            raise ValueError("salience must be finite")
        object.__setattr__(self, "salience", salience)
        object.__setattr__(self, "created_wall", float(self.created_wall))
        object.__setattr__(self, "created_mono", float(self.created_mono))
        if self.deadline_mono is not None:
            object.__setattr__(self, "deadline_mono", float(self.deadline_mono))
        if self.parent_event_id is not None and not isinstance(self.parent_event_id, str):
            raise ValueError("parent_event_id must be a string or None")
        object.__setattr__(self, "requires_response", bool(self.requires_response))
        object.__setattr__(self, "payload", seal_payload(self.payload))

    # -- convenience wrappers over the module-level functions ---------------

    def to_dict(self) -> dict:
        """JSON-shaped dict of this event. See :func:`to_dict`."""
        return to_dict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "CognitiveEvent":
        """Rebuild an event from :meth:`to_dict` output. See :func:`from_dict`."""
        return from_dict(data)

    def is_expired(self, now_mono: Optional[float] = None) -> bool:
        """True once ``deadline_mono`` has passed (always False without one)."""
        if self.deadline_mono is None:
            return False
        now = time.monotonic() if now_mono is None else now_mono
        return now >= self.deadline_mono


# ----------------------------------------------------------------------
# factory


def new_event(
    type: "EventType | str",
    source: str,
    payload: Optional[Mapping[str, Any]] = None,
    *,
    priority: Optional[int] = None,
    trace_id: Optional[str] = None,
    parent: "CognitiveEvent | str | None" = None,
    salience: float = 0.0,
    requires_response: bool = False,
    deadline_mono: Optional[float] = None,
    created_wall: Optional[float] = None,
    created_mono: Optional[float] = None,
) -> CognitiveEvent:
    """Build a :class:`CognitiveEvent`, filling in everything mechanical.

    ``event_id`` is a fresh uuid4 hex, ``created_wall`` is :func:`time.time`
    (for logs and humans) and ``created_mono`` is :func:`time.monotonic` (for
    latency and deadlines, immune to clock steps).

    ``priority`` defaults from :data:`DEFAULT_PRIORITY`. Pass one explicitly
    only to express something the type cannot — an ordinary tool result that
    happens to be unblocking a live turn, say.

    ``parent`` accepts either an event or a bare event id. Given an event, the
    child inherits its ``trace_id`` unless one is passed, which is what keeps a
    whole causal chain (voice → perception → goal → tool) under one trace.

    ``created_wall``/``created_mono`` default to now. A publisher that knows
    when the thing actually happened (a WebSocket receive stamp) passes it.

    Raises :class:`PayloadRejected` (a ``ValueError``) if the payload is not
    plain JSON or exceeds :data:`MAX_PAYLOAD_BYTES`.
    """
    try:
        etype = EventType(type)
    except ValueError:
        raise ValueError(
            f"unknown event type {type!r}; expected one of "
            f"{sorted(t.value for t in EventType)}"
        ) from None

    if payload is None:
        payload = {}

    if parent is None:
        parent_id = None
        parent_trace = None
    elif isinstance(parent, CognitiveEvent):
        parent_id = parent.event_id
        parent_trace = parent.trace_id
    elif isinstance(parent, str):
        parent_id = parent
        parent_trace = None
    else:
        raise ValueError(
            "parent must be a CognitiveEvent, an event id, or None, "
            f"got {parent.__class__.__name__}"
        )

    if priority is None:
        priority = DEFAULT_PRIORITY[etype]

    return CognitiveEvent(
        event_id=uuid.uuid4().hex,
        type=etype,
        source=source,
        priority=int(priority),
        created_wall=time.time() if created_wall is None else created_wall,
        created_mono=time.monotonic() if created_mono is None else created_mono,
        trace_id=trace_id or parent_trace or uuid.uuid4().hex,
        parent_event_id=parent_id,
        deadline_mono=deadline_mono,
        salience=salience,
        requires_response=requires_response,
        payload=payload,   # sealed (JSON deep copy) by __post_init__
    )


# ----------------------------------------------------------------------
# serialization boundary


def to_dict(event: CognitiveEvent) -> dict:
    """Plain-dict form of ``event``, ready for ``json.dumps``.

    ``type`` degrades to its wire string and ``payload`` to a plain dict. Note
    that ``created_mono`` is only meaningful inside the process that produced
    it — a monotonic clock has no shared epoch — so a deserialized event's
    ``created_mono`` is history, not something to subtract from the local
    clock. ``created_wall`` is the field to compare across processes.
    """
    return {
        "event_id": event.event_id,
        "type": event.type.value,
        "source": event.source,
        "priority": event.priority,
        "created_wall": event.created_wall,
        "created_mono": event.created_mono,
        "trace_id": event.trace_id,
        "parent_event_id": event.parent_event_id,
        "deadline_mono": event.deadline_mono,
        "salience": event.salience,
        "requires_response": event.requires_response,
        "payload": json.loads(json.dumps(dict(event.payload))),
    }


_REQUIRED_KEYS = (
    "event_id", "type", "source", "priority", "created_wall", "created_mono",
    "trace_id", "payload",
)


def from_dict(data: Mapping[str, Any]) -> CognitiveEvent:
    """Inverse of :func:`to_dict`. Round-trips through JSON unchanged.

    Optional fields (``parent_event_id``, ``deadline_mono``, ``salience``,
    ``requires_response``) may be absent and take their usual defaults, so an
    event written by an older producer still loads.
    """
    if not isinstance(data, Mapping):
        raise ValueError(
            f"event dict must be a mapping, got {data.__class__.__name__}"
        )
    missing = [k for k in _REQUIRED_KEYS if k not in data]
    if missing:
        raise ValueError(f"event dict missing required field(s): {missing}")

    payload = data["payload"]
    if not isinstance(payload, Mapping):
        raise ValueError(
            f"event payload must be a mapping, got {payload.__class__.__name__}"
        )

    try:
        etype = EventType(data["type"])
    except ValueError:
        raise ValueError(f"unknown event type {data['type']!r}") from None

    deadline = data.get("deadline_mono")
    return CognitiveEvent(
        event_id=str(data["event_id"]),
        type=etype,
        source=str(data["source"]),
        priority=int(data["priority"]),
        created_wall=float(data["created_wall"]),
        created_mono=float(data["created_mono"]),
        trace_id=str(data["trace_id"]),
        parent_event_id=data.get("parent_event_id"),
        deadline_mono=None if deadline is None else float(deadline),
        salience=float(data.get("salience", 0.0)),
        requires_response=bool(data.get("requires_response", False)),
        payload=payload,   # sealed by __post_init__
    )


def is_serializable(event: CognitiveEvent) -> bool:
    """True if ``event`` survives a JSON round trip without loss.

    Payloads are sealed as JSON at construction, so this holds for every
    event that exists. It is kept as the explicit check at a process, socket
    or disk boundary.
    """
    try:
        json.dumps(to_dict(event), allow_nan=False)
    except (TypeError, ValueError):
        return False
    return True
