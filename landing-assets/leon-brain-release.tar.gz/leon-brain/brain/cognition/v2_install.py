"""
Build / retire the Leon V2 Phase 2 shadow runtime from ``server.state``.

Kept out of ``server/init_brain.py`` so the boot file carries one small
call, and so the install policy is testable. Stdlib only at import; the V2
modules are imported lazily inside :func:`install_from_server_state`.

Policy (D14): during Phase 2 the runtime is built only when
``LEON_V2_RUNTIME`` is *explicitly* set to ``shadow`` (or ``on``, which runs
shadow). Unset or blank means OFF (``reason=not_opted_in``), so a release
tarball, a tenant copy or a deleted drop-in never runs an unsoaked runtime.
``brain.v2_config`` parsing and its runbook defaults are unchanged; this is
an install-time guard recorded in the migration ledger as a deviation until
the 6.6 gate passes.
"""
from __future__ import annotations

import os
import sys
import threading
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Optional

__all__ = ["install_from_server_state", "install_scheduler_from_server_state",
           "install_provider_from_server_state", "install_speech_from_server_state",
           "install_thought_realizer_from_server_state", "retire_thought_realizer",
           "load_thought_configuration_from_env", "thought_intents_opted_in",
           "load_provider_configuration_from_env",
           "make_user_turn_probe", "flag_explicitly_set"]
_SCHEDULER_INSTALL_LOCK = threading.Lock()
_RUNTIME_INSTALL_LOCK = threading.Lock()
_TASK_INSTALL_LOCK = threading.Lock()
_PREDICTION_DISPATCH_INSTALL_LOCK = threading.Lock()
_PROVIDER_INSTALL_LOCK = threading.Lock()
_SPEECH_INSTALL_LOCK = threading.Lock()
_THOUGHT_INSTALL_LOCK = threading.Lock()
_PROCESS_CLOCK_ID = uuid.uuid4().hex  # one monotonic clock domain for this process


def flag_explicitly_set(env: Mapping[str, str], var: str = "LEON_V2_RUNTIME") -> bool:
    return bool(str(env.get(var, "") or "").strip())


def make_user_turn_probe(state: Any) -> Callable[[], bool]:
    """True while ANY user-turn signal is active. Lock-free attribute reads only.

    Conservative on purpose: the responder lock is also held by daemon turns
    and goal pursuit sets is_processing, so the probe errs toward "busy" and
    a shadow text plan waits longer rather than overlapping a real turn.
    """
    def probe() -> bool:
        rs = getattr(state, "_responder_stats", None) or {}
        if rs.get("is_processing"):
            return True
        lk = getattr(state, "_responder_lock", None)
        if lk is not None and lk.locked():
            return True
        cl = sys.modules.get("brain.conversation_lane")
        cur = getattr(getattr(cl, "GATE", None), "current", None)
        if cur is not None and not cur.is_set():
            return True
        tp = sys.modules.get("server.turn_priority")
        if getattr(getattr(tp, "USER_TURN_GATE", None), "_pending", None):
            return True
        return False
    return probe


def _retire_previous(state: Any) -> bool:
    rt = getattr(state, "cognitive_runtime", None)
    pub = sys.modules.get("brain.cognition.v2_publish")
    if pub is not None:
        try:
            pub.uninstall()
        except Exception as exc:
            print(f"[V2] uninstall failed trace_id=- subsystem=v2.runtime exc={type(exc).__name__} "
                  f"recovery=continuing", flush=True)
    if rt is not None:
        # Phase 7: the thought realizer holds leases on the memory slot. Retire
        # it (quiesce -> stop) before the runtime quiesces/stops MemoryShadow.
        if not retire_thought_realizer(state):
            print("[V2] runtime replacement deferred: thought realization lease still "
                  "draining recovery=retain handles and retry", flush=True)
            return False
        try:
            rt.stop(join_timeout=0.25)
        except Exception as exc:
            print(f"[V2] previous runtime stop failed trace_id=- subsystem=v2.runtime "
                  f"exc={type(exc).__name__} recovery=daemon thread ends with the process",
                  flush=True)
            return False
        # An attached provider is a capability of this exact scheduler. Keep
        # its terminal hook visible until that scheduler cannot dispatch again.
        # Do not couple the independent scheduler to runtimes without providers.
        if (getattr(rt, "providers", None) is not None
                and not getattr(rt, "retirement_complete", lambda: True)()):
            if not _SCHEDULER_INSTALL_LOCK.acquire(timeout=.25):
                return False
            try:
                if not _retire_scheduler(state):
                    return False
            finally:
                _SCHEDULER_INSTALL_LOCK.release()
            rt.stop(join_timeout=.25)
        if not getattr(rt, "retirement_complete", lambda: True)():
            print("[V2] runtime replacement deferred: previous consumer/scene owner "
                  "still retiring recovery=retain handles and retry", flush=True)
            return False
        print("[V2] init_brain re-entered: previous cognitive runtime stopped trace_id=- "
              "subsystem=v2.runtime exc=- recovery=rebuilding", flush=True)
    state.cognitive_runtime = None
    state.cognitive_event_bus = None
    return True


@dataclass(frozen=True)
class _ProviderBinding:
    runtime: Any
    scheduler: Any
    responder: Any
    owner: Any
    config: Any
    mode: str


def _retire_provider_binding(state: Any) -> bool:
    """Caller holds scheduler install lock; never discard a draining facade."""
    if not _PROVIDER_INSTALL_LOCK.acquire(timeout=.25):
        return False
    try:
        binding = getattr(state, "v2_provider_binding", None)
        runtime = binding.runtime if type(binding) is _ProviderBinding else getattr(state, "cognitive_runtime", None)
        owner = getattr(runtime, "providers", None)
        responder = binding.responder if type(binding) is _ProviderBinding else getattr(state, "brain_api_responder", None)
        exposed = getattr(responder, "_v2_provider_hooks", None)
        if binding is not None and (type(binding) is not _ProviderBinding or owner is not binding.owner):
            return False
        if exposed is not None and exposed is not owner:
            return False
        if owner is None:
            return exposed is None
        return runtime.retire_providers() is True
    finally:
        _PROVIDER_INSTALL_LOCK.release()


def _retire_scheduler(state: Any) -> bool:
    mod = sys.modules.get("brain.cognition.inference_scheduler")
    if mod is None and getattr(state, "inference_scheduler", None) is not None:
        print("[V2] scheduler owner module unavailable; replacement refused "
              "subsystem=v2.inference_scheduler recovery=retain previous scheduler", flush=True)
        return False
    if mod is not None:
        try:
            previous = getattr(state, "inference_scheduler", None) or mod.get_scheduler()
            current = mod.get_scheduler()
            binding = getattr(state, "v2_provider_binding", None)
            if binding is not None and (type(binding) is not _ProviderBinding
                    or previous is not binding.scheduler
                    or (current is not None and current is not binding.scheduler)):
                return False
            if previous is not None and current is not None and current is not previous:
                return False
            # Stop selection and cancel only explicitly routed calls before
            # joining the scheduler. Its drain then completes provider scopes.
            providers_retired = _retire_provider_binding(state)
            retired = mod.uninstall(join_timeout=0.25)
            if not providers_retired:
                providers_retired = _retire_provider_binding(state)
            if retired is False or not providers_retired:
                state.inference_scheduler = previous or mod.get_scheduler()
                print("[V2] scheduler replacement deferred: previous worker/ledger still draining "
                      "subsystem=v2.inference_scheduler recovery=retry after current turn finishes",
                      flush=True)
                return False
        except Exception as exc:
            print(f"[V2] scheduler uninstall failed trace_id=- subsystem=v2.inference_scheduler "
                  f"exc={type(exc).__name__} recovery=retain previous scheduler; replacement refused",
                  flush=True)
            return False
    elif not _retire_provider_binding(state):
        return False
    state.inference_scheduler = None
    return True


def install_scheduler_from_server_state(state: Any, *,
                                        environ: Optional[Mapping[str, str]] = None,
                                        sidecar_path: Optional[str] = None) -> Any:
    """Leon V2 Phase 3: build (or not) the inference scheduler. Never raises.

    Policy: built unless LEON_INFERENCE_SCHEDULER is off (runbook default
    shadow). Building it changes nothing by itself: the shadow ledger records
    only while the live flag ``inference_scheduler`` is not off, and a turn
    goes through the scheduler only when ``inference_scheduler.user`` /
    ``.voice`` and ``.inner_voice`` select it. All live flags default to off, so a fresh
    install is legacy-only until the operator flips a flag (no restart).
    Independent of the Phase 2 runtime opt-in (LEON_V2_RUNTIME).
    """
    # Serialize the facade change together with its server.state reference.
    # Refuse concurrent re-entry rather than queueing an unbounded init wait.
    if not _SCHEDULER_INSTALL_LOCK.acquire(timeout=0.5):
        print("[V2] scheduler installation already in progress; replacement deferred", flush=True)
        return None
    try:
        scheduler = _install_scheduler_from_server_state(state, environ=environ, sidecar_path=sidecar_path)
    finally:
        _SCHEDULER_INSTALL_LOCK.release()
    if scheduler is not None:
        # Independent scheduler replacement can reuse a still-running cognitive
        # runtime, but the previous provider binding must already have retired.
        install_provider_from_server_state(state)
    return scheduler


def _install_scheduler_from_server_state(state: Any, *,
                                         environ: Optional[Mapping[str, str]],
                                         sidecar_path: Optional[str]) -> Any:
    env = os.environ if environ is None else environ
    try:
        if not _retire_scheduler(state):
            return None
        from brain.v2_config import load_v2_config, get_v2_config, V2Mode
        try:
            cfg = load_v2_config(env) if environ is not None else get_v2_config()
        except ValueError:
            state.inference_scheduler = None
            print("[V2] inference scheduler OFF reason=invalid_flag trace_id=- "
                  "subsystem=v2.inference_scheduler recovery=legacy-only", flush=True)
            return None
        if cfg.inference_scheduler is V2Mode.OFF:
            print("[V2] inference scheduler OFF reason=LEON_INFERENCE_SCHEDULER=off", flush=True)
            return None
        from brain import v2_live_flags as live
        from brain.cognition import inference_scheduler as isched
        if sidecar_path is None and environ is not None:
            # An explicit environment (tests, tooling) never writes the
            # production sidecar unless it names one.
            sidecar_path = str(environ.get("LEON_V2_SCHED_SIDECAR", "") or "")
        sched = isched.build_for_server_state(state, live=live, sidecar_path=sidecar_path)
        state.inference_scheduler = sched
        flags = live.snapshot()["flags"]
        print("[V2] inference scheduler built (legacy stays authoritative unless a live flag "
              "selects it) " + " ".join(
                  f"{k}={flags.get(k, 'off')}" for k in
                  (isched.LIVE_FEATURE, *isched.GROUP_FEATURES.values())),
              flush=True)
        return sched
    except Exception as exc:
        print(f"[V2] inference scheduler install failed trace_id=- "
              f"subsystem=v2.inference_scheduler exc={type(exc).__name__} "
              f"recovery=legacy-only (scheduler disabled)", flush=True)
        try:
            _retire_scheduler(state)
        except Exception:
            pass
        return None


def install_from_server_state(state: Any, *, environ: Optional[Mapping[str, str]] = None,
                              sidecar_dir: Optional[str] = "/var/log/leon/v2",
                              state_dir: Optional[str] = None) -> Any:
    """Build (or not) the shadow runtime. Never raises; returns it or None.

    ``state_dir`` must be the actual loaded persistence owner's SAVE_DIR. Without
    an explicit absolute path the sensory integration remains unavailable.
    Also builds the Phase 3 scheduler under its independent opt-in policy.
    """
    if not _RUNTIME_INSTALL_LOCK.acquire(timeout=0.5):
        print("[V2] runtime installation already in progress; replacement deferred", flush=True)
        return None
    try:
        return _install_from_server_state(state, environ=environ,
                                          sidecar_dir=sidecar_dir, state_dir=state_dir)
    finally:
        _RUNTIME_INSTALL_LOCK.release()


def _install_from_server_state(state: Any, *, environ: Optional[Mapping[str, str]],
                               sidecar_dir: Optional[str], state_dir: Optional[str]) -> Any:
    env = os.environ if environ is None else environ
    try:
        if not _retire_previous(state):
            state.v2_runtime_reason = "retirement_pending"
            return None
        scheduler = install_scheduler_from_server_state(state, environ=environ)
        if scheduler is None and getattr(state, "inference_scheduler", None) is not None:
            state.v2_runtime_reason = "scheduler_retirement_pending"
            return None
        from brain.v2_config import load_v2_config, get_v2_config, describe_v2_config, V2Mode
        try:
            cfg = load_v2_config(env) if environ is not None else get_v2_config()
        except ValueError as bad:
            state.v2_config = None
            state.v2_runtime_mode = "off"
            state.v2_runtime_reason = "invalid_flag"
            _resume_legacy_speech()
            print(f"[V2] V2 flag invalid trace_id=- subsystem=v2.config exc=ValueError "
                  f"recovery=runtime forced OFF: {bad}", flush=True)
            return None
        state.v2_config = cfg
        # Actual persistence-owner path supplied by init_brain, never guessed.
        state.v2_canonical_roots = ((state_dir,) if isinstance(state_dir, str)
                                    and os.path.isabs(state_dir) else ())
        print(f"[V2] {describe_v2_config(cfg)}", flush=True)
        if not flag_explicitly_set(env):
            state.v2_runtime_mode = "off"
            state.v2_runtime_reason = "not_opted_in"
            _resume_legacy_speech()
            print("[V2] cognitive runtime OFF: publishers are no-ops reason=not_opted_in", flush=True)
            return None
        if cfg.runtime is V2Mode.OFF:
            state.v2_runtime_mode = "off"
            state.v2_runtime_reason = "flag_off"
            _resume_legacy_speech()
            print("[V2] cognitive runtime OFF: publishers are no-ops reason=flag_off", flush=True)
            return None
        if cfg.runtime is V2Mode.ON:
            print("[V2] LEON_V2_RUNTIME=on is not implemented in Phase 2 trace_id=- "
                  "subsystem=v2.runtime exc=- recovery=running SHADOW (legacy stays authoritative)",
                  flush=True)
        from brain import v2_live_flags as live
        from brain.cognition.event_bus import EventBus as CognitiveEventBus
        from brain.cognition.runtime import CognitiveRuntime
        from brain.cognition.sensory_runtime import SensoryRuntime
        from brain.cognition import v2_publish
        bus = CognitiveEventBus()
        rt = CognitiveRuntime(
            cognition=getattr(state, "cognition", None), brain=getattr(state, "brain", None),
            bus=bus, mode="shadow", user_turn_probe=make_user_turn_probe(state),
            sweep_fn=lambda: v2_publish.sweep(state),
            live_mode_fn=lambda: live.live_mode("runtime"),
            sidecar_dir=sidecar_dir)
        rt.sensory = SensoryRuntime(
            state=state, state_dir=state_dir, configured_mode=cfg.sensory_hub.value,
            live_mode=lambda: live.live_mode("sensory_hub"),
            runtime_accepting=lambda: rt.accepting)
        rt.requested_mode = cfg.runtime.value
        state.cognitive_event_bus = bus
        state.cognitive_runtime = rt
        state.v2_runtime_mode = "shadow"
        state.v2_runtime_reason = "opted_in"
        install_speech_from_server_state(state)
        if state.speech_runtime_reason not in ("not_opted_in", "installed_cold"):
            raise RuntimeError("speech lifecycle attachment refused")
        install_prediction_from_server_state(state)
        install_provider_from_server_state(state)
        v2_publish.install(rt)
        rt.start()
        exe = getattr(getattr(state, "cognition", None), "executive", None)
        print("[V2] cognitive runtime started mode=shadow executive="
              + ("yes" if exe is not None else "no")
              + f" live_flags={live.snapshot()['flags']}", flush=True)
        return rt
    except Exception as exc:
        print(f"[V2] runtime install failed trace_id=- subsystem=v2.runtime "
              f"exc={type(exc).__name__} recovery=legacy-only (runtime disabled)", flush=True)
        try:
            if _retire_previous(state):
                _resume_legacy_speech()
        except Exception as exc2:
            print(f"[V2] runtime cleanup failed trace_id=- subsystem=v2.runtime "
                  f"exc={type(exc2).__name__} recovery=publishers remain no-ops", flush=True)
        state.v2_runtime_mode = "off"
        state.v2_runtime_reason = "install_failed"
        return None


def _resume_legacy_speech() -> None:
    # No import or worker creation for an initially disabled runtime.
    queue = sys.modules.get("brain.voice.speech_queue")
    if queue is not None:
        queue.resume_legacy_after_retirement()


def install_speech_from_server_state(state: Any) -> Any:
    """Attach before cold binding; the existing runtime tick selects ON.

    Initial OFF/SHADOW performs no imports and at most a queue metadata probe. A replacement
    can explicitly reopen legacy speech only after the previous owner drained.
    No synthesis, audio stop, model call or extra periodic worker is started.
    """
    if not _SPEECH_INSTALL_LOCK.acquire(timeout=.25):
        return None
    try:
        runtime = getattr(state, "cognitive_runtime", None)
        if runtime is None:
            state.speech_runtime_reason = "owner_unavailable"
            return None
        previous = getattr(runtime, "speech", None)
        if previous is not None and not previous.retired:
            state.speech_runtime = previous
            return previous
        configured = getattr(getattr(getattr(state, "v2_config", None), "speech_arbitration", None), "value", "off")
        loaded_queue = sys.modules.get("brain.voice.speech_queue")
        if configured != "on" and (loaded_queue is None or not loaded_queue.admissions_frozen()):
            state.speech_runtime = None
            state.speech_runtime_reason = "not_opted_in"
            return None
        from brain.cognition.speech_runtime import SpeechRuntime
        from brain.voice import speech_queue
        from brain import v2_live_flags as live
        owner = SpeechRuntime(queue=speech_queue, configured_mode=configured,
            live_mode=lambda: live.live_mode("speech_arbitration"),
            runtime_accepting=lambda: runtime.accepting)
        if not runtime.attach_speech(owner):
            owner.stop()
            state.speech_runtime_reason = "attachment_refused"
            return None
        state.speech_runtime = owner
        try:
            owner.start()
        except Exception:
            owner.quiesce()
            owner.stop()
            state.speech_runtime_reason = "installation_failed_owner_retained"
            raise
        state.speech_runtime_reason = "installed_cold"
        return owner
    finally:
        _SPEECH_INSTALL_LOCK.release()


def install_tasks_from_server_state(state: Any) -> Any:
    """Late optional task pool, rooted in the existing executive and runtime.

    Configuration must already be verified by the trusted confinement builder.
    An absent configuration or authenticated installation identity stays OFF.
    Never infer workspace access from display projects, model text or paths.
    """
    if not _TASK_INSTALL_LOCK.acquire(timeout=.25):
        return None
    try:
        runtime = getattr(state, "cognitive_runtime", None)
        cfg = getattr(state, "v2_config", None)
        mode = getattr(getattr(cfg, "tasks", None), "value", "off")
        if runtime is None or mode != "on":
            state.task_runtime_reason = "not_opted_in"
            return None
        previous = getattr(runtime, "tasks", None)
        if previous is not None and not previous.retired:
            state.task_runtime = previous
            return previous
        from brain.cognition.task_runtime import TaskRuntime, TaskExecutionConfig
        configuration = getattr(state, "task_execution_config", None)
        if configuration is None and os.environ.get("LEON_TASK_CONFIG"):
            try:
                from brain.cognition.task_configuration import load_task_execution_config
                configuration = load_task_execution_config(os.environ["LEON_TASK_CONFIG"],
                    canonical_roots=getattr(state, "v2_canonical_roots", ()))
                state.task_execution_config = configuration
            except Exception:
                state.task_runtime_reason = "task_configuration_unverified"
                return None
        executive = getattr(getattr(state, "cognition", None), "executive", None)
        principal_fn = getattr(sys.modules.get("server"), "installation_principal", None)
        if (type(configuration) is not TaskExecutionConfig or executive is None
                or not callable(principal_fn)):
            state.task_runtime_reason = "verified_configuration_or_identity_missing"
            return None
        from brain import v2_live_flags as live
        owner = TaskRuntime(operational_dir=configuration.operational_dir,
            workspaces=configuration.workspaces, installation_principal=principal_fn(),
            containment_authority=configuration.containment_authority,
            containment_preview=configuration.containment_preview,
            containment_wrapper=configuration.containment_wrapper,
            check_handler_factory=configuration.check_handler_factory,
            planner_configuration=configuration.planner_configuration,
            improvement_configuration=configuration.improvement_configuration,
            proof_check_handler_factory=configuration.proof_check_handler_factory,
            configured_mode=mode, live_mode=lambda: live.live_mode("tasks"))
        # Bind handles before starting workers, so even a partial start failure
        # remains owned and cannot be silently replaced while actions drain.
        if not runtime.attach_tasks(owner):
            owner.stop()
            return None
        state.task_runtime = owner
        if not executive.bind_task_runtime(owner):
            owner.stop()
            state.task_runtime_reason = "previous_executive_task_owner_retiring"
            return None
        try:
            owner.start()
        except Exception:
            owner.quiesce()
            owner.stop(join_timeout=.25)
            state.task_runtime_reason = "installation_failed_owner_retained"
            return None
        state.task_runtime_reason = "installed" if owner.stats()["installed"] else "live_flag_off"
        return owner
    finally:
        _TASK_INSTALL_LOCK.release()


def install_prediction_from_server_state(state: Any) -> Any:
    """Cold singular observer; no model, capture, canonical write or new thread."""
    runtime = getattr(state, "cognitive_runtime", None)
    config = getattr(state, "v2_config", None)
    configured = getattr(getattr(config, "prediction_error", None), "value", "off")
    if runtime is None or configured == "off":
        return None
    previous = getattr(runtime, "prediction", None)
    if previous is not None:
        return previous
    from brain.cognition.prediction_runtime import PredictionRuntime
    from brain.cognition import v2_publish
    from brain import v2_live_flags as live
    owner = PredictionRuntime(clock_id=_PROCESS_CLOCK_ID, configured_mode=configured,
        live_mode=lambda: live.live_mode("prediction_error"),
        runtime_accepting=lambda: runtime.accepting, publish=runtime.publish, budget=None)
    if not v2_publish.install_prediction_owner(owner):
        owner.stop()
        raise RuntimeError("previous prediction owner still bound")
    if not runtime.attach_prediction(owner, release=lambda: v2_publish.uninstall_prediction_owner(owner)):
        owner.stop()
        if not v2_publish.uninstall_prediction_owner(owner):
            raise RuntimeError("prediction callback retirement pending")
        return None
    return owner


def install_prediction_dispatch_from_server_state(state: Any) -> Any:
    """Bind actual tool wrappers after the canonical WorldModel exists.

    This creates no request scopes, predictions, context queries or threads.
    Actual callers still need their explicit identity and measurement scope.
    """
    if not _PREDICTION_DISPATCH_INSTALL_LOCK.acquire(timeout=.25):
        return None
    try:
        runtime = getattr(state, "cognitive_runtime", None)
        observer = getattr(runtime, "prediction", None)
        cognition = getattr(state, "cognition", None)
        world = getattr(cognition, "world_model", None)
        if observer is None or cognition is None or world is None:
            return None
        previous = getattr(observer, "dispatch", None)
        bound = getattr(cognition, "prediction_dispatch", None)
        if previous is not None:
            return previous if bound is previous else None
        if bound is not None and not bound.retired:
            return None
        from brain.cognition.prediction_dispatch import PredictionDispatch
        from brain.cognition import v2_publish
        owner = PredictionDispatch(world_model=world, clock_id=observer.clock_id,
            capture=v2_publish.capture_world_prediction,
            mark_dispatched=v2_publish.mark_prediction_dispatched,
            terminal=v2_publish.emit_prediction_outcome, ready=lambda: observer.ready,
            enabled=True)
        if not observer.attach_dispatch(owner):
            owner.stop()
            return None
        cognition.prediction_dispatch = owner
        return owner
    finally:
        _PREDICTION_DISPATCH_INSTALL_LOCK.release()


def install_memory_from_server_state(state: Any) -> Any:
    """Attach lazy SHADOW reads after canonical initialization; never guess paths."""
    runtime = getattr(state, "cognitive_runtime", None)
    config = getattr(state, "v2_config", None)
    if runtime is None or config is None:
        return None
    previous = getattr(runtime, "memory", None)
    if previous is not None and not previous.retired:
        state.memory_shadow = previous
        held = getattr(state, "thought_configuration", None)
        matches = getattr(previous, "thought_configuration_matches", None)
        if callable(matches) and not matches(None if held is None else held.intent):
            # Never rebind a live owner; a changed binding needs retirement first.
            state.thought_intent_reason = "owner_rebinding_refused"
        return previous
    from brain.cognition.memory_shadow import MemoryShadow
    from brain.context_package import memory_evidence_allowed
    from brain import v2_live_flags as live
    # Phase 7: the explicit thought_intents binding is independent of the
    # SHADOW retrieval mode; absent opt-in/configuration leaves it unselected.
    thought: dict = {}
    configuration = load_thought_configuration_from_env(state)
    principal_fn = getattr(sys.modules.get("server"), "installation_principal", None)
    if configuration is not None and callable(principal_fn):
        thought = dict(
            thought_intent_config=configuration.intent,
            thought_intent_requested=lambda: live.live_mode("thought_intents") in ("shadow", "on"),
            thought_principal=principal_fn)
    owner = MemoryShadow(state=state, configured_mode=config.memory_service.value,
                         live_mode=lambda: live.live_mode("memory_service"),
                         runtime_accepting=lambda: runtime.accepting,
                         authorize=memory_evidence_allowed,
                         telemetry=runtime.record_memory_telemetry, **thought)
    if not runtime.attach_memory(owner):
        owner.quiesce()
        owner.stop(join_timeout=0)
        return None
    state.memory_shadow = owner
    return owner


def thought_intents_opted_in(env: Mapping[str, str]) -> bool:
    """Phase 7 env opt-in: only the literal ``LEON_THOUGHT_INTENTS=on`` selects it."""
    return str(env.get("LEON_THOUGHT_INTENTS", "") or "").strip().lower() == "on"


def load_thought_configuration_from_env(state: Any, *,
                                        environ: Optional[Mapping[str, str]] = None) -> Any:
    """Read ``LEON_THOUGHT_INTENT_CONFIG`` only after the env opt-in. Never raises.

    The typed configuration is retained on ``state.thought_configuration`` and
    reused; it is loaded with the trusted installation principal. A missing
    or invalid selected configuration leaves the selected path unavailable
    (``state.thought_intent_reason``) without any legacy retry.
    """
    env = os.environ if environ is None else environ
    held = getattr(state, "thought_configuration", None)
    if held is not None:
        return held
    if not thought_intents_opted_in(env):
        state.thought_intent_reason = "not_opted_in"
        return None
    path = str(env.get("LEON_THOUGHT_INTENT_CONFIG", "") or "")
    principal_fn = getattr(sys.modules.get("server"), "installation_principal", None)
    if not path or not callable(principal_fn):
        state.thought_intent_reason = "configuration_or_identity_missing"
        return None
    try:
        from brain.cognition.thought_configuration import load_thought_configuration
        configuration = load_thought_configuration(path, installation_principal=principal_fn())
    except Exception as exc:
        state.thought_intent_reason = "configuration_unverified"
        print(f"[V2] thought configuration unverified exc={type(exc).__name__} "
              "recovery=selected thought path unavailable; no legacy retry", flush=True)
        return None
    state.thought_configuration = configuration
    state.thought_intent_reason = "configured"
    return configuration


def _local_thought_budget(state: Any, scheduler: Any) -> Callable[[], bool]:
    """Bounded trusted budget probe: scheduler alive and the local transport usable."""
    def available() -> bool:
        if not scheduler.alive():
            return False
        local = sys.modules.get("brain.local_llm")
        if local is None or getattr(local, "LOCAL_LLM_MODE", "off") == "off":
            return False
        return local.is_available() is True
    return available


def install_thought_realizer_from_server_state(state: Any) -> Any:
    """Phase 7: build the cold ThoughtRealizer once scheduler, responder, memory
    owner and InnerVoice exist, and attach it to that InnerVoice instance.

    No lease, model call, flag effect or thread. The live flag ``thought_intents``
    (off/shadow/on) decides at each thought; legacy stays authoritative when off.
    """
    if not _THOUGHT_INSTALL_LOCK.acquire(timeout=.25):
        return None
    try:
        runtime = getattr(state, "cognitive_runtime", None)
        memory = getattr(runtime, "memory", None)
        scheduler = getattr(state, "inference_scheduler", None)
        responder = getattr(state, "brain_api_responder", None)
        voice = getattr(state, "inner_voice", None)
        configuration = getattr(state, "thought_configuration", None)
        previous = getattr(state, "thought_realizer", None)
        if previous is not None and not previous.retired:
            if getattr(voice, "_v2_thought_realizer", None) is previous:
                return previous
            state.thought_realizer_reason = "binding_mismatch"
            return None
        if configuration is None:
            state.thought_realizer_reason = "not_opted_in"
            return None
        if runtime is None or memory is None or scheduler is None or responder is None or voice is None:
            state.thought_realizer_reason = "owners_unavailable"
            return None
        from brain.cognition.thought_configuration import ThoughtConfiguration
        if (type(configuration) is not ThoughtConfiguration
                or memory.retired or not memory.thought_configuration_matches(configuration.intent)):
            state.thought_realizer_reason = "memory_owner_unbound"
            return None
        principal_fn = getattr(sys.modules.get("server"), "installation_principal", None)
        if not callable(principal_fn):
            state.thought_realizer_reason = "identity_missing"
            return None
        if getattr(voice, "_v2_thought_realizer", None) is not None:
            state.thought_realizer_reason = "voice_already_bound"
            return None
        from brain.cognition.thought_realization import ThoughtRealizer
        from brain import v2_live_flags as live
        owner = ThoughtRealizer(memory_owner=memory, configuration=configuration,
                                scheduler=scheduler, responder=responder,
                                foreground_busy=make_user_turn_probe(state),
                                local_budget_available=_local_thought_budget(state, scheduler),
                                live_mode=live.live_mode, principal=principal_fn)
        voice._v2_thought_realizer = owner
        state.thought_realizer = owner
        state.thought_realizer_reason = "installed_cold"
        return owner
    except Exception as exc:
        state.thought_realizer_reason = "installation_failed"
        print(f"[V2] thought realizer installation failed exc={type(exc).__name__} "
              "recovery=legacy inner voice stays authoritative", flush=True)
        return None
    finally:
        _THOUGHT_INSTALL_LOCK.release()


def retire_thought_realizer(state: Any) -> bool:
    """Quiesce then stop the realizer; False while its memory lease still drains."""
    owner = getattr(state, "thought_realizer", None)
    if owner is None:
        return True
    try:
        owner.quiesce()
        if not owner.stop():
            return False
    except Exception as exc:
        print(f"[V2] thought realizer retirement failed exc={type(exc).__name__} "
              "recovery=retain handle; retry", flush=True)
        return False
    voice = getattr(state, "inner_voice", None)
    if getattr(voice, "_v2_thought_realizer", None) is owner:
        voice._v2_thought_realizer = None
    state.thought_realizer = None
    state.thought_realizer_reason = "retired"
    return True


def load_provider_configuration_from_env(state: Any, *,
                                         environ: Optional[Mapping[str, str]] = None) -> Any:
    """Read ``LEON_PROVIDER_CONFIG`` only after the ``LEON_PROVIDER_ROUTER`` opt-in.
    Never raises.

    The env opt-in is the parsed ``provider_router`` flag (``shadow``/``on``;
    ``brain.v2_config`` accepts no other enabled spelling). The typed
    configuration is retained on ``state.v2_provider_config`` and reused. A
    missing or invalid file leaves the hook uninstalled, so the baseline
    transport is unchanged; nothing is guessed and no credential is read
    except by the NAME the file declares. ``state.v2_provider_config_reason``
    keeps the loader outcome after the installer records its own reason.
    """
    env = os.environ if environ is None else environ
    held = getattr(state, "v2_provider_config", None)
    if held is not None:
        return held

    def outcome(reason: str) -> None:
        state.v2_provider_reason = reason
        state.v2_provider_config_reason = reason

    try:
        from brain.v2_config import load_v2_config, V2Mode
        cfg = getattr(state, "v2_config", None)
        configured = (cfg.provider_router if cfg is not None
                      else load_v2_config(env).provider_router)
        if V2Mode(configured) is V2Mode.OFF:
            outcome("not_opted_in")
            return None
    except ValueError:
        outcome("invalid_flag")
        return None
    path = str(env.get("LEON_PROVIDER_CONFIG", "") or "")
    roots = tuple(getattr(state, "v2_canonical_roots", None) or ())
    if not path:
        outcome("configuration_missing")
        return None
    if not roots:
        outcome("canonical_roots_unavailable")
        return None
    try:
        from brain.cognition.provider_configuration import load_provider_configuration
        configuration = load_provider_configuration(path, environ=env, canonical_roots=roots)
    except Exception as exc:
        outcome("configuration_unverified")
        print(f"[V2] provider configuration unverified exc={type(exc).__name__} "
              "recovery=provider hook not installed; baseline transport unchanged", flush=True)
        return None
    state.v2_provider_config = configuration
    outcome("configured" if all(getattr(adapter, "configured", False) is True
                                for adapter in configuration.adapters)
            else "configured_credential_missing")
    print("[V2] provider configuration loaded reason=" + state.v2_provider_reason
          + f" routes={len(configuration.routes)}", flush=True)
    return configuration


def install_provider_from_server_state(state: Any) -> Any:
    """Bind typed operator configuration to exact existing runtime/caller owners.

    No credential discovery, provider construction, flag read, ledger open or
    model call occurs here. The existing runtime tick owns activation. Lock
    order matches scheduler replacement: scheduler, provider, runtime ownership.
    Absent typed configuration is loaded once from the trusted operator file
    (env opt-in required); the loader never raises into startup.
    """
    if not _SCHEDULER_INSTALL_LOCK.acquire(timeout=.25):
        return None
    try:
        if not _PROVIDER_INSTALL_LOCK.acquire(timeout=.25):
            return None
        try:
            if getattr(state, "v2_provider_config", None) is None:
                load_provider_configuration_from_env(state)
            runtime = getattr(state, "cognitive_runtime", None)
            scheduler = getattr(state, "inference_scheduler", None)
            responder = getattr(state, "brain_api_responder", None)
            configured = getattr(getattr(getattr(state, "v2_config", None), "provider_router", None), "value", "off")
            config = getattr(state, "v2_provider_config", None)
            previous = getattr(state, "v2_provider_binding", None)
            if previous is not None:
                if type(previous) is not _ProviderBinding:
                    state.v2_provider_reason = "binding_unavailable"
                    return None
                if getattr(previous.runtime, "providers", None) is not previous.owner:
                    state.v2_provider_reason = "binding_mismatch"
                    return None
                same = (previous.runtime is runtime and previous.scheduler is scheduler
                        and previous.responder is responder and previous.config is config
                        and previous.mode == configured)
                if same and not previous.owner.retired:
                    if (runtime.providers is previous.owner
                            and getattr(responder, "_v2_provider_hooks", None) is previous.owner):
                        return previous.owner
                    state.v2_provider_reason = "binding_mismatch"
                    return None
                if not previous.runtime.retire_providers():
                    state.v2_provider_reason = "retirement_pending"
                    return None
            if configured == "off":
                state.v2_provider_reason = "not_opted_in"
                return None
            if runtime is None or scheduler is None or responder is None:
                state.v2_provider_reason = "owners_unavailable"
                return None
            from brain.cognition.provider_hooks import ProviderHooks, ProviderHookConfig
            from brain.cognition import inference_scheduler as isched
            if type(config) is not ProviderHookConfig:
                state.v2_provider_reason = "typed_config_unavailable"
                return None
            if isched.get_scheduler() is not scheduler:
                state.v2_provider_reason = "scheduler_binding_mismatch"
                return None
            if getattr(responder, "_v2_provider_hooks", None) is not None:
                state.v2_provider_reason = "responder_already_bound"
                return None
            from brain import v2_live_flags as live
            owner = ProviderHooks(scheduler=scheduler, config=config,
                configured_mode=configured, live_mode=lambda: live.live_mode("provider_router"),
                runtime_accepting=lambda: runtime.accepting)
            binding = _ProviderBinding(runtime, scheduler, responder, owner, config, configured)

            def publish():
                if (getattr(state, "cognitive_runtime", None) is not runtime
                        or getattr(state, "inference_scheduler", None) is not scheduler
                        or getattr(state, "brain_api_responder", None) is not responder
                        or getattr(responder, "_v2_provider_hooks", None) is not None):
                    raise RuntimeError("provider owner changed before publication")
                state.v2_provider_binding = binding
                state.provider_hooks = owner
                responder._v2_provider_hooks = owner

            def release():
                # Queued work must still encounter the terminal attachment.
                # Ledger cleanup alone does not end scheduler admission.
                if scheduler.worker_alive() or isched.get_scheduler() is scheduler:
                    return False
                if getattr(responder, "_v2_provider_hooks", None) is owner:
                    responder._v2_provider_hooks = None
                if getattr(state, "provider_hooks", None) is owner:
                    state.provider_hooks = None
                if getattr(state, "v2_provider_binding", None) is binding:
                    state.v2_provider_binding = None
                return True

            if not runtime.attach_providers(owner, publish=publish, release=release):
                owner.quiesce()
                if runtime.providers is owner:
                    runtime.retire_providers()
                else:
                    owner.stop(timeout=0)
                state.v2_provider_reason = "attachment_refused"
                return None
            state.v2_provider_reason = "installed_cold"
            return owner
        except Exception as exc:
            state.v2_provider_reason = "installation_failed"
            print(f"[V2] provider installation failed exc={type(exc).__name__} "
                  "recovery=retain owned binding; no provider activation", flush=True)
            return None
        finally:
            _PROVIDER_INSTALL_LOCK.release()
    finally:
        _SCHEDULER_INSTALL_LOCK.release()
