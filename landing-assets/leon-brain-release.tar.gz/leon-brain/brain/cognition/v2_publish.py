"""
The single publish helper for the Leon V2 Phase 2 event fabric (SHADOW).

Every publisher site in the legacy code calls exactly one function,
:func:`emit`, fetched lazily with ``sys.modules.get(...)`` so that when the
runtime is OFF this module is never even imported and a site costs a dict
lookup. ``emit`` never raises, never blocks, never awaits and never calls a
model, a tool, the network or the SNN. It turns the site's local variables
into a small, allow-listed, JSON-only payload and offers one or two events to
the runtime.

Privacy and boundedness
-----------------------
* User text travels only inside the in-memory USER_MESSAGE / VOICE_FINAL
  event, capped at :data:`TEXT_MAX_CHARS`. Everything recorded downstream
  (decisions, sidecar, logs) carries ``text_sha1`` and ``chars`` only.
* Ambient speech overheard by the audio daemon is sha1 + length only.
* Builders read the objects they are handed synchronously via ``getattr``;
  they never keep a reference, and they never read media (no ``image_b64``,
  no ``pcm16``, no frame bytes).
* Every rate/edge gate dict is capped at :data:`_MAX_GATE_KEYS` keys.
"""
from __future__ import annotations

import hashlib
import itertools
import logging
import math
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, Iterable, List, Optional

from .events import EventType, PayloadRejected, new_event

log = logging.getLogger("leon.v2.publish")

__all__ = ["install", "uninstall", "get_runtime", "emit", "sweep", "stats", "SITES",
           "install_prediction_owner", "uninstall_prediction_owner", "prediction_capture_ready",
           "capture_prediction", "capture_world_prediction", "mark_prediction_dispatched",
           "emit_prediction_outcome"]

TEXT_MAX_CHARS = 8000
CAPTION_MAX_CHARS = 160
SHORT_MAX_CHARS = 300
PUBLISH_HIGH_WATER = 256
_ALWAYS_PUBLISH = frozenset({EventType.USER_MESSAGE, EventType.VOICE_FINAL,
                             EventType.VOICE_PARTIAL, EventType.RESOURCE_EVENT})
_MAX_GATE_KEYS = 256
FAIL_LOG_INTERVAL_S = 60.0
WEBCAM_STALE_S = 180.0
#: Legacy retrospective prediction-error rule (D15), pinned to the literal in
#: loop.record_tool_call. A registered prospective ticket suppresses this child;
#: the single runtime observer then owns the standardized PE for that ticket.
PE_SURPRISE_THRESHOLD = 0.25
TOOL_SURPRISE_THRESHOLD = PE_SURPRISE_THRESHOLD
GATE_LOCK_TIMEOUT_S = 0.005
EMIT_LATENCY_WINDOW = 512
TOOL_PERSIST_N = 3
TOOL_PERSIST_WINDOW_S = 3600.0
_LOOPBACK = frozenset({"127.0.0.1", "::1", "localhost"})

_runtime: Any = None
_prediction_owner: Any = None
_prediction_owner_lock = threading.Lock()
_lock = threading.Lock()
_counters: Dict[str, int] = {}
_site_counts: Dict[str, Dict[str, int]] = {}
_edge: Dict[str, Any] = {}
_edge_ts: Dict[str, float] = {}
_last: Dict[str, float] = {}
_fail_last: Dict[str, float] = {}
_fail_suppressed: Dict[str, int] = {}
_tool_surprises: Dict[str, Deque[float]] = {}
_tls = threading.local()
_lat: Dict[str, Deque[float]] = {}
_counter_lock_timeouts = itertools.count()
_stall_warned = [0.0]
_consolidation = {"last_published": None}
_webcam: Dict[str, Any] = {"ts": None, "changed_mono": None, "streaming": None,
                           "res": None, "ready": None}


@dataclass(frozen=True)
class _Spec:
    etype: EventType
    source: str
    payload: Dict[str, Any]
    priority: Optional[int] = None
    salience: float = 0.0
    requires_response: bool = False
    created: Optional[tuple] = None        # (wall, mono)
    coalesce_key: Optional[str] = None
    rate_key: Optional[str] = None
    min_interval_s: float = 0.0
    edge_key: Optional[str] = None
    edge_value: Any = None
    hold_down_s: float = 0.0
    link_parent: bool = False
    on_published: Optional[Callable[[], None]] = None
    trace_id: Optional[str] = None


# ----------------------------------------------------------------------
# install / stats


def install(runtime: Any) -> None:
    global _runtime
    _runtime = runtime


def uninstall() -> None:
    global _runtime
    _runtime = None


def get_runtime() -> Any:
    return _runtime


def install_prediction_owner(owner: Any) -> bool:
    """Cold callback binding only. Never replace an active/draining PE owner."""
    global _prediction_owner
    if owner is None or getattr(owner, "retired", True) or not _prediction_owner_lock.acquire(False):
        return False
    try:
        if _prediction_owner is not None and _prediction_owner is not owner:
            return False
        _prediction_owner = owner
        return True
    finally:
        _prediction_owner_lock.release()


def uninstall_prediction_owner(owner: Any) -> bool:
    global _prediction_owner
    if not getattr(owner, "retired", False) or not _prediction_owner_lock.acquire(False):
        return False
    try:
        if _prediction_owner is not owner:
            return False
        _prediction_owner = None
        return True
    finally:
        _prediction_owner_lock.release()


def prediction_capture_ready() -> bool:
    owner = _prediction_owner
    return owner is not None and owner.ready


def capture_prediction(prediction: Any) -> Any:
    owner = _prediction_owner
    return owner.capture(prediction) if owner is not None else None


def capture_world_prediction(prediction: Any, **identity: Any) -> Any:
    """Already-computed forecast only; this helper never calls a model."""
    owner = _prediction_owner
    return owner.capture_world(prediction, **identity) if owner is not None else None


def mark_prediction_dispatched(ticket: Any, *, action_started_mono: float) -> bool:
    if ticket is None:
        return False
    from .prediction_runtime import PredictionTicket
    return (isinstance(ticket, PredictionTicket) and
            ticket._prediction_owner.mark_dispatched(ticket, action_started_mono=action_started_mono))


def _prediction_outcome(ticket: Any, **fields: Any) -> Any:
    if ticket is None:
        return None
    from .prediction_runtime import PredictionTicket
    if not isinstance(ticket, PredictionTicket):
        return None
    return ticket._prediction_owner.project_outcome(ticket, **fields)


def _prediction_parent(ticket: Any) -> bool:
    if ticket is None:
        return False
    from .prediction_runtime import PredictionRuntime, PredictionTicket
    return (type(ticket) is PredictionTicket and
            type(ticket._prediction_owner) is PredictionRuntime and
            ticket._prediction_owner.owns_ticket(ticket))


def emit_prediction_outcome(ticket: Any, **fields: Any) -> bool:
    """Standalone terminal hook for cancellation/missing/non-episode results."""
    return emit("prediction.outcome", ticket=ticket, **fields)


def _count(name: str, site: Optional[str] = None) -> None:
    # Bounded wait: a publisher may be the main thread (SIGUSR1 handler).
    if not _lock.acquire(timeout=GATE_LOCK_TIMEOUT_S):
        next(_counter_lock_timeouts)
        return
    try:
        _counters[name] = _counters.get(name, 0) + 1
        if site is not None:
            if site not in _site_counts and len(_site_counts) >= 64:
                site = "_other"
            sc = _site_counts.setdefault(site, {})
            sc[name] = sc.get(name, 0) + 1
    finally:
        _lock.release()


def _lat_pct(values: List[float]) -> Dict[str, Any]:
    if not values:
        return {"n": 0, "p50_us": None, "p99_us": None, "max_us": None}
    v = sorted(values)
    n = len(v)
    return {"n": n, "p50_us": round(v[n // 2] * 1e6, 1),
            "p99_us": round(v[min(n - 1, int(0.99 * (n - 1) + 0.5))] * 1e6, 1),
            "max_us": round(v[-1] * 1e6, 1)}


def stats() -> Dict[str, Any]:
    with _lock:
        out = {"installed": _runtime is not None,
               "counters": dict(_counters),
               "by_site": {k: dict(v) for k, v in _site_counts.items()},
               "gate_keys": {"edge": len(_edge), "rate": len(_last),
                             "tools": len(_tool_surprises)}}
    lat = {site: _lat_pct(list(dq)) for site, dq in list(_lat.items())}
    out["emit_latency"] = lat
    p99s = [v["p99_us"] for v in lat.values() if v["p99_us"] is not None]
    out["emit_p99_us"] = max(p99s) if p99s else None
    # itertools.count has no public read; its repr is "count(N)"
    out["counter_lock_timeouts"] = int(repr(_counter_lock_timeouts)[6:-1])
    return out


def _report(site: str, trace_id: str, exc: BaseException) -> None:
    now = time.monotonic()
    _count("failed", site)
    if not _lock.acquire(timeout=GATE_LOCK_TIMEOUT_S):
        next(_counter_lock_timeouts)
        return
    try:
        last = _fail_last.get(site)
        if last is not None and now - last < FAIL_LOG_INTERVAL_S:
            _fail_suppressed[site] = _fail_suppressed.get(site, 0) + 1
            return
        _fail_last[site] = now
        n = _fail_suppressed.pop(site, 0)
    finally:
        _lock.release()
    detail = f" detail={str(exc)[:160]}" if isinstance(exc, PayloadRejected) else ""
    log.warning("[V2] publish failed trace_id=%s subsystem=v2.publish.%s exc=%s%s "
                "recovery=shadow event dropped; legacy path unaffected (suppressed=%d)",
                trace_id, site, type(exc).__name__, detail, n)


# ----------------------------------------------------------------------
# emit


def emit(site: str, /, **fields: Any) -> bool:
    """THE publisher entry point. Never raises; never blocks (bounded lock waits)."""
    rt = _runtime
    if rt is None:
        return False
    if getattr(_tls, "active", False):      # signal handler / nested call on this thread
        _count("reentrant_skip", site)
        return False
    _tls.active = True
    t0 = time.perf_counter()
    trace = "-"
    try:
        if not rt.accepting:
            _count("refused_not_accepting", site)
            _note_stall(rt)
            return False
        builder = SITES.get(site)
        if builder is None:
            _count("unknown_site", site)
            _report(site, trace, LookupError(site))
            return False
        parent = None
        any_ok = False
        for spec in builder(fields):
            ev = _publish(rt, spec, parent if spec.link_parent else None, site)
            if ev is not None:
                any_ok = True
                parent = ev
                trace = ev.trace_id
        return any_ok
    except Exception as exc:
        _report(site, trace, exc)
        return False
    finally:
        _tls.active = False
        dq = _lat.get(site)
        if dq is None and len(_lat) < 64:
            dq = _lat.setdefault(site, deque(maxlen=EMIT_LATENCY_WINDOW))
        if dq is not None:
            dq.append(time.perf_counter() - t0)


def _note_stall(rt: Any) -> None:
    if not getattr(rt, "stalled", False):
        return
    _count("stalled_refusals")
    now = time.monotonic()
    if now - _stall_warned[0] >= FAIL_LOG_INTERVAL_S:
        _stall_warned[0] = now
        log.warning("[V2] runtime not accepting trace_id=- subsystem=v2.publish "
                    "exc=RuntimeNotAccepting recovery=publishers refusing until the worker "
                    "beats again; legacy unaffected")


def _gate_room(d: Dict[str, Any]) -> None:
    if len(d) > _MAX_GATE_KEYS:
        d.clear()
        _counters["gate_resets"] = _counters.get("gate_resets", 0) + 1


def _publish(rt: Any, spec: _Spec, parent: Any, site: str) -> Any:
    now = time.monotonic()
    if not _lock.acquire(timeout=GATE_LOCK_TIMEOUT_S):
        _count("gate_lock_timeouts", site)
        return None
    try:
        if spec.edge_key is not None:
            if spec.edge_key in _edge and _edge[spec.edge_key] == spec.edge_value:
                skip = "skipped_edge"
            elif (spec.hold_down_s > 0 and spec.edge_key in _edge_ts
                  and now - _edge_ts[spec.edge_key] < spec.hold_down_s):
                skip = "skipped_holddown"
            else:
                skip = None
        else:
            skip = None
        if skip is None and spec.rate_key is not None and spec.min_interval_s > 0:
            last = _last.get(spec.rate_key)
            if last is not None and now - last < spec.min_interval_s:
                skip = "skipped_rate"
    finally:
        _lock.release()
    if skip is not None:
        _count(skip, site)
        return None
    if spec.etype not in _ALWAYS_PUBLISH:
        if rt.bus_depth() > PUBLISH_HIGH_WATER:
            _count("skipped_depth", site)
            return None
        if not rt.consumer_alive():
            _count("skipped_consumer", site)
            return None
    payload = dict(spec.payload)
    if spec.coalesce_key is not None:
        payload["coalesce_key"] = spec.coalesce_key
    kw: Dict[str, Any] = {}
    if spec.created is not None:
        kw["created_wall"], kw["created_mono"] = spec.created
    ev = new_event(spec.etype, spec.source, payload, priority=spec.priority,
                   parent=parent, salience=spec.salience,
                   requires_response=spec.requires_response, trace_id=spec.trace_id, **kw)
    if not rt.publish(ev):
        _count("refused", site)
        return None
    if _lock.acquire(timeout=GATE_LOCK_TIMEOUT_S):
        try:
            if spec.edge_key is not None:
                _gate_room(_edge)
                _gate_room(_edge_ts)
                _edge[spec.edge_key] = spec.edge_value
                _edge_ts[spec.edge_key] = now
            if spec.rate_key is not None:
                _gate_room(_last)
                _last[spec.rate_key] = now
        finally:
            _lock.release()
    else:
        _count("gate_lock_timeouts", site)
    if spec.on_published is not None:
        try:
            spec.on_published()
        except Exception as exc:
            _report(site, ev.trace_id, exc)
    _count("published", site)
    return ev


# ----------------------------------------------------------------------
# helpers


def _text(s: Any, cap: int = TEXT_MAX_CHARS) -> Dict[str, Any]:
    """Surrogate-safe: a lone surrogate is repaired (lossy=True), never dropped."""
    s = s if isinstance(s, str) else ("" if s is None else str(s))
    repaired = s.encode("utf-8", "replace").decode("utf-8")
    return {"text": repaired[:cap], "chars": len(s), "truncated": len(s) > cap,
            "lossy": repaired != s,
            "text_sha1": hashlib.sha1(s.encode("utf-8", "surrogatepass")).hexdigest()[:12]}


def _sha(s: Any) -> Dict[str, Any]:
    s = s if isinstance(s, str) else ("" if s is None else str(s))
    return {"chars": len(s),
            "text_sha1": hashlib.sha1(s.encode("utf-8", "surrogatepass")).hexdigest()[:12]}


def _clip(x: Any, n: int) -> Optional[str]:
    return None if x is None else str(x)[:n]


def _num(x: Any, nd: int = 4) -> Optional[float]:
    try:
        f = float(x)
    except (TypeError, ValueError):
        return None
    return round(f, nd) if math.isfinite(f) else None


def _int(x: Any) -> Optional[int]:
    try:
        return int(x)
    except (TypeError, ValueError):
        return None


def _created(received: Any) -> Optional[tuple]:
    if isinstance(received, tuple) and len(received) == 2:
        w, m = _num(received[0], 6), _num(received[1], 6)
        if w is not None and m is not None:
            return (w, m)
    return None


# ----------------------------------------------------------------------
# builders: fields -> [_Spec]


def _b_ws_text_input(f: Dict[str, Any]) -> List[_Spec]:
    text = f.get("text")
    if not isinstance(text, str):
        return []
    ws = f.get("ws")
    host = None
    try:
        host = getattr(getattr(ws, "client", None), "host", None)
    except Exception:
        host = None
    if text.startswith("[Discord DM] "):
        channel = "discord"
    elif host in _LOOPBACK:
        channel = "loopback_ws"
    else:
        channel = "dashboard"
    created = _created(f.get("received"))
    payload = {**_text(text), "channel": channel,
               "ws_client": f"{id(ws):x}" if ws is not None else None,
               "client_host": _clip(host, 64),
               "has_attachment": "[Attached file:" in text,
               "session_id": "default",
               "received_wall": created[0] if created else None}
    return [_Spec(EventType.USER_MESSAGE, "ws", payload, requires_response=True,
                  created=created)]


def _b_voice_accepted(f: Dict[str, Any]) -> List[_Spec]:
    text = f.get("text")
    if not isinstance(text, str):
        return []
    src = str(f.get("source") or "voice")[:32]
    created = _created(f.get("received"))
    payload = {**_text(text), "voice_source": src, "path": "handle_voice_utterance",
               "captured_ts": _num(f.get("captured_ts"), 3),
               "received_wall": created[0] if created else None,
               "gate_reason": _clip(f.get("gate_reason"), 64),
               "gate_overlap": _num(f.get("gate_overlap"), 3)}
    return [_Spec(EventType.VOICE_FINAL, f"voice.{src}", payload,
                  requires_response=True, created=created)]


def _b_wake_orch_accepted(f: Dict[str, Any]) -> List[_Spec]:
    text = f.get("text")
    if not isinstance(text, str) or not text:
        return []
    cap = f.get("capture")
    res = f.get("result")
    payload = {**_text(text), "path": "wake_orchestrator",
               "stt_confidence": _num(getattr(res, "confidence", None), 3),
               "duration_s": _num(getattr(cap, "duration_s", None), 2),
               "wake_word": _clip(getattr(cap, "wake_word", None), 40),
               "push_to_talk": bool(getattr(cap, "push_to_talk", False))}
    return [_Spec(EventType.VOICE_FINAL, "voice.wake_orchestrator", payload,
                  requires_response=True)]


def _b_audio_daemon_heard(f: Dict[str, Any]) -> List[_Spec]:
    addressed = bool(f.get("addressed"))
    payload = {"kind": "speech_heard", "addressed": addressed,
               "duration_s": _num(f.get("duration"), 2), **_sha(f.get("text"))}
    return [_Spec(EventType.PERCEPTION_CHANGE, "audio_daemon", payload,
                  priority=80 if addressed else 40, rate_key="audio_daemon.heard",
                  min_interval_s=2.0)]


def _b_perception_floors_alerts(f: Dict[str, Any]) -> List[_Spec]:
    alerts = [str(a)[:120] for a in list(f.get("alerts") or [])[:5]]
    was, is_ = f.get("was_present"), f.get("is_present")
    b0, b1 = _num(f.get("prev_brightness")), _num(f.get("brightness"))
    payload = {"kind": "alert_batch", "alerts": alerts,
               "alert_count": len(f.get("alerts") or []),
               "presence_changed": (was is not None and is_ is not None and bool(was) != bool(is_)),
               "dean_present": None if is_ is None else bool(is_),
               "emotion": _clip(f.get("emotion"), 40),
               "brightness_delta": (round(b1 - b0, 4) if b0 is not None and b1 is not None else None),
               "activity_mode": _clip(f.get("activity_mode"), 40),
               "new_object_count": len(f.get("new_objects") or ())}
    return [_Spec(EventType.PERCEPTION_CHANGE, "perception_floors", payload,
                  priority=80, coalesce_key="alerts")]


def _b_vision_daemon_observation(f: Dict[str, Any]) -> List[_Spec]:
    src = str(f.get("source") or "screen")[:32]
    payload = {"kind": "caption", "caption": _clip(f.get("caption"), CAPTION_MAX_CHARS),
               "diff_score": _num(f.get("diff_score")), "needs_interpretation": False}
    return [_Spec(EventType.PERCEPTION_CHANGE, f"vision_daemon.{src}", payload,
                  priority=40, coalesce_key="caption",
                  rate_key=f"vision_daemon.{src}", min_interval_s=30.0)]


def _b_relay_perception(f: Dict[str, Any]) -> List[_Spec]:
    novelty = _num(f.get("novelty")) or 0.0
    if novelty < 0.55:
        return []
    src = str(f.get("source") or "unknown")[:32]
    salient = novelty >= 0.8
    kind = "salient" if salient else "caption_turnover"
    payload = {"kind": kind, "caption": _clip(f.get("caption"), CAPTION_MAX_CHARS),
               "novelty": novelty, "needs_interpretation": salient}
    return [_Spec(EventType.PERCEPTION_CHANGE, f"relay.{src}", payload,
                  priority=80 if salient else 40, rate_key=f"relay.{src}.{kind}",
                  min_interval_s=10.0 if salient else 30.0)]


def _sensory_scalar(value: Any) -> Any:
    # Scene changes are scalars, not arbitrary features, transcripts or media.
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return _num(value)
    if isinstance(value, str) and len(value) <= 160:
        if "data:" not in value.lower() and "base64" not in value.lower():
            return value
    return None


def _b_sensory_hub_change(f: Dict[str, Any]) -> List[_Spec]:
    """Projection of the hub's bounded scene deltas; never retains observations."""
    obs = f.get("observation")
    changes = f.get("changes")
    if obs is None or not isinstance(changes, (list, tuple)):
        return []
    observation_id = _clip(getattr(obs, "observation_id", None), 64)
    modality = getattr(obs, "modality", None)
    if not observation_id or modality not in ("screen", "webcam", "audio", "telemetry"):
        return []
    projected = []
    for change in changes[:32]:
        if not isinstance(change, dict):
            continue
        entity_id = change.get("entity_id")
        field_name = change.get("field")
        if not isinstance(entity_id, str) or not isinstance(field_name, str):
            continue
        projected.append({"entity_id": entity_id[:64], "field": field_name[:32],
                          "old": _sensory_scalar(change.get("old")),
                          "new": _sensory_scalar(change.get("new")),
                          "salience": max(0.0, min(1.0, _num(change.get("salience")) or 0.0)),
                          "seq": _int(change.get("seq")),
                          "observation_id": _clip(change.get("observation_id"), 64)})
    if not projected:
        return []
    observation = {"observation_id": observation_id, "modality": modality,
                   "source": _clip(getattr(obs, "source", None), 48),
                   "created_wall": _num(getattr(obs, "created_wall", None), 6),
                   "created_mono": _num(getattr(obs, "created_mono", None), 6),
                   "confidence": max(0.0, min(1.0, _num(getattr(obs, "confidence", None)) or 0.0)),
                   "change_score": max(0.0, min(1.0, _num(getattr(obs, "change_score", None)) or 0.0))}
    payload = {"kind": "sensory_change", "observation_id": observation_id,
               "modality": modality, "observation": observation,
               "changes": projected, "changes_count": len(projected),
               "effective_mode": "shadow"}
    # The hub already performs per-entity debounce. Coalescing an entire batch
    # by modality here would silently discard unrelated entity changes.
    return [_Spec(EventType.PERCEPTION_CHANGE, "sensory_hub." + modality, payload,
                  priority=80, salience=max(c["salience"] for c in projected),
                  created=_created((getattr(obs, "created_wall", None),
                                    getattr(obs, "created_mono", None))))]


def _b_cognition_tool_closed(f: Dict[str, Any]) -> List[_Spec]:
    if f.get("kind") != "tool":
        return []
    pred = f.get("pred")
    ok = bool(f.get("success"))
    p_success = _num(getattr(pred, "p_success", None))
    surprise = abs(p_success - (1.0 if ok else 0.0)) if p_success is not None else None
    tool = _clip(f.get("tool"), 80) or "?"
    ctx = f.get("context")
    side = f.get("side_effects")
    payload = {"episode_id": _int(f.get("ep_id")), "tool": tool, "ok": ok,
               "latency_ms": _num(f.get("latency_ms"), 1),
               "error": _clip(f.get("error"), SHORT_MAX_CHARS),
               "side_effects": [str(s)[:40] for s in list(side or [])[:10]],
               "p_success": p_success,
               "pred_confidence": _num(getattr(pred, "confidence", None)),
               "pred_method": _clip(getattr(pred, "method", None), 40),
               "surprise": _num(surprise),
               "bucket": _clip(getattr(ctx, "bucket", None), 40),
               "salience": _num(f.get("salience")),
               "thread": threading.current_thread().name[:40],
               "episode_recorded": True,
               "prediction_timing": "retrospective",
               "prospective": False, "calibration_eligible": False,
               "pe_child": bool(surprise is not None and surprise > PE_SURPRISE_THRESHOLD)}
    if _prediction_parent(f.get("prediction_parent_ticket")):
        # Nested canonical episodes stay intact, but only the outer wrapper
        # may project a terminal outcome for the issued prediction.
        annotation = {"prediction_owner": "prediction_runtime",
                      "prediction_nested": True, "pe_child": False}
    else:
        annotation = _prediction_outcome(f.get("prediction_ticket"),
            observed={"success": ok, "latency_ms": f.get("latency_ms")},
            observed_mono=f.get("prediction_observed_mono"),
            evidence=f.get("prediction_evidence", "unverified"),
            evidence_ref=f.get("prediction_evidence_ref"))
    trace_id = None
    if annotation is not None:
        payload.update(annotation)
        if "prediction_v1" in annotation:
            trace_id = annotation["prediction_v1"]["trace_id"]
    specs = [_Spec(EventType.TOOL_RESULT, "cognition.loop", payload, trace_id=trace_id)]
    if payload["pe_child"]:
        now = time.monotonic()
        persistent = False
        if _lock.acquire(timeout=GATE_LOCK_TIMEOUT_S):
            try:
                dq = _tool_surprises.get(tool)
                if dq is None:
                    if len(_tool_surprises) >= _MAX_GATE_KEYS:
                        _tool_surprises.clear()
                    dq = _tool_surprises[tool] = deque(maxlen=16)
                dq.append(now)
                persistent = sum(1 for t in dq if now - t <= TOOL_PERSIST_WINDOW_S) >= TOOL_PERSIST_N
            finally:
                _lock.release()
        else:
            next(_counter_lock_timeouts)
        pe = {"episode_id": payload["episode_id"], "tool": tool, "ok": ok,
              "surprise": _num(surprise), "p_success": p_success,
              "persistent": persistent, "prediction_timing": "retrospective",
              "prospective": False, "calibration_eligible": False}
        specs.append(_Spec(EventType.PREDICTION_ERROR, "cognition.loop", pe,
                           salience=min(1.0, surprise), link_parent=True))
    return specs


def _b_prediction_outcome(f: Dict[str, Any]) -> List[_Spec]:
    annotation = _prediction_outcome(f.get("ticket"), observed=f.get("observed", {}),
        observed_mono=f.get("observed_mono"), status=f.get("status", "completed"),
        evidence=f.get("evidence", "unverified"), evidence_ref=f.get("evidence_ref"))
    if annotation is None or "outcome_v1" not in annotation:
        return []
    return [_Spec(EventType.TOOL_RESULT, "prediction.runtime", annotation,
                  trace_id=annotation["prediction_v1"]["trace_id"])]


def _b_dream_state(f: Dict[str, Any]) -> List[_Spec]:
    return [_Spec(EventType.SLEEP_EVENT, "dreaming",
                  {"kind": "state_change", "old": _clip(f.get("old"), 32),
                   "new": _clip(f.get("new"), 32)})]


def _b_dream_cycle(f: Dict[str, Any]) -> List[_Spec]:
    c = f.get("cycle")
    md = getattr(c, "mood_delta", None) or {}
    payload = {"kind": "dream_cycle", "cycle_id": _int(getattr(c, "cycle_id", None)),
               "duration_s": _num(getattr(c, "duration_s", None), 3),
               "phases": [str(p)[:16] for p in list(getattr(c, "phases_completed", None) or [])[:8]],
               "memories_replayed": _int(getattr(c, "memories_replayed", None)),
               "novel_patterns": _int(getattr(c, "novel_patterns_found", None)),
               "synapses_strengthened": _int(getattr(c, "synapses_strengthened", None)),
               "synapses_weakened": _int(getattr(c, "synapses_weakened", None)),
               "mood_delta": {str(k)[:24]: _num(v) for k, v in list(dict(md).items())[:8]},
               "narrative": _clip(getattr(c, "narrative", None), 200)}
    return [_Spec(EventType.SLEEP_EVENT, "dreaming", payload)]


def _b_dream_explore_intent(f: Dict[str, Any]) -> List[_Spec]:
    return [_Spec(EventType.LEARNING_INTENT, "dreaming",
                  {"kind": "explore", "topic": _clip(f.get("topic"), 120),
                   "curiosity_level": _num(f.get("curiosity_level"))})]


def _b_dream_outreach_intent(f: Dict[str, Any]) -> List[_Spec]:
    return [_Spec(EventType.BACKGROUND_THOUGHT, "dreaming",
                  {"kind": "outreach_intent", "n_context": len(f.get("context_parts") or ())})]


def _b_dream_curiosity(f: Dict[str, Any]) -> List[_Spec]:
    c = f.get("cycle")
    n = _int(getattr(c, "novel_patterns_found", None)) or 0
    return [_Spec(EventType.LEARNING_INTENT, "dreaming",
                  {"kind": "dream_curiosity", "cycle_id": _int(getattr(c, "cycle_id", None)),
                   "novel_patterns": n, "raise": round(min(0.3, n * 0.05), 4)})]


def _b_inner_voice_intent(f: Dict[str, Any]) -> List[_Spec]:
    nm = f.get("nm") or {}
    payload = {"kind": "nonverbal_intent", "trigger": _clip(f.get("trigger"), 120),
               "dominant_region": _clip(f.get("dominant"), 40),
               "nm": {str(k)[:24]: _num(v, 3) for k, v in list(dict(nm).items())[:8]}}
    return [_Spec(EventType.BACKGROUND_THOUGHT, "inner_voice", payload,
                  rate_key="inner_voice.intent", min_interval_s=60.0)]


def _b_inner_voice_thought(f: Dict[str, Any]) -> List[_Spec]:
    t = f.get("thought")
    text = getattr(t, "text", "") or ""
    payload = {"kind": "articulated", "trigger": _clip(getattr(t, "trigger", None), 120),
               "dominant_region": _clip(getattr(t, "dominant_region", None), 40),
               "text": str(text)[:280], "chars": len(text)}
    return [_Spec(EventType.BACKGROUND_THOUGHT, "inner_voice", payload)]


def _goal_payload(g: Any, change: str) -> Dict[str, Any]:
    return {"change": change, "goal_id": _clip(getattr(g, "id", None), 40),
            "goal_type": _clip(getattr(g, "type", None), 24),
            "goal_source": _clip(getattr(g, "source", None), 24),
            "status": _clip(getattr(g, "status", None), 16),
            "progress": _num(getattr(g, "progress", None)),
            "priority": _num(getattr(g, "priority", None))}


def _b_goals_add(f: Dict[str, Any]) -> List[_Spec]:
    return [_Spec(EventType.GOAL_EVENT, "goals", _goal_payload(f.get("goal"), "added"))]


def _b_goals_update(f: Dict[str, Any]) -> List[_Spec]:
    g = f.get("goal")
    change = "completed" if getattr(g, "status", None) == "completed" else "progress"
    return [_Spec(EventType.GOAL_EVENT, "goals", _goal_payload(g, change))]


def _b_goals_abandon(f: Dict[str, Any]) -> List[_Spec]:
    return [_Spec(EventType.GOAL_EVENT, "goals", _goal_payload(f.get("goal"), "abandoned"))]


def _b_goal_pursuit_selected(f: Dict[str, Any]) -> List[_Spec]:
    g = f.get("goal") or {}
    get = g.get if isinstance(g, dict) else (lambda k, d=None: getattr(g, k, d))
    return [_Spec(EventType.GOAL_EVENT, "goal_pursuit",
                  {"change": "pursuit_selected", "goal_id": _clip(get("id"), 40),
                   "progress": _num(get("progress")), "cycle": _int(f.get("cycle"))})]


def _sleep_daemon(transition: str) -> Callable[[Dict[str, Any]], List[_Spec]]:
    def build(f: Dict[str, Any]) -> List[_Spec]:
        idle = _num(f.get("idle_s"), 1)
        return [_Spec(EventType.SLEEP_EVENT, "sleep_daemon",
                      {"kind": "sleep_daemon", "transition": transition,
                       "fatigue": _num(f.get("fatigue"), 3),
                       "idle_s": idle if idle is not None and idle < 1e8 else None})]
    return build


def _b_consolidation_pass(f: Dict[str, Any]) -> List[_Spec]:
    """At most 1 per 300 s, but every pass is *covered*: each event carries the
    contiguous range of pass numbers since the previous published one."""
    ni = f.get("new_insights")
    pass_no = _int(f.get("pass_no"))
    last = _consolidation["last_published"]
    reset = pass_no is not None and last is not None and pass_no <= last
    first = pass_no if (last is None or reset or pass_no is None) else last + 1
    payload = {"kind": "consolidation_pass", "pass_no": pass_no,
               "pass_no_first": first, "pass_no_last": pass_no,
               "passes_covered": (pass_no - first + 1) if pass_no is not None and first is not None else None,
               "counter_reset": bool(reset),
               "new_insights": len(ni) if hasattr(ni, "__len__") else _int(ni)}

    def _published(n=pass_no):
        _consolidation["last_published"] = n
    return [_Spec(EventType.SLEEP_EVENT, "sleep_consolidation", payload,
                  coalesce_key="consolidation_pass", rate_key="consolidation.pass",
                  min_interval_s=300.0, on_published=_published)]


def _b_actuator_bypass_tool(f: Dict[str, Any]) -> List[_Spec]:
    """Desk and self.* tools never reach the wrapped actuator call or the
    episode store, so legacy saw no result for them; publish one TOOL_RESULT."""
    tool = _clip(f.get("tool"), 80) or "?"
    res = f.get("result")
    ok = res.get("ok") if isinstance(res, dict) and isinstance(res.get("ok"), bool) else None
    err = _clip(res.get("error"), SHORT_MAX_CHARS) if isinstance(res, dict) else None
    payload = {"tool": tool, "bypass": "desk" if tool.startswith("self.desk_") else "self",
               "ok": ok, "error": err, "episode_recorded": False, "pe_child": False}
    return [_Spec(EventType.TOOL_RESULT, "actuator.bypass", payload)]


def _b_mortality_tick(f: Dict[str, Any]) -> List[_Spec]:
    m = f.get("mortality")
    sig = _num(getattr(m, "mortality_signal", None)) or 0.0
    bucket = "ok" if sig < 0.25 else ("elevated" if sig < 0.5 else "critical")
    payload = {"signal": sig, "bucket": bucket,
               "mem_available_frac": _num(getattr(m, "mem_available_frac", None)),
               "process_memory_gb": _num(getattr(m, "process_memory_gb", None), 3),
               "disk_available_gb": _num(getattr(m, "disk_available_gb", None), 2),
               "cpu_temp": _num(getattr(m, "cpu_temp", None), 1),
               "on_battery": getattr(m, "on_battery", None) if isinstance(getattr(m, "on_battery", None), bool) else None}
    return [_Spec(EventType.RESOURCE_EVENT, "real_mortality", payload, salience=sig,
                  edge_key="mortality.bucket", edge_value=bucket, hold_down_s=300.0)]


def _b_workspace_ignition(f: Dict[str, Any]) -> List[_Spec]:
    """Runbook 11.1: GlobalWorkspace ignition metadata only (region, rate, salience,
    binding-window summary). Never text, never a model call. The event id is the
    trace id. Rate-limited per region: an ignition held for seconds is one event."""
    c = f.get("content")
    region = _clip(getattr(c, "region", None), 40) or "unknown"

    def _num(v: Any) -> float:
        try:
            x = float(v)
        except (TypeError, ValueError):
            return 0.0
        return x if x == x and abs(x) != float("inf") else 0.0

    bid = _num(getattr(c, "bid_strength", 0.0))
    window: List[str] = []
    ws = f.get("workspace")
    try:
        for item in (ws.binding_window() if ws is not None else [])[-5:]:
            window.append(_clip(getattr(item, "region", None), 40) or "?")
    except Exception:
        window = []
    payload = {"kind": "workspace_ignition", "region": region,
               "firing_rate": round(_num(getattr(c, "firing_rate", 0.0)), 4),
               "bid": round(bid, 4),
               "n_regions_responding": int(_num(getattr(c, "n_regions_responding", 0))),
               "quantum_decided": bool(getattr(c, "quantum_decided", False)),
               "pattern_hash": int(_num(getattr(c, "pattern_hash", 0))) & 0xFFFFFFFF,
               "binding_window": window}
    return [_Spec(EventType.BACKGROUND_THOUGHT, "workspace", payload,
                  salience=max(0.0, min(1.0, bid)),
                  rate_key=f"workspace.ignition.{region}", min_interval_s=10.0)]


SITES: Dict[str, Callable[[Dict[str, Any]], List[_Spec]]] = {
    "prediction.outcome": _b_prediction_outcome,
    "sensory_hub.change": _b_sensory_hub_change,
    "ws.text_input": _b_ws_text_input,
    "voice.accepted": _b_voice_accepted,
    "wake_orch.accepted": _b_wake_orch_accepted,
    "audio_daemon.heard": _b_audio_daemon_heard,
    "perception_floors.alerts": _b_perception_floors_alerts,
    "vision_daemon.observation": _b_vision_daemon_observation,
    "relay.perception": _b_relay_perception,
    "cognition.tool_closed": _b_cognition_tool_closed,
    "dream.state": _b_dream_state,
    "dream.cycle": _b_dream_cycle,
    "dream.explore_intent": _b_dream_explore_intent,
    "dream.outreach_intent": _b_dream_outreach_intent,
    "dream.curiosity": _b_dream_curiosity,
    "inner_voice.intent": _b_inner_voice_intent,
    "inner_voice.thought": _b_inner_voice_thought,
    "workspace.ignition": _b_workspace_ignition,
    "goals.add": _b_goals_add,
    "goals.update_progress": _b_goals_update,
    "goals.abandon": _b_goals_abandon,
    "goal_pursuit.selected": _b_goal_pursuit_selected,
    "sleep_daemon.asleep": _sleep_daemon("asleep"),
    "sleep_daemon.woke_owner": _sleep_daemon("woke_owner_spoke"),
    "sleep_daemon.woke_rested": _sleep_daemon("woke_rested"),
    "consolidation.pass": _b_consolidation_pass,
    "mortality.tick": _b_mortality_tick,
    "actuator.bypass_tool": _b_actuator_bypass_tool,
}


# ----------------------------------------------------------------------
# polled webcam liveness (runs on the runtime thread every 15 s)


def sweep(server_state: Any) -> None:
    """Publish webcam liveness edges from metadata only. Never reads frames."""
    rt = _runtime
    if rt is None or not rt.accepting:
        return
    now = time.monotonic()
    ts = _num(getattr(server_state, "_webcam_frame_ts", None), 3)
    cache = getattr(server_state, "_webcam_frame_cache", None) or {}
    try:
        width = _int(cache.get("width")) if isinstance(cache, dict) else None
        height = _int(cache.get("height")) if isinstance(cache, dict) else None
    except Exception:
        width = height = None
    clients = getattr(server_state, "_webcam_clients", None)
    try:
        ready = sum(1 for v in list(clients.values()) if v) if isinstance(clients, dict) else None
    except Exception:
        ready = None
    w = _webcam
    if ts is not None and ts != w["ts"]:
        w["ts"] = ts
        w["changed_mono"] = now
    streaming = bool(w["changed_mono"] is not None and now - w["changed_mono"] < WEBCAM_STALE_S)
    base = {"frame_id": f"webcam:{int(ts * 1000)}" if ts else None,
            "width": width, "height": height, "ready_clients": ready}
    specs: List[_Spec] = []
    if w["streaming"] is None:
        w["streaming"] = streaming                     # baseline, no event
    elif streaming != w["streaming"]:
        w["streaming"] = streaming
        p = {"kind": "stream_started" if streaming else "stream_stopped", **base}
        if not streaming and w["changed_mono"] is not None:
            p["gap_s"] = round(now - w["changed_mono"], 1)
        specs.append(_Spec(EventType.PERCEPTION_CHANGE, "webcam", p, priority=80))
    res = (width, height) if width and height else None
    if streaming and res is not None and w["res"] is not None and res != w["res"]:
        specs.append(_Spec(EventType.PERCEPTION_CHANGE, "webcam",
                           {"kind": "resolution_changed", **base}, priority=40,
                           rate_key="webcam.resolution", min_interval_s=30.0))
    if res is not None:
        w["res"] = res
    if ready is not None:
        avail = ready > 0
        if w["ready"] is None:
            w["ready"] = avail
        elif avail != w["ready"]:
            w["ready"] = avail
            specs.append(_Spec(EventType.PERCEPTION_CHANGE, "webcam",
                               {"kind": "camera_available" if avail else "camera_unavailable",
                                **base}, priority=80))
    for spec in specs:
        try:
            _publish(rt, spec, None, "webcam.sweep")
        except Exception as exc:
            _report("webcam.sweep", "-", exc)


def _reset_for_tests() -> None:
    global _runtime
    with _lock:
        _runtime = None
        for d in (_counters, _site_counts, _edge, _edge_ts, _last, _fail_last,
                  _fail_suppressed, _tool_surprises, _lat):
            d.clear()
        _consolidation["last_published"] = None
        _webcam.update(ts=None, changed_mono=None, streaming=None, res=None, ready=None)
