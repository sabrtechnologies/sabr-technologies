"""
Rollout — internal simulation before committing to an action.

Given a candidate action, return a Simulation with:
  - the world model's prediction
  - a utility score combining p_success, latency, side-effects, reversibility
  - a recommendation: "execute" | "defer" | "abort"

The recommendation is what the closed loop reads to decide whether to fire.
"defer" raises the uncertainty drive (we'll observe more before trying again);
"abort" raises friction (we won't try this path soon).

Reversibility is hard-coded per tool family from the risk tier — there's no
way to learn it from data without already paying the cost. We treat HIGH
risk as low reversibility (closing apps, shell exec, code edits) and
penalize utility accordingly.

Multi-step rollouts (depth > 1) are stubbed for now — we project a
synthetic post-state context and look up the best follow-up prediction.
That's enough to discount actions that succeed but lead to dead ends.
"""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

from brain.cognition.episodes import Context, Prediction
from brain.cognition.snn_gating import Gates

log = logging.getLogger("leon.cognition.rollout")


# Reversibility per risk tier — higher = easier to undo
_REVERSIBILITY = {
    "low":    0.95,   # read-only, can rerun safely
    "medium": 0.70,   # mostly reversible (focus a window, copy clipboard)
    "high":   0.30,   # closing apps, shell exec, code edits
}

# Side-effect weight in utility — higher penalty for likely side effects
_SIDE_EFFECT_PENALTY = 0.6


@dataclass
class Simulation:
    action_kind: str
    action_name: str
    action_args: Dict[str, Any]
    prediction: Prediction
    utility: float                       # higher = better candidate
    reversibility: float                 # 0..1
    recommendation: str                  # "execute" | "defer" | "abort"
    reason: str = ""                     # why this recommendation
    follow_up_utility: float = 0.0       # discounted best next-step utility

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_kind": self.action_kind,
            "action_name": self.action_name,
            "action_args": self.action_args,
            "prediction": self.prediction.to_dict(),
            "utility": round(self.utility, 4),
            "reversibility": round(self.reversibility, 3),
            "recommendation": self.recommendation,
            "reason": self.reason,
            "follow_up_utility": round(self.follow_up_utility, 4),
        }


class Rollout:
    """Internal one-step simulator that gates real actions on predicted utility."""

    def __init__(self, world_model, drives, gates_provider):
        self.wm = world_model
        self.drives = drives
        self.gates = gates_provider  # SNNGates

    def simulate(
        self,
        action_kind: str,
        action_name: str,
        action_args: Dict[str, Any],
        context: Context,
        *,
        depth: int = 1,
        explore: bool = False,
    ) -> Simulation:
        pred = self.wm.predict(action_kind, action_name, action_args, context)
        gates = self.gates.current()
        rev = self._reversibility(action_name)

        # Utility components — bounded so weights are interpretable.
        # success_term      ∈ [0, 1]
        # latency_term      ∈ [-1, 0]      (5s latency → -1)
        # side_effect_term  ∈ [-0.6, 0]
        # reversibility_term∈ [0, 1]
        # drive_bias        ∈ [0, ~2]      (from drives system)
        # exploration_kick  ∈ [0, 0.5]     (only if explore=True)
        latency_term = -min(1.0, pred.latency_ms / 5000.0)
        side_effect_term = -_SIDE_EFFECT_PENALTY * pred.p_side_effects
        reversibility_term = rev
        drive_bias = self.drives.action_bias(action_name)
        exploration_kick = (random.random() * 0.5) if explore else 0.0
        # Stability preference rewards repeating known-good (high-confidence high-p_success)
        stability_term = gates.stability_preference * pred.confidence * pred.p_success

        utility = (
            0.55 * pred.p_success
            + 0.10 * latency_term
            + 0.15 * reversibility_term
            + side_effect_term
            + 0.20 * drive_bias
            + exploration_kick
            + 0.10 * stability_term
        )

        # Follow-up estimation — cheap stub: assume post-state ≈ current
        # state with active_app possibly different, hour unchanged.
        # If the world model has data on what tends to come next, we'd
        # mine it here; for v0 we just discount the best generic next.
        follow_up_utility = 0.0
        if depth > 1 and pred.p_success > 0.5:
            follow_up_utility = 0.3 * self._best_next_utility(context)
            utility += follow_up_utility

        # Recommendation
        # ABORT: irreversible action with low confidence
        if rev < 0.4 and pred.confidence < 0.3 and not explore:
            recommendation = "abort"
            reason = f"low-reversibility action with thin data (conf={pred.confidence:.2f})"
        # DEFER: p_success below NE-driven threshold, and not exploring
        elif pred.p_success < gates.confidence_threshold and not explore:
            recommendation = "defer"
            reason = (f"p_success={pred.p_success:.2f} below threshold "
                      f"{gates.confidence_threshold:.2f} (NE={context.nm.get('norepinephrine',0):.2f})")
        else:
            recommendation = "execute"
            reason = (f"p_success={pred.p_success:.2f}, utility={utility:.2f}, "
                      f"explore={explore}")

        return Simulation(
            action_kind=action_kind,
            action_name=action_name,
            action_args=action_args,
            prediction=pred,
            utility=float(utility),
            reversibility=float(rev),
            recommendation=recommendation,
            reason=reason,
            follow_up_utility=float(follow_up_utility),
        )

    # -- helpers ----------------------------------------------------------

    @staticmethod
    def _reversibility(action_name: str) -> float:
        try:
            from brain.actuator_client import TOOL_RISK
            risk = TOOL_RISK.get(action_name) \
                or TOOL_RISK.get(action_name.replace(".", "_")) \
                or "medium"
        except Exception:
            risk = "medium"
        return _REVERSIBILITY[risk]

    def _best_next_utility(self, context: Context) -> float:
        """Stub for follow-up estimation. Returns 0..1 estimate of best
        achievable utility in the next step given current context.

        v0: returns a constant based on how many active drives are loud.
        v1 (later) will query the world model over a candidate set.
        """
        snap = self.drives.snapshot()
        loud = sum(1 for d in snap["drives"].values()
                   if d["above_baseline"] > 0.2)
        return 0.4 + 0.1 * loud  # 0.4 baseline, +0.1 per loud drive

    # ── Phase 11A — multi-step rollout with beam search ─────────────────

    def simulate_chain(
        self,
        candidates: List[Dict[str, Any]],
        context: Context,
        *,
        depth: int = 5,
        beam_width: int = 5,
        explore: bool = False,
        prune_aggressively: bool = True,
    ) -> "ChainSimulation":
        """Beam-search over multi-step action chains with upper-bound pruning.

        Args:
          candidates: list of {kind, name, args} dicts to consider at each step.
                      The same pool is reused; the planner expects there to be
                      meaningful diversity in it.
          context:    current Context (NM/app/hour/bucket).
          depth:      how many steps deep to simulate (Phase 12C: default 5).
          beam_width: how many partial paths to keep per depth (default 5).
          explore:    if True, inject random utility bonus for exploration.
          prune_aggressively:
                      Phase 12C — if True (default), enable upper-bound pruning:
                      drop partial paths whose optimistic remaining utility
                      can't beat the best terminal-or-completed path found so
                      far. Cuts ~50-70% of step scorings at depth=5+ without
                      changing the optimum (the bound is sound — we never
                      prune a path that could still win).

        Returns a ChainSimulation with a recommended path + path-level
        recommendation that respects accumulated risk and confidence decay.

        Implementation notes:
          - Confidence MULTIPLIES along a path (chain rule) so deep paths
            with low-confidence steps get penalized.
          - Risk ACCUMULATES additively; the weakest link sets reversibility.
          - Latency SUMS with a soft cap so one slow step doesn't dominate.
          - Dead-end: a step at conf<0.05 freezes the branch (terminal flag,
            H5 fix).
          - Upper-bound pruning (Phase 12C): we track the best fully-expanded
            path's utility as `alpha`. For an in-progress path at depth d with
            `remaining = depth - d - 1` steps left, the optimistic final
            utility is `cumulative_utility + remaining * max_step_utility`
            where `max_step_utility` is the maximum single-step utility seen
            during initial-beam scoring (a real ceiling, not a guess). Paths
            whose ceiling falls below alpha are pruned.
        """
        if not candidates or depth < 1:
            return _empty_chain(reason="no candidates or zero depth")

        # Initial beam: each candidate as a single-step path. Score the full
        # candidate pool (capped) so we can learn max_step_utility, which
        # becomes the per-step ceiling used for pruning later.
        scored_initial: List[_ScoredStep] = []
        for c in candidates[: max(beam_width * 2, 8)]:
            step = self._score_single_step(c, context, depth_index=0, explore=explore)
            if step is None:
                continue
            scored_initial.append(step)
        if not scored_initial:
            # M1: scoring failed on every candidate — that's not "no data",
            # it's "everything looks bad". Abort, don't defer-and-proceed.
            return _empty_chain(reason="no scoreable candidates", recommendation="abort")
        # Per-step ceiling for upper-bound pruning (Phase 12C).
        max_step_utility = max((s.utility for s in scored_initial), default=0.0)

        beam: List[_PartialPath] = [
            _PartialPath(
                steps=[step],
                cumulative_utility=step.utility,
                cumulative_confidence=step.prediction.confidence if step.prediction.confidence > 0 else 0.5,
                cumulative_risk=step.risk_contribution,
                cumulative_latency_ms=step.prediction.latency_ms,
                min_reversibility=step.reversibility,
                failure_modes=list(step.failure_modes),
            )
            for step in scored_initial
        ]
        # Keep top-N by utility
        beam.sort(key=lambda p: -p.cumulative_utility)
        beam = beam[:beam_width]

        # Alpha = best fully-expanded utility seen so far. Initialize from
        # the best initial-beam path (depth=1 is "fully expanded" if depth==1
        # or if a path goes terminal). We update alpha as we go.
        alpha = beam[0].cumulative_utility if beam else 0.0

        # Expand to target depth
        for d in range(1, depth):
            next_beam: List[_PartialPath] = []
            for path in beam:
                # Already-terminal paths carry through unchanged (H5 fix).
                if path.terminal:
                    # Terminal paths are "completed" — they bump alpha.
                    if path.cumulative_utility > alpha:
                        alpha = path.cumulative_utility
                    next_beam.append(path)
                    continue
                # Dead-end detection: if last step's confidence is bottom-floor,
                # freeze this branch — mark terminal, append ONE failure mode.
                last_conf = path.steps[-1].prediction.confidence
                if last_conf < 0.05:
                    path.failure_modes.append(f"dead-end at depth {d-1} (conf<0.05)")
                    path.terminal = True
                    if path.cumulative_utility > alpha:
                        alpha = path.cumulative_utility
                    next_beam.append(path)
                    continue
                # Phase 12C — upper-bound pruning. Optimistic remaining utility
                # assumes EVERY remaining step contributes max_step_utility.
                # If that ceiling can't beat alpha, drop the path now without
                # scoring further candidates.
                if prune_aggressively:
                    remaining = depth - d  # steps still to be added
                    ceiling = path.cumulative_utility + remaining * max_step_utility
                    if ceiling < alpha:
                        # Pruned. Keep it in next_beam as terminal so the
                        # final pick can still surface it if alpha drops
                        # later, but don't expand.
                        path.failure_modes.append(
                            f"pruned at depth {d-1} (ceiling {ceiling:.2f} < alpha {alpha:.2f})"
                        )
                        path.terminal = True
                        next_beam.append(path)
                        continue
                for c in candidates[: max(beam_width * 2, 8)]:
                    # No-op: skip pure-repeat steps (B after A=B is degenerate
                    # unless A is observation-class).
                    if (path.steps[-1].action_name == c.get("name") and
                            path.steps[-1].action_kind != "observe"):
                        continue
                    step = self._score_single_step(c, context, depth_index=d, explore=explore)
                    if step is None:
                        continue
                    new_path = path.extend_with(step)
                    if new_path.cumulative_utility > path.cumulative_utility - 0.3:
                        next_beam.append(new_path)
                        # Update alpha greedily if a depth-D path's running
                        # utility already beats it — a deeper path is more
                        # informed so this is sound.
                        if new_path.cumulative_utility > alpha:
                            alpha = new_path.cumulative_utility
            if not next_beam:
                break
            next_beam.sort(key=lambda p: -p.cumulative_utility)
            beam = next_beam[:beam_width]

        # Pick best
        beam.sort(key=lambda p: -p.cumulative_utility)
        best = beam[0]
        gates = self.gates.current()

        # Path-level recommendation
        recommendation, reason = self._classify_path(best, gates)

        return ChainSimulation(
            recommendation=recommendation,
            confidence=round(best.cumulative_confidence, 3),
            expected_utility=round(best.cumulative_utility, 3),
            risk=round(best.cumulative_risk, 3),
            reversibility=round(best.min_reversibility, 3),
            path=[s.to_dict() for s in best.steps],
            failure_modes=best.failure_modes[:5],
            reason=reason,
            depth=len(best.steps),
            beam_explored=len(beam),
        )

    # ── helpers ----------------------------------------------------------

    def _score_single_step(
        self,
        candidate: Dict[str, Any],
        context: Context,
        *,
        depth_index: int,
        explore: bool,
    ) -> Optional["_ScoredStep"]:
        try:
            kind = candidate.get("kind", "tool")
            name = candidate.get("name", "")
            args = candidate.get("args", {}) or {}
            if not name:
                return None
            pred = self.wm.predict(kind, name, args, context)
        except Exception as e:
            log.warning("score_single_step predict failed for %r: %s", candidate, e)
            return None
        rev = self._reversibility(name)
        # Per-step utility — same components as Phase 1 simulate() but
        # with depth-aware confidence weighting so deep steps with thin data
        # don't inflate path utility.
        depth_decay = 0.85 ** depth_index  # ~0.85, 0.72, 0.61 at depths 0/1/2
        latency_term = -min(1.0, pred.latency_ms / 5000.0)
        side_term = -_SIDE_EFFECT_PENALTY * pred.p_side_effects
        drive_bias = self.drives.action_bias(name)
        kick = (random.random() * 0.35) if explore else 0.0
        utility = (
            0.55 * pred.p_success * depth_decay
            + 0.10 * latency_term
            + 0.15 * rev
            + side_term
            + 0.18 * drive_bias * depth_decay
            + kick
        )
        # Risk = side-effect prob * (1-reversibility), weighted by depth
        risk = pred.p_side_effects * (1.0 - rev) * (1.0 + 0.2 * depth_index)
        failure_modes = []
        if pred.p_success < 0.4:
            failure_modes.append(f"step {depth_index+1}: low p_success ({pred.p_success:.2f}) for {name}")
        if rev < 0.5:
            failure_modes.append(f"step {depth_index+1}: low reversibility ({rev:.2f}) for {name}")
        if pred.latency_ms > 3000:
            failure_modes.append(f"step {depth_index+1}: high latency (~{int(pred.latency_ms)}ms) for {name}")
        return _ScoredStep(
            action_kind=kind, action_name=name, action_args=args,
            prediction=pred, utility=utility, reversibility=rev,
            risk_contribution=risk, depth_index=depth_index,
            failure_modes=failure_modes,
        )

    def _classify_path(self, path: "_PartialPath", gates: Gates) -> Tuple[str, str]:
        """Path-level recommendation. Stricter than per-step because errors
        compound and irreversible chains are worse than irreversible single
        steps."""
        # ABORT: any step in the chain is irreversible AND chain confidence is low
        if path.min_reversibility < 0.4 and path.cumulative_confidence < 0.4:
            return ("abort",
                    f"chain has irreversible step (min_rev={path.min_reversibility:.2f}) "
                    f"with weak chain confidence ({path.cumulative_confidence:.2f})")
        # ABORT: accumulated risk above hard ceiling
        if path.cumulative_risk > 0.8:
            return ("abort",
                    f"accumulated risk {path.cumulative_risk:.2f} exceeds ceiling (0.8)")
        # DEFER: chain confidence below NE-driven threshold
        if path.cumulative_confidence < gates.confidence_threshold:
            return ("defer",
                    f"chain confidence {path.cumulative_confidence:.2f} below threshold "
                    f"{gates.confidence_threshold:.2f}")
        # DEFER: too many failure modes flagged
        if len(path.failure_modes) >= 3:
            return ("defer",
                    f"{len(path.failure_modes)} failure modes flagged along path")
        # PROCEED
        return ("proceed",
                f"chain utility={path.cumulative_utility:.2f}, conf={path.cumulative_confidence:.2f}, "
                f"risk={path.cumulative_risk:.2f}, min_rev={path.min_reversibility:.2f}")


# ── Multi-step rollout dataclasses ─────────────────────────────────────────

@dataclass
class _ScoredStep:
    """One step inside a multi-step beam-search path. Internal."""
    action_kind: str
    action_name: str
    action_args: Dict[str, Any]
    prediction: Prediction
    utility: float
    reversibility: float
    risk_contribution: float
    depth_index: int
    failure_modes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.depth_index + 1,
            "action_kind": self.action_kind,
            "action_name": self.action_name,
            "action_args": self.action_args,
            "p_success": round(self.prediction.p_success, 3),
            "latency_ms": round(self.prediction.latency_ms, 1),
            "confidence": round(self.prediction.confidence, 3),
            "method": self.prediction.method,
            "utility": round(self.utility, 3),
            "reversibility": round(self.reversibility, 3),
            "risk_contribution": round(self.risk_contribution, 3),
            "failure_modes": self.failure_modes,
        }


@dataclass
class _PartialPath:
    """A partial beam-search path during expansion. Internal."""
    steps: List[_ScoredStep]
    cumulative_utility: float
    cumulative_confidence: float       # MULTIPLIED chain confidence
    cumulative_risk: float             # SUM of risk contributions
    cumulative_latency_ms: float
    min_reversibility: float           # weakest link
    failure_modes: List[str] = field(default_factory=list)
    # H5 fix: once a path dead-ends (last step conf<0.05) it should be frozen,
    # not re-evaluated each beam-search depth iteration. Without this flag,
    # the dead-end branch in simulate_chain mutates the same _PartialPath
    # across iterations — failure_modes grows by one per depth, eventually
    # tripping _classify_path's "len(failure_modes)>=3 → defer" rule on what
    # should be a stable terminal.
    terminal: bool = False

    def extend_with(self, step: _ScoredStep) -> "_PartialPath":
        return _PartialPath(
            steps=self.steps + [step],
            cumulative_utility=self.cumulative_utility + step.utility,
            cumulative_confidence=self.cumulative_confidence * max(0.05, step.prediction.confidence or 0.5),
            cumulative_risk=self.cumulative_risk + step.risk_contribution,
            cumulative_latency_ms=self.cumulative_latency_ms + step.prediction.latency_ms,
            min_reversibility=min(self.min_reversibility, step.reversibility),
            failure_modes=self.failure_modes + step.failure_modes,
        )


@dataclass
class ChainSimulation:
    """Output of multi-step beam-search rollout.

    The structured payload an autopilot/responder can act on.
    """
    recommendation: str                 # 'proceed' | 'defer' | 'abort'
    confidence: float                   # 0..1 chain confidence (product over steps)
    expected_utility: float
    risk: float                         # 0..~3 accumulated
    reversibility: float                # 0..1, minimum along path (weakest link)
    path: List[Dict[str, Any]]          # serialized steps
    failure_modes: List[str]
    reason: str
    depth: int
    beam_explored: int

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _empty_chain(*, reason: str, recommendation: str = "defer") -> "ChainSimulation":
    # M1 fix: callers can now distinguish "no data, defer cautiously" (default)
    # from "no scoreable candidates, abort outright". Previously every empty
    # chain was 'defer' which autopilot_integration treats as proceed-with-warning
    # — so all-failing predictions silently proceeded.
    return ChainSimulation(
        recommendation=recommendation,
        confidence=0.0,
        expected_utility=0.0,
        risk=0.0,
        reversibility=1.0,
        path=[],
        failure_modes=[reason],
        reason=reason,
        depth=0,
        beam_explored=0,
    )
