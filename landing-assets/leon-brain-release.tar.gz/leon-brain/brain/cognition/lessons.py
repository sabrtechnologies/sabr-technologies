"""
Phase 13 — Lessons / Corrections.

Captures Dean's corrections into a persistent rule store. The whole point:
when Dean says "stop doing X" or "always do Y", that guidance must influence
Leon's future behavior FOREVER, not just for the current Claude turn.

Three sources feed this store:

  1) Explicit  — Dean says "remember:", "don't do that", "stop doing X",
                 "always Y", etc. The responder calls .capture_from_turn(...)
                 on every user turn; the heuristic matcher pulls candidates.
  2) Implicit  — Dean repeats the SAME correction multiple times for the same
                 topic; we boost weight on the relevant rule.
  3) Manual    — POST /api/cognition/lessons/add or skill_inventory tools.

A Lesson is:
  id (rowid), text, scope (global|tool:<name>|topic:<x>|app:<x>),
  polarity (do|dont), weight (0..1, decays slightly with disuse),
  created_ts, last_seen_ts, hit_count

Consumed by:
  • Executive — veto strategies that violate a do-not lesson
  • Prompt builder — inject up to N relevant lessons per turn
  • Suggestions — propose adherence reminders proactively
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.lessons")


_SCHEMA = """
CREATE TABLE IF NOT EXISTS lessons (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    text          TEXT NOT NULL,
    scope         TEXT NOT NULL DEFAULT 'global',
    polarity      TEXT NOT NULL DEFAULT 'dont',
    weight        REAL NOT NULL DEFAULT 0.5,
    created_ts    REAL NOT NULL,
    last_seen_ts  REAL NOT NULL,
    hit_count     INTEGER NOT NULL DEFAULT 1,
    source        TEXT
);
CREATE INDEX IF NOT EXISTS idx_lessons_scope ON lessons(scope);
CREATE INDEX IF NOT EXISTS idx_lessons_weight ON lessons(weight DESC);
"""


# Heuristic patterns for capturing corrections. These are intentionally
# conservative — we want very high precision, low recall. False-positive
# lessons are worse than missed ones because they will hurt every prompt.
#
# 2026-10-04: the old patterns matched "don't"/"always"/"remember" ANYWHERE
# in a sentence, so ordinary talk became rules: "I don't know what this is"
# -> DON'T: know what this is, "do you remember anything" -> DO: anything.
# A rule is now only taken from a sentence that STARTS with the trigger
# (after "Leon,"/"ok"/"and" style lead-ins) and is not a question.
#
# 2026-10-05: that still kept fragments ("talking, start looking") and stored
# Dean's words with the trigger cut off, so prompts read "DON'T: say you are
# about to do it". Now the word after the trigger must be a known imperative
# verb, the candidate must score _MIN_CONFIDENCE, and what is stored is the
# whole instruction as Dean gave it ("Don't call me sir."), so it reads on
# its own. Everything else is dropped and logged at debug level for audit.
_TRIGGERS = (
    # (pattern, polarity, canonical lead)
    (re.compile(r"^(?:don'?t|do\s+not)\s+(.+)$", re.I), "dont", "Don't"),
    (re.compile(r"^never\s+(.+)$", re.I), "dont", "Never"),
    (re.compile(r"^stop\s+(.+)$", re.I), "dont", "Stop"),
    (re.compile(r"^always\s+(.+)$", re.I), "do", "Always"),
    (re.compile(r"^remember\s+to\s+(.+)$", re.I), "do", "Remember to"),
    (re.compile(r"^make\s+sure\s+(?:that\s+)?(?:you\s+|to\s+)(.+)$", re.I),
     "do", "Make sure you"),
)
_PAT_FROM_NOW_ON = re.compile(
    r"^(?:from\s+now\s+on|going\s+forward)\s*,?\s+(.+)$", re.I,
)
_PAT_REMEMBER = re.compile(r"^remember(?:\s+this)?\s*:\s*(.+)$", re.I)
# "from now on you should ask first" -> "ask first"
_YOU_MODAL = re.compile(
    r"^you(?:'ll|\s+will|\s+should|\s+need\s+to|\s+have\s+to|\s+must|"
    r"\s+gotta|\s+got\s+to)?\s+", re.I,
)
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")
_LEAD_IN = re.compile(
    r"^(?:(?:hey\s+)?leon|ok(?:ay)?|alright|so|and|also|but|look|listen|yo|bro|"
    r"man|dude|no|yeah|please|seriously|honestly|one\s+more\s+thing)\b[\s,:-]*",
    re.I,
)
# Verbs that start a real instruction about how Leon behaves. The word after
# "don't"/"never"/"always" must be one of these: "don't know", "never mind",
# "don't worry", "always have to" are Dean talking, not instructing.
_IMPERATIVE_VERBS = {
    "act", "add", "address", "announce", "answer", "apologize", "ask", "assume",
    "be", "beg", "bother", "build", "call", "change", "check", "circle", "claim",
    "close", "comment", "commit", "confirm", "copy", "delete", "deploy",
    "describe", "double-check", "drop", "email", "end", "explain", "fake",
    "finish", "follow", "give", "guess", "hand", "hedge", "hide", "ignore",
    "include", "install", "interrupt", "invent", "keep", "label", "leave",
    "lecture", "let", "lie", "list", "loop", "make", "mention", "message",
    "move", "narrate", "offer", "open", "overwrite", "pad", "pause", "pester",
    "ping", "play", "post", "pretend", "promise", "push", "put", "quote",
    "ramble", "read", "reference", "refer", "remove", "repeat", "reply",
    "report", "respond", "restart", "say", "send", "share", "show", "skip",
    "sound", "spam", "speak", "spend", "start", "stay", "summarize", "talk",
    "tell", "test", "text", "touch", "treat", "try", "turn", "update", "use",
    "verify", "wait", "waste", "write",
}
# "stop <x>ing": words ending in -ing that are not verbs.
_NOT_GERUNDS = {
    "nothing", "anything", "something", "everything", "thing", "morning",
    "evening", "during", "string", "bring", "king", "ring", "sing", "spring",
    "wing", "being",
}
_EMOTIONAL = re.compile(
    r"\b(?:miss you|love you|i feel|i felt|feel like|feeling|so much|"
    r"proud of you|i'm sad|i'm tired|lonely|i wish)\b", re.I,
)
_HEDGE = re.compile(
    r"(?:, but\b|\bi guess\b|\byou know\b|\bi mean\b|\bkinda\b|\bsort of\b|"
    r"\bor something\b|\bi'm just\b|\bi think\b|\bmaybe\b|\bprobably\b)", re.I,
)
# An instruction for the task at hand, not a standing rule.
_MOMENTARY = re.compile(
    r"\b(?:this time|tonight|right now|for now|today|until|yet|anymore)\b", re.I,
)
_FILLER = re.compile(r"\b(?:bro|man|dude|lol|tbh|whatever|like,)", re.I)
_FIRST_PERSON = re.compile(r"\b(?:i|i'm|i've|i'll|i'd|we|we're)\b", re.I)
_THIRD_PERSON = re.compile(r"\b(?:they|their|them|he|she|his|her)\b", re.I)
_VAGUE = {"it", "that", "this", "those", "these"}
_MIN_RULE_WORDS = 3       # words after the trigger
_MAX_RULE_WORDS = 20      # longer than this is a run-on voice turn, not a rule
_MIN_CONFIDENCE = 0.75
# Leads a canonical rule already carries; render() adds DO/DON'T otherwise.
_CANONICAL_LEAD = re.compile(
    r"^(?:don'?t|do\s+not|never|stop|always|remember|make\s+sure|"
    r"from\s+now\s+on|avoid)\b", re.I,
)
# Prompt boilerplate from Leon's own daemons. Those prompts pass through the
# same responder as Dean's turns; their "Do not ..." lines are instructions to
# the model, not things Dean said, and were being stored as his rules.
_DAEMON_PROMPT_MARKERS = (
    "AMBIENT GLANCE", "SOCIAL INITIATIVE", "SPONTANEOUS THOUGHT", "INITIATIVE —",
    "SELF-AWARENESS:", "Output exactly QUIET", "[LEON COGNITIVE STATE",
    "You have some observations from your background monitoring",
)

_MAX_LESSON_LEN = 240
_MIN_LESSON_LEN = 5
_DECAY_PER_DAY = 0.02
_WEIGHT_BOOST_REPEAT = 0.15
_WEIGHT_INIT = 0.6


@dataclass
class Lesson:
    id: int
    text: str
    scope: str
    polarity: str
    weight: float
    created_ts: float
    last_seen_ts: float
    hit_count: int
    source: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class LessonStore:
    """Persistent rule store. Sqlite, WAL, thread-safe."""

    def __init__(self, *, path: Optional[str] = None):
        self.path = path or os.path.expanduser("~/.leon/lessons.db")
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            self.path, check_same_thread=False, isolation_level=None,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass

    # -- capture -------------------------------------------------------

    def capture_from_turn(self, user_text: str,
                          *, source: str = "user") -> List[Lesson]:
        """Try to extract one or more lessons from a single Dean turn."""
        out: List[Lesson] = []
        for pol, clean in extract_rules(user_text):
            scope = _infer_scope(user_text, clean)
            lesson = self.add(text=clean, polarity=pol, scope=scope,
                              source=source)
            if lesson is not None:
                out.append(lesson)
        return out

    def add(
        self, *,
        text: str,
        polarity: str = "dont",
        scope: str = "global",
        source: Optional[str] = None,
    ) -> Optional[Lesson]:
        """Add or merge a lesson. If a near-duplicate exists, bump its weight."""
        text = (text or "").strip()
        if len(text) < _MIN_LESSON_LEN or len(text) > _MAX_LESSON_LEN:
            return None
        if polarity not in ("do", "dont"):
            polarity = "dont"
        now = time.time()
        with self._lock:
            # near-duplicate check (case-insensitive substring within scope)
            dup = self._find_duplicate(text, scope)
            if dup is not None:
                new_weight = min(1.0, dup["weight"] + _WEIGHT_BOOST_REPEAT)
                self._conn.execute(
                    "UPDATE lessons SET last_seen_ts=?, hit_count=hit_count+1, weight=? WHERE id=?",
                    (now, new_weight, dup["id"]),
                )
                row = self._conn.execute(
                    "SELECT * FROM lessons WHERE id=?", (dup["id"],),
                ).fetchone()
                return _row(row)
            cur = self._conn.execute(
                """INSERT INTO lessons
                    (text, scope, polarity, weight, created_ts, last_seen_ts, hit_count, source)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (text, scope, polarity, _WEIGHT_INIT, now, now, 1, source),
            )
            row = self._conn.execute(
                "SELECT * FROM lessons WHERE id=?", (cur.lastrowid,),
            ).fetchone()
        log.info("captured lesson [%s,%s] %s", scope, polarity, text[:80])
        return _row(row)

    # -- query ---------------------------------------------------------

    def all(self, *, limit: int = 200, apply_decay: bool = True) -> List[Lesson]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM lessons ORDER BY weight DESC, last_seen_ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
        if apply_decay:   # False = Leon V2 shadow dry run: same rows, no writes
            self._apply_decay(rows)
        return [_row(r) for r in rows]

    def relevant(
        self, *,
        text: str = "",
        scope_hints: Optional[List[str]] = None,
        limit: int = 6,
        apply_decay: bool = True,
    ) -> List[Lesson]:
        """Return the top-K lessons relevant to the current turn.

        Relevance scoring:
          • exact scope match           +1.0
          • scope == 'global'           +0.3
          • token overlap with `text`   +0.5 * overlap_ratio
          • base weight                 +1.0 * weight
          • recency (last 7d)           +0.2
        """
        hints = set(scope_hints or [])
        hints.add("global")
        now = time.time()
        text_tokens = set(_tokens(text or ""))
        rows = self.all(limit=200, apply_decay=apply_decay)
        scored: List[Tuple[float, Lesson]] = []
        for L in rows:
            score = 1.0 * L.weight
            if L.scope in hints:
                score += 1.0 if L.scope != "global" else 0.3
            if text_tokens:
                lt = set(_tokens(L.text))
                if lt:
                    overlap = len(text_tokens & lt) / max(1, len(lt))
                    score += 0.5 * overlap
            if (now - L.last_seen_ts) < 7 * 86400:
                score += 0.2
            scored.append((score, L))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [L for _, L in scored[:limit]]

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            n = self._conn.execute("SELECT COUNT(*) AS n FROM lessons").fetchone()["n"]
            by_scope = self._conn.execute(
                "SELECT scope, COUNT(*) AS n FROM lessons GROUP BY scope"
            ).fetchall()
            by_pol = self._conn.execute(
                "SELECT polarity, COUNT(*) AS n FROM lessons GROUP BY polarity"
            ).fetchall()
        return {
            "total": n,
            "by_scope": {r["scope"]: r["n"] for r in by_scope},
            "by_polarity": {r["polarity"]: r["n"] for r in by_pol},
        }

    def remove(self, lesson_id: int) -> bool:
        with self._lock:
            cur = self._conn.execute("DELETE FROM lessons WHERE id=?", (lesson_id,))
            return cur.rowcount > 0

    # -- internals -----------------------------------------------------

    def _find_duplicate(self, text: str, scope: str):
        rows = self._conn.execute(
            "SELECT id, weight FROM lessons WHERE scope=?", (scope,),
        ).fetchall()
        ttl = text.lower()
        for r in rows:
            existing_text = self._conn.execute(
                "SELECT text FROM lessons WHERE id=?", (r["id"],),
            ).fetchone()["text"].lower()
            if ttl == existing_text:
                return r
            # cheap substring containment counts as dup
            if len(ttl) > 12 and (ttl in existing_text or existing_text in ttl):
                return r
        return None

    def _apply_decay(self, rows) -> None:
        """Apply mild weight decay for rows we just read but haven't seen
        recently. Cheap; runs at most once per query."""
        now = time.time()
        for r in rows:
            age_days = (now - (r["last_seen_ts"] or now)) / 86400.0
            if age_days < 7:
                continue
            decay = min(0.5, age_days * _DECAY_PER_DAY)
            new_w = max(0.05, (r["weight"] or 0.0) - decay)
            try:
                self._conn.execute(
                    "UPDATE lessons SET weight=? WHERE id=? AND weight>?",
                    (new_w, r["id"], new_w),
                )
            except Exception:
                pass


def _row(row) -> Lesson:
    return Lesson(
        id=row["id"], text=row["text"],
        scope=row["scope"] or "global",
        polarity=row["polarity"] or "dont",
        weight=float(row["weight"] or 0.0),
        created_ts=float(row["created_ts"] or 0.0),
        last_seen_ts=float(row["last_seen_ts"] or 0.0),
        hit_count=int(row["hit_count"] or 0),
        source=row["source"],
    )


def _tokens(s: str) -> List[str]:
    return [t for t in re.findall(r"[a-z0-9]{3,}", s.lower())][:64]


def extract_rules(user_text: str) -> List[Tuple[str, str]]:
    """(polarity, canonical rule) for every sentence of `user_text` that is a
    complete instruction Dean gave about Leon's behavior. Empty for ordinary
    talk."""
    return [(c["polarity"], c["rule"]) for c in judge_candidates(user_text)
            if c["accepted"]]


def judge_candidates(user_text: str) -> List[Dict[str, Any]]:
    """Every trigger-led sentence of `user_text`, scored. Each entry has
    polarity, rule (canonical text, or "" if none could be formed),
    confidence, accepted, reason and the raw sentence. Rejections are logged
    at debug level so the capture can be audited."""
    if not user_text or len(user_text) < _MIN_LESSON_LEN:
        return []
    if any(m in user_text for m in _DAEMON_PROMPT_MARKERS):
        return []
    out: List[Dict[str, Any]] = []
    for sentence in _SENTENCE_SPLIT.split(user_text.replace("’", "'")):
        s = sentence.strip()
        if not s:
            continue
        for _ in range(4):
            stripped = _LEAD_IN.sub("", s, count=1).strip()
            if stripped == s:
                break
            s = stripped
        cand = _judge_sentence(s)
        if cand is None:
            continue
        cand["sentence"] = sentence.strip()
        if not cand["accepted"]:
            log.debug("lesson candidate rejected (%s, conf=%.2f): %r",
                      cand["reason"], cand["confidence"], cand["sentence"][:80])
        out.append(cand)
    return out


def _judge_sentence(s: str) -> Optional[Dict[str, Any]]:
    """None if `s` doesn't open with a trigger; else a scored candidate."""
    if s.endswith("?"):
        if _starts_with_trigger(s.rstrip(" ?")):
            return _cand("dont", "", 0.0, "question")
        return None
    s = s.rstrip(" .!;")
    m = _PAT_REMEMBER.match(s)
    if m:
        return _judge_body("do", "Remember:", m.group(1), fact=True)
    m = _PAT_FROM_NOW_ON.match(s)
    if m:
        rest = _clean(m.group(1))
        inner = _match_trigger(rest)
        if inner is not None:
            return _judge_body(*inner)
        return _judge_body("do", "From now on,", _YOU_MODAL.sub("", rest, count=1))
    trig = _match_trigger(s)
    if trig is None:
        return None
    return _judge_body(*trig)


def _starts_with_trigger(s: str) -> bool:
    return bool(_PAT_REMEMBER.match(s) or _PAT_FROM_NOW_ON.match(s)
                or _match_trigger(s))


def _match_trigger(s: str) -> Optional[Tuple[str, str, str]]:
    for pat, pol, lead in _TRIGGERS:
        m = pat.match(s)
        if m:
            return pol, lead, m.group(1)
    return None


def _clean(body: str) -> str:
    body = re.sub(r"\s+", " ", body or "").strip(" ,.;:!-")
    # trailing tags that aren't part of the instruction: ", please", ", ok"
    body = re.sub(r"(?:,\s*(?:please|ok(?:ay)?|bro|man|dude|alright))+$", "",
                  body, flags=re.I)
    return body.strip(" ,.;:!-")


def _cand(pol: str, rule: str, conf: float, reason: str) -> Dict[str, Any]:
    return {"polarity": pol, "rule": rule, "confidence": round(conf, 2),
            "accepted": bool(rule) and conf >= _MIN_CONFIDENCE, "reason": reason}


def _judge_body(pol: str, lead: str, body: str, *,
                fact: bool = False) -> Dict[str, Any]:
    """Score what follows the trigger and, if it is a real instruction,
    build the canonical rule `<lead> <body>.`"""
    body = _clean(body)
    words = body.split()
    low = body.lower()
    first = words[0].lower().strip(",.;:'\"") if words else ""
    if len(words) < _MIN_RULE_WORDS + (1 if fact else 0):
        return _cand(pol, "", 0.0, "too short")
    if len(words) > _MAX_RULE_WORDS:
        return _cand(pol, "", 0.0, "run-on, not a rule")
    if _EMOTIONAL.search(body):
        return _cand(pol, "", 0.0, "emotional statement")
    if _HEDGE.search(body):
        return _cand(pol, "", 0.0, "hedged talk")
    if _MOMENTARY.search(body):
        return _cand(pol, "", 0.0, "about the task at hand")
    if not fact:
        if lead == "Stop":
            verb_ok = (first.endswith("ing") and len(first) >= 5
                       and first not in _NOT_GERUNDS)
        else:
            verb_ok = first in _IMPERATIVE_VERBS
        if not verb_ok:
            return _cand(pol, "", 0.0, f"no imperative verb ({first!r})")
        if len(words) <= 4 and any(w.lower().strip(",.") in _VAGUE for w in words):
            return _cand(pol, "", 0.0, "vague reference")
    conf = 1.0
    if _FILLER.search(body):
        conf -= 0.3
    if not fact and _FIRST_PERSON.search(body):
        conf -= 0.2      # often about Dean, not about how Leon behaves
    if _THIRD_PERSON.search(body):
        conf -= 0.2      # often about someone else
    if len(words) > 14:
        conf -= 0.15
    if len(re.findall(r"\band\b|,", low)) > 1:
        conf -= 0.1      # chained clauses: likely talk running on
    rule = f"{lead} {body}."
    if len(rule) > _MAX_LESSON_LEN:
        return _cand(pol, "", 0.0, "too long")
    return _cand(pol, rule, conf, "ok" if conf >= _MIN_CONFIDENCE else "low confidence")


def render(text: str, polarity: str) -> str:
    """One prompt line for a lesson. Canonical rules already say DO/DON'T in
    their own words; older or manual ones get a tag."""
    text = (text or "").strip()
    if _CANONICAL_LEAD.match(text):
        return text
    return ("DO: " if polarity == "do" else "DON'T: ") + text


def _infer_scope(full_text: str, lesson_text: str) -> str:
    """Best-effort scope inference from the rule itself. Default 'global'.
    (Scanning the whole turn tagged rules app:code whenever Dean said
    "code" anywhere in it.)"""
    low = (lesson_text or "").lower()
    # tool scope
    m = re.search(r"\b(tool|use|using|call|fire|run)\s+([a-z_][a-z0-9_.]+)\b", low)
    if m:
        cand = m.group(2)
        if "." in cand or "_" in cand:
            return f"tool:{cand}"
    # app scope
    for app in ("brave", "chrome", "spotify", "discord", "slack", "vscode",
                "obsidian", "soundcloud", "gmail", "calendar"):
        if re.search(rf"\b{app}\b", low):
            return f"app:{app}"
    return "global"


__all__ = ["LessonStore", "Lesson", "extract_rules", "judge_candidates", "render"]
