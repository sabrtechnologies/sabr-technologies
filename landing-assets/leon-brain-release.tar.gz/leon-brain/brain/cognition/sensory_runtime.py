"""Phase 5 lifecycle adapter; the existing runtime owns its tick and retirement.

Importing or constructing this adapter performs no I/O. The first explicitly
enabled tick loads only the derived scene file at the supplied owning state
directory. Capture, inference, legacy perception and canonical memory ownership
do not change. The existing SceneModel persister remains the only disk writer.
"""
from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any, Callable, Optional

log = logging.getLogger("leon.v2.sensory_runtime")
LIVE_FEATURE = "sensory_hub"


class SensoryRuntime:
    """One runtime's hub/scene owner. OFF is lazy; every enabled mode is SHADOW.

    A stopped or failed owner is retained until stop() confirms the persister
    and final save completed. A failed save is not successful retirement.
    """

    def __init__(self, *, state: Any, state_dir: Optional[str],
                 configured_mode: str, live_mode: Callable[[], str],
                 runtime_accepting: Callable[[], bool]) -> None:
        self._state = state
        self._path = os.fspath(state_dir) if state_dir is not None else None
        self._path_valid = bool(self._path and os.path.isabs(self._path))
        self._configured_mode = configured_mode
        self._live_mode = live_mode
        self._runtime_accepting = runtime_accepting
        self._lock = threading.Lock()
        self._admission_lock = threading.Lock()
        self._inflight = 0
        self._idle = threading.Event()
        self._idle.set()
        self._stopping = False
        self._retired = False
        self._ready = False
        self._hub_module = None
        self.hub = None
        self.scene = None
        self._failures = 0
        self._warned = -1e18
        self._reason = "off" if self._path_valid else "missing_explicit_state_dir"

    def mode(self) -> str:
        if self._stopping or not self._ready or not self._requested():
            return "off"
        return "shadow"

    def _requested(self) -> bool:
        try:
            return (self._path_valid and self._configured_mode in ("shadow", "canary", "on")
                    and self._runtime_accepting()
                    and self._live_mode() in ("shadow", "canary", "on"))
        except Exception:
            return False

    def _failed(self, where: str, exc: BaseException) -> None:
        self._failures += 1
        self._reason = where
        now = time.monotonic()
        if now - self._warned >= 60:
            self._warned = now
            log.warning("[V2] sensory lifecycle %s failed exc=%s "
                        "recovery=retain owner; retry on next lifecycle call",
                        where, type(exc).__name__)

    def tick(self) -> None:
        """Bounded observation flush from the existing runtime, no new loop."""
        if self._stopping or not self._requested() or not self._lock.acquire(blocking=False):
            return
        try:
            if self._stopping:
                return
            if self.hub is None:
                from brain import sensory_hub
                from brain.scene_model import SceneModel, default_path
                # Never replace an unknown/current producer or a draining owner.
                # Use the facade's existing ownership lock across check/install;
                # install() itself is a replacing API, not compare-and-install.
                if not sensory_hub._install_lock.acquire(timeout=0.005):
                    self._reason = "hub_install_busy"
                    return
                try:
                    if sensory_hub.get_hub() is not None:
                        self._reason = "previous_hub_retained"
                        return
                    self._hub_module = sensory_hub
                    self.scene = SceneModel(default_path(self._path))
                    self.hub = self._make_hub(sensory_hub)
                    sensory_hub.install(self.hub)
                    self._state.sensory_hub = self.hub
                    self._state.scene_model = self.scene
                finally:
                    sensory_hub._install_lock.release()
            if self._hub_module.get_hub() is not self.hub:
                self._reason = "hub_ownership_changed"
                self.quiesce()
                return
            if not self._ready:
                if not self.scene.start_persister():
                    self._reason = "persister_not_started"
                    return
                self._ready = True
            self._reason = "shadow"
            self.hub.flush_pending()
        except Exception as exc:
            self._failed("activation_or_flush", exc)
        finally:
            self._lock.release()

    def _make_hub(self, module: Any) -> Any:
        owner = self

        class OwnedHub(module.SensoryHub):
            # Cover the entire ingest -> scene.apply -> publish transaction.
            # Merely setting mode=off cannot drain a producer already in apply().
            def ingest(self, *args: Any, **kwargs: Any) -> Any:
                if not owner._admission_lock.acquire(timeout=0.005):
                    return None
                try:
                    if owner.mode() == "off":
                        return None
                    owner._inflight += 1
                    owner._idle.clear()
                finally:
                    owner._admission_lock.release()
                try:
                    return super().ingest(*args, **kwargs)
                finally:
                    with owner._admission_lock:
                        owner._inflight -= 1
                        if not owner._inflight:
                            owner._idle.set()

        return OwnedHub(self.scene, mode_fn=self.mode)

    def quiesce(self) -> None:
        """Immediate admission cutoff. No lock wait or I/O on shutdown caller."""
        self._stopping = True

    def stop(self, *, join_timeout: float = 0.25) -> bool:
        """Drain on the runtime worker, or explicit bounded retirement retry.

        The existing persister's final atomic save can outlast its join timeout;
        callers must not invoke this on the nonblocking shutdown path. The
        runtime worker's finally block performs this operation instead.
        """
        self.quiesce()
        if not self._lock.acquire(blocking=False):
            return False
        try:
            if self._retired:
                return True
            # Synchronize with a producer that passed mode() immediately before
            # quiesce, but has not yet incremented the in-flight count.
            if not self._admission_lock.acquire(timeout=max(0.0, join_timeout)):
                self._reason = "producer_retirement_pending"
                return False
            self._admission_lock.release()
            if not self._idle.wait(max(0.0, join_timeout)):
                self._reason = "producer_retirement_pending"
                return False
            if self.scene is not None:
                if self.scene.stop_persister(flush=True, join_timeout=join_timeout) is False:
                    self._reason = "persistence_retirement_pending"
                    return False
            if self._hub_module is not None and self._hub_module.get_hub() is self.hub:
                if not self._hub_module.uninstall(flush=False):
                    self._reason = "hub_retirement_pending"
                    return False
            if self.hub is not None and getattr(self._state, "sensory_hub", None) is self.hub:
                self._state.sensory_hub = None
            if self.scene is not None and getattr(self._state, "scene_model", None) is self.scene:
                self._state.scene_model = None
            self._retired = True
            self._reason = "retired"
            return True
        except Exception as exc:
            self._failed("retirement_failed", exc)
            return False
        finally:
            self._lock.release()

    @property
    def retired(self) -> bool:
        return self._retired

    def stats(self) -> dict:
        # Paths, captions, feature values and scene contents are deliberately absent.
        return {"mode": self.mode(), "reason": self._reason,
                "has_owner": self.hub is not None, "ready": self._ready,
                "stopping": self._stopping, "retired": self._retired,
                "inflight": self._inflight,
                "failures": self._failures}
