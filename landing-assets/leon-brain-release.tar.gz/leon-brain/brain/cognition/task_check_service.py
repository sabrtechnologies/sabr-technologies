"""Private, bounded execution broker for operator-configured named checks.

No task planning, inference, grant issuance, arbitrary command or replay. The
parent TaskWorker remains task/resource/authorization owner. This process runs
in a separately provisioned, verified cgroup and retains execution uncertainty.
"""
from __future__ import annotations

import argparse
import array
from dataclasses import asdict
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import socket
import sqlite3
import stat
import struct
import threading
import time

VERSION = 1
MAX_FRAME = 32768
MAX_RECEIPTS = 256
SOURCE_FILES = ("task_check_service.py", "task_check_bridge.py",
                "task_check_containment.py", "task_project_actions.py",
                "task_worker.py", "task_lifecycle.py", "task_check_snapshot.py",
                "improvement_artifacts.py")
SERVICE_MODULES = tuple(name for name in SOURCE_FILES if name != 'task_check_bridge.py')
ACTION_FIELDS = ("action_id", "task_id", "idem_key", "name", "arguments",
                 "resources", "tier", "fingerprint", "state", "dispatched")
TASK_FIELDS = ("task_id", "project_scope", "authorization_ref", "state",
               "cancel_requested", "deadline_wall")


class CheckServiceUnavailable(RuntimeError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def _identifier(value, maximum=200):
    if (not isinstance(value, str) or not value or len(value) > maximum
            or any(ord(c) < 32 for c in value)):
        raise CheckServiceUnavailable("bounded_identifier_required")
    return value


def _absolute(path):
    if (not isinstance(path, str) or not path.startswith("/") or "\0" in path
            or os.path.realpath(path) != path or os.path.normpath(path) != path):
        raise CheckServiceUnavailable("unaliased_absolute_path_required")
    return path


def source_pin(path):
    """Root-owned code/config with immutable-to-service parent directories."""
    path = _absolute(path)
    for parent in (Path(path).parent, *Path(path).parent.parents):
        info = parent.stat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise CheckServiceUnavailable("operator_owned_source_directory_required")
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != 0
                or before.st_mode & 0o7022 or before.st_size > 64 * 1024 * 1024):
            raise CheckServiceUnavailable("operator_owned_source_file_required")
        value = hashlib.sha256()
        while True:
            data = os.read(fd, 65536)
            if not data:
                break
            value.update(data)
        after = os.fstat(fd)
        current = os.stat(path, follow_symlinks=False)
        if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                or (current.st_dev, current.st_ino) != (before.st_dev, before.st_ino)):
            raise CheckServiceUnavailable("source_changed_during_read")
        return {"path": path, "sha256": value.hexdigest(), "dev": before.st_dev, "ino": before.st_ino}
    finally:
        os.close(fd)


def source_snapshot(directory):
    return {name: source_pin(str(Path(directory) / name)) for name in SOURCE_FILES}


def install_source_loader(directory, pins, *, package_name='_leon_check_execution'):
    """Compile verified app source directly; never load cached application pyc."""
    import importlib.abc
    import importlib.util
    import sys
    import types
    compiled = {'task_check_service.py': pins['task_check_service.py']['sha256']}
    class PinnedLoader(importlib.abc.MetaPathFinder, importlib.abc.Loader):
        def find_spec(self, fullname, path=None, target=None):
            if not fullname.startswith(package_name + '.'):
                return None
            name = fullname[len(package_name) + 1:] + '.py'
            if name not in SERVICE_MODULES or '.' in name[:-3]:
                raise CheckServiceUnavailable('unmanifested_service_import')
            return importlib.util.spec_from_loader(fullname, self, origin=pins[name]['path'])

        def create_module(self, spec):
            return None

        def exec_module(self, module):
            name = module.__name__.rsplit('.', 1)[1] + '.py'
            pin = pins[name]
            if source_pin(pin['path']) != pin:
                raise CheckServiceUnavailable('source_changed_before_compile')
            data = Path(pin['path']).read_bytes()
            if hashlib.sha256(data).hexdigest() != pin['sha256'] or source_pin(pin['path']) != pin:
                raise CheckServiceUnavailable('source_changed_before_compile')
            module.__file__ = pin['path']
            exec(compile(data, pin['path'], 'exec'), module.__dict__)
            compiled[name] = pin['sha256']
    package = types.ModuleType(package_name)
    package.__path__ = [directory]
    if package_name in sys.modules:
        raise CheckServiceUnavailable('service_package_already_loaded')
    sys.modules[package_name] = package
    loader = PinnedLoader()
    sys.meta_path.insert(0, loader)
    return loader, compiled


def load_operator_configuration(path, expected_sha256):
    """Read pinned local configuration, never an IPC/request-selected file."""
    before = source_pin(path)
    if before["sha256"] != expected_sha256:
        raise CheckServiceUnavailable("operator_configuration_changed")
    if os.stat(path).st_size > MAX_FRAME:
        raise CheckServiceUnavailable("operator_configuration_too_large")
    config = json.loads(Path(path).read_text())
    if source_pin(path) != before:
        raise CheckServiceUnavailable("operator_configuration_changed")
    fields = {"version", "socket_path", "broker_path", "client_uid", "scope", "root",
              "checks", "forbidden_roots", "shared_resources", "source_sha256"}
    if (type(config) is not dict or set(config) not in (fields, fields | {'immutable_runtime'}) or config["version"] != VERSION
            or type(config["client_uid"]) is not int or config["client_uid"] < 0):
        raise CheckServiceUnavailable("exact_operator_configuration_required")
    _absolute(config["socket_path"]); _absolute(config["broker_path"])
    if not config["broker_path"].endswith(".sqlite"):
        raise CheckServiceUnavailable("fixed_broker_database_required")
    snapshot = source_snapshot(str(Path(__file__).resolve().parent))
    if config["source_sha256"] != {name: pin["sha256"] for name, pin in snapshot.items()}:
        raise CheckServiceUnavailable("operator_source_manifest_changed")
    if 'immutable_runtime' in config:
        from .task_check_snapshot import runtime_policy
        runtime_policy(config['immutable_runtime'])
    return config, before, snapshot


def build_guard(config):
    from .task_check_containment import CheckContainment, ContainedCommand
    commands = []
    if type(config["checks"]) is not list:
        raise CheckServiceUnavailable("fixed_checks_required")
    for check in config["checks"]:
        if type(check) is not dict or set(check) != {"name", "argv", "cwd", "timeout_s"}:
            raise CheckServiceUnavailable("exact_fixed_check_configuration_required")
        if type(check["argv"]) is not list:
            raise CheckServiceUnavailable("fixed_argv_required")
        commands.append(ContainedCommand(check["name"], tuple(check["argv"]),
                                         check["cwd"], check["timeout_s"]))
    if type(config["forbidden_roots"]) is not list or type(config["shared_resources"]) is not list:
        raise CheckServiceUnavailable("fixed_workspace_policy_required")
    guard = CheckContainment(scope=config["scope"], root=config["root"], checks=tuple(commands),
        forbidden_roots=tuple(config["forbidden_roots"]), shared_resources=tuple(config["shared_resources"]))
    # Broker/runtime metadata must never be visible in the writable workspace.
    for path in (config["broker_path"], config["socket_path"]):
        parent = str(Path(path).parent)
        if os.path.commonpath((parent, guard.workspace.root)) in (parent, guard.workspace.root):
            raise CheckServiceUnavailable("execution_metadata_overlaps_workspace")
        if not any(os.path.commonpath((parent, forbidden)) == forbidden for forbidden in config["forbidden_roots"]):
            raise CheckServiceUnavailable("execution_metadata_must_be_forbidden")
    return guard


def wire_request(action, task, spec):
    """Send the exact attempt identity, never checkpoint, conversation or argv."""
    value = {"action": {key: action.get(key) for key in ACTION_FIELDS},
             "task": {key: task.get(key) for key in TASK_FIELDS}, "spec": asdict(spec)}
    data = canonical(value).encode()
    if len(data) > MAX_FRAME - 1024:
        raise CheckServiceUnavailable("bounded_execution_request_required")
    return json.loads(data)


def validate_request(value, resolve_spec):
    if type(value) is not dict or set(value) not in ({"action", "task", "spec"}, {"action", "task", "spec", "immutable"}):
        raise CheckServiceUnavailable("exact_execution_request_required")
    action, task = value["action"], value["task"]
    if (type(action) is not dict or set(action) != set(ACTION_FIELDS)
            or type(task) is not dict or set(task) != set(TASK_FIELDS)):
        raise CheckServiceUnavailable("exact_attempt_fields_required")
    for key in ("action_id", "task_id", "idem_key", "fingerprint"):
        _identifier(action[key])
    for key in ("task_id", "project_scope", "authorization_ref"):
        _identifier(task[key])
    if (action["name"] != "project.run_check" or action["task_id"] != task["task_id"]
            or action["state"] != "RUNNING" or action["dispatched"] is not True
            or task["state"] != "RUNNING" or task["cancel_requested"] is not False):
        raise CheckServiceUnavailable("committed_attempt_required")
    spec = resolve_spec(action["name"], action["arguments"], task)
    if canonical(value["spec"]) != canonical(asdict(spec)):
        raise CheckServiceUnavailable("canonical_spec_mismatch")
    if (type(action["tier"]) is not int or action["tier"] != 3 or spec.minimum_tier != 3
            or action["resources"] != list(spec.resources)):
        raise CheckServiceUnavailable("exact_attempt_policy_required")
    expected = hashlib.sha256(json.dumps([action["name"], canonical(action["arguments"]),
                                         list(spec.resources), action["tier"]]).encode()).hexdigest()
    if action["fingerprint"] != expected:
        raise CheckServiceUnavailable("attempt_fingerprint_mismatch")
    deadline = task["deadline_wall"]
    if deadline is not None and (isinstance(deadline, bool) or not isinstance(deadline, (int, float))
                                 or not math.isfinite(deadline) or time.time() >= deadline):
        raise CheckServiceUnavailable("deadline_before_execution")
    return spec


def _receive(sock, timeout=3, *, allow_fd=False):
    end = time.monotonic() + timeout
    descriptors=[]
    def read(size):
        data = bytearray()
        while len(data) < size:
            remaining = end - time.monotonic()
            if remaining <= 0:
                raise CheckServiceUnavailable("ipc_read_timeout")
            sock.settimeout(remaining)
            chunk, ancillary, flags, _ = sock.recvmsg(size-len(data), socket.CMSG_SPACE(8*array.array('i').itemsize),
                                                     socket.MSG_CMSG_CLOEXEC)
            malformed=False
            for level, kind, payload in ancillary:
                if level != socket.SOL_SOCKET or kind != socket.SCM_RIGHTS:
                    malformed=True; continue
                received=array.array('i')
                received.frombytes(payload[:len(payload)-len(payload)%received.itemsize])
                descriptors.extend(received)
                if len(payload)%received.itemsize: malformed=True
            if (malformed or flags & (socket.MSG_CTRUNC | socket.MSG_TRUNC)
                    or len(descriptors)>1 or (descriptors and not allow_fd)
                    or any(not fcntl.fcntl(fd,fcntl.F_GETFD)&fcntl.FD_CLOEXEC for fd in descriptors)):
                raise CheckServiceUnavailable('unexpected_or_truncated_descriptors')
            if not chunk:
                raise CheckServiceUnavailable("ipc_closed")
            data.extend(chunk)
        return bytes(data)
    try:
        size = struct.unpack("!I", read(4))[0]
        if not 1 <= size <= MAX_FRAME:
            raise CheckServiceUnavailable("ipc_frame_bound")
        raw=read(size)
        value = json.loads(raw, parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite")))
        if type(value) is not dict or canonical(value).encode()!=raw:
            raise CheckServiceUnavailable("canonical_ipc_object_required")
        if allow_fd:
            result=(value,descriptors[0] if descriptors else None)
            descriptors.clear()
            return result
        return value
    finally:
        for fd in descriptors: os.close(fd)


def _send(sock, value, *, on_attempt=None, descriptor=None):
    data = canonical(value).encode()
    if len(data) > MAX_FRAME:
        raise CheckServiceUnavailable("ipc_frame_bound")
    sock.settimeout(3)
    if on_attempt is not None:
        on_attempt()
    frame=struct.pack("!I",len(data))+data
    if descriptor is None:
        sock.sendall(frame)
    else:
        rights=array.array('i',[descriptor])
        sent=sock.sendmsg([frame],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,rights)])
        if sent<=0: raise CheckServiceUnavailable('descriptor_send_unverified')
        if sent<len(frame): sock.sendall(frame[sent:])


def peer_credentials(sock):
    return struct.unpack("3i", sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))


def _private_directory(path):
    path = _absolute(path)
    info = os.stat(path, follow_symlinks=False)
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
        raise CheckServiceUnavailable("private_service_directory_required")
    return path


def _private_leaf(path):
    if os.path.lexists(path):
        info = os.lstat(path)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                or info.st_uid != os.geteuid() or info.st_mode & 0o077):
            raise CheckServiceUnavailable("private_unaliased_broker_leaf_required")


def _unknown(reason):
    return {"outcome": "UNKNOWN", "details": {"ok": False, "reason": reason,
            "uncertain": True, "replay_allowed": False}}


class ExecutionBroker:
    """One executor, no queue, durable retained attempt receipts and fences."""
    def __init__(self, path, *, resolve_spec, execute, readiness, execute_snapshot=None):
        self.path = _absolute(path)
        _private_directory(str(Path(path).parent))
        self._lock = threading.RLock()
        self._thread = None
        self._stopping = False
        self._closed = False
        self._fault = False
        self._resolve_spec, self._execute_handler, self._readiness = resolve_spec, execute, readiness
        self._execute_snapshot = execute_snapshot
        self._db = None
        self._lease = None
        for leaf in (path, path + "-wal", path + "-shm", path + "-journal", path + ".lock"):
            _private_leaf(leaf)
        try:
            self._lease = os.open(path + ".lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
            fcntl.flock(self._lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
            os.close(fd)
            self._db = sqlite3.connect(path, timeout=.25, isolation_level=None, check_same_thread=False)
            self._db.row_factory = sqlite3.Row
            self._db.execute('PRAGMA synchronous=FULL')
            self._db.execute('PRAGMA journal_mode=DELETE')
            self._db.execute('''CREATE TABLE IF NOT EXISTS receipts (
              action_id TEXT PRIMARY KEY, request_sha256 TEXT NOT NULL,
              task_id TEXT NOT NULL, resources TEXT NOT NULL,
              request TEXT NOT NULL, state TEXT NOT NULL, result TEXT,
              created_wall REAL NOT NULL, completed_wall REAL)''')
            self._db.execute("UPDATE receipts SET state='UNKNOWN', result=?, completed_wall=? WHERE state='STARTED'",
                (canonical(_unknown('execution_owner_restarted')), time.time()))
        except BaseException:
            if self._db is not None:
                self._db.close()
            if self._lease is not None:
                os.close(self._lease)
            raise

    def _row(self, action_id, request_sha256):
        row = self._db.execute('SELECT * FROM receipts WHERE action_id=?', (action_id,)).fetchone()
        if row is not None and row['request_sha256'] != request_sha256:
            raise CheckServiceUnavailable('attempt_identity_conflict')
        return row

    @staticmethod
    def _receipt(row):
        if row is None:
            return {'state': 'NOT_FOUND'}
        return {'state': row['state'], 'action_id': row['action_id'],
                'request_sha256': row['request_sha256'],
                'result': json.loads(row['result']) if row['result'] is not None else None}

    def lookup(self, action_id, request_sha256):
        _identifier(action_id); _identifier(request_sha256, 64)
        with self._lock:
            return self._receipt(self._row(action_id, request_sha256))

    def ready(self):
        with self._lock:
            return (not self._stopping and not self._closed and not self._fault
                    and self._readiness() is True)

    def validate_spec(self, value):
        """Preview proves the same server registry without claiming an action."""
        try:
            if type(value) is not dict or value.get('name') != 'project.run_check':
                return False
            spec = self._resolve_spec(value['name'], dict(value['arguments']),
                                      {'project_scope': value['scope']})
            return canonical(value) == canonical(asdict(spec)) and self.ready()
        except Exception:
            return False

    def submit(self, value, *, bundle=None):
        # Freeze the request before recording or crossing into the executor.
        value = json.loads(canonical(value))
        action_id = _identifier(value.get('action', {}).get('action_id'))
        request_sha256 = digest(value)
        with self._lock:
            prior = self._row(action_id, request_sha256)
            if prior is not None:
                return self._receipt(prior)  # immutable lookup, never re-execution
            if not self.ready():
                raise CheckServiceUnavailable('execution_admission_unavailable')
            spec = validate_request(value, self._resolve_spec)
            if 'immutable' in value:
                if self._execute_snapshot is None or type(bundle) is not bytes:
                    raise CheckServiceUnavailable('immutable_execution_unavailable')
                from .task_check_snapshot import validate_material
                try: validate_material(value['immutable'],bundle,value['action'],value['task'],spec)
                except Exception as exc: raise CheckServiceUnavailable('immutable_material_invalid') from exc
            elif bundle is not None:
                raise CheckServiceUnavailable('ordinary_execution_rejects_descriptor')
            if self._thread is not None and self._thread.is_alive():
                raise CheckServiceUnavailable('single_executor_busy')
            if self._db.execute('SELECT count(*) FROM receipts').fetchone()[0] >= MAX_RECEIPTS:
                raise CheckServiceUnavailable('retained_receipt_capacity_exhausted')
            for row in self._db.execute("SELECT resources FROM receipts WHERE state IN ('STARTED','UNKNOWN')"):
                if set(json.loads(row[0])) & set(spec.resources):
                    raise CheckServiceUnavailable('uncertain_execution_resource_fence')
            self._db.execute('INSERT INTO receipts VALUES (?,?,?,?,?,\'STARTED\',NULL,?,NULL)',
                (action_id, request_sha256, value['task']['task_id'], canonical(list(spec.resources)),
                 canonical(value), time.time()))
            # STARTED is synchronous-durable before the thread can do anything.
            self._thread = threading.Thread(target=self._execute, args=(value,bundle),
                                             name='leon-confined-check', daemon=False)
            try:
                self._thread.start()
            except BaseException:
                self._record(action_id, _unknown('executor_start_unverified'))
                if not self._thread.is_alive():
                    self._thread = None
                raise
            return self._receipt(self._row(action_id, request_sha256))

    def permits(self, action, task, spec):
        """Internal already-recorded attempt proof; never issues a task grant."""
        value = wire_request(action, task, spec)
        with self._lock:
            if self._thread is None or threading.current_thread() is not self._thread:
                return False
            row = self._row(action['action_id'], digest(value))
            return row is not None and row['state'] == 'STARTED'

    def _record(self, action_id, result):
        self._db.execute('UPDATE receipts SET state=?, result=?, completed_wall=? WHERE action_id=? AND state=\'STARTED\'',
            (result['outcome'], canonical(result), time.time(), action_id))

    def _execute(self, value, bundle=None):
        result = _unknown('execution_result_unverified')
        try:
            spec = validate_request(value, self._resolve_spec)
            # Recheck readiness in the actual execution cgroup immediately before effects.
            if self._readiness() is not True:
                result = {'outcome': 'FAILED', 'details': {'ok': False, 'executed': False,
                          'reason': 'containment_unavailable_before_execution'}}
            else:
                if 'immutable' in value:
                    answer=self._execute_snapshot(value,bundle,spec)
                else:
                    answer = self._execute_handler(value['action'], value['task'])
                result = {'outcome': answer.outcome, 'details': dict(answer.details)}
                if len(canonical(result).encode()) > 8192 or result['outcome'] not in ('SUCCEEDED', 'FAILED', 'UNKNOWN'):
                    result = _unknown('execution_result_invalid')
                elif result['outcome'] == 'SUCCEEDED' and not all(result['details'].get(k) is True
                        for k in ('ok', 'namespace_drained', 'process_drained')):
                    result = _unknown('successful_execution_lacks_drain_proof')
                elif result['outcome'] == 'FAILED' and result['details'].get('executed') is not False and not all(
                        result['details'].get(k) is True for k in ('namespace_drained', 'process_drained')):
                    result = _unknown('failed_execution_lacks_drain_proof')
                elif result['outcome'] == 'FAILED' and result['details'].get('ok') is not False:
                    result = _unknown('failed_execution_semantics_invalid')
                if 'immutable' in value and result['outcome']=='SUCCEEDED':
                    from .task_check_snapshot import validate_proof
                    proof=result['details'].get('input_proof')
                    if type(proof) is not dict:
                        result=_unknown('immutable_completion_proof_missing')
                    else:
                        validate_proof(proof,value['immutable'],runtime_sha256=proof.get('runtime_sha256'),request_sha256=digest(value))
                        if result['details'].get('immutable_receipt')!={'action_id':value['action']['action_id'],
                                'request_sha256':digest(value),'proof_sha256':digest(proof)}:
                            result=_unknown('immutable_completion_binding_differs')
        except Exception:
            result = _unknown('execution_exception')
        finally:
            with self._lock:
                try:
                    self._record(value['action']['action_id'], result)
                except Exception:
                    self._fault = True  # retained STARTED becomes UNKNOWN on restart

    def stop(self, timeout=0):
        with self._lock:
            self._stopping = True
            thread = self._thread
        if thread is not None:
            thread.join(max(0, min(float(timeout), 125)))
            if thread.is_alive():
                return False
        with self._lock:
            if not self._closed:
                self._db.close()
                os.close(self._lease)
                self._closed = True
            return True


class CheckService:
    """One bounded Unix request at a time plus the broker's sole executor."""
    def __init__(self, *, socket_path, client_uid, broker, identity):
        self.socket_path = _absolute(socket_path)
        _private_directory(str(Path(socket_path).parent))
        self.client_uid, self.broker, self._identity = client_uid, broker, identity
        self._socket = None
        self._inode = None
        self._stopping = threading.Event()

    def open(self):
        if self._socket is not None or os.path.lexists(self.socket_path):
            raise CheckServiceUnavailable('socket_already_exists_requires_operator_review')
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            listener.bind(self.socket_path)
            os.chmod(self.socket_path, 0o600)
            self._inode = os.lstat(self.socket_path).st_ino
            listener.listen(4)
            listener.settimeout(.1)
            self._socket = listener
            return self
        except BaseException:
            listener.close()
            raise

    def _connection(self, connection):
        if peer_credentials(connection)[1] != self.client_uid:
            return
        hello = _receive(connection)
        if set(hello) != {'op', 'nonce'} or hello['op'] != 'hello':
            return
        nonce = _identifier(hello['nonce'], 64)
        identity = self._identity()
        _send(connection, {**identity, 'nonce': nonce, 'ready': self.broker.ready()})
        request,descriptor = _receive(connection,allow_fd=True)
        try:
            if request.get('op')=='execute' and type(request.get('request')) is not dict:
                raise CheckServiceUnavailable('exact_execution_request_required')
            if descriptor is not None and (request.get('op')!='execute' or 'immutable' not in request.get('request',{})):
                raise CheckServiceUnavailable('unexpected_execution_descriptor')
            if request.get('op') == 'status' and set(request) == {'op', 'spec'}:
                response = {'ready': self.broker.validate_spec(request['spec'])}
            elif request.get('op') == 'execute' and set(request) == {'op', 'request'}:
                bundle=None
                if 'immutable' in request['request']:
                    if descriptor is None: raise CheckServiceUnavailable('immutable_descriptor_required')
                    from .task_check_snapshot import read_sealed_fd
                    try: bundle=read_sealed_fd(descriptor)
                    except Exception as exc: raise CheckServiceUnavailable('immutable_descriptor_invalid') from exc
                response = self.broker.submit(request['request'],bundle=bundle)
            elif request.get('op') == 'lookup' and set(request) == {'op', 'action_id', 'request_sha256'}:
                response = self.broker.lookup(request['action_id'], request['request_sha256'])
            else:
                raise CheckServiceUnavailable('unsupported_service_operation')
            _send(connection, {'ok': True, 'value': response})
        except CheckServiceUnavailable as exc:
            _send(connection, {'ok': False, 'reason': str(exc), 'accepted': False})
        except Exception:
            # A database/thread-start exception may occur after STARTED was
            # durably written. Never describe that as definitive nonexecution.
            _send(connection, {'ok': False, 'reason': 'request_outcome_unverified', 'accepted': True})
        finally:
            if descriptor is not None: os.close(descriptor)

    def serve(self):
        while not self._stopping.is_set():
            try:
                connection, _ = self._socket.accept()
            except socket.timeout:
                continue
            except OSError:
                if self._stopping.is_set():
                    break
                raise
            with connection:
                try:
                    self._connection(connection)
                except (OSError, ValueError, CheckServiceUnavailable):
                    pass

    def quiesce(self):
        self._stopping.set()

    def stop(self, timeout=0):
        self.quiesce()
        if not self.broker.stop(timeout):
            return False
        if self._socket is not None:
            self._socket.close()
            self._socket = None
        if os.path.lexists(self.socket_path) and os.lstat(self.socket_path).st_ino == self._inode:
            os.unlink(self.socket_path)
        return True


def run_service(config, config_pin, loaded_sources, compiled_modules=None):
    from .task_project_actions import ProjectActions
    from .task_check_snapshot import execute_snapshot, runtime_policy
    # Import the complete manifested execution closure before advertising ready.
    from . import improvement_artifacts
    if os.geteuid() == 0:
        raise CheckServiceUnavailable('dedicated_nonroot_service_identity_required')
    guard = build_guard(config)
    runtime = runtime_policy(config['immutable_runtime']) if 'immutable_runtime' in config else None
    holder = {}
    backend = ProjectActions((guard.workspace,), authority=lambda a, t, s:
        holder['broker'].permits(a, t, s) and guard.authorize(a, t, s))
    def unchanged():
        return (source_pin(config_pin['path']) == config_pin
                and source_snapshot(str(Path(__file__).resolve().parent)) == loaded_sources
                and compiled_modules == {name: loaded_sources[name]['sha256'] for name in SERVICE_MODULES})
    def ready():
        return unchanged() and guard.availability().get('available') is True
    # Probe before opening the listening socket; missing prerequisites deny startup.
    if not ready():
        raise CheckServiceUnavailable('execution_boundary_unavailable')
    def immutable_execute(request,bundle,spec):
        if runtime is None: raise CheckServiceUnavailable('immutable_runtime_not_configured')
        return execute_snapshot(request,bundle,spec,runtime=runtime,
                                manifest=guard.snapshot_manifest(spec),runner_pin=loaded_sources['task_check_snapshot.py'])
    broker = ExecutionBroker(config['broker_path'], resolve_spec=backend.canonical_resource_spec,
        execute=guard.wrap_handler(backend.handlers['project.run_check']), readiness=ready,
        execute_snapshot=immutable_execute if runtime is not None else None)
    holder['broker'] = broker
    def identity():
        if not unchanged():
            raise CheckServiceUnavailable('loaded_execution_source_changed')
        return {'version': VERSION, 'pid': os.getpid(), 'configuration_sha256': config_pin['sha256'],
                'loaded_sources': loaded_sources, 'compiled_modules': dict(compiled_modules)}
    service = CheckService(socket_path=config['socket_path'], client_uid=config['client_uid'],
                           broker=broker, identity=identity)
    try:
        signal.signal(signal.SIGTERM, lambda *_: service.quiesce())
        signal.signal(signal.SIGINT, lambda *_: service.quiesce())
        service.open().serve()
    finally:
        service.stop(125)  # no task/speech cancellation kills committed work


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--config-sha256', required=True)
    args = parser.parse_args(argv)
    config, pin, loaded = load_operator_configuration(args.config, args.config_sha256)
    import sys
    loader, compiled = install_source_loader(str(Path(__file__).resolve().parent), loaded)
    try:
        run_service(config, pin, loaded, compiled)
    finally:
        sys.meta_path.remove(loader)


if __name__ == '__main__':
    # Deliberately bypass brain.cognition.__init__, whose many unrelated imports
    # are inappropriate in this small execution service. Only pinned siblings
    # and the isolated interpreter's standard library may load here.
    import sys
    __package__ = '_leon_check_execution'
    main()
