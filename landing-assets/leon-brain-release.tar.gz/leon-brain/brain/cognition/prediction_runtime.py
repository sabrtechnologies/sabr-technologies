"""Prospective capture registry for the existing event consumer, default OFF.

No models, threads, consumers, canonical writers or action owners are created.
Only caller-captured records with an explicit pre-dispatch marker can enter the
observer as prospective evidence. Legacy result-time predictions stay separate.
"""
from dataclasses import dataclass, field
import math
import threading
import time
import uuid
import weakref


@dataclass(frozen=True, eq=False)
class PredictionTicket:
    """Opaque in-process capture capability; never serialize or log it."""
    _prediction_owner: object = field(repr=False)
    _key: str = field(repr=False)
    _generation: int = field(repr=False)


class PredictionRuntime:
    def __init__(self, *, clock_id, configured_mode="off", live_mode=lambda: "off",
                 runtime_accepting=lambda: False, publish=None, budget=None,
                 capacity=256, retention_s=3600.0, horizon_s=300.0,
                 clock=time.monotonic):
        if not isinstance(clock_id, str) or not clock_id or len(clock_id) > 128:
            raise ValueError("explicit bounded process clock_id required")
        if type(capacity) is not int or not 1 <= capacity <= 1024:
            raise ValueError("invalid capture capacity")
        if (not math.isfinite(retention_s) or not math.isfinite(horizon_s)
                or not 1 <= retention_s <= 86400 or not 0 < horizon_s <= retention_s):
            raise ValueError("invalid retention/horizon")
        self.clock_id = clock_id
        self._configured = configured_mode
        self._live_mode, self._runtime_accepting = live_mode, runtime_accepting
        self._publish_event, self._budget = publish, budget
        self._capacity, self._retention, self._horizon = capacity, retention_s, horizon_s
        self._clock = clock
        self._lock = threading.RLock()
        self._lifecycle = threading.Lock()
        self._owner_id = uuid.uuid4().hex
        self._generation = 0
        self._records = {}
        # Exact issued identities survive registry expiry only while a caller
        # still holds its ticket. No unbounded strong-reference tombstones.
        self._issued = weakref.WeakSet()
        self._observer = self._types = None
        self.dispatch = None  # Existing actual tool wrappers; no second worker.
        self._accepting = self._stopping = self._retired = False
        self._counts = {"captured": 0, "dispatched": 0, "projected": 0,
                        "rejected": 0, "duplicate": 0, "expired": 0,
                        "observed": 0, "unregistered": 0, "legacy_owned": 0,
                        "published": 0, "publish_refused": 0, "failures": 0}

    @property
    def ready(self):
        """Cached admission only; safe for a cold caller hook."""
        return self._accepting and not self._stopping

    def _requested(self):
        try:
            return (not self._stopping and callable(self._publish_event)
                    and self._configured in ("shadow", "canary", "on")
                    and self._runtime_accepting()
                    and self._live_mode() in ("shadow", "canary", "on"))
        except Exception:
            return False

    def _disable(self):
        self._accepting = False
        with self._lock:
            self._records.clear()
            self._generation += 1
        self._observer = None

    def tick(self):
        """Existing runtime tick only; bounded sweeps/retries, no new loop."""
        if not self._lifecycle.acquire(blocking=False):
            return
        try:
            if not self._requested():
                self._disable()
                return
            if self._observer is None:
                from . import prediction_error
                self._types = prediction_error
                self._observer = prediction_error.PredictionErrorObserver(mode="shadow",
                    clock_id=self.clock_id, publish=self._publish, budget=self._budget,
                    capacity=self._capacity, retention_s=self._retention,
                    horizon_s=self._horizon, clock=self._clock)
            with self._lock:
                now = self._clock()
                expired = [key for key, item in self._records.items() if now >= item["expires"]]
                for key in expired:
                    del self._records[key]
                self._counts["expired"] += len(expired)
            self._accepting = True
            self._observer.retry_publications()
        except Exception:
            self._accepting = False
            self._counts["failures"] += 1
        finally:
            self._lifecycle.release()

    def capture(self, prediction):
        """Register a forecast BEFORE dispatch, without evaluating a model.

        Required IDs and predicted/deadline timestamps belong to the caller.
        A duplicate prediction_id cannot reserve a second observation slot.
        """
        if not self.ready or not self._lock.acquire(blocking=False):
            return None
        try:
            now = self._clock()
            P = self._types
            if (not self.ready or not isinstance(prediction, P.PredictionRecord)
                    or prediction.clock_id != self.clock_id or not prediction.prospective
                    or not now - self._retention < prediction.predicted_mono <= now
                    or prediction.deadline_mono <= now
                    or prediction.deadline_mono - prediction.predicted_mono > self._horizon
                    or prediction.prediction_id in self._records
                    or len(self._records) >= self._capacity):
                self._counts["rejected"] += 1
                return None
            ticket = PredictionTicket(self, prediction.prediction_id, self._generation)
            self._records[ticket._key] = {"ticket": ticket,
                "prediction": P.PredictionRecord.from_dict(prediction.to_dict()),
                "captured": now, "started": None, "outcome": None,
                "expires": prediction.predicted_mono + self._retention}
            self._issued.add(ticket)
            self._counts["captured"] += 1
            return ticket
        except Exception:
            self._counts["rejected"] += 1
            return None
        finally:
            self._lock.release()

    def capture_world(self, prediction, *, latency_scale_ms, **identity):
        """Project an already computed existing WorldModel forecast, no inference."""
        if not self.ready:
            return None
        try:
            return self.capture(self._types.from_world_prediction(prediction,
                latency_scale_ms=latency_scale_ms, prospective=True, **identity))
        except Exception:
            self._counts["rejected"] += 1
            return None

    def owns_ticket(self, ticket):
        """Cached exact issuance identity, without projecting or consuming it.

        Membership performs no registry iteration or caller code (exact class
        only). Weak identities remain valid across disable and retirement, so
        a draining wrapper cannot reintroduce a second retrospective PE.
        """
        return (type(ticket) is PredictionTicket and
                ticket._prediction_owner is self and ticket in self._issued)

    def _entry(self, ticket):
        if (not isinstance(ticket, PredictionTicket) or ticket._prediction_owner is not self
                or ticket._generation != self._generation):
            return None
        item = self._records.get(ticket._key)
        return item if item is not None and item["ticket"] is ticket else None

    def mark_dispatched(self, ticket, *, action_started_mono):
        """Caller invokes immediately BEFORE execution on the same clock domain."""
        if not self.ready or not self._lock.acquire(blocking=False):
            return False
        try:
            item = self._entry(ticket)
            now = self._clock()
            if (not self.ready or item is None or item["started"] is not None
                    or item["outcome"] is not None or type(action_started_mono) not in (int, float)
                    or not math.isfinite(action_started_mono)
                    or not item["captured"] <= action_started_mono <= now
                    or action_started_mono > item["prediction"].deadline_mono):
                self._counts["rejected"] += 1
                return False
            item["started"] = float(action_started_mono)
            self._counts["dispatched"] += 1
            return True
        finally:
            self._lock.release()

    def project_outcome(self, ticket, *, observed, observed_mono, status="completed",
                        evidence="unverified", evidence_ref=None):
        """Publisher projection, never observer dispatch or canonical mutation.

        Recognized tickets retain PE ownership even after disable/drop/expiry;
        they must not fall back to a duplicate retrospective legacy PE child.
        A missing annotation reports loss honestly instead of inventing a pair.
        """
        if not self.owns_ticket(ticket):
            return None
        owned = {"prediction_owner": "prediction_runtime", "pe_child": False}
        if not self.ready or not self._lock.acquire(blocking=False):
            return owned
        try:
            item = self._entry(ticket)
            if (not self.ready or item is None or self._clock() >= item["expires"]
                    or (status == "completed" and item["started"] is None)):
                self._counts["rejected"] += 1
                return owned
            p = item["prediction"]
            P = self._types
            outcome = P.OutcomeRecord(prediction_id=p.prediction_id, request_id=p.request_id,
                action_id=p.action_id, trace_id=p.trace_id, clock_id=p.clock_id,
                observed_mono=observed_mono, observed=observed, status=status,
                evidence=evidence, evidence_ref=evidence_ref,
                action_started_mono=item["started"])
            if outcome.observed_mono < item["captured"] or outcome.observed_mono > self._clock():
                self._counts["rejected"] += 1
                return owned
            if item["outcome"] is not None:
                if item["outcome"] != outcome:
                    self._counts["rejected"] += 1
                    return owned
                self._counts["duplicate"] += 1
            else:
                item["outcome"] = outcome
                self._counts["projected"] += 1
            return {**owned, "prediction_owner_id": self._owner_id,
                    "prediction_generation": self._generation,
                    "prediction_v1": p.to_dict(), "outcome_v1": outcome.to_dict()}
        except Exception:
            self._counts["rejected"] += 1
            return owned
        finally:
            self._lock.release()

    def observe_event(self, event):
        """Existing sole consumer calls once per event; never drains its bus."""
        if not self._lifecycle.acquire(blocking=False):
            return {"status": "busy"}
        try:
            if not self._requested() or self._observer is None:
                self._disable()
                return {"status": "off"}
            if event.source == "prediction_error.observer":
                return {"status": "self_event_ignored"}
            fields = event.payload
            if fields.get("pe_child") is True:
                self._counts["legacy_owned"] += 1
                return {"status": "legacy_prediction_error_owner"}
            if "prediction_v1" not in fields and "outcome_v1" not in fields:
                return {"status": "unannotated"}
            with self._lock:
                p = self._types.PredictionRecord.from_dict(fields["prediction_v1"])
                outcome = self._types.OutcomeRecord(**dict(fields["outcome_v1"]))
                item = self._records.get(p.prediction_id)
                if (fields.get("prediction_owner_id") != self._owner_id
                        or fields.get("prediction_generation") != self._generation
                        or item is None or item["prediction"] != p or item["outcome"] != outcome
                        or event.trace_id != p.trace_id or self._clock() >= item["expires"]):
                    self._counts["unregistered"] += 1
                    return {"status": "unregistered_capture"}
            result = self._observer.observe_event(event)
            self._counts["observed"] += 1
            # Do not propagate metric payloads, IDs or observer history into stats.
            return {"status": result["status"],
                    "results": [r["status"] for r in result.get("results", [])]}
        except Exception:
            self._counts["unregistered"] += 1
            return {"status": "invalid_event"}
        finally:
            self._lifecycle.release()

    def _publish(self, event):
        if not self._requested():
            return False
        try:
            accepted = self._publish_event(event) is True
        except Exception:
            accepted = False
        self._counts["published" if accepted else "publish_refused"] += 1
        return accepted

    def attach_dispatch(self, owner):
        """Retain the late wrapper owner across shutdown and in-flight tools."""
        if not self._lifecycle.acquire(blocking=False):
            return False
        try:
            if self._stopping or self._retired:
                return False
            if self.dispatch is owner:
                return True
            if self.dispatch is not None:
                return False
            self.dispatch = owner
            # quiesce itself never waits on this lock. Cover the race where
            # it observed no child immediately before this assignment.
            if self._stopping:
                owner.quiesce()
            return True
        finally:
            self._lifecycle.release()

    def quiesce(self):
        self._stopping = True
        self._accepting = False
        if self.dispatch is not None:
            self.dispatch.quiesce()

    def stop(self, *, join_timeout=0):
        """No thread to join. False means an owned tick/consumer call is draining."""
        self.quiesce()
        if not self._lifecycle.acquire(blocking=False):
            return False
        try:
            if self.dispatch is not None and self.dispatch.stop() is not True:
                return False
            self._disable()
            self._retired = True
            return True
        finally:
            self._lifecycle.release()

    @property
    def retired(self):
        return self._retired

    def stats(self):
        return {"mode": "shadow" if self.ready else "off", "retired": self._retired,
                "stopping": self._stopping, "retained": len(self._records),
                "capacity": self._capacity, "metadata_only": True,
                "dispatch": self.dispatch.stats() if self.dispatch is not None else None,
                "calibrated": None, "improvement_established": False,
                **self._counts}
