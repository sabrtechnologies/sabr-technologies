"""Durable supervised planner ingress using the existing task runtime owner.

No database connection, worker, inference call, action execution, or outbox
acknowledgment is created here. Public approval methods are trusted executive
APIs, never model tools. Root must install this resolver before workers start.
"""
from contextlib import contextmanager
from dataclasses import asdict, dataclass
import json
import math
import re

from .task_planner import PlanContext, StepIdentity, PlannerDenied, goal_digest, _digest, _json
from .task_policy import TrustedTaskContext


class IngressDenied(PlannerDenied):
    pass


class IngressConflict(IngressDenied):
    pass


class IngressCapacity(IngressDenied):
    pass


@dataclass(frozen=True)
class PlanScope:
    """Trusted scope-resolver output; never deserialize this from request data."""
    project_scope: str
    allowed_actions: tuple[str, ...]
    allowed_paths: tuple[str, ...]
    allowed_checks: tuple[str, ...]
    max_steps: int = 8
    max_rounds: int = 16
    lifetime_s: int = 900
    authorization_revision: int = 1


@dataclass(frozen=True)
class ParentConstraint:
    """Trusted immutable parent reservation, never request-derived authority."""
    kind: str
    reference: str
    binding_sha256: str


def _constraint(value):
    if (type(value) is not ParentConstraint or value.kind != 'development_improvement'
            or type(value.binding_sha256) is not str or not _HEX.fullmatch(value.binding_sha256)):
        raise IngressDenied('known exact parent constraint required')
    _text(value.reference)
    return value


@dataclass(frozen=True)
class PlanStepApproval:
    """Current durable approval authority, resolved outside checkpoints."""
    principal: str
    parent_id: str
    project_scope: str
    proposal_sha256: str
    approval_ref: str
    issued_wall: float
    expires_wall: float
    revoked: bool = False


_ACTIONS = {'project.read_text', 'project.replace_text', 'project.run_check'}
_HEX = re.compile(r'[0-9a-f]{64}\Z')
_SCHEMA = '''
CREATE TABLE IF NOT EXISTS planner_ingress_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS planner_plans(
 submission TEXT PRIMARY KEY,principal TEXT NOT NULL,fingerprint TEXT NOT NULL,
 registration TEXT NOT NULL,issued_wall REAL NOT NULL,deadline_wall REAL NOT NULL,
 task_id TEXT UNIQUE,context TEXT,revoked_wall REAL,revocation_ref TEXT);
CREATE TABLE IF NOT EXISTS planner_steps(
 parent TEXT NOT NULL,step_key TEXT NOT NULL,proposal_sha256 TEXT NOT NULL,
 approval_ref TEXT NOT NULL,source_sha256 TEXT NOT NULL,spec TEXT NOT NULL,
 submission TEXT UNIQUE NOT NULL,grant_ref TEXT UNIQUE NOT NULL,
 issued_wall REAL NOT NULL,approval_expires_wall REAL NOT NULL,expires_wall REAL NOT NULL,
 child_id TEXT UNIQUE,action_id TEXT UNIQUE,revoked_wall REAL,revocation_ref TEXT,
 PRIMARY KEY(parent,step_key),UNIQUE(parent,proposal_sha256));
'''


def _text(value, limit=200):
    if (type(value) is not str or not value.strip() or len(value.encode('utf-8')) > limit
            or any(ord(c) < 32 for c in value)):
        raise IngressDenied('bounded identifier required')
    return value


def _scope(value, requested):
    if type(value) is not PlanScope or value.project_scope != requested:
        raise IngressDenied('trusted registered scope required')
    _text(requested, 1000)
    for items in (value.allowed_actions, value.allowed_paths, value.allowed_checks):
        if type(items) is not tuple or len(items) > 16 or len(set(items)) != len(items):
            raise IngressDenied('bounded immutable scope required')
        for item in items:
            _text(item, 512)
    if not value.allowed_actions or not set(value.allowed_actions) <= _ACTIONS:
        raise IngressDenied('registered actions required')
    for number, low, high in ((value.max_steps, 1, 8), (value.max_rounds, 1, 16),
                             (value.lifetime_s, 1, 3600), (value.authorization_revision, 1, 1000000)):
        if type(number) is not int or not low <= number <= high:
            raise IngressDenied('bounded scope budget required')
    return value


class PlannerIngress:
    def __init__(self, runtime, *, resolve_scope, resolve_approval, enabled=lambda: False,
                 max_plans=128, max_approvals=1024):
        if not callable(resolve_scope) or not callable(resolve_approval) or not callable(enabled):
            raise TypeError('trusted scope/approval resolvers and selection required')
        if (type(max_plans) is not int or not 1 <= max_plans <= 256 or
                type(max_approvals) is not int or not 1 <= max_approvals <= 2048):
            raise ValueError('finite registry quotas required')
        self.runtime, self._resolve_scope, self._enabled = runtime, resolve_scope, enabled
        self._resolve_approval = resolve_approval
        self._approval_constraint = None
        self._max_plans, self._max_approvals = max_plans, max_approvals
        self._prepared = False
        self._locked_depth, self._runtime_selected = 0, False

    @property
    def store(self):
        return self.runtime._store

    @property
    def db(self):
        return self.runtime._registry

    def prepare(self):
        """Cold, explicit root startup seam, BEFORE existing TaskWorker.start()."""
        with self.runtime._lock:
            if self.runtime._stopping or self.store is None or self.db is None:
                raise IngressDenied('existing task owner required')
            with self.store._lock:
                self.db.executescript(_SCHEMA)
                config = _json([1, self._max_plans, self._max_approvals])
                previous = self.db.execute("SELECT value FROM planner_ingress_meta WHERE key='config'").fetchone()
                if previous is not None and previous[0] != config:
                    raise IngressConflict('retained registry configuration differs')
                self.db.execute("INSERT OR IGNORE INTO planner_ingress_meta VALUES ('config',?)", (config,))
                self._prepared = True
        return self

    def bind_approval_constraint(self, callback):
        """Bind once in root's prepared, pre-worker startup window.

        The runtime start lock serializes this with construction/start/retirement.
        A stopped or partially started worker never reopens this window.
        """
        with self.runtime._lock:
            owner = getattr(self.runtime, '_planner_owner', None)
            if (not callable(callback) or not self._prepared or self.runtime._stopping
                    or self.runtime._started or self.runtime._worker is not None
                    or getattr(self.runtime, '_planner_ingress', None) is not self
                    or owner is None or owner.ingress is not self or owner.planner is None):
                raise IngressDenied('exact prepared pre-worker constraint binding required')
            if self._approval_constraint is not None and self._approval_constraint is not callback:
                raise IngressConflict('parent constraint callback already bound')
            self._approval_constraint = callback
        return self

    def parent_constraint(self, task_id, *, principal):
        """Historical immutable reservation; grants no action authority."""
        with self._locked(principal):
            row, _, _ = self._plan(task_id)
            return self._registered_constraint(row)

    @staticmethod
    def _registered_constraint(row):
        registration = json.loads(row['registration'])
        if _digest(registration) != row['fingerprint']:
            raise IngressDenied('immutable parent registration differs')
        value = registration.get('constraint')
        if value is None:
            return None
        if type(value) is not dict or set(value) != {'kind', 'reference', 'binding_sha256'}:
            raise IngressDenied('retained parent constraint differs')
        return _constraint(ParentConstraint(**value))

    @contextmanager
    def _locked(self, principal):
        # Same order as runtime ingress: runtime -> store -> short DB operations.
        # No SQL transaction is held across TaskPolicy's separate durable grant.
        with self.runtime._access(principal):
            if not self._locked_depth:
                # Worker health takes its control lock. Never acquire that lock
                # while holding store._lock: a worker may hold control in claim.
                self._runtime_selected = self.runtime._enabled() is True
            if not self._prepared or not self.store._lock.acquire(timeout=.25):
                raise IngressDenied('planner registry unavailable or busy')
            self._locked_depth += 1
            try:
                yield
            finally:
                self._locked_depth -= 1
                self.store._lock.release()

    def _now(self):
        now = self.runtime._clock()
        if type(now) not in (int, float) or not math.isfinite(now):
            raise IngressDenied('finite clock required')
        return now

    def _selected(self):
        if self._enabled() is not True or not self._runtime_selected or self.runtime._stopping:
            raise IngressDenied('planner admission disabled')

    def _plan(self, task_id):
        row = self.db.execute('SELECT * FROM planner_plans WHERE task_id=?', (_text(task_id),)).fetchone()
        if row is None or row['principal'] != self.runtime._principal or row['context'] is None:
            raise IngressDenied('registered parent required')
        values = json.loads(row['context'])
        for field in ('allowed_actions', 'allowed_paths', 'allowed_checks'):
            values[field] = tuple(values[field])
        context = PlanContext(**values)
        task = self.store.get_task(task_id)
        if (task is None or context.task_id != task_id or context.principal != row['principal']
                or task['idem_key'] != context.submission_id or task['project_scope'] != context.project_scope
                or task['authorization_ref'] != context.authorization_ref or task['priority'] != 70
                or task['deadline_wall'] != context.deadline_wall):
            raise IngressDenied('parent identity differs from registration')
        return row, context, task

    def _active(self, row, context, task):
        self._selected()
        current = _scope(self._resolve_scope(context.principal, context.project_scope), context.project_scope)
        registered = json.loads(row['registration'])['scope']
        if _json(asdict(current)) != _json(registered):
            raise IngressDenied('trusted scope changed')
        if (row['revoked_wall'] is not None or task['cancel_requested']
                or task['state'] in ('CANCELLED', 'FAILED', 'NEEDS_REVIEW', 'SUCCEEDED')
                or not context.issued_wall <= self._now() < context.deadline_wall):
            raise IngressDenied('parent is revoked, cancelled, expired or terminal')

    def register_plan(self, *, principal, scope, goal, idempotency_key,
                      authorization_ref, approved, constraint=None):
        """Explicit planning permission only; optional trusted reservation is atomic."""
        if approved is not True:
            raise IngressDenied('explicit planning authorization required')
        _text(authorization_ref); _text(idempotency_key)
        if constraint is not None:
            _constraint(constraint)
        with self._locked(principal):
            self._selected()
            allowed = _scope(self._resolve_scope(principal, scope), scope)
            registration = {'scope': asdict(allowed), 'goal_sha256': goal_digest(goal),
                            'authorization_ref': authorization_ref}
            if constraint is not None:
                registration['constraint'] = asdict(constraint)
            fingerprint = _digest(registration)
            submission = 'planner-parent:' + _digest([principal, idempotency_key])
            row = self.db.execute('SELECT * FROM planner_plans WHERE submission=?', (submission,)).fetchone()
            if row is not None and (row['principal'] != principal or row['fingerprint'] != fingerprint):
                raise IngressConflict('parent submission has different registration')
            if row is None:
                if self.db.execute('SELECT count(*) FROM planner_plans').fetchone()[0] >= self._max_plans:
                    raise IngressCapacity('retained parent quota exhausted')
                now = self._now()
                self.db.execute('INSERT INTO planner_plans VALUES (?,?,?,?,?,?,NULL,NULL,NULL,NULL)',
                    (submission, principal, fingerprint, _json(registration), now, now + allowed.lifetime_s))
                row = self.db.execute('SELECT * FROM planner_plans WHERE submission=?', (submission,)).fetchone()
            if row['task_id'] is not None:
                return self._plan(row['task_id'])[1]
            if row['revoked_wall'] is not None or not row['issued_wall'] <= self._now() < row['deadline_wall']:
                raise IngressDenied('partial registration expired or revoked')
            task = self.store.create_task(idempotency_key=submission, project_scope=scope,
                authorization_ref=authorization_ref, priority=70, deadline_wall=row['deadline_wall'])
            context = PlanContext(principal, task['task_id'], submission, authorization_ref,
                allowed.authorization_revision, scope, registration['goal_sha256'], allowed.allowed_actions,
                allowed.allowed_paths, allowed.allowed_checks, allowed.max_steps, allowed.max_rounds,
                row['issued_wall'], row['deadline_wall'])
            self.db.execute('UPDATE planner_plans SET task_id=?,context=? WHERE submission=? AND task_id IS NULL',
                            (task['task_id'], _json(asdict(context)), submission))
            return context

    def resolve_context(self, task_id):
        """Immutable parent identity for TaskPlanner; never reads checkpoint authority."""
        try:
            with self._locked(self.runtime._principal):
                return self._plan(task_id)[1]
        except Exception:
            return None

    def require_active_parent(self, task_id, *, principal):
        """Root gate for new planning/completion; returns before any model work."""
        with self._locked(principal):
            row, context, task = self._plan(task_id)
            self._active(row, context, task)
            return context

    def _source(self, context, task):
        data = task['checkpoint']
        if (data.get('schema') != 1 or data.get('kind') != 'supervised_coding_plan'
                or data.get('context_sha256') != _digest(asdict(context))
                or goal_digest(data.get('goal')) != context.goal_sha256
                or type(data.get('round')) is not int or not 1 <= data['round'] <= context.max_rounds
                or type(data.get('step')) is not int or not 0 <= data['step'] < context.max_steps
                or type(data.get('history')) is not list or len(data['history']) != data['step']):
            raise IngressDenied('planner source differs from registration')
        _text(data.get('request_id'))
        for index, ref in enumerate(data['history'], 1):
            identity = self._lookup(context, 'planner-step:' + str(index))
            if identity is None or any(ref.get(k) != v for k, v in asdict(identity).items()):
                raise IngressDenied('history differs from immutable child registry')
            action = self.store.get_action(identity.action_id)
            if (action['state'] != 'SUCCEEDED' or ref.get('outcome') != 'SUCCEEDED'
                    or ref.get('result_seq') != action['result_seq']
                    or ref.get('result_sha256') != _digest(action['result'])):
                raise IngressDenied('history differs from retained successful receipt')
        proposal = data.get('proposal')
        if type(proposal) is not dict or proposal.get('decision') != 'action':
            raise IngressDenied('exact action proposal required')
        digest = _digest([asdict(context), data['round'], data['step'], data['request_id'], data['history'], proposal])
        if data.get('proposal_sha256') != digest:
            raise IngressDenied('proposal source digest differs')
        return data, digest, _digest([data['round'], data['step'], data['request_id'], data['history']])

    def _canonical(self, context, task, proposal):
        name, arguments = proposal.get('name'), proposal.get('arguments')
        if name not in context.allowed_actions or type(arguments) is not dict:
            raise IngressDenied('action outside registered scope')
        if ((name == 'project.run_check' and arguments.get('check') not in context.allowed_checks)
                or (name != 'project.run_check' and arguments.get('path') not in context.allowed_paths)):
            raise IngressDenied('path or check outside registered scope')
        spec = self.runtime._backend.canonical_resource_spec(name, arguments, task)
        metadata = {key: value for key, value in asdict(spec).items() if key not in ('name', 'arguments')}
        if _json(metadata) != _json(proposal.get('spec')):
            raise IngressDenied('canonical configuration differs from reviewed proposal')
        return spec

    def _preview_containment(self, spec):
        # The execution service serializes protocol connections. Its current
        # caller may need both parent locks for final effect authority before it
        # can answer our preview. Never retain either lock over this RPC.
        if spec.name == 'project.run_check' and self.runtime._containment_verified(spec) is not True:
            raise IngressDenied('check containment unverified')

    def _approval(self, context, digest, reference, expiry, *, issued=None):
        retained = self.db.execute('SELECT revoked_wall FROM planner_steps WHERE parent=? AND approval_ref=?',
                                   (context.task_id, reference)).fetchone()
        if retained is not None and retained['revoked_wall'] is not None:
            raise IngressDenied('step approval irrevocably revoked')
        approval = self._resolve_approval(reference)
        if (type(approval) is PlanStepApproval and approval.revoked is True
                and approval.principal == context.principal and approval.parent_id == context.task_id
                and approval.project_scope == context.project_scope and approval.proposal_sha256 == digest
                and approval.approval_ref == reference):
            self.db.execute('UPDATE planner_steps SET revoked_wall=?,revocation_ref=? '
                'WHERE parent=? AND approval_ref=? AND revoked_wall IS NULL',
                (self._now(), 'resolver:'+reference, context.task_id, reference))
        if (type(approval) is not PlanStepApproval or approval.principal != context.principal
                or approval.parent_id != context.task_id or approval.project_scope != context.project_scope
                or approval.proposal_sha256 != digest or approval.approval_ref != reference
                or approval.revoked is not False or approval.expires_wall != expiry
                or (issued is not None and approval.issued_wall != issued)):
            raise IngressDenied('trusted exact approval unavailable or changed')
        for value in (approval.issued_wall, approval.expires_wall, expiry):
            if type(value) not in (int, float) or not math.isfinite(value):
                raise IngressDenied('finite approval lifetime required')
        if (not 0 < expiry - approval.issued_wall <= 3600
                or not approval.issued_wall <= self._now() < expiry):
            raise IngressDenied('approval expired or outside finite lifetime')
        row, registered, _ = self._plan(context.task_id)
        if registered != context:
            raise IngressDenied('reserved parent context differs')
        constraint = self._registered_constraint(row)
        if constraint is not None:
            # This seam is pure local registry work under existing locks. It is
            # rechecked before/after preview, submission and active effect use.
            # A missing integration after restart must never erase reservation.
            try:
                permitted = (self._approval_constraint is not None and
                    self._approval_constraint(context, constraint, approval) is True)
            except Exception:
                permitted = False
            if not permitted:
                raise IngressDenied('reserved parent approval constraint denied')
        return approval

    def record_approval(self, task_id, *, principal, proposal_sha256, approval_ref, approved, expires_wall):
        """Persist a trusted exact approval BEFORE TaskPlanner.approve_step()."""
        if approved is not True or type(proposal_sha256) is not str or not _HEX.fullmatch(proposal_sha256):
            raise IngressDenied('explicit exact proposal approval required')
        _text(approval_ref)
        previewed = None
        for _ in range(2):
            with self._locked(principal):
                row, context, task = self._plan(task_id)
                old = self.db.execute('SELECT * FROM planner_steps WHERE parent=? AND proposal_sha256=?',
                                      (task_id, proposal_sha256)).fetchone()
                if old is not None:
                    if old['approval_ref'] != approval_ref or old['approval_expires_wall'] != expires_wall:
                        raise IngressConflict('approval identity or expiry changed')
                    self._approval(context, proposal_sha256, approval_ref, expires_wall, issued=old['issued_wall'])
                    return {'step_key': old['step_key'], 'proposal_sha256': proposal_sha256}
                self._active(row, context, task)
                approval = self._approval(context, proposal_sha256, approval_ref, expires_wall)
                data, digest, source = self._source(context, task)
                if data['phase'] != 'AWAIT_APPROVAL' or digest != proposal_sha256:
                    raise IngressDenied('reviewed proposal is no longer awaiting approval')
                spec = self._canonical(context, task, data['proposal'])
                key = 'planner-step:' + str(data['step'] + 1)
                if self.db.execute('SELECT 1 FROM planner_steps WHERE parent=? AND step_key=?', (task_id, key)).fetchone():
                    raise IngressConflict('step already has immutable approval')
                if self.db.execute('SELECT count(*) FROM planner_steps').fetchone()[0] >= self._max_approvals:
                    raise IngressCapacity('retained approval quota exhausted')
                current = (context, task['revision'], approval, digest, source, spec, key)
                if previewed is not None:
                    if current != previewed:
                        raise IngressConflict('reviewed approval changed during containment preview')
                    submission = 'planner-child:' + _digest([task_id, key])
                    self.db.execute('INSERT INTO planner_steps VALUES (?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,NULL,NULL)',
                        (task_id, key, digest, approval_ref, source, _json(asdict(spec)), submission,
                         'planner-grant:' + _digest([submission]), approval.issued_wall, expires_wall,
                         min(context.deadline_wall, expires_wall)))
                    return {'step_key': key, 'proposal_sha256': digest}
                previewed = current
            self._preview_containment(spec)

    def _child(self, context, row):
        child = self.store.get_task(row['child_id']) if row['child_id'] is not None else None
        if child is not None and (child['idem_key'] != row['submission'] or child['project_scope'] != context.project_scope
                or child['authorization_ref'] != row['grant_ref'] or child['priority'] != 70
                or child['deadline_wall'] != row['expires_wall']):
            raise IngressDenied('registered child identity differs')
        return child

    def _lookup(self, context, step_key):
        row = self.db.execute('SELECT * FROM planner_steps WHERE parent=? AND step_key=?',
                              (context.task_id, _text(step_key))).fetchone()
        if row is None:
            return None
        child = self._child(context, row)
        action = self.store.action_for_step(child['task_id'], 'effect:1') if child is not None else None
        if action is None:
            return None
        spec = json.loads(row['spec'])
        if (action['name'] != spec['name'] or action['arguments'] != dict(spec['arguments'])
                or action['resources'] != spec['resources'] or action['tier'] != spec['minimum_tier']
                or row['action_id'] not in (None, action['action_id'])):
            raise IngressDenied('retained action differs from immutable approval')
        return StepIdentity(child['task_id'], action['action_id'], row['proposal_sha256'])

    def lookup_step(self, *, context, step_key):
        with self._locked(context.principal):
            if self._plan(context.task_id)[1] != context:
                raise IngressDenied('immutable parent context differs')
            return self._lookup(context, step_key)

    def lookup_approved_step(self, task_id, *, principal, proposal_sha256,
                             approval_ref, expires_wall):
        """Recover a replied/lost approved child after parent progress; no writes."""
        if (type(proposal_sha256) is not str or not _HEX.fullmatch(proposal_sha256)
                or type(expires_wall) not in (int, float) or not math.isfinite(expires_wall)):
            raise IngressDenied('exact historical approval identity required')
        _text(approval_ref)
        with self._locked(principal):
            _, context, _ = self._plan(task_id)
            row = self.db.execute('SELECT * FROM planner_steps WHERE parent=? AND proposal_sha256=?',
                                  (task_id, proposal_sha256)).fetchone()
            if row is None:
                return None
            if row['approval_ref'] != approval_ref or row['approval_expires_wall'] != expires_wall:
                raise IngressConflict('historical approval reference or expiry differs')
            return self._lookup(context, row['step_key'])

    def resolve_child(self, task_id, *, active=True):
        """Root TaskPolicy resolver seam; active=False is authorized metadata only."""
        try:
            with self._locked(self.runtime._principal):
                step = self.db.execute('SELECT * FROM planner_steps WHERE child_id=?', (_text(task_id),)).fetchone()
                if step is None:
                    return None
                row, context, parent = self._plan(step['parent'])
                if active:
                    self._active(row, context, parent)
                    self._approval(context, step['proposal_sha256'], step['approval_ref'],
                                   step['approval_expires_wall'], issued=step['issued_wall'])
                    if self._now() >= step['expires_wall']:
                        return None
                child = self._child(context, step)
                if child is None:
                    return None
                return TrustedTaskContext(context.principal, child['task_id'], step['submission'],
                                          context.authorization_revision, context.project_scope)
        except Exception:
            return None

    def submit_step(self, *, context, step_key, spec, proposal_sha256, approval_ref, parent_revision):
        previewed = None
        for _ in range(2):
            with self._locked(context.principal):
                row, registered, parent = self._plan(context.task_id)
                if registered != context:
                    raise IngressDenied('immutable parent context differs')
                step = self.db.execute('SELECT * FROM planner_steps WHERE parent=? AND step_key=?',
                                      (context.task_id, _text(step_key))).fetchone()
                if (step is None or step['proposal_sha256'] != proposal_sha256 or step['approval_ref'] != approval_ref
                        or step['spec'] != _json(asdict(spec))):
                    raise IngressDenied('durable exact approval required')
                prior = self._lookup(context, step_key)
                if prior is not None:
                    return prior  # Retained identity only; never grant/enqueue again.
                self._active(row, context, parent)
                approval = self._approval(context, proposal_sha256, approval_ref,
                    step['approval_expires_wall'], issued=step['issued_wall'])
                data, digest, source = self._source(context, parent)
                if (type(parent_revision) is not int or parent['revision'] != parent_revision
                        or data['phase'] != 'DISPATCH_INTENT' or data.get('approval_ref') != approval_ref
                        or step_key != 'planner-step:' + str(data['step'] + 1)
                        or digest != proposal_sha256 or source != step['source_sha256']
                        or self._now() >= step['expires_wall']):
                    raise IngressDenied('parent dispatch intent or approved source changed')
                canonical = self._canonical(context, parent, data['proposal'])
                if _json(asdict(canonical)) != step['spec']:
                    raise IngressDenied('approved canonical action changed')
                current = (context, parent['revision'], _json(dict(step)), approval, canonical, source)
                if previewed is not None:
                    if current != previewed:
                        raise IngressConflict('approved submission changed during containment preview')
                    child = self.store.create_task(idempotency_key=step['submission'], project_scope=context.project_scope,
                        authorization_ref=step['grant_ref'], priority=70, deadline_wall=step['expires_wall'],
                        checkpoint={'schema': 1, 'kind': 'approved_planner_step', 'parent': context.task_id,
                                    'step_key': step_key, 'result_seq': 0})
                    if step['child_id'] not in (None, child['task_id']):
                        raise IngressConflict('child identity differs')
                    self.db.execute('UPDATE planner_steps SET child_id=? WHERE parent=? AND step_key=?',
                                    (child['task_id'], context.task_id, step_key))
                    self.runtime._policy.create_grant(grant_ref=step['grant_ref'],
                        context=self.resolve_child(child['task_id']), action_key='effect:1', spec=canonical,
                        tier=canonical.minimum_tier, approval_ref=approval_ref, expires_wall=step['expires_wall'])
                    action = self.store.enqueue_action(child['task_id'], idempotency_key='effect:1', name=canonical.name,
                        arguments=dict(canonical.arguments), resources=list(canonical.resources),
                        tier=canonical.minimum_tier, expected_revision=child['revision'])
                    self.db.execute('UPDATE planner_steps SET action_id=? WHERE parent=? AND step_key=?',
                                    (action['action_id'], context.task_id, step_key))
                    identity = StepIdentity(child['task_id'], action['action_id'], proposal_sha256)
                    break
                previewed = current
            self._preview_containment(canonical)
        self.runtime._worker.notify()
        return identity

    def _cancel_children(self, context, step_key=None):
        rows = self.db.execute('SELECT * FROM planner_steps WHERE parent=?', (context.task_id,)).fetchall()
        for row in rows:
            if step_key is not None and row['step_key'] != step_key:
                continue
            child = self._child(context, row)
            if child is None:
                continue
            action = self.store.action_for_step(child['task_id'], 'effect:1')
            if action is None or not action['dispatched']:
                self.store.cancel_task(child['task_id'])

    def cancel_future(self, *, context, step_key):
        with self._locked(context.principal):
            _, registered, parent = self._plan(context.task_id)
            if registered != context or not parent['cancel_requested']:
                raise IngressDenied('persist parent cancellation first')
            self._cancel_children(context, _text(step_key))
        self.runtime._worker.notify()

    def cancel_plan(self, task_id, *, principal):
        """Root calls this BEFORE planner.cancel() cancels its inference handle."""
        with self._locked(principal):
            _, context, _ = self._plan(task_id)
            task = self.store.cancel_task(task_id)
            self._cancel_children(context)
            result = {'task_id': task_id, 'state': task['state'], 'cancel_requested': task['cancel_requested']}
        self.runtime._worker.notify()
        return result

    def revoke_plan(self, task_id, *, principal, revocation_ref):
        with self._locked(principal):
            self._plan(task_id)
            self.db.execute('UPDATE planner_plans SET revoked_wall=?,revocation_ref=? '
                'WHERE task_id=? AND revoked_wall IS NULL', (self._now(), _text(revocation_ref), task_id))
        return self.cancel_plan(task_id, principal=principal)

    def revoke_step(self, task_id, *, principal, step_key, revocation_ref):
        """Durably deny this step; never release UNKNOWN/committed resources."""
        with self._locked(principal):
            _, context, _ = self._plan(task_id)
            step_key, reason = _text(step_key), _text(revocation_ref)
            row = self.db.execute('SELECT 1 FROM planner_steps WHERE parent=? AND step_key=?', (task_id, step_key)).fetchone()
            if row is None:
                raise IngressDenied('registered step required')
            self.db.execute('UPDATE planner_steps SET revoked_wall=?,revocation_ref=? '
                'WHERE parent=? AND step_key=? AND revoked_wall IS NULL', (self._now(), reason, task_id, step_key))
            self._cancel_children(context, step_key)
        self.runtime._worker.notify()

    def receipts(self, task_id, *, principal, after_seq=0, limit=100):
        """Authorized retained child receipts, even after cancel; never ack outbox."""
        with self._locked(principal):
            context = self.resolve_child(task_id, active=False)
            if context is None or context.principal != principal:
                raise IngressDenied('registered child required')
            return self.store.receipts_after(task_id, after_seq=after_seq, limit=limit)

    def checkpoint_result(self, result):
        """Root tick may ack its outbox only after this returns literal True."""
        with self._locked(self.runtime._principal):
            if type(result) is not dict:
                return False
            child_id = result.get('task_id')
            context = self.resolve_child(child_id, active=False)
            if context is None:
                return False
            step = self.db.execute('SELECT * FROM planner_steps WHERE child_id=?', (child_id,)).fetchone()
            parent = self._plan(step['parent'])[1]
            identity = self._lookup(parent, step['step_key'])
            if identity is None or identity.action_id != result.get('action_id'):
                return False
            action, child = self.store.get_action(identity.action_id), self.store.get_task(child_id)
            if (action['result_seq'] != result.get('seq') or action['state'] != result.get('outcome')
                    or action['result'] != result.get('payload')):
                return False
            if action['state'] == 'SUCCEEDED' and child['state'] == 'READY':
                data = child['checkpoint']
                if (data.get('kind') != 'approved_planner_step' or data.get('parent') != step['parent']
                        or data.get('step_key') != step['step_key']):
                    return False
                data = {**data, 'result_seq': action['result_seq'], 'action_id': identity.action_id}
                child = self.store.checkpoint(child_id, data, expected_revision=child['revision'], state='SUCCEEDED')
            if child['state'] == 'SUCCEEDED':
                return (child['checkpoint'].get('result_seq') == action['result_seq']
                        and child['checkpoint'].get('action_id') == identity.action_id)
            return child['state'] in ('FAILED', 'CANCELLED', 'NEEDS_REVIEW')
