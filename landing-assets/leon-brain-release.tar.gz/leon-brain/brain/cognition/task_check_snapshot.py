"""Immutable check-input construction, not a general command runner.

Only the authenticated broker may invoke execute_snapshot after its durable
STARTED claim. Material integrity is not origin/approval authority; the parent
registry and final grant callback retain those responsibilities. No writable
workspace or host runtime-directory mount is used in this mode.
"""
from __future__ import annotations

import base64
from dataclasses import asdict, dataclass, fields
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import time

MAX_BUNDLE = 6 * 1024 * 1024
MAX_RUNTIME_FILES = 256
MAX_RUNTIME_BYTES = 64 * 1024 * 1024
MAX_RUNTIME_FILE = 32 * 1024 * 1024
MAX_PROOF = 8192
MAX_OUTPUT = 768  # worst-case JSON escaping still fits the broker's 8 KiB result
MODE = 'immutable_readonly_snapshot'
SEALS = fcntl.F_SEAL_WRITE | fcntl.F_SEAL_GROW | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_SEAL


class SnapshotDenied(ValueError):
    pass


@dataclass(frozen=True)
class VerifiedInputProof:
    """Produced only after authenticated retained receipt validation.

    Consumers must still match the exact immutable registration, planner step,
    TaskStore result sequence and result digest. This value grants no authority.
    """
    reference: str
    snapshot_ref: str
    mode: str
    action_id: str
    planner_proposal_sha256: str
    configuration_sha256: str
    artifact_sha256: str
    input_tree_sha256: str
    completion_tree_sha256: str
    mutation_excluded: bool
    held_until_drain: bool
    namespace_drained: bool
    process_drained: bool
    request_sha256: str
    runtime_sha256: str


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def _hash(value):
    if type(value) is not str or not re.fullmatch('[0-9a-f]{64}', value):
        raise SnapshotDenied('exact_snapshot_digest_required')
    return value


def _ref(value):
    if type(value) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}', value):
        raise SnapshotDenied('bounded_snapshot_reference_required')
    return value


def sealed_fd(data, *, label='leon-check-input'):
    if type(data) is not bytes or not 0 <= len(data) <= MAX_RUNTIME_BYTES:
        raise SnapshotDenied('bounded_snapshot_bytes_required')
    fd = os.memfd_create(label, os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING)
    try:
        if fd<3: raise SnapshotDenied('service_standard_descriptors_required')
        view = memoryview(data)
        while view:
            count = os.write(fd, view)
            if count <= 0: raise SnapshotDenied('snapshot_write_failed')
            view = view[count:]
        fcntl.fcntl(fd, fcntl.F_ADD_SEALS, SEALS)
        if fcntl.fcntl(fd, fcntl.F_GET_SEALS) & SEALS != SEALS:
            raise SnapshotDenied('snapshot_seals_missing')
        os.lseek(fd, 0, os.SEEK_SET)
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_sealed_fd(fd, *, maximum=MAX_BUNDLE):
    """Read an already received CLOEXEC regular sealed inode without shared offset."""
    info = os.fstat(fd)
    if (not stat.S_ISREG(info.st_mode) or not 0 < info.st_size <= maximum
            or fcntl.fcntl(fd, fcntl.F_GETFD) & fcntl.FD_CLOEXEC == 0
            or fcntl.fcntl(fd, fcntl.F_GET_SEALS) & SEALS != SEALS):
        raise SnapshotDenied('bounded_sealed_cloexec_inode_required')
    data = bytearray()
    while len(data) < info.st_size:
        chunk = os.pread(fd, min(65536, info.st_size-len(data)), len(data))
        if not chunk: raise SnapshotDenied('snapshot_truncated')
        data.extend(chunk)
    after = os.fstat(fd)
    if (after.st_dev, after.st_ino, after.st_size) != (info.st_dev, info.st_ino, info.st_size):
        raise SnapshotDenied('snapshot_inode_changed')
    return bytes(data)


def _development(value):
    from .improvement_artifacts import DevelopmentBinding, InputFile
    if type(value) is not dict or set(value) != {f.name for f in fields(DevelopmentBinding)}:
        raise SnapshotDenied('exact_development_binding_required')
    data = dict(value)
    for name in ('root_identity', 'editable_paths', 'protected_paths', 'required_checks'):
        if type(data[name]) is not list: raise SnapshotDenied('canonical_binding_lists_required')
        data[name] = tuple(data[name])
    if type(data['input_files']) is not list: raise SnapshotDenied('complete_input_files_required')
    data['input_files'] = tuple(InputFile(**item) for item in data['input_files'])
    return DevelopmentBinding(**data)


def prepare_material(material, action, task, spec):
    """Freeze trusted registry material; this function does not grant authority."""
    try:
        registration = asdict(material.registration)
        binding = asdict(material.development_binding)
        bundle = material.bundle
        role = material.role
        tree = registration['source_tree_sha256' if role == 'baseline' else 'candidate_tree_sha256']
        value = {'version': 1, 'mode': MODE, 'action_id': action['action_id'],
                 'task_id': task['task_id'], 'proposal_task_id': registration['proposal_task_id'],
                 'parent_task_id': registration['parent_task_id'], 'step_key': material.step_key,
                 'planner_proposal_sha256': material.planner_proposal_sha256,
                 'configuration_sha256': registration['configuration_sha256'],
                 'artifact_sha256': registration['artifact_sha256'],
                 'input_tree_sha256': tree, 'role': role, 'development_binding': binding,
                 'spec_sha256': sha(canonical(asdict(spec)))}
        value = json.loads(canonical(value))
        validate_material(value, bundle, action, task, spec)
        return value, bundle
    except (AttributeError, KeyError, TypeError, ValueError) as exc:
        raise SnapshotDenied('trusted_check_material_invalid') from exc


def validate_material(value, bundle, action, task, spec):
    """Recompute the exact bundle/tree against the fixed locally resolved spec."""
    from .improvement_artifacts import validate_bundle
    keys = {'version','mode','action_id','task_id','proposal_task_id','parent_task_id','step_key',
            'planner_proposal_sha256','configuration_sha256','artifact_sha256','input_tree_sha256',
            'role','development_binding','spec_sha256'}
    if (type(value) is not dict or set(value) != keys or type(value['version']) is not int or value['version'] != 1
            or value['mode'] != MODE or value['role'] not in ('baseline','candidate')
            or type(bundle) is not bytes or not 0 < len(bundle) <= MAX_BUNDLE
            or sha(bundle) != value['artifact_sha256'] or len(canonical(value)) > 24576):
        raise SnapshotDenied('exact_immutable_material_required')
    for key in ('action_id','task_id','proposal_task_id','parent_task_id','step_key'): _ref(value[key])
    for key in ('planner_proposal_sha256','configuration_sha256','artifact_sha256','input_tree_sha256','spec_sha256'): _hash(value[key])
    binding = _development(value['development_binding'])
    if (value['action_id'] != action['action_id'] or value['task_id'] != task['task_id']
            or action['task_id'] != task['task_id'] or spec.name != 'project.run_check'
            or value['spec_sha256'] != sha(canonical(asdict(spec)))
            or value['configuration_sha256'] != spec.configuration_sha256
            or binding.configuration_sha256 != spec.configuration_sha256
            or binding.workspace_scope != spec.scope or task['project_scope'] != spec.scope
            or binding.root_identity != tuple(spec.root_identity)
            or binding.proposal_task_id != value['proposal_task_id']
            or binding.parent_task_id != value['parent_task_id']
            or dict(spec.arguments)['check'] not in binding.required_checks):
        raise SnapshotDenied('immutable_attempt_scope_mismatch')
    artifact = validate_bundle(binding, bundle)
    metadata = artifact.metadata()
    role = value['role']
    if (metadata['artifact_sha256'] != value['artifact_sha256']
            or metadata[('source' if role == 'baseline' else 'candidate')+'_tree_sha256'] != value['input_tree_sha256']):
        raise SnapshotDenied('immutable_artifact_tree_mismatch')
    decoded = json.loads(bundle)
    contents = {p: base64.b64decode(data, validate=True) for p,data in decoded['source_files'].items()}
    if role == 'candidate':
        for patch in decoded['patch']:
            contents[patch['path']] = base64.b64decode(patch['after_base64'], validate=True)
    inventory = decoded[('source' if role == 'baseline' else 'candidate')+'_inventory']
    return contents, inventory


def runtime_policy(value):
    """Operator-only dependency closure. No inferred imports or directory binds."""
    if type(value) is not dict or set(value) != {'version','python','files'} or type(value['version']) is not int or value['version'] != 1:
        raise SnapshotDenied('explicit_runtime_closure_required')
    rows = value['files']
    if type(rows) is not list or not 1 <= len(rows) <= MAX_RUNTIME_FILES:
        raise SnapshotDenied('bounded_runtime_closure_required')
    paths = set()
    for row in rows:
        if type(row) is not dict or set(row) != {'source','path','sha256','mode'}:
            raise SnapshotDenied('exact_runtime_file_required')
        path, source = row['path'], row['source']
        if (type(path) is not str or len(path) > 256 or not path.startswith(('/usr/','/lib/','/lib64/','/bin/'))
                or any(p in ('','.','..') for p in path.split('/')[1:]) or '\\' in path or ':' in path
                or any(ord(char)<33 or ord(char)>126 for char in path)
                or path in paths or type(source) is not str or not source.startswith('/')
                or os.path.normpath(source) != source or os.path.realpath(source) != source
                or type(row['mode']) is not int or row['mode'] not in (0o444,0o555,0o644,0o755)):
            raise SnapshotDenied('unaliased_fixed_runtime_file_required')
        _hash(row['sha256']); paths.add(path)
    if (value['python'] not in paths or not next(row['mode']&0o111 for row in rows if row['path']==value['python'])
            or any(a != b and b.startswith(a+'/') for a in paths for b in paths)):
        raise SnapshotDenied('runtime_interpreter_or_path_conflict')
    return json.loads(canonical(value))


def _read_runtime(policy):
    from .task_check_service import source_pin
    result, total = {}, 0
    for row in policy['files']:
        pin = source_pin(row['source'])
        if pin['sha256'] != row['sha256']: raise SnapshotDenied('runtime_source_changed')
        fd = os.open(row['source'], os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            info = os.fstat(fd)
            if (info.st_dev,info.st_ino) != (pin['dev'],pin['ino']) or info.st_nlink != 1 or info.st_size > MAX_RUNTIME_FILE:
                raise SnapshotDenied('runtime_source_alias_or_bound')
            data = bytearray()
            while len(data) <= MAX_RUNTIME_FILE:
                part = os.read(fd, min(65536, MAX_RUNTIME_FILE+1-len(data)))
                if not part: break
                data.extend(part)
            total += len(data)
            if total > MAX_RUNTIME_BYTES or sha(data) != row['sha256'] or source_pin(row['source']) != pin:
                raise SnapshotDenied('runtime_closure_changed_or_exhausted')
            result[row['path']] = bytes(data)
        finally: os.close(fd)
    return result


def _json_file(data):
    # One bounded object only; duplicate JSON keys are excluded by canonical bytes.
    value = json.loads(data)
    if canonical(value) != data: raise SnapshotDenied('canonical_snapshot_json_required')
    return value


def validate_proof(value, binding, *, runtime_sha256, request_sha256):
    for item in (runtime_sha256,request_sha256,binding['spec_sha256'],binding['planner_proposal_sha256'],binding['configuration_sha256'],
                 binding['artifact_sha256'],binding['input_tree_sha256']): _hash(item)
    expected = {'version':1, 'mode':MODE, 'action_id':binding['action_id'],
        'planner_proposal_sha256':binding['planner_proposal_sha256'],
        'configuration_sha256':binding['configuration_sha256'], 'artifact_sha256':binding['artifact_sha256'],
        'input_tree_sha256':binding['input_tree_sha256'], 'completion_tree_sha256':binding['input_tree_sha256'],
        'runtime_sha256':runtime_sha256, 'request_sha256':request_sha256,'spec_sha256':binding['spec_sha256'],
        'mutation_excluded':True, 'held_until_drain':True, 'namespace_drained':True, 'process_drained':True}
    if type(value) is not dict or type(value.get('version')) is not int or value != expected or any(type(value.get(k)) is not bool for k in
            ('mutation_excluded','held_until_drain','namespace_drained','process_drained')):
        raise SnapshotDenied('same_attempt_supervisor_proof_required')
    return dict(value)


def _measure_tree(root, expected):
    """Complete exact private tree, including mode and unexpected entries."""
    rows = []
    def walk(path, relative):
        info = os.lstat(path)
        if stat.S_ISDIR(info.st_mode):
            rows.append({'path':relative,'kind':'directory','mode':stat.S_IMODE(info.st_mode)})
            names = os.listdir(path)
            if len(names) > 192 or len(rows)+len(names) > 193: raise SnapshotDenied('snapshot_tree_bound')
            for name in sorted(names): walk(path+'/'+name, relative+'/'+name if relative else name)
        elif stat.S_ISREG(info.st_mode):
            if info.st_size > 65536: raise SnapshotDenied('snapshot_file_bound')
            fd = os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
            try: data = os.read(fd,65537)
            finally: os.close(fd)
            rows.append({'path':relative,'kind':'file','mode':stat.S_IMODE(info.st_mode),'size':len(data),'sha256':sha(data)})
        else: raise SnapshotDenied('snapshot_special_entry')
    walk(root,'')
    rows.sort(key=lambda row:row['path'])
    if rows != expected: raise SnapshotDenied('snapshot_inventory_differs')
    return sha(canonical(rows))


def _readonly_mounts(paths):
    mounts = {}
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        parts=line.split()
        path=re.sub(r'\\(040|011|012|134)',lambda match:chr(int(match[1],8)),parts[4])
        mounts[path]=parts[5].split(',')
    # Every individual runtime/workspace file is its own readonly bind mount;
    # the readonly root covers directories and excludes additions/renames.
    if 'ro' not in mounts.get('/',[]): raise SnapshotDenied('snapshot_root_writable')
    for path in paths:
        if 'ro' not in mounts.get(path,[]): raise SnapshotDenied('snapshot_file_writable')


def build_command(manifest, binding, inventory, contents, runtime, runtime_contents, *, request_sha256, runner_bytes):
    """Return a fixed command plus owned source descriptors; no host data mounts."""
    owned=[]
    try:
        argv=[manifest['bwrap']['path'],'--unshare-user','--disable-userns','--unshare-pid',
              '--unshare-net','--unshare-ipc','--unshare-uts','--die-with-parent','--as-pid-1',
              '--new-session','--cap-drop','ALL']
        workspace_dirs=[row for row in inventory if row['kind']=='directory']
        for row in sorted(workspace_dirs,key=lambda row:(row['path'].count('/'),row['path'])):
            argv.extend(('--perms',format(row['mode'],'o'),'--dir','/workspace'+('/'+row['path'] if row['path'] else '')))
        mounts=[]
        def mount(data,mode,destination):
            fd=sealed_fd(data)
            owned.append(fd)
            argv.extend(('--perms',format(mode,'o'),'--ro-bind-data',str(fd),destination))
            mounts.append(destination)
        for row in inventory:
            if row['kind']=='file': mount(contents[row['path']],row['mode'],'/workspace/'+row['path'])
        for row in runtime['files']: mount(runtime_contents[row['path']],row['mode'],row['path'])
        # The supervisor itself is included in the pinned service closure and copied
        # into private backing; neither its host path nor its parent is mounted.
        if type(runner_bytes) is not bytes or not 0<len(runner_bytes)<=256*1024:
            raise SnapshotDenied('bounded_pinned_supervisor_required')
        mount(runner_bytes,0o444,'/__leon/snapshot.py')
        inside={'binding':binding,'inventory':inventory,'runtime':runtime,'mount_paths':mounts+['/__leon/manifest.json'],
                'request_sha256':request_sha256,'command':manifest['command'],'cwd':manifest['cwd'],
                'timeout_s':manifest['timeout_s']}
        encoded=canonical(inside)
        if len(encoded)>131072: raise SnapshotDenied('snapshot_manifest_bound')
        mount(encoded,0o444,'/__leon/manifest.json')
        argv.extend(('--proc','/proc','--remount-ro','/proc','--dev','/dev',
            '--size',str(16*1024*1024),'--tmpfs','/tmp','--dir','/tmp/home',
            '--remount-ro','/','--clearenv','--setenv','PATH','/usr/bin:/bin',
            '--setenv','LANG','C.UTF-8','--setenv','HOME','/tmp/home','--setenv','TMPDIR','/tmp',
            '--setenv','PYTHONDONTWRITEBYTECODE','1','--chdir','/workspace','--',
            runtime['python'],'-I','-S','/__leon/snapshot.py','--inside','/__leon/manifest.json','0'))
        return tuple(argv),tuple(owned)
    except BaseException:
        for fd in owned: os.close(fd)
        raise


def _run_bounded(argv, descriptors, proof_reader, proof_writer, timeout):
    """One process/namespace attempt; output is discarded beyond a fixed prefix."""
    import selectors
    proc=None
    output=bytearray(); proof=bytearray()
    selector=selectors.DefaultSelector()
    try:
        # Normalize only the trusted supervisor's result channel onto fd0.
        # Standard fd0 survives bwrap without a broad preserved-FD range; the
        # untrusted check receives DEVNULL as stdin and closes all extra FDs.
        proc=subprocess.Popen(argv,stdin=proof_writer,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
            close_fds=True,pass_fds=descriptors,start_new_session=True,
            env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'})
        os.close(proof_writer); proof_writer=None
        for fd,kind in ((proc.stdout.fileno(),'output'),(proof_reader,'proof')):
            os.set_blocking(fd,False); selector.register(fd,selectors.EVENT_READ,kind)
        end=time.monotonic()+timeout+3
        while selector.get_map() and time.monotonic()<end:
            for key,_ in selector.select(min(.05,max(0,end-time.monotonic()))):
                data=os.read(key.fd,65536)
                if not data: selector.unregister(key.fd); continue
                if key.data=='proof':
                    proof.extend(data)
                    if len(proof)>MAX_PROOF: raise SnapshotDenied('supervisor_proof_overflow')
                elif len(output)<MAX_OUTPUT: output.extend(data[:MAX_OUTPUT-len(output)])
        if selector.get_map(): raise SnapshotDenied('snapshot_descendants_or_pipe_not_drained')
        code=proc.wait(timeout=max(.01,end-time.monotonic()))
        return code,bytes(proof),output.decode('utf-8','replace')
    finally:
        selector.close()
        if proc is not None:
            if proc.poll() is None:
                try: os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                try: proc.wait(timeout=1)
                except subprocess.TimeoutExpired: pass
            if proc.stdout is not None: proc.stdout.close()
        if proof_writer is not None: os.close(proof_writer)


def execute_snapshot(request, bundle, spec, *, runtime, manifest, runner_pin):
    """Called only by ExecutionBroker after its exact durable attempt claim."""
    from .task_worker import ActionResult
    from .task_check_containment import _verify_pins, _resource_boundary
    from .task_check_service import source_pin
    descriptors=(); read_fd=None; write_fd=None; started=False
    try:
        runtime=runtime_policy(runtime)
        binding=request['immutable']
        contents,inventory=validate_material(binding,bundle,request['action'],request['task'],spec)
        runtime_contents=_read_runtime(runtime)
        _verify_pins(manifest); _resource_boundary()
        if runner_pin.get('path')!=str(Path(__file__).resolve()) or source_pin(runner_pin['path'])!=runner_pin:
            raise SnapshotDenied('loaded_snapshot_source_changed')
        runner_bytes=Path(runner_pin['path']).read_bytes()
        if sha(runner_bytes)!=runner_pin['sha256'] or source_pin(runner_pin['path'])!=runner_pin:
            raise SnapshotDenied('loaded_snapshot_source_changed')
        read_fd,write_fd=os.pipe2(os.O_CLOEXEC)
        if min(read_fd,write_fd)<3: raise SnapshotDenied('service_standard_descriptors_required')
        request_sha256=sha(canonical(request))
        argv,descriptors=build_command(manifest,binding,inventory,contents,runtime,runtime_contents,
            request_sha256=request_sha256,runner_bytes=runner_bytes)
        deadline=request['task']['deadline_wall']
        if deadline is not None and (type(deadline) not in (int,float) or not math.isfinite(deadline) or time.time()>=deadline):
            raise SnapshotDenied('deadline_before_snapshot_execution')
        started=True
        # _run_bounded owns the writer even when Popen fails.
        owned_writer=write_fd; write_fd=None
        code,data,output=_run_bounded(argv,descriptors,read_fd,owned_writer,manifest['timeout_s'])
        result=_json_file(data)
        if type(result) is not dict or set(result)!={'proof','returncode','timed_out_or_cancelled'}:
            raise SnapshotDenied('supervisor_result_invalid')
        proof=validate_proof(result['proof'],binding,runtime_sha256=sha(canonical(runtime)),request_sha256=request_sha256)
        if (type(result['timed_out_or_cancelled']) is not bool or code not in (0,10)
                or (result['returncode'] is not None and type(result['returncode']) is not int)
                or (code==0 and (result['returncode']!=0 or result['timed_out_or_cancelled']))
                or (code==10 and result['returncode']==0 and not result['timed_out_or_cancelled'])):
            raise SnapshotDenied('supervisor_completion_mismatch')
        ok=code==0
        return ActionResult('SUCCEEDED' if ok else 'FAILED',{'ok':ok,'check':dict(spec.arguments)['check'],
            'returncode':result['returncode'],'reason':'check_complete' if ok else 'check_nonzero_or_timeout',
            'output':output,'process_drained':True,'namespace_drained':True,
            'input_proof':proof,'immutable_receipt':{'action_id':binding['action_id'],
                'request_sha256':request_sha256,'proof_sha256':sha(canonical(proof))}})
    except Exception:
        if started:
            return ActionResult('UNKNOWN',{'ok':False,'reason':'immutable_execution_unverified',
                'uncertain':True,'replay_allowed':False})
        return ActionResult('FAILED',{'ok':False,'executed':False,'reason':'immutable_input_unavailable'})
    finally:
        for fd in descriptors: os.close(fd)
        if read_fd is not None: os.close(read_fd)
        if write_fd is not None: os.close(write_fd)


def _inside(manifest, proof_fd):
    """Standalone trusted PID1; result channel is never inherited by the check."""
    import ctypes
    import resource
    status = dict(line.split(':',1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    if (proof_fd!=0 or os.getpid()!=1 or int(status['CapEff'],16) or int(status['CapPrm'],16)
            or int(status['NoNewPrivs'])!=1 or os.path.exists('/root') or os.path.exists('/home')):
        return 125
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(4,0,0,0,0)!=0 or libc.prctl(1,signal.SIGKILL,0,0,0)!=0: return 125
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_NOFILE,(64,64))
    resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024*1024,8*1024*1024))
    stopped=False
    def stop(*_):
        nonlocal stopped
        stopped=True
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    code=None
    try:
        _readonly_mounts(manifest['mount_paths'])
        before=_measure_tree('/workspace',manifest['inventory'])
        if before!=manifest['binding']['input_tree_sha256']: return 125
        # Runtime bytes too are measured inside the private readonly namespace.
        for row in manifest['runtime']['files']:
            info=os.lstat(row['path'])
            if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode)!=row['mode'] or sha(Path(row['path']).read_bytes())!=row['sha256']:
                return 125
        proc=subprocess.Popen(manifest['command'],cwd='/workspace'+('/'+manifest['cwd'] if manifest['cwd'] else ''),
                              stdin=subprocess.DEVNULL,close_fds=True,start_new_session=True)
        end=time.monotonic()+manifest['timeout_s']
        while not stopped and time.monotonic()<end:
            code=proc.poll()
            if code is not None: break
            time.sleep(.01)
    except Exception: stopped=True
    try: os.kill(-1,signal.SIGKILL)
    except ProcessLookupError: pass
    except OSError: return 125
    end=time.monotonic()+1
    drained=False
    while time.monotonic()<end:
        try:
            pid,_=os.waitpid(-1,os.WNOHANG)
            if pid==0: time.sleep(.01)
        except ChildProcessError:
            drained=True; break
        except InterruptedError: continue
    if not drained: return 125
    try:
        _readonly_mounts(manifest['mount_paths'])
        after=_measure_tree('/workspace',manifest['inventory'])
        proof={'version':1,'mode':MODE,'action_id':manifest['binding']['action_id'],
               'planner_proposal_sha256':manifest['binding']['planner_proposal_sha256'],
               'configuration_sha256':manifest['binding']['configuration_sha256'],
               'artifact_sha256':manifest['binding']['artifact_sha256'],
               'input_tree_sha256':before,'completion_tree_sha256':after,
               'runtime_sha256':sha(canonical(manifest['runtime'])), 'request_sha256':manifest['request_sha256'],
               'spec_sha256':manifest['binding']['spec_sha256'],
               'mutation_excluded':True,'held_until_drain':True,'namespace_drained':True,'process_drained':True}
        validate_proof(proof,manifest['binding'],runtime_sha256=sha(canonical(manifest['runtime'])),request_sha256=manifest['request_sha256'])
        message=canonical({'proof':proof,'returncode':code,'timed_out_or_cancelled':code is None or stopped})
        if len(message)>MAX_PROOF: return 125
        os.write(proof_fd,message)
        return 0 if code==0 and not stopped else 10
    except Exception: return 125


def _main():
    import sys
    if len(sys.argv)!=4 or sys.argv[1]!='--inside': return 125
    data=Path(sys.argv[2]).read_bytes()
    if len(data)>131072: return 125
    return _inside(_json_file(data),int(sys.argv[3]))


if __name__=='__main__':
    raise SystemExit(_main())
