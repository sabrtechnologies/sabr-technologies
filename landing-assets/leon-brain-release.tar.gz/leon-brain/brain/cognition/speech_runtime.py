"""Cold arbitration binding and retirement of the existing speech worker.

The runtime tick caches selection; audio hot paths read only that cached bool.
One-shot retirement runs potentially blocking sink callbacks off the consumer.
There is no new synthesis, capture, inference, or task execution loop.
"""
from __future__ import annotations

import math
import threading
import time


def stop_existing_audio(_event):
    """Only the existing bounded sink-stop actuator; no task or model cancel."""
    from brain.actuator_client import call
    return call('audio.stop', {}, timeout=.25)


class SpeechRuntime:
    def __init__(self, *, queue, configured_mode='off', live_mode=lambda: 'off',
                 runtime_accepting=lambda: False, stop_audio=stop_existing_audio):
        self._queue = queue
        self._configured, self._live, self._accepting = configured_mode, live_mode, runtime_accepting
        self._stop_audio = stop_audio
        self._lock = threading.RLock()
        # Serialize only admission fencing and final retirement publication.
        # Startup and potentially blocking sink cleanup use separate locks.
        self._lifecycle_lock = threading.Lock()
        self._installed = self._active = self._stopping = self._retired = False
        self._cleanup_thread = None
        self._failure = None

    def start(self):
        with self._lock:
            if self._stopping:
                raise RuntimeError('speech owner is retiring')
            if self._installed:
                return self
            # Initial OFF remains untouched. A new lifecycle explicitly
            # reopens legacy speech after an earlier owner drained and froze
            # admission; install itself verifies old binding/worker release.
            if self._configured != 'on' and self._queue.admissions_frozen() is not True:
                return self
            self._queue.install_arbitration(enabled=self.enabled, stop_audio=self._stop_audio)
            self._installed = True
            # quiesce intentionally never waits on the startup lock.
            if self._stopping:
                self._queue.quiesce_arbitration()
            return self

    def enabled(self):
        return self._active and not self._stopping

    def tick(self):
        if self._stopping:
            self.stop()
            return
        active = False
        if self._installed and self._configured == 'on':
            try:
                active = self._accepting() is True and self._live() == 'on'
            except Exception:
                pass
        # A concurrent quiesce remains authoritative through enabled().
        self._active = active

    def quiesce(self):
        # Keep the check and freeze indivisible with clear + retirement, so a
        # paused old caller cannot later freeze a subsequently installed owner.
        with self._lifecycle_lock:
            if self._retired:
                return
            self._stopping = True
            self._active = False
            if self._installed:
                self._queue.quiesce_arbitration()

    def _cleanup_alive(self):
        return self._cleanup_thread is not None and self._cleanup_thread.is_alive()

    def _drain(self):
        try:
            if self._queue.stop(timeout=.25) is True:
                with self._lifecycle_lock:
                    self._queue.clear_arbitration()
                    self._retired = True
        except Exception as exc:
            self._failure = type(exc).__name__

    def stop(self, *, join_timeout=0):
        if (isinstance(join_timeout, bool) or not isinstance(join_timeout, (int, float))
                or not math.isfinite(join_timeout) or join_timeout < 0):
            raise ValueError('join_timeout')
        if self.retired:
            return True
        deadline = time.monotonic() + join_timeout
        self.quiesce()
        if not self._lock.acquire(blocking=False):
            return False
        try:
            if not self._installed:
                with self._lifecycle_lock:
                    self._retired = True
            elif not self._retired and not self._cleanup_alive():
                self._cleanup_thread = threading.Thread(target=self._drain,
                    name='leon-speech-retire', daemon=True)
                try:
                    self._cleanup_thread.start()
                except Exception as exc:
                    self._failure = type(exc).__name__
            cleanup = self._cleanup_thread
        finally:
            self._lock.release()
        if cleanup is not threading.current_thread() and self._cleanup_alive() and join_timeout:
            cleanup.join(max(0, deadline - time.monotonic()))
        return self.retired

    @property
    def retired(self):
        return self._retired and not self._cleanup_alive()

    def stats(self):
        return {'installed': self._installed and not self.retired, 'active': self.enabled(),
                'stopping': self._stopping, 'retiring': self._cleanup_alive(),
                'retired': self.retired, 'failure': self._failure}
