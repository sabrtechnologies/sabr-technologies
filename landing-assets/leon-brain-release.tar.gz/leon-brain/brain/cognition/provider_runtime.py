"""Explicit provider policy inside the existing admitted scheduler call.

No credentials, adapters, ledgers, threads, queues or model calls are created by
OFF/SHADOW. Execution uses one ProviderRouter, pinned to one caller-selected
provider per admitted request; failures never select an implicit paid fallback.
"""
from contextvars import ContextVar
from dataclasses import dataclass
import json
import math
import threading
import time
import weakref

from ..providers.base import (Capability, ProviderSpec, ProviderRequest, ProviderEvent,
    Usage, Unavailable, UnsupportedPolicy, ProtocolError, check_cancel)
from ..providers.base import ProviderError
from ..providers.budget import Limits, BudgetLedger, price_micro_usd


@dataclass(frozen=True)
class RequestScope:
    site: str
    group: str
    channel: str

    def __post_init__(self):
        if any(not isinstance(v, str) or not v or len(v) > 256 for v in
               (self.site, self.group, self.channel)):
            raise ValueError("explicit bounded scheduler scope required")


@dataclass(frozen=True)
class ProviderRule:
    spec: ProviderSpec
    input_token_bound: int
    output_token_bound: int
    evidence_ref: str = ""
    valid_until_mono: float = 0.0
    billing_kind: str = "unverified"  # local, subscription, metered
    billing_verified: bool = False
    full_call_bounds_verified: bool = False
    transport_cancel_verified: bool = False
    no_tools_verified: bool = False
    tool_drain_verified: bool = False

    def __post_init__(self):
        if not isinstance(self.spec, ProviderSpec):
            raise ValueError("exact existing provider spec required")
        if any(type(n) is not int or n <= 0 for n in (self.input_token_bound, self.output_token_bound)):
            raise ValueError("explicit positive full-call token bounds required")
        if not isinstance(self.evidence_ref, str) or len(self.evidence_ref) > 256:
            raise ValueError("invalid policy evidence reference")
        if not math.isfinite(self.valid_until_mono):
            raise ValueError("finite policy validity required")
        for name in ("billing_verified", "full_call_bounds_verified", "transport_cancel_verified",
                     "no_tools_verified", "tool_drain_verified"):
            if type(getattr(self, name)) is not bool:
                raise ValueError("policy attestations must be explicit booleans")


@dataclass(frozen=True)
class ProviderPolicy:
    revision: str
    rules: tuple
    scopes: tuple
    limits: Limits
    per_capability: tuple = ()

    def __post_init__(self):
        if not isinstance(self.revision, str) or not self.revision or len(self.revision) > 128:
            raise ValueError("explicit bounded policy revision required")
        object.__setattr__(self, "rules", tuple(self.rules))
        object.__setattr__(self, "scopes", tuple(self.scopes))
        object.__setattr__(self, "per_capability", tuple(tuple(pair) for pair in self.per_capability))
        if (not isinstance(self.limits, Limits) or not 1 <= len(self.rules) <= 16
                or any(not isinstance(r, ProviderRule) for r in self.rules)
                or len({r.spec.provider_id for r in self.rules}) != len(self.rules)
                or not 1 <= len(self.scopes) <= 128
                or any(not isinstance(s, RequestScope) for s in self.scopes)):
            raise ValueError("invalid frozen provider policy")
        keys = []
        for key, limits in self.per_capability:
            Capability(key)
            if not isinstance(key, str) or not isinstance(limits, Limits):
                raise ValueError("invalid per-capability budget")
            keys.append(key)
        if len(set(keys)) != len(keys):
            raise ValueError("duplicate capability budget")


def _json_snapshot(value):
    try:
        data = json.dumps(value, allow_nan=False, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except (ValueError, TypeError):
        raise UnsupportedPolicy("provider request options must be explicit JSON data") from None
    if len(data.encode("utf-8")) > 65536:
        raise UnsupportedPolicy("provider request options exceed bound")
    return data


_selected = ContextVar("leon_explicit_provider_rule", default=None)
_installed = weakref.WeakKeyDictionary()
_install_lock = threading.Lock()


class _GuardedBudget:
    def __init__(self, owner): self.owner = owner

    def reserve(self, capabilities, tokens, micro_usd):
        self.owner._check_budget()
        return self.owner._ledger.reserve(capabilities, tokens, micro_usd)

    def settle(self, *args, **kwargs):
        # Settlement must finish even after admission or live policy is revoked.
        return self.owner._ledger.settle(*args, **kwargs)


class _PinnedAdapter:
    def __init__(self, owner, rule, adapter):
        self.owner, self.rule, self.adapter = owner, rule, adapter
        self.spec = rule.spec

    @property
    def configured(self):
        return (_selected.get() is self.rule and self.adapter.configured is True
                and self.adapter.spec == self.spec)

    def _bound(self, name, request, approved):
        observed = getattr(self.adapter, name)(request)
        if type(observed) is not int or observed < 0 or observed > approved:
            raise UnsupportedPolicy("adapter lacks reviewed full-call token bounds")
        return approved

    def input_bound(self, request):
        if request.input_bound() > self.rule.input_token_bound:
            raise UnsupportedPolicy("request exceeds approved full-call input bound")
        return self._bound("input_bound", request, self.rule.input_token_bound)

    def output_bound(self, request):
        if request.max_output_tokens > self.rule.output_token_bound:
            raise UnsupportedPolicy("request exceeds approved full-call output bound")
        return self._bound("output_bound", request, self.rule.output_token_bound)

    def stream(self, request, cancel_token=None):
        if not self.configured:
            raise Unavailable("provider configuration changed")
        stream = iter(self.adapter.stream(request, cancel_token=cancel_token))
        try:
            for event in stream:
                if not isinstance(event, ProviderEvent):
                    raise ProtocolError("adapter must emit typed ProviderEvent values")
                if event.usage is not None and not isinstance(event.usage, Usage):
                    raise ProtocolError("adapter usage must be an observed Usage value")
                if event.usage is not None:
                    # Observe before router cancellation suppresses delivery;
                    # these counters confer no final-accounting authority.
                    self.owner._counts["usage_events"] += 1
                    self.owner._counts["usage_final_events"] += int(event.usage_final is True)
                if event.type in ("tool_use", "tool_confirm_request", "tool_result"):
                    if not request.allow_tools:
                        raise UnsupportedPolicy("no-tools adapter emitted a tool envelope")
                    if event.raw is None:
                        raise ProtocolError("tool envelope requires original legacy event")
                if event.type == "decision" and request.capabilities != frozenset({Capability.DECISION}):
                    raise ProtocolError("typed decision cannot substitute for language or tools")
                # Never infer usage from text length or reinterpret Jev confidence.
                # Preserve the exact typed event and its original tool-bearing raw.
                yield event
        finally:
            close = getattr(stream, "close", None)
            if close is not None:
                close()


class ProviderRuntime:
    def __init__(self, *, policy, adapters=(), ledger=None, mode="off", health=None):
        if not isinstance(policy, ProviderPolicy) or mode not in {"off", "shadow", "canary", "on"}:
            raise ValueError("explicit provider policy and supported mode required")
        self._policy, self._mode = policy, mode
        self._adapters, self._ledger = tuple(adapters), ledger
        self._health = health  # Optional owner-supplied registry shared with the router.
        self._router = self._scheduler = None
        self._lock = threading.RLock()
        self._stopping = self._retired = False
        self._active = {}
        self._last_admitted_token = None  # One scheduler slot; bounded duplicate-call guard.
        self._counts = {"started": 0, "completed": 0, "failed": 0,
                        "usage_events": 0, "usage_final_events": 0}

    @property
    def policy(self): return self._policy

    @property
    def mode(self): return self._mode

    def install(self, scheduler):
        """One owner per existing scheduler; no scheduler creation/start/stop."""
        with _install_lock:
            existing = _installed.get(scheduler)
            if (self._stopping or (existing is not None and existing is not self)
                    or (self._scheduler is not None and self._scheduler is not scheduler)):
                return False
            self._scheduler = scheduler
            _installed[scheduler] = self
            return True

    def uninstall(self):
        with _install_lock:
            if not self._retired or _installed.get(self._scheduler) is not self:
                return False
            del _installed[self._scheduler]
            return True

    def _check_budget(self):
        if (not isinstance(self._ledger, BudgetLedger) or self._ledger.limits != self.policy.limits
                or self._ledger.per_capability != dict(self.policy.per_capability)):
            raise Unavailable("injected budget ledger does not match frozen policy")

    def _rule(self, provider_id, allow_tools):
        rule = next((r for r in self.policy.rules if r.spec.provider_id == provider_id), None)
        if (rule is None or not rule.evidence_ref or rule.valid_until_mono <= time.monotonic()
                or not rule.billing_verified or not rule.full_call_bounds_verified
                or not rule.transport_cancel_verified
                or rule.billing_kind not in {"local", "subscription", "metered"}
                or rule.spec.input_usd_per_million is None or rule.spec.output_usd_per_million is None):
            raise Unavailable("provider transport/billing/bounds policy is unverified or expired")
        if rule.billing_kind == "local" and not rule.spec.local:
            raise Unavailable("local billing policy does not match provider")
        if rule.billing_kind == "subscription" and (rule.spec.input_usd_per_million != 0
                                                   or rule.spec.output_usd_per_million != 0):
            raise Unavailable("subscription incremental-cost contract is inconsistent")
        if allow_tools:
            if not rule.tool_drain_verified or Capability.TOOL_USE not in rule.spec.capabilities:
                raise UnsupportedPolicy("provider tool policy/drain is unverified")
        elif not rule.no_tools_verified or not rule.spec.no_tools_enforced:
            raise UnsupportedPolicy("provider no-tools transport is unverified")
        return rule

    def _ensure_router(self):
        if self._router is not None:
            return
        from ..providers.router import ProviderRouter
        adapters = {a.spec.provider_id:a for a in self._adapters}
        if len(adapters) != len(self._adapters):
            raise Unavailable("duplicate provider adapter bindings")
        selected = []
        for rule in self.policy.rules:
            adapter = adapters.get(rule.spec.provider_id)
            if adapter is not None:
                selected.append(_PinnedAdapter(self, rule, adapter))
        self._router = ProviderRouter(selected, _GuardedBudget(self), health=self._health)

    def unavailable(self, provider_id, capabilities):
        """Content-free reason a no-tools call cannot dispatch now, else None.

        A cheap pre-dispatch check for the route owner: cached policy, adapter
        and health state plus one read-only ledger preview of the exact
        reservation the router would make. Nothing is reserved, sent or probed.
        """
        if self.mode not in {"canary", "on"} or self._stopping or self._scheduler is None:
            return "not_ready"
        adapter = next((a for a in self._adapters if a.spec.provider_id == provider_id), None)
        if adapter is None or adapter.configured is not True:
            return "credential"
        try:
            rule = self._rule(provider_id, False)
        except ProviderError:
            return "policy"
        if adapter.spec != rule.spec:
            return "policy"
        if self._health is not None and not self._health.available(provider_id):
            return "breaker"
        try:
            self._check_budget()
            # _PinnedAdapter reserves the approved full-call bounds, never an estimate.
            cost = price_micro_usd(rule.spec, rule.input_token_bound, rule.output_token_bound)
            if not self._ledger.would_admit(frozenset(Capability(c) for c in capabilities),
                                            rule.input_token_bound + rule.output_token_bound, cost):
                return "budget"
        except Exception:
            return "budget"
        return None

    def provider_for(self, request, *, provider_id, capabilities, context,
                     max_output_tokens, questions=None, legacy_kwargs=None, deep=False):
        """Build the exact scheduler provider callback; this never invokes it.

        Root may call this inside its default provider after prepare/coalescing,
        then invoke the returned callback with the admitted prompt/kwargs/token.
        Queue-time closures reject changed privileges/options instead of guessing.
        """
        if self.mode not in {"canary", "on"} or self._stopping or self._scheduler is None:
            raise Unavailable("provider execution requires explicitly enabled installed owner")
        scope = RequestScope(request.site, request.group, request.channel)
        if scope not in self.policy.scopes:
            raise UnsupportedPolicy("scheduler request scope is not approved")
        rule = self._rule(provider_id, request.allow_tools)
        capabilities = frozenset(Capability(c) for c in capabilities)
        if not capabilities <= rule.spec.capabilities:
            raise UnsupportedPolicy("requested capability is not implemented by selected adapter")
        if Capability.DECISION in capabilities and (capabilities != {Capability.DECISION} or request.allow_tools
                                                    or request.persist_history):
            raise UnsupportedPolicy("decision provider is a typed advisor only")
        if not isinstance(context, str):
            raise UnsupportedPolicy("explicit rendered context snapshot required")
        options = _json_snapshot(dict(request.responder_kwargs if legacy_kwargs is None else legacy_kwargs))
        qdata = _json_snapshot({} if questions is None else questions)
        identity = (request.request_id, request.trace_id, scope, request.allow_tools,
                    request.persist_history, request.deadline_mono, request.kind)
        invoked = [False]

        def provide(req, prompt, kwargs, token):
            from . import inference_scheduler as scheduler_module
            scheduler = self._scheduler
            current = (req.request_id, req.trace_id, RequestScope(req.site, req.group, req.channel),
                       req.allow_tools, req.persist_history, req.deadline_mono, req.kind)
            active = getattr(scheduler, "_active", None)
            if (req is not request or current != identity or _json_snapshot(dict(kwargs)) != options
                    or invoked[0] or self._stopping or self.mode not in {"canary", "on"}
                    or _installed.get(scheduler) is not self
                    or threading.current_thread() is not getattr(scheduler, "_thread", None)
                    or not scheduler_module.in_worker_context()
                    or active is None or active.req is not req or active.token is not token
                    or active.state != "running"):
                raise UnsupportedPolicy("provider call is not this exact admitted scheduler request")
            invoked[0] = True
            check_cancel(token, req.deadline_mono)
            current_rule = self._rule(provider_id, req.allow_tools)
            if current_rule is not rule:
                raise UnsupportedPolicy("frozen provider rule changed")
            bound_options = json.loads(options)
            for key, expected in (("allow_tools", req.allow_tools), ("persist_history", req.persist_history),
                                  ("channel", req.channel)):
                if key in bound_options and bound_options[key] != expected:
                    raise UnsupportedPolicy("legacy option conflicts with admitted policy")
            prepared = ProviderRequest(prompt=prompt, context=context, capabilities=capabilities,
                allow_tools=req.allow_tools, persist_history=req.persist_history,
                background=req.channel == "daemon", deep=deep, max_output_tokens=max_output_tokens,
                deadline_mono=req.deadline_mono, questions=json.loads(qdata),
                legacy_kwargs=bound_options, trace_id=req.trace_id)
            with self._lock:
                if self._stopping or self._last_admitted_token is token:
                    raise Unavailable("provider owner is retiring or this admission was already used")
                self._check_budget()
                self._ensure_router()
                self._last_admitted_token = token
                self._active[req.request_id] = token
                self._counts["started"] += 1
            selection = _selected.set(rule)
            stream = None
            try:
                stream = self._router.stream(prepared, cancel_token=token)
                for event in stream:
                    yield event
                self._counts["completed"] += 1
            except BaseException:
                self._counts["failed"] += 1
                raise
            finally:
                try:
                    if stream is not None:
                        stream.close()
                finally:
                    _selected.reset(selection)
                    with self._lock:
                        self._active.pop(req.request_id, None)
        return provide

    def quiesce(self):
        self._stopping = True

    def stop(self):
        """Cancel owned calls, retain until provider/tool drain and settlement end."""
        self.quiesce()
        with self._lock:
            tokens = tuple(self._active.values())
        for token in tokens:
            token.cancel("provider_runtime_retired")
        with self._lock:
            self._retired = not self._active
            return self._retired

    @property
    def retired(self):
        return self._retired

    def stats(self):
        return {"mode": self.mode, "stopping": self._stopping, "retired": self._retired,
                "installed": self._scheduler is not None and _installed.get(self._scheduler) is self,
                "active": len(self._active), "router_created": self._router is not None,
                "implicit_fallback": False, "ledger_owned": False, **self._counts}
