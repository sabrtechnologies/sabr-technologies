"""Continuity-preserving procedural plans; OFF by default, no implicit I/O dispatch.

Legacy stores remain authoritative. Imports are read-only and use stable IDs.
An integrator supplies the existing action dispatcher, policy gate and event sink.
The utterance ledger is shared with the voice spotter and claims BEFORE dispatch.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import sqlite3
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional


@dataclass(frozen=True)
class ActionStep:
    tool: str
    args: dict = field(default_factory=dict)


@dataclass(frozen=True)
class Predicate:
    key: str
    equals: Any = True


@dataclass(frozen=True)
class VerificationSpec:
    kind: str = "tool_ok"
    expected: dict = field(default_factory=lambda: {"ok": True})


@dataclass(frozen=True)
class RollbackSpec:
    steps: tuple[ActionStep, ...] = ()


@dataclass(frozen=True)
class Procedure:
    procedure_id: str
    name: str
    trigger_examples: tuple[str, ...]
    required_keywords: tuple[str, ...]
    action_steps: tuple[ActionStep, ...]
    preconditions: tuple[Predicate, ...] = ()
    verification: VerificationSpec = field(default_factory=VerificationSpec)
    rollback: Optional[RollbackSpec] = None
    risk: str = "R3"
    reversible: bool = False
    confidence: float = 0.0
    successes: int = 0
    failures: int = 0
    source: str = "manual"


@dataclass(frozen=True)
class ProcedureMatch:
    procedure: Procedure
    steps: tuple[ActionStep, ...]
    confidence: float
    text: str


@dataclass(frozen=True)
class GateDecision:
    allowed: bool = False
    confirmed: bool = False
    reason: str = "policy did not authorize"


def normalize(text):
    return " ".join(re.findall(r"[a-z0-9%]+", (text or "").lower()))


def _score(value):
    try:
        number = float(value)
        return max(0.0, min(number, 1.0)) if math.isfinite(number) else 0.0
    except (ValueError, TypeError):
        return 0.0


def _id(prefix, value):
    return prefix + hashlib.sha256(value.encode("utf-8")).hexdigest()[:24]


def step_risk(step):
    """Conservative floor; data/learned metadata cannot downgrade an action."""
    if step.tool in {"screen.capture", "volume.get", "state.get"}:
        return "R0"
    if step.tool in {"volume.adjust", "volume.set", "volume.mute", "brightness.set", "brightness.adjust"}:
        return "R1"
    if step.tool == "keyboard.hotkey":
        if step.args.get("combo") in {"XF86AudioPlay", "XF86AudioNext", "XF86AudioPrev"}:
            return "R1"
        if step.args.get("combo") == "super+l":
            return "R2"
    if step.tool in {"app.open", "window.move", "draft.create"}:
        return "R2"
    return "R3"


def risk_of(procedure, steps):
    return max([procedure.risk if procedure.risk in {"R0", "R1", "R2", "R3"} else "R3"]
               + [step_risk(s) for s in steps])


class UtteranceLedger:
    """Process-local at-most-once attempts, including uncertain/failed dispatch.

    Never evicts an utterance to make room: capacity exhaustion fails closed.
    Retire entries only after all partial/final producers have acknowledged end.
    Across process restarts the integrator needs a durable receipt/idempotency key.
    """
    def __init__(self, capacity=4096):
        self.capacity = capacity
        self._lock = threading.Lock()
        self._entries = {}
        self._finals = {}

    def get(self, trace_id, utterance_id):
        with self._lock:
            return copy.deepcopy(self._entries.get((trace_id, utterance_id)))

    def claim(self, trace_id, utterance_id, initial):
        with self._lock:
            key = (trace_id, utterance_id)
            if key in self._entries:
                return False, copy.deepcopy(self._entries[key])
            if initial.get("partial") and key in self._finals:
                return False, {"status": "blocked", "reason": "final transcript already received", "executed": False}
            if len(self._entries) >= self.capacity:
                return False, {"status": "blocked", "reason": "utterance ledger full", "executed": False}
            self._entries[key] = copy.deepcopy(initial)
            return True, None

    def finish(self, trace_id, utterance_id, result):
        with self._lock:
            self._entries[(trace_id, utterance_id)] = copy.deepcopy(result)

    def get_final(self, trace_id, utterance_id):
        with self._lock:
            return copy.deepcopy(self._finals.get((trace_id, utterance_id)))

    def claim_final(self, trace_id, utterance_id, payload):
        """Commit first final before emission, independently of an action claim."""
        with self._lock:
            key = (trace_id, utterance_id)
            if key in self._finals:
                return False, copy.deepcopy(self._finals[key])
            if len(self._finals) >= self.capacity:
                raise RuntimeError("final receipt ledger full")
            self._finals[key] = copy.deepcopy(payload)
            return True, None

    def finish_final(self, trace_id, utterance_id, payload):
        with self._lock:
            self._finals[(trace_id, utterance_id)] = copy.deepcopy(payload)

    def pending_feedback(self):
        """Recovery references only; callers retry feedback, never actions."""
        with self._lock:
            return _pending_receipts(self._entries.items(), self._finals.items())

    def retire(self, trace_id, utterance_id):
        """Caller guarantees no producer can replay this utterance after retirement."""
        with self._lock:
            key = (trace_id, utterance_id)
            value, final = self._entries.get(key), self._finals.get(key)
            if not _can_retire(value, final):
                return False
            self._entries.pop(key, None)
            self._finals.pop(key, None)
            return True


def _can_retire(action, final):
    return not (action and (action.get("status") == "running" or action.get("feedback_pending"))) and not (
        final and not final.get("feedback_delivered"))


def _pending_receipts(actions, finals):
    refs = []
    for (trace_id, utterance_id), receipt in actions:
        kind = "uncertain_action" if receipt.get("status") == "running" else "action"
        if kind == "uncertain_action" or receipt.get("feedback_pending"):
            refs.append({"kind": kind, "trace_id": trace_id, "utterance_id": utterance_id})
    for (trace_id, utterance_id), receipt in finals:
        if not receipt.get("feedback_delivered"):
            refs.append({"kind": "voice_final", "trace_id": trace_id, "utterance_id": utterance_id})
    return refs


class SQLiteUtteranceLedger:
    """Optional durable receipts in an EXPLICIT separate derived-store path.

    No defaults point at canonical state. An uncertain/running receipt remains
    latched across restart, since the actuator may have received the action.
    This guarantees at-most-once dispatch attempts, not atomic physical effects.
    """
    def __init__(self, path, capacity=4096):
        self.capacity, self._lock = capacity, threading.RLock()
        self._conn = sqlite3.connect(str(path), timeout=3, check_same_thread=False,
                                     isolation_level=None)
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.execute("CREATE TABLE IF NOT EXISTS procedural_receipts ("
                           "trace_id TEXT NOT NULL, utterance_id TEXT NOT NULL, receipt TEXT NOT NULL, "
                           "PRIMARY KEY(trace_id, utterance_id))")
        self._conn.execute("CREATE TABLE IF NOT EXISTS procedural_final_receipts ("
                           "trace_id TEXT NOT NULL, utterance_id TEXT NOT NULL, receipt TEXT NOT NULL, "
                           "PRIMARY KEY(trace_id, utterance_id))")

    def get(self, trace_id, utterance_id):
        with self._lock:
            row = self._conn.execute("SELECT receipt FROM procedural_receipts WHERE trace_id=? AND utterance_id=?",
                                     (trace_id, utterance_id)).fetchone()
            return json.loads(row[0]) if row else None

    def claim(self, trace_id, utterance_id, initial):
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                existing = self.get(trace_id, utterance_id)
                if existing is not None:
                    self._conn.execute("COMMIT")
                    return False, existing
                if initial.get("partial") and self.get_final(trace_id, utterance_id) is not None:
                    self._conn.execute("COMMIT")
                    return False, {"status": "blocked", "reason": "final transcript already received", "executed": False}
                if self._conn.execute("SELECT COUNT(*) FROM procedural_receipts").fetchone()[0] >= self.capacity:
                    self._conn.execute("COMMIT")
                    return False, {"status": "blocked", "reason": "utterance ledger full", "executed": False}
                self._conn.execute("INSERT INTO procedural_receipts VALUES(?,?,?)",
                                   (trace_id, utterance_id, json.dumps(initial, allow_nan=False)))
                self._conn.execute("COMMIT")
                return True, None
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def finish(self, trace_id, utterance_id, result):
        with self._lock:
            self._conn.execute("UPDATE procedural_receipts SET receipt=? WHERE trace_id=? AND utterance_id=?",
                               (json.dumps(result, allow_nan=False), trace_id, utterance_id))

    def get_final(self, trace_id, utterance_id):
        with self._lock:
            row = self._conn.execute("SELECT receipt FROM procedural_final_receipts WHERE trace_id=? AND utterance_id=?",
                                     (trace_id, utterance_id)).fetchone()
            return json.loads(row[0]) if row else None

    def claim_final(self, trace_id, utterance_id, payload):
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                existing = self.get_final(trace_id, utterance_id)
                if existing is not None:
                    self._conn.execute("COMMIT")
                    return False, existing
                if self._conn.execute("SELECT COUNT(*) FROM procedural_final_receipts").fetchone()[0] >= self.capacity:
                    raise RuntimeError("final receipt ledger full")
                self._conn.execute("INSERT INTO procedural_final_receipts VALUES(?,?,?)",
                                   (trace_id, utterance_id, json.dumps(payload, allow_nan=False)))
                self._conn.execute("COMMIT")
                return True, None
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def finish_final(self, trace_id, utterance_id, payload):
        with self._lock:
            self._conn.execute("UPDATE procedural_final_receipts SET receipt=? WHERE trace_id=? AND utterance_id=?",
                               (json.dumps(payload, allow_nan=False), trace_id, utterance_id))

    def pending_feedback(self):
        with self._lock:
            actions = [((r[0], r[1]), json.loads(r[2])) for r in self._conn.execute(
                "SELECT trace_id, utterance_id, receipt FROM procedural_receipts")]
            finals = [((r[0], r[1]), json.loads(r[2])) for r in self._conn.execute(
                "SELECT trace_id, utterance_id, receipt FROM procedural_final_receipts")]
            return _pending_receipts(actions, finals)

    def retire(self, trace_id, utterance_id):
        """Explicit producer acknowledgment only; no age-based eviction."""
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                if not _can_retire(self.get(trace_id, utterance_id), self.get_final(trace_id, utterance_id)):
                    self._conn.execute("COMMIT")
                    return False
                self._conn.execute("DELETE FROM procedural_receipts WHERE trace_id=? AND utterance_id=?",
                                   (trace_id, utterance_id))
                self._conn.execute("DELETE FROM procedural_final_receipts WHERE trace_id=? AND utterance_id=?",
                                   (trace_id, utterance_id))
                self._conn.execute("COMMIT")
                return True
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def close(self):
        with self._lock:
            self._conn.close()


# Finite numeric aliases match local recognizers' spoken-number output, without
# guessing arbitrary numeric phrases or expanding the early command vocabulary.
_PERCENT_WORDS = ("zero", "five", "ten", "fifteen", "twenty", "twenty five", "thirty", "thirty five",
                  "forty", "forty five", "fifty", "fifty five", "sixty", "sixty five", "seventy",
                  "seventy five", "eighty", "eighty five", "ninety", "ninety five", "one hundred")
_SPOKEN_VOLUME = {f"set volume to {word} percent": f"set volume to {n * 5} percent"
                  for n, word in enumerate(_PERCENT_WORDS)}

# Finite early vocabulary. Regexes below are imported from the legacy table;
# these phrases constrain partial speech, rather than copying that broad grammar.
_PHRASES = {
    "volume_down": ("turn the volume down", "lower the volume", "quieter", "softer"),
    "volume_up": ("turn the volume up", "raise the volume", "louder"),
    "volume_mute": ("mute", "unmute"),
    "volume_max": ("maximum volume", "volume maximum"),
    "volume_min": ("volume minimum", "volume zero", "volume off"),
    "volume_set": tuple(_SPOKEN_VOLUME.values()) + tuple(_SPOKEN_VOLUME),
    "play_pause": ("play music", "pause music", "resume music"),
    "next_track": ("next song", "skip track"),
    "prev_track": ("previous song", "previous track"),
    "lock_screen": ("lock screen", "lock computer"),
    "screenshot": ("take screenshot", "grab screenshot"),
}


def _builtin_steps(name, text, match, legacy):
    if name in {"volume_down", "volume_up"}:
        amount = legacy._extract_number(text, default=5)
        return (ActionStep("volume.adjust", {"delta": -amount if name == "volume_down" else amount}),)
    if name in {"volume_max", "volume_min", "volume_set"}:
        target = 100 if name == "volume_max" else 0 if name == "volume_min" else int(match.group(1))
        return (ActionStep("volume.set", {"percent": target}),)
    if name == "volume_mute":
        return (ActionStep("volume.mute", {}),)
    combo = {"play_pause": "XF86AudioPlay", "next_track": "XF86AudioNext",
             "prev_track": "XF86AudioPrev", "lock_screen": "super+l"}.get(name)
    return (ActionStep("keyboard.hotkey", {"combo": combo}),) if combo else (ActionStep("screen.capture", {}),)


def _reply(match):
    if match.procedure.source != "builtin":
        return "Done. (Used a pattern I learned from experience.)"
    name, args = match.procedure.name, match.steps[0].args
    if name == "volume_down":
        return f"Done — lowered volume by {abs(args['delta'])}%."
    if name == "volume_up":
        return f"Done — raised volume by {args['delta']}%."
    if name == "volume_set":
        return f"Volume set to {args['percent']}%."
    return {"volume_max": "Volume maxed out at 100%.", "volume_min": "Volume set to 0%.",
            "volume_mute": "Toggled mute.", "play_pause": "Toggled play/pause.",
            "next_track": "Skipped to next track.", "prev_track": "Went to previous track.",
            "lock_screen": "Screen locked.", "screenshot": "Screenshot captured."}.get(name, "Done.")


def _resolved_steps(procedure, text, bindings=None):
    """Never drop or guess missing argument templates, including nested values."""
    numbers = iter(re.findall(r"(?<!\w)-?\d+(?:\.\d+)?", text))
    bindings = bindings or {}

    def fill(value, key, index):
        if value == "__NUMBER__":
            if key in bindings.get(index, {}):
                return copy.deepcopy(bindings[index][key])
            if key == "delta":
                # Legacy learning discarded the original sign. Requiring a
                # binding avoids turning a learned "down" command into "up".
                raise ValueError("numeric delta template requires explicit binding")
            raw = next(numbers, None)
            if raw is None:
                raise ValueError("missing numeric argument")
            return float(raw) if "." in raw else int(raw)
        if value == "__STRING__" or (isinstance(value, str) and value.startswith("<") and value.endswith(">")):
            if key not in bindings.get(index, {}):
                raise ValueError("argument template requires explicit binding")
            return copy.deepcopy(bindings[index][key])
        if isinstance(value, dict):
            return {k: fill(v, k, index) for k, v in value.items()}
        if isinstance(value, list):
            return [fill(v, key, index) for v in value]
        return copy.deepcopy(value)

    return tuple(ActionStep(s.tool, {k: fill(v, k, i) for k, v in s.args.items()})
                 for i, s in enumerate(procedure.action_steps))


def _validate_steps(steps):
    if not steps:
        raise ValueError("procedure has no steps")
    for step in steps:
        if not isinstance(step.tool, str) or not step.tool or not isinstance(step.args, dict):
            raise ValueError("invalid action step")
        for key, value in step.args.items():
            if key in {"delta", "percent", "volume", "brightness"}:
                low = -100 if key == "delta" else 0
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= 100:
                    raise ValueError("numeric action argument outside safe range")
        # JSON validation also rejects non-finite numbers in unknown nested args.
        json.dumps(step.args, allow_nan=False)


class ProceduralRouter:
    @classmethod
    def from_existing(cls, *, skill_memory, **kwargs):
        """Use existing handles/paths without constructing or migrating stores."""
        from brain import reflex_learning
        return cls(learned_path=reflex_learning._REFLEX_FILE, skill_memory=skill_memory, **kwargs)

    def __init__(self, *, mode="off", dispatch=None, action_gate=None, emit=None,
                 learned_path=None, skill_memory=None, ledger=None, clock=time.monotonic):
        if mode not in {"off", "shadow", "on"}:
            raise ValueError("mode must be off, shadow or on")
        from brain import reflexes as legacy
        self.mode, self.dispatch, self.action_gate, self.emit = mode, dispatch, action_gate, emit
        self.ledger, self.clock = ledger or UtteranceLedger(), clock
        self._legacy, self._lock = legacy, threading.RLock()
        self._patterns = [(re.compile(p), h.__name__.lstrip("_")) for p, h in legacy._REFLEXES]
        self.learned_path = Path(learned_path) if learned_path is not None else None
        self.skill_memory = skill_memory  # reuse a live instance; never create/migrate a database
        self._sources, self._manual, self._last = {}, {}, None
        self.source_errors = {}
        self.refresh_sources()

    def refresh_sources(self):
        """Idempotent read projection; broken imports retain the last good source."""
        builtins = {}
        for _, name in self._patterns:
            if name not in _PHRASES:
                raise ValueError(f"unmapped legacy handler: {name}")
            text = _PHRASES[name][0]
            pattern = next(p for p, n in self._patterns if n == name and p.search(text))
            steps = _builtin_steps(name, text, pattern.search(text), self._legacy)
            risk = max(step_risk(s) for s in steps)
            builtins["builtin:" + name] = Procedure("builtin:" + name, name, _PHRASES[name], (), steps,
                risk=risk, reversible=risk == "R1", confidence=1.0, source="builtin")
        with self._lock:
            self._sources["builtin"] = builtins
        if self.learned_path is not None:
            try:
                if not self.learned_path.exists() and "learned" not in self._sources:
                    raw = {}
                else:
                    raw = json.loads(self.learned_path.read_text(encoding="utf-8"))
                if not isinstance(raw, dict):
                    raise ValueError("learned reflex store must contain an object")
                imported = {}
                for key, row in raw.items():
                    steps = (ActionStep(row["tool"], copy.deepcopy(row.get("args_template", {}))),)
                    successes = max(0, int(row.get("success_count", 0)))
                    pid = _id("learned:", key)
                    imported[pid] = Procedure(pid, row.get("user_example") or row["tool"],
                        (row.get("user_example", ""),), tuple(row.get("keywords", ())), steps,
                        risk=max("R2", max(step_risk(s) for s in steps)),
                        confidence=min(0.98, (successes + 1) / (successes + 2)),
                        successes=successes, source="learned_reflex")
                self._replace_source("learned", imported)
            except Exception as exc:
                self.source_errors["learned"] = type(exc).__name__
        if self.skill_memory is not None:
            try:
                imported = {}
                for row in self.skill_memory.procedural_snapshot():
                    steps = tuple(ActionStep(s["tool"], copy.deepcopy(s["arg_template"])) for s in row["steps"])
                    pid = _id("skill:", row["signature"])
                    success, total = row["success_runs"] + row["invoke_success"], row["runs"] + row["invoke_runs"]
                    imported[pid] = Procedure(pid, row["name"], (row["name"],), (), steps,
                        preconditions=(Predicate("allow_deprecated", True),) if row["state"] == "deprecated" else (),
                        risk=max(["R2"] + [step_risk(s) for s in steps]),
                        confidence=min(0.98, _score(row["reinforcement"]), (success + 1) / (total + 2)),
                        successes=success, failures=max(0, total-success), source="skill_memory")
                self._replace_source("skills", imported)
            except Exception as exc:
                self.source_errors["skills"] = type(exc).__name__
        return {name: len(records) for name, records in self._sources.items()}

    def _replace_source(self, name, records):
        with self._lock:
            self._sources[name] = records
            self.source_errors.pop(name, None)

    def register(self, procedure):
        """Explicit reviewed procedures only; data cannot replace imported IDs."""
        if not procedure.procedure_id.startswith("manual:"):
            raise ValueError("manual procedures require a manual: ID")
        with self._lock:
            self._manual[procedure.procedure_id] = copy.deepcopy(procedure)

    def procedures(self):
        with self._lock:
            return copy.deepcopy([p for source in self._sources.values() for p in source.values()] + list(self._manual.values()))

    def safe_grammar(self):
        phrases = {}
        for procedure in self.procedures():
            risk = risk_of(procedure, procedure.action_steps)
            threshold = 0.99 if risk == "R0" else 0.995
            if risk not in {"R0", "R1"} or (risk == "R1" and not procedure.reversible) or _score(procedure.confidence) < threshold:
                continue
            for phrase in procedure.trigger_examples:
                clean = normalize(phrase)
                if clean:
                    phrases.setdefault(clean, []).append(procedure.procedure_id)
        # Ambiguous phrases are excluded from recognizer grammar altogether.
        safe = {text: ids[0] for text, ids in phrases.items() if len(ids) == 1}
        actions = {p.procedure_id: asdict(p) for p in self.procedures() if p.procedure_id in safe.values()}
        version = _id("grammar:", json.dumps({"phrases": safe, "actions": actions}, sort_keys=True))
        return {"version": version, "phrases": safe}

    def match(self, text, *, partial=False, confidence=1.0, bindings=None):
        clean = (text or "").strip().lower()
        if not clean or len(clean) > 80:
            return None
        if re.search(r"\b(?:don't|do not|never|not|without)\b", clean):
            return None
        norm = normalize(clean)
        if partial:
            wanted = self.safe_grammar()["phrases"].get(norm)
            if wanted is None:
                return None
        else:
            wanted = None
        clean = _SPOKEN_VOLUME.get(norm, clean)
        with self._lock:
            # Preserve built-in follow-up behavior, but gate every replay anew.
            if not partial and re.fullmatch(r"(?:more|again|keep going|do it again|one more|repeat|same|yes|yep|yea|yeah)[\s!.]*", clean):
                return copy.deepcopy(self._last)
        # Known built-ins take precedence over fuzzy learned intent; no learned
        # pattern is allowed to hijack a known motor command.
        catalog = {p.procedure_id: p for p in self.procedures()}
        for pattern, name in self._patterns:
            found = pattern.search(clean)
            pid = "builtin:" + name
            if found and (wanted is None or wanted == pid):
                p = catalog[pid]
                return ProcedureMatch(p, _builtin_steps(name, clean, found, self._legacy),
                                      min(_score(confidence), _score(p.confidence)), clean)
        candidates = []
        tokens = set(norm.split())
        for p in catalog.values():
            if p.source == "builtin" or (wanted is not None and wanted != p.procedure_id):
                continue
            exact = norm in {normalize(t) for t in p.trigger_examples if t}
            required = {normalize(k) for k in p.required_keywords if k}
            if not exact and not (not partial and len(required) >= 2 and required <= tokens):
                continue
            try:
                steps = _resolved_steps(p, clean, bindings)
                _validate_steps(steps)
            except (ValueError, TypeError):
                continue
            candidates.append(ProcedureMatch(p, steps, min(_score(confidence), _score(p.confidence)), clean))
        return candidates[0] if len(candidates) == 1 else None

    def _emit(self, kind, payload):
        if self.emit is None:
            return False
        try:
            payload = copy.deepcopy(payload)
            payload["event_id"] = _id("procedure_event:", json.dumps([
                payload.get("trace_id"), payload.get("utterance_id"),
                payload.get("procedure_id"), kind]))
            return self.emit(kind, payload) is not False
        except Exception:
            return False  # an event failure must never replay a physical action

    def retry_feedback(self, *, trace_id, utterance_id):
        """Retry only retained feedback. Sinks deduplicate the stable event_id."""
        result = self.ledger.get(trace_id, utterance_id)
        if result is None or result.get("status") == "running":
            return result
        pending = result.get("feedback_pending", [])
        result["feedback_pending"] = [kind for kind in pending if not self._emit(kind, result)]
        result["feedback_delivered"] = not result["feedback_pending"]
        self.ledger.finish(trace_id, utterance_id, result)
        return result

    def execute(self, match, *, trace_id, utterance_id, partial=False, context=None):
        context = dict(context or {})
        if not trace_id or not utterance_id:
            raise ValueError("stable trace_id and utterance_id are required")
        prior = self.ledger.get(trace_id, utterance_id)
        if prior is not None:
            return {**prior, "duplicate": True}
        p = match.procedure
        risk = risk_of(p, match.steps)
        base = {"procedure_id": p.procedure_id, "trace_id": trace_id, "utterance_id": utterance_id,
                "recognized_intent": p.name, "parameters": [asdict(s) for s in match.steps],
                "expected_outcome": asdict(p.verification), "confidence": _score(match.confidence),
                "risk": risk, "partial": partial, "executed": False, "ok": False,
                "actual_outcome": [], "latency_ms": 0.0}
        if self.mode == "off":
            return {**base, "status": "off"}
        threshold = 0.99 if risk == "R0" else 0.995
        if partial and (risk not in {"R0", "R1"} or _score(match.confidence) < threshold
                        or (risk == "R1" and not p.reversible)
                        or not (context.get("wake_context") or context.get("always_on_authorized"))):
            return {**base, "status": "blocked", "reason": "partial command not eligible"}
        try:
            _validate_steps(match.steps)
            if p.verification.kind != "tool_ok" or p.verification.expected != {"ok": True}:
                raise ValueError("unsupported verification policy")
            if any(context.get(pred.key) != pred.equals for pred in p.preconditions):
                raise ValueError("precondition not satisfied")
        except (ValueError, TypeError) as exc:
            return {**base, "status": "blocked", "reason": str(exc)}
        if self.mode == "shadow":
            result = {**base, "status": "shadow"}
            self._emit("PROCEDURE_PREDICTED", result)
            return result
        # All steps must be authorized before the first side effect. Unknown
        # gate outputs and gate errors fail closed; R3 needs explicit confirmation.
        for step in match.steps:
            decision = GateDecision(allowed=risk in {"R0", "R1"})
            if self.action_gate is not None:
                try:
                    decision = self.action_gate(p, step, {**context, "risk": risk, "partial": partial})
                except Exception:
                    decision = GateDecision(reason="action gate failed")
            if not isinstance(decision, GateDecision) or not decision.allowed or (risk == "R3" and not decision.confirmed):
                return {**base, "status": "blocked", "reason": "existing action policy/confirmation required"}
        if self.dispatch is None or self.emit is None:
            return {**base, "status": "blocked", "reason": "dispatcher and feedback sink required"}
        running = {**base, "status": "running", "executed": True}
        claimed, previous = self.ledger.claim(trace_id, utterance_id, running)
        if not claimed:
            return {**previous, "duplicate": True}
        started, actual = self.clock(), []
        for index, step in enumerate(match.steps):
            try:
                reply = self.dispatch(step.tool, copy.deepcopy(step.args))
                ok = isinstance(reply, dict) and reply.get("ok") is True
                # Never copy screenshot/audio payloads or secret tool content into feedback.
                actual.append({"step": index, "tool": step.tool, "ok": ok,
                               "error": None if ok else "tool did not report success"})
            except Exception as exc:
                actual.append({"step": index, "tool": step.tool, "ok": False, "error": type(exc).__name__})
                ok = False
            if not ok:
                break
        success = len(actual) == len(match.steps) and all(r["ok"] for r in actual)
        result = {**base, "status": "completed" if success else "failed", "executed": True,
                  "ok": success, "actual_outcome": actual,
                  "latency_ms": max(0.0, (self.clock()-started)*1000),
                  "response": _reply(match) if success else "I tried that action, but could not verify success.",
                  "feedback_pending": ["REFLEX_RESULT", "TOOL_RESULT", "EFFERENCE_COPY"]}
        # Save before feedback: retries after delivery errors still cannot execute twice.
        self.ledger.finish(trace_id, utterance_id, result)
        result = self.retry_feedback(trace_id=trace_id, utterance_id=utterance_id)
        if success and p.source == "builtin":
            with self._lock:
                self._last = copy.deepcopy(match)
        return result

    def route(self, text, *, trace_id, utterance_id, partial=False, confidence=1.0, context=None, bindings=None):
        prior = self.ledger.get(trace_id, utterance_id)
        if prior is not None:
            return {**prior, "duplicate": True}
        match = self.match(text, partial=partial, confidence=confidence, bindings=bindings)
        return self.execute(match, trace_id=trace_id, utterance_id=utterance_id,
                            partial=partial, context=context) if match else None
