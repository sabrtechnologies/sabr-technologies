"""Pure private thought admission policy; runtime wiring is explicit."""
from dataclasses import dataclass
import hashlib
import json
import math
import re

from .thought_intent import ThoughtIntent


def _finite(value, low, high, *, inclusive_low=True):
    return (type(value) in (int, float) and math.isfinite(value)
            and (value >= low if inclusive_low else value > low) and value <= high)


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
        ensure_ascii=False, allow_nan=False).encode('utf-8')).hexdigest()


@dataclass(frozen=True)
class ThoughtArticulationPolicy:
    local_model: str
    min_urgency: float = .25
    deadline_s: float = 15.0
    max_output_tokens: int = 128
    max_output_bytes: int = 2048

    def __post_init__(self):
        if (type(self.local_model) is not str or len(self.local_model) > 128
                or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]*', self.local_model) is None
                or self.local_model.lower() == 'auto' or 'cloud' in self.local_model.lower()
                or ':' not in self.local_model
                or not _finite(self.min_urgency, 0, 1)
                or not _finite(self.deadline_s, 0, 15, inclusive_low=False)
                or type(self.max_output_tokens) is not int
                or not 1 <= self.max_output_tokens <= 256
                or type(self.max_output_bytes) is not int
                or not 1 <= self.max_output_bytes <= 8192):
            raise ValueError('bounded private thought admission policy required')


@dataclass(frozen=True)
class ThoughtAdmissionContext:
    """Trusted caller snapshot after durable readback; never request/model data.

    A pure decision does not confer execution authority. The captured runtime
    must recheck its owner, scheduler, live selection and deadline at dispatch.
    """
    thought_id: str
    snapshot_sha256: str
    current: bool
    foreground_busy: bool
    local_budget_available: bool
    now_wall: float
    expires_wall: float

    def __post_init__(self):
        if (not isinstance(self.thought_id, str) or not 1 <= len(self.thought_id) <= 200
                or not isinstance(self.snapshot_sha256, str)
                or len(self.snapshot_sha256) != 64
                or any(c not in '0123456789abcdef' for c in self.snapshot_sha256)
                or any(type(getattr(self, key)) is not bool for key in
                       ('current', 'foreground_busy', 'local_budget_available'))
                or not _finite(self.now_wall, 0, 1e12)
                or not _finite(self.expires_wall, 0, 1e12)):
            raise ValueError('explicit bounded trusted thought admission context required')


@dataclass(frozen=True)
class ThoughtDecision:
    kind: str
    reason: str
    priority: int = 30


def decide_thought(intent, *, context, policy):
    """No inference, state mutation, tools, generic routing or private telemetry."""
    if (type(intent) is not ThoughtIntent or type(context) is not ThoughtAdmissionContext
            or type(policy) is not ThoughtArticulationPolicy):
        raise TypeError('exact typed thought admission inputs required')
    intent = ThoughtIntent(**intent.to_dict())
    context.__post_init__(); policy.__post_init__()
    if (intent.privacy != 'private' or context.thought_id != intent.thought_id
            or context.snapshot_sha256 != _digest(intent.to_dict())):
        return ThoughtDecision('defer', 'snapshot_mismatch')
    if not context.current:
        return ThoughtDecision('defer', 'owner_unavailable')
    remaining = context.expires_wall - context.now_wall
    if remaining <= 0 or remaining > policy.deadline_s:
        return ThoughtDecision('defer', 'deadline_unavailable')
    if context.foreground_busy:
        return ThoughtDecision('defer', 'foreground_busy')
    if not context.local_budget_available:
        return ThoughtDecision('defer', 'budget_unavailable')
    if intent.urgency < policy.min_urgency:
        return ThoughtDecision('retain_nonverbal', 'low_urgency')
    return ThoughtDecision('realize_local', 'private_local_budget')
