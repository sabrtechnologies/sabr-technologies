"""
Leon V2 Phase 3: one inference scheduler (runbook section 7).

After cutover no dream, inner voice, user socket, wake thread, goal loop,
mission loop or business daemon owns the language model directly; they
submit :class:`InferenceRequest` objects and consume an
:class:`InferenceHandle`. Exactly one worker thread dispatches inference.
See docs/v2/phase3_scheduler.md for the design, the rollout gates and what
this phase deliberately leaves on the legacy path.

What this module provides
-------------------------
* ``InferenceKind`` / ``InferenceRequest`` / ``InferenceHandle`` (the 7.1 API).
* ``InferenceScheduler``: one worker, a priority heap (USER/VOICE 100,
  perception 80, active task 70, background 30, dream 10; FIFO within a
  priority), preemption of lower-priority work with a PREEMPTED record,
  monotonic deadlines (expired jobs are dropped, never retried), a bounded
  event queue per job, and no TTS (the consumer speaks sentence events on
  its own thread while the worker keeps streaming).
* ``LegacyLockBridge``: while some callers are still on the legacy path, the
  scheduler holds the legacy ``_responder_lock`` on behalf of the job it is
  running, and admits user turns through the same newest-message-wins
  ``UserTurnGate`` the legacy paths use, so migrated and unmigrated callers
  stay mutually exclusive and supersession stays one ledger.
* Routing (live flags ``inference_scheduler.user`` / ``.voice`` / ``.inner_voice``, default off)
  and the SHADOW facade the responder and ``local_llm`` report tickets to
  (live flag ``inference_scheduler``, default off).

Safety rules
------------
* Every public entry point used from a legacy call site is fail-open: it
  returns None (use the legacy path) instead of raising.
* A foreground job is never dropped by the scheduler: when the worker cannot
  admit it (stopped, dead, internal error) the caller gets ``fallback`` and
  runs the unchanged legacy path with the same gate registration.
* Providers own cancellation and the drain boundary for dispatched tools.
  Results reach attached consumers; detached or stalled consumers have bounded
  retention with explicit delivery-loss counts, never silent action replay.
* No user text is logged or recorded here: records carry kinds, sites,
  channels, timings and outcomes only.

Import side effects: none (no threads, no files, no flag reads).
"""
from __future__ import annotations

import heapq
import itertools
import math
import os
import queue
import sys
import threading
import time
import uuid
from collections import deque
from contextlib import nullcontext
from dataclasses import dataclass, field
from enum import Enum
from types import SimpleNamespace
from typing import Any, Callable, Deque, Dict, Iterator, List, Optional, Tuple

from brain.inference_cancel import CancelToken, call_with_cancel, UnsupportedInferencePolicy

from .inference_shadow import SIDECAR_DEFAULT, SIDECAR_ENV, ShadowLedger, ShadowTicket

__all__ = [
    "InferenceKind", "InferenceRequest", "InferenceHandle", "InferenceScheduler",
    "LegacyLockBridge", "SchedulerUnavailable", "UnsupportedInferencePolicy", "InferenceDeliveryError",
    "PRIORITY", "FOREGROUND_PRIORITY",
    "make_request", "route", "submit_foreground", "foreground_allow_tools",
    "shadow_call_begin", "slot_begin",
    "slot_end", "get_scheduler", "get_ledger", "install", "uninstall", "stats",
    "build_for_server_state", "SITE_TABLE", "LIVE_FEATURE", "GROUP_FEATURES",
]


class InferenceKind(str, Enum):
    USER = "user"
    VOICE = "voice"
    ACTIVE_TASK = "active_task"
    PERCEPTION = "perception"
    BACKGROUND = "background"
    DREAM = "dream"

    def __str__(self) -> str:
        return self.value


PRIORITY: Dict[InferenceKind, int] = {
    InferenceKind.USER: 100,
    InferenceKind.VOICE: 100,
    InferenceKind.PERCEPTION: 80,
    InferenceKind.ACTIVE_TASK: 70,
    InferenceKind.BACKGROUND: 30,
    InferenceKind.DREAM: 10,
}
FOREGROUND_PRIORITY = 100

#: Terminal outcomes of a job (strings so records serialize as-is).
COMPLETED = "completed"          # the provider ran to its end
FAILED = "failed"                # the provider raised; re-raised in the consumer
PREEMPTED = "preempted"          # a higher-priority job took the slot
CANCELLED = "cancelled"          # handle.cancel()/close() (Stop, consumer left)
EXPIRED = "expired"              # monotonic deadline passed (dropped, not retried)
SUPERSEDED = "superseded"        # a newer user message will answer this text
ANSWERED = "answered"            # a prior winner already answered this text
TIMEOUT = "timeout"              # admission ceiling (a genuine wedge)
FALLBACK = "fallback"            # the scheduler could not admit; caller goes legacy
REJECTED = "rejected"            # background queue full
STOPPED = "stopped"              # scheduler stopped
CONSUMER_GONE = "consumer_gone"  # nobody drained the event queue for too long

_REASON_OUTCOME = {"preempted": PREEMPTED, "deadline": EXPIRED, "stopping": STOPPED,
                   "consumer_gone": CONSUMER_GONE}

LIVE_FEATURE = "inference_scheduler"
GROUP_FEATURES = {"user": "inference_scheduler.user", "voice": "inference_scheduler.voice",
                  "inner_voice": "inference_scheduler.inner_voice",
                  "routines": "inference_scheduler.routines",
                  "goal_pursuit": "inference_scheduler.goal_pursuit",
                  "proactive": "inference_scheduler.proactive",
                  "mission": "inference_scheduler.mission",
                  "upgrade_awareness": "inference_scheduler.upgrade_awareness",
                  "perception_greet": "inference_scheduler.perception_greet",
                  "dreaming": "inference_scheduler.dreaming",
                  "conversation": "inference_scheduler.conversation",
                  "spontaneous_speech": "inference_scheduler.spontaneous_speech"}

_END = object()
_WORKER = threading.local()


def in_worker_context() -> bool:
    """Whether this thread is the scheduler's provider worker.

    Adapters must also match their admitted request/token; this marker is not
    authorization for an arbitrary action or another request's model call.
    """
    return bool(getattr(_WORKER, "in_worker", False))


class SchedulerUnavailable(RuntimeError):
    """submit() refused: the scheduler is not running."""


class InferenceDeliveryError(RuntimeError):
    """A detached consumer exceeded bounded result retention; never retry tools."""


def priority_of(kind: Any) -> int:
    return PRIORITY[InferenceKind(kind)]


@dataclass
class InferenceRequest:
    request_id: str
    trace_id: str
    kind: InferenceKind
    priority: int
    prompt: str = field(repr=False)
    brain_state: dict = field(repr=False)
    responder_kwargs: dict = field(repr=False)
    created_mono: float
    deadline_mono: Optional[float]
    allow_tools: bool
    persist_history: bool
    can_preempt: bool
    #: provider interrupt channel: "user" (foreground) or "daemon" (background)
    channel: str
    # ── Phase 3 extensions (see docs/v2/phase3_scheduler.md) ──
    site: str = ""
    group: str = ""
    #: "direct" (no legacy lock), "user_gate" (newest-wins gate + legacy lock),
    #: "exclusive" (wake wait with preemption), "background" (bounded wait,
    #: no foreground levers or user gate)
    admission: str = "direct"
    admission_timeout_s: Optional[float] = None
    #: prepare(texts) -> (prompt, responder_kwargs), called by the worker after
    #: a user_gate admission merged every pending text into one turn
    prepare: Optional[Callable[[List[str]], Tuple[str, dict]]] = field(default=None, repr=False)
    #: provider(request, prompt, kwargs, cancel_token) -> iterator of events
    provider: Optional[Callable[..., Iterator[Any]]] = field(default=None, repr=False)
    received_ts: Optional[float] = None


def make_request(kind: Any, prompt: str, brain_state: Optional[dict] = None, *,
                 responder_kwargs: Optional[dict] = None, channel: Optional[str] = None,
                 site: str = "", group: str = "", deadline_s: Optional[float] = None,
                 allow_tools: bool = True, persist_history: bool = False,
                 can_preempt: Optional[bool] = None, admission: str = "direct",
                 admission_timeout_s: Optional[float] = None,
                 prepare: Optional[Callable[[List[str]], Tuple[str, dict]]] = None,
                 provider: Optional[Callable[..., Iterator[Any]]] = None,
                 trace_id: Optional[str] = None, received_ts: Optional[float] = None,
                 clock: Callable[[], float] = time.monotonic) -> InferenceRequest:
    k = InferenceKind(kind)
    pr = PRIORITY[k]
    now = clock()
    if admission not in ("direct", "user_gate", "exclusive", "background"):
        raise ValueError(f"unknown admission {admission!r}")
    return InferenceRequest(
        request_id=uuid.uuid4().hex[:16], trace_id=trace_id or uuid.uuid4().hex[:16],
        kind=k, priority=pr, prompt=prompt, brain_state=brain_state if brain_state is not None else {},
        responder_kwargs=dict(responder_kwargs or {}), created_mono=now,
        deadline_mono=(now + float(deadline_s)) if deadline_s is not None else None,
        allow_tools=bool(allow_tools), persist_history=bool(persist_history),
        can_preempt=(pr >= FOREGROUND_PRIORITY) if can_preempt is None else bool(can_preempt),
        channel=channel or ("user" if pr >= FOREGROUND_PRIORITY else "daemon"),
        site=site, group=group, admission=admission, admission_timeout_s=admission_timeout_s,
        prepare=prepare, provider=provider, received_ts=received_ts)


@dataclass(frozen=True)
class _ResponderCapture:
    responder: Any
    authority: Any


class _Job:
    __slots__ = ("provider_callback", "responder_capture", "provider_submission", "req", "seq", "token", "events", "mu", "state", "outcome", "exc",
                 "admission", "admitted", "finished", "notify_pending", "notified",
                 "gate", "gate_id", "bridge_lock", "started_mono", "ended_mono",
                 "preempted_by", "n_events", "saw_done", "delivered_done", "model_used", "created_wall",
                 "consumer_closed", "delivery_abandoned", "undelivered_tool_results")

    def __init__(self, req: InferenceRequest, seq: int, events_max: int) -> None:
        self.req, self.seq = req, seq
        self.provider_callback = None
        self.responder_capture = None
        self.provider_submission = None  # Trusted provider capture, never request kwargs.
        self.token = CancelToken()
        self.events: "queue.Queue[Any]" = queue.Queue(maxsize=events_max)
        self.mu = threading.Lock()
        self.state = "queued"             # queued -> admitting -> running -> done
        self.outcome: Optional[str] = None
        self.exc: Optional[BaseException] = None
        self.admission: Optional[Tuple[str, List[str], float]] = None
        self.admitted = threading.Event()
        self.finished = threading.Event()
        self.notify_pending = threading.Event()
        self.notified = False
        self.gate: Any = None
        self.gate_id: Optional[int] = None
        self.bridge_lock: Any = None
        self.started_mono: Optional[float] = None
        self.ended_mono: Optional[float] = None
        self.preempted_by: Optional[str] = None
        self.n_events = 0
        self.saw_done = False
        self.delivered_done = False
        self.model_used = False
        self.created_wall = time.time()
        self.consumer_closed = threading.Event()
        self.delivery_abandoned = False
        self.undelivered_tool_results = 0

    def __lt__(self, other: "_Job") -> bool:     # heap tiebreak safety
        return self.seq < other.seq


class InferenceHandle:
    """What a caller holds for one submitted job."""

    def __init__(self, sched: "InferenceScheduler", job: _Job) -> None:
        self._s, self._job = sched, job

    @property
    def request_id(self) -> str:
        return self._job.req.request_id

    @property
    def gate_id(self) -> Optional[int]:
        return self._job.gate_id

    @property
    def outcome(self) -> Optional[str]:
        return self._job.outcome

    def done(self) -> bool:
        return self._job.finished.is_set()

    def cancel(self, reason: str = "cancelled") -> None:
        self._s._cancel(self._job, reason)

    def close(self) -> None:
        """The consumer is finished with this job (idempotent)."""
        if not self._job.finished.is_set():
            self._job.consumer_closed.set()
            self._s._cancel(self._job, "consumer_closed")

    def wait_admission(self, notify: Optional[Callable[[], None]] = None, *,
                       ceiling: float = 3600.0, notify_after: float = 12.0,
                       poll_s: float = 0.1) -> Tuple[str, List[str], float]:
        """Block until the job is admitted or ends before admission.

        Returns ``(status, texts, waited)`` with the same statuses as
        ``server.turn_priority.acquire_user_turn`` (go / superseded /
        answered / timeout) plus ``fallback`` (run the legacy path, reusing
        ``gate_id``) and ``cancelled``. While the job is still queued behind
        other scheduler work, supersession, the wait note and the ceiling are
        handled here, exactly as a legacy waiter handles them.
        """
        job = self._job
        while True:
            if job.admitted.wait(poll_s):
                break
            if job.notify_pending.is_set():
                job.notify_pending.clear()
                if notify is not None:
                    try:
                        notify()
                    except Exception as exc:
                        print(f"[SCHED] wait notify failed exc={type(exc).__name__}", flush=True)
            with job.mu:
                queued = job.state == "queued"
            if not queued:
                continue
            waited = self._s._clock() - job.req.created_mono
            gate = job.gate
            try:
                sup = gate is not None and job.gate_id is not None and gate.superseded(job.gate_id)
            except Exception:
                sup = False
            if sup and self._s._finish_queued(job, SUPERSEDED):
                break
            if not self._s.worker_alive() and self._s._finish_queued(job, FALLBACK):
                break
            if waited >= ceiling and self._s._finish_queued(job, TIMEOUT):
                break
            if notify is not None and waited >= notify_after:
                with job.mu:
                    fire = not job.notified
                    job.notified = True
                if fire:
                    try:
                        allow = gate.allow_note() if gate is not None else True
                    except Exception:
                        allow = True
                    if allow:
                        try:
                            notify()
                        except Exception as exc:
                            print(f"[SCHED] wait notify failed exc={type(exc).__name__}",
                                  flush=True)
        status, texts, waited = job.admission or (job.outcome or FALLBACK, [], 0.0)
        if status not in ("go", SUPERSEDED, ANSWERED, TIMEOUT, CANCELLED, EXPIRED,
                          PREEMPTED):
            # Infrastructure failure permits legacy retry. An intentional
            # cancellation or deadline must never resurrect the same turn.
            status, texts = (CANCELLED if job.provider_submission is not None else FALLBACK), []
        return status, list(texts), waited

    def iter_events(self, poll_s: float = 0.5) -> Iterator[Any]:
        """Provider events in order. Ends when the job ends; re-raises a
        provider exception in the consumer's thread. Raises InferenceDeliveryError
        if a detached/stalled consumer exhausted bounded tool-result retention.
        This is delivery failure, not permission to re-execute an action."""
        job = self._job

        def deliver(item: Any) -> bool:
            # Cancellation revokes buffered speech as well as future provider
            # events. A dispatched tool's completed result remains observable.
            # Completed jobs cannot be retroactively cancelled.
            kind = getattr(item, "type", None)
            if job.token.is_set() and job.outcome != COMPLETED and kind != "tool_result":
                return False
            if kind == "done":
                job.delivered_done = True
            return True

        while True:
            try:
                item = job.events.get(timeout=poll_s)
            except queue.Empty:
                if job.finished.is_set():
                    try:
                        while True:
                            item = job.events.get_nowait()
                            if item is _END:
                                break
                            if deliver(item):
                                yield item
                    except queue.Empty:
                        pass
                    break
                if not self._s.worker_alive():
                    raise SchedulerUnavailable("inference scheduler worker is not running")
                continue
            if item is _END:
                break
            if deliver(item):
                yield item
        if job.exc is not None:
            raise job.exc
        if job.undelivered_tool_results:
            raise InferenceDeliveryError(
                f"{job.undelivered_tool_results} tool results exceeded bounded delivery retention; "
                "execution was drained, do not replay actions")

    def record(self) -> Dict[str, Any]:
        return self._s._record(self._job)


class _DeadlineWatch:
    """Interrupt this job even when its provider is blocked between events.

    The callback owns only the job's token. Closing it prevents rearming; a
    racing callback can never interrupt a later request's transport.
    """
    def __init__(self, deadline, token, clock):
        self.deadline, self.token, self.clock = deadline, token, clock
        self.lock = threading.Lock()
        self.closed = False
        self.timer = None
        if deadline is not None:
            self._tick()

    def _tick(self):
        with self.lock:
            if self.closed:
                return
            remaining = self.deadline - self.clock()
            if remaining > 0:
                self.timer = threading.Timer(remaining, self._tick)
                self.timer.daemon = True
                self.timer.start()
                return
            self.closed = True
        self.token.cancel("deadline")

    def close(self):
        with self.lock:
            self.closed = True
            if self.timer is not None:
                self.timer.cancel()


class InferenceScheduler:
    """One worker, one priority heap, one active job at a time."""

    def __init__(self, *, provider: Optional[Callable[..., Iterator[Any]]] = None,
                 interrupt: Optional[Callable[[str, str], Any]] = None,
                 bridge: Optional["LegacyLockBridge"] = None,
                 clock: Callable[[], float] = time.monotonic,
                 event_queue_max: int = 4096, max_queued_background: int = 64,
                 max_queued_foreground: int = 64,
                 consumer_stall_s: float = 300.0, ring: int = 256,
                 on_record: Optional[Callable[[Dict[str, Any]], Any]] = None,
                 name: str = "v2-inference-scheduler") -> None:
        self._provider = provider
        self._interrupt = interrupt
        self._bridge = bridge
        self._clock = clock
        self._events_max = int(event_queue_max)
        self._max_bg = int(max_queued_background)
        self._max_fg = int(max_queued_foreground)
        self._stall_s = float(consumer_stall_s)
        if self._events_max <= 0 or self._max_bg < 0 or self._max_fg < 0:
            raise ValueError("event queue must be positive; admission limits cannot be negative")
        if not math.isfinite(self._stall_s) or self._stall_s <= 0:
            raise ValueError("consumer_stall_s must be finite and positive")
        self._on_record = on_record
        self._name = name
        self._cv = threading.Condition(threading.Lock())
        # A channel-wide interrupt must finish before the worker can dispatch
        # a successor on that channel. Cancellation callbacks may inspect stats,
        # so they cannot safely run while _cv is held.
        self._dispatch_lock = threading.Lock()
        self._heap: List[Tuple[int, int, _Job]] = []
        self._seq = itertools.count(1)
        self._active: Optional[_Job] = None
        self._thread: Optional[threading.Thread] = None
        self._stopping = False
        self.records: Deque[Dict[str, Any]] = deque(maxlen=ring)
        self.preemptions: Deque[Dict[str, Any]] = deque(maxlen=ring)
        self.fg_waits: Deque[float] = deque(maxlen=512)
        self.counters: Dict[str, int] = {}

    # ── lifecycle ─────────────────────────────────────────────────────────
    def start(self) -> "InferenceScheduler":
        with self._cv:
            if self._thread is not None and self._thread.is_alive():
                return self
            self._stopping = False
            self._thread = threading.Thread(target=self._loop, daemon=True, name=self._name)
            self._thread.start()
        return self

    def alive(self) -> bool:
        """Accepting work (for submit and routing)."""
        return self.worker_alive() and not self._stopping

    def worker_alive(self) -> bool:
        """The worker thread exists (for consumers of already-admitted jobs)."""
        t = self._thread
        return t is not None and t.is_alive()

    def stop(self, join_timeout: float = 1.0) -> None:
        """Stop accepting work. Queued foreground jobs fall back to the legacy
        path; a RUNNING foreground job is never cut off (the worker exits
        after it); background work is cancelled."""
        with self._cv:
            self._stopping = True
            pending = [j for _, _, j in self._heap]
            self._heap.clear()
            active = self._active
            self._cv.notify_all()
        for j in pending:
            self._finish_queued(j, FALLBACK if j.req.priority >= FOREGROUND_PRIORITY else STOPPED)
        if active is not None and active.req.priority < FOREGROUND_PRIORITY:
            active.token.cancel("stopping")
        t = self._thread
        if t is not None and join_timeout > 0 and t is not threading.current_thread():
            t.join(join_timeout)

    def _count(self, name: str, n: int = 1) -> None:
        self.counters[name] = self.counters.get(name, 0) + n

    # ── submission ────────────────────────────────────────────────────────
    def submit(self, req: InferenceRequest) -> InferenceHandle:
        job = _Job(req, next(self._seq), self._events_max)
        provider = job.provider_callback = req.provider or self._provider
        capture = getattr(provider, "_capture_provider_submission", None)
        if capture is not None:
            job.responder_capture = capture(req)
            job.provider_submission = job.responder_capture.authority
        if not self.alive():
            if job.provider_submission is None:
                raise SchedulerUnavailable("inference scheduler is not running")
            self._finish_queued(job, CANCELLED)
            return InferenceHandle(self, job)
        if req.admission == "user_gate":
            try:
                if self._bridge is None:
                    raise SchedulerUnavailable("user_gate admission needs the legacy bridge")
                self._bridge.register(job)
            except Exception:
                if job.provider_submission is None:
                    raise
                # A failed register can have ambiguous effects; never replay it
                # through legacy admission for an explicitly selected provider.
                self._finish_queued(job, CANCELLED)
                return InferenceHandle(self, job)
        victim = None
        refusal = None
        with self._cv:
            if self._stopping:
                # Registered already: hand the caller a FALLBACK handle so the
                # legacy path reuses gate_id (a raise would register twice).
                refusal = FALLBACK if req.priority >= FOREGROUND_PRIORITY else STOPPED
            # Finished heap entries must not occupy capacity until the active
            # provider returns; reclaim them on every admission.
            self._heap = [e for e in self._heap if e[2].state == "queued"]
            heapq.heapify(self._heap)
            foreground = req.priority >= FOREGROUND_PRIORITY
            queued = sum(1 for _, _, j in self._heap
                         if (j.req.priority >= FOREGROUND_PRIORITY) == foreground)
            if refusal is None and queued >= (self._max_fg if foreground else self._max_bg):
                refusal = FALLBACK if foreground else REJECTED
                self._count("foreground_overflow" if foreground else "rejected")
            if refusal is None:
                heapq.heappush(self._heap, (-req.priority, job.seq, job))
                self._count("submitted")
                a = self._active
                if (a is not None and req.can_preempt and a.req.priority < req.priority
                        and a.state in ("queued", "admitting", "running") and not a.token.is_set()):
                    victim = a
                self._cv.notify()
        if refusal is not None:
            self._finish(job, refusal)
        if victim is not None:
            self._preempt(victim, req)
        return InferenceHandle(self, job)

    def _preempt(self, victim: _Job, by: InferenceRequest) -> None:
        with self._dispatch_lock:
            if self._active is not victim or victim.finished.is_set() or victim.token.is_set():
                return
            victim.preempted_by = by.request_id
            self._preempt_active(victim, by)

    def _preempt_active(self, victim: _Job, by: InferenceRequest) -> None:
        now = self._clock()
        rec = {"victim_kind": victim.req.kind.value, "victim_site": victim.req.site,
               "victim_group": victim.req.group,
               "ran_s": round(now - (victim.started_mono or now), 4),
               "victim_used_model": victim.model_used, "by_kind": by.kind.value,
               "by_site": by.site, "wall": time.time()}
        self.preemptions.append(rec)
        self._count("preemptions")
        victim.token.cancel("preempted")
        if self._interrupt is not None:
            try:
                self._interrupt(victim.req.channel, "preempted")
            except Exception:
                self._count("interrupt_failures")

    def _cancel(self, job: _Job, reason: str) -> None:
        if self._finish_queued(job, CANCELLED if reason != "stopping" else STOPPED):
            return
        with job.mu:
            if job.state == "done":
                return
        job.token.cancel(reason)

    # ── worker ────────────────────────────────────────────────────────────
    def _loop(self) -> None:
        _WORKER.in_worker = True
        while True:
            with self._cv:
                while not self._heap and not self._stopping:
                    self._cv.wait(1.0)
                if self._stopping:
                    return
                _, _, job = heapq.heappop(self._heap)
                self._active = job
            try:
                self._run_job(job)
            except BaseException as exc:          # the worker must survive anything
                self._count("worker_errors")
                print(f"[SCHED] worker error exc={type(exc).__name__} "
                      f"subsystem=v2.inference_scheduler recovery=job failed, worker continues",
                      flush=True)
                try:
                    if self._bridge is not None:
                        self._bridge.release(job)
                finally:
                    if not job.finished.is_set():
                        job.exc = job.exc or (exc if isinstance(exc, Exception) else None)
                        self._finish(job, FAILED if job.state == "running" else FALLBACK)
            finally:
                with self._dispatch_lock:
                    with self._cv:
                        self._active = None

    def _run_job(self, job: _Job) -> None:
        req = job.req
        with job.mu:
            if job.state != "queued":
                return                                  # finished by its caller while queued
            if job.token.is_set():
                job.state = "done"
                self._finalize(job, _REASON_OUTCOME.get(job.token.reason or "", CANCELLED))
                return
            if req.deadline_mono is not None and self._clock() >= req.deadline_mono:
                job.state = "done"
                self._count("expired")
                self._finalize(job, EXPIRED)
                return
            job.state = "admitting"
        texts: List[str] = [req.prompt]
        waited = 0.0
        if req.admission != "direct":
            if self._bridge is None:
                self._finish(job, FALLBACK)
                return
            try:
                status, texts, waited = self._bridge.admit(job, self._notifier(job))
            except Exception as exc:
                self._count("admission_errors")
                print(f"[SCHED] admission failed exc={type(exc).__name__} "
                      f"subsystem=v2.inference_scheduler recovery=legacy path (fallback)",
                      flush=True)
                self._bridge.release(job)
                status, texts, waited = FALLBACK, [], 0.0
            if status != "go":
                self._bridge.release(job)
                if job.token.is_set():
                    status = _REASON_OUTCOME.get(job.token.reason or "", CANCELLED)
                job.admission = (status, [], waited)
                self._count(f"admission.{status}")
                self._finish(job, status)
                return
        # The legacy lock may have taken minutes to arrive, or cancellation
        # may have raced with admission. Do not invoke even a non-generator
        # provider after its request has been cancelled or expired.
        if req.deadline_mono is not None and self._clock() >= req.deadline_mono:
            job.token.cancel("deadline")
        if job.token.is_set():
            if self._bridge is not None:
                self._bridge.release(job)
            self._finish(job, _REASON_OUTCOME.get(job.token.reason or "", CANCELLED))
            return
        prompt, kwargs = req.prompt, dict(req.responder_kwargs)
        if req.admission == "user_gate":
            merged = "\n".join(texts) if len(texts) > 1 else (texts[0] if texts else req.prompt)
            prompt = merged
            if req.prepare is not None:
                try:
                    prompt, kwargs = req.prepare(list(texts))
                except Exception as exc:
                    self._count("prepare_errors")
                    print(f"[SCHED] prepare failed exc={type(exc).__name__} "
                          f"recovery=merged text, request kwargs", flush=True)
                    prompt, kwargs = merged, dict(req.responder_kwargs)
        job.started_mono = self._clock()
        if req.priority >= FOREGROUND_PRIORITY:
            self.fg_waits.append(max(0.0, job.started_mono - req.created_mono))
        with job.mu:
            job.state = "running"
        job.admission = ("go", list(texts), waited)
        job.admitted.set()
        outcome = COMPLETED
        gen = None
        deadline_watch = _DeadlineWatch(req.deadline_mono, job.token, self._clock)
        previous_capture = getattr(_WORKER, "responder_capture", None)
        _WORKER.responder_capture = job.responder_capture
        try:
            if req.deadline_mono is not None and self._clock() >= req.deadline_mono:
                job.token.cancel("deadline")
            if job.token.is_set():
                outcome = _REASON_OUTCOME.get(job.token.reason or "", CANCELLED)
                return
            provider = job.provider_callback
            if provider is None:
                raise SchedulerUnavailable("no provider")
            gen = provider(req, prompt, kwargs, job.token)
            for ev in gen:
                et = getattr(ev, "type", None)
                if et == "model" and getattr(ev, "tier", None) != "reflex":
                    job.model_used = True
                if job.token.is_set() and et != "tool_result":
                    # The provider owns outstanding actions. Even status/speech
                    # events can arrive between their results; suppress these
                    # without closing a generator that still needs to drain.
                    continue
                if not self._push(job, ev):
                    continue
                if et == "done":
                    job.saw_done = True
                if job.token.is_set():
                    # A CLI turn can have several tools already dispatched.
                    # The provider owns their drain boundary and must stop
                    # dispatching new work; consume every remaining result
                    # before closing its iterator and releasing the slot.
                    continue
                if (req.deadline_mono is not None and not job.saw_done
                        and self._clock() >= req.deadline_mono):
                    job.token.cancel("deadline")
                    # Let the cancellation-aware provider finish an action it
                    # has already dispatched. Closing here skips its tool-result
                    # drain and can release the slot while the action still runs.
            if job.token.is_set() and not job.delivered_done:
                outcome = _REASON_OUTCOME.get(job.token.reason or "", CANCELLED)
        except Exception as exc:
            if job.token.is_set() and not job.delivered_done:
                # Closing a cancelled transport often raises from its read.
                # That is the requested terminal outcome, not a provider fault.
                outcome = _REASON_OUTCOME.get(job.token.reason or "", CANCELLED)
            else:
                job.exc = exc
                outcome = FAILED
                self._count("provider_errors")
        finally:
            try:
                deadline_watch.close()
                if gen is not None:
                    try:
                        gen.close()                    # closes the local HTTP stream
                    except Exception:
                        pass
            finally:
                _WORKER.responder_capture = previous_capture
            if self._bridge is not None:
                self._bridge.release(job)
            self._finish(job, outcome)

    def _notifier(self, job: _Job) -> Optional[Callable[[], None]]:
        def notify() -> None:
            with job.mu:
                if job.notified:
                    return
                job.notified = True
            job.notify_pending.set()
        return notify

    def _push(self, job: _Job, ev: Any) -> bool:
        blocked = self._clock()
        is_result = getattr(ev, "type", None) == "tool_result"
        while True:
            detached = job.consumer_closed.is_set() or job.delivery_abandoned
            if (detached or job.token.is_set()) and not is_result:
                return False
            try:
                if detached:
                    # Preserve as many late results as fit without waiting for
                    # a UI which explicitly left. Never grow an unbounded spool.
                    job.events.put_nowait(ev)
                else:
                    job.events.put(ev, timeout=min(0.05, self._stall_s))
                job.n_events += 1
                return True
            except queue.Full:
                if detached:
                    job.undelivered_tool_results += 1
                    self._count("undelivered_tool_results")
                    return False
                now = self._clock()
                if now - blocked >= self._stall_s:
                    self._count("consumer_gone")
                    job.delivery_abandoned = True
                    job.token.cancel("consumer_gone")
                    # Continue provider consumption even when delivery has
                    # failed. Releasing the slot here can strand running tools.

    # ── completion ────────────────────────────────────────────────────────
    def _finish_queued(self, job: _Job, outcome: str) -> bool:
        """End a job that has not been picked up by the worker. True if it was."""
        with job.mu:
            if job.state != "queued":
                return False
            job.state = "done"
        job.token.cancel(outcome)
        self._finalize(job, outcome)
        return True

    def _finish(self, job: _Job, outcome: str) -> None:
        with job.mu:
            if job.finished.is_set():
                return
            job.state = "done"
        if outcome == COMPLETED and job.token.is_set() and not job.delivered_done:
            outcome = _REASON_OUTCOME.get(job.token.reason or "", CANCELLED)
        self._finalize(job, outcome)

    def _finalize(self, job: _Job, outcome: str) -> None:
        if job.finished.is_set():
            return
        if outcome == FALLBACK and job.provider_submission is not None:
            outcome = CANCELLED
            waited = job.admission[2] if job.admission is not None else 0.0
            job.admission = (CANCELLED, [], waited)
        job.outcome = outcome
        job.ended_mono = self._clock()
        if job.admission is None:
            job.admission = (outcome, [], 0.0)
        job.finished.set()
        job.admitted.set()
        try:
            job.events.put_nowait(_END)
        except queue.Full:
            pass                                   # iter_events also watches `finished`
        self._count(f"outcome.{outcome}")
        rec = self._record(job)
        self.records.append(rec)
        if self._on_record is not None:
            try:
                self._on_record(rec)
            except Exception:
                self._count("record_hook_failures")

    def _record(self, job: _Job) -> Dict[str, Any]:
        req = job.req
        start, end = job.started_mono, job.ended_mono
        return {"request_id": req.request_id, "trace_id": req.trace_id, "kind": req.kind.value,
                "priority": req.priority, "site": req.site, "group": req.group,
                "channel": req.channel, "admission": req.admission, "outcome": job.outcome,
                "created_mono": req.created_mono, "started_mono": start, "ended_mono": end,
                "wait_s": round(start - req.created_mono, 4) if start is not None else None,
                "run_s": round(end - start, 4) if (start is not None and end is not None) else None,
                "events": job.n_events, "model_used": job.model_used,
                "consumer_closed": job.consumer_closed.is_set(),
                "delivery_abandoned": job.delivery_abandoned,
                "undelivered_tool_results": job.undelivered_tool_results,
                "preempted_by": job.preempted_by, "created_wall": job.created_wall}

    # ── introspection ─────────────────────────────────────────────────────
    def stats(self) -> Dict[str, Any]:
        with self._cv:
            a = self._active
            queued = [(j.req.kind.value, j.req.priority) for _, _, j in self._heap
                      if j.state == "queued"]
        waits = list(self.fg_waits)
        return {
            "alive": self.alive(), "queued": len(queued),
            "queued_by_kind": {k: sum(1 for kk, _ in queued if kk == k) for k, _ in queued},
            "active": None if a is None else {
                "kind": a.req.kind.value, "site": a.req.site, "state": a.state,
                "running_s": round(self._clock() - a.started_mono, 3) if a.started_mono else None},
            "counters": dict(self.counters),
            "fg_wait": ({"n": len(waits), "p50_s": round(_pct(waits, 50), 4),
                         "p95_s": round(_pct(waits, 95), 4), "max_s": round(max(waits), 4)}
                        if waits else {"n": 0}),
            "preemptions": len(self.preemptions),
        }


def _pct(values: List[float], q: float) -> float:
    s = sorted(values)
    return s[max(0, min(len(s) - 1, math.ceil(q / 100.0 * len(s)) - 1))]


# ── bridge to the legacy lock and newest-wins gate ────────────────────────────

class _Levers:
    """What a scheduled foreground job pulls while it waits for the legacy
    lock: the legacy ``preempt_daemon()`` (daemon CLI session + the
    "user waiting" flag) plus ``interrupt_channel("daemon")``, which cancels
    an in-flight local background generation and closes its HTTP stream."""

    def __init__(self, responder: Any, interrupt: Optional[Callable[[str, str], Any]]) -> None:
        self._r, self._interrupt = responder, interrupt

    def preempt_daemon(self) -> bool:
        ok = False
        fn = getattr(self._r, "preempt_daemon", None)
        if callable(fn):
            ok = bool(fn())
        if self._interrupt is not None:
            try:
                self._interrupt("daemon", "preempted")
            except Exception:
                pass
        return ok

    def preempt_satisfied(self) -> None:
        fn = getattr(self._r, "preempt_satisfied", None)
        if callable(fn):
            fn()


class LegacyLockBridge:
    """Admission for scheduled foreground jobs while unmigrated callers still
    take ``_responder_lock``. The scheduler holds that lock for the whole run
    of a user_gate/exclusive job, so a legacy background holder and a
    scheduled user turn can never use the model at the same time."""

    def __init__(self, *, lock_fn: Callable[[], Any], responder_fn: Callable[[], Any],
                 tp_fn: Callable[[], Any],
                 interrupt: Optional[Callable[[str, str], Any]] = None,
                 clock: Callable[[], float] = time.monotonic, slice_s: float = 0.25) -> None:
        self._lock_fn, self._responder_fn, self._tp_fn = lock_fn, responder_fn, tp_fn
        self._interrupt = interrupt
        self._clock = clock
        self._slice = slice_s

    def register(self, job: _Job) -> None:
        """Caller thread, at submit: the text joins the one newest-wins ledger."""
        tp = self._tp_fn()
        gate = getattr(tp, "USER_TURN_GATE", None)
        if gate is None:
            raise SchedulerUnavailable("server.turn_priority is not loaded")
        job.gate = gate
        job.gate_id = gate.register(job.req.prompt)

    def has_pending(self) -> bool:
        """An earlier user text is still unclaimed, so the next admitted turn
        answers it too (newest-wins merge). Unknown counts as pending."""
        gate = getattr(self._tp_fn(), "USER_TURN_GATE", None)
        probe = getattr(gate, "has_pending", None)
        return True if probe is None else bool(probe())

    def admit(self, job: _Job, notify: Optional[Callable[[], None]]) -> Tuple[str, List[str], float]:
        lock = self._lock_fn()
        responder = self._responder_fn()
        if job.req.admission == "background":
            # Background work must never pull foreground preemption levers or
            # add synthetic prompts to the user's newest-turn gate. Wait only
            # for its own small admission budget, yielding if a user arrives.
            if lock is None:
                raise SchedulerUnavailable("background admission requires the legacy lock")
            t0 = self._clock()
            budget = job.req.admission_timeout_s
            budget = 1.0 if budget is None else max(0.0, float(budget))
            while True:
                waited = self._clock() - t0
                if job.token.is_set():
                    return "cancelled", [], waited
                if job.req.deadline_mono is not None and self._clock() >= job.req.deadline_mono:
                    job.token.cancel("deadline")
                    return "expired", [], waited
                if lock.acquire(blocking=False):
                    job.bridge_lock = lock
                    return "go", [job.req.prompt], waited
                if waited >= budget:
                    return "timeout", [], waited
                job.token.wait(min(self._slice, budget - waited))
        if job.req.admission == "user_gate":
            tp = self._tp_fn()
            acquire = getattr(tp, "acquire_user_turn", None)
            if lock is None or acquire is None or job.gate_id is None:
                raise SchedulerUnavailable("legacy admission is not available")
            status, texts, waited = acquire(
                lock, _Levers(responder, self._interrupt), job.req.prompt, gate=job.gate,
                registered_id=job.gate_id, notify=notify, should_stop=job.token.is_set)
            if status == "go":
                job.bridge_lock = lock
            return status, list(texts), waited
        # exclusive: the wake orchestrator's plain wait, now with the levers
        if lock is None:
            return "go", [job.req.prompt], 0.0
        t0 = self._clock()
        if lock.acquire(blocking=False):
            job.bridge_lock = lock
            return "go", [job.req.prompt], 0.0
        levers = _Levers(responder, self._interrupt)
        try:
            levers.preempt_daemon()
        except Exception:
            pass
        timeout = float(job.req.admission_timeout_s or 30.0)
        try:
            while True:
                waited = self._clock() - t0
                if job.token.is_set():
                    return "cancelled", [], waited
                remaining = timeout - waited
                if remaining <= 0:
                    return "timeout", [], waited
                if lock.acquire(timeout=min(self._slice, remaining)):
                    job.bridge_lock = lock
                    return "go", [job.req.prompt], self._clock() - t0
        finally:
            try:
                levers.preempt_satisfied()
            except Exception:
                pass

    def release(self, job: _Job) -> None:
        lk, job.bridge_lock = job.bridge_lock, None
        if lk is not None:
            try:
                lk.release()
            except RuntimeError:
                pass


# ── module state, routing and the shadow facade ───────────────────────────────

_STATE: Dict[str, Any] = {"scheduler": None, "ledger": None,
                          "is_active": None, "live_mode": None}
_LIFECYCLE = threading.RLock()
_WARNED: Dict[str, float] = {}


def _warn(key: str, msg: str) -> None:
    now = time.monotonic()
    if now - _WARNED.get(key, -1e9) >= 300.0:
        _WARNED[key] = now
        print(f"[SCHED] {msg}", flush=True)


def install(scheduler: Optional[InferenceScheduler], ledger: Optional[ShadowLedger], *,
            live_mode_fn: Optional[Callable[[str], str]] = None,
            is_active_fn: Optional[Callable[..., bool]] = None) -> None:
    with _LIFECYCLE:
        replacing = (_STATE.get("scheduler") is not scheduler or _STATE.get("ledger") is not ledger)
        if replacing and not uninstall(join_timeout=0.25):
            raise SchedulerUnavailable("previous inference scheduler or ledger is still draining")
        _STATE.update(scheduler=scheduler, ledger=ledger, live_mode=live_mode_fn,
                      is_active=is_active_fn)


def uninstall(join_timeout: float = 1.0) -> bool:
    """Disable routing and retire in order; False means retirement is pending.

    Retain ownership while a foreground turn/tool drains. Its ledger must
    remain alive to receive the final job record. A later bounded retry can
    finish retirement; never kill tools or silently replace a live worker.
    """
    with _LIFECYCLE:
        sched, led = _STATE.get("scheduler"), _STATE.get("ledger")
        _STATE.update(live_mode=None, is_active=None)
        try:
            if sched is not None:
                sched.stop(join_timeout=join_timeout)
                if sched.worker_alive():
                    return False
            if led is not None:
                led.stop(join_timeout=join_timeout)
                if led.alive():
                    return False
        except Exception as exc:
            _warn("retire", f"retirement failed exc={type(exc).__name__} recovery=retain ownership")
            return False
        _STATE.update(scheduler=None, ledger=None)
        return True


def get_scheduler() -> Optional[InferenceScheduler]:
    return _STATE.get("scheduler")


def get_ledger() -> Optional[ShadowLedger]:
    return _STATE.get("ledger")


def route(group: str, *, channel: Optional[str] = None,
          key: Optional[str] = None) -> Optional[InferenceScheduler]:
    """The scheduler when this group's turn should go through it (ON or a
    selected CANARY), else None (legacy). Never raises.

    The master flag ``inference_scheduler`` = off is the kill switch for
    every group; otherwise only ``inference_scheduler.<group>`` decides."""
    try:
        sched = _STATE.get("scheduler")
        live_mode, is_active = _STATE.get("live_mode"), _STATE.get("is_active")
        if sched is None:
            return None
        required = getattr(getattr(sched, "_provider", None), "_requires_provider_admission", None)
        selected = bool(required(group, channel)) if required is not None else False
        if live_mode is None or is_active is None:
            return sched if selected else None  # Retiring selected routes receive terminal handles.
        if not sched.alive() and not selected:
            return None
        feat = GROUP_FEATURES.get(group)
        if feat is None or live_mode(LIVE_FEATURE) == "off":
            return None
        return sched if is_active(feat, channel=channel, key=key) else None
    except Exception as exc:
        _warn("route", f"route failed exc={type(exc).__name__} recovery=legacy path")
        return None


def submit_foreground(sched: InferenceScheduler, *, kind: str, text: str,
                      brain_state: Optional[dict], admission: str,
                      prepare: Optional[Callable[[List[str]], Tuple[str, dict]]] = None,
                      responder_kwargs: Optional[dict] = None, site: str = "",
                      group: str = "", received_ts: Optional[float] = None,
                      admission_timeout_s: Optional[float] = None,
                      allow_tools: bool = True) -> Optional[InferenceHandle]:
    """Submit a USER/VOICE turn. None means "use the legacy path". Never raises.

    allow_tools=True is the unchanged legacy request. A consumer passes False
    only with the answer of foreground_allow_tools() for this exact turn."""
    try:
        req = make_request(kind, text, brain_state, responder_kwargs=responder_kwargs,
                           channel="user", site=site, group=group, admission=admission,
                           admission_timeout_s=admission_timeout_s, prepare=prepare,
                           received_ts=received_ts, allow_tools=allow_tools,
                           persist_history=bool((responder_kwargs or {}).get("persist_history", 1)))
        return sched.submit(req)
    except Exception as exc:
        _warn("submit", f"submit failed exc={type(exc).__name__} "
                        f"subsystem=v2.inference_scheduler recovery=legacy path")
        return None


def foreground_allow_tools(sched: Any, text: str, *, site: str, group: str,
                           admission: str = "user_gate") -> bool:
    """Tool policy for one foreground turn; True is the unchanged legacy request.

    False only when the provider attached to this scheduler's responder would
    select this exact scope for a no-tools request right now, the text is a
    plain conversation turn, and newest-wins admission has no older pending
    text to merge into it. No attached provider, provider off/shadow, an
    unrouted scope, a tool/command/reflex/override turn, an unavailable
    provider, any exception and any doubt all answer True. Never raises."""
    try:
        probe = getattr(getattr(sched, "_provider", None), "_selects_plain_turn", None)
        if probe is None or probe(text, site, group, "user") is not True:
            return True
        if admission == "user_gate":
            pending = getattr(getattr(sched, "_bridge", None), "has_pending", None)
            if pending is not None and pending() is not False:
                return True
        return False
    except Exception:
        return True


#: Every production respond_streaming call site, by (file, enclosing function):
#: its scheduler kind and migration group. tests/test_respond_streaming_call_sites.py
#: keeps this table and the code in step.
SITE_TABLE: Dict[Tuple[str, str], Tuple[InferenceKind, str]] = {
    ("server/routers/websocket.py", "_respond_async"): (InferenceKind.USER, "user"),
    ("server/helpers.py", "handle_voice_utterance"): (InferenceKind.VOICE, "voice"),
    ("brain/voice/wake_orchestrator.py", "_handle_utterance"): (InferenceKind.VOICE, "voice"),
    ("brain/inner_voice.py", "_generate_thought"): (InferenceKind.BACKGROUND, "inner_voice"),
    ("run.py", "_last_thought"): (InferenceKind.BACKGROUND, "inner_voice"),
    ("brain/consciousness_routines.py", "run_wakeup_routine"): (InferenceKind.BACKGROUND, "routines"),
    ("brain/consciousness_routines.py", "reflect"): (InferenceKind.DREAM, "routines"),
    ("brain/proactive.py", "_escalate"): (InferenceKind.BACKGROUND, "proactive"),
    ("brain/proactive.py", "_social_reach_out"): (InferenceKind.BACKGROUND, "proactive"),
    ("brain/proactive.py", "_escalate_spontaneous"): (InferenceKind.BACKGROUND, "proactive"),
    ("brain/initiative.py", "_initiative_turn"): (InferenceKind.BACKGROUND, "proactive"),
    ("brain/mission/consciousness.py", "_initiate_proactive_message"): (InferenceKind.BACKGROUND, "mission"),
    ("brain/perception_floors.py", "_greet"): (InferenceKind.PERCEPTION, "perception_greet"),
    ("brain/upgrade_awareness.py", "_speak_discoveries"): (InferenceKind.BACKGROUND, "upgrade_awareness"),
    ("brain/dreaming.py", "_try_outreach"): (InferenceKind.BACKGROUND, "dreaming"),
    ("brain/dreaming.py", "_try_explore"): (InferenceKind.BACKGROUND, "dreaming"),
    ("brain/goal_pursuit.py", "_tick"): (InferenceKind.ACTIVE_TASK, "goal_pursuit"),
    ("server/job_events.py", "notice_turn"): (InferenceKind.BACKGROUND, "coding_job"),
    ("brain/action_cues.py", "cue_turn"): (InferenceKind.BACKGROUND, "action_cue"),
}
_BY_FUNC: Dict[str, List[Tuple[str, InferenceKind, str]]] = {}
for (_rel, _fn), (_k, _g) in SITE_TABLE.items():
    _BY_FUNC.setdefault(_fn, []).append((_rel, _k, _g))


def classify_site(filename: str, func: str, *, supervised: bool) -> Tuple[str, InferenceKind, str]:
    path = (filename or "").replace("\\", "/")
    for rel, kind, group in _BY_FUNC.get(func, ()):
        if path == rel or path.endswith("/" + rel):
            return f"{rel}:{func}", kind, group
    base = path.rsplit("/", 1)[-1]
    return (f"{base}:{func}", InferenceKind.USER if supervised else InferenceKind.BACKGROUND,
            "unclassified")


def shadow_call_begin(frame: Any, *, supervised: bool, channel: Optional[str],
                      received_ts: Optional[float], call_channel: Optional[str] = None
                      ) -> Optional[ShadowTicket]:
    """Called by respond_streaming at its first step with the consumer's frame.
    Non-blocking (reads a cached mode attribute and appends to a deque) and
    never raises. None when shadow is off or the call is the scheduler's own."""
    try:
        led = _STATE.get("ledger")
        if led is None or led.mode == "off" or getattr(_WORKER, "in_worker", False):
            return None
        code = getattr(frame, "f_code", None)
        site, kind, group = classify_site(getattr(code, "co_filename", "?"),
                                          getattr(code, "co_name", "?"),
                                          supervised=bool(supervised))
        arrival = None
        if isinstance(received_ts, (int, float)) and not isinstance(received_ts, bool):
            lag = time.time() - float(received_ts)
            if 0.0 <= lag <= 3600.0:
                arrival = time.monotonic() - lag
        if group == "unclassified":
            _warn(f"site:{site}", f"respond_streaming from an unclassified site {site}; "
                                  f"shadow ticket kind={kind.value}")
        return led.begin(kind=kind.value, priority=PRIORITY[kind], site=site,
                         channel=channel or call_channel, group=group, arrival_mono=arrival)
    except Exception:
        return None


def slot_begin(label: str) -> Optional[int]:
    """local_llm reports an HTTP generation against the local model slot."""
    try:
        led = _STATE.get("ledger")
        if led is None or led.mode == "off":
            return None
        return led.slot_begin(label)
    except Exception:
        return None


def slot_end(sid: Optional[int], outcome: str, stats: Optional[Dict[str, Any]] = None) -> None:
    if sid is None:
        return
    try:
        led = _STATE.get("ledger")
        if led is not None:
            led.slot_end(sid, outcome, stats)
    except Exception:
        pass


def stats() -> Dict[str, Any]:
    sched, led = _STATE.get("scheduler"), _STATE.get("ledger")
    live_mode = _STATE.get("live_mode")
    modes: Dict[str, Any] = {}
    if live_mode is not None:
        for name in (LIVE_FEATURE, *GROUP_FEATURES.values()):
            try:
                modes[name] = live_mode(name)
            except Exception as exc:
                modes[name] = f"error:{type(exc).__name__}"
    return {"installed": sched is not None, "live_flags": modes,
            "scheduler": sched.stats() if sched is not None else None,
            "shadow": led.stats() if led is not None else None}


def responder_provider(responder_fn: Callable[[], Any], *,
                       scope_factory=None) -> Callable[..., Iterator[Any]]:
    """The production provider: the responder's respond_streaming, with the
    job's cancel token. Keeps the wrapper semantics (recorder, context
    package, channel, record_text, received_ts) because it IS the wrapper."""
    def capture(req):
        r = responder_fn()
        hooks = getattr(r, "_v2_provider_hooks", None)
        authority = hooks.capture_submission(req, responder=r) if hooks is not None else None
        return _ResponderCapture(r, authority)

    def requires_admission(group, channel=None):
        hooks = getattr(responder_fn(), "_v2_provider_hooks", None)
        return hooks is not None and hooks.requires_admission(group, channel)

    def selects_plain_turn(text, site, group, channel):
        hooks = getattr(responder_fn(), "_v2_provider_hooks", None)
        return hooks is not None and hooks.selects_plain_turn(
            text, site=site, group=group, channel=channel) is True

    def provide(req: InferenceRequest, prompt: str, kwargs: dict,
                token: CancelToken) -> Iterator[Any]:
        captured = getattr(_WORKER, "responder_capture", None)
        r = captured.responder if captured is not None else responder_fn()
        if r is None:
            raise SchedulerUnavailable("the responder is not built")
        policy_kwargs = dict(kwargs)
        if not req.allow_tools:
            if getattr(r, "supports_no_tools", False) is not True:
                raise UnsupportedInferencePolicy(
                    "allow_tools=False is unsupported by the responder; refusing inference")
            policy_kwargs["allow_tools"] = False
        policy_kwargs["persist_history"] = req.persist_history
        hooks = getattr(r, "_v2_provider_hooks", None)
        submission = captured.authority if captured is not None else None
        if submission is not None and hooks is not submission.owner:
            from ..providers.base import Unavailable
            raise Unavailable("selected provider owner changed before admission")
        # Preserve the real recorder/context/history facade and its single
        # call site. A provider owner consumes this exact admission only at
        # the responder's verified text transport boundary.
        context = hooks.admitted(req, prompt, policy_kwargs, token, responder=r,
                                 submission=submission) if hooks is not None else nullcontext()
        with context:
            yield from call_with_cancel(r.respond_streaming, prompt, req.brain_state,
                                        cancel_token=token, **policy_kwargs)
    provide._capture_provider_submission = capture
    provide._requires_provider_admission = requires_admission
    provide._selects_plain_turn = selects_plain_turn
    if scope_factory is None:
        return provide

    def scoped(req, prompt, kwargs, token):
        # Provider scope starts on the worker after admission and remains in
        # place through cancellation/tool drain. A queued caller must never
        # mutate global tool policy or clear it while a tool is still running.
        with scope_factory():
            yield from provide(req, prompt, kwargs, token)
    scoped._capture_provider_submission = capture
    scoped._requires_provider_admission = requires_admission
    scoped._selects_plain_turn = selects_plain_turn
    return scoped


def collect_narration(sched, *, prompt, brain_state, responder, site, group,
                      responder_kwargs=None, kind="background", preflight=None,
                      deadline_s=45.0, admission_timeout_s=2.0, prepare_prompt=None):
    """Return bounded speech events only after a successful no-tools job drains.

    Speech synthesis, broadcasts and persistence belong to the caller after this
    function returns, outside the inference slot. Selected failures never replay
    a legacy call. An optional cheap gate runs under the same owner/deadline.
    """
    def provide(req, text, kwargs, token):
        if prepare_prompt is not None:
            text = prepare_prompt(text, req, token)
            if not isinstance(text, str) or not text:
                raise UnsupportedInferencePolicy("narration prompt preparation failed")
        if preflight is not None and not preflight(req, token):
            if not token.is_set():
                yield SimpleNamespace(type="done", full_text="QUIET")
            return
        if not token.is_set():
            yield from responder_provider(lambda: responder)(req, text, kwargs, token)

    req = make_request(kind, prompt, brain_state, site=site, group=group,
                       channel="daemon", admission="background",
                       admission_timeout_s=admission_timeout_s, deadline_s=deadline_s,
                       allow_tools=False, persist_history=False, can_preempt=False,
                       responder_kwargs=dict(responder_kwargs or {}), provider=provide)
    handle = sched.submit(req)
    events, chars, failed, completed = [], 0, False, False
    try:
        status, _, _ = handle.wait_admission()
        if status != "go":
            return ()
        for ev in handle.iter_events():
            kind = getattr(ev, "type", None)
            if kind in ("error", "tool_use", "tool_result", "tool_confirm_request"):
                failed = True
                handle.cancel("invalid_narration")
            if kind in ("model", "delta", "sentence", "done"):
                chars += len(getattr(ev, "text", "") or "") + len(getattr(ev, "full_text", "") or "")
                if len(events) >= 512 or chars > 65536:
                    failed = True
                    handle.cancel("narration_limit")
                elif not failed:
                    events.append(ev)
                if kind == "done":
                    completed = bool((getattr(ev, "full_text", "") or "").strip())
        if failed or not completed or handle.outcome != COMPLETED:
            return ()
        return tuple(events)
    finally:
        handle.close()


def collect_housekeeping(sched, *, prompt, brain_state, responder, task, site,
                         kind="background", free_ask=None, paid_fallback=False,
                         deadline_s=30.0):
    """Run a private reflection under one cancellable background owner.

    A selected route never retries through the legacy caller. The free request
    is text-only. An explicitly enabled paid fallback must also honor no-tools;
    providers lacking that policy are rejected before issuing a paid request.
    """
    if free_ask is None:
        from brain.housekeeping_llm import ask as free_ask

    def provide(req, text, kwargs, token):
        try:
            result = free_ask(text, task=task, max_tokens=180, timeout=25.0,
                              cancel_token=token, deadline_mono=req.deadline_mono)
        except Exception:
            result = None
        if token.is_set():
            return
        if result and result.strip():
            yield SimpleNamespace(type="done", full_text=result.strip())
        elif paid_fallback:
            yield from responder_provider(lambda: responder)(req, text, kwargs, token)

    req = make_request(kind, prompt, brain_state, site=site, group="routines",
                       channel="daemon", admission="background", admission_timeout_s=2.0,
                       deadline_s=deadline_s, allow_tools=False, persist_history=False,
                       responder_kwargs={"replay_history": False, "persist_history": False,
                                         "force_api": True, "bypass_consciousness": True},
                       provider=provide)
    handle = sched.submit(req)
    result = ""
    try:
        status, _, _ = handle.wait_admission()
        if status != "go":
            return ""
        for ev in handle.iter_events():
            if getattr(ev, "type", None) == "done":
                result = (getattr(ev, "full_text", "") or "").strip()
        return result if handle.outcome == COMPLETED else ""
    finally:
        handle.close()


def build_for_server_state(state: Any, *, live: Any, sidecar_path: Optional[str] = None,
                           start: bool = True) -> InferenceScheduler:
    """Build, start and install the scheduler for the running server. Called
    by brain.cognition.v2_install; everything it does stays gated by the live
    flags (default off). Raises on failure (the installer is fail-open)."""
    with _LIFECYCLE:
        if not uninstall(join_timeout=0.25):
            raise SchedulerUnavailable("previous inference scheduler or ledger is still draining")
        return _build_for_server_state(state, live=live, sidecar_path=sidecar_path, start=start)


def _build_for_server_state(state: Any, *, live: Any, sidecar_path: Optional[str],
                            start: bool) -> InferenceScheduler:
    path = sidecar_path if sidecar_path is not None else os.environ.get(SIDECAR_ENV, SIDECAR_DEFAULT)
    ledger = ShadowLedger(sidecar_path=path or None,
                          mode_fn=lambda: live.live_mode(LIVE_FEATURE))

    def responder_fn() -> Any:
        return getattr(state, "brain_api_responder", None)

    def interrupt(channel: str, reason: str) -> None:
        fn = getattr(responder_fn(), "interrupt_channel", None)
        if callable(fn):
            fn(channel, reason)

    bridge = LegacyLockBridge(lock_fn=lambda: getattr(state, "_responder_lock", None),
                              responder_fn=responder_fn,
                              tp_fn=lambda: sys.modules.get("server.turn_priority"),
                              interrupt=interrupt)
    sched = InferenceScheduler(provider=responder_provider(responder_fn), interrupt=interrupt,
                               bridge=bridge, on_record=ledger.record_job)
    install(sched, ledger, live_mode_fn=live.live_mode, is_active_fn=live.is_active)
    if start:
        try:
            ledger.start()
            sched.start()
        except Exception:
            uninstall(join_timeout=0.25)
            raise
    return sched
