"""Fail-closed fixed-policy bubblewrap checks; no host setup or permissions.

The integrator must compose BOTH authorize() and wrap_handler(). A successful
read-only namespace probe is required, as are actual finite caller-cgroup
limits. Missing prerequisites never fall back to an ordinary subprocess.
"""
from __future__ import annotations

import base64
import copy
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import threading
import time


VERSION = 1
KNOWN_FAILURE = 10
UNVERIFIED = 125
RUNTIME_ROOTS = ("/usr/bin","/usr/lib","/usr/lib64","/usr/local/bin","/usr/local/lib")
MAX_MEMORY = 768 * 1024 * 1024
MAX_PIDS = 64
MAX_CPU = 1.0
INSIDE_RUNNER = "/__leon/check_containment.py"


class ContainmentUnavailable(RuntimeError):
    pass


def _json(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False)


def _hash(value):
    return hashlib.sha256(_json(value).encode()).hexdigest()


def _absolute(path):
    if (not isinstance(path,str) or not path.startswith("/") or "\0" in path or
            os.path.realpath(path)!=path or os.path.normpath(path)!=path):
        raise ContainmentUnavailable("unaliased_absolute_path_required")
    return path


def _overlap(a,b):
    return os.path.commonpath((a,b)) in (a,b)


def _relative(path):
    if path==".": return ""
    if (not isinstance(path,str) or not path or len(path)>512 or "\\" in path or
            ":" in path or "\0" in path or any(p in ("",".","..") for p in path.split("/"))):
        raise ContainmentUnavailable("relative_cwd_required")
    return path


def _pin_file(path, *, executable=False):
    path=_absolute(path)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        before=os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_mode&0o7022 or
                before.st_uid not in (0,os.geteuid()) or before.st_size>64*1024*1024 or
                (executable and not before.st_mode&0o111)):
            raise ContainmentUnavailable("trusted_file_required")
        digest=hashlib.sha256()
        while True:
            chunk=os.read(fd,65536)
            if not chunk: break
            digest.update(chunk)
        after=os.fstat(fd)
        current=os.stat(path,follow_symlinks=False)
        if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(
                after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) or (
                current.st_dev,current.st_ino)!=(before.st_dev,before.st_ino):
            raise ContainmentUnavailable("trusted_file_changed")
        return {"path":path,"sha256":digest.hexdigest(),"dev":before.st_dev,"ino":before.st_ino}
    finally:
        os.close(fd)


def _verify_pins(manifest):
    for name in ("bwrap","python","runner"):
        expected=manifest[name]
        if _pin_file(expected["path"],executable=name!="runner")!=expected:
            raise ContainmentUnavailable("trusted_binary_or_runner_changed")
    root=_absolute(manifest["root"])
    info=os.stat(root,follow_symlinks=False)
    if not stat.S_ISDIR(info.st_mode) or [info.st_dev,info.st_ino]!=manifest["root_identity"]:
        raise ContainmentUnavailable("workspace_identity_changed")
    for blocked in manifest["forbidden"]:
        if _overlap(root,_absolute(blocked)) or any(_overlap(blocked,r) for r in RUNTIME_ROOTS):
            raise ContainmentUnavailable("private_state_overlaps_mount")
    if any(_overlap(root,r) for r in RUNTIME_ROOTS) or any(
            _overlap(root,manifest[name]["path"]) for name in ("bwrap","python","runner")):
        raise ContainmentUnavailable("workspace_overlaps_trusted_runtime")
    for directory in manifest["runtime"]:
        if directory not in RUNTIME_ROOTS or _absolute(directory)!=directory or not os.path.isdir(directory):
            raise ContainmentUnavailable("fixed_runtime_directory_changed")
    for path,target in manifest["runtime_aliases"].items():
        if (path,target)!=("/usr/lib64","lib") or not os.path.islink(path) or os.readlink(path)!=target:
            raise ContainmentUnavailable("fixed_runtime_alias_changed")


def _resource_boundary():
    """Read effective cgroup-v2 limits; no control files are ever written."""
    memberships=Path("/proc/self/cgroup").read_text().splitlines()
    rows=[r[3:] for r in memberships if r.startswith("0::")]
    if len(rows)!=1 or not rows[0].startswith("/") or any(p==".." for p in rows[0].split("/")):
        raise ContainmentUnavailable("cgroup_v2_required")
    root=Path("/sys/fs/cgroup")
    directory=root/rows[0].lstrip("/")
    if not any(" - cgroup2 " in line and line.split()[4]==str(root)
               for line in Path("/proc/self/mountinfo").read_text().splitlines()):
        raise ContainmentUnavailable("cgroup_v2_mount_required")
    memory,pids,cpu=math.inf,math.inf,math.inf
    while True:
        for name in ("memory.max","pids.max","cpu.max"):
            file=directory/name
            if not file.exists(): continue
            value=file.read_text().strip().split()
            if not value or value[0]=="max": continue
            if name=="memory.max": memory=min(memory,int(value[0]))
            elif name=="pids.max": pids=min(pids,int(value[0]))
            else: cpu=min(cpu,int(value[0])/int(value[1]))
        if directory==root: break
        directory=directory.parent
        if root not in (directory,*directory.parents):
            raise ContainmentUnavailable("invalid_cgroup_membership")
    if not (0<memory<=MAX_MEMORY and 0<pids<=MAX_PIDS and 0<cpu<=MAX_CPU):
        raise ContainmentUnavailable("finite_memory_pid_cpu_boundary_required")
    return {"memory_bytes":int(memory),"pids":int(pids),"cpu_fraction":cpu}


def _mounts():
    def unescape(value):
        for encoded,plain in (("\\040"," "),("\\011","\t"),("\\012","\n"),("\\134","\\")):
            value=value.replace(encoded,plain)
        return value
    return tuple(unescape(line.split()[4]) for line in Path("/proc/self/mountinfo").read_text().splitlines())


def _workspace_boundary(manifest):
    """A bind mount must not expose host sockets, hardlink aliases or submounts."""
    root=manifest["root"]
    if any(p!=root and os.path.commonpath((root,p))==root for p in _mounts()):
        raise ContainmentUnavailable("workspace_contains_nested_mount")
    count=0
    deadline=time.monotonic()+1
    def walk(fd,depth):
        nonlocal count
        if depth>16: raise ContainmentUnavailable("workspace_audit_depth_limit")
        info=os.fstat(fd)
        if info.st_uid not in (0,os.geteuid()) or info.st_mode&0o022:
            raise ContainmentUnavailable("workspace_not_exclusively_managed")
        with os.scandir(fd) as entries:
            for entry in entries:
                count+=1
                if count>10000 or time.monotonic()>deadline:
                    raise ContainmentUnavailable("workspace_audit_budget_exceeded")
                info=entry.stat(follow_symlinks=False)
                if not (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)):
                    raise ContainmentUnavailable("workspace_contains_alias_or_special_file")
                if info.st_uid not in (0,os.geteuid()) or info.st_mode&0o022:
                    raise ContainmentUnavailable("workspace_not_exclusively_managed")
                if stat.S_ISDIR(info.st_mode):
                    child=os.open(entry.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
                    try:
                        actual=os.fstat(child)
                        if (actual.st_dev,actual.st_ino)!=(info.st_dev,info.st_ino):
                            raise ContainmentUnavailable("workspace_changed_during_audit")
                        walk(child,depth+1)
                    finally: os.close(child)
                elif not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:
                    raise ContainmentUnavailable("workspace_contains_alias_or_special_file")
    fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        info=os.fstat(fd)
        if [info.st_dev,info.st_ino]!=manifest["root_identity"]:
            raise ContainmentUnavailable("workspace_identity_changed")
        walk(fd,0)
    finally: os.close(fd)


def _encode(manifest):
    data=base64.urlsafe_b64encode(_json(manifest).encode()).decode()
    if len(data)>12288: raise ContainmentUnavailable("configuration_too_large")
    return tuple(data[i:i+4096] for i in range(0,len(data),4096))


def _decode(parts):
    text="".join(parts)
    if len(text)>12288: raise ContainmentUnavailable("configuration_too_large")
    data=json.loads(base64.b64decode(text,altchars=b'-_',validate=True))
    if not isinstance(data,dict) or data.get("version")!=VERSION:
        raise ContainmentUnavailable("configuration_version")
    return data


def _bwrap_argv(manifest, *, probe=False):
    # Empty root: never bind '/' or /opt, /var, /run, /home or a host /proc.
    argv=[manifest["bwrap"]["path"],"--unshare-user","--disable-userns",
          "--unshare-pid","--unshare-net","--unshare-ipc","--unshare-uts",
          "--die-with-parent","--as-pid-1","--new-session","--cap-drop","ALL",
          "--dir","/usr","--dir","/usr/local"]
    for directory in manifest["runtime"]:
        argv.extend(("--ro-bind",directory,directory))
    for path,target in sorted(manifest["runtime_aliases"].items()):
        argv.extend(("--symlink",target,path))
    argv.extend(("--symlink","usr/bin","/bin",
          "--symlink","usr/lib","/lib","--symlink","usr/lib64","/lib64",
          "--proc","/proc","--remount-ro","/proc","--dev","/dev",
          "--tmpfs","/tmp","--dir","/tmp/home","--dir","/__leon",
          "--ro-bind",manifest["runner"]["path"],INSIDE_RUNNER,
          "--bind",manifest["root"],"/workspace","--clearenv",
          "--setenv","PATH","/usr/local/bin:/usr/bin:/bin","--setenv","LANG","C.UTF-8",
          "--setenv","HOME","/tmp/home","--setenv","TMPDIR","/tmp",
          "--setenv","PYTHONDONTWRITEBYTECODE","1","--chdir","/workspace",
          "--",manifest["python"]["path"],"-I","-S",INSIDE_RUNNER,
          "--probe" if probe else "--inside",*_encode(manifest)))
    return tuple(argv)


def _namespace_probe(manifest):
    proc=None
    try:
        proc=subprocess.Popen(_bwrap_argv(manifest,probe=True),stdin=subprocess.DEVNULL,
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        stdout,stderr=proc.communicate(timeout=3)
        if proc.returncode!=0 or len(stdout)>1024 or len(stderr)>4096:
            return False
        data=json.loads(stdout)
        return data=={"pid":1,"caps":0,"no_new_privs":1,"private_home":True,"version":VERSION}
    except (OSError,subprocess.SubprocessError,ValueError):
        return False
    finally:
        if proc is not None:
            if proc.poll() is None:
                try: os.killpg(proc.pid,signal.SIGKILL)
                except OSError: pass
                try: proc.wait(timeout=.5)
                except subprocess.TimeoutExpired: pass
            for pipe in (proc.stdout,proc.stderr):
                if pipe is not None: pipe.close()


@dataclass(frozen=True)
class ContainedCommand:
    name: str
    argv: tuple[str,...]
    cwd: str = "."
    timeout_s: float = 30


class CheckContainment:
    """Trusted configuration factory + fail-closed authority/result adapters.

    forbidden_roots must include operational metadata and canonical state. All
    configured checks share one approved workspace. Callers must still enforce
    managed-workspace exclusivity and durable per-action grants.
    """
    def __init__(self, *, scope, root, checks, forbidden_roots,
                 bwrap="/usr/bin/bwrap", python=None, shared_resources=()):
        from .task_project_actions import Check,Workspace,ProjectActions
        if os.name!="posix" or not sys.platform.startswith("linux"):
            raise ContainmentUnavailable("linux_required")
        if type(checks) is not tuple or not 1<=len(checks)<=16 or type(forbidden_roots) is not tuple or not 1<=len(forbidden_roots)<=8:
            raise ContainmentUnavailable("explicit_bounded_configuration_required")
        root=_absolute(root)
        info=os.stat(root,follow_symlinks=False)
        base={"version":VERSION,"scope":scope,"root":root,"root_identity":[info.st_dev,info.st_ino],
              "forbidden":[_absolute(p) for p in forbidden_roots],
              "runtime":[p for p in RUNTIME_ROOTS if os.path.isdir(p) and not os.path.islink(p)],
              "runtime_aliases":{p:os.readlink(p) for p in RUNTIME_ROOTS if os.path.islink(p)},
              "bwrap":_pin_file(_absolute(bwrap),executable=True),
              "python":_pin_file(os.path.realpath(python or "/usr/bin/python3"),executable=True),
              "runner":_pin_file(os.path.realpath(__file__))}
        if not base["python"]["path"].startswith("/usr/"):
            raise ContainmentUnavailable("interpreter_must_be_in_readonly_runtime")
        _verify_pins(base)
        self._manifests={}
        generated=[]
        for command in checks:
            if (not isinstance(command,ContainedCommand) or not isinstance(command.name,str) or
                    not command.name or command.name in self._manifests or type(command.argv) is not tuple or
                    not 1<=len(command.argv)<=32 or any(not isinstance(a,str) or not a or "\0" in a or len(a)>512 for a in command.argv) or
                    not command.argv[0].startswith(("/usr/","/bin/","/workspace/")) or
                    isinstance(command.timeout_s,bool) or not isinstance(command.timeout_s,(int,float)) or
                    not math.isfinite(command.timeout_s) or not .1<=command.timeout_s<=118):
                raise ContainmentUnavailable("bounded_fixed_command_required")
            cwd=_relative(command.cwd)
            manifest={**base,"name":command.name,"command":list(command.argv),"cwd":cwd,"timeout_s":command.timeout_s}
            ref="bwrap-pid1-v1:"+_hash(manifest)
            generated.append(Check(command.name,(base["python"]["path"],"-I","-S",base["runner"]["path"],
                                   "--launch",*_encode(manifest)),timeout_s=command.timeout_s+2,containment_ref=ref))
            self._manifests[command.name]=manifest
        self._workspace=Workspace(scope,root,tuple(generated),tuple(shared_resources))
        self._backend=ProjectActions((self._workspace,))
        self._probe_lock=threading.Lock()
        self._probe_at=0.0
        self._probe_good=False

    @property
    def workspace(self):
        return self._workspace

    def snapshot_manifest(self,spec):
        """Fixed local command only; snapshot mode supplies its own readonly inputs."""
        expected=self._backend.canonical_resource_spec(spec.name,dict(spec.arguments),{'project_scope':spec.scope})
        if expected!=spec or not self.validate_spec(spec):
            raise ContainmentUnavailable('snapshot_fixed_check_unavailable')
        return copy.deepcopy(self._manifests[dict(spec.arguments)['check']])

    def availability(self):
        try:
            manifest=next(iter(self._manifests.values()))
            _verify_pins(manifest)
            _workspace_boundary(manifest)
            limits=_resource_boundary()
            with self._probe_lock:
                if self._probe_at==0 or time.monotonic()-self._probe_at>30:
                    self._probe_good=_namespace_probe(manifest)
                    self._probe_at=time.monotonic()
                if not self._probe_good:
                    return {"available":False,"reason":"mandatory_namespace_probe_failed"}
            return {"available":True,"policy":"bwrap-pid1-v1","limits":limits}
        except Exception as exc:
            return {"available":False,"reason":str(exc) if isinstance(exc,ContainmentUnavailable) else "containment_verification_failed"}

    def _match(self,action,task,spec):
        if action.get("name")!="project.run_check" or action.get("arguments",{}).get("check") not in self._manifests:
            return False
        expected=self._backend.canonical_resource_spec(action["name"],action["arguments"],task)
        return expected==spec

    def authorize(self,action,task,spec):
        try:
            return self._match(action,task,spec) and self.availability().get("available") is True
        except Exception:
            return False

    def validate_spec(self,spec):
        """Preview gate, before task/action IDs exist; never grants permission."""
        try:
            if spec.name!="project.run_check" or dict(spec.arguments).get("check") not in self._manifests:
                return False
            expected=self._backend.canonical_resource_spec(spec.name,dict(spec.arguments),
                                                          {"project_scope":spec.scope})
            return expected==spec and self.availability().get("available") is True
        except Exception:
            return False

    def wrap_handler(self,handler):
        """Root must install this wrapper as well as compose authorize with grants."""
        from .task_worker import ActionResult
        def wrapped(action,task):
            try:
                spec=self._backend.canonical_resource_spec(action["name"],action["arguments"],task)
                if not self.authorize(action,task,spec):
                    return ActionResult("FAILED",{"ok":False,"reason":"containment_unavailable","executed":False})
                result=handler(action,task)
                if not isinstance(result,ActionResult):
                    raise ContainmentUnavailable("unexpected_backend_result")
                data=dict(result.details)
                if data.get("executed") is False:
                    return result
                code=data.get("returncode")
                verified=(data.get("process_drained") is True and type(code) is int and
                          ((code==0 and result.outcome=="SUCCEEDED") or
                           (code==KNOWN_FAILURE and result.outcome=="FAILED" and data.get("reason")=="check_nonzero")))
                if verified:
                    return ActionResult(result.outcome,{**data,"namespace_drained":True,"containment_policy":"bwrap-pid1-v1"})
                return ActionResult("UNKNOWN",{**data,"ok":False,"reason":"namespace_completion_unverified",
                                               "uncertain":True,"replay_allowed":False})
            except Exception:
                return ActionResult("UNKNOWN",{"ok":False,"reason":"containment_result_unverified",
                                               "uncertain":True,"replay_allowed":False})
        return wrapped


def _inside_status():
    status={}
    for line in Path("/proc/self/status").read_text().splitlines():
        key,_,value=line.partition(":"); status[key]=value.strip()
    caps=int(status["CapEff"],16)|int(status["CapPrm"],16)
    return {"pid":os.getpid(),"caps":caps,"no_new_privs":int(status["NoNewPrivs"]),
            "private_home":not os.path.exists("/root") and not os.path.exists("/home"),"version":VERSION}


def _inside(manifest):
    """Trusted read-only PID 1. The untrusted check is always a child process."""
    if _inside_status()!={"pid":1,"caps":0,"no_new_privs":1,"private_home":True,"version":VERSION}:
        return UNVERIFIED
    import ctypes
    import resource
    libc=ctypes.CDLL(None,use_errno=True)
    # Prevent same-UID children from ptracing this proof owner; retain kernel
    # parent-death cleanup. No external namespace descriptors are passed in.
    if libc.prctl(4,0,0,0,0)!=0 or libc.prctl(1,signal.SIGKILL,0,0,0)!=0:
        return UNVERIFIED
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_NOFILE,(64,64))
    resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024*1024,8*1024*1024))
    stopped=False
    def stop(*_):
        nonlocal stopped
        stopped=True
    signal.signal(signal.SIGTERM,stop)
    signal.signal(signal.SIGINT,stop)
    proc=None
    code=None
    try:
        cwd="/workspace"+("/"+manifest["cwd"] if manifest["cwd"] else "")
        proc=subprocess.Popen(manifest["command"],cwd=cwd,stdin=subprocess.DEVNULL,
                              close_fds=True,start_new_session=True)
        deadline=time.monotonic()+manifest["timeout_s"]
        while not stopped and time.monotonic()<deadline:
            code=proc.poll()
            if code is not None: break
            time.sleep(.01)
        if code is None: stopped=True
    except Exception:
        stopped=True
    # PID 1 in the mandatory private PID namespace can reap every descendant,
    # including double-fork/setsid children. Never perform kill(-1) on the host.
    try:
        os.kill(-1,signal.SIGKILL)
    except ProcessLookupError:
        pass
    except OSError:
        return UNVERIFIED
    end=time.monotonic()+1
    while time.monotonic()<end:
        try:
            pid,_=os.waitpid(-1,os.WNOHANG)
            if pid==0: time.sleep(.01)
        except ChildProcessError:
            return 0 if code==0 and not stopped else KNOWN_FAILURE
        except InterruptedError:
            continue
    return UNVERIFIED


def _main(argv):
    try:
        if not argv or argv[0] not in ("--launch","--inside","--probe"):
            return UNVERIFIED
        manifest=_decode(argv[1:])
        if argv[0]=="--probe":
            print(_json(_inside_status()),flush=True)
            return 0
        if argv[0]=="--inside":
            return _inside(manifest)
        _verify_pins(manifest)
        _workspace_boundary(manifest)
        _resource_boundary()
        command=_bwrap_argv(manifest)
        # ProjectActions supplies a workspace cwd descriptor. It must not leak
        # to the payload, even though it names the same approved workspace.
        for descriptor in [int(n) for n in os.listdir("/proc/self/fd") if n.isdigit() and int(n)>2]:
            try: os.close(descriptor)
            except OSError: pass
        os.execve(command[0],command,{"PATH":"/usr/bin:/bin","LANG":"C.UTF-8"})
    except Exception:
        return UNVERIFIED
    return UNVERIFIED


if __name__=="__main__":
    # Exit codes are supervisor-owned: arbitrary check statuses never pass
    # through. The root result wrapper requires this completion proof.
    raise SystemExit(_main(sys.argv[1:]))
