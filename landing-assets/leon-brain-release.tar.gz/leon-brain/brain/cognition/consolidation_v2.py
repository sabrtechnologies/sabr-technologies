"""Priority-10 consolidation units using Leon's installed inference scheduler.

No new loop, inference session, model/store instance, or brain.step owner.
Default OFF; SHADOW builds derived proposals/checkpoints only. Canonical commits
are explicit, versioned calls through an injected existing owning API.
"""
from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import threading
import time
from dataclasses import asdict, dataclass, field
from types import SimpleNamespace
from typing import Callable


def _id(value):
    if not isinstance(value, str) or not value.strip() or len(value) > 160:
        raise ValueError("expected nonempty bounded reference")
    return value


def _json(value, limit=16384):
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    if len(raw.encode("utf-8")) > limit:
        raise ValueError("checkpoint metadata exceeds bounded size")
    return raw


def _digest(value):
    return hashlib.sha256(_json(value).encode()).hexdigest()


@dataclass(frozen=True)
class Evidence:
    reference: str
    origin_id: str
    session_id: str
    kind: str  # observation, outcome, authoritative, generated
    verified: bool = False
    success: bool | None = None
    observed_at: float = 0.0

    def __post_init__(self):
        for value in (self.reference, self.origin_id, self.session_id):
            _id(value)
        if self.kind not in {"observation", "outcome", "authoritative", "generated"}:
            raise ValueError("unknown evidence kind")
        if type(self.verified) is not bool or (self.success is not None and type(self.success) is not bool):
            raise ValueError("verification and success must be explicit booleans")
        if isinstance(self.observed_at, bool) or not isinstance(self.observed_at, (int, float)) or not math.isfinite(self.observed_at) or self.observed_at < 0:
            raise ValueError("invalid evidence timestamp")


@dataclass(frozen=True)
class Proposal:
    proposal_id: str
    kind: str  # procedural, semantic, identity
    content_ref: str
    evidence: tuple[Evidence, ...]
    reversible: bool = False
    generated: bool = False

    def __post_init__(self):
        _id(self.proposal_id)
        _id(self.content_ref)
        if self.kind not in {"procedural", "semantic", "identity"}:
            raise ValueError("unsupported consolidation target; neural state stays with its owner")
        evidence = tuple(self.evidence)
        if not 1 <= len(evidence) <= 32 or any(not isinstance(e, Evidence) for e in evidence):
            raise ValueError("proposal requires bounded evidence references")
        if type(self.reversible) is not bool or type(self.generated) is not bool:
            raise ValueError("proposal flags must be booleans")
        object.__setattr__(self, "evidence", evidence)


def evaluate_proposal(proposal):
    """Eligibility policy, not proof of truth or an authorization to write."""
    # Repeated copies/references to one observation do not manufacture support.
    unique = {}
    conflicts = set()
    for evidence in proposal.evidence:
        prior = unique.get(evidence.reference)
        if prior is not None and prior != evidence:
            conflicts.add(evidence.reference)
        unique[evidence.reference] = evidence
    verified = [e for ref, e in unique.items() if ref not in conflicts and e.verified
                and e.kind != "generated" and e.origin_id != "unknown"]
    n = len(verified)
    authoritative = any(e.kind == "authoritative" for e in verified)
    origins = len({e.origin_id for e in verified})
    history = (len({e.session_id for e in verified if e.session_id != "unknown"}) >= 2
               and len({e.observed_at for e in verified if e.observed_at > 0}) >= 2)
    if proposal.kind == "procedural":
        outcomes = [e for e in verified if e.kind == "outcome" and e.success is not None]
        by_action = {}
        for evidence in outcomes:
            by_action.setdefault(evidence.origin_id, set()).add(evidence.success)
        successes = sum(values == {True} for values in by_action.values())
        eligible = proposal.reversible and successes >= 3 and successes / max(1, len(by_action)) >= 0.8
        reason = "repeated_verified_successes" if eligible else "needs_reversible_verified_success_history"
    elif proposal.kind == "semantic":
        eligible = authoritative or (n >= 2 and origins >= 2) or (n >= 3 and history)
        reason = "corroborated_or_authoritative" if eligible else "needs_corroboration_repetition_or_authority"
    else:
        eligible = n >= 3 and history
        reason = "versioned_identity_evidence_history" if eligible else "identity_requires_evidence_history"
    return {"eligible": bool(eligible), "reason": reason, "verified_support": n,
            "distinct_origins": origins, "conflicting_references": len(conflicts),
            "generated_is_evidence": False, "canonical_authorized": False}


@dataclass(frozen=True)
class UnitResult:
    ok: bool
    output_refs: tuple[str, ...] = ()
    receipt_id: str | None = None
    version_after: str | None = None

    def __post_init__(self):
        if type(self.ok) is not bool or len(self.output_refs) > 32:
            raise ValueError("invalid unit result")
        refs = tuple(_id(ref) for ref in self.output_refs)
        for value in (self.receipt_id, self.version_after):
            if value is not None:
                _id(value)
        object.__setattr__(self, "output_refs", refs)


@dataclass(frozen=True)
class WorkUnit:
    unit_id: str
    owner: str
    operation: str
    run: Callable = field(repr=False, compare=False)
    kind: str = "derived"  # read, derived, canonical
    version_before: str | None = None
    proposal: Proposal | None = None
    destructive: bool = False
    rollback_ref: str | None = None
    max_duration_ms: float = 50.0
    retry_safe: bool = False

    def __post_init__(self):
        for value in (self.unit_id, self.owner, self.operation):
            _id(value)
        if self.kind not in {"read", "derived", "canonical"} or not callable(self.run):
            raise ValueError("invalid consolidation unit")
        if not isinstance(self.max_duration_ms, (int, float)) or isinstance(self.max_duration_ms, bool) or not math.isfinite(self.max_duration_ms) or not 0 < self.max_duration_ms <= 100:
            raise ValueError("unit must declare a cooperative budget of at most 100 ms")
        if type(self.destructive) is not bool:
            raise ValueError("destructive flag must be a boolean")
        if self.kind != "canonical" and self.destructive:
            raise ValueError("derived/read units cannot destroy canonical data")
        if type(self.retry_safe) is not bool or (self.kind == "canonical" and self.retry_safe):
            raise ValueError("canonical units cannot claim automatic retry safety")
        if self.kind == "canonical":
            _id(self.version_before)
            if not isinstance(self.proposal, Proposal):
                raise ValueError("canonical unit requires an evidenced proposal")
            if self.destructive:
                _id(self.rollback_ref)

    def manifest(self):
        return {"unit_id": self.unit_id, "owner": self.owner, "operation": self.operation,
            "kind": self.kind, "version_before": self.version_before,
            "proposal": asdict(self.proposal) if self.proposal else None,
            "destructive": self.destructive, "rollback_ref": self.rollback_ref,
            "max_duration_ms": self.max_duration_ms, "retry_safe": self.retry_safe}


@dataclass(frozen=True)
class CommitAuthorization:
    allowed: bool = False
    expected_version: str | None = None
    review_ref: str | None = None


class CheckpointJournal:
    """Explicit-path derived metadata, never canonical memory or a second index.

    A running unit receipt is committed before calling its owner. Incomplete
    receipts remain uncertain across reopen and require explicit reconciliation.
    Metadata is not a backup of canonical content or a rollback implementation.
    """
    def __init__(self, path, *, capacity=256):
        if type(capacity) is not int or not 1 <= capacity <= 4096:
            raise ValueError("invalid checkpoint capacity")
        self.capacity, self._lock = capacity, threading.RLock()
        self._conn = sqlite3.connect(str(path), timeout=0.05, isolation_level=None, check_same_thread=False)
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.execute("CREATE TABLE IF NOT EXISTS consolidation_jobs (job_id TEXT PRIMARY KEY, manifest TEXT NOT NULL, status TEXT NOT NULL)")
        self._conn.execute("CREATE TABLE IF NOT EXISTS consolidation_units (job_id TEXT NOT NULL, unit_id TEXT NOT NULL, receipt TEXT NOT NULL, PRIMARY KEY(job_id, unit_id))")
        self._conn.execute("CREATE TABLE IF NOT EXISTS consolidation_proposals (proposal_id TEXT PRIMARY KEY, proposal TEXT NOT NULL, assessment TEXT NOT NULL)")

    def prepare(self, job_id, manifest):
        _id(job_id)
        raw = _json(manifest, limit=131072)
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute("SELECT manifest FROM consolidation_jobs WHERE job_id=?", (job_id,)).fetchone()
                if row is not None:
                    if row[0] != raw:
                        raise ValueError("checkpoint manifest conflict")
                    self._conn.execute("COMMIT")
                    return False
                if self._conn.execute("SELECT COUNT(*) FROM consolidation_jobs").fetchone()[0] >= self.capacity:
                    raise RuntimeError("checkpoint capacity reached; explicit archival required")
                self._conn.execute("INSERT INTO consolidation_jobs VALUES(?,?,?)", (job_id, raw, "prepared"))
                self._conn.execute("COMMIT")
                return True
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def job(self, job_id):
        with self._lock:
            row = self._conn.execute("SELECT manifest,status FROM consolidation_jobs WHERE job_id=?", (job_id,)).fetchone()
            return {"manifest": json.loads(row[0]), "status": row[1]} if row else None

    def status(self, job_id, status):
        _id(status)
        with self._lock:
            self._conn.execute("UPDATE consolidation_jobs SET status=? WHERE job_id=?", (status, job_id))

    def unit(self, job_id, unit_id):
        with self._lock:
            row = self._conn.execute("SELECT receipt FROM consolidation_units WHERE job_id=? AND unit_id=?", (job_id, unit_id)).fetchone()
            return json.loads(row[0]) if row else None

    def claim(self, job_id, unit, authorization=None):
        receipt = {"status": "running", "owner": unit.owner, "operation": unit.operation, "kind": unit.kind,
                   "version_before": unit.version_before, "idempotency_key": _digest([job_id, unit.unit_id]),
                   "review_ref": authorization.review_ref if authorization else None}
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                if self.job(job_id) is None:
                    raise ValueError("unit has no prepared checkpoint")
                prior = self.unit(job_id, unit.unit_id)
                retryable = prior and (prior["status"] == "not_started" or
                    (unit.retry_safe and unit.kind != "canonical" and prior["status"] in {"uncertain", "failed"}))
                if retryable:
                    self._conn.execute("UPDATE consolidation_units SET receipt=? WHERE job_id=? AND unit_id=?",
                                       (_json(receipt), job_id, unit.unit_id))
                elif prior is not None:
                    self._conn.execute("COMMIT")
                    return None
                else:
                    self._conn.execute("INSERT INTO consolidation_units VALUES(?,?,?)", (job_id, unit.unit_id, _json(receipt)))
                self._conn.execute("COMMIT")
                return receipt
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise

    def finish(self, job_id, unit_id, receipt):
        with self._lock:
            self._conn.execute("UPDATE consolidation_units SET receipt=? WHERE job_id=? AND unit_id=?",
                               (_json(receipt), job_id, unit_id))

    def propose(self, proposal):
        raw, assessment = _json(asdict(proposal)), evaluate_proposal(proposal)
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                row = self._conn.execute("SELECT proposal FROM consolidation_proposals WHERE proposal_id=?", (proposal.proposal_id,)).fetchone()
                if row and row[0] != raw:
                    raise ValueError("proposal ID conflict")
                if row is None:
                    if self._conn.execute("SELECT COUNT(*) FROM consolidation_proposals").fetchone()[0] >= self.capacity * 32:
                        raise RuntimeError("proposal capacity reached")
                    self._conn.execute("INSERT INTO consolidation_proposals VALUES(?,?,?)", (proposal.proposal_id, raw, _json(assessment)))
                self._conn.execute("COMMIT")
            except BaseException:
                self._conn.execute("ROLLBACK")
                raise
        return assessment

    def proposals(self, limit=32):
        if type(limit) is not int or not 1 <= limit <= 256:
            raise ValueError("invalid proposal query limit")
        with self._lock:
            return [{"proposal": json.loads(row[0]), "assessment": json.loads(row[1])} for row in self._conn.execute(
                "SELECT proposal,assessment FROM consolidation_proposals ORDER BY rowid DESC LIMIT ?", (limit,))]

    def reconcile(self, job_id, unit_id, *, owner_receipt_id, version_after):
        """Record an existing owner's verified commit; never invoke/replay it."""
        _id(owner_receipt_id)
        _id(version_after)
        with self._lock:
            prior = self.unit(job_id, unit_id)
            if prior is None or prior["status"] not in {"running", "uncertain"}:
                return False
            self.finish(job_id, unit_id, {**prior, "status": "completed", "reconciled": True,
                "result": {"ok": True, "receipt_id": owner_receipt_id, "version_after": version_after, "output_refs": []}})
            return True

    def close(self):
        with self._lock:
            self._conn.close()


class ConsolidationCancelled(RuntimeError):
    pass


class UnitContext:
    def __init__(self, *, token, deadline_mono, user_active, clock, journal, job_id, receipt):
        self.token, self.deadline_mono, self.user_active, self.clock = token, deadline_mono, user_active, clock
        self.journal, self.job_id, self.receipt = journal, job_id, receipt

    def check(self):
        if self.deadline_mono is not None and self.clock() >= self.deadline_mono:
            self.token.cancel("deadline")
        try:
            active = self.user_active() is True
        except Exception:
            active = True
        if active:
            self.token.cancel("preempted")
        if self.token.is_set():
            raise ConsolidationCancelled(self.token.reason or "cancelled")

    @property
    def idempotency_key(self):
        return self.receipt["idempotency_key"]


class ConsolidationCoordinator:
    """Submit work to the installed scheduler; own no worker or inference slot."""
    def __init__(self, *, journal, mode="off", scheduler_api=None, user_active=lambda: True,
                 authorize=None, clock=time.monotonic):
        if mode not in {"off", "shadow", "on"}:
            raise ValueError("invalid consolidation mode")
        self.journal, self.mode, self._api = journal, mode, scheduler_api
        self.user_active, self.authorize, self.clock = user_active, authorize, clock
        self._lock, self._handles = threading.RLock(), {}

    def _installed(self):
        api = self._api
        if api is None:
            # Do not construct or install a scheduler, and never fall back to a
            # direct model/legacy consolidation call when it is absent.
            from . import inference_scheduler as api
        scheduler = api.get_scheduler()
        if scheduler is None or not scheduler.alive():
            return api, None
        return api, scheduler

    def submit(self, *, job_id, trace_id, units, source_versions, deadline_s=30.0, resume=False):
        _id(job_id)
        _id(trace_id)
        units = tuple(units)
        if not 1 <= len(units) <= 64 or len({u.unit_id for u in units}) != len(units):
            raise ValueError("job requires unique bounded units")
        if not isinstance(deadline_s, (int, float)) or isinstance(deadline_s, bool) or not math.isfinite(deadline_s) or not 0 < deadline_s <= 300:
            raise ValueError("invalid consolidation deadline")
        versions = {_id(owner): _id(version) for owner, version in source_versions.items()}
        if not versions:
            raise ValueError("checkpoint needs source revision references")
        if self.mode == "off":
            return {"status": "off", "handle": None}
        with self._lock:
            existing = self._handles.get(job_id)
            if existing is not None and not existing.done():
                return {"status": "duplicate", "handle": existing}
            try:
                if self.user_active() is not False:
                    return {"status": "user_active", "handle": None}
                api, scheduler = self._installed()
            except Exception:
                return {"status": "scheduler_unavailable", "handle": None}
            if scheduler is None:
                return {"status": "scheduler_unavailable", "handle": None}
            manifest = {"schema": 1, "job_id": job_id, "trace_id": trace_id, "mode": self.mode,
                        "source_versions": versions, "units": [u.manifest() for u in units]}
            fresh = self.journal.prepare(job_id, manifest)
            if not fresh and not resume:
                return {"status": "already_checkpointed", "handle": existing}
            request = api.make_request("dream", "", {}, site="consolidation_v2.units", group="routines",
                channel="daemon", admission="direct", deadline_s=deadline_s, allow_tools=False,
                persist_history=False, can_preempt=False, trace_id=trace_id, clock=self.clock,
                provider=lambda req, prompt, kwargs, token: self._provide(req, token, job_id, units))
            if request.priority != 10:
                raise ValueError("installed scheduler changed dream priority")
            try:
                handle = scheduler.submit(request)
            except Exception:
                self.journal.status(job_id, "submission_failed")
                return {"status": "submission_failed", "handle": None}
            self._handles[job_id] = handle
            return {"status": "submitted", "handle": handle, "checkpoint_id": job_id}

    def _provide(self, request, token, job_id, units):
        status = "completed"
        self.journal.status(job_id, "running")
        try:
            for unit in units:
                ctx = UnitContext(token=token, deadline_mono=request.deadline_mono,
                    user_active=self.user_active, clock=self.clock, journal=self.journal, job_id=job_id, receipt={})
                ctx.check()
                prior = self.journal.unit(job_id, unit.unit_id)
                if prior is not None:
                    if prior["status"] in {"completed", "proposed"}:
                        continue
                    if prior["status"] != "not_started" and not (unit.retry_safe and unit.kind != "canonical"
                            and prior["status"] in {"uncertain", "failed"}):
                        status = "uncertain_unit_requires_review"
                        break
                decision = None
                if unit.kind == "canonical":
                    assessment = self.journal.propose(unit.proposal)
                    if self.mode == "shadow":
                        claimed = self.journal.claim(job_id, unit)
                        if claimed is None:
                            status = "concurrent_unit_claim"
                            break
                        self.journal.finish(job_id, unit.unit_id, {**claimed, "status": "proposed", "assessment": assessment})
                        yield SimpleNamespace(type="consolidation_progress", unit_id=unit.unit_id, status="proposed")
                        continue
                    decision = self.authorize(unit, assessment) if self.authorize else None
                    if (not assessment["eligible"] or not isinstance(decision, CommitAuthorization)
                            or decision.allowed is not True or decision.expected_version != unit.version_before
                            or not decision.review_ref):
                        status = "canonical_authorization_required"
                        break
                    _id(decision.review_ref)
                ctx.check()
                receipt = self.journal.claim(job_id, unit, decision)
                if receipt is None:
                    status = "concurrent_unit_claim"
                    break
                ctx.receipt = receipt
                started = self.clock()
                try:
                    ctx.check()
                except ConsolidationCancelled:
                    self.journal.finish(job_id, unit.unit_id, {**receipt, "status": "not_started"})
                    raise
                try:
                    # Existing owner must check its expected version and use
                    # this idempotency key atomically with its canonical write.
                    result = unit.run(ctx)
                    if not isinstance(result, UnitResult):
                        raise ValueError("owner returned no typed result receipt")
                    if unit.kind == "canonical" and result.ok and (not result.receipt_id or not result.version_after):
                        raise ValueError("canonical owner omitted durable receipt/version")
                    duration = max(0.0, (self.clock() - started) * 1000)
                    state = "completed" if result.ok else "uncertain" if unit.kind == "canonical" else "failed"
                    self.journal.finish(job_id, unit.unit_id, {**receipt, "status": state,
                        "duration_ms": duration, "over_budget": duration > unit.max_duration_ms, "result": asdict(result)})
                    # Even after cancellation, dispatched canonical work records
                    # its owner result; the scheduler drains tool_result events.
                except BaseException as exc:
                    # Never retry a call after TypeError/cancel/transport failure:
                    # its owning API may already have committed the write.
                    self.journal.finish(job_id, unit.unit_id, {**receipt, "status": "uncertain",
                        "error_type": type(exc).__name__})
                    raise
                yield SimpleNamespace(type="tool_result" if unit.kind == "canonical" else "consolidation_progress",
                    source="consolidation_v2", unit_id=unit.unit_id, status=state, result=asdict(result))
                if not result.ok or duration > unit.max_duration_ms:
                    status = "unit_failed" if not result.ok else "unit_over_budget"
                    break
                ctx.check()
        except ConsolidationCancelled:
            status = token.reason or "cancelled"
        except GeneratorExit:
            status = "provider_closed"
            raise
        except Exception:
            status = "failed"
            raise
        finally:
            self.journal.status(job_id, status if not token.is_set() else token.reason or "cancelled")
        if not token.is_set():
            yield SimpleNamespace(type="done", full_text="", result={"job_id": job_id, "status": status})

    def record_terminal(self, job_id, handle):
        """Existing consumer records scheduler refusal/cancel before provider start."""
        if not handle.done():
            return False
        checkpoint = self.journal.job(job_id)
        if checkpoint and checkpoint["status"] in {"prepared", "running"}:
            self.journal.status(job_id, handle.outcome or "unknown_terminal")
        return True

    def submit_reflection(self, *, trace_id, prompt, deadline_s=30.0):
        """Optional private reasoning via the installed scheduler's provider only.

        Output is a proposal, never verified knowledge or identity. The returned
        handle must be consumed by the existing owner; no inference fallback.
        """
        _id(trace_id)
        if self.mode != "on":
            return {"status": self.mode, "handle": None}
        if not isinstance(prompt, str) or len(prompt) > 8000:
            raise ValueError("reflection prompt must be bounded")
        if not isinstance(deadline_s, (int, float)) or isinstance(deadline_s, bool) or not math.isfinite(deadline_s) or not 0 < deadline_s <= 300:
            raise ValueError("invalid reflection deadline")
        try:
            if self.user_active() is not False:
                return {"status": "user_active", "handle": None}
            api, scheduler = self._installed()
            if scheduler is None:
                return {"status": "scheduler_unavailable", "handle": None}
            request = api.make_request("dream", prompt, {}, site="consolidation_v2.reflection", group="routines",
                channel="daemon", admission="background", admission_timeout_s=1.0, deadline_s=deadline_s,
                allow_tools=False, persist_history=False, can_preempt=False, trace_id=trace_id,
                responder_kwargs={"replay_history": False, "persist_history": False}, clock=self.clock)
            if request.priority != 10:
                raise ValueError("installed scheduler changed dream priority")
            return {"status": "submitted", "handle": scheduler.submit(request)}
        except Exception:
            return {"status": "scheduler_unavailable", "handle": None}


def proposal_unit(proposal, *, unit_id=None):
    """A complete derived unit useful for existing consolidator candidate output."""
    def run(ctx):
        ctx.check()
        ctx.journal.propose(proposal)
        return UnitResult(True, (proposal.proposal_id,))
    return WorkUnit(unit_id or proposal.proposal_id, "existing_candidate_owner", "assess_proposal", run, retry_safe=True)


def existing_source_units(*, episodes=None, knowledge=None, limit=64):
    """Build bounded proposal units from existing read handles, without new stores.

    Calls happen inside scheduler admission. Verification/authority metadata must
    come from the owning API; historical success counts alone are not promotion
    evidence. This function never invokes whole legacy consolidation passes.
    """
    if type(limit) is not int or not 1 <= limit <= 128:
        raise ValueError("source scan must be bounded")
    units = []
    if episodes is not None:
        def episode_run(ctx):
            ctx.check()
            rows = episodes.recent(limit=limit)
            groups = {}
            for row in rows[:limit]:
                ctx.check()
                if not row.get("id") or not row.get("action_name") or row.get("success") not in (0, 1, True, False):
                    continue
                key = (str(row["action_name"]), str(row.get("arg_signature", "")))
                if key not in groups and len(groups) >= 32:
                    continue
                evidence = Evidence("episode:" + str(row["id"]), str(row.get("action_id") or "unknown"),
                    str(row.get("session_id") or "unknown"), "outcome",
                    verified=row.get("outcome_verified") is True, success=bool(row["success"]),
                    observed_at=float(row.get("ts") or 0))
                group = groups.setdefault(key, [])
                if len(group) < 32:
                    group.append(evidence)
            refs = []
            for key, evidence in groups.items():
                ctx.check()
                pid = "procedural:" + _digest([key, [asdict(e) for e in evidence]])
                # Reversibility must be supplied by the actual action policy;
                # tool names or success counts cannot authorize automation.
                reversible = all(row.get("reversible") is True for row in rows[:limit]
                    if (str(row.get("action_name")), str(row.get("arg_signature", ""))) == key)
                proposal = Proposal(pid, "procedural", evidence[0].reference, tuple(evidence), reversible=reversible)
                ctx.journal.propose(proposal)
                refs.append(pid)
            return UnitResult(True, tuple(refs))
        units.append(WorkUnit("episode_candidates", "EpisodeStore", "recent_verified_patterns", episode_run, retry_safe=True))
    if knowledge is not None:
        def knowledge_run(ctx):
            ctx.check()
            rows = knowledge.recent(limit=limit)
            groups = {}
            for row in rows[:limit]:
                ctx.check()
                if not row.get("id") or not isinstance(row.get("text"), str) or not row["text"].strip() or len(row["text"]) > 8000:
                    continue
                # Content equality groups references; no new semantic index or
                # text/model-generated claims are persisted in the checkpoint.
                fingerprint = hashlib.sha256(" ".join(row["text"].split()).casefold().encode()).hexdigest()
                if fingerprint not in groups and len(groups) >= 32:
                    continue
                metadata = row.get("metadata") or {}
                if isinstance(metadata, str):
                    try:
                        metadata = json.loads(metadata)
                    except ValueError:
                        metadata = {}
                if not isinstance(metadata, dict):
                    metadata = {}
                kind = "generated" if metadata.get("generated") is True else "authoritative" if metadata.get("authoritative") is True else "observation"
                evidence = Evidence("knowledge:" + str(row["id"]), str(metadata.get("origin_id") or "unknown"),
                    str(metadata.get("session_id") or "unknown"), kind, verified=metadata.get("verified") is True,
                    observed_at=float(row.get("timestamp") or 0))
                group = groups.setdefault(fingerprint, [])
                if len(group) < 32:
                    group.append(evidence)
            refs = []
            for fingerprint, evidence in groups.items():
                ctx.check()
                proposal = Proposal("semantic:" + _digest([fingerprint, [asdict(e) for e in evidence]]),
                    "semantic", evidence[0].reference, tuple(evidence))
                ctx.journal.propose(proposal)
                refs.append(proposal.proposal_id)
            return UnitResult(True, tuple(refs))
        units.append(WorkUnit("knowledge_candidates", "KnowledgeStore", "corroborated_references", knowledge_run, retry_safe=True))
    return tuple(units)
