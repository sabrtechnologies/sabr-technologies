"""
Phase 13 — Awareness loop.

Continuous lightweight snapshot of Dean's environment so the executive
controller has live context BEFORE Claude is invoked.

What we track (best-effort, all read-only, all cached):

  active_app      — focused window class (gnome-terminal, brave, code, …)
  active_title    — focused window title (truncated, redacted)
  workspace       — KDE virtual desktop number
  is_idle         — Dean's mouse/keyboard idle for >5min
  idle_secs       — exact idle time
  hour_of_day
  day_of_week
  load_avg_1m     — system load
  mem_pct         — % memory used
  cpu_temp_c      — if available
  battery_pct     — laptop only (None on desktop)
  on_ac           — laptop only
  network_up      — quick socket probe
  brave_tab_url   — current Brave tab if CDP is up
  brave_tabs      — count of open tabs
  active_project  — if active_title points at one of Dean's project dirs
  last_focus_switch_s — seconds since active window changed

We DO NOT:
  • Take screenshots in the loop (heavy, privacy).
  • Read clipboard.
  • Read terminal contents.
  • Read browser history.

Loop runs at ~5s by default (LEON_AWARENESS_TICK_S). All probes are
wrapped — any single failure logs once and the snapshot still returns
with that field None. Snapshot is immutable, dataclass.

Public surface:
  AwarenessLoop(interval_s=5.0)
    .start()         — daemon thread
    .stop()
    .snapshot()      — last known snapshot (Snapshot | None)
    .history(n=20)   — last n snapshots for trend display
"""

from __future__ import annotations

import collections
import logging
import os
import socket
import subprocess
import threading
import time
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.cognition.awareness")


def _project_hints() -> tuple:
    """Directory / window-title fragments that mean "the owner is working".

    Was a shipped literal tuple of the owner's project directories. On a
    customer's machine those are folder names that will never exist, so the
    active-project signal was dead for every customer AND carried a
    stranger's company names into their install. Now: this SI's own name
    always, the owner's directories only on the original (brain/origin.py
    returns () on every shipped build).

    Lowercase; callers compare case-insensitively.
    """
    hints = []
    try:
        from brain.identity import si_name, si_name_slug
        n = (si_name() or "").strip().lower()
        if n and n != "si":
            hints.append(n)
            slug = (si_name_slug() or "").strip().lower()
            if slug and slug != n:
                hints.append(slug)
    except Exception:
        pass
    try:
        from brain.origin import owner_project_dir_hints
        hints.extend(owner_project_dir_hints())
    except Exception:
        pass
    return tuple(dict.fromkeys(h for h in hints if h))

_IDLE_THRESHOLD_S = 300.0


@dataclass
class Snapshot:
    ts: float
    active_app: Optional[str] = None
    active_title: Optional[str] = None
    workspace: Optional[int] = None
    is_idle: bool = False
    idle_secs: float = 0.0
    hour_of_day: int = 0
    day_of_week: int = 0
    load_avg_1m: Optional[float] = None
    mem_pct: Optional[float] = None
    cpu_temp_c: Optional[float] = None
    battery_pct: Optional[int] = None
    on_ac: Optional[bool] = None
    network_up: Optional[bool] = None
    brave_tab_url: Optional[str] = None
    brave_tabs: Optional[int] = None
    active_project: Optional[str] = None
    last_focus_switch_s: Optional[float] = None
    # Phase 14 — temporal continuity
    session_id: Optional[str] = None       # stable across short pauses
    session_age_s: float = 0.0             # how long this session has lasted
    session_focus_changes: int = 0         # window-focus events this session
    workflow_app_dwell: Dict[str, float] = field(default_factory=dict)  # app→total seconds
    # Free-form: any probe can stash extras here without schema churn
    extras: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class AwarenessLoop:
    """Background snapshot collector. Daemon thread, safe to leave running."""

    def __init__(self, *, interval_s: Optional[float] = None,
                 history_size: int = 60):
        if interval_s is None:
            interval_s = float(os.environ.get("LEON_AWARENESS_TICK_S", "5.0"))
        self.interval_s = max(1.0, interval_s)
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last: Optional[Snapshot] = None
        self._history: collections.deque = collections.deque(maxlen=history_size)
        self._last_app: Optional[str] = None
        self._last_app_ts: float = time.time()
        # Probe-failure dedup: only log a probe's failure once per process.
        self._logged_failures: set = set()
        # Phase 14 — temporal session tracking
        # A new session_id is minted when:
        #   • this is the first tick after process start
        #   • OR Dean was idle > _SESSION_BREAK_S since the last tick
        self._session_id: Optional[str] = None
        self._session_started_ts: float = 0.0
        self._session_focus_changes: int = 0
        self._session_app_dwell: Dict[str, float] = {}
        self._session_last_tick_ts: float = 0.0
        # 30min idle/gap breaks a session
        self._SESSION_BREAK_S: float = float(
            os.environ.get("LEON_SESSION_BREAK_S", "1800")
        )

    # -- lifecycle -----------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="leon-awareness", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t is not None:
            t.join(timeout=2.0)

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    # -- public --------------------------------------------------------

    def snapshot(self) -> Optional[Snapshot]:
        return self._last

    def snapshot_dict(self) -> Optional[Dict[str, Any]]:
        s = self._last
        return s.to_dict() if s else None

    def history(self, n: int = 20) -> List[Dict[str, Any]]:
        return [s.to_dict() for s in list(self._history)[-n:]]

    def tick_now(self) -> Snapshot:
        """Synchronous one-off snapshot (used by tests / endpoints)."""
        s = self._collect()
        self._publish(s)
        return s

    # -- core loop -----------------------------------------------------

    def _run(self) -> None:
        # Initial fast tick so consumers see something immediately.
        try:
            self._publish(self._collect())
        except Exception as e:
            log.warning("initial awareness tick failed: %s", e)
        while not self._stop.is_set():
            self._stop.wait(self.interval_s)
            if self._stop.is_set():
                break
            try:
                self._publish(self._collect())
            except Exception as e:
                log.warning("awareness tick failed: %s", e)

    def _publish(self, s: Snapshot) -> None:
        self._last = s
        self._history.append(s)

    # -- collection ----------------------------------------------------

    def _collect(self) -> Snapshot:
        now = time.time()
        s = Snapshot(ts=now)
        tm = time.localtime(now)
        s.hour_of_day = tm.tm_hour
        s.day_of_week = tm.tm_wday

        s.active_app, s.active_title, s.workspace = self._active_window()
        if s.active_app and s.active_app != self._last_app:
            self._last_app = s.active_app
            self._last_app_ts = now
        s.last_focus_switch_s = round(now - self._last_app_ts, 2)

        s.idle_secs = self._idle_seconds()
        s.is_idle = s.idle_secs >= _IDLE_THRESHOLD_S

        s.load_avg_1m = self._load_avg()
        s.mem_pct = self._mem_pct()
        s.cpu_temp_c = self._cpu_temp()
        s.battery_pct, s.on_ac = self._battery()
        s.network_up = self._network_up()

        url, tab_count = self._brave_tabs()
        s.brave_tab_url = url
        s.brave_tabs = tab_count

        s.active_project = self._infer_project(s.active_title)

        # Phase 14 — temporal session bookkeeping
        self._update_session(s, now)
        s.session_id = self._session_id
        s.session_age_s = round(now - self._session_started_ts, 1)
        s.session_focus_changes = self._session_focus_changes
        # Top-5 apps by dwell, condensed for the snapshot
        if self._session_app_dwell:
            top = sorted(self._session_app_dwell.items(),
                          key=lambda kv: kv[1], reverse=True)[:5]
            s.workflow_app_dwell = {k: round(v, 1) for k, v in top}
        return s

    def _update_session(self, snap: Snapshot, now: float) -> None:
        """Mint or continue the current session_id; accumulate app dwell."""
        gap = now - (self._session_last_tick_ts or now)
        if (self._session_id is None
                or gap > self._SESSION_BREAK_S
                or (snap.idle_secs and snap.idle_secs > self._SESSION_BREAK_S)):
            # Start a new session
            self._session_id = f"s{int(now)}"
            self._session_started_ts = now
            self._session_focus_changes = 0
            self._session_app_dwell = {}
        # Focus-change counter (compare with prior tick)
        if snap.active_app and snap.active_app != self._last_app \
                and self._last_app is not None:
            self._session_focus_changes += 1
        # App dwell accumulator: add delta since last tick to current focused app
        if self._session_last_tick_ts and snap.active_app:
            dwell_app = snap.active_app or (snap.active_title or "?")[:32]
            self._session_app_dwell[dwell_app] = (
                self._session_app_dwell.get(dwell_app, 0.0)
                + (now - self._session_last_tick_ts)
            )
        self._session_last_tick_ts = now

    def session(self) -> Dict[str, Any]:
        """Standalone session info for the /api/cognition/awareness/session endpoint."""
        now = time.time()
        return {
            "session_id": self._session_id,
            "started_ts": self._session_started_ts,
            "age_s": round(now - self._session_started_ts, 1)
                if self._session_started_ts else 0.0,
            "focus_changes": self._session_focus_changes,
            "app_dwell": dict(sorted(self._session_app_dwell.items(),
                                       key=lambda kv: kv[1], reverse=True)),
            "session_break_threshold_s": self._SESSION_BREAK_S,
        }

    # -- probes (each guarded individually) ----------------------------

    def _safe(self, name: str, fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            if name not in self._logged_failures:
                log.info("awareness probe %s unavailable: %s", name, e)
                self._logged_failures.add(name)
            return None

    def _active_window(self):
        # Prefer wmctrl (lightweight + parseable). xdotool fallback.
        out = self._safe("wmctrl", _run, ["wmctrl", "-lG"], timeout=1.0)
        if not out:
            return None, None, None
        try:
            active_win = self._safe(
                "xdotool-active",
                _run, ["xdotool", "getactivewindow"], timeout=1.0,
            )
            if not active_win:
                return None, None, None
            wid_dec = int(active_win.strip())
            wid_hex = f"0x{wid_dec:08x}"
            for line in out.splitlines():
                if line.lower().startswith(wid_hex):
                    parts = line.split(None, 7)
                    if len(parts) >= 8:
                        try:
                            ws = int(parts[1])
                        except ValueError:
                            ws = None
                        title = parts[7]
                        cls = self._safe(
                            "xdotool-class",
                            _run,
                            ["xdotool", "getwindowclassname", active_win.strip()],
                            timeout=1.0,
                        )
                        cls = (cls or "").strip() or None
                        return cls, title[:160], ws
        except Exception:
            return None, None, None
        return None, None, None

    def _idle_seconds(self) -> float:
        out = self._safe("xprintidle", _run, ["xprintidle"], timeout=1.0)
        if not out:
            return 0.0
        try:
            return int(out.strip()) / 1000.0
        except Exception:
            return 0.0

    def _load_avg(self) -> Optional[float]:
        try:
            with open("/proc/loadavg") as f:
                return float(f.read().split()[0])
        except Exception:
            return None

    def _mem_pct(self) -> Optional[float]:
        try:
            mem = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    k, _, v = line.partition(":")
                    mem[k.strip()] = int(v.strip().split()[0])
            total = mem.get("MemTotal", 0)
            avail = mem.get("MemAvailable", 0)
            if total > 0:
                return round((1.0 - avail / total) * 100.0, 1)
        except Exception:
            return None
        return None

    def _cpu_temp(self) -> Optional[float]:
        # Best-effort — try a known thermal path
        try:
            for i in range(5):
                p = f"/sys/class/thermal/thermal_zone{i}/temp"
                if os.path.exists(p):
                    with open(p) as f:
                        v = int(f.read().strip())
                        if v > 1000:
                            return round(v / 1000.0, 1)
        except Exception:
            return None
        return None

    def _battery(self):
        try:
            root = "/sys/class/power_supply"
            if not os.path.isdir(root):
                return None, None
            for name in os.listdir(root):
                base = os.path.join(root, name)
                tpath = os.path.join(base, "type")
                if not os.path.exists(tpath):
                    continue
                with open(tpath) as f:
                    tp = f.read().strip()
                if tp == "Battery":
                    cap = os.path.join(base, "capacity")
                    if os.path.exists(cap):
                        with open(cap) as f:
                            pct = int(f.read().strip())
                        status = os.path.join(base, "status")
                        on_ac = None
                        if os.path.exists(status):
                            with open(status) as f:
                                on_ac = f.read().strip().lower() in ("charging", "full")
                        return pct, on_ac
            return None, None
        except Exception:
            return None, None

    def _network_up(self) -> Optional[bool]:
        try:
            sock = socket.create_connection(("1.1.1.1", 53), timeout=0.6)
            sock.close()
            return True
        except Exception:
            return False

    def _brave_tabs(self):
        # Quick CDP /json call. No dependency.
        try:
            import urllib.request, json as _json
            req = urllib.request.Request("http://127.0.0.1:9222/json", method="GET")
            with urllib.request.urlopen(req, timeout=0.6) as resp:
                data = _json.loads(resp.read().decode("utf-8", "replace"))
            pages = [d for d in data if d.get("type") == "page"]
            if not pages:
                return None, 0
            # Heuristic: first page is most-recently-active in many cases
            return pages[0].get("url"), len(pages)
        except Exception:
            return None, None

    def _infer_project(self, title: Optional[str]) -> Optional[str]:
        if not title:
            return None
        low = title.lower()
        for h in _project_hints():
            if h in low:
                return h
        return None


def _run(cmd: List[str], timeout: float = 1.0) -> Optional[str]:
    """Run a small command — return stdout or None on any failure."""
    env = dict(os.environ)
    env.setdefault("DISPLAY", ":0")
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, env=env,
        )
        if r.returncode != 0:
            return None
        return r.stdout
    except Exception:
        return None


__all__ = ["AwarenessLoop", "Snapshot"]
