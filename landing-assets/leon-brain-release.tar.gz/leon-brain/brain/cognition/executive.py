"""
Phase 13 — Executive Controller.

The cognition router that decides — BEFORE Claude is invoked — what kind of
thinking is needed:

  STRATEGY_REFLEX_LOCAL   — answer from Leon's own state (no Claude, no tool)
  STRATEGY_REFLEX_TOOL    — fire a single deterministic tool + canned ack
  STRATEGY_CANNED         — fixed text response (greeting, thanks, etc.)
  STRATEGY_CLAUDE_FAST    — short Claude turn, persistent session, low ctx
  STRATEGY_CLAUDE_DEEP    — Claude with full cognition context + retrieval
  STRATEGY_AUTOPILOT      — long-horizon goal: queue + plan
  STRATEGY_BACKGROUND     — do not respond now; record + defer

ExecutivePlan is the single artifact every other component reads. It carries:

  strategy           — which path above
  confidence         — 0..1 we picked right
  reasoning          — short rationale
  budget_ms          — target latency budget for the whole turn
  prompt_flags       — what cognition sections to include in the prompt
  retrieval_depth    — how many memory turns to pull (gates × budget)
  tools_to_consider  — biased toward healthy tools, lessons-aware
  vetoes             — list of (tool/topic, reason) — never use these
  notes              — small free-form dict for downstream

This module is SHADOW-MODE by default. The responder is not yet patched to
read the plan in this phase 13 first cut — instead, the plan is exposed
via `cognition.executive.plan(user_text)` and the responder reads it via a
helper. Bootstrap wires the helper after install. Flip
`LEON_EXECUTIVE_AUTHORITATIVE=on` to let it actually steer.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.executive")


@dataclass
class SimulationResult:
    """Pre-action outcome prediction (Phase 14)."""
    p_success: float                # 0..1
    expected_latency_ms: float
    rollback_cost: str              # "none"|"cheap"|"medium"|"expensive"
    side_effect_risk: float         # 0..1
    confidence: float               # how confident we are in this prediction
    dependency_risk: float          # 0..1; high if any required tool is broken
    notes: List[str]                # short reasons

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @property
    def is_safe(self) -> bool:
        return (self.p_success >= 0.5
                 and self.dependency_risk < 0.5
                 and self.side_effect_risk < 0.7)


# ── Strategy constants ────────────────────────────────────────────────────

STRATEGY_REFLEX_LOCAL = "reflex_local"
STRATEGY_REFLEX_TOOL  = "reflex_tool"
STRATEGY_CANNED       = "canned"
STRATEGY_CLAUDE_FAST  = "claude_fast"
STRATEGY_CLAUDE_DEEP  = "claude_deep"
STRATEGY_AUTOPILOT    = "autopilot"
STRATEGY_BACKGROUND   = "background"


# Latency budgets per strategy (ms). The responder honors these as hints.
_BUDGETS = {
    STRATEGY_REFLEX_LOCAL: 250,
    STRATEGY_REFLEX_TOOL:  600,
    STRATEGY_CANNED:       250,
    STRATEGY_CLAUDE_FAST:  2500,
    STRATEGY_CLAUDE_DEEP:  9000,
    STRATEGY_AUTOPILOT:    60000,
    STRATEGY_BACKGROUND:   500,
}


@dataclass
class ExecutivePlan:
    strategy: str
    confidence: float
    reasoning: str
    budget_ms: int
    prompt_flags: Dict[str, bool] = field(default_factory=dict)
    retrieval_depth: int = 4
    tools_to_consider: List[str] = field(default_factory=list)
    vetoes: List[Tuple[str, str]] = field(default_factory=list)
    awareness_snapshot: Optional[Dict[str, Any]] = None
    notes: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["vetoes"] = [list(v) for v in self.vetoes]
        return d


class ExecutiveController:
    """Routes the next turn before any Claude call.

    All deps are optional. Each missing dep degrades gracefully — the
    executive still produces a plan, just with less signal.
    """

    def __init__(
        self,
        *,
        hierarchy=None,          # phase 3 router (reactive/model/strategic)
        gates=None,              # SNN gates → budgets, retries
        drives=None,             # loud drive biases reasoning
        awareness=None,          # active app / load / idle
        tool_health=None,        # avoid broken, prefer healthy
        lessons=None,            # vetoes from "stop doing X" rules
        skills=None,             # learned chain match
        reflex=None,             # reflex layer (state-introspection)
        canned_match_fn=None,    # callable(text)->canned_text|None
        command_match_fn=None,   # callable(text)->cmd-spec|None
        prompt_builder=None,     # phase 3 cognition prompt
        world_model=None,        # phase 1 world model for simulation
        tool_classifier=None,    # phase 14 — preferred-tool ranking
    ):
        self.hierarchy = hierarchy
        self.gates = gates
        self.drives = drives
        self.awareness = awareness
        self.tool_health = tool_health
        self.lessons = lessons
        self.skills = skills
        self.reflex = reflex
        self.canned_match_fn = canned_match_fn
        self.command_match_fn = command_match_fn
        self.prompt_builder = prompt_builder
        # Phase 14
        self.world_model = world_model
        self.tool_classifier = tool_classifier

        self._last_plan: Optional[ExecutivePlan] = None
        # Tiny in-memory rolling log of plans for the dashboard
        self._history: List[Dict[str, Any]] = []
        # Phase 14 — LRU-ish strategy cache (small, exact-text match)
        # Same input → same plan within TTL, no re-routing cost
        self._plan_cache: Dict[str, Tuple[float, ExecutivePlan]] = {}
        self._plan_cache_ttl_s: float = float(
            os.environ.get("LEON_PLAN_CACHE_TTL_S", "30")
        )
        self._plan_cache_max: int = 256
        # Routing telemetry — counters since process start
        self._counters: Dict[str, int] = {
            "plan_calls": 0, "cache_hits": 0,
            "claude_calls": 0, "reflex_calls": 0,
            "canned_calls": 0, "tool_calls": 0,
            "autopilot_calls": 0,
        }
        # Route trace ring buffer for /api/cognition/executive/route_trace
        self._route_trace: List[Dict[str, Any]] = []

    # -- public --------------------------------------------------------

    def plan(self, user_text: str,
              *, context: Optional[Dict[str, Any]] = None,
              skip_cache: bool = False) -> ExecutivePlan:
        """Produce an ExecutivePlan for `user_text`.

        Order of checks (cheapest first):
          0. Plan cache (Phase 14) — same input within TTL → cached plan
          1. Reflex layer match → REFLEX_LOCAL
          2. Command-intent match → REFLEX_TOOL
          3. Canned-reply match → CANNED
          4. Hierarchy router signal:
              reactive    → CLAUDE_FAST
              strategic   → AUTOPILOT
              model       → CLAUDE_FAST or CLAUDE_DEEP based on drives/budget
        """
        self._counters["plan_calls"] = self._counters.get("plan_calls", 0) + 1
        clean = (user_text or "").strip()
        self._cur_input = clean  # stashed for _record() cache write
        # Phase 14 — strategy cache: identical input within TTL
        if not skip_cache and clean:
            cached = self._plan_cache.get(clean)
            if cached:
                ts, plan = cached
                if (time.time() - ts) < self._plan_cache_ttl_s:
                    self._counters["cache_hits"] += 1
                    return plan
        snap = None
        if self.awareness is not None:
            try:
                snap = self.awareness.snapshot_dict()
            except Exception:
                snap = None

        # 1) Reflex layer
        if self.reflex is not None:
            try:
                r = self.reflex.respond(clean)
                if r is not None and r.confidence >= 0.85:
                    plan = self._make(
                        STRATEGY_REFLEX_LOCAL,
                        confidence=r.confidence,
                        reasoning=f"reflex:{r.source}",
                        snap=snap,
                        notes={"reflex_text": r.text, "reflex_ms": r.latency_ms},
                    )
                    return self._record(plan)
            except Exception as e:
                log.warning("reflex check failed: %s", e)

        # 2) Command-intent (single deterministic tool)
        if self.command_match_fn is not None:
            try:
                cmd = self.command_match_fn(clean)
                if cmd is not None:
                    plan = self._make(
                        STRATEGY_REFLEX_TOOL,
                        confidence=0.92,
                        reasoning="command_intent",
                        snap=snap,
                        notes={"command": True},
                    )
                    return self._record(plan)
            except Exception as e:
                log.warning("command_match probe failed: %s", e)

        # 3) Canned text
        if self.canned_match_fn is not None:
            try:
                c = self.canned_match_fn(clean)
                if c is not None:
                    plan = self._make(
                        STRATEGY_CANNED, confidence=0.97,
                        reasoning="canned_match", snap=snap,
                        notes={"canned_text": c},
                    )
                    return self._record(plan)
            except Exception as e:
                log.warning("canned_match probe failed: %s", e)

        # 4) Hierarchy
        route = None
        if self.hierarchy is not None:
            try:
                route = self.hierarchy.classify(clean)
            except Exception as e:
                log.warning("hierarchy classify failed: %s", e)

        if route is not None and route.layer == "strategic":
            plan = self._make(
                STRATEGY_AUTOPILOT, confidence=route.confidence,
                reasoning=f"hierarchy:strategic — {route.reasoning}",
                prompt_flags=route.suggested_cognition_flags or {},
                snap=snap,
            )
            return self._record(self._apply_lesson_vetoes(plan))

        # Deep vs fast
        depth_score = self._depth_score(clean, route)
        if depth_score >= 0.55:
            plan = self._make(
                STRATEGY_CLAUDE_DEEP, confidence=0.7,
                reasoning=f"deep_score={depth_score:.2f}",
                prompt_flags=(route.suggested_cognition_flags if route else None) or {
                    "include_identity": True,
                    "include_drives": True,
                    "include_relevant_entities": True,
                    "include_recent_episodes": True,
                },
                snap=snap,
                retrieval_depth=self._retrieval_depth(default=10),
            )
        else:
            plan = self._make(
                STRATEGY_CLAUDE_FAST, confidence=0.75,
                reasoning="fast_path",
                prompt_flags=(route.suggested_cognition_flags if route else None) or {
                    "include_identity": True,
                },
                snap=snap,
                retrieval_depth=self._retrieval_depth(default=4),
            )

        # Tool bias: prefer healthy tools matching the intent
        plan.tools_to_consider = self._tools_to_consider(clean)
        plan = self._apply_lesson_vetoes(plan)
        # Skill hint
        if self.skills is not None:
            try:
                hit = self.skills.match(intent_text=clean)
                if hit is not None:
                    plan.notes["skill_match"] = {
                        "skill_id": hit.id, "name": hit.name,
                        "success_rate": hit.success_rate, "steps": len(hit.steps),
                    }
            except Exception as e:
                log.warning("skill match failed: %s", e)
        return self._record(plan)

    def last(self) -> Optional[Dict[str, Any]]:
        return self._last_plan.to_dict() if self._last_plan else None

    def history(self, n: int = 20) -> List[Dict[str, Any]]:
        return self._history[-n:]

    # -- internals -----------------------------------------------------

    def _make(
        self,
        strategy: str,
        *,
        confidence: float,
        reasoning: str,
        prompt_flags: Optional[Dict[str, bool]] = None,
        snap: Optional[Dict[str, Any]] = None,
        notes: Optional[Dict[str, Any]] = None,
        retrieval_depth: Optional[int] = None,
    ) -> ExecutivePlan:
        budget = _BUDGETS.get(strategy, 3000)
        # Allow gates to shrink budget if drive is "speed"
        if self.gates is not None:
            try:
                g = self.gates.current()
                # patience proxy: serotonin
                ser = getattr(g, "patience", None)
                if ser is not None and ser < 0.3:
                    budget = int(budget * 0.7)
            except Exception:
                pass
        return ExecutivePlan(
            strategy=strategy,
            confidence=confidence,
            reasoning=reasoning,
            budget_ms=budget,
            prompt_flags=prompt_flags or {"include_identity": True},
            retrieval_depth=retrieval_depth or 4,
            tools_to_consider=[],
            vetoes=[],
            awareness_snapshot=snap,
            notes=notes or {},
        )

    def _depth_score(self, text: str, route) -> float:
        score = 0.0
        # length signal
        if len(text) > 220:
            score += 0.5
        elif len(text) > 60:
            score += 0.25
        # multi-clause
        if text.count(",") >= 2 or text.count(".") >= 2:
            score += 0.15
        # explicit complexity words (each contributes)
        low = text.lower()
        complex_words = ("explain", "design", "plan", "compare", "tradeoff",
                         "tradeoffs", "architect", "outline", "research",
                         "analyze", "evaluate", "deep", "thorough")
        hits = sum(1 for w in complex_words if w in low)
        score += min(0.5, 0.2 * hits)
        # NE high → cautious → prefer deep
        if self.gates is not None:
            try:
                g = self.gates.current()
                ct = getattr(g, "confidence_threshold", 0.5)
                if ct > 0.7:
                    score += 0.15
            except Exception:
                pass
        # Loud drive escalates depth (curiosity / continuity)
        if self.drives is not None:
            try:
                loud = self.drives.loudest()
                if loud in ("curiosity", "continuity"):
                    score += 0.1
            except Exception:
                pass
        if route is not None and route.layer == "model_driven":
            flags = route.suggested_cognition_flags or {}
            if flags.get("include_recent_episodes"):
                score += 0.1
        return min(1.5, score)

    def _retrieval_depth(self, default: int = 6) -> int:
        if self.gates is None:
            return default
        try:
            g = self.gates.current()
            sal = getattr(g, "memory_salience", 1.0)
            return max(2, min(20, int(round(default * float(sal)))))
        except Exception:
            return default

    def _tools_to_consider(self, text: str) -> List[str]:
        """Best-effort tool suggestion list, biased to healthy tools.

        This is just a HINT — the responder is still free to pick anything.
        """
        if self.tool_health is None:
            return []
        try:
            healthy = self.tool_health.all_stats(status="healthy", limit=200)
            # Keyword-bias: pick tools whose name shares a token with text
            tokens = {t.lower() for t in text.split() if len(t) > 3}
            scored: List[Tuple[float, str]] = []
            for ts in healthy:
                name = ts.tool.lower()
                shared = sum(1 for t in tokens if t in name)
                if shared > 0:
                    scored.append((shared + ts.success_rate, ts.tool))
            scored.sort(key=lambda x: x[0], reverse=True)
            return [t for _, t in scored[:6]]
        except Exception:
            return []

    def _apply_lesson_vetoes(self, plan: ExecutivePlan) -> ExecutivePlan:
        if self.lessons is None:
            return plan
        try:
            relevant = self.lessons.relevant(text=plan.reasoning, limit=4)
        except Exception:
            return plan
        for L in relevant:
            if L.polarity == "dont" and L.scope.startswith("tool:"):
                tname = L.scope.split(":", 1)[1]
                plan.vetoes.append((tname, f"lesson #{L.id}: {L.text[:80]}"))
        return plan

    def _record(self, plan: ExecutivePlan) -> ExecutivePlan:
        self._last_plan = plan
        self._history.append({
            "ts": time.time(), **plan.to_dict(),
        })
        self._history = self._history[-200:]
        # Phase 14 — cache by the user_text the caller stashed on _cur_input.
        ut = getattr(self, "_cur_input", None)
        if ut:
            self._plan_cache[ut] = (time.time(), plan)
            # Trim to max size
            if len(self._plan_cache) > self._plan_cache_max:
                # Drop the 32 oldest entries in one pass
                oldest = sorted(self._plan_cache.items(),
                                  key=lambda kv: kv[1][0])[:32]
                for k, _ in oldest:
                    self._plan_cache.pop(k, None)
        # Phase 14 — counters by strategy family
        strat = plan.strategy
        if strat.startswith("claude_"):
            self._counters["claude_calls"] += 1
        elif strat == "reflex_local":
            self._counters["reflex_calls"] += 1
        elif strat == "canned":
            self._counters["canned_calls"] += 1
        elif strat == "reflex_tool":
            self._counters["tool_calls"] += 1
        elif strat == "autopilot":
            self._counters["autopilot_calls"] += 1
        return plan


# ── Phase 14 additions: simulation + telemetry + authoritative API ──────


def _simulate(self, *, strategy: str = STRATEGY_CLAUDE_FAST,
                tools: Optional[List[str]] = None,
                skill_id: Optional[int] = None,
                context_text: str = "") -> SimulationResult:
    """Pre-action outcome prediction. Cheap (<1ms typical). Pulls signals
    from tool_health + world_model + skill stats + drives.

    The result is used to:
      • veto risky autopilot/repair actions
      • escalate approval requirement
      • bias retry budget
      • inject warnings into the prompt

    NOT a substitute for actually trying — it's a sanity gate.
    """
    notes: List[str] = []

    # Dependency risk — any required tool currently broken?
    dep_risk = 0.0
    if tools and self.tool_health is not None:
        broken = 0
        degraded = 0
        for t in tools:
            stat = self.tool_health.get(t)
            if stat is None:
                continue
            if stat.status == "broken":
                broken += 1
                notes.append(f"{t} is BROKEN")
            elif stat.status == "degraded":
                degraded += 1
        if tools:
            dep_risk = min(1.0, broken / len(tools)
                            + 0.3 * (degraded / len(tools)))

    # If a skill is chosen, use its reinforcement + sr as confidence
    skill_p = None
    if skill_id is not None and self.skills is not None:
        try:
            sk = next((s for s in self.skills.all(limit=200)
                        if s.id == skill_id), None)
            if sk is not None:
                # combine mined sr and invoke sr (invoke is more recent)
                invk = sk.invoke_runs
                if invk:
                    invoke_sr = sk.invoke_success / invk
                    skill_p = 0.4 * sk.success_rate + 0.6 * invoke_sr
                else:
                    skill_p = sk.success_rate
                notes.append(f"skill {sk.name!r} reinforcement={sk.reinforcement:.2f} state={sk.state}")
                if sk.state == "deprecated":
                    skill_p = max(0.1, (skill_p or 0.5) * 0.5)
                    notes.append("skill is DEPRECATED — heavy penalty")
        except Exception:
            pass

    # Expected latency — average across involved tools
    exp_lat = 0.0
    if tools and self.tool_health is not None:
        lats = []
        for t in tools:
            s = self.tool_health.get(t)
            if s and s.latency_p95_ms:
                lats.append(s.latency_p95_ms)
        if lats:
            exp_lat = sum(lats) / len(lats)
    if exp_lat == 0.0:
        exp_lat = _BUDGETS.get(strategy, 3000) * 0.6

    # Base success — start with skill_p if available, else use tool success
    if skill_p is not None:
        p_success = max(0.05, min(0.99, skill_p * (1.0 - dep_risk)))
    elif tools and self.tool_health is not None:
        srs = [self.tool_health.get(t).success_rate
                for t in tools
                if self.tool_health.get(t) is not None]
        avg_sr = sum(srs) / len(srs) if srs else 0.85
        # Joint success ≈ product, but smooth toward avg
        p_success = max(0.05, min(0.99, avg_sr ** max(1, len(srs)) * (1 - dep_risk * 0.5)))
    else:
        # Pure-Claude turn → use historical claude.response sr if known
        p_success = 0.92  # claude rarely fails outright
        notes.append("no tools — assuming claude.response baseline 0.92")

    # Rollback cost — heuristic from tool names
    rollback = "none"
    state_changers = {"open", "close", "click", "send", "post", "delete",
                       "kill", "write", "save", "commit", "push", "lock",
                       "shutdown", "restart"}
    if tools and any(any(sc in t for sc in state_changers) for t in tools):
        rollback = "medium"
    if tools and any("delete" in t or "rm." in t or "kill" in t for t in tools):
        rollback = "expensive"

    # Side-effect risk — coarse: state-changing tools have non-zero risk
    side_eff = 0.0
    if rollback == "expensive":
        side_eff = 0.9
    elif rollback == "medium":
        side_eff = 0.3

    # Confidence — high if we had real per-tool data
    conf = 0.5
    if tools and self.tool_health is not None:
        n_seen = sum(1 for t in tools if self.tool_health.get(t) is not None)
        conf = max(0.3, min(0.95, n_seen / max(1, len(tools))))
    if skill_p is not None and skill_id is not None:
        conf = max(conf, 0.7)

    return SimulationResult(
        p_success=round(p_success, 3),
        expected_latency_ms=round(exp_lat, 1),
        rollback_cost=rollback,
        side_effect_risk=round(side_eff, 3),
        confidence=round(conf, 3),
        dependency_risk=round(dep_risk, 3),
        notes=notes,
    )


def _route(self, user_text: str) -> Dict[str, Any]:
    """Phase 14 authoritative entry: produce a Route record the responder
    can act on directly. Combines plan + reflex answer (if any) + skill
    invocation candidate + simulation."""
    plan = self.plan(user_text)
    reflex_answer = None
    if plan.strategy == STRATEGY_REFLEX_LOCAL and self.reflex is not None:
        try:
            r = self.reflex.respond(user_text)
            if r is not None:
                reflex_answer = r.to_dict()
        except Exception:
            pass
    skill_hint = plan.notes.get("skill_match") if isinstance(plan.notes, dict) else None
    # Cheap simulation only if we're about to act with tools
    sim = None
    if plan.strategy in (STRATEGY_REFLEX_TOOL, STRATEGY_AUTOPILOT) \
            and plan.tools_to_consider:
        try:
            sim = self.simulate(strategy=plan.strategy,
                                  tools=plan.tools_to_consider[:3]).to_dict()
        except Exception:
            sim = None
    rec = {
        "ts": time.time(),
        "input": (user_text or "")[:140],
        "strategy": plan.strategy,
        "reasoning": plan.reasoning,
        "budget_ms": plan.budget_ms,
        "confidence": plan.confidence,
        "reflex_answer": reflex_answer,
        "skill_hint": skill_hint,
        "simulation": sim,
    }
    self._route_trace.append(rec)
    self._route_trace = self._route_trace[-200:]
    return rec


def _counters_snapshot(self) -> Dict[str, Any]:
    out = dict(self._counters)
    plan_calls = max(1, out.get("plan_calls", 0))
    out["cache_hit_rate"] = round(out.get("cache_hits", 0) / plan_calls, 3)
    total_routes = (out.get("claude_calls", 0) + out.get("reflex_calls", 0)
                     + out.get("canned_calls", 0) + out.get("tool_calls", 0)
                     + out.get("autopilot_calls", 0))
    if total_routes:
        out["claude_share"] = round(out.get("claude_calls", 0) / total_routes, 3)
        out["local_share"] = round(
            (out.get("reflex_calls", 0) + out.get("canned_calls", 0)
              + out.get("tool_calls", 0)) / total_routes, 3
        )
    return out


def _route_trace_recent(self, n: int = 50) -> List[Dict[str, Any]]:
    return self._route_trace[-n:]


# Attach Phase 14 methods to the class
ExecutiveController.simulate = _simulate
ExecutiveController.route = _route
ExecutiveController.counters = _counters_snapshot
ExecutiveController.route_trace = _route_trace_recent


__all__ = [
    "ExecutiveController", "ExecutivePlan",
    "STRATEGY_REFLEX_LOCAL", "STRATEGY_REFLEX_TOOL", "STRATEGY_CANNED",
    "STRATEGY_CLAUDE_FAST", "STRATEGY_CLAUDE_DEEP",
    "STRATEGY_AUTOPILOT", "STRATEGY_BACKGROUND",
]
