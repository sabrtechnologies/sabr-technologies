"""
Phase 12A — Hypothesis corroboration.

LLM-generated causal hypotheses (Phase 11B) sit with status='unverified' until
something checks whether reality keeps confirming the underlying A→B precedes
pattern. This module is that something.

How verification works
──────────────────────
For each unverified hypothesis (cause_action_name → effect_action_name):

  1. Pull all episodes since hypothesis.first_seen (only NEW evidence counts,
     so the LLM's training-time pattern doesn't bootstrap its own confirmation).
  2. Within each session, find every occurrence of the cause action; count
     how many were followed within 30s by the effect action.
  3. Compute fresh_ratio = follows / cause_occurrences.
  4. Apply the verdict bands:
       fresh_ratio >= 0.70 AND occurrences >= 5  → 'corroborated'
       fresh_ratio <= 0.30 AND occurrences >= 5  → 'contradicted'
       otherwise                                  → stay 'unverified'

Status updates are append-only to a SIDECAR file
brain_state/causal_hypothesis_status.jsonl. That keeps the source-of-truth
file (`causal_hypotheses.jsonl`) immutable and lets us roll back verification
by tail-truncating the sidecar. The sidecar reader uses latest-wins per key.

Corroborated hypotheses are exposed to the prompt builder so Leon's reasoning
can reference verified causal knowledge — a meaningful upgrade over the
free-floating raw hypotheses.
"""

from __future__ import annotations

import collections
import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.hypothesis_verify")


# Verdict thresholds — tunable but mirror the support floor used at hypothesis
# generation (Phase 11B uses min_support=5, min_confidence=0.7).
_CORROBORATE_RATIO = 0.70
_CONTRADICT_RATIO = 0.30
_MIN_OCCURRENCES = 5
_PRECEDES_WINDOW_MS = 30_000  # match the rule miner's window

# Cap on how many sessions × episodes we scan per pass — keep the verifier
# bounded even if the episode log grows.
_MAX_EPISODES_PER_PASS = 5000


def _default_status_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "causal_hypothesis_status.jsonl")


def _default_hypothesis_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "causal_hypotheses.jsonl")


def _hyp_key(cause: str, effect: str) -> str:
    return f"{cause}→{effect}"


@dataclass
class VerdictRecord:
    """One row in the sidecar status log."""
    key: str
    status: str                 # 'corroborated' | 'contradicted' | 'unverified'
    fresh_ratio: float
    occurrences: int            # cause-action count in the fresh window
    follows: int                # cause→effect-within-window count
    window_start_ts: float      # epoch sec — start of the evidence window
    verified_ts: float          # when this verdict was computed

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── core verifier ───────────────────────────────────────────────────────────

class HypothesisVerifier:
    """Walks unverified hypotheses, scans fresh episodes, writes verdicts."""

    def __init__(
        self,
        *,
        episodes,
        status_path: Optional[str] = None,
        hypothesis_path: Optional[str] = None,
    ):
        self.episodes = episodes
        self.status_path = status_path or _default_status_path()
        self.hypothesis_path = hypothesis_path or _default_hypothesis_path()
        os.makedirs(os.path.dirname(self.status_path), exist_ok=True)

    # ── public API ──────────────────────────────────────────────────────

    def verify_pass(self) -> Dict[str, Any]:
        """Run one verification pass over all unverified hypotheses.

        Returns a summary: {checked, corroborated, contradicted, still_unverified,
        skipped_insufficient_evidence}.
        """
        t0 = time.time()
        hypotheses = self._load_open_hypotheses()
        if not hypotheses:
            return {
                "checked": 0, "corroborated": 0, "contradicted": 0,
                "still_unverified": 0, "skipped": 0,
                "duration_s": round(time.time() - t0, 3),
            }
        existing_status = self.latest_status_map()

        # Build a single (action_name, session_id, ts, success) sequence so we
        # don't reload episodes for every hypothesis.
        sessions = self._fresh_session_episodes()

        result = collections.Counter()
        verdicts: List[VerdictRecord] = []
        for h in hypotheses:
            key = _hyp_key(h.get("cause", ""), h.get("effect", ""))
            # Skip already-decided (corroborated/contradicted are sticky).
            current = existing_status.get(key, {}).get("status", "unverified")
            if current in ("corroborated", "contradicted"):
                continue
            first_seen = float(h.get("first_seen") or 0.0)
            v = self._evaluate(
                cause=h["cause"], effect=h["effect"],
                first_seen=first_seen, sessions=sessions,
            )
            verdicts.append(v)
            result[v.status] += 1

        if verdicts:
            self._append_verdicts(verdicts)

        return {
            "checked": sum(result.values()),
            "corroborated": result.get("corroborated", 0),
            "contradicted": result.get("contradicted", 0),
            "still_unverified": result.get("unverified", 0),
            "skipped": len(hypotheses) - sum(result.values()),
            "duration_s": round(time.time() - t0, 3),
        }

    def latest_status_map(self) -> Dict[str, Dict[str, Any]]:
        """Read sidecar status file. Latest-wins per key. Empty if file missing."""
        out: Dict[str, Dict[str, Any]] = {}
        if not os.path.exists(self.status_path):
            return out
        try:
            with open(self.status_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                    except Exception:
                        continue
                    k = d.get("key")
                    if k:
                        out[k] = d  # latest wins because we iterate top-down
        except Exception as e:
            log.warning("status file read failed: %s", e)
        return out

    def corroborated_hypotheses(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Return hypotheses currently flagged 'corroborated'.

        Useful for prompt_builder — Leon's reasoning can cite these as
        verified causal claims (with the underlying pattern data still
        backing them).
        """
        status = self.latest_status_map()
        all_hyps = self._load_open_hypotheses()
        out: List[Dict[str, Any]] = []
        for h in all_hyps:
            key = _hyp_key(h.get("cause", ""), h.get("effect", ""))
            s = status.get(key, {})
            if s.get("status") == "corroborated":
                merged = dict(h)
                merged["status"] = "corroborated"
                merged["fresh_ratio"] = s.get("fresh_ratio")
                merged["occurrences"] = s.get("occurrences")
                merged["verified_ts"] = s.get("verified_ts")
                out.append(merged)
        # Most recently verified first.
        out.sort(key=lambda x: -(x.get("verified_ts") or 0))
        return out[:limit]

    def summary(self) -> Dict[str, Any]:
        """Aggregate counts across all stored hypotheses (live tally)."""
        status = self.latest_status_map()
        counts = collections.Counter(s.get("status", "unverified") for s in status.values())
        total_hyps = len(self._load_open_hypotheses())
        return {
            "total_hypotheses": total_hyps,
            "corroborated": counts.get("corroborated", 0),
            "contradicted": counts.get("contradicted", 0),
            "verified_unverified": counts.get("unverified", 0),
            "never_evaluated": max(0, total_hyps - sum(counts.values())),
        }

    # ── internals ───────────────────────────────────────────────────────

    def _load_open_hypotheses(self) -> List[Dict[str, Any]]:
        """Load hypotheses.jsonl, skipping 'touch' meta-records (M2)."""
        if not os.path.exists(self.hypothesis_path):
            return []
        try:
            with open(self.hypothesis_path) as f:
                lines = f.readlines()
        except Exception as e:
            log.warning("hypothesis read failed: %s", e)
            return []
        # Dedupe by (cause,effect) — first seen wins (the LLM hypothesis text
        # of record). Touch lines are skipped.
        out_by_key: Dict[str, Dict[str, Any]] = {}
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            if d.get("type") == "touch":
                continue
            c = d.get("cause"); e = d.get("effect")
            if not c or not e:
                continue
            key = _hyp_key(c, e)
            if key not in out_by_key:
                out_by_key[key] = d
        return list(out_by_key.values())

    def _fresh_session_episodes(self) -> Dict[str, List[Dict[str, Any]]]:
        """Pull recent episodes, group by session_id, sort by id ASC."""
        rows = self.episodes.recent(limit=_MAX_EPISODES_PER_PASS)
        sessions: Dict[str, List[Dict[str, Any]]] = collections.defaultdict(list)
        for r in rows:
            sid = r.get("session_id") or ""
            sessions[sid].append(r)
        for eps in sessions.values():
            eps.sort(key=lambda x: x.get("id", 0))
        return sessions

    def _evaluate(
        self,
        *,
        cause: str,
        effect: str,
        first_seen: float,
        sessions: Dict[str, List[Dict[str, Any]]],
    ) -> VerdictRecord:
        """Count cause→effect-within-30s pairs in episodes after first_seen."""
        occurrences = 0
        follows = 0
        for sid, eps in sessions.items():
            for i, ep in enumerate(eps):
                if (ep.get("ts") or 0) < first_seen:
                    continue
                if ep.get("action_name") != cause:
                    continue
                occurrences += 1
                # Look forward in same session for effect within window.
                a_ts = ep.get("ts", 0)
                for j in range(i + 1, len(eps)):
                    nxt = eps[j]
                    gap_ms = (nxt.get("ts", 0) - a_ts) * 1000
                    if gap_ms > _PRECEDES_WINDOW_MS:
                        break
                    if nxt.get("action_name") == effect:
                        follows += 1
                        break
        ratio = (follows / occurrences) if occurrences else 0.0
        # Determine verdict — sticky thresholds. Below min_occurrences we
        # explicitly emit 'unverified' so callers can tell "evaluated but
        # not enough evidence" from "never looked".
        if occurrences < _MIN_OCCURRENCES:
            status = "unverified"
        elif ratio >= _CORROBORATE_RATIO:
            status = "corroborated"
        elif ratio <= _CONTRADICT_RATIO:
            status = "contradicted"
        else:
            status = "unverified"
        return VerdictRecord(
            key=_hyp_key(cause, effect),
            status=status,
            fresh_ratio=round(ratio, 3),
            occurrences=occurrences,
            follows=follows,
            window_start_ts=first_seen,
            verified_ts=time.time(),
        )

    def _append_verdicts(self, verdicts: List[VerdictRecord]) -> None:
        try:
            with open(self.status_path, "a") as f:
                for v in verdicts:
                    f.write(json.dumps(v.to_dict()) + "\n")
            # Rotate: cap at 5K lines
            try:
                with open(self.status_path, "r") as f:
                    lines = f.readlines()
                if len(lines) > 5000:
                    with open(self.status_path, "w") as f:
                        f.writelines(lines[-2500:])
            except Exception:
                pass
        except Exception as e:
            log.warning("verdict append failed: %s", e)
