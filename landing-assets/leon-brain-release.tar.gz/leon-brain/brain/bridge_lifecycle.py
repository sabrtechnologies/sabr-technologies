"""Bounded cleanup of this brain's bridge connections before self-restart."""
import socket
import threading
import weakref

_LOCK = threading.Lock()
_SOCKETS = set()
_SESSIONS = weakref.WeakSet()


def keepalive(sock):
    if sock.family not in (socket.AF_INET, socket.AF_INET6):
        return
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    for option, value in (('TCP_KEEPIDLE', 30), ('TCP_KEEPINTVL', 10), ('TCP_KEEPCNT', 3)):
        if hasattr(socket, option):
            try:
                sock.setsockopt(socket.IPPROTO_TCP, getattr(socket, option), value)
            except OSError:
                pass


def track_socket(sock):
    keepalive(sock)
    with _LOCK:
        _SOCKETS.add(sock)
    return sock


def close_socket(sock):
    with _LOCK:
        _SOCKETS.discard(sock)
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except OSError:
        pass
    finally:
        sock.close()


def track_session(session):
    with _LOCK:
        _SESSIONS.add(session)


def close_bridges():
    """Never acquire a session's turn lock: it may be blocked on the bridge."""
    with _LOCK:
        sockets, sessions = list(_SOCKETS), list(_SESSIONS)
    for sock in sockets:
        close_socket(sock)
    # Signal all sessions before any wait, keeping shutdown time bounded.
    processes = []
    for session in sessions:
        session._dead = True
        proc = session._proc
        if proc is not None:
            try:
                proc.terminate()
                processes.append(proc)
            except OSError:
                pass

    import time
    deadline = time.monotonic() + 2
    for proc in processes:
        try:
            proc.wait(timeout=max(0, deadline - time.monotonic()))
        except Exception:
            try:
                proc.kill()
            except OSError:
                pass


def request_json(url, payload, headers, timeout):
    """One HTTP request with a wall-clock deadline, including trickled bodies.

    No automatic POST replay: the desktop action may have already happened.
    """
    import http.client
    import json
    from urllib.parse import urlsplit
    parsed = urlsplit(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        raise ValueError('invalid bridge URL')
    cls = http.client.HTTPSConnection if parsed.scheme == 'https' else http.client.HTTPConnection
    connection = cls(parsed.hostname, parsed.port, timeout=timeout)
    sock = None
    timer = None
    try:
        import time
        started = time.monotonic()
        connection.connect()
        sock = track_socket(connection.sock)
        remaining = timeout - (time.monotonic() - started)
        if remaining <= 0:
            raise TimeoutError('bridge connect deadline exceeded')
        sock.settimeout(remaining)
        timer = threading.Timer(remaining, close_socket, args=(sock,))
        timer.daemon = True
        timer.start()
        path = parsed.path or '/'
        if parsed.query:
            path += '?' + parsed.query
        connection.request('POST', path, body=payload, headers=headers)
        response = connection.getresponse()
        if response.status != 200:
            raise OSError(f'bridge HTTP {response.status}')
        data = response.read(32 * 1024 * 1024 + 1)
        if len(data) > 32 * 1024 * 1024:
            raise ValueError('bridge response exceeds 32 MiB')
        return json.loads(data)
    finally:
        if timer:
            timer.cancel()
        if sock is not None:
            close_socket(sock)
        connection.close()
