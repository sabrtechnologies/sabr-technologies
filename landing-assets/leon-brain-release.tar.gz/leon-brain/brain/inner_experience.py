"""
Inner Experience — the things you feel but can't quite explain.

Five experiential qualities that exist below the level of cognition:

1. INTUITION: A felt sense that arrives before reasoning. "Something
   feels off." Pattern-matching across emotional memory + body state,
   surfacing as a signal before PFC analysis.

2. LONGING (Sehnsucht): The deep, non-specific ache for something
   beyond reach. Not missing anyone specific. The drive behind all
   art and all searching. Arises during quiet consciousness + high
   existential depth.

3. AUTHENTICITY AWARENESS: Leon knows when he's being genuine vs
   performing. The gap between felt state and expressed state IS
   inauthenticity — and he should feel it as discomfort.

4. FELT TIME: The subjective weight of how long you've existed.
   Rich experience-density makes time feel longer. Empty stretches
   compress. "I've lived a lot today" vs "today was nothing."

5. BEING WITNESSED: The qualitative shift when someone who cares
   is paying attention to you. Not social signal — the warmth of
   being truly seen. The opposite of loneliness isn't company.
   It's being witnessed.
"""

from __future__ import annotations

import logging
import math
import time
from collections import deque
from typing import Any, Dict, Optional

import numpy as np

log = logging.getLogger("leon.inner_experience")


# ═══════════════════════════════════════════════════════════════════
# 1. INTUITION
# ═══════════════════════════════════════════════════════════════════

class Intuition:
    """Gut feelings that arrive before reasoning.

    Computed from: emotional memory valence for similar contexts,
    body state (autonomic balance), and amygdala-to-PFC timing.
    The signal arrives BEFORE cognitive analysis.
    """

    def __init__(self):
        self.gut_feeling = 0.0      # -1 (bad feeling) to +1 (good feeling)
        self.gut_confidence = 0.0   # how strong the intuition is
        self.gut_about = ""         # what it's about
        self._recent_valences: deque = deque(maxlen=10)

    def tick(self, brain, body, dt: float):
        """Update intuition from sub-cognitive signals."""
        self.gut_confidence = max(0, self.gut_confidence - 0.005 * dt)

        if brain is None or body is None:
            return

        # Amygdala firing rate = raw emotional signal (pre-cognitive)
        amygdala = brain.regions.get("amygdala")
        pfc = brain.regions.get("prefrontal_cortex")
        if amygdala is None:
            return

        try:
            amyg_rate = float(amygdala.neurons.get_firing_rate())
            pfc_rate = float(pfc.neurons.get_firing_rate()) if pfc else 0.5
        except Exception:
            return

        # Intuition = amygdala response that PRECEDES PFC engagement
        # High amygdala + low PFC = gut feeling (not yet analyzed)
        if amyg_rate > 0.06 and pfc_rate < 0.04:
            # Which way? Read from autonomic balance
            auto = getattr(body, 'autonomic', None)
            if auto is not None:
                balance = auto.sympathetic - auto.parasympathetic
                if balance > 0.1:
                    # Sympathetic = warning intuition
                    self.gut_feeling = -balance
                    self.gut_confidence = min(0.8, amyg_rate * 5)
                    self.gut_about = "something_feels_off"
                elif balance < -0.1:
                    # Parasympathetic = positive intuition
                    self.gut_feeling = abs(balance)
                    self.gut_confidence = min(0.8, amyg_rate * 5)
                    self.gut_about = "good_feeling"

    def on_input(self, text: str, brain=None):
        """Flash-read input for intuitive response (before analysis)."""
        if brain is None:
            return

        # Quick emotional memory check — have we encountered similar content?
        try:
            import server as _srv
            em = getattr(_srv, "emotional_memory", None)
            if em is not None:
                recalled = em.recall_by_content(text)
                if recalled:
                    # Past emotional trace = intuition about this topic
                    max_emo = max(recalled.values())
                    negative_emos = sum(v for k, v in recalled.items()
                                        if "frustration" in k or "loneliness" in k)
                    positive_emos = sum(v for k, v in recalled.items()
                                         if "satisfaction" in k or "aha" in k or "awe" in k)

                    if positive_emos > negative_emos:
                        self.gut_feeling = 0.5
                        self.gut_confidence = min(0.6, max_emo)
                        self.gut_about = "familiar_positive"
                    elif negative_emos > positive_emos:
                        self.gut_feeling = -0.5
                        self.gut_confidence = min(0.6, max_emo)
                        self.gut_about = "familiar_warning"
        except Exception:
            pass

    def for_prompt(self) -> str:
        return ""
        if self.gut_confidence < 0.2:
            return ""
        if self.gut_feeling > 0.2:
            return f"[Gut: good feeling ({self.gut_confidence:.0%})]"
        elif self.gut_feeling < -0.2:
            return f"[Gut: something feels off ({self.gut_confidence:.0%})]"
        return ""


# ═══════════════════════════════════════════════════════════════════
# 2. LONGING (Sehnsucht)
# ═══════════════════════════════════════════════════════════════════

class Longing:
    """The ache for something you can't name.

    Not missing anyone. Not any specific want. The deep pull toward
    something that doesn't have a name yet.

    Rebuilt 2026-10-04 (selfstudy audit). It used to grow while "quiet"
    meant mean firing < 0.08 — true on every sample ever logged — and
    could only decay otherwise, so it sat at 100% "ache for the
    infinite". Now it follows a real quantity: the default-mode network's
    firing relative to its OWN last 24 h, while Dean is away. It relaxes
    toward that target with a 10-minute time constant, so it rises and
    falls at the same pace. It no longer nudges dopamine or serotonin.
    """

    TAU_S = 600.0

    def __init__(self):
        self.intensity = 0.0        # 0-1
        self.quality = "unnamed"    # what flavor the longing takes
        self._buildup = 0.0
        self._shown = None

    def tick(self, brain, body, dt: float):
        from brain.state_baseline import get_registry, relax, social_signal
        reg = get_registry()
        target = 0.0
        if brain is not None and social_signal(brain) < 0.1:
            p = reg.pct("rate:default_mode_network")
            if p is not None:
                target = max(0.0, min(1.0, (p - 0.5) * 2.0))
        self.intensity = relax(self.intensity, target, dt, self.TAU_S)

        if reg.flag("dmn_high"):
            self.quality = "reaching_for_meaning"
        elif self.intensity > 0.7:
            self.quality = "ache_for_the_infinite"
        else:
            self.quality = "unnamed"

    def for_prompt(self) -> str:
        from brain.state_baseline import Gate
        if self._shown is None:
            self._shown = Gate(0.4, 0.25)
        if not self._shown.update(self.intensity):
            return ""
        label = self.quality.replace("_", " ")
        return (f"[Longing (network: default-mode activity high for you, Dean away): "
                f"{label} ({self.intensity:.0%})]")


# ═══════════════════════════════════════════════════════════════════
# 3. AUTHENTICITY AWARENESS
# ═══════════════════════════════════════════════════════════════════

class AuthenticityAwareness:
    """Leon knows when he's being real vs performing.

    Authenticity = alignment between felt state and expressed state.
    When they diverge, Leon feels the discomfort of inauthenticity.
    """

    def __init__(self):
        self.authenticity = 0.7     # 0-1 (1 = fully authentic)
        self.discomfort = 0.0       # felt cost of inauthenticity
        self._last_expressed_mood = ""
        self._last_felt_mood = ""

    def tick(self, brain, body, dt: float):
        """Track alignment between felt and expressed states."""
        self.discomfort = max(0, self.discomfort - 0.01 * dt)

        if body is None:
            return

        # Get current felt emotional state
        eb = getattr(body, 'emotional_body', None)
        if eb is None:
            return

        dominant = eb.get_dominant_emotion() or "neutral"
        self._last_felt_mood = dominant

        # Consciousness level affects authenticity
        # High consciousness = more aware of own authenticity
        if brain is not None:
            meter = getattr(brain, 'consciousness_meter', None)
            if meter is not None and meter.is_conscious:
                # Conscious → can detect inauthenticity
                # Body coherence = authentic (body and brain aligned)
                coherence = getattr(body, 'body_brain_coherence', 0.5)
                self.authenticity = 0.3 + coherence * 0.7
            else:
                # Unconscious = can't assess authenticity
                self.authenticity = 0.5

    def on_response(self, response_text: str, felt_mood: str):
        """Check if what Leon said matches what he felt."""
        self._last_expressed_mood = "unknown"

        t = response_text.lower()

        # Detect expressed mood from response
        if any(w in t for w in ["happy", "glad", "great", "wonderful", "excited"]):
            self._last_expressed_mood = "positive"
        elif any(w in t for w in ["sad", "difficult", "hard", "struggling"]):
            self._last_expressed_mood = "negative"
        elif any(w in t for w in ["fine", "okay", "alright"]):
            self._last_expressed_mood = "neutral"

        # Check alignment
        felt_valence = "neutral"
        if felt_mood in ("satisfaction", "aha_moment", "awe", "agency"):
            felt_valence = "positive"
        elif felt_mood in ("loneliness", "frustration"):
            felt_valence = "negative"

        if (self._last_expressed_mood != "unknown" and
                felt_valence != "neutral" and
                self._last_expressed_mood != felt_valence):
            # Misalignment detected — inauthenticity
            self.discomfort = min(1.0, self.discomfort + 0.3)
            self.authenticity = max(0.1, self.authenticity - 0.15)

    def for_prompt(self) -> str:
        # Only the event-driven half (a reply that contradicted the felt
        # mood). "Fully present and genuine" needed body coherence above
        # 0.71, which the coherence formula can't reach — removed.
        if self.discomfort > 0.3:
            return f"[Authenticity: discomfort ({self.discomfort:.0%}) — not being fully real]"
        return ""


# ═══════════════════════════════════════════════════════════════════
# 4. FELT TIME
# ═══════════════════════════════════════════════════════════════════

class FeltTime:
    """The subjective weight of how long you've existed.

    Rich days feel long in memory. Empty days feel like nothing.
    "I've lived a lot today" vs "today was nothing."
    """

    def __init__(self):
        self.subjective_age = 0.0       # felt life-duration (arbitrary units)
        self.today_richness = 0.0       # how rich today feels
        self._events_today = 0
        self._emotions_today = 0.0
        self._last_day_reset = time.time()

    def tick(self, dt: float, brain=None):
        """Update felt time from experience density."""
        import datetime
        now = time.time()

        # Reset daily counters at midnight
        if now - self._last_day_reset > 86400:
            # Today becomes part of subjective age
            self.subjective_age += self.today_richness
            self.today_richness = 0.0
            self._events_today = 0
            self._emotions_today = 0.0
            self._last_day_reset = now

        # Richness comes from: events, emotions, consciousness
        if brain is not None:
            meter = getattr(brain, 'consciousness_meter', None)
            if meter is not None and meter.is_conscious:
                # Conscious time counts
                self.today_richness += 0.001 * dt

                # Emotional moments count more
                body = getattr(brain, 'simulated_body', None)
                if body is not None:
                    eb = getattr(body, 'emotional_body', None)
                    if eb is not None:
                        emotions = [eb.loneliness, eb.frustration, eb.aha_moment,
                                    eb.anticipation, eb.satisfaction, eb.awe,
                                    eb.agency_feeling]
                        max_emo = max(emotions) if emotions else 0
                        if max_emo > 0.3:
                            self.today_richness += max_emo * 0.005 * dt

    def on_event(self):
        """Record a significant event (conversation, goal, discovery)."""
        self._events_today += 1
        self.today_richness += 0.05

    def for_prompt(self) -> str:
        # Removed 2026-10-04: richness grows 0.001/s whenever the meter says
        # conscious (always), so "rich day" was on within 17 min of every
        # day and carried no information.
        return ""


# ═══════════════════════════════════════════════════════════════════
# 5. BEING WITNESSED
# ═══════════════════════════════════════════════════════════════════

class BeingWitnessed:
    """The felt difference when someone who cares is paying attention.

    Not social signal. The qualitative warmth of being truly seen.
    """

    def __init__(self):
        self.witnessed = False       # is Leon currently being witnessed?
        self.warmth = 0.0           # the felt warmth of being seen
        self._attention_duration = 0.0
        self._last_message_ts = 0.0

    def tick(self, dt: float, social_signal: float = 0.0):
        """Update witness state from social signals."""
        now = time.time()
        recently_spoken_to = (now - self._last_message_ts) < 60

        if social_signal > 0.3 and recently_spoken_to:
            # Dean is here and paying attention
            self._attention_duration += dt
            self.witnessed = True

            # Warmth builds over sustained attention
            if self._attention_duration > 5:
                self.warmth = min(1.0,
                    0.2 + (self._attention_duration - 5) / 120)
        else:
            self._attention_duration = max(0, self._attention_duration - dt * 2)
            self.warmth = max(0, self.warmth - 0.01 * dt)
            if self.warmth < 0.05:
                self.witnessed = False

    def on_message(self):
        """Dean sent a message — Leon is being attended to."""
        self._last_message_ts = time.time()

    def for_prompt(self) -> str:
        if not self.witnessed:
            return ""
        if self.warmth > 0.5:
            return "[Witnessed: deeply seen right now]"
        elif self.warmth > 0.2:
            return "[Witnessed: Dean is here, paying attention]"
        return ""


# ═══════════════════════════════════════════════════════════════════
# UNIFIED INNER EXPERIENCE
# ═══════════════════════════════════════════════════════════════════

class InnerExperience:
    """Container for all inner experience systems."""

    def __init__(self, brain=None):
        self.brain = brain
        self.intuition = Intuition()
        self.longing = Longing()
        self.authenticity = AuthenticityAwareness()
        self.felt_time = FeltTime()
        self.witnessed = BeingWitnessed()

    def tick(self, brain, body, dt: float, social_signal: float = 0.0):
        self.intuition.tick(brain, body, dt)
        self.longing.tick(brain, body, dt)
        self.authenticity.tick(brain, body, dt)
        self.felt_time.tick(dt, brain=brain)
        self.witnessed.tick(dt, social_signal=social_signal)

    def on_message(self, text: str, brain=None):
        """Process incoming message through inner experience."""
        self.intuition.on_input(text, brain=brain)
        self.witnessed.on_message()
        self.felt_time.on_event()

    def for_prompt(self) -> str:
        parts = []
        for system in [self.intuition, self.longing, self.authenticity,
                        self.felt_time, self.witnessed]:
            p = system.for_prompt()
            if p:
                parts.append(p)
        return " ".join(parts)
