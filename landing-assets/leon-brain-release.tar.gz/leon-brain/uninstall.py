#!/usr/bin/env python3
"""Sabr SI — Uninstall (cross-platform entry point).

    python uninstall.py              show what WOULD be removed, touch nothing
    python uninstall.py --yes        actually remove it

Flags:
    --yes                   perform the removal (without this, nothing is deleted)
    --purge-memories        delete brain_state outright instead of archiving it
    --remove-claude-code    also remove the global @anthropic-ai/claude-code package

Why this file exists
--------------------
The only uninstaller that shipped was uninstall.sh. Bash. On Windows that is
not a broken uninstaller, it is no uninstaller — nothing runs it, so a Windows
owner had literally no supported way to remove the SI, and every reinstall
inherited the previous SI's autostart task, Startup shortcut and ~/.leon
cognition databases.

On Windows this module does the removal itself, natively.
On Linux/macOS it hands off to uninstall.sh, which is already proven there;
this file is the single command a user can be told to run on any OS.

The two rules from uninstall.sh are preserved exactly:

  1. The SI's identity — .env, brain_state, and ~/.leon (the skills, lessons,
     reflections and tool health it actually learned) — is archived BEFORE
     anything is deleted, and the uninstall REFUSES to continue if that
     archive cannot be written.

  2. It does not remove what it did not install. Python, Node, your Claude
     Code login: reported with the exact command to remove them yourself,
     never removed for you.

Note the .leon probe sits OUTSIDE the "is there anything to keep" guard, for
the same reason it does in the shell version: on a tree with no .env or
brain_state yet, an inside-the-guard probe skips the archive while still
deleting ~/.leon. That is data loss, and it is the exact bug caught in the
shell script's container run.
"""

import argparse
import re
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HOME = Path.home()
SYSTEM = platform.system()
AUTOSTART_TASK = "Sabr SI"
# Every ONLOGON task name that has ever started an SI. We create only the
# first; we DELETE all of them, same policy as STARTUP_BATS.
AUTOSTART_TASKS = (AUTOSTART_TASK, "SabrSI", "Sabr_SI", "SabrSI Autostart")
STARTUP_BAT = "Sabr SI.bat"
COGNITION = HOME / ".leon"

# Kept in sync with uninstall.sh deliberately: both scripts must agree on what
# counts as "the SI's identity", or the two platforms archive different things.
KEEP_NAMES = (".env", "brain_state")

G, Y, R, C, D, N = "\033[32m", "\033[33m", "\033[31m", "\033[36m", "\033[2m", "\033[0m"
if SYSTEM == "Windows" and not os.environ.get("WT_SESSION"):
    # Old conhost does not render ANSI. Colour codes as literal garbage in an
    # uninstaller reads as "this thing is broken" right when trust matters.
    G = Y = R = C = D = N = ""


def say(msg=""):
    print(msg, flush=True)


def human(n):
    for unit in ("B", "K", "M", "G"):
        if n < 1024:
            return f"{n:.0f}{unit}"
        n /= 1024
    return f"{n:.0f}T"


def dir_size(p: Path):
    total = 0
    for dirpath, _, names in os.walk(p, onerror=lambda e: None):
        for name in names:
            try:
                total += (Path(dirpath) / name).stat().st_size
            except OSError:
                pass
    return total


def size_of(p: Path):
    try:
        if p.is_dir():
            return human(dir_size(p))
        if p.exists():
            return human(p.stat().st_size)
    except OSError:
        pass
    return "-"


# ── Windows discovery ────────────────────────────────────────────────────

#: Two installers write two DIFFERENT Startup filenames: install_client.py
#: writes "Sabr SI.bat", the GUI installer (sabr_installer.py) writes
#: "SabrSI.bat". This uninstaller only ever knew the first, so anyone who
#: installed via the downloaded EXE and then uninstalled kept a Startup entry
#: that opens a console at EVERY sign-in, forever, and runs an infinite
#: retry loop relaunching an SI that no longer exists. Know both names.
STARTUP_BATS = (STARTUP_BAT, "SabrSI.bat")


def startup_dir() -> Path:
    appdata = os.environ.get("APPDATA") or (HOME / "AppData" / "Roaming")
    return (Path(appdata) / "Microsoft" / "Windows" / "Start Menu"
            / "Programs" / "Startup")


#: THIRD SPELLING, found live on a real Windows install 2026-09-04: the GUI
#: installer had moved on to "SabrSI.vbs" (a WScript shim, so no console
#: window flashes at sign-in) while this uninstaller still only knew two .bat
#: names. Result reproduced end to end: uninstall printed "auto-start  none",
#: deleted the whole tree, and left SabrSI.vbs behind pointing at a
#: sabr_si_run.bat that no longer exists — a failing launch at EVERY sign-in,
#: forever, for software the customer removed.
#:
#: Chasing filenames is what failed twice. Discovery is now CONTENT-BASED:
#: anything in the Startup folder that names this install (by path, or by the
#: sabr_si_run launcher, or by an obvious SabrSI filename) is ours, whatever
#: extension the installer invents next. .lnk is binary and may hold the path
#: as UTF-16, so the needle is searched in both encodings.
_STARTUP_SUFFIXES = {".bat", ".cmd", ".vbs", ".ps1", ".lnk", ".js", ".exe"}
_STARTUP_NAME_RE = re.compile(r"^sabr[ _\-]?si\b.*", re.IGNORECASE)


def _startup_entry_is_ours(path: Path) -> bool:
    """True if this Startup entry belongs to this product."""
    if _STARTUP_NAME_RE.match(path.name):
        return True
    if path.suffix.lower() not in _STARTUP_SUFFIXES:
        return False
    try:
        blob = path.read_bytes()
    except OSError:
        return False
    for needle in (str(ROOT), "sabr_si_run", "SabrSI"):
        raw = needle.encode("utf-8", "ignore").lower()
        if raw and raw in blob.lower():
            return True
        wide = needle.encode("utf-16-le", "ignore").lower()
        if wide and wide in blob.lower():
            return True
    return False


def startup_shortcuts() -> list:
    """Every Startup entry belonging to this install, discovered not guessed.

    Keeps the two historical .bat names unconditionally (so a dry-run still
    names them) and adds anything else in the folder that points at us.
    """
    d = startup_dir()
    found = [d / name for name in STARTUP_BATS]
    seen = {p.name.lower() for p in found}
    try:
        entries = sorted(d.iterdir())
    except OSError:
        entries = []
    for entry in entries:
        if entry.name.lower() in seen or not entry.is_file():
            continue
        if _startup_entry_is_ours(entry):
            found.append(entry)
            seen.add(entry.name.lower())
    return found


def startup_shortcut() -> Path:
    """The one that's actually there, for display; falls back to canonical."""
    for p in startup_shortcuts():
        if p.exists():
            return p
    return startup_dir() / STARTUP_BAT


def scheduled_task_exists() -> bool:
    try:
        # Detection must be as wide as removal, or the uninstaller reports
        # "no auto-start found" on a machine that very much has one.
        for _task in AUTOSTART_TASKS:
            r = subprocess.run(["schtasks", "/query", "/tn", _task],
                               capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                return True
        return False
    except (OSError, subprocess.SubprocessError):
        return False


def running_pids():
    """PIDs of processes running THIS install's interpreter.

    Scoped to the install tree exactly like the shell version, so an unrelated
    python.exe belonging to the user's own work is never killed.
    """
    scripts = ROOT / ".venv" / "Scripts"
    # pythonw.exe, not just python.exe. An autostart entry that must not flash a
    # console window is launched with pythonw — which is exactly how the SI is
    # started at logon. Matching only python.exe reports "running: no" for the
    # one process that is always running, so nothing gets stopped and rmtree
    # then fails on files the live SI still holds open.
    exes = [scripts / "python.exe", scripts / "pythonw.exe"]
    exes = [e for e in exes if e.exists()]
    if not exes:
        return []

    def esc(p):
        return str(p).replace(chr(92), chr(92) * 2)

    filt = " or ".join(f"ExecutablePath='{esc(e)}'" for e in exes)
    out = ""
    try:
        r = subprocess.run(["wmic", "process", "where", f"({filt})",
                            "get", "ProcessId"],
                           capture_output=True, text=True, timeout=30)
        out = r.stdout
    except (OSError, subprocess.SubprocessError):
        out = ""
    if not out.strip():
        # wmic is deprecated and absent on newer Windows 11 images. PowerShell
        # CIM is the supported replacement; try it before concluding "nothing
        # is running", because a false negative here means we delete the tree
        # out from under a live process.
        try:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 f"Get-CimInstance Win32_Process -Filter \"{filt}\" "
                 f"| Select-Object -ExpandProperty ProcessId"],
                capture_output=True, text=True, timeout=60)
            out = r.stdout
        except (OSError, subprocess.SubprocessError):
            out = ""

    # NEVER include this process or its parent. The documented command is
    # `python uninstall.py`, and if that python IS the install's venv python,
    # a bare taskkill /T /F kills the uninstaller partway through: identity
    # archived, autostart still registered, tree still on disk, and no error
    # printed because the process that would have printed it is gone.
    mine = {os.getpid(), os.getppid()}
    pids = [int(t) for t in out.split() if t.isdigit() and int(t) not in mine]
    for extra in supervisor_pids():
        if extra not in pids and extra not in mine:
            pids.append(extra)
    return pids


def supervisor_pids():
    """PIDs of NON-python processes that keep this install alive.

    The SI is not started as a bare python.exe. It is started as
        cmd.exe /K "<install>\\sabr_si_run.bat"
    and that batch file relaunches run.py whenever run.py exits. Matching only
    the venv interpreter therefore kills the child and leaves the parent, which
    immediately starts a NEW child — so the tree can never be removed, and the
    uninstall reports nothing wrong because by the time it looks again there is
    (once more) a live SI. Measured on a real Windows install: pids changed
    between the kill and the check, and the whole 410M tree survived.

    Anything whose command line points inside the install tree counts, minus
    this process and its parent.
    """
    root = str(ROOT)
    ps = (
        "Get-CimInstance Win32_Process | "
        "Where-Object { $_.CommandLine -and "
        f"$_.CommandLine.ToLower().Contains('{root.lower()}'.ToLower()) }} | "
        "Select-Object -ExpandProperty ProcessId"
    )
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           capture_output=True, text=True, timeout=60)
        out = r.stdout
    except (OSError, subprocess.SubprocessError):
        return []
    mine = {os.getpid(), os.getppid()}
    return [int(t) for t in out.split() if t.isdigit() and int(t) not in mine]


# ── Archive ──────────────────────────────────────────────────────────────

def build_archive(purge_memories: bool) -> Path | None:
    """Archive identity + learned cognition. Returns path, or None if nothing
    needed archiving. Raises RuntimeError if an archive was needed and failed."""
    members = []
    for name in KEEP_NAMES:
        if name == "brain_state" and purge_memories:
            continue
        p = ROOT / name
        if p.exists():
            members.append((p, name))
    # OUTSIDE the guard above — see module docstring.
    if COGNITION.is_dir():
        members.append((COGNITION, ".leon"))

    if not members:
        return None

    stamp = time.strftime("%Y%m%d-%H%M%S")
    archive = HOME / f"sabr-si-identity-{stamp}.tar.gz"
    say("")
    say("Saving identity before removing anything...")
    try:
        with tarfile.open(archive, "w:gz") as tar:
            for src, arcname in members:
                tar.add(src, arcname=arcname)
        if archive.stat().st_size == 0:
            raise OSError("archive is empty")
        # Holds .env — live API keys in plaintext. Owner-only from birth.
        try:
            os.chmod(archive, 0o600)
        except OSError:
            pass
    except (OSError, tarfile.TarError) as e:
        try:
            archive.unlink()
        except OSError:
            pass
        raise RuntimeError(str(e)) from e
    say(f"{G}[OK]{N} {archive}  ({size_of(archive)})")
    return archive


# ── Removal steps ────────────────────────────────────────────────────────

def stop_running(pids, dry):
    if not pids:
        return
    say("Stopping the SI...")
    if dry:
        say(f"  {D}would stop pid(s): {' '.join(map(str, pids))}{N}")
        return
    # Supervisors first, then children. Killing a child while its relauncher is
    # alive just produces a new child with a new pid; the check below then sees
    # "something is running" forever. Order matters, and so does re-discovering
    # pids each round instead of trusting the list we walked in with.
    supers = set(supervisor_pids())
    ordered = [p for p in pids if p in supers] + [p for p in pids if p not in supers]
    still = ordered
    for _ in range(10):
        for pid in still:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           capture_output=True, timeout=30)
        time.sleep(1.5)
        # Re-discover from scratch: the relauncher hands out NEW pids, so an
        # "is it dead yet" check against the original list always says yes.
        still = running_pids()
        if not still:
            break
    if still:
        say(f"{Y}[WARN]{N} still running: {' '.join(map(str, still))}"
            f" — remove may leave files behind")
    else:
        say(f"{G}[OK]{N} stopped")


def remove_autostart(has_task, shortcut, dry):
    """MUST run before the tree is deleted.

    A leftover ONLOGON task pointing at a start.bat that no longer exists makes
    Windows pop a console and fail on every single sign-in, forever, for
    software the user uninstalled. That is the Windows twin of the stale
    systemd unit the shell version guards against.
    """
    if has_task:
        if dry:
            say(f"  {D}would remove scheduled task \"{AUTOSTART_TASK}\"{N}")
        else:
            # Sweep every spelling for the same reason STARTUP_BATS exists:
            # a task registered under a near-miss name (found live as
            # "SabrSI", no space, on 2026-08-12) survives an uninstall that
            # only knows its own constant, and fails at every sign-in forever.
            r = None
            for _task in AUTOSTART_TASKS:
                _r = subprocess.run(["schtasks", "/delete", "/tn", _task, "/f"],
                                    capture_output=True, text=True, timeout=30)
                if _r.returncode == 0:
                    r = _r
            if r is not None:
                say(f"{G}[OK]{N} removed auto-start (scheduled task)")
            else:
                say(f"{Y}[WARN]{N} could not remove scheduled task — remove it with: "
                    f"schtasks /delete /tn \"{AUTOSTART_TASK}\" /f")
    # Remove EVERY known Startup filename, not just the one this uninstaller
    # happened to write — see STARTUP_BATS. `shortcut` is kept as a parameter
    # for callers/display, but removal sweeps the whole set.
    for path in startup_shortcuts():
        if not path.exists():
            continue
        if dry:
            say(f"  {D}would remove {path}{N}")
        else:
            try:
                path.unlink()
                say(f"{G}[OK]{N} removed auto-start (Startup folder: {path.name})")
            except OSError as e:
                say(f"{Y}[WARN]{N} could not remove {path}: {e}")


def remove_tree(path: Path, label, dry, state):
    if not path.exists():
        return
    if dry:
        say(f"  {D}would remove {path}  ({size_of(path)}){N}")
        return
    shutil.rmtree(path, ignore_errors=True)
    if path.exists():
        say(f"{R}[FAILED]{N} {path} is still there — check permissions "
            f"(a file may still be open)")
        state["failed"] = True
    else:
        say(f"{G}[OK]{N} removed {label}")


# ── Windows uninstall ────────────────────────────────────────────────────

def uninstall_windows(args) -> int:
    dry = not args.yes
    state = {"failed": False}

    has_task = scheduled_task_exists()
    shortcut = startup_shortcut()
    pids = running_pids()

    say("")
    say(f"{C}Sabr SI — uninstall{N}")
    say(f"  install     {ROOT}  ({size_of(ROOT)})")
    say(f"  cognition   {COGNITION}  "
        f"({size_of(COGNITION) if COGNITION.is_dir() else 'not present'})")
    say(f"  auto-start  "
        f"{'scheduled task' if has_task else ''}"
        f"{' + ' if has_task and shortcut.exists() else ''}"
        f"{'Startup folder' if shortcut.exists() else ''}"
        f"{'none' if not has_task and not shortcut.exists() else ''}")
    say(f"  running     {'yes, pid ' + ' '.join(map(str, pids)) if pids else 'no'}")

    if dry:
        say("")
        say(f"{Y}Dry run — nothing has been removed.{N}")
        say("This is what would happen:")
        if COGNITION.is_dir() or any((ROOT / n).exists() for n in KEEP_NAMES):
            say(f"  {D}would archive identity + learned cognition to "
                f"{HOME}\\sabr-si-identity-<timestamp>.tar.gz{N}")
        stop_running(pids, dry=True)
        remove_autostart(has_task, shortcut, dry=True)
        remove_tree(ROOT, "install tree", True, state)
        remove_tree(COGNITION, "cognition", True, state)
        say("")
        say(f"Run it for real with:  {C}python uninstall.py --yes{N}")
        return 0

    # STOP FIRST, THEN ARCHIVE. This ordering is load-bearing and was inverted
    # here until 2026-08-11 — uninstall.sh already carries the comment for why
    # (caught 2026-08-10): archiving a LIVE SI reads brain_state while it is
    # being written, so the identity archive is a torn snapshot — sqlite mid-WAL,
    # half-flushed state — or the archive outright fails because Windows will not
    # let you read a file another process holds. The archive is the one thing the
    # owner cannot rebuild, so it must be taken of a stopped, quiet install.
    stop_running(pids, dry=False)

    try:
        archive = build_archive(args.purge_memories)
    except RuntimeError as e:
        say("")
        say(f"{R}[STOPPED]{N} Could not write the identity archive: {e}")
        say("Nothing has been removed. Free some space (or pass --purge-memories")
        say("if you genuinely want this SI's memories deleted) and run this again.")
        return 1

    remove_autostart(has_task, shortcut, dry=False)
    remove_tree(COGNITION, f"{COGNITION} (learned skills, lessons, reflections)",
                False, state)
    # The install tree last: this file lives inside it, and on Windows a
    # directory cannot be removed while it is any process's cwd.
    os.chdir(HOME)
    remove_tree(ROOT, str(ROOT), False, state)

    say("")
    say(f"{C}Left behind, on purpose:{N}")
    if archive:
        say(f"  · {G}{archive}{N} — this SI's identity and memories.")
        say(f"    {Y}It contains .env — real API keys. Treat it like a password file.{N}")
        say(f"    {D}To bring this SI back: reinstall, then BEFORE its first boot run{N}")
        say(f"    {C}python leon-brain\\restore_identity.py {archive}{N}")
        say(f"    {D}Do not just untar it — .leon belongs in your home directory,{N}")
        say(f"    {D}not in the install, and a plain untar hides it from the SI.{N}")
        say(f"    {D}Delete the archive yourself when you are sure.{N}")
    if args.remove_claude_code:
        # This flag is documented and parsed. Until now the Windows path simply
        # ignored it — the user asked for a removal, got a success message, and
        # the package was still installed. A silently-ignored destructive flag
        # is worse than no flag.
        r = subprocess.run(["npm", "rm", "-g", "@anthropic-ai/claude-code"],
                           capture_output=True, text=True, timeout=300,
                           shell=True)
        if r.returncode == 0:
            say(f"  · {G}removed @anthropic-ai/claude-code{N} (you asked with "
                f"--remove-claude-code)")
        else:
            say(f"  · {Y}could not remove @anthropic-ai/claude-code{N} — do it "
                f"with:  npm rm -g @anthropic-ai/claude-code")
        say(f"  · {D}Your Claude Code login and Node itself were left alone.{N}")
    else:
        say(f"  · {D}Python, Node and your Claude Code login — shared with the rest of{N}")
        say(f"    {D}your machine and may predate this product. Remove Claude Code{N}")
        say(f"    {D}yourself with:  npm rm -g @anthropic-ai/claude-code{N}")

    if state["failed"]:
        say("")
        say(f"{Y}Finished with problems — see [FAILED] above.{N}")
        return 1
    say("")
    say(f"{G}Done.{N}")
    return 0


# ── Entry ────────────────────────────────────────────────────────────────

def _interpreter_is_inside_tree() -> bool:
    """True when the running python.exe lives inside the tree we're deleting.

    On Windows a running executable and its loaded DLLs are locked by the OS.
    The obvious way to run this — the venv python that shipped with the SI —
    therefore CANNOT delete its own .venv: shutil.rmtree walks past the locked
    files, ignore_errors=True swallows the denial, and the user is left with a
    half-removed install that still looks installed. Linux/macOS unlink open
    files happily, which is exactly why this only ever bites on Windows.
    """
    try:
        Path(sys.executable).resolve().relative_to(ROOT)
        return True
    except (ValueError, OSError):
        return False


def _external_python() -> str | None:
    """Find a python interpreter that is NOT inside the install tree."""
    seen = []
    for name in ("python", "python3", "python.exe", "python3.exe"):
        p = shutil.which(name)
        if p:
            seen.append(p)
    for launcher in ("py",):
        exe = shutil.which(launcher)
        if not exe:
            continue
        try:
            r = subprocess.run([exe, "-3", "-c", "import sys;print(sys.executable)"],
                               capture_output=True, text=True, timeout=20)
            if r.returncode == 0 and r.stdout.strip():
                seen.append(r.stdout.strip())
        except (OSError, subprocess.SubprocessError):
            pass
    for cand in seen:
        try:
            Path(cand).resolve().relative_to(ROOT)
        except (ValueError, OSError):
            if Path(cand).exists():
                return cand
    return None


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--purge-memories", action="store_true")
    ap.add_argument("--remove-claude-code", action="store_true")
    args = ap.parse_args()

    # ROOT is derived from this script's own location, so a copy dropped
    # anywhere — home, Downloads, a USB stick — silently redefines "the install
    # tree we are about to delete" as that directory. Found 2026-08-10 by
    # placing this file in the user's HOME: ROOT became C:\Users\<name>, the
    # interpreter-inside-tree guard then matched the SYSTEM python (which lives
    # under AppData), and the only reason nothing was destroyed is that the
    # guard aborted for an unrelated reason. Prove ROOT is a real install
    # before any deletion logic gets a vote.
    markers = [ROOT / "run.py", ROOT / "brain", ROOT / "server"]
    missing = [m.name for m in markers if not m.exists()]
    if missing:
        say("")
        say(f"{R}[ERROR]{N} {ROOT} does not look like an SI install "
            f"(missing: {', '.join(missing)}).")
        say(f"  {D}This script deletes the directory it lives in. Move it into"
            f" the install folder and run it from there.{N}")
        return 1

    if SYSTEM == "Windows":
        if args.yes and _interpreter_is_inside_tree():
            ext = _external_python()
            if ext is None:
                say("")
                say(f"{R}[ERROR]{N} refusing to uninstall with the SI's own python.")
                say(f"  {D}Windows locks a running executable, so this interpreter"
                    f" cannot delete the .venv it lives in — you would be left"
                    f" with a half-removed install.{N}")
                say(f"  Install python from python.org, then run:")
                say(f'    python "{Path(__file__).resolve()}" --yes')
                return 1
            say(f"{D}re-running with {ext} (the SI's own python cannot delete"
                f" itself on Windows){N}")
            return subprocess.run([ext, str(Path(__file__).resolve()),
                                   *sys.argv[1:]], cwd=str(HOME)).returncode
        return uninstall_windows(args)

    sh = ROOT / "uninstall.sh"
    if not sh.exists():
        say(f"{R}[ERROR]{N} {sh} is missing — cannot uninstall on {SYSTEM}.")
        return 1
    cmd = ["bash", str(sh)]
    if args.yes:
        cmd.append("--yes")
    if args.purge_memories:
        cmd.append("--purge-memories")
    if args.remove_claude_code:
        cmd.append("--remove-claude-code")
    return subprocess.run(cmd).returncode


if __name__ == "__main__":
    sys.exit(main())
