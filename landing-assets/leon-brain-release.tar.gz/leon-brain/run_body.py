#!/usr/bin/env python3
"""Sabr SI — body-only entry point (hosted-brain mode).

When the brain is hosted, this machine runs the BODY: senses stream OUT
(sensor_relay POSTs mic/screen/webcam to the brain over HTTPS) and hands
commands come DOWN an outbound WebSocket this process holds open to the
brain (NAT/firewall-friendly: the customer's machine only ever dials out,
nothing listens on the internet).

Components supervised here (restarted with backoff if they die):
  actuator.py     — local hands, uid-restricted Unix socket
  sensor_relay.py — senses → POST {brain}/api/relay/*
  hands bridge    — WS client {brain}/ws/body (Bearer auth) → local actuator

Config comes from .env written by the installer (LEON_BRAIN_URL,
LEON_TENANT_TOKEN, LEON_SI_NAME).
"""

from __future__ import annotations

import asyncio
import json
import os
import signal
import subprocess
import sys
import time
import urllib.parse

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "leon-actuator"))
# AF_UNIX on posix, loopback TCP + rendezvous token on Windows. This module
# used to be called actuator_transport with a request() helper; the live tree
# renamed it and connect() now returns (socket, token-or-None) — the framing
# below mirrors brain/actuator_client.py's _call_socket exactly.
import leon_transport


def load_env():
    path = os.path.join(ROOT, ".env")
    if os.path.exists(path):
        # utf-8 pinned: the installer writes this file as UTF-8, so a
        # locale read on Windows mojibakes an accented name at best and
        # raises UnicodeDecodeError at worst. This is the hosted client's
        # entry point — it fails before the body ever connects.
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                os.environ.setdefault(k.strip(), v.strip())


class Child:
    """A supervised subprocess with restart backoff."""

    def __init__(self, name: str, argv: list):
        self.name, self.argv = name, argv
        self.proc = None
        self.backoff = 2

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self):
        print(f"[BODY] starting {self.name}", flush=True)
        self.proc = subprocess.Popen(self.argv, cwd=ROOT)

    def tend(self):
        if self.alive():
            self.backoff = 2
            return
        if self.proc is not None:
            print(f"[BODY] {self.name} exited ({self.proc.returncode}); "
                  f"restarting in {self.backoff}s", flush=True)
            time.sleep(self.backoff)
            self.backoff = min(self.backoff * 2, 60)
        self.start()


def build_children(host: str, port: int, scheme: str) -> list:
    """The subprocesses this entry point supervises. Factored out of main()
    so tests can assert every spawned script actually exists in the tree
    without starting anything."""
    py = sys.executable
    return [
        Child("actuator", [py, os.path.join(ROOT, "leon-actuator", "actuator.py")]),
        Child("sensors", [py, os.path.join(ROOT, "sensor_relay.py"),
                          "--host", host, "--port", str(port), "--scheme", scheme]),
    ]


def actuator_call(payload: dict, timeout: float = 30.0) -> dict:
    """One JSON-RPC round trip on the local actuator socket.

    Live convention (see brain/actuator_client.py:_call_socket):
    leon_transport.connect(timeout) -> (socket, token_or_None); when a token
    comes back (Windows loopback-TCP transport) it must be attached to the
    request dict as "token", and framing is one newline-terminated JSON line
    each way.
    """
    s, tok = leon_transport.connect(timeout)
    if tok:
        payload = dict(payload)
        payload["token"] = tok
    data = (json.dumps(payload) + "\n").encode("utf-8")
    try:
        s.sendall(data)
        buf = b""
        deadline = time.time() + timeout
        while not buf.endswith(b"\n"):
            if time.time() > deadline:
                return {"ok": False, "error": "actuator response timeout"}
            chunk = s.recv(65536)
            if not chunk:
                break
            buf += chunk
    finally:
        s.close()
    if not buf:
        return {"ok": False, "error": "empty actuator response"}
    return json.loads(buf.decode("utf-8"))


async def hands_bridge(brain_url: str, token: str):
    """Hold an outbound WS to the brain; dispatch tool calls to the actuator."""
    import websockets

    # Token goes in the Authorization header, never the URL: the query
    # string lands in the brain's reverse-proxy access log on every
    # reconnect, and this is the body's permanent credential.
    ws_url = (brain_url.replace("https://", "wss://").replace("http://", "ws://")
              .rstrip("/") + "/ws/body")
    # websockets ≥14 renamed extra_headers → additional_headers; the legacy
    # client swallows unknown kwargs until connect time, so a try/except
    # TypeError can't pick the name — inspect the signature instead. The
    # inspection runs before the retry loop, so it must never raise: an
    # escaped exception here kills the bridge task silently and the body
    # runs on with senses but no hands. Fall back to the version number,
    # then to the legacy name — a wrong guess surfaces as a logged,
    # retried connect error instead of a dead task.
    import inspect
    try:
        hdr_kw = ("additional_headers"
                  if "additional_headers" in inspect.signature(websockets.connect).parameters
                  else "extra_headers")
    except Exception:
        try:
            major = int(str(getattr(websockets, "__version__", "")).split(".")[0])
        except ValueError:
            major = 0
        hdr_kw = "additional_headers" if major >= 14 else "extra_headers"
    auth = {hdr_kw: {"Authorization": f"Bearer {token}"}}

    backoff = 2
    while True:
        try:
            async with websockets.connect(ws_url, ping_interval=20, **auth) as ws:
                print("[BODY] hands bridge connected", flush=True)
                backoff = 2
                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except ValueError:
                        continue
                    if msg.get("type") != "tool_call":
                        continue
                    call_id = msg.get("id")
                    try:
                        result = await asyncio.to_thread(
                            actuator_call,
                            {"tool": msg.get("tool"), "args": msg.get("args") or {}})
                    except Exception as e:
                        result = {"ok": False, "error": f"{type(e).__name__}: {e}"}
                    await ws.send(json.dumps(
                        {"type": "tool_result", "id": call_id, "result": result}))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[BODY] hands bridge down ({e}); retry in {backoff}s", flush=True)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 60)


async def main():
    load_env()
    brain_url = os.environ.get("LEON_BRAIN_URL", "").strip()
    token = os.environ.get("LEON_TENANT_TOKEN", "").strip()
    if not brain_url or not token:
        sys.exit("[BODY] LEON_BRAIN_URL and LEON_TENANT_TOKEN are required "
                 "(written by the installer into .env)")

    parsed = urllib.parse.urlparse(brain_url)
    host = parsed.hostname or brain_url
    scheme = parsed.scheme or "https"
    port = parsed.port or (443 if scheme == "https" else 80)
    children = build_children(host, port, scheme)

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:  # Windows
            pass

    bridge = asyncio.create_task(hands_bridge(brain_url, token))

    async def supervise():
        while not stop.is_set():
            for c in children:
                await asyncio.to_thread(c.tend)
            await asyncio.sleep(3)

    sup = asyncio.create_task(supervise())
    await stop.wait()
    print("[BODY] shutting down", flush=True)
    for t in (bridge, sup):
        t.cancel()
    for c in children:
        if c.alive():
            c.proc.terminate()


if __name__ == "__main__":
    asyncio.run(main())
