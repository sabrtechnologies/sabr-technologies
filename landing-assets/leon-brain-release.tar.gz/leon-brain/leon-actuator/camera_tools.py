"""camera_tools — Leon's eyes on the room, cross-platform.

Before this module the only webcam path in the codebase was vision_daemon.py's
ffmpeg + v4l2 grab, which is Linux-only. An SI installed on Windows or macOS
was blind. This module gives the actuator a real webcam capability on all
three desktop platforms via cv2.VideoCapture, which wraps V4L2 (Linux),
AVFoundation (macOS) and DirectShow/MSMF (Windows).

Registered into the actuator's dotted-name dispatch (EXTRA_TOOLS):
  webcam.capture(device?, warmup_frames?, max_width?, ...) → base64 PNG
  camera.report(max_index?, probe?)                        → diagnostic

Return shape matches actuator.screen_capture() exactly:
  {"ok": True, "result": {"image_b64": ..., "width": w, "height": h,
                          "format": "png"}}
  {"ok": False, "error": "..."}

Three real-world quirks this module exists to handle:

  1. WARMUP. Most webcams hand back a black or half-exposed garbage frame on
     the first read after open — the sensor's auto-exposure/auto-white-balance
     hasn't converged. We read and discard `warmup_frames` frames before
     keeping one. This is a bug fix, not polish: without it a meaningful
     fraction of captures are useless black rectangles.

  2. macOS PERMISSION. If the process has not been granted Camera access in
     System Settings → Privacy & Security → Camera, AVFoundation does NOT
     error. open() succeeds, read() succeeds, and every frame is solid black.
     A naive implementation reports success and hands the SI a black image,
     which it will then confidently describe as "a dark room". We detect the
     all-black case and report it as a permission problem.

  3. WINDOWS BACKEND. cv2.CAP_ANY on Windows often picks MSMF, which is slow
     to open (multi-second) and fails outright on some UVC devices. DirectShow
     (CAP_DSHOW) is the reliable first choice; we fall back to MSMF then ANY.
"""

from __future__ import annotations

import base64
import os
import platform
import shutil
import subprocess
import threading
from typing import Any, Dict, List, Optional, Tuple

PLATFORM = platform.system()  # "Windows", "Linux", "Darwin"
IS_WINDOWS = PLATFORM == "Windows"
IS_MACOS = PLATFORM == "Darwin"
IS_LINUX = PLATFORM == "Linux"

# Defaults
DEFAULT_WARMUP_FRAMES = 5
DEFAULT_MAX_WIDTH = 1280
DEFAULT_OPEN_TIMEOUT = 12.0   # seconds; cv2 open/read can block forever
DEFAULT_PROBE_TIMEOUT = 6.0   # per-device budget while enumerating

# A frame is "black" if it is both dark and flat. A genuinely dark room still
# has sensor noise (std of several counts); a permission-denied AVFoundation
# frame is exactly 0 everywhere.
BLACK_MEAN_THRESHOLD = 2.0
BLACK_STD_THRESHOLD = 1.0

_INSTALL_HINT = (
    "opencv is not installed in the actuator's Python environment. "
    "Install it with:  python3 -m pip install opencv-python-headless numpy  "
    "(use 'opencv-python-headless' rather than 'opencv-python' — the actuator "
    "never opens a GUI window and the headless wheel avoids pulling in Qt/GTK)."
)

_cv2 = None
_np = None


# ── Lazy dependency loading ───────────────────────────────────────────────
def _ensure_cv2():
    """Import cv2 + numpy on first use. Raises _MissingDep with an actionable
    message rather than a bare ImportError, so the SI can tell the user what
    to actually type."""
    global _cv2, _np
    if _cv2 is None:
        # Quiet OpenCV's stderr spew while probing nonexistent device indices.
        os.environ.setdefault("OPENCV_LOG_LEVEL", "SILENT")
        os.environ.setdefault("OPENCV_VIDEOIO_PRIORITY_MSMF", "0" if IS_WINDOWS else "")
        try:
            import cv2  # type: ignore
            import numpy  # type: ignore
        except ImportError as e:
            raise _MissingDep(f"{_INSTALL_HINT} (import failed: {e})") from e
        try:
            cv2.setLogLevel(0)  # LOG_LEVEL_SILENT
        except Exception:
            pass
        _cv2, _np = cv2, numpy
    return _cv2, _np


class _MissingDep(Exception):
    """opencv/numpy unavailable. Carries a user-actionable install string."""


# ── Platform plumbing ─────────────────────────────────────────────────────
def _backend_candidates() -> List[Tuple[int, str]]:
    """Ordered (cv2 API preference, human name) list for this OS.

    Windows: DirectShow first — MSMF is the cv2 default via CAP_ANY and is
    both slower to open and broken on a number of UVC webcams.
    macOS:   AVFoundation explicitly; QTKit is long dead.
    Linux:   V4L2 explicitly; CAP_ANY can wander into GStreamer.
    """
    cv2, _ = _ensure_cv2()
    if IS_WINDOWS:
        return [(cv2.CAP_DSHOW, "DSHOW"), (cv2.CAP_MSMF, "MSMF"), (cv2.CAP_ANY, "ANY")]
    if IS_MACOS:
        return [(cv2.CAP_AVFOUNDATION, "AVFOUNDATION"), (cv2.CAP_ANY, "ANY")]
    return [(cv2.CAP_V4L2, "V4L2"), (cv2.CAP_ANY, "ANY")]


def _normalize_device(device: Any) -> Any:
    """Accept 0, "0", "/dev/video0", "video2" → what cv2.VideoCapture wants.

    On Linux a device path string is passed through verbatim (V4L2 accepts
    it). Everywhere else we need an integer index; macOS AVFoundation and
    Windows DShow have no path concept.
    """
    if device is None:
        return 0
    if isinstance(device, bool):  # bool is an int subclass — reject explicitly
        raise ValueError("device must be an index or a path, not a boolean")
    if isinstance(device, int):
        return device
    s = str(device).strip()
    if not s:
        return 0
    if s.isdigit():
        return int(s)
    if s.startswith("/dev/") or os.path.exists(s):
        if not IS_LINUX:
            raise ValueError(
                f"device path {s!r} is Linux-only; on {PLATFORM} pass a numeric "
                "camera index instead (0 is the built-in camera)"
            )
        return s
    # "video0" → /dev/video0 convenience
    if IS_LINUX and s.startswith("video") and s[5:].isdigit():
        return "/dev/" + s
    raise ValueError(f"unrecognized device {device!r} (use an index like 0, "
                     "or on Linux a path like /dev/video0)")


def _run_with_timeout(fn, timeout: float, what: str):
    """Run fn() on a worker thread, raise TimeoutError if it overruns.

    cv2.VideoCapture.open() and .read() can block indefinitely on a wedged
    UVC device or a macOS permission prompt that nobody is there to click.
    The actuator serves a socket and must not hang. We cannot kill a blocked
    C-extension thread, so the worker is a daemon and is deliberately leaked
    on timeout — the process stays responsive and the thread dies with it.
    """
    box: Dict[str, Any] = {}

    def _target():
        try:
            box["value"] = fn()
        except BaseException as e:  # noqa: BLE001 - re-raised on the caller side
            box["error"] = e

    t = threading.Thread(target=_target, daemon=True, name=f"camera-{what}")
    t.start()
    t.join(timeout)
    if t.is_alive():
        raise TimeoutError(
            f"{what} timed out after {timeout:.0f}s — the camera is busy, "
            "wedged, or waiting on an OS permission prompt"
        )
    if "error" in box:
        raise box["error"]
    return box.get("value")


def _open_capture(device: Any, timeout: float) -> Tuple[Any, str]:
    """Try each backend in order; return (capture, backend_name).

    Raises RuntimeError with every backend's failure if none opened.
    """
    cv2, _ = _ensure_cv2()
    failures = []
    for api, name in _backend_candidates():
        try:
            cap = _run_with_timeout(
                lambda a=api: cv2.VideoCapture(device, a), timeout, f"open[{name}]"
            )
        except TimeoutError as e:
            failures.append(f"{name}: {e}")
            continue
        except Exception as e:
            failures.append(f"{name}: {type(e).__name__}: {e}")
            continue
        if cap is not None and cap.isOpened():
            return cap, name
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass
        failures.append(f"{name}: device did not open")
    raise RuntimeError("; ".join(failures) or "no backend available")


def _frame_is_black(frame) -> bool:
    """True if the frame carries no image information at all.

    Deliberately strict: a dark room is dim but noisy (std well above 1).
    Only a driver handing back a zeroed buffer — which is exactly what macOS
    does when Camera permission is denied — is this flat.
    """
    _, np = _ensure_cv2()
    try:
        arr = np.asarray(frame)
        return bool(arr.mean() < BLACK_MEAN_THRESHOLD and arr.std() < BLACK_STD_THRESHOLD)
    except Exception:
        return False


def _permission_hint() -> str:
    """OS-specific guidance for the black-frame / cannot-open case."""
    if IS_MACOS:
        return (
            "macOS Camera permission is almost certainly the cause. AVFoundation "
            "returns solid black frames instead of an error when access is denied. "
            "Grant it in System Settings → Privacy & Security → Camera, for the "
            "application that hosts this process (Terminal, iTerm, or the Python "
            "binary / .app bundle running the actuator), then restart the actuator "
            "— the permission is only re-read at process start. Note that a "
            "process launched from a bare TTY or a launchd job with no GUI session "
            "may never be shown the prompt at all; run it once from a normal "
            "Terminal window to trigger the dialog."
        )
    if IS_WINDOWS:
        return (
            "Check Settings → Privacy & security → Camera: both 'Camera access' "
            "and 'Let desktop apps access your camera' must be On. Also close any "
            "app already holding the camera (Teams, Zoom, Discord, Camera app) — "
            "on Windows the device is exclusive to one process."
        )
    return (
        "On Linux check that /dev/video* exists (the uvcvideo module is loaded) "
        "and that this user is in the 'video' group: sudo usermod -aG video $USER "
        "(re-login required). Also make sure nothing else already holds the "
        "device — try: fuser -v /dev/video0"
    )


# ── webcam.capture ────────────────────────────────────────────────────────
def webcam_capture(args: Dict[str, Any]) -> Dict[str, Any]:
    """Grab a single frame from the webcam, return base64 PNG.

    args (all optional):
      device         index (0) or, on Linux, a path ("/dev/video0")
      warmup_frames  frames to read and throw away first (default 5).
                     Raise it to 10-15 for cheap cameras that need longer to
                     converge auto-exposure; 0 disables (not recommended).
      max_width      downscale wider frames to this (default 1280) to keep
                     the base64 payload sane, matching screen_capture()
      width/height   requested sensor resolution; the driver may ignore it
      allow_black    return the frame even if it is all black (default False;
                     only useful when you genuinely want to prove darkness)
      timeout        seconds before giving up on open/read (default 12)
    """
    args = args or {}
    try:
        cv2, np = _ensure_cv2()
    except _MissingDep as e:
        return {"ok": False, "error": str(e)}

    try:
        device = _normalize_device(args.get("device"))
        warmup = int(args.get("warmup_frames", DEFAULT_WARMUP_FRAMES))
        if warmup < 0:
            warmup = 0
        warmup = min(warmup, 60)  # sanity cap; each frame is ~33ms
        max_width = int(args.get("max_width", DEFAULT_MAX_WIDTH) or 0)
        timeout = float(args.get("timeout", DEFAULT_OPEN_TIMEOUT))
        allow_black = bool(args.get("allow_black", False))
    except (ValueError, TypeError) as e:
        return {"ok": False, "error": f"bad argument: {e}"}

    cap = None
    try:
        try:
            cap, backend = _open_capture(device, timeout)
        except TimeoutError as e:
            return {"ok": False, "error": f"{e}. {_permission_hint()}"}
        except RuntimeError as e:
            return {"ok": False, "error":
                    f"could not open camera {device!r} on {PLATFORM} ({e}). "
                    f"{_permission_hint()}"}

        # Requested resolution, best-effort — drivers silently clamp to the
        # nearest supported mode, so we always trust the frame's real shape.
        for prop, key in ((cv2.CAP_PROP_FRAME_WIDTH, "width"),
                          (cv2.CAP_PROP_FRAME_HEIGHT, "height")):
            if args.get(key):
                try:
                    cap.set(prop, float(args[key]))
                except Exception:
                    pass

        # Warmup: discard the first N frames. Read failures during warmup are
        # not fatal — some backends return False for a beat before streaming.
        def _warm():
            for _ in range(warmup):
                cap.read()
            return True

        if warmup:
            try:
                _run_with_timeout(_warm, timeout, "warmup")
            except TimeoutError as e:
                return {"ok": False, "error": f"{e}. {_permission_hint()}"}

        # The keeper frame. Retry a few times: the first post-warmup read can
        # still miss on slow USB buses.
        frame = None
        last_err = "read returned no frame"
        for _attempt in range(3):
            try:
                ok, candidate = _run_with_timeout(cap.read, timeout, "read")
            except TimeoutError as e:
                return {"ok": False, "error": f"{e}. {_permission_hint()}"}
            except Exception as e:
                last_err = f"{type(e).__name__}: {e}"
                continue
            if ok and candidate is not None and getattr(candidate, "size", 0):
                frame = candidate
                break
        if frame is None:
            return {"ok": False, "error":
                    f"camera {device!r} opened via {backend} but delivered no "
                    f"frame ({last_err}). {_permission_hint()}"}

        # Quirk 2: a permission-denied macOS camera reports success and streams
        # black. Never hand the SI a black frame and call it a capture.
        if _frame_is_black(frame) and not allow_black:
            return {"ok": False, "error":
                    f"camera {device!r} ({backend}) returned an all-black frame. "
                    "This is not a real image. "
                    + ("" if IS_MACOS else "The lens cover may be closed, or the "
                       "camera may be in use by another app. ")
                    + _permission_hint()
                    + " If the room really is pitch dark, re-run with "
                      "allow_black=true to get the frame anyway."}

        h, w = frame.shape[:2]
        if max_width and w > max_width:
            ratio = max_width / float(w)
            frame = cv2.resize(frame, (max_width, max(1, int(h * ratio))),
                               interpolation=cv2.INTER_AREA)
            h, w = frame.shape[:2]

        ok, buf = cv2.imencode(".png", frame)
        if not ok:
            return {"ok": False, "error": "PNG encoding failed"}

        return {"ok": True, "result": {
            "image_b64": base64.b64encode(buf.tobytes()).decode("ascii"),
            "width": int(w),
            "height": int(h),
            "format": "png",
        }}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    finally:
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass


# ── camera.report ─────────────────────────────────────────────────────────
def _os_device_names() -> List[Dict[str, Any]]:
    """Best-effort OS-native camera enumeration, for names cv2 can't give us.

    cv2 has no device-name API on any platform, so index 0 is otherwise an
    anonymous number. Every branch here is optional and failure is silent.
    """
    out: List[Dict[str, Any]] = []
    try:
        if IS_LINUX:
            for n in range(10):
                path = f"/dev/video{n}"
                if not os.path.exists(path):
                    continue
                name = None
                try:
                    with open(f"/sys/class/video4linux/video{n}/name") as f:
                        name = f.read().strip()
                except Exception:
                    pass
                out.append({"path": path, "index": n, "name": name})
        elif IS_MACOS:
            if shutil.which("system_profiler"):
                res = subprocess.run(
                    ["system_profiler", "SPCameraDataType"],
                    capture_output=True, text=True, timeout=15)
                for line in res.stdout.splitlines():
                    s = line.strip()
                    if s.endswith(":") and not s.startswith("Camera") and ":" in s:
                        label = s[:-1].strip()
                        if label and label not in ("Model ID", "Unique ID"):
                            out.append({"name": label})
        elif IS_WINDOWS:
            ps = ("Get-CimInstance Win32_PnPEntity | "
                  "Where-Object { $_.PNPClass -eq 'Camera' -or $_.PNPClass -eq 'Image' } | "
                  "Select-Object -ExpandProperty Name")
            res = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True, timeout=20)
            for line in res.stdout.splitlines():
                if line.strip():
                    out.append({"name": line.strip()})
    except Exception:
        pass
    return out


def _probe_index(idx: int, timeout: float) -> Dict[str, Any]:
    """Open one index, grab a frame, classify what came back."""
    cv2, _ = _ensure_cv2()
    info: Dict[str, Any] = {"index": idx, "opened": False}
    cap = None
    try:
        try:
            cap, backend = _open_capture(idx, timeout)
        except Exception as e:
            info["error"] = str(e)
            return info
        info["opened"] = True
        info["backend"] = backend
        try:
            info["width"] = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            info["height"] = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            info["fps"] = round(float(fps), 2) if fps and fps > 0 else None
        except Exception:
            pass

        def _grab():
            for _ in range(3):  # short warmup so we don't misread a cold sensor
                cap.read()
            return cap.read()

        try:
            ok, frame = _run_with_timeout(_grab, timeout, f"probe-read[{idx}]")
        except TimeoutError as e:
            info["frame_ok"] = False
            info["error"] = str(e)
            return info
        if not ok or frame is None or not getattr(frame, "size", 0):
            info["frame_ok"] = False
            info["error"] = "opened but delivered no frame"
            return info
        info["frame_ok"] = True
        info["black_frame"] = _frame_is_black(frame)
        try:
            _, np = _ensure_cv2()
            info["mean_brightness"] = round(float(np.asarray(frame).mean()), 3)
        except Exception:
            pass
        return info
    finally:
        if cap is not None:
            try:
                cap.release()
            except Exception:
                pass


def camera_report(args: Dict[str, Any]) -> Dict[str, Any]:
    """Diagnose the camera situation on this machine.

    args (all optional):
      max_index  highest camera index to probe (default 4)
      probe      actually open each device (default True). Set False for a
                 fast, non-invasive listing that won't fight another app for
                 the device or trigger a macOS permission prompt.
      timeout    per-device budget in seconds (default 6)

    Returns per-camera status plus a `permission_likely_blocked` verdict.
    The important case: on macOS a denied Camera permission produces
    opened=True, frame_ok=True, black_frame=True — a success that isn't one.
    We surface that as a permission problem rather than a working camera.
    """
    args = args or {}
    result: Dict[str, Any] = {
        "platform": PLATFORM,
        "backend_preference": [],
        "opencv": None,
        "os_devices": [],
        "cameras": [],
        "permission_likely_blocked": False,
        "notes": [],
    }

    try:
        cv2, _ = _ensure_cv2()
    except _MissingDep as e:
        result["opencv"] = None
        result["notes"].append(str(e))
        # Still useful: the OS-level device list needs no opencv.
        result["os_devices"] = _os_device_names()
        result["summary"] = "opencv missing — cannot capture until it is installed"
        return {"ok": True, "result": result}

    result["opencv"] = getattr(cv2, "__version__", "unknown")
    try:
        result["backend_preference"] = [n for _, n in _backend_candidates()]
    except Exception:
        pass
    result["os_devices"] = _os_device_names()

    try:
        max_index = int(args.get("max_index", 4))
    except (TypeError, ValueError):
        max_index = 4
    max_index = max(0, min(max_index, 15))
    try:
        timeout = float(args.get("timeout", DEFAULT_PROBE_TIMEOUT))
    except (TypeError, ValueError):
        timeout = DEFAULT_PROBE_TIMEOUT
    probe = args.get("probe", True)

    if probe:
        for idx in range(max_index + 1):
            # On Linux there is no point probing an index with no /dev/videoN.
            if IS_LINUX and not os.path.exists(f"/dev/video{idx}"):
                continue
            try:
                result["cameras"].append(_probe_index(idx, timeout))
            except Exception as e:
                result["cameras"].append(
                    {"index": idx, "opened": False,
                     "error": f"{type(e).__name__}: {e}"})
    else:
        result["notes"].append("probe=False — devices listed but not opened")

    working = [c for c in result["cameras"]
               if c.get("frame_ok") and not c.get("black_frame")]
    black = [c for c in result["cameras"] if c.get("black_frame")]
    opened_no_frame = [c for c in result["cameras"]
                       if c.get("opened") and not c.get("frame_ok")]

    result["working_cameras"] = [c["index"] for c in working]

    if black:
        result["permission_likely_blocked"] = True
        result["notes"].append(
            f"camera index/es {[c['index'] for c in black]} opened and streamed, "
            "but every frame is solid black — that is a permission denial or a "
            "covered lens, NOT a working camera. " + _permission_hint())
    if opened_no_frame:
        result["notes"].append(
            f"camera index/es {[c['index'] for c in opened_no_frame]} opened but "
            "produced no frame — usually another application is holding the "
            "device. " + _permission_hint())
    if probe and not result["cameras"]:
        # Nothing even enumerated.
        if IS_MACOS:
            result["permission_likely_blocked"] = True
        result["notes"].append(
            "no camera devices detected at all. " + _permission_hint())
    elif probe and not working and not black:
        if IS_MACOS:
            result["permission_likely_blocked"] = True
        result["notes"].append(
            "no camera could be opened. " + _permission_hint())

    if IS_MACOS:
        result["notes"].append(
            "macOS specific: Camera permission is evaluated per-process at "
            "first use and cached for the process lifetime. If you grant it "
            "while the actuator is running, restart the actuator before "
            "retrying.")

    if working:
        result["summary"] = (f"{len(working)} working camera(s): "
                             f"{result['working_cameras']}")
    elif result["permission_likely_blocked"]:
        result["summary"] = "camera present but blocked (permission or in use)"
    else:
        result["summary"] = "no working camera detected"

    return {"ok": True, "result": result}


EXTRA_TOOLS = {
    "webcam.capture": webcam_capture,
    "camera.report": camera_report,
}


if __name__ == "__main__":  # manual smoke test: python3 camera_tools.py
    import json
    print(json.dumps(camera_report({}), indent=2))
    r = webcam_capture({})
    if r.get("ok"):
        r["result"]["image_b64"] = r["result"]["image_b64"][:48] + "...(truncated)"
    print(json.dumps(r, indent=2))
