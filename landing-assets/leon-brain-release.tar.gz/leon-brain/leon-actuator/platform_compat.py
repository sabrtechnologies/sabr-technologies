"""
Platform compatibility layer — abstracts OS-specific desktop control.

Detects the platform at import time and provides unified functions for:
  - Mouse control (click, move, drag, scroll)
  - Keyboard control (type, hotkey)
  - Window management (list, focus, move, minimize, maximize)
  - Clipboard (copy, paste)
  - Monitor detection (list monitors, geometry)
  - Notifications (desktop toast)
  - Screenshot (already cross-platform via mss)

Backends:
  Linux X11:   xdotool + wmctrl (fastest, current Leon default)
  Linux Wayland: ydotool + wlrctl (fallback)
  macOS:       cliclick + AppleScript + pyperclip
  Windows:     pyautogui + pygetwindow + pyperclip

Usage:
  from platform_compat import platform as P
  P.mouse_click(x, y)
  P.keyboard_type("hello")
  P.window_list()
  P.clipboard_copy("text")
"""

import os
import platform as _platform
import shutil
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

SYSTEM = _platform.system()  # "Linux", "Darwin", "Windows"

# ── Settling delay ────────────────────────────────────────────────────────
# xdotool round-trips every request through the X server, so the Linux paths
# always got a few milliseconds of implicit settling between "move" and
# "click", or between "focus" and "type". Library calls (Quartz via cliclick/
# pyautogui, pygetwindow) return the instant they've posted the event, so on a
# slower machine the next action can fire before the window manager has caught
# up. LEON_INPUT_SETTLE_MS tunes it; 0 disables.
try:
    _SETTLE = max(0.0, float(os.environ.get("LEON_INPUT_SETTLE_MS", "40")) / 1000.0)
except ValueError:
    _SETTLE = 0.04


def _settle(mult: float = 1.0) -> None:
    """Explicit replacement for xdotool's implicit X-round-trip delay."""
    if _SETTLE > 0:
        time.sleep(_SETTLE * mult)


# Detect Wayland vs X11 on Linux
_WAYLAND = False
if SYSTEM == "Linux":
    _WAYLAND = bool(os.environ.get("WAYLAND_DISPLAY"))


def _run(cmd: list, timeout: int = 10, **kw) -> subprocess.CompletedProcess:
    """Run a command, return CompletedProcess."""
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)


def _has(binary: str) -> bool:
    return shutil.which(binary) is not None


# ═══════════════════════════════════════════════════════════════════════
# LINUX (X11) — xdotool + wmctrl
# ═══════════════════════════════════════════════════════════════════════

class LinuxX11:
    name = "linux-x11"

    @staticmethod
    def mouse_click(x: int, y: int, button: int = 1):
        _run(["xdotool", "mousemove", str(x), str(y)])
        _run(["xdotool", "click", str(button)])

    @staticmethod
    def mouse_move(x: int, y: int):
        _run(["xdotool", "mousemove", str(x), str(y)])

    @staticmethod
    def mouse_scroll(x: int, y: int, clicks: int = 3, direction: str = "down"):
        _run(["xdotool", "mousemove", str(x), str(y)])
        btn = "5" if direction == "down" else "4"
        for _ in range(abs(clicks)):
            _run(["xdotool", "click", btn])

    @staticmethod
    def mouse_drag(x1: int, y1: int, x2: int, y2: int, button: int = 1):
        _run(["xdotool", "mousemove", str(x1), str(y1)])
        _run(["xdotool", "mousedown", str(button)])
        _run(["xdotool", "mousemove", "--delay", "50", str(x2), str(y2)])
        _run(["xdotool", "mouseup", str(button)])

    @staticmethod
    def mouse_get_pos() -> Tuple[int, int]:
        r = _run(["xdotool", "getmouselocation", "--shell"])
        vals = {}
        for line in r.stdout.strip().split("\n"):
            if "=" in line:
                k, v = line.split("=", 1)
                vals[k] = int(v)
        return vals.get("X", 0), vals.get("Y", 0)

    @staticmethod
    def keyboard_type(text: str, delay_ms: int = 20):
        _run(["xdotool", "type", "--delay", str(delay_ms), "--clearmodifiers", text])

    @staticmethod
    def keyboard_hotkey(keys: str):
        _run(["xdotool", "key", "--clearmodifiers", keys])

    @staticmethod
    def window_list() -> List[Dict[str, str]]:
        r = _run(["wmctrl", "-l"])
        windows = []
        for line in r.stdout.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split(None, 3)
            if len(parts) >= 4:
                windows.append({
                    "id": parts[0],
                    "desktop": parts[1],
                    "host": parts[2],
                    "title": parts[3],
                })
        return windows

    @staticmethod
    def window_focus(title: str) -> bool:
        r = _run(["wmctrl", "-a", title])
        return r.returncode == 0

    @staticmethod
    def window_close(title: str) -> bool:
        """Polite close — sends WM_DELETE, same as clicking [X]."""
        r = _run(["wmctrl", "-c", title])
        return r.returncode == 0

    @staticmethod
    def window_minimize(title: str) -> bool:
        r = _run(["xdotool", "search", "--name", title, "windowminimize"])
        return r.returncode == 0

    @staticmethod
    def window_maximize(title: str) -> bool:
        r = _run(["wmctrl", "-r", title, "-b", "add,maximized_vert,maximized_horz"])
        return r.returncode == 0

    @staticmethod
    def clipboard_copy(text: str) -> bool:
        try:
            p = subprocess.Popen(["xsel", "-b", "-i"], stdin=subprocess.PIPE)
            p.communicate(text.encode(), timeout=5)
            return p.returncode == 0
        except Exception:
            try:
                p = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
                p.communicate(text.encode(), timeout=5)
                return p.returncode == 0
            except Exception:
                return False

    @staticmethod
    def clipboard_paste() -> str:
        try:
            r = _run(["xclip", "-selection", "clipboard", "-o"])
            if r.returncode == 0:
                return r.stdout
        except Exception:
            pass
        try:
            r = _run(["xsel", "-b", "-o"])
            return r.stdout
        except Exception:
            return ""

    @staticmethod
    def list_monitors() -> List[Dict]:
        r = _run(["xrandr", "--listmonitors"])
        monitors = []
        for line in r.stdout.strip().split("\n")[1:]:  # skip header
            parts = line.strip().split()
            if len(parts) >= 3:
                geo = parts[2]  # e.g. "1920/509x1080/286+0+0"
                monitors.append({"name": parts[-1], "geometry": geo})
        return monitors

    @staticmethod
    def notify(title: str, body: str = "", timeout_ms: int = 5000):
        _run(["notify-send", "-t", str(timeout_ms), title, body])

    @staticmethod
    def screen_scale() -> float:
        """Screenshot pixels per input coordinate unit. X11 is 1:1."""
        return 1.0

    @staticmethod
    def monitors_normalized() -> List[Dict]:
        """Monitors in the SAME coordinate space mouse_click() takes."""
        import re
        out = _run(["xrandr", "--listmonitors"]).stdout
        mons = []
        for i, line in enumerate(out.splitlines()[1:]):
            m = re.search(r'(\d+)/\d+x(\d+)/\d+\+(\d+)\+(\d+)', line)
            if m:
                w, h, x, y = (int(g) for g in m.groups())
                mons.append({"idx": len(mons), "name": line.split()[-1],
                             "x": x, "y": y, "w": w, "h": h, "scale": 1.0})
        return sorted(mons, key=lambda d: d["x"])

    # ── Extended surface (added so pc_tools / tools_extra / system_tools /
    #    leon_cursor have a non-Linux route instead of dying on xdotool) ──

    @staticmethod
    def window_unmaximize(title: str) -> bool:
        r = _run(["wmctrl", "-r", title, "-b", "remove,maximized_vert,maximized_horz"])
        return r.returncode == 0

    @staticmethod
    def window_move(title: str, x: int, y: int) -> bool:
        _run(["wmctrl", "-r", title, "-b", "remove,maximized_vert,maximized_horz"])
        r = _run(["wmctrl", "-r", title, "-e", f"0,{int(x)},{int(y)},-1,-1"])
        return r.returncode == 0

    @staticmethod
    def window_resize(title: str, width: int, height: int) -> bool:
        _run(["wmctrl", "-r", title, "-b", "remove,maximized_vert,maximized_horz"])
        r = _run(["wmctrl", "-r", title, "-e", f"0,-1,-1,{int(width)},{int(height)}"])
        return r.returncode == 0

    @staticmethod
    def window_close_active() -> bool:
        wid = _run(["xdotool", "getactivewindow"]).stdout.strip()
        if not wid:
            return False
        return _run(["xdotool", "windowclose", wid]).returncode == 0

    @staticmethod
    def show_desktop(on: bool = True) -> bool:
        r = _run(["wmctrl", "-k", "on" if on else "off"])
        return r.returncode == 0

    @staticmethod
    def lock_screen() -> bool:
        for cmd in (["loginctl", "lock-session"], ["xdg-screensaver", "lock"],
                    ["gnome-screensaver-command", "-l"]):
            if _has(cmd[0]) and _run(cmd).returncode == 0:
                return True
        return False

    @staticmethod
    def power_suspend() -> bool:
        return _run(["systemctl", "suspend"]).returncode == 0

    @staticmethod
    def power_reboot() -> bool:
        return _run(["sudo", "-n", "systemctl", "reboot"]).returncode == 0

    @staticmethod
    def power_shutdown() -> bool:
        return _run(["sudo", "-n", "systemctl", "poweroff"]).returncode == 0

    @staticmethod
    def volume_set(level: Optional[int] = None, delta: Optional[int] = None) -> str:
        if level is not None:
            lvl = max(0, min(150, int(level)))
            _run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{lvl}%"])
            return f"set {lvl}%"
        if delta is not None:
            d = int(delta)
            sign = "+" if d >= 0 else "-"
            _run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{sign}{abs(d)}%"])
            return f"delta {d}%"
        raise ValueError("need level or delta")

    @staticmethod
    def volume_get() -> str:
        return _run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"]).stdout.strip()

    @staticmethod
    def volume_mute(state: Any = "toggle") -> bool:
        s = "toggle" if state == "toggle" else ("1" if state else "0")
        return _run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", s]).returncode == 0

    @staticmethod
    def media_key(key: str) -> bool:
        transport = {"playpause": "play-pause", "play": "play", "pause": "pause",
                     "next": "next", "previous": "previous", "stop": "stop"}
        if key in transport and _has("playerctl"):
            return _run(["playerctl", transport[key]]).returncode == 0
        xf86 = {"playpause": "XF86AudioPlay", "next": "XF86AudioNext",
                "previous": "XF86AudioPrev", "stop": "XF86AudioStop",
                "volumeup": "XF86AudioRaiseVolume",
                "volumedown": "XF86AudioLowerVolume", "mute": "XF86AudioMute"}
        if key in xf86 and _has("xdotool"):
            return _run(["xdotool", "key", xf86[key]]).returncode == 0
        raise ValueError(f"unsupported media key '{key}'")


# ═══════════════════════════════════════════════════════════════════════
# macOS — cliclick + AppleScript + pyperclip
# ═══════════════════════════════════════════════════════════════════════

class MacOS:
    name = "macos"

    @staticmethod
    def mouse_click(x: int, y: int, button: int = 1):
        if _has("cliclick"):
            # Move and click as separate steps with a settle between them:
            # a single c:x,y can outrun apps that only update hover state on
            # the move event, which xdotool's two round-trips never did.
            _run(["cliclick", f"m:{x},{y}"])
            _settle()
            _run(["cliclick", ("c" if button == 1 else "rc") + f":{x},{y}"])
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.moveTo(x, y)
            _settle()
            pyautogui.click(x, y, button="left" if button == 1 else "right")
        _settle()

    @staticmethod
    def mouse_move(x: int, y: int):
        if _has("cliclick"):
            _run(["cliclick", f"m:{x},{y}"])
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.moveTo(x, y)

    @staticmethod
    def mouse_scroll(x: int, y: int, clicks: int = 3, direction: str = "down"):
        _ensure_pyautogui_global()
        import pyautogui
        pyautogui.moveTo(x, y)
        _settle()
        pyautogui.scroll(-clicks if direction == "down" else clicks)
        _settle()

    @staticmethod
    def mouse_drag(x1: int, y1: int, x2: int, y2: int, button: int = 1):
        _ensure_pyautogui_global()
        import pyautogui
        pyautogui.moveTo(x1, y1)
        _settle(2)  # let the source accept the press before dragging
        pyautogui.drag(x2 - x1, y2 - y1, duration=0.3)
        _settle(2)  # let the drop target process the release

    @staticmethod
    def mouse_get_pos() -> Tuple[int, int]:
        if _has("cliclick"):
            r = _run(["cliclick", "p:."])
            parts = r.stdout.strip().split(",")
            if len(parts) == 2:
                return int(parts[0]), int(parts[1])
        _ensure_pyautogui_global()
        import pyautogui
        pos = pyautogui.position()
        return pos.x, pos.y

    @staticmethod
    def keyboard_type(text: str, delay_ms: int = 20):
        if _has("cliclick"):
            _run(["cliclick", f"t:{text}"])
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.typewrite(text, interval=delay_ms / 1000)

    @staticmethod
    def keyboard_hotkey(keys: str):
        # Convert "cmd+c" / "ctrl+shift+t" -> cliclick key-down/up sequence.
        # cliclick's kp: only accepts single named keys, NOT combos — so we
        # hold modifiers with kd:, tap the final key, then release with ku:.
        if _has("cliclick"):
            parts = [p.strip().lower() for p in keys.split("+") if p.strip()]
            mod_map = {"cmd": "cmd", "command": "cmd", "win": "cmd", "meta": "cmd",
                       "ctrl": "ctrl", "control": "ctrl", "alt": "alt",
                       "opt": "alt", "option": "alt", "shift": "shift", "fn": "fn"}
            named = {"return", "enter", "esc", "escape", "space", "tab", "delete",
                     "backspace", "up", "down", "left", "right", "home", "end",
                     "pageup", "pagedown", "fwd-delete"}
            mods = [mod_map[p] for p in parts if p in mod_map]
            keys_only = [p for p in parts if p not in mod_map]
            cmds = []
            if mods:
                cmds.append("kd:" + ",".join(mods))
            for k in keys_only:
                cmds.append(f"kp:{k}" if k in named else f"t:{k}")
            if mods:
                cmds.append("ku:" + ",".join(mods))
            if cmds:
                _run(["cliclick"] + cmds)
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.hotkey(*keys.split("+"))
        _settle()

    @staticmethod
    def window_list() -> List[Dict[str, str]]:
        script = '''
        tell application "System Events"
            set windowList to {}
            repeat with proc in (every process whose visible is true)
                repeat with win in (every window of proc)
                    set end of windowList to (name of proc) & "|" & (name of win)
                end repeat
            end repeat
            return windowList
        end tell
        '''
        r = _run(["osascript", "-e", script])
        windows = []
        for item in r.stdout.strip().split(", "):
            if "|" in item:
                app, title = item.split("|", 1)
                windows.append({"app": app, "title": title})
        return windows

    @staticmethod
    def window_focus(title: str) -> bool:
        """Activate AND verify — `set frontmost` reports success even when
        Accessibility is denied or the app refuses to come forward."""
        script = f'''
        tell application "System Events"
            set frontApp to first process whose visible is true and (name of every window contains "{title}")
            set frontmost of frontApp to true
        end tell
        '''
        want = (title or "").lower()
        for _ in range(3):
            r = _run(["osascript", "-e", script])
            if r.returncode != 0:
                return False
            _settle(2)
            front = _run(["osascript", "-e",
                          'tell application "System Events" to get name of '
                          'first process whose frontmost is true'])
            if want in (front.stdout or "").strip().lower():
                return True
        return False

    @staticmethod
    def window_close(title: str) -> bool:
        """Polite close — clicks the real close button so the app can prompt
        to save. Deliberately NOT `quit`, which can discard unsaved work."""
        script = f'''
        tell application "System Events"
            click (first button of (first window of (first process whose name contains "{title}")) whose subrole is "AXCloseButton")
        end tell
        '''
        r = _run(["osascript", "-e", script])
        return r.returncode == 0

    @staticmethod
    def window_minimize(title: str) -> bool:
        script = f'''
        tell application "System Events"
            click (first button of (first window of (first process whose name contains "{title}")) whose subrole is "AXMinimizeButton")
        end tell
        '''
        r = _run(["osascript", "-e", script])
        return r.returncode == 0

    @staticmethod
    def window_maximize(title: str) -> bool:
        script = f'''
        tell application "System Events"
            click (first button of (first window of (first process whose name contains "{title}")) whose subrole is "AXZoomButton")
        end tell
        '''
        r = _run(["osascript", "-e", script])
        return r.returncode == 0

    @staticmethod
    def clipboard_copy(text: str) -> bool:
        try:
            p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
            p.communicate(text.encode(), timeout=5)
            return p.returncode == 0
        except Exception:
            return False

    @staticmethod
    def clipboard_paste() -> str:
        try:
            r = _run(["pbpaste"])
            return r.stdout
        except Exception:
            return ""

    @staticmethod
    def list_monitors() -> List[Dict]:
        script = 'tell application "Finder" to get bounds of window of desktop'
        r = _run(["osascript", "-e", script])
        # Simplified — just return primary display
        try:
            import AppKit
            screens = AppKit.NSScreen.screens()
            return [{"name": f"display-{i}", "frame": str(s.frame())} for i, s in enumerate(screens)]
        except ImportError:
            return [{"name": "primary", "geometry": r.stdout.strip()}]

    @staticmethod
    def notify(title: str, body: str = "", timeout_ms: int = 5000):
        script = f'display notification "{body}" with title "{title}"'
        _run(["osascript", "-e", script])

    @staticmethod
    def screen_scale() -> float:
        """Retina backing scale: screenshot PIXELS per input POINT.

        This is the coordinate-space trap. Quartz — and therefore cliclick and
        pyautogui — take POINTS. mss/CGDisplayCreateImage hand back PIXELS. On
        a 2x Retina display a target found at pixel (2000, 1200) in a
        screenshot must be clicked at point (1000, 600), or every click lands
        at a quarter of the intended position. Callers that mix vision and
        input MUST divide screenshot coords by this.
        """
        try:
            import AppKit  # type: ignore
            return float(AppKit.NSScreen.mainScreen().backingScaleFactor())
        except Exception:
            return 1.0

    @staticmethod
    def monitors_normalized() -> List[Dict]:
        """Monitors in POINTS — the same space mouse_click() takes."""
        try:
            import AppKit  # type: ignore
            mons = []
            for i, sc in enumerate(AppKit.NSScreen.screens()):
                f = sc.frame()
                mons.append({
                    "idx": i, "name": f"display-{i}",
                    "x": int(f.origin.x), "y": int(f.origin.y),
                    "w": int(f.size.width), "h": int(f.size.height),
                    "scale": float(sc.backingScaleFactor()),
                })
            return sorted(mons, key=lambda d: d["x"])
        except Exception:
            _ensure_pyautogui_global()
            import pyautogui
            w, h = pyautogui.size()
            return [{"idx": 0, "name": "primary", "x": 0, "y": 0,
                     "w": int(w), "h": int(h), "scale": MacOS.screen_scale()}]

    # ── Extended surface (mirrors LinuxX11's) ──

    @staticmethod
    def _osa(script: str) -> subprocess.CompletedProcess:
        return _run(["osascript", "-e", script])

    @staticmethod
    def window_unmaximize(title: str) -> bool:
        # AXZoomButton toggles; "unmaximize" is the same click when zoomed.
        return MacOS.window_maximize(title)

    @staticmethod
    def window_move(title: str, x: int, y: int) -> bool:
        r = MacOS._osa(
            f'tell application "System Events" to set position of '
            f'(first window of (first process whose name contains "{title}")) '
            f'to {{{int(x)}, {int(y)}}}')
        return r.returncode == 0

    @staticmethod
    def window_resize(title: str, width: int, height: int) -> bool:
        r = MacOS._osa(
            f'tell application "System Events" to set size of '
            f'(first window of (first process whose name contains "{title}")) '
            f'to {{{int(width)}, {int(height)}}}')
        return r.returncode == 0

    @staticmethod
    def window_close_active() -> bool:
        r = MacOS._osa(
            'tell application "System Events" to click '
            '(first button of (first window of (first process whose frontmost is true)) '
            'whose subrole is "AXCloseButton")')
        return r.returncode == 0

    @staticmethod
    def show_desktop(on: bool = True) -> bool:
        # Mission Control's "Show Desktop" — F11 (key code 103). Toggles.
        r = MacOS._osa('tell application "System Events" to key code 103')
        return r.returncode == 0

    @staticmethod
    def lock_screen() -> bool:
        return _run(["pmset", "displaysleepnow"]).returncode == 0

    @staticmethod
    def power_suspend() -> bool:
        return _run(["pmset", "sleepnow"]).returncode == 0

    @staticmethod
    def power_reboot() -> bool:
        return MacOS._osa('tell application "System Events" to restart').returncode == 0

    @staticmethod
    def power_shutdown() -> bool:
        return MacOS._osa('tell application "System Events" to shut down').returncode == 0

    @staticmethod
    def volume_set(level: Optional[int] = None, delta: Optional[int] = None) -> str:
        if level is not None:
            lvl = max(0, min(100, int(level)))
            MacOS._osa(f"set volume output volume {lvl}")
            return f"set {lvl}%"
        if delta is not None:
            cur = MacOS._osa("output volume of (get volume settings)").stdout.strip()
            try:
                base = int(cur)
            except ValueError:
                base = 50
            lvl = max(0, min(100, base + int(delta)))
            MacOS._osa(f"set volume output volume {lvl}")
            return f"delta {int(delta)}% -> {lvl}%"
        raise ValueError("need level or delta")

    @staticmethod
    def volume_get() -> str:
        return MacOS._osa("get volume settings").stdout.strip()

    @staticmethod
    def volume_mute(state: Any = "toggle") -> bool:
        if state == "toggle":
            cur = MacOS._osa("output muted of (get volume settings)").stdout.strip()
            want = "false" if cur == "true" else "true"
        else:
            want = "true" if state else "false"
        return MacOS._osa(f"set volume output muted {want}").returncode == 0

    @staticmethod
    def media_key(key: str) -> bool:
        if key in ("volumeup", "volumedown"):
            MacOS.volume_set(delta=6 if key == "volumeup" else -6)
            return True
        if key == "mute":
            return MacOS.volume_mute("toggle")
        transport = {"playpause": "playpause", "play": "play", "pause": "pause",
                     "next": "next track", "previous": "previous track",
                     "stop": "pause"}
        if key in transport:
            for app in ("Spotify", "Music"):
                r = MacOS._osa(
                    f'tell application "System Events" to (name of processes) contains "{app}"')
                if r.stdout.strip() == "true":
                    return MacOS._osa(
                        f'tell application "{app}" to {transport[key]}').returncode == 0
            return False
        raise ValueError(f"unsupported media key '{key}'")

    @staticmethod
    def permissions_status() -> Dict[str, Any]:
        """Probe macOS TCC so Leon KNOWS when he's being silently blocked
        instead of clicking into the void. Returns booleans + a tool check.

        Camera and Microphone are checked the same way Accessibility and
        Screen Recording always have been: Leon's actuator needs all four
        (mouse/keyboard, screen, webcam, ears), and camera_tools.py already
        found the hard way that a denied Camera doesn't error at all — it
        just hands back solid black frames — so "no exception" cannot be
        read as "granted" for either of these two either.
        """
        status = {"accessibility": None, "screen_recording": None,
                  "camera": None, "microphone": None,
                  "input_tool": bool(_has("cliclick")), "notes": []}
        # Accessibility: System Events UI scripting fails without it.
        try:
            r = _run(["osascript", "-e",
                      'tell application "System Events" to return name of first process'],
                     timeout=5)
            status["accessibility"] = (r.returncode == 0)
            if r.returncode != 0:
                status["notes"].append("Accessibility OFF — mouse/keyboard/windows won't work")
        except Exception:
            status["accessibility"] = False
        # Screen Recording: CGDisplayCreateImage returns None when denied.
        try:
            import Quartz  # type: ignore
            img = Quartz.CGDisplayCreateImage(Quartz.CGMainDisplayID())
            status["screen_recording"] = img is not None
            if img is None:
                status["notes"].append("Screen Recording OFF — Leon sees a black screen")
        except Exception:
            status["screen_recording"] = None  # can't determine without pyobjc-Quartz
        # Camera / Microphone: AVFoundation's own authorization status, not a
        # capture attempt — asking directly means we never have to open a
        # device (and possibly steal it from another app) just to find out.
        try:
            import AVFoundation  # type: ignore
            _AUTH_GRANTED = 3  # AVAuthorizationStatusAuthorized
            cam = AVFoundation.AVCaptureDevice.authorizationStatusForMediaType_(
                AVFoundation.AVMediaTypeVideo)
            status["camera"] = (cam == _AUTH_GRANTED)
            if cam != _AUTH_GRANTED:
                status["notes"].append(
                    "Camera OFF — webcam captures return solid black frames, not an error")
            mic = AVFoundation.AVCaptureDevice.authorizationStatusForMediaType_(
                AVFoundation.AVMediaTypeAudio)
            status["microphone"] = (mic == _AUTH_GRANTED)
            if mic != _AUTH_GRANTED:
                status["notes"].append("Microphone OFF — Leon won't hear you")
        except Exception:
            status["camera"] = None
            status["microphone"] = None  # can't determine without pyobjc-AVFoundation
        if not status["input_tool"]:
            status["notes"].append("cliclick missing — clicks fall back to pyautogui")
        return status


# ═══════════════════════════════════════════════════════════════════════
# WINDOWS — pyautogui + pygetwindow + pyperclip
# ═══════════════════════════════════════════════════════════════════════

class Windows:
    name = "windows"

    @staticmethod
    def _pag():
        _ensure_dpi_awareness()
        _ensure_pyautogui_global()
        import pyautogui
        return pyautogui

    @staticmethod
    def screen_scale() -> float:
        """Screenshot pixels per input coordinate unit.

        Once the process is per-monitor-DPI-aware (see _ensure_dpi_awareness)
        pyautogui and mss both work in real physical pixels, so this is 1.0.
        Without that call Windows silently virtualizes the process to 96 DPI
        and every coordinate on a 150%-scaled monitor is off by 1.5x.
        """
        _ensure_dpi_awareness()
        return 1.0

    @staticmethod
    def monitors_normalized() -> List[Dict]:
        _ensure_dpi_awareness()
        try:
            from screeninfo import get_monitors
            mons = [{"idx": i, "name": m.name or f"monitor-{i}",
                     "x": m.x, "y": m.y, "w": m.width, "h": m.height,
                     "scale": 1.0}
                    for i, m in enumerate(get_monitors())]
            return sorted(mons, key=lambda d: d["x"])
        except Exception:
            w, h = Windows._pag().size()
            return [{"idx": 0, "name": "primary", "x": 0, "y": 0,
                     "w": int(w), "h": int(h), "scale": 1.0}]

    @staticmethod
    def mouse_click(x: int, y: int, button: int = 1):
        pag = Windows._pag()
        pag.moveTo(x, y)
        _settle()
        pag.click(x, y, button="left" if button == 1 else "right")
        _settle()

    @staticmethod
    def mouse_move(x: int, y: int):
        Windows._pag().moveTo(x, y)

    @staticmethod
    def mouse_scroll(x: int, y: int, clicks: int = 3, direction: str = "down"):
        Windows._pag().moveTo(x, y)
        Windows._pag().scroll(-clicks if direction == "down" else clicks)

    @staticmethod
    def mouse_drag(x1: int, y1: int, x2: int, y2: int, button: int = 1):
        Windows._pag().moveTo(x1, y1)
        Windows._pag().drag(x2 - x1, y2 - y1, duration=0.3)

    @staticmethod
    def mouse_get_pos() -> Tuple[int, int]:
        pos = Windows._pag().position()
        return pos.x, pos.y

    @staticmethod
    def keyboard_type(text: str, delay_ms: int = 20):
        Windows._pag().typewrite(text, interval=delay_ms / 1000)

    @staticmethod
    def keyboard_hotkey(keys: str):
        Windows._pag().hotkey(*keys.split("+"))
        _settle()

    @staticmethod
    def window_list() -> List[Dict[str, str]]:
        try:
            import pygetwindow as gw
            return [{"title": w.title, "visible": w.visible} for w in gw.getAllWindows() if w.title]
        except ImportError:
            # Fallback: tasklist
            r = _run(["tasklist", "/v", "/fo", "csv"])
            windows = []
            for line in r.stdout.strip().split("\n")[1:]:
                parts = line.split('","')
                if len(parts) >= 9:
                    title = parts[8].strip('"')
                    if title and title != "N/A":
                        windows.append({"title": title, "process": parts[0].strip('"')})
            return windows

    @staticmethod
    def window_focus(title: str) -> bool:
        """Activate AND verify.

        pygetwindow's activate() wraps SetForegroundWindow, which Windows
        refuses (returning success to the caller) whenever another process
        holds the foreground lock — the classic silent no-op. Never trust the
        call; read the foreground window back, and retry with a minimize/
        restore bounce, which is the one nudge Windows still honours.
        """
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if not wins:
                return False
            w = wins[0]
            want = (title or "").lower()
            for attempt in range(3):
                try:
                    w.activate()
                except Exception:
                    pass
                _settle(2)
                front = gw.getActiveWindow()
                if front is not None and want in (front.title or "").lower():
                    return True
                if attempt == 1:
                    # Foreground lock held — bounce the window to earn focus.
                    try:
                        w.minimize(); _settle(2); w.restore(); _settle(2)
                    except Exception:
                        pass
            return False
        except Exception:
            pass
        return False

    @staticmethod
    def window_close(title: str) -> bool:
        """Polite close via pygetwindow's close() — posts WM_CLOSE, so the
        app still gets to show its 'save changes?' prompt."""
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].close()
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def window_minimize(title: str) -> bool:
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].minimize()
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def window_maximize(title: str) -> bool:
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].maximize()
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def clipboard_copy(text: str) -> bool:
        try:
            import pyperclip
            pyperclip.copy(text)
            return True
        except ImportError:
            Windows._pag().hotkey("ctrl", "c")
            return True

    @staticmethod
    def clipboard_paste() -> str:
        try:
            import pyperclip
            return pyperclip.paste()
        except ImportError:
            return ""

    @staticmethod
    def list_monitors() -> List[Dict]:
        try:
            from screeninfo import get_monitors
            return [{"name": m.name or f"monitor-{i}", "x": m.x, "y": m.y,
                     "width": m.width, "height": m.height}
                    for i, m in enumerate(get_monitors())]
        except ImportError:
            return [{"name": "primary", "width": 1920, "height": 1080}]

    @staticmethod
    def notify(title: str, body: str = "", timeout_ms: int = 5000):
        try:
            from plyer import notification
            notification.notify(title=title, message=body, timeout=timeout_ms // 1000)
        except ImportError:
            # PowerShell fallback
            ps = f'[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms"); ' \
                 f'$n=New-Object System.Windows.Forms.NotifyIcon; ' \
                 f'$n.Icon=[System.Drawing.SystemIcons]::Information; ' \
                 f'$n.Visible=$true; ' \
                 f'$n.ShowBalloonTip({timeout_ms},"{title}","{body}",[System.Windows.Forms.ToolTipIcon]::Info)'
            _run(["powershell", "-Command", ps])

    # ── Extended surface (mirrors LinuxX11's) ──

    @staticmethod
    def _win(title: str):
        import pygetwindow as gw
        wins = gw.getWindowsWithTitle(title)
        return wins[0] if wins else None

    @staticmethod
    def window_unmaximize(title: str) -> bool:
        w = Windows._win(title)
        if w is None:
            return False
        w.restore()
        return True

    @staticmethod
    def window_move(title: str, x: int, y: int) -> bool:
        w = Windows._win(title)
        if w is None:
            return False
        w.moveTo(int(x), int(y))
        return True

    @staticmethod
    def window_resize(title: str, width: int, height: int) -> bool:
        w = Windows._win(title)
        if w is None:
            return False
        w.resizeTo(int(width), int(height))
        return True

    @staticmethod
    def window_close_active() -> bool:
        import pygetwindow as gw
        w = gw.getActiveWindow()
        if w is None:
            return False
        w.close()
        return True

    @staticmethod
    def show_desktop(on: bool = True) -> bool:
        Windows._pag().hotkey("win", "d")
        return True

    @staticmethod
    def lock_screen() -> bool:
        return _run(["rundll32.exe", "user32.dll,LockWorkStation"]).returncode == 0

    @staticmethod
    def power_suspend() -> bool:
        return _run(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"]).returncode == 0

    @staticmethod
    def power_reboot() -> bool:
        return _run(["shutdown", "/r", "/t", "0"]).returncode == 0

    @staticmethod
    def power_shutdown() -> bool:
        return _run(["shutdown", "/s", "/t", "0"]).returncode == 0

    @staticmethod
    def _volume_iface():
        """pycaw endpoint volume, or None when pycaw isn't installed."""
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            dev = AudioUtilities.GetSpeakers()
            iface = dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            return cast(iface, POINTER(IAudioEndpointVolume))
        except Exception:
            return None

    @staticmethod
    def volume_set(level: Optional[int] = None, delta: Optional[int] = None) -> str:
        vol = Windows._volume_iface()
        if vol is not None:
            cur = round(vol.GetMasterVolumeLevelScalar() * 100)
            tgt = int(level) if level is not None else cur + int(delta or 0)
            tgt = max(0, min(100, tgt))
            vol.SetMasterVolumeLevelScalar(tgt / 100.0, None)
            return f"set {tgt}%"
        # No pycaw — nudge with the media keys instead of failing outright.
        if delta is None:
            raise RuntimeError("absolute volume needs pycaw (pip install pycaw)")
        pag = Windows._pag()
        for _ in range(max(1, abs(int(delta)) // 2)):
            pag.press("volumeup" if int(delta) > 0 else "volumedown")
        return f"delta {int(delta)}% (via media keys)"

    @staticmethod
    def volume_get() -> str:
        vol = Windows._volume_iface()
        if vol is None:
            return "unknown (pycaw not installed)"
        return f"{round(vol.GetMasterVolumeLevelScalar() * 100)}%"

    @staticmethod
    def volume_mute(state: Any = "toggle") -> bool:
        vol = Windows._volume_iface()
        if vol is not None:
            want = (not vol.GetMute()) if state == "toggle" else bool(state)
            vol.SetMute(bool(want), None)
            return True
        Windows._pag().press("volumemute")
        return True

    @staticmethod
    def media_key(key: str) -> bool:
        keymap = {"playpause": "playpause", "play": "playpause", "pause": "playpause",
                  "next": "nexttrack", "previous": "prevtrack", "stop": "stop",
                  "volumeup": "volumeup", "volumedown": "volumedown",
                  "mute": "volumemute"}
        if key not in keymap:
            raise ValueError(f"unsupported media key '{key}'")
        Windows._pag().press(keymap[key])
        return True


# ═══════════════════════════════════════════════════════════════════════
# Helper
# ═══════════════════════════════════════════════════════════════════════

_DPI_DONE = False


def _ensure_dpi_awareness() -> None:
    """Make this process per-monitor DPI aware on Windows. Idempotent.

    Windows lies to processes that don't ask. A non-DPI-aware process gets a
    virtualized 96-DPI coordinate space, so on a monitor at 150% scaling
    pyautogui reports 1280x800 for a real 1920x1200 panel — clicks computed
    from a screenshot land 1.5x off, and only on the scaled monitor, which is
    exactly the kind of bug that looks like "Leon randomly misclicks".
    Declaring PER_MONITOR_AWARE_V2 puts input and capture in the same space.
    """
    global _DPI_DONE
    if _DPI_DONE or _platform.system() != "Windows":
        return
    _DPI_DONE = True
    try:
        import ctypes
        # -4 == DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 (Win10 1703+)
        if ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            return
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PER_MONITOR_AWARE
        return
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.SetProcessDPIAware()  # Vista-era, system-wide
    except Exception:
        pass


def _ensure_pyautogui_global():
    try:
        import pyautogui
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0.05
    except ImportError:
        raise RuntimeError("pyautogui not installed. Run: pip install pyautogui")


# ═══════════════════════════════════════════════════════════════════════
# Auto-select platform
# ═══════════════════════════════════════════════════════════════════════

def _detect() -> Any:
    if SYSTEM == "Darwin":
        return MacOS
    elif SYSTEM == "Windows":
        return Windows
    else:
        # Linux — prefer X11 if available
        if _has("xdotool") and not _WAYLAND:
            return LinuxX11
        # Could add LinuxWayland class here later (ydotool + wlrctl)
        return LinuxX11  # best effort


# ═══════════════════════════════════════════════════════════════════════
# Preflight — PROVE control works, don't just believe the return code
# ═══════════════════════════════════════════════════════════════════════

# Where the owner has to go to fix each capability, per platform.
_FIX_PANE = {
    "Darwin": {
        "input": "System Settings > Privacy & Security > Accessibility — "
                 "enable the app running Leon (Terminal, iTerm, or Leon.app)",
        "screen": "System Settings > Privacy & Security > Screen Recording — "
                  "enable the app running Leon, then restart it "
                  "(this grant only takes effect after a relaunch)",
    },
    "Windows": {
        "input": "Run Leon at the same integrity level as the target app — an "
                 "elevated (admin) window will not accept synthetic input from "
                 "a non-elevated process (UIPI)",
        "screen": "Ensure Leon is not running as a service or in Session 0; "
                  "screen capture needs an interactive desktop session",
    },
    "Linux": {
        "input": "Install xdotool and make sure DISPLAY/XAUTHORITY point at the "
                 "running X session",
        "screen": "Ensure DISPLAY is set and the X session is reachable",
    },
}


def preflight(move_probe: bool = True) -> Dict[str, Any]:
    """Prove — empirically — that Leon can actually drive this machine.

    THE FAILURE THIS EXISTS FOR. On macOS, synthetic input (CGEventPost, which
    is what cliclick and pyautogui both post) and screen capture are gated
    behind TCC. When Accessibility or Screen Recording is denied, the calls do
    NOT raise and do NOT return an error — they succeed and do nothing, or
    hand back a solid black frame. A return code of 0 is therefore worthless
    as evidence. So we don't ask "did the call succeed", we ask "did the world
    change": move the cursor and read the position back, grab a frame and
    check it isn't null/black.

    Returns {ok, platform, checks: {name: {ok, detail, fix}}, blocking: [...]}.
    Nothing here raises — a broken machine still gets a structured answer.
    """
    be = _detect()
    sysname = SYSTEM
    panes = _FIX_PANE.get(sysname, _FIX_PANE["Linux"])
    checks: Dict[str, Dict[str, Any]] = {}

    # ── 1. Input: move the cursor and read it back ──────────────────────
    if move_probe:
        try:
            ox, oy = be.mouse_get_pos()
            # Nudge somewhere reachable and clearly different, then verify.
            tx, ty = (ox + 17, oy + 13) if (ox, oy) != (0, 0) else (120, 120)
            be.mouse_move(tx, ty)
            _settle(3)
            nx, ny = be.mouse_get_pos()
            moved = abs(nx - tx) <= 3 and abs(ny - ty) <= 3
            be.mouse_move(ox, oy)  # always put the pointer back
            checks["input"] = {
                "ok": moved,
                "detail": (f"cursor moved to ({tx},{ty}) and read back "
                           f"({nx},{ny})") if moved else
                          (f"asked for ({tx},{ty}) but cursor is at ({nx},{ny}) "
                           "— the move call reported success and did nothing, "
                           "which is the signature of a denied permission"),
                "fix": None if moved else panes["input"],
            }
        except Exception as e:
            checks["input"] = {"ok": False,
                               "detail": f"{type(e).__name__}: {e}",
                               "fix": panes["input"]}
    else:
        checks["input"] = {"ok": None, "detail": "skipped (move_probe=False)",
                           "fix": None}

    # ── 2. Screen capture: grab a frame, prove it isn't null or all-black ──
    try:
        import mss  # type: ignore
        with mss.MSS() as sct:
            shot = sct.grab(sct.monitors[0])
        raw = bytes(shot.rgb)
        if not raw:
            checks["screen"] = {"ok": False, "detail": "capture returned no data",
                                "fix": panes["screen"]}
        else:
            # Sample rather than scan the whole frame — cheap, and enough to
            # tell a real desktop from the solid black a denied grant returns.
            step = max(3, (len(raw) // 3 // 4000) * 3)
            sample = raw[::step]
            if max(sample) == 0:
                checks["screen"] = {
                    "ok": False,
                    "detail": "capture succeeded but every sampled pixel is "
                              "black — this is what a denied Screen Recording "
                              "grant looks like, not an error",
                    "fix": panes["screen"]}
            else:
                checks["screen"] = {
                    "ok": True,
                    "detail": f"captured {shot.size.width}x{shot.size.height} "
                              "with non-black content",
                    "fix": None}
    except Exception as e:
        checks["screen"] = {"ok": False, "detail": f"{type(e).__name__}: {e}",
                            "fix": panes["screen"]}

    # ── 3. Coordinate space — so callers know how to map vision to clicks ──
    try:
        scale = be.screen_scale() if hasattr(be, "screen_scale") else 1.0
        mons = be.monitors_normalized() if hasattr(be, "monitors_normalized") else []
        checks["coordinates"] = {
            "ok": True,
            "detail": f"{len(mons)} monitor(s); screenshot pixels per input "
                      f"unit = {scale}"
                      + ("  — divide screenshot coordinates by this before "
                         "clicking" if scale != 1.0 else ""),
            "scale": scale, "monitors": mons, "fix": None}
    except Exception as e:
        checks["coordinates"] = {"ok": False, "detail": f"{type(e).__name__}: {e}",
                                 "fix": None}

    # ── 4. Platform-specific permission probes (macOS TCC) ──────────────
    if hasattr(be, "permissions_status"):
        try:
            checks["permissions"] = {"ok": True, "detail": be.permissions_status(),
                                     "fix": None}
        except Exception as e:
            checks["permissions"] = {"ok": False,
                                     "detail": f"{type(e).__name__}: {e}",
                                     "fix": None}

    blocking = [{"capability": k, "why": v["detail"], "fix": v["fix"]}
                for k, v in checks.items() if v.get("ok") is False]
    return {"ok": not blocking, "platform": getattr(be, "name", sysname),
            "system": sysname, "checks": checks, "blocking": blocking}


# The singleton — import this
platform = _detect()
# Non-mac platforms don't gate input behind permissions — give a safe stub
# so callers can always ask platform.permissions_status().
if not hasattr(platform, "permissions_status"):
    platform.permissions_status = staticmethod(
        lambda: {"accessibility": True, "screen_recording": True, "notes": []})
print(f"[PLATFORM] Detected: {platform.name} (system={SYSTEM}, wayland={_WAYLAND})")
