"""
Advanced browser automation via Chrome DevTools Protocol (Phase — power tools).

Builds on browser_cdp.py — attaches to Dean's real Brave session on
127.0.0.1:9222 (the one with all his logged-in tabs). All CDP plumbing
(_open_session, _evaluate, _http_get_json, _CDPSession, _pick_tab,
_list_tabs, CDPUnreachable) is REUSED from browser_cdp.py — nothing
re-implemented here.

Tool surface (~28 tools, all under the `browser.` namespace):

  Forms & autofill:
    form_fill_all / form_submit / form_extract / autofill_login
  Tabs & windows:
    tab_group_by_domain / tab_close_duplicates / tab_close_all_except
    tab_pin / tab_unpin / tab_move_to_new_window
    tabs_save_session / tabs_restore_session / tabs_list_sessions
  Page interaction:
    scroll_to_bottom / scroll_to_top / extract_all_links / extract_all_images
    extract_main_text / extract_table / count_elements / element_exists
    highlight_element
  Page state & data:
    get_meta_tags / get_page_performance / get_all_cookies_for_domain
    set_cookie / clear_cookies / execute_js / wait_for_navigation
    download_file

Every tool takes a dict, returns {"ok": bool, ...}, and NEVER raises —
errors come back as {"ok": False, "error": "..."}. Most accept an
optional `url_contains` to disambiguate when several tabs are open.
"""

from __future__ import annotations

import base64
import json
import os
import time
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import urlparse

from browser_cdp import (
    CDPUnreachable,
    _CDPSession,
    _evaluate,
    _http_get_json,
    _list_tabs,
    _open_session,
    _pick_tab,
)


# ── module config ───────────────────────────────────────────────────────

# Saved tab-sessions live alongside the brain's other state files.
_SESSIONS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "brain_state", "browser_sessions",
)


# ── shared helpers ──────────────────────────────────────────────────────


def _err(e: Exception) -> Dict[str, Any]:
    """Uniform error envelope. CDPUnreachable keeps its long actionable text."""
    if isinstance(e, CDPUnreachable):
        return {"ok": False, "error": str(e)}
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _run_js(code: str, url_contains: Optional[str] = None) -> Any:
    """Open a session, evaluate JS, always close. Raises on failure —
    callers wrap in try/except and funnel through _err()."""
    s = _open_session(url_contains)
    try:
        return _evaluate(s, code)
    finally:
        s.close()


def _domain_of(url: str) -> str:
    """Bare hostname from a URL ('' for chrome://, about:, etc.)."""
    try:
        return (urlparse(url).hostname or "").lower()
    except Exception:
        return ""


def _sessions_dir() -> str:
    """Ensure the saved-session directory exists; return its path."""
    os.makedirs(_SESSIONS_DIR, exist_ok=True)
    return _SESSIONS_DIR


def _session_path(name: str) -> str:
    """Sanitised path for a named session file (no traversal, no slashes)."""
    safe = "".join(c for c in str(name) if c.isalnum() or c in ("-", "_", " ")).strip()
    safe = safe.replace(" ", "_") or "session"
    return os.path.join(_sessions_dir(), f"{safe}.json")


# A JS finder that resolves either a CSS selector OR a visible-text needle
# to the single narrowest matching element. Mirrors browser_cdp.py's logic
# so behaviour is consistent across the actuator. Embeds as a JS expression
# evaluating to an Element (or null).
def _finder_expr(selector: str = "", text: str = "") -> str:
    if selector:
        return f"document.querySelector({json.dumps(selector)})"
    needle = (text or "").lower()
    return f"""(() => {{
        const needle = {json.dumps(needle)};
        const all = Array.from(document.body.querySelectorAll('*'));
        for (const el of all) {{
            const st = getComputedStyle(el);
            if (st.display === 'none' || st.visibility === 'hidden') continue;
            const txt = (el.innerText || el.textContent || '').toLowerCase();
            if (!txt.includes(needle)) continue;
            const child = Array.from(el.children).some(c =>
                (c.innerText || c.textContent || '').toLowerCase().includes(needle));
            if (!child) return el;
        }}
        return null;
    }})()"""


# ══════════════════════════════════════════════════════════════════════
# FORMS & AUTOFILL
# ══════════════════════════════════════════════════════════════════════


def form_fill_all(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fill many inputs in one call.

    args:
      fields (dict, required): {key: value}. Each key is tried as a CSS
                               selector first, then as a name/id/placeholder/
                               aria-label/associated-<label> text match.
      url_contains (str, opt): disambiguate tabs.
    """
    fields = args.get("fields")
    if not isinstance(fields, dict) or not fields:
        return {"ok": False, "error": "fields must be a non-empty dict"}
    js = f"""
        (() => {{
            const fields = {json.dumps(fields)};
            const findInput = (key) => {{
                let el = null;
                try {{ el = document.querySelector(key); }} catch (e) {{}}
                if (el) return el;
                const k = key.toLowerCase();
                const cands = Array.from(document.querySelectorAll(
                    'input, textarea, select, [contenteditable]'));
                for (const c of cands) {{
                    const attrs = [c.name, c.id, c.placeholder,
                                   c.getAttribute('aria-label')]
                        .filter(Boolean).map(s => s.toLowerCase());
                    if (attrs.some(a => a.includes(k))) return c;
                }}
                for (const lab of Array.from(document.querySelectorAll('label'))) {{
                    if ((lab.innerText || '').toLowerCase().includes(k)) {{
                        if (lab.htmlFor) {{
                            const t = document.getElementById(lab.htmlFor);
                            if (t) return t;
                        }}
                        const inner = lab.querySelector('input, textarea, select');
                        if (inner) return inner;
                    }}
                }}
                return null;
            }};
            const out = [];
            for (const [key, val] of Object.entries(fields)) {{
                const el = findInput(key);
                if (!el) {{ out.push({{key, ok: false, err: 'no input'}}); continue; }}
                const tag = el.tagName.toLowerCase();
                try {{
                    el.focus();
                    if (tag === 'select') {{
                        el.value = String(val);
                    }} else if (el.isContentEditable) {{
                        el.textContent = String(val);
                    }} else if (el.type === 'checkbox' || el.type === 'radio') {{
                        el.checked = !!val && val !== 'false';
                    }} else {{
                        const proto = tag === 'textarea'
                            ? window.HTMLTextAreaElement.prototype
                            : window.HTMLInputElement.prototype;
                        const setter = Object.getOwnPropertyDescriptor(
                            proto, 'value');
                        if (setter && setter.set) setter.set.call(el, String(val));
                        else el.value = String(val);
                    }}
                    el.dispatchEvent(new Event('input', {{bubbles: true}}));
                    el.dispatchEvent(new Event('change', {{bubbles: true}}));
                    out.push({{key, ok: true, tag,
                               name: el.name || el.id || null}});
                }} catch (e) {{
                    out.push({{key, ok: false, err: String(e)}});
                }}
            }}
            return out;
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or []
        filled = sum(1 for r in res if r.get("ok"))
        return {"ok": filled > 0, "result": {
            "filled": filled, "requested": len(fields), "fields": res,
        }}
    except Exception as e:
        return _err(e)


def form_submit(args: Dict[str, Any]) -> Dict[str, Any]:
    """Submit a <form>. With no form_selector, submits the first form on
    the page.

    args:
      form_selector (str, opt): CSS selector for the target <form>.
      url_contains (str, opt):  disambiguate tabs.
    """
    sel = (args.get("form_selector") or "").strip()
    js = f"""
        (() => {{
            const sel = {json.dumps(sel)};
            const form = sel
                ? document.querySelector(sel)
                : document.querySelector('form');
            if (!form) return {{ok: false, err: 'no form found'}};
            if (form.tagName !== 'FORM')
                return {{ok: false, err: 'selector is not a <form>'}};
            const action = form.action || location.href;
            // Prefer requestSubmit so HTML validation + submit handlers fire.
            try {{
                if (form.requestSubmit) form.requestSubmit();
                else form.submit();
            }} catch (e) {{
                form.submit();
            }}
            return {{ok: true, action}};
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "submit failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def form_extract(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read every input in a form — name, type, current value, label.

    args:
      form_selector (str, opt): CSS selector. Defaults to the first form.
      url_contains (str, opt):  disambiguate tabs.
    """
    sel = (args.get("form_selector") or "").strip()
    js = f"""
        (() => {{
            const sel = {json.dumps(sel)};
            const form = sel
                ? document.querySelector(sel)
                : document.querySelector('form');
            if (!form) return {{ok: false, err: 'no form found'}};
            const labelFor = (el) => {{
                if (el.id) {{
                    const l = document.querySelector('label[for=' +
                        CSS.escape(el.id) + ']');
                    if (l) return (l.innerText || '').trim().slice(0, 80);
                }}
                const wrap = el.closest('label');
                if (wrap) return (wrap.innerText || '').trim().slice(0, 80);
                return null;
            }};
            const fields = Array.from(
                form.querySelectorAll('input, textarea, select')).map(el => ({{
                    tag: el.tagName.toLowerCase(),
                    type: el.type || null,
                    name: el.name || null,
                    id: el.id || null,
                    label: labelFor(el),
                    placeholder: el.placeholder || null,
                    value: (el.type === 'password')
                        ? '<hidden>'
                        : String(el.value ?? '').slice(0, 300),
                    checked: (el.type === 'checkbox' || el.type === 'radio')
                        ? el.checked : undefined,
                    required: !!el.required,
                }}));
            return {{ok: true, action: form.action || location.href,
                     method: (form.method || 'get').toUpperCase(),
                     count: fields.length, fields}};
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "extract failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def autofill_login(args: Dict[str, Any]) -> Dict[str, Any]:
    """Heuristically fill a login form — finds the email/username field and
    the password field, fills both, does NOT submit (caller decides).

    args:
      username (str, required)
      password (str, required)
      url_contains (str, opt): disambiguate tabs.
    """
    username = args.get("username")
    password = args.get("password")
    if username is None or password is None:
        return {"ok": False, "error": "username and password are required"}
    js = f"""
        (() => {{
            const user = {json.dumps(str(username))};
            const pass = {json.dumps(str(password))};
            const setVal = (el, v) => {{
                el.focus();
                const proto = el.tagName === 'TEXTAREA'
                    ? window.HTMLTextAreaElement.prototype
                    : window.HTMLInputElement.prototype;
                const setter = Object.getOwnPropertyDescriptor(proto, 'value');
                if (setter && setter.set) setter.set.call(el, v);
                else el.value = v;
                el.dispatchEvent(new Event('input', {{bubbles: true}}));
                el.dispatchEvent(new Event('change', {{bubbles: true}}));
            }};
            const pw = document.querySelector('input[type=password]');
            if (!pw) return {{ok: false, err: 'no password field on page'}};
            // Username = the nearest text/email input that precedes the
            // password field, else the first such input on the page.
            const texts = Array.from(document.querySelectorAll(
                'input[type=text], input[type=email], input:not([type]), ' +
                'input[type=tel]'));
            let userEl = null;
            const pwIdx = Array.prototype.indexOf.call(
                document.querySelectorAll('input'), pw);
            for (const t of texts) {{
                const ti = Array.prototype.indexOf.call(
                    document.querySelectorAll('input'), t);
                if (ti < pwIdx) userEl = t;  // last one before password
            }}
            if (!userEl && texts.length) userEl = texts[0];
            if (userEl) setVal(userEl, user);
            setVal(pw, pass);
            return {{ok: true,
                     username_field: userEl
                        ? (userEl.name || userEl.id || userEl.type) : null,
                     username_filled: !!userEl,
                     password_filled: true, submitted: false}};
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "autofill failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════
# TABS & WINDOWS
# ══════════════════════════════════════════════════════════════════════


def tab_group_by_domain(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all open tabs grouped by domain."""
    try:
        tabs = _list_tabs()
        groups: Dict[str, List[Dict[str, Any]]] = {}
        for t in tabs:
            url = t.get("url", "")
            dom = _domain_of(url) or "(local/internal)"
            groups.setdefault(dom, []).append({
                "id": t.get("id"),
                "title": (t.get("title") or "")[:80],
                "url": url[:160],
            })
        ordered = dict(sorted(groups.items(),
                              key=lambda kv: len(kv[1]), reverse=True))
        return {"ok": True, "result": {
            "domain_count": len(ordered),
            "tab_count": len(tabs),
            "groups": ordered,
        }}
    except Exception as e:
        return _err(e)


def tab_close_duplicates(args: Dict[str, Any]) -> Dict[str, Any]:
    """Close tabs whose URL duplicates an earlier tab; keep the first."""
    try:
        tabs = _list_tabs()
        seen: set = set()
        closed: List[Dict[str, Any]] = []
        for t in tabs:
            url = t.get("url", "")
            if url in seen:
                try:
                    _http_get_json(f"/json/close/{t['id']}")
                    closed.append({"id": t.get("id"), "url": url[:140]})
                except Exception:
                    pass
            else:
                seen.add(url)
        return {"ok": True, "result": {
            "closed": len(closed),
            "kept": len(seen),
            "closed_tabs": closed,
        }}
    except Exception as e:
        return _err(e)


def tab_close_all_except(args: Dict[str, Any]) -> Dict[str, Any]:
    """Close every tab whose URL does NOT contain the given substring.

    args:
      keep_url_contains (str, required): substring; tabs matching survive.
    """
    keep = (args.get("keep_url_contains") or "").strip().lower()
    if not keep:
        return {"ok": False, "error": "keep_url_contains is required"}
    try:
        tabs = _list_tabs()
        kept, closed = [], []
        survivors = [t for t in tabs if keep in (t.get("url") or "").lower()]
        if not survivors:
            return {"ok": False, "error":
                    f"no tab matches '{keep}' — refusing to close everything"}
        for t in tabs:
            url = t.get("url", "")
            if keep in url.lower():
                kept.append({"id": t.get("id"), "url": url[:140]})
            else:
                try:
                    _http_get_json(f"/json/close/{t['id']}")
                    closed.append({"id": t.get("id"), "url": url[:140]})
                except Exception:
                    pass
        return {"ok": True, "result": {
            "closed": len(closed), "kept": len(kept),
            "kept_tabs": kept,
        }}
    except Exception as e:
        return _err(e)


def _set_tab_pin(url_contains: str, pinned: bool) -> Dict[str, Any]:
    """Pin/unpin a tab. CDP has no direct pin RPC, so we drive the tabs
    extension surface via Page targets — Brave honours the `pinned`
    flag through the DevTools target's createTab path only, so for an
    already-open tab we fall back to re-creating it pinned is not
    possible. Instead we use the `Target` domain attribute which Brave
    exposes for pinning on newer builds; if unsupported we report so."""
    try:
        tab = _pick_tab(url_contains)
    except Exception as e:
        return _err(e)
    # Brave/Chrome expose pin state only via the browser-level target.
    # Use the /json metadata: not settable over HTTP. Best-effort via
    # the chrome.tabs surface is unavailable to CDP. We mark via a
    # CDP browser endpoint when present.
    try:
        s = _CDPSession(_http_get_json("/json/version").get(
            "webSocketDebuggerUrl"))
    except Exception as e:
        return _err(e)
    try:
        # Target.activateTarget is universal; pinning isn't a CDP method.
        # We surface a clear, non-raising result rather than pretend.
        return {"ok": False, "error":
                "tab pinning is not exposed over CDP; Brave only supports "
                "pin/unpin via the chrome.tabs extension API. Tab found: "
                f"{tab.get('url','')[:120]}",
                "result": {"tab_id": tab.get("id"),
                           "requested_pinned": pinned}}
    finally:
        s.close()


def tab_pin(args: Dict[str, Any]) -> Dict[str, Any]:
    """Pin the first tab whose URL contains the substring.

    Note: CDP does not expose tab pinning; this reports the limitation
    cleanly rather than failing silently.

    args: url_contains (str, required)
    """
    uc = (args.get("url_contains") or "").strip()
    if not uc:
        return {"ok": False, "error": "url_contains is required"}
    return _set_tab_pin(uc, True)


def tab_unpin(args: Dict[str, Any]) -> Dict[str, Any]:
    """Unpin the first tab whose URL contains the substring.

    Note: CDP does not expose tab pinning; this reports the limitation
    cleanly rather than failing silently.

    args: url_contains (str, required)
    """
    uc = (args.get("url_contains") or "").strip()
    if not uc:
        return {"ok": False, "error": "url_contains is required"}
    return _set_tab_pin(uc, False)


def tab_move_to_new_window(args: Dict[str, Any]) -> Dict[str, Any]:
    """Pop a tab out into its own window — opens the tab's URL in a fresh
    Brave window and closes the original.

    args:
      url_contains (str, required): match the tab to move.
    """
    uc = (args.get("url_contains") or "").strip()
    if not uc:
        return {"ok": False, "error": "url_contains is required"}
    try:
        tab = _pick_tab(uc)
        target_url = tab.get("url", "")
        # Re-open via the browser-level target with newWindow=true.
        ver = _http_get_json("/json/version")
        browser_ws = ver.get("webSocketDebuggerUrl")
        if not browser_ws:
            return {"ok": False, "error":
                    "browser-level CDP endpoint unavailable"}
        s = _CDPSession(browser_ws)
        try:
            res = s.call("Target.createTarget", {
                "url": target_url, "newWindow": True,
            })
        finally:
            s.close()
        new_id = res.get("targetId")
        # Close the original now that it lives in the new window.
        try:
            _http_get_json(f"/json/close/{tab['id']}")
        except Exception:
            pass
        return {"ok": True, "result": {
            "moved_url": target_url[:160],
            "new_target_id": new_id,
            "closed_original": tab.get("id"),
        }}
    except Exception as e:
        return _err(e)


def tabs_save_session(args: Dict[str, Any]) -> Dict[str, Any]:
    """Save the URLs of all currently-open tabs to a named session file
    under brain_state/browser_sessions/.

    args:
      name (str, required): session name.
    """
    name = (args.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name is required"}
    try:
        tabs = _list_tabs()
        entries = [{"url": t.get("url", ""), "title": t.get("title", "")}
                   for t in tabs if t.get("url")]
        payload = {
            "name": name,
            "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "tab_count": len(entries),
            "tabs": entries,
        }
        path = _session_path(name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        return {"ok": True, "result": {
            "name": name, "tab_count": len(entries), "path": path,
        }}
    except Exception as e:
        return _err(e)


def tabs_restore_session(args: Dict[str, Any]) -> Dict[str, Any]:
    """Re-open every tab from a previously saved session.

    args:
      name (str, required): session name to restore.
    """
    name = (args.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name is required"}
    path = _session_path(name)
    if not os.path.exists(path):
        return {"ok": False, "error": f"no saved session named '{name}'"}
    try:
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        from urllib.parse import quote
        opened, failed = [], []
        for entry in payload.get("tabs", []):
            url = entry.get("url", "")
            if not url:
                continue
            try:
                info = _http_get_json(f"/json/new?{quote(url, safe='')}")
                opened.append({"url": url[:140], "id": info.get("id")})
            except Exception as ex:
                failed.append({"url": url[:140], "err": str(ex)})
        return {"ok": True, "result": {
            "name": name, "opened": len(opened),
            "failed": len(failed),
            "opened_tabs": opened,
            "failed_tabs": failed,
        }}
    except Exception as e:
        return _err(e)


def tabs_list_sessions(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all saved tab-sessions with their tab counts and save times."""
    try:
        d = _sessions_dir()
        out = []
        for fn in sorted(os.listdir(d)):
            if not fn.endswith(".json"):
                continue
            full = os.path.join(d, fn)
            try:
                with open(full, "r", encoding="utf-8") as f:
                    p = json.load(f)
                out.append({
                    "name": p.get("name", fn[:-5]),
                    "tab_count": p.get("tab_count", len(p.get("tabs", []))),
                    "saved_at": p.get("saved_at"),
                    "path": full,
                })
            except Exception:
                out.append({"name": fn[:-5], "error": "unreadable",
                            "path": full})
        return {"ok": True, "result": {"count": len(out), "sessions": out}}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════
# PAGE INTERACTION
# ══════════════════════════════════════════════════════════════════════


def scroll_to_bottom(args: Dict[str, Any]) -> Dict[str, Any]:
    """Scroll to the bottom in increments — triggers lazy/infinite-scroll
    loading on the way down.

    args:
      steps (int, opt):        number of scroll increments (default 10).
      pause_ms (int, opt):     pause between steps (default 350).
      url_contains (str, opt): disambiguate tabs.
    """
    steps = max(1, int(args.get("steps", 10)))
    pause = max(0, int(args.get("pause_ms", 350)))
    js = f"""
        new Promise((resolve) => {{
            const steps = {steps};
            const pause = {pause};
            let i = 0;
            const startH = document.documentElement.scrollHeight;
            const tick = () => {{
                window.scrollBy(0, window.innerHeight * 0.9);
                i++;
                if (i >= steps) {{
                    window.scrollTo(0, document.documentElement.scrollHeight);
                    resolve({{
                        steps: i,
                        start_height: startH,
                        end_height: document.documentElement.scrollHeight,
                        final_scroll_y: window.scrollY,
                    }});
                    return;
                }}
                setTimeout(tick, pause);
            }};
            tick();
        }})
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def scroll_to_top(args: Dict[str, Any]) -> Dict[str, Any]:
    """Scroll the page back to the top. args: url_contains (opt)."""
    try:
        _run_js("window.scrollTo(0, 0); 'done'", args.get("url_contains"))
        return {"ok": True, "result": {"scrolled_to": "top"}}
    except Exception as e:
        return _err(e)


def extract_all_links(args: Dict[str, Any]) -> Dict[str, Any]:
    """Pull every <a href> on the page.

    args:
      filter_contains (str, opt): keep only links whose href contains this.
      limit (int, opt):           cap results (default 500).
      url_contains (str, opt):    disambiguate tabs.
    """
    filt = (args.get("filter_contains") or "").lower()
    limit = int(args.get("limit", 500))
    js = f"""
        (() => {{
            const filt = {json.dumps(filt)};
            const limit = {limit};
            const out = [];
            for (const a of document.querySelectorAll('a[href]')) {{
                const href = a.href;
                if (!href) continue;
                if (filt && !href.toLowerCase().includes(filt)) continue;
                out.push({{
                    href,
                    text: (a.innerText || a.textContent || '').trim().slice(0, 120),
                }});
                if (out.length >= limit) break;
            }}
            return out;
        }})()
    """
    try:
        out = _run_js(js, args.get("url_contains")) or []
        return {"ok": True, "result": {"count": len(out), "links": out}}
    except Exception as e:
        return _err(e)


def extract_all_images(args: Dict[str, Any]) -> Dict[str, Any]:
    """Pull every <img src> on the page (with alt text and natural size).

    args:
      limit (int, opt):        cap results (default 300).
      url_contains (str, opt): disambiguate tabs.
    """
    limit = int(args.get("limit", 300))
    js = f"""
        (() => {{
            const limit = {limit};
            const out = [];
            for (const img of document.querySelectorAll('img')) {{
                const src = img.currentSrc || img.src;
                if (!src) continue;
                out.push({{
                    src,
                    alt: (img.alt || '').slice(0, 120),
                    width: img.naturalWidth || null,
                    height: img.naturalHeight || null,
                }});
                if (out.length >= limit) break;
            }}
            return out;
        }})()
    """
    try:
        out = _run_js(js, args.get("url_contains")) or []
        return {"ok": True, "result": {"count": len(out), "images": out}}
    except Exception as e:
        return _err(e)


def extract_main_text(args: Dict[str, Any]) -> Dict[str, Any]:
    """Readability-style main-content extraction — strips nav, header,
    footer, aside, ads, scripts; returns the densest text block.

    args:
      url_contains (str, opt): disambiguate tabs.
    """
    js = """
        (() => {
            const STRIP = 'nav,header,footer,aside,script,style,noscript,' +
                'form,[role=navigation],[role=banner],[role=complementary],' +
                '.ad,.ads,.advert,.advertisement,.sidebar,.cookie,.popup,' +
                '.newsletter,.share,.social';
            // Clone the body so we don't mutate Dean's live page.
            const clone = document.body.cloneNode(true);
            clone.querySelectorAll(STRIP).forEach(n => n.remove());
            // Score candidate containers by text length / link density.
            const cands = Array.from(clone.querySelectorAll(
                'article, main, [role=main], .content, .post, .article, ' +
                '#content, #main, div, section'));
            let best = clone, bestScore = 0;
            for (const el of cands) {
                const txt = (el.innerText || '').trim();
                if (txt.length < 200) continue;
                const links = el.querySelectorAll('a').length;
                const linkDensity = links / (txt.length / 100 + 1);
                const score = txt.length / (1 + linkDensity);
                if (score > bestScore) { bestScore = score; best = el; }
            }
            const text = (best.innerText || '').replace(/\\n{3,}/g, '\\n\\n').trim();
            return {
                title: document.title,
                text: text.slice(0, 50000),
                truncated: text.length > 50000,
                char_count: text.length,
                word_count: text.split(/\\s+/).filter(Boolean).length,
            };
        })()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def extract_table(args: Dict[str, Any]) -> Dict[str, Any]:
    """Parse an HTML <table> into a list of row-dicts (keyed by header).

    args:
      table_index (int, opt):  which table on the page (0-based, default 0).
      url_contains (str, opt): disambiguate tabs.
    """
    idx = int(args.get("table_index", 0))
    js = f"""
        (() => {{
            const tables = Array.from(document.querySelectorAll('table'));
            if (tables.length === 0) return {{ok: false, err: 'no tables'}};
            if ({idx} >= tables.length)
                return {{ok: false, err: 'only ' + tables.length +
                         ' table(s) on page'}};
            const t = tables[{idx}];
            const cellText = (c) => (c.innerText || c.textContent || '')
                .trim().replace(/\\s+/g, ' ');
            // Header = first <thead> row, else first <tr>.
            let headerRow = t.querySelector('thead tr');
            const allRows = Array.from(t.querySelectorAll('tr'));
            let bodyRows = allRows;
            let headers = [];
            if (headerRow) {{
                headers = Array.from(headerRow.querySelectorAll('th,td'))
                    .map(cellText);
                bodyRows = Array.from(t.querySelectorAll('tbody tr'));
                if (bodyRows.length === 0)
                    bodyRows = allRows.filter(r => r !== headerRow);
            }} else if (allRows.length) {{
                headers = Array.from(allRows[0].querySelectorAll('th,td'))
                    .map(cellText);
                bodyRows = allRows.slice(1);
            }}
            if (!headers.length)
                headers = ['col0'];
            const rows = bodyRows.map(r => {{
                const cells = Array.from(r.querySelectorAll('th,td'))
                    .map(cellText);
                const obj = {{}};
                cells.forEach((c, i) => {{
                    obj[headers[i] || ('col' + i)] = c;
                }});
                return obj;
            }}).filter(o => Object.keys(o).length);
            return {{ok: true, table_index: {idx},
                     table_count: tables.length,
                     headers, row_count: rows.length, rows}};
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "extract failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def count_elements(args: Dict[str, Any]) -> Dict[str, Any]:
    """Count elements matching a CSS selector.

    args:
      selector (str, required)
      url_contains (str, opt)
    """
    sel = (args.get("selector") or "").strip()
    if not sel:
        return {"ok": False, "error": "selector is required"}
    js = f"""
        (() => {{
            try {{
                return {{ok: true,
                         count: document.querySelectorAll(
                             {json.dumps(sel)}).length}};
            }} catch (e) {{
                return {{ok: false, err: 'bad selector: ' + e.message}};
            }}
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "count failed")}
        return {"ok": True, "result": {"selector": sel,
                                       "count": res.get("count", 0)}}
    except Exception as e:
        return _err(e)


def element_exists(args: Dict[str, Any]) -> Dict[str, Any]:
    """True/false: does an element matching the CSS selector OR visible
    text exist on the page?

    args:
      selector (str, opt) / text (str, opt): one is required.
      url_contains (str, opt)
    """
    selector = (args.get("selector") or args.get("selector_or_text") or "").strip()
    text = (args.get("text") or "").strip()
    # `selector_or_text` is a convenience: if it doesn't look like a
    # selector, treat it as text.
    if not selector and not text:
        return {"ok": False, "error": "selector or text is required"}
    finder = _finder_expr(selector, text)
    js = f"""
        (() => {{
            try {{
                const el = {finder};
                return {{ok: true, exists: !!el,
                         tag: el ? el.tagName.toLowerCase() : null}};
            }} catch (e) {{
                return {{ok: false, err: e.message}};
            }}
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "check failed")}
        return {"ok": True, "result": {
            "exists": bool(res.get("exists")),
            "tag": res.get("tag"),
        }}
    except Exception as e:
        return _err(e)


def highlight_element(args: Dict[str, Any]) -> Dict[str, Any]:
    """Inject a bright red outline around a matching element — a visual
    debugging aid so Dean can see what Leon is targeting.

    args:
      selector (str, opt) / text (str, opt): one is required.
      url_contains (str, opt)
    """
    selector = (args.get("selector") or args.get("selector_or_text") or "").strip()
    text = (args.get("text") or "").strip()
    if not selector and not text:
        return {"ok": False, "error": "selector or text is required"}
    finder = _finder_expr(selector, text)
    js = f"""
        (() => {{
            const el = {finder};
            if (!el) return {{ok: false, err: 'no match'}};
            el.scrollIntoView({{block: 'center', behavior: 'instant'}});
            const prev = el.style.outline;
            el.style.outline = '3px solid #ff1744';
            el.style.outlineOffset = '2px';
            el.style.boxShadow = '0 0 0 6px rgba(255,23,68,0.25)';
            const r = el.getBoundingClientRect();
            return {{ok: true, tag: el.tagName.toLowerCase(),
                     text: (el.innerText || '').trim().slice(0, 100),
                     bbox: {{x: r.x, y: r.y, w: r.width, h: r.height}},
                     prev_outline: prev}};
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "highlight failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════
# PAGE STATE & DATA
# ══════════════════════════════════════════════════════════════════════


def get_meta_tags(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return all <meta> tags as a dict (keyed by name/property/http-equiv).

    args: url_contains (opt).
    """
    js = """
        (() => {
            const out = {};
            for (const m of document.querySelectorAll('meta')) {
                const key = m.getAttribute('name')
                    || m.getAttribute('property')
                    || m.getAttribute('http-equiv')
                    || m.getAttribute('charset');
                if (!key) continue;
                const val = m.getAttribute('content')
                    || m.getAttribute('charset') || '';
                out[key] = val;
            }
            return out;
        })()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        return {"ok": True, "result": {"count": len(res), "meta": res}}
    except Exception as e:
        return _err(e)


def get_page_performance(args: Dict[str, Any]) -> Dict[str, Any]:
    """Navigation Timing API metrics — load time, DOM-ready, TTFB, etc.

    args: url_contains (opt).
    """
    js = """
        (() => {
            const nav = performance.getEntriesByType('navigation')[0];
            const t = performance.timing || {};
            const round = (x) => (x == null ? null : Math.round(x));
            let metrics;
            if (nav) {
                metrics = {
                    source: 'NavigationTiming L2',
                    dom_interactive_ms: round(nav.domInteractive),
                    dom_content_loaded_ms: round(nav.domContentLoadedEventEnd),
                    load_complete_ms: round(nav.loadEventEnd),
                    ttfb_ms: round(nav.responseStart),
                    response_end_ms: round(nav.responseEnd),
                    dns_ms: round(nav.domainLookupEnd - nav.domainLookupStart),
                    connect_ms: round(nav.connectEnd - nav.connectStart),
                    transfer_size: nav.transferSize ?? null,
                    type: nav.type,
                };
            } else if (t.navigationStart) {
                const base = t.navigationStart;
                metrics = {
                    source: 'NavigationTiming L1',
                    dom_interactive_ms: round(t.domInteractive - base),
                    dom_content_loaded_ms:
                        round(t.domContentLoadedEventEnd - base),
                    load_complete_ms: round(t.loadEventEnd - base),
                    ttfb_ms: round(t.responseStart - base),
                };
            } else {
                metrics = {source: 'unavailable'};
            }
            const paint = {};
            for (const p of performance.getEntriesByType('paint')) {
                paint[p.name] = Math.round(p.startTime);
            }
            return {metrics, paint,
                    resource_count:
                        performance.getEntriesByType('resource').length};
        })()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def get_all_cookies_for_domain(args: Dict[str, Any]) -> Dict[str, Any]:
    """All cookies whose domain matches the given substring. Sensitive
    cookie values (session/token/auth) are redacted.

    args:
      domain (str, required)
      url_contains (str, opt)
    """
    domain = (args.get("domain") or "").strip().lower()
    if not domain:
        return {"ok": False, "error": "domain is required"}
    SENSITIVE = ("session", "token", "auth", "sid", "secret")
    try:
        s = _open_session(args.get("url_contains"))
        try:
            s.call("Network.enable", {})
            res = s.call("Network.getCookies", {})
        finally:
            s.close()
        cookies = res.get("cookies", []) or []
        matched = [c for c in cookies
                   if domain in (c.get("domain") or "").lower()]
        out = []
        for c in matched:
            name = c.get("name", "")
            redact = any(k in name.lower() for k in SENSITIVE)
            out.append({
                "name": name,
                "value": "<redacted>" if redact else c.get("value"),
                "domain": c.get("domain"),
                "path": c.get("path"),
                "expires": c.get("expires"),
                "httpOnly": c.get("httpOnly"),
                "secure": c.get("secure"),
                "sameSite": c.get("sameSite"),
            })
        return {"ok": True, "result": {"domain": domain,
                                       "count": len(out), "cookies": out}}
    except Exception as e:
        return _err(e)


def set_cookie(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set a cookie via CDP.

    args:
      name (str, required)
      value (str, required)
      domain (str, required)
      path (str, opt): default '/'.
      secure (bool, opt) / http_only (bool, opt)
      url_contains (str, opt)
    """
    name = (args.get("name") or "").strip()
    domain = (args.get("domain") or "").strip()
    if not name or "value" not in args or not domain:
        return {"ok": False, "error":
                "name, value, and domain are all required"}
    cookie = {
        "name": name,
        "value": str(args.get("value", "")),
        "domain": domain,
        "path": args.get("path", "/") or "/",
        "secure": bool(args.get("secure", False)),
        "httpOnly": bool(args.get("http_only", False)),
    }
    try:
        s = _open_session(args.get("url_contains"))
        try:
            s.call("Network.enable", {})
            res = s.call("Network.setCookie", cookie)
        finally:
            s.close()
        if not res.get("success", True):
            return {"ok": False, "error": "CDP rejected the cookie"}
        return {"ok": True, "result": {"set": name, "domain": domain,
                                       "path": cookie["path"]}}
    except Exception as e:
        return _err(e)


def clear_cookies(args: Dict[str, Any]) -> Dict[str, Any]:
    """Clear cookies. With `domain`, only cookies for that domain are
    removed; without it, ALL cookies in the browser profile are cleared.

    args:
      domain (str, opt)
      url_contains (str, opt)
    """
    domain = (args.get("domain") or "").strip().lower()
    try:
        s = _open_session(args.get("url_contains"))
        try:
            s.call("Network.enable", {})
            if not domain:
                s.call("Network.clearBrowserCookies", {})
                return {"ok": True, "result": {"cleared": "all cookies"}}
            res = s.call("Network.getCookies", {})
            cookies = res.get("cookies", []) or []
            removed = 0
            for c in cookies:
                if domain in (c.get("domain") or "").lower():
                    try:
                        s.call("Network.deleteCookies", {
                            "name": c.get("name"),
                            "domain": c.get("domain"),
                            "path": c.get("path", "/"),
                        })
                        removed += 1
                    except Exception:
                        pass
            return {"ok": True, "result": {"domain": domain,
                                           "cleared": removed}}
        finally:
            s.close()
    except Exception as e:
        return _err(e)


def execute_js(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run arbitrary JavaScript in the front (or specified) tab and return
    its result. MEDIUM risk — for cases the higher-level tools don't cover.

    args:
      code (str, required): JS expression / IIFE; its value is returned.
      url_contains (str, opt)
    """
    code = (args.get("code") or "").strip()
    if not code:
        return {"ok": False, "error": "code is required"}
    try:
        value = _run_js(code, args.get("url_contains"))
        return {"ok": True, "result": {"value": value}}
    except Exception as e:
        return _err(e)


def wait_for_navigation(args: Dict[str, Any]) -> Dict[str, Any]:
    """Block until the page navigates (URL changes) or finishes loading.

    args:
      timeout_ms (int, opt):   give up after this many ms (default 10000).
      url_contains (str, opt): pick the tab to watch.
    """
    timeout_ms = int(args.get("timeout_ms", 10000))
    try:
        s = _open_session(args.get("url_contains"))
        try:
            start_url = _evaluate(s, "location.href")
            deadline = time.monotonic() + timeout_ms / 1000.0
            while time.monotonic() < deadline:
                time.sleep(0.25)
                try:
                    cur = _evaluate(s, "location.href")
                    ready = _evaluate(s, "document.readyState")
                except Exception:
                    # Navigation can briefly drop the JS context — retry.
                    continue
                if cur != start_url and ready == "complete":
                    return {"ok": True, "result": {
                        "navigated": True,
                        "from": start_url,
                        "to": cur,
                        "ready_state": ready,
                    }}
            cur = _evaluate(s, "location.href")
            return {"ok": False, "error":
                    f"no navigation within {timeout_ms}ms "
                    f"(still at {cur[:120]})"}
        finally:
            s.close()
    except Exception as e:
        return _err(e)


def download_file(args: Dict[str, Any]) -> Dict[str, Any]:
    """Download a file by fetching it inside the page context (so cookies /
    auth carry) and saving the bytes to disk.

    args:
      url (str, required):     file URL to download.
      save_to (str, required): absolute local path to write.
      url_contains (str, opt): tab whose session/cookies to borrow.
    """
    url = (args.get("url") or "").strip()
    save_to = (args.get("save_to") or "").strip()
    if not url or not save_to:
        return {"ok": False, "error": "url and save_to are both required"}
    js = f"""
        (async () => {{
            try {{
                const resp = await fetch({json.dumps(url)},
                    {{credentials: 'include'}});
                if (!resp.ok)
                    return {{ok: false, err: 'HTTP ' + resp.status}};
                const buf = await resp.arrayBuffer();
                const bytes = new Uint8Array(buf);
                let bin = '';
                const CHUNK = 0x8000;
                for (let i = 0; i < bytes.length; i += CHUNK) {{
                    bin += String.fromCharCode.apply(
                        null, bytes.subarray(i, i + CHUNK));
                }}
                return {{ok: true, b64: btoa(bin), size: bytes.length,
                         content_type: resp.headers.get('content-type')}};
            }} catch (e) {{
                return {{ok: false, err: String(e)}};
            }}
        }})()
    """
    try:
        res = _run_js(js, args.get("url_contains")) or {}
        if not res.get("ok"):
            return {"ok": False, "error": res.get("err", "fetch failed")}
        data = base64.b64decode(res.get("b64", ""))
        os.makedirs(os.path.dirname(os.path.abspath(save_to)) or ".",
                    exist_ok=True)
        with open(save_to, "wb") as f:
            f.write(data)
        return {"ok": True, "result": {
            "saved_to": save_to,
            "bytes": len(data),
            "content_type": res.get("content_type"),
        }}
    except Exception as e:
        return _err(e)


# ── tool registry ───────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Forms & autofill
    "browser.form_fill_all":             form_fill_all,
    "browser.form_submit":               form_submit,
    "browser.form_extract":              form_extract,
    "browser.autofill_login":            autofill_login,
    # Tabs & windows
    "browser.tab_group_by_domain":       tab_group_by_domain,
    "browser.tab_close_duplicates":      tab_close_duplicates,
    "browser.tab_close_all_except":      tab_close_all_except,
    "browser.tab_pin":                   tab_pin,
    "browser.tab_unpin":                 tab_unpin,
    "browser.tab_move_to_new_window":    tab_move_to_new_window,
    "browser.tabs_save_session":         tabs_save_session,
    "browser.tabs_restore_session":      tabs_restore_session,
    "browser.tabs_list_sessions":        tabs_list_sessions,
    # Page interaction
    "browser.scroll_to_bottom":          scroll_to_bottom,
    "browser.scroll_to_top":             scroll_to_top,
    "browser.extract_all_links":         extract_all_links,
    "browser.extract_all_images":        extract_all_images,
    "browser.extract_main_text":         extract_main_text,
    "browser.extract_table":             extract_table,
    "browser.count_elements":            count_elements,
    "browser.element_exists":            element_exists,
    "browser.highlight_element":         highlight_element,
    # Page state & data
    "browser.get_meta_tags":             get_meta_tags,
    "browser.get_page_performance":      get_page_performance,
    "browser.get_all_cookies_for_domain": get_all_cookies_for_domain,
    "browser.set_cookie":                set_cookie,
    "browser.clear_cookies":             clear_cookies,
    "browser.execute_js":                execute_js,
    "browser.wait_for_navigation":       wait_for_navigation,
    "browser.download_file":             download_file,
}
