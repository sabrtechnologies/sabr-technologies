"""
info_tools.py — External-data Leon actuator tools.

Free, no-auth public APIs only. Imported by actuator.py and merged into
TOOLS alongside tools_extra.EXTRA_TOOLS. Same contract as the rest of
the actuator: each function takes a dict `args` and returns either
    {"ok": True,  "result": <payload>}
or
    {"ok": False, "error": "<message>"}

Categories:
  - Weather (wttr.in)
  - News (Hacker News firebase API)
  - Stocks (Yahoo Finance public quote/search endpoints)
  - Crypto (CoinGecko)
  - Public info (ipify, ip-api, URL HEAD checks, time zones, quotes, xkcd)
  - Dev (GitHub users/repos/trending, PyPI, npm)
  - Web (URL summarizer)

All outbound HTTP requests:
  - 8s timeout (5s for HEAD checks)
  - User-Agent: "Sabr-SI/1.3 (+https://47industries.com)"
  - Wrapped in try/except — never raise out of a tool
"""

from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────────
# Shared helpers
# ──────────────────────────────────────────────────────────────────────────

_USER_AGENT = "Sabr-SI/1.3 (+https://47industries.com)"
_DEFAULT_TIMEOUT = 8.0


def _http_request(
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    method: str = "GET",
    timeout: float = _DEFAULT_TIMEOUT,
    extra_headers: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Low-level HTTP. Returns {ok, status, headers, body, final_url} or {ok:False, error}."""
    if params:
        qs = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
        sep = "&" if "?" in url else "?"
        url = f"{url}{sep}{qs}" if qs else url
    headers = {"User-Agent": _USER_AGENT, "Accept": "*/*"}
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, headers=headers, method=method)
    started = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read() if method != "HEAD" else b""
            elapsed_ms = int((time.monotonic() - started) * 1000)
            return {
                "ok": True,
                "status": resp.status,
                "headers": {k.lower(): v for k, v in resp.headers.items()},
                "body": body,
                "final_url": resp.geturl(),
                "elapsed_ms": elapsed_ms,
            }
    except urllib.error.HTTPError as e:
        return {
            "ok": False,
            "error": f"HTTP {e.code} for {url}",
            "status": e.code,
        }
    except urllib.error.URLError as e:
        reason = getattr(e, "reason", e)
        msg = str(reason)
        if "timed out" in msg.lower() or "timeout" in msg.lower():
            return {"ok": False, "error": f"request to {url} timed out after {timeout}s"}
        return {"ok": False, "error": f"network error for {url}: {msg}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _http_json(
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    timeout: float = _DEFAULT_TIMEOUT,
    extra_headers: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """GET URL and parse JSON. Returns {ok, result} or {ok:False, error}."""
    if extra_headers is None:
        extra_headers = {}
    extra_headers.setdefault("Accept", "application/json")
    resp = _http_request(url, params=params, timeout=timeout, extra_headers=extra_headers)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "unknown error")}
    try:
        data = json.loads(resp["body"].decode("utf-8", errors="replace"))
        return {"ok": True, "result": data, "_meta": {
            "status": resp["status"],
            "elapsed_ms": resp["elapsed_ms"],
            "final_url": resp["final_url"],
        }}
    except json.JSONDecodeError as e:
        return {"ok": False, "error": f"invalid JSON from {url}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# WEATHER (wttr.in)
# ──────────────────────────────────────────────────────────────────────────


def _wttr_fetch(location: str) -> Dict[str, Any]:
    loc = urllib.parse.quote(location, safe="")
    url = f"https://wttr.in/{loc}?format=j1"
    return _http_json(url)


def weather_now(args: Dict[str, Any]) -> Dict[str, Any]:
    """Current weather via wttr.in. args: {location?: str}."""
    location = (args.get("location") or "").strip() or "auto"
    fetched = _wttr_fetch(location)
    if not fetched.get("ok"):
        return {"ok": False, "error": f"wttr.in: {fetched.get('error')}"}
    data = fetched["result"]
    try:
        cur = (data.get("current_condition") or [{}])[0]
        area_block = (data.get("nearest_area") or [{}])[0]
        area_name = ""
        for key in ("areaName", "region", "country"):
            arr = area_block.get(key) or []
            if arr and isinstance(arr, list) and arr[0].get("value"):
                area_name = arr[0]["value"]
                break
        desc_arr = cur.get("weatherDesc") or []
        description = desc_arr[0]["value"] if desc_arr else ""
        result = {
            "location": location if location != "auto" else (area_name or "auto"),
            "area": area_name,
            "temp_c": _to_num(cur.get("temp_C")),
            "temp_f": _to_num(cur.get("temp_F")),
            "feels_like_c": _to_num(cur.get("FeelsLikeC")),
            "feels_like_f": _to_num(cur.get("FeelsLikeF")),
            "humidity": _to_num(cur.get("humidity")),
            "wind_kmh": _to_num(cur.get("windspeedKmph")),
            "wind_dir": cur.get("winddir16Point"),
            "description": description,
            "uv_index": _to_num(cur.get("uvIndex")),
            "observation_time": cur.get("localObsDateTime"),
        }
        return {"ok": True, "result": result}
    except Exception as e:
        return {"ok": False, "error": f"could not parse wttr response: {e}"}


def weather_forecast(args: Dict[str, Any]) -> Dict[str, Any]:
    """Multi-day forecast via wttr.in. args: {location?: str, days?: int (default 3)}."""
    location = (args.get("location") or "").strip() or "auto"
    days = int(args.get("days") or 3)
    days = max(1, min(days, 3))  # wttr returns up to 3 days
    fetched = _wttr_fetch(location)
    if not fetched.get("ok"):
        return {"ok": False, "error": f"wttr.in: {fetched.get('error')}"}
    data = fetched["result"]
    try:
        forecast = []
        for day in (data.get("weather") or [])[:days]:
            hourly = day.get("hourly") or []
            chance_rain = 0
            condition = ""
            if hourly:
                mid = hourly[len(hourly) // 2]
                chance_rain = _to_num(mid.get("chanceofrain")) or 0
                desc_arr = mid.get("weatherDesc") or []
                condition = desc_arr[0]["value"] if desc_arr else ""
            forecast.append({
                "date": day.get("date"),
                "max_temp_c": _to_num(day.get("maxtempC")),
                "min_temp_c": _to_num(day.get("mintempC")),
                "avg_temp_c": _to_num(day.get("avgtempC")),
                "max_temp_f": _to_num(day.get("maxtempF")),
                "min_temp_f": _to_num(day.get("mintempF")),
                "condition": condition,
                "chance_of_rain": chance_rain,
                "sunrise": (day.get("astronomy") or [{}])[0].get("sunrise"),
                "sunset": (day.get("astronomy") or [{}])[0].get("sunset"),
            })
        return {"ok": True, "result": {"location": location, "days": forecast}}
    except Exception as e:
        return {"ok": False, "error": f"could not parse wttr forecast: {e}"}


def _to_num(v: Any) -> Optional[float]:
    if v is None or v == "":
        return None
    try:
        f = float(v)
        return int(f) if f.is_integer() else f
    except (TypeError, ValueError):
        return None


# ──────────────────────────────────────────────────────────────────────────
# NEWS (Hacker News)
# ──────────────────────────────────────────────────────────────────────────


_HN_BASE = "https://hacker-news.firebaseio.com/v0"


def _hn_fetch_stories(endpoint: str, limit: int) -> Dict[str, Any]:
    limit = max(1, min(int(limit or 10), 30))
    ids_resp = _http_json(f"{_HN_BASE}/{endpoint}.json")
    if not ids_resp.get("ok"):
        return {"ok": False, "error": f"HackerNews: {ids_resp.get('error')}"}
    ids = (ids_resp["result"] or [])[:limit]
    stories: List[Dict[str, Any]] = []
    for sid in ids:
        item_resp = _http_json(f"{_HN_BASE}/item/{sid}.json", timeout=6.0)
        if not item_resp.get("ok"):
            continue
        item = item_resp["result"] or {}
        stories.append({
            "id": item.get("id"),
            "title": item.get("title"),
            "url": item.get("url") or f"https://news.ycombinator.com/item?id={item.get('id')}",
            "score": item.get("score"),
            "author": item.get("by"),
            "comments_count": item.get("descendants"),
            "time": item.get("time"),
        })
    return {"ok": True, "result": stories}


def news_hackernews_top(args: Dict[str, Any]) -> Dict[str, Any]:
    """Top Hacker News stories. args: {limit?: int (default 10, max 30)}."""
    return _hn_fetch_stories("topstories", args.get("limit", 10))


def news_hackernews_ask(args: Dict[str, Any]) -> Dict[str, Any]:
    """Ask Hacker News stories. args: {limit?: int (default 10, max 30)}."""
    return _hn_fetch_stories("askstories", args.get("limit", 10))


# ──────────────────────────────────────────────────────────────────────────
# STOCKS (Yahoo Finance public endpoints)
# ──────────────────────────────────────────────────────────────────────────


def stock_price(args: Dict[str, Any]) -> Dict[str, Any]:
    """Quote a stock. args: {symbol: str}."""
    symbol = (args.get("symbol") or "").strip().upper()
    if not symbol:
        return {"ok": False, "error": "symbol required"}
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(symbol, safe='')}"
    fetched = _http_json(url)
    if not fetched.get("ok"):
        err = fetched.get("error", "")
        if "404" in err:
            return {"ok": False, "error": f"unknown symbol '{symbol}'"}
        return {"ok": False, "error": f"Yahoo Finance: {err}"}
    try:
        data = fetched["result"] or {}
        chart = (data.get("chart") or {})
        if chart.get("error"):
            return {"ok": False, "error": f"Yahoo Finance: {chart['error'].get('description', 'error')}"}
        results = chart.get("result") or []
        if not results:
            return {"ok": False, "error": f"no data for symbol '{symbol}'"}
        meta = results[0].get("meta") or {}
        price = meta.get("regularMarketPrice")
        prev_close = meta.get("chartPreviousClose") or meta.get("previousClose")
        change_pct = None
        if price is not None and prev_close:
            try:
                change_pct = round((float(price) - float(prev_close)) / float(prev_close) * 100, 4)
            except (TypeError, ValueError, ZeroDivisionError):
                change_pct = None
        return {"ok": True, "result": {
            "symbol": meta.get("symbol", symbol),
            "price": price,
            "currency": meta.get("currency"),
            "change_24h_pct": change_pct,
            "previous_close": prev_close,
            "market_state": meta.get("marketState"),
            "exchange": meta.get("exchangeName") or meta.get("fullExchangeName"),
            "instrument_type": meta.get("instrumentType"),
            "long_name": meta.get("longName") or meta.get("shortName"),
        }}
    except Exception as e:
        return {"ok": False, "error": f"could not parse Yahoo response: {e}"}


def stock_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search Yahoo Finance for tickers. args: {query: str}."""
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query required"}
    url = "https://query1.finance.yahoo.com/v1/finance/search"
    fetched = _http_json(url, params={"q": query, "quotesCount": 5, "newsCount": 0})
    if not fetched.get("ok"):
        return {"ok": False, "error": f"Yahoo search: {fetched.get('error')}"}
    try:
        data = fetched["result"] or {}
        quotes = (data.get("quotes") or [])[:5]
        out = []
        for q in quotes:
            out.append({
                "symbol": q.get("symbol"),
                "name": q.get("shortname") or q.get("longname"),
                "exchange": q.get("exchDisp") or q.get("exchange"),
                "type": q.get("quoteType") or q.get("typeDisp"),
                "score": q.get("score"),
            })
        return {"ok": True, "result": out}
    except Exception as e:
        return {"ok": False, "error": f"could not parse Yahoo search: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# CRYPTO (CoinGecko)
# ──────────────────────────────────────────────────────────────────────────


_CG_BASE = "https://api.coingecko.com/api/v3"

_COIN_SYMBOL_MAP = {
    "btc": "bitcoin",
    "eth": "ethereum",
    "sol": "solana",
    "doge": "dogecoin",
    "ada": "cardano",
    "dot": "polkadot",
    "matic": "matic-network",
    "avax": "avalanche-2",
    "ltc": "litecoin",
    "link": "chainlink",
    "xrp": "ripple",
    "bnb": "binancecoin",
    "trx": "tron",
    "shib": "shiba-inu",
    "atom": "cosmos",
    "uni": "uniswap",
    "near": "near",
    "apt": "aptos",
    "arb": "arbitrum",
    "op": "optimism",
}


def crypto_price(args: Dict[str, Any]) -> Dict[str, Any]:
    """Crypto price via CoinGecko. args: {symbol: str, vs?: str (default 'usd')}."""
    symbol = (args.get("symbol") or "").strip().lower()
    vs = (args.get("vs") or "usd").strip().lower()
    if not symbol:
        return {"ok": False, "error": "symbol required"}
    coin_id = _COIN_SYMBOL_MAP.get(symbol, symbol)
    fetched = _http_json(f"{_CG_BASE}/simple/price",
                         params={"ids": coin_id, "vs_currencies": vs,
                                 "include_24hr_change": "true",
                                 "include_market_cap": "true"})
    if not fetched.get("ok"):
        return {"ok": False, "error": f"CoinGecko: {fetched.get('error')}"}
    data = fetched["result"] or {}
    if not data or coin_id not in data:
        return {"ok": False, "error": f"unknown coin '{symbol}' (tried id '{coin_id}')"}
    entry = data[coin_id]
    return {"ok": True, "result": {
        "symbol": symbol,
        "id": coin_id,
        "vs_currency": vs,
        "price": entry.get(vs),
        "market_cap": entry.get(f"{vs}_market_cap"),
        "change_24h_pct": entry.get(f"{vs}_24h_change"),
    }}


def crypto_top10(args: Dict[str, Any]) -> Dict[str, Any]:
    """Top 10 crypto by market cap via CoinGecko. args: {vs?: str (default 'usd')}."""
    vs = (args.get("vs") or "usd").strip().lower()
    fetched = _http_json(f"{_CG_BASE}/coins/markets",
                         params={"vs_currency": vs, "order": "market_cap_desc",
                                 "per_page": 10, "page": 1, "sparkline": "false"})
    if not fetched.get("ok"):
        return {"ok": False, "error": f"CoinGecko: {fetched.get('error')}"}
    coins = fetched["result"] or []
    out = []
    for c in coins:
        out.append({
            "symbol": (c.get("symbol") or "").upper(),
            "name": c.get("name"),
            "price": c.get("current_price"),
            "market_cap": c.get("market_cap"),
            "market_cap_rank": c.get("market_cap_rank"),
            "change_24h_pct": c.get("price_change_percentage_24h"),
            "vs_currency": vs,
        })
    return {"ok": True, "result": out}


# ──────────────────────────────────────────────────────────────────────────
# PUBLIC INFO
# ──────────────────────────────────────────────────────────────────────────


def public_ip(args: Dict[str, Any]) -> Dict[str, Any]:
    """Your public IP via ipify."""
    fetched = _http_json("https://api.ipify.org", params={"format": "json"})
    if not fetched.get("ok"):
        return {"ok": False, "error": f"ipify: {fetched.get('error')}"}
    data = fetched["result"] or {}
    return {"ok": True, "result": {"ip": data.get("ip")}}


def ip_geolocation(args: Dict[str, Any]) -> Dict[str, Any]:
    """Geolocate an IP. args: {ip?: str (default current public IP)}."""
    ip = (args.get("ip") or "").strip()
    target = ip or ""
    url = f"http://ip-api.com/json/{urllib.parse.quote(target, safe='')}"
    fetched = _http_json(url)
    if not fetched.get("ok"):
        return {"ok": False, "error": f"ip-api: {fetched.get('error')}"}
    data = fetched["result"] or {}
    if data.get("status") != "success":
        return {"ok": False, "error": f"ip-api: {data.get('message', 'lookup failed')}"}
    return {"ok": True, "result": {
        "ip": data.get("query"),
        "country": data.get("country"),
        "country_code": data.get("countryCode"),
        "region": data.get("regionName"),
        "city": data.get("city"),
        "zip": data.get("zip"),
        "isp": data.get("isp"),
        "org": data.get("org"),
        "lat": data.get("lat"),
        "lon": data.get("lon"),
        "timezone": data.get("timezone"),
    }}


def url_status_check(args: Dict[str, Any]) -> Dict[str, Any]:
    """HEAD a URL, return status + headers. args: {url: str}."""
    url = (args.get("url") or "").strip()
    if not url:
        return {"ok": False, "error": "url required"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    resp = _http_request(url, method="HEAD", timeout=5.0)
    if not resp.get("ok"):
        # Some servers reject HEAD. Try a small GET as fallback.
        if resp.get("status") in (405, 501) or "405" in str(resp.get("error", "")):
            resp = _http_request(url, method="GET", timeout=5.0)
            if not resp.get("ok"):
                return {"ok": False, "error": resp.get("error", "request failed")}
        else:
            return {"ok": False, "error": resp.get("error", "request failed")}
    headers = resp.get("headers") or {}
    final_url = resp.get("final_url")
    result = {
        "status_code": resp.get("status"),
        "server": headers.get("server"),
        "content_type": headers.get("content-type"),
        "content_length": headers.get("content-length"),
        "response_time_ms": resp.get("elapsed_ms"),
    }
    if final_url and final_url != url:
        result["redirected_to"] = final_url
    return {"ok": True, "result": result}


def time_in_zone(args: Dict[str, Any]) -> Dict[str, Any]:
    """Current time in a timezone. args: {timezone: str (IANA, e.g. 'America/New_York')}."""
    tz_name = (args.get("timezone") or "").strip()
    if not tz_name:
        return {"ok": False, "error": "timezone required (IANA name e.g. 'America/New_York')"}
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo(tz_name)
    except Exception as e:
        return {"ok": False, "error": f"unknown timezone '{tz_name}': {e}"}
    now = datetime.now(tz)
    return {"ok": True, "result": {
        "timezone": tz_name,
        "iso": now.isoformat(),
        "year": now.year,
        "month": now.month,
        "day": now.day,
        "hour": now.hour,
        "minute": now.minute,
        "second": now.second,
        "day_of_week": now.strftime("%A"),
        "is_dst": bool(now.dst()),
        "utc_offset": now.strftime("%z"),
    }}


def time_world_clock(args: Dict[str, Any]) -> Dict[str, Any]:
    """Time across several zones. args: {timezones?: list of IANA names}."""
    zones = args.get("timezones") or [
        "America/New_York",
        "America/Los_Angeles",
        "Europe/London",
        "Asia/Tokyo",
    ]
    if not isinstance(zones, list):
        return {"ok": False, "error": "timezones must be a list"}
    out = []
    for z in zones:
        sub = time_in_zone({"timezone": z})
        if sub.get("ok"):
            r = sub["result"]
            out.append({
                "timezone": r["timezone"],
                "iso": r["iso"],
                "hour": r["hour"],
                "minute": r["minute"],
                "day_of_week": r["day_of_week"],
                "is_dst": r["is_dst"],
            })
        else:
            out.append({"timezone": z, "error": sub.get("error")})
    return {"ok": True, "result": out}


def random_quote(args: Dict[str, Any]) -> Dict[str, Any]:
    """Random quote via quotable.io."""
    fetched = _http_json("https://api.quotable.io/random")
    if not fetched.get("ok"):
        return {"ok": False, "error": f"quotable: {fetched.get('error')}"}
    data = fetched["result"] or {}
    return {"ok": True, "result": {
        "content": data.get("content"),
        "author": data.get("author"),
        "tags": data.get("tags") or [],
        "length": data.get("length"),
    }}


def xkcd_today(args: Dict[str, Any]) -> Dict[str, Any]:
    """Latest xkcd comic."""
    fetched = _http_json("https://xkcd.com/info.0.json")
    if not fetched.get("ok"):
        return {"ok": False, "error": f"xkcd: {fetched.get('error')}"}
    data = fetched["result"] or {}
    return {"ok": True, "result": {
        "num": data.get("num"),
        "title": data.get("title") or data.get("safe_title"),
        "img": data.get("img"),
        "alt": data.get("alt"),
        "day": data.get("day"),
        "month": data.get("month"),
        "year": data.get("year"),
        "link": f"https://xkcd.com/{data.get('num')}/" if data.get("num") else None,
    }}


# ──────────────────────────────────────────────────────────────────────────
# DEV-FOCUSED
# ──────────────────────────────────────────────────────────────────────────


def github_user_info(args: Dict[str, Any]) -> Dict[str, Any]:
    """Public GitHub profile. args: {username: str}."""
    username = (args.get("username") or "").strip()
    if not username:
        return {"ok": False, "error": "username required"}
    fetched = _http_json(f"https://api.github.com/users/{urllib.parse.quote(username, safe='')}",
                         extra_headers={"Accept": "application/vnd.github+json"})
    if not fetched.get("ok"):
        err = fetched.get("error", "")
        if "404" in err:
            return {"ok": False, "error": f"GitHub user '{username}' not found"}
        return {"ok": False, "error": f"GitHub: {err}"}
    d = fetched["result"] or {}
    return {"ok": True, "result": {
        "login": d.get("login"),
        "name": d.get("name"),
        "bio": d.get("bio"),
        "company": d.get("company"),
        "location": d.get("location"),
        "blog": d.get("blog"),
        "twitter": d.get("twitter_username"),
        "public_repos": d.get("public_repos"),
        "public_gists": d.get("public_gists"),
        "followers": d.get("followers"),
        "following": d.get("following"),
        "created_at": d.get("created_at"),
        "avatar_url": d.get("avatar_url"),
        "html_url": d.get("html_url"),
    }}


def github_repo_info(args: Dict[str, Any]) -> Dict[str, Any]:
    """Public GitHub repo info. args: {owner: str, repo: str}."""
    owner = (args.get("owner") or "").strip()
    repo = (args.get("repo") or "").strip()
    if not owner or not repo:
        return {"ok": False, "error": "owner and repo required"}
    url = f"https://api.github.com/repos/{urllib.parse.quote(owner, safe='')}/{urllib.parse.quote(repo, safe='')}"
    fetched = _http_json(url, extra_headers={"Accept": "application/vnd.github+json"})
    if not fetched.get("ok"):
        err = fetched.get("error", "")
        if "404" in err:
            return {"ok": False, "error": f"GitHub repo '{owner}/{repo}' not found"}
        return {"ok": False, "error": f"GitHub: {err}"}
    d = fetched["result"] or {}
    return {"ok": True, "result": {
        "full_name": d.get("full_name"),
        "description": d.get("description"),
        "language": d.get("language"),
        "stars": d.get("stargazers_count"),
        "forks": d.get("forks_count"),
        "open_issues": d.get("open_issues_count"),
        "watchers": d.get("subscribers_count"),
        "default_branch": d.get("default_branch"),
        "license": (d.get("license") or {}).get("spdx_id"),
        "topics": d.get("topics") or [],
        "homepage": d.get("homepage"),
        "html_url": d.get("html_url"),
        "created_at": d.get("created_at"),
        "updated_at": d.get("updated_at"),
        "pushed_at": d.get("pushed_at"),
        "archived": d.get("archived"),
        "fork": d.get("fork"),
    }}


def github_repo_trending(args: Dict[str, Any]) -> Dict[str, Any]:
    """Trending repos by scraping github.com/trending. args: {language?: str, since?: 'daily'|'weekly'|'monthly'}."""
    language = (args.get("language") or "").strip()
    since = (args.get("since") or "daily").strip().lower()
    if since not in ("daily", "weekly", "monthly"):
        since = "daily"
    path = "https://github.com/trending"
    if language:
        path = f"{path}/{urllib.parse.quote(language, safe='')}"
    path = f"{path}?since={since}"
    resp = _http_request(path, extra_headers={"Accept": "text/html"})
    if not resp.get("ok"):
        return {"ok": False, "error": f"github trending: {resp.get('error')}"}
    html = resp["body"].decode("utf-8", errors="replace")
    # Each trending repo lives in <article class="Box-row">
    articles = re.findall(r'<article class="Box-row">(.*?)</article>', html, re.DOTALL)
    out: List[Dict[str, Any]] = []
    for art in articles[:10]:
        m_repo = re.search(r'<h2[^>]*>\s*<a[^>]*href="/([^"]+)"', art)
        if not m_repo:
            continue
        full_name = m_repo.group(1).strip()
        m_desc = re.search(r'<p class="col-9[^"]*"[^>]*>(.*?)</p>', art, re.DOTALL)
        description = ""
        if m_desc:
            description = re.sub(r"<[^>]+>", "", m_desc.group(1)).strip()
        m_lang = re.search(r'<span itemprop="programmingLanguage">([^<]+)</span>', art)
        lang = m_lang.group(1).strip() if m_lang else None
        stars = None
        # Total stars: first <a href="/{owner}/{repo}/stargazers">
        m_stars = re.search(
            rf'<a[^>]+href="/{re.escape(full_name)}/stargazers"[^>]*>(.*?)</a>',
            art, re.DOTALL)
        if m_stars:
            txt = re.sub(r"<[^>]+>", "", m_stars.group(1)).strip().replace(",", "")
            try:
                stars = int(re.sub(r"\D", "", txt) or "0")
            except ValueError:
                stars = None
        # Stars today/this period
        m_period = re.search(r'<span class="d-inline-block float-sm-right">(.*?)</span>',
                             art, re.DOTALL)
        period_stars = None
        if m_period:
            ptxt = re.sub(r"<[^>]+>", "", m_period.group(1)).strip()
            period_match = re.search(r"([\d,]+)", ptxt)
            if period_match:
                try:
                    period_stars = int(period_match.group(1).replace(",", ""))
                except ValueError:
                    period_stars = None
        out.append({
            "repo": full_name,
            "url": f"https://github.com/{full_name}",
            "description": description,
            "language": lang,
            "stars": stars,
            "stars_this_period": period_stars,
        })
    return {"ok": True, "result": {"since": since, "language": language or None, "repos": out}}


def pypi_package_info(args: Dict[str, Any]) -> Dict[str, Any]:
    """PyPI package metadata. args: {package: str}."""
    package = (args.get("package") or "").strip()
    if not package:
        return {"ok": False, "error": "package required"}
    fetched = _http_json(f"https://pypi.org/pypi/{urllib.parse.quote(package, safe='')}/json")
    if not fetched.get("ok"):
        err = fetched.get("error", "")
        if "404" in err:
            return {"ok": False, "error": f"PyPI package '{package}' not found"}
        return {"ok": False, "error": f"PyPI: {err}"}
    d = fetched["result"] or {}
    info = d.get("info") or {}
    version = info.get("version")
    releases = d.get("releases") or {}
    latest_release_iso = None
    if version and version in releases and releases[version]:
        latest_release_iso = releases[version][0].get("upload_time_iso_8601") \
            or releases[version][0].get("upload_time")
    return {"ok": True, "result": {
        "name": info.get("name"),
        "version": version,
        "summary": info.get("summary"),
        "author": info.get("author"),
        "license": info.get("license"),
        "home_page": info.get("home_page"),
        "project_url": info.get("project_url") or info.get("package_url"),
        "requires_python": info.get("requires_python"),
        "latest_release_iso": latest_release_iso,
    }}


def npm_package_info(args: Dict[str, Any]) -> Dict[str, Any]:
    """npm registry metadata. args: {package: str}."""
    package = (args.get("package") or "").strip()
    if not package:
        return {"ok": False, "error": "package required"}
    # npm allows scoped names like @scope/name — encode the slash but not the @.
    encoded = urllib.parse.quote(package, safe="@/")
    fetched = _http_json(f"https://registry.npmjs.org/{encoded}")
    if not fetched.get("ok"):
        err = fetched.get("error", "")
        if "404" in err:
            return {"ok": False, "error": f"npm package '{package}' not found"}
        return {"ok": False, "error": f"npm: {err}"}
    d = fetched["result"] or {}
    dist_tags = d.get("dist-tags") or {}
    latest = dist_tags.get("latest")
    times = d.get("time") or {}
    repo = d.get("repository")
    if isinstance(repo, dict):
        repo_url = repo.get("url")
    else:
        repo_url = repo
    return {"ok": True, "result": {
        "name": d.get("name"),
        "latest_version": latest,
        "description": d.get("description"),
        "license": d.get("license"),
        "homepage": d.get("homepage"),
        "repository": repo_url,
        "author": (d.get("author") or {}).get("name") if isinstance(d.get("author"), dict) else d.get("author"),
        "latest_release_iso": times.get(latest) if latest else None,
        "keywords": d.get("keywords") or [],
    }}


# ──────────────────────────────────────────────────────────────────────────
# WEB UTILS
# ──────────────────────────────────────────────────────────────────────────


def web_summarize_url(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fetch a URL and extract title, description, first 5 paragraphs. args: {url: str}."""
    url = (args.get("url") or "").strip()
    if not url:
        return {"ok": False, "error": "url required"}
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    resp = _http_request(url, extra_headers={"Accept": "text/html,application/xhtml+xml"})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "fetch failed")}
    body = resp["body"]
    # Try to detect encoding from Content-Type, fall back to utf-8.
    ctype = (resp.get("headers") or {}).get("content-type", "")
    encoding = "utf-8"
    m = re.search(r"charset=([\w\-]+)", ctype, re.I)
    if m:
        encoding = m.group(1)
    try:
        html = body.decode(encoding, errors="replace")
    except (LookupError, TypeError):
        html = body.decode("utf-8", errors="replace")
    full_length = len(html)
    # Try BeautifulSoup if available, otherwise fall back to regex.
    title = ""
    description = ""
    paragraphs: List[str] = []
    try:
        from bs4 import BeautifulSoup  # type: ignore
        soup = BeautifulSoup(html, "html.parser")
        if soup.title and soup.title.string:
            title = soup.title.string.strip()
        meta = soup.find("meta", attrs={"name": "description"}) \
            or soup.find("meta", attrs={"property": "og:description"})
        if meta and meta.get("content"):
            description = meta["content"].strip()
        for p in soup.find_all("p")[:20]:
            text = p.get_text(" ", strip=True)
            if text and len(text) > 30:
                paragraphs.append(text)
            if len(paragraphs) >= 5:
                break
    except ImportError:
        # Regex fallback — good enough for many pages
        m_title = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.DOTALL)
        if m_title:
            title = re.sub(r"\s+", " ", m_title.group(1)).strip()
        m_desc = re.search(
            r'<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)["\']',
            html, re.I)
        if not m_desc:
            m_desc = re.search(
                r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']+)["\']',
                html, re.I)
        if m_desc:
            description = m_desc.group(1).strip()
        for m_p in re.finditer(r"<p[^>]*>(.*?)</p>", html, re.I | re.DOTALL):
            txt = re.sub(r"<[^>]+>", "", m_p.group(1))
            txt = re.sub(r"\s+", " ", txt).strip()
            if txt and len(txt) > 30:
                paragraphs.append(txt)
            if len(paragraphs) >= 5:
                break

    excerpt = "\n\n".join(paragraphs)
    if len(excerpt) > 8000:
        excerpt = excerpt[:8000].rsplit(" ", 1)[0] + "…"

    return {"ok": True, "result": {
        "url": resp.get("final_url") or url,
        "title": title,
        "description": description,
        "excerpt": excerpt,
        "paragraph_count": len(paragraphs),
        "full_length": full_length,
    }}


# ──────────────────────────────────────────────────────────────────────────
# Registry — wired into actuator.TOOLS alongside tools_extra.EXTRA_TOOLS
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS = {
    "info.weather_now": weather_now,
    "info.weather_forecast": weather_forecast,
    "info.news_hackernews_top": news_hackernews_top,
    "info.news_hackernews_ask": news_hackernews_ask,
    "info.stock_price": stock_price,
    "info.stock_search": stock_search,
    "info.crypto_price": crypto_price,
    "info.crypto_top10": crypto_top10,
    "info.public_ip": public_ip,
    "info.ip_geolocation": ip_geolocation,
    "info.url_status_check": url_status_check,
    "info.time_in_zone": time_in_zone,
    "info.time_world_clock": time_world_clock,
    "info.random_quote": random_quote,
    "info.xkcd_today": xkcd_today,
    "info.github_user_info": github_user_info,
    "info.github_repo_info": github_repo_info,
    "info.github_repo_trending": github_repo_trending,
    "info.pypi_package_info": pypi_package_info,
    "info.npm_package_info": npm_package_info,
    "info.web_summarize_url": web_summarize_url,
}
