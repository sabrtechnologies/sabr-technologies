"""
Accessibility tree integration + element caching.

This is the single biggest speed upgrade for desktop control:
  - Current: OCR (500ms) or Vision API (1.5s, $0.003/call) per click
  - With this: Accessibility tree lookup in 10-50ms, FREE

How it works:
  1. Query the OS accessibility tree for UI elements
  2. Match elements by name, role, or description
  3. Cache discovered elements so repeat actions skip ALL inference
  4. Click directly at the element's coordinates

Platform support:
  - Linux: AT-SPI2 via python-atspi or subprocess (atspi2-explorer)
  - macOS: AXUIElement via pyobjc (atomacos wrapper)
  - Windows: UI Automation via pywinauto (best support)

Falls back gracefully if accessibility APIs aren't available.
"""

import hashlib
import os
import platform
import subprocess
import time
from typing import Any, Dict, List, Optional, Tuple

SYSTEM = platform.system()

# ── Element cache ────────────────────────────────────────────────────
# Caches element positions by (app_title, element_text, element_role).
# TTL of 30 seconds — UI layouts don't change that fast.

_element_cache: Dict[str, Dict] = {}
_CACHE_TTL = 30  # seconds


def _cache_key(app: str, text: str, role: str = "") -> str:
    return hashlib.md5(f"{app}:{text}:{role}".encode()).hexdigest()


def _cache_get(app: str, text: str, role: str = "") -> Optional[Dict]:
    key = _cache_key(app, text, role)
    entry = _element_cache.get(key)
    if entry and time.time() - entry["ts"] < _CACHE_TTL:
        return entry
    if entry:
        del _element_cache[key]
    return None


def _cache_set(app: str, text: str, role: str, x: int, y: int, w: int, h: int):
    key = _cache_key(app, text, role)
    _element_cache[key] = {
        "x": x, "y": y, "w": w, "h": h,
        "center_x": x + w // 2, "center_y": y + h // 2,
        "ts": time.time(),
    }


def cache_clear(args: Dict[str, Any] = None) -> Dict[str, Any]:
    """Clear the element cache."""
    count = len(_element_cache)
    _element_cache.clear()
    return {"ok": True, "cleared": count}


def cache_stats(args: Dict[str, Any] = None) -> Dict[str, Any]:
    """Get cache statistics."""
    now = time.time()
    active = sum(1 for e in _element_cache.values() if now - e["ts"] < _CACHE_TTL)
    return {"ok": True, "total": len(_element_cache), "active": active, "ttl": _CACHE_TTL}


# ── Linux AT-SPI2 ───────────────────────────────────────────────────

def _atspi_find_elements(name_pattern: str = "", role: str = "") -> List[Dict]:
    """Find UI elements via AT-SPI2 on Linux (GNOME/GTK apps)."""
    elements = []
    try:
        # Try python-atspi first
        import pyatspi
        desktop = pyatspi.Registry.getDesktop(0)
        for app in desktop:
            if app is None:
                continue
            try:
                _walk_atspi(app, name_pattern, role, elements, depth=0, max_depth=8)
            except Exception:
                continue
    except ImportError:
        # Fallback: use gdbus or busctl to query AT-SPI
        try:
            r = subprocess.run(
                ["busctl", "--user", "tree", "org.a11y.atspi.Registry"],
                capture_output=True, text=True, timeout=5,
            )
            # Very limited fallback — can detect if AT-SPI is running
            if r.returncode == 0:
                elements.append({"note": "AT-SPI2 is running but python-atspi not installed. pip install pyatspi"})
        except Exception:
            pass
    return elements


def _walk_atspi(obj, name_pattern: str, role_filter: str, results: list, depth: int, max_depth: int):
    """Recursively walk AT-SPI tree."""
    if depth > max_depth or len(results) > 50:
        return
    try:
        import pyatspi
        name = obj.name or ""
        role_name = obj.getRoleName() or ""

        if name_pattern and name_pattern.lower() in name.lower():
            try:
                ext = obj.queryComponent()
                bbox = ext.getExtents(pyatspi.DESKTOP_COORDS)
                results.append({
                    "name": name,
                    "role": role_name,
                    "x": bbox.x, "y": bbox.y,
                    "w": bbox.width, "h": bbox.height,
                })
            except Exception:
                results.append({"name": name, "role": role_name})

        if role_filter and role_filter.lower() in role_name.lower():
            try:
                ext = obj.queryComponent()
                bbox = ext.getExtents(pyatspi.DESKTOP_COORDS)
                results.append({
                    "name": name,
                    "role": role_name,
                    "x": bbox.x, "y": bbox.y,
                    "w": bbox.width, "h": bbox.height,
                })
            except Exception:
                results.append({"name": name, "role": role_name})

        for i in range(obj.childCount):
            child = obj.getChildAtIndex(i)
            if child:
                _walk_atspi(child, name_pattern, role_filter, results, depth + 1, max_depth)
    except Exception:
        pass


# ── macOS Accessibility ──────────────────────────────────────────────

def _macos_find_elements(name_pattern: str = "", role: str = "") -> List[Dict]:
    """Find UI elements via macOS Accessibility API."""
    elements = []
    try:
        from ApplicationServices import (
            AXUIElementCreateSystemWide,
            AXUIElementCopyAttributeValue,
        )
        from Quartz import kAXFocusedApplicationAttribute

        system = AXUIElementCreateSystemWide()
        err, focused_app = AXUIElementCopyAttributeValue(system, kAXFocusedApplicationAttribute, None)
        if err == 0 and focused_app:
            _walk_macos(focused_app, name_pattern, role, elements, depth=0, max_depth=8)
    except ImportError:
        # Try atomacos
        try:
            import atomacos
            app = atomacos.getAppRefByLocalizedName("")  # Frontmost app
            _walk_atomacos(app, name_pattern, role, elements, depth=0, max_depth=8)
        except ImportError:
            elements.append({"note": "Install pyobjc or atomacos for macOS accessibility. pip install pyobjc-framework-ApplicationServices"})
    return elements


def _walk_atomacos(obj, name_pattern, role_filter, results, depth, max_depth):
    """Walk accessibility tree using atomacos."""
    if depth > max_depth or len(results) > 50:
        return
    try:
        import atomacos
        name = getattr(obj, "AXTitle", "") or getattr(obj, "AXDescription", "") or ""
        role_name = getattr(obj, "AXRole", "")
        if name_pattern and name_pattern.lower() in name.lower():
            pos = getattr(obj, "AXPosition", None)
            size = getattr(obj, "AXSize", None)
            entry = {"name": name, "role": role_name}
            if pos and size:
                entry.update({"x": int(pos[0]), "y": int(pos[1]),
                             "w": int(size[0]), "h": int(size[1])})
            results.append(entry)
        for child in getattr(obj, "AXChildren", []) or []:
            _walk_atomacos(child, name_pattern, role_filter, results, depth + 1, max_depth)
    except Exception:
        pass


def _walk_macos(element, name_pattern, role_filter, results, depth, max_depth):
    """Walk accessibility tree using native PyObjC."""
    if depth > max_depth or len(results) > 50:
        return
    try:
        from ApplicationServices import AXUIElementCopyAttributeValue
        err, title = AXUIElementCopyAttributeValue(element, "AXTitle", None)
        name = str(title) if err == 0 and title else ""
        err, role = AXUIElementCopyAttributeValue(element, "AXRole", None)
        role_name = str(role) if err == 0 and role else ""

        if name_pattern and name_pattern.lower() in name.lower():
            entry = {"name": name, "role": role_name}
            err, pos = AXUIElementCopyAttributeValue(element, "AXPosition", None)
            err2, size = AXUIElementCopyAttributeValue(element, "AXSize", None)
            if err == 0 and err2 == 0 and pos and size:
                entry.update({"x": int(pos.x), "y": int(pos.y),
                             "w": int(size.width), "h": int(size.height)})
            results.append(entry)

        err, children = AXUIElementCopyAttributeValue(element, "AXChildren", None)
        if err == 0 and children:
            for child in children:
                _walk_macos(child, name_pattern, role_filter, results, depth + 1, max_depth)
    except Exception:
        pass


# ── Windows UI Automation ────────────────────────────────────────────

def _windows_find_elements(name_pattern: str = "", role: str = "") -> List[Dict]:
    """Find UI elements via Windows UI Automation (pywinauto)."""
    elements = []
    try:
        from pywinauto import Desktop
        desktop = Desktop(backend="uia")
        for win in desktop.windows():
            try:
                if name_pattern:
                    # Search within each window
                    found = win.descendants(title_re=f".*{name_pattern}.*")
                    for el in found[:20]:
                        rect = el.rectangle()
                        elements.append({
                            "name": el.window_text(),
                            "role": el.friendly_class_name(),
                            "x": rect.left, "y": rect.top,
                            "w": rect.width(), "h": rect.height(),
                            "window": win.window_text(),
                        })
                if role:
                    found = win.descendants(control_type=role)
                    for el in found[:20]:
                        rect = el.rectangle()
                        elements.append({
                            "name": el.window_text(),
                            "role": el.friendly_class_name(),
                            "x": rect.left, "y": rect.top,
                            "w": rect.width(), "h": rect.height(),
                            "window": win.window_text(),
                        })
            except Exception:
                continue
    except ImportError:
        elements.append({"note": "Install pywinauto for Windows UI Automation. pip install pywinauto"})
    return elements


# ── Unified tool functions ───────────────────────────────────────────

def a11y_find(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find UI elements by name or role using the OS accessibility tree.

    Args:
        name: Text to search for in element names/labels
        role: Element role to filter (button, text, checkbox, etc.)
    """
    name = (args.get("name") or "").strip()
    role = (args.get("role") or "").strip()

    if not name and not role:
        return {"ok": False, "error": "name or role is required"}

    # Check cache first
    cached = _cache_get("*", name, role)
    if cached:
        return {"ok": True, "source": "cache", "elements": [cached]}

    if SYSTEM == "Linux":
        elements = _atspi_find_elements(name, role)
    elif SYSTEM == "Darwin":
        elements = _macos_find_elements(name, role)
    elif SYSTEM == "Windows":
        elements = _windows_find_elements(name, role)
    else:
        return {"ok": False, "error": f"Unsupported platform: {SYSTEM}"}

    # Cache results
    for el in elements:
        if "x" in el and "w" in el:
            _cache_set("*", el.get("name", ""), el.get("role", ""),
                      el["x"], el["y"], el["w"], el["h"])

    return {"ok": True, "source": "live", "elements": elements, "count": len(elements)}


def a11y_click(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find and click a UI element by name using accessibility tree.

    This is the FAST alternative to click_element (vision API, 1.5s).
    Uses accessibility tree: 10-50ms, zero API cost.

    Args:
        name: Text/label of the element to click
        role: Optional role filter (button, text, etc.)
    """
    name = (args.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name is required"}
    role = (args.get("role") or "").strip()

    # Check cache first
    cached = _cache_get("*", name, role)
    if cached:
        cx, cy = cached["center_x"], cached["center_y"]
        _do_click(cx, cy)
        return {"ok": True, "source": "cache", "x": cx, "y": cy, "element": name}

    # Find via accessibility
    result = a11y_find({"name": name, "role": role})
    if not result.get("ok") or not result.get("elements"):
        return {"ok": False, "error": f"Element '{name}' not found in accessibility tree"}

    # Click the first match that has coordinates
    for el in result["elements"]:
        if "x" in el and "w" in el:
            cx = el["x"] + el["w"] // 2
            cy = el["y"] + el["h"] // 2
            _do_click(cx, cy)
            return {"ok": True, "source": "a11y", "x": cx, "y": cy,
                    "element": el.get("name", name), "role": el.get("role", "")}

    return {"ok": False, "error": f"Element '{name}' found but has no coordinates"}


def _do_click(x: int, y: int):
    """Perform a click using the platform compat layer."""
    try:
        from platform_compat import platform as P
        P.mouse_click(x, y)
    except Exception:
        # Direct fallback
        if SYSTEM == "Linux":
            subprocess.run(["xdotool", "mousemove", str(x), str(y)], capture_output=True)
            subprocess.run(["xdotool", "click", "1"], capture_output=True)
        elif SYSTEM == "Darwin":
            subprocess.run(["cliclick", f"c:{x},{y}"], capture_output=True)


# ── Export ────────────────────────────────────────────────────────────

EXTRA_TOOLS = {
    "a11y.find":        a11y_find,
    "a11y.click":       a11y_click,
    "a11y.cache_clear": cache_clear,
    "a11y.cache_stats": cache_stats,
}
