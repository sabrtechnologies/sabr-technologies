#!/bin/bash
# Sabr SI — Uninstall
#
#   ~/leon-brain/uninstall.sh              show what WOULD be removed, touch nothing
#   ~/leon-brain/uninstall.sh --yes        actually remove it
#
# Flags:
#   --yes                   perform the removal (without this, nothing is deleted)
#   --purge-memories        delete brain_state outright instead of archiving it
#   --remove-claude-code    also uninstall the global @anthropic-ai/claude-code npm package
#
# Two rules this script will not break:
#
#   1. It archives the SI's identity — .env and brain_state, the name it was
#      given and everything it has learned — BEFORE deleting anything, and
#      REFUSES to continue if that archive cannot be written. Erasing a mind
#      because somebody typed one command is the act B4 took out of the
#      installer; it does not get to come back in through the uninstaller.
#
#   2. It does not remove what it did not install. Homebrew, python3, tmux,
#      portaudio and your Claude Code login are shared with the rest of your
#      machine and may predate this product. They are reported, with the exact
#      command to remove them yourself, never removed for you.
#
# Everything it deliberately leaves behind is printed at the end. An uninstaller
# that quietly leaves things around is how people stop trusting an installer.
#
# NOTE: intentionally no `set -e`, same as bootstrap.sh — failures are handled
# and reported where they happen instead of exiting silently mid-step.

G='\033[38;5;39m'; C='\033[38;5;45m'; Y='\033[0;33m'; R='\033[0;31m'; D='\033[2m'; N='\033[0m'
say(){ echo -e "$@"; }

DO_IT=""; PURGE=""; RM_CLAUDE=""
for arg in "$@"; do
  case "$arg" in
    --yes|-y)             DO_IT="1" ;;
    --purge-memories)     PURGE="1" ;;
    --remove-claude-code) RM_CLAUDE="1" ;;
    -h|--help)            sed -n '2,29p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) say "${R}Unknown option: $arg${N}  (try --help)"; exit 2 ;;
  esac
done

# Default to THE TREE THIS SCRIPT LIVES IN, not a guessed $HOME/leon-brain.
#
# Caught 2026-08-10 by a full install -> uninstall -> reinstall run in a clean
# container. The SI was unpacked to /root/inst/leon-brain (any path that is not
# literally $HOME/leon-brain does it), and the uninstaller — invoked from
# INSIDE that very tree — reported "Nothing to remove: there is no SI installed
# here" and exited 0. It was standing in the install it could not see.
#
# That is the worst possible failure for an uninstaller: it does nothing, says
# so cheerfully, and looks like success. The owner believes the SI is gone. It
# is not. ~/.leon survives, so the NEXT install silently inherits a dead SI's
# skills, lessons and tool health — the exact bug the cognition handling was
# added to prevent, walked straight back in through the front door.
#
# $0 is not reliable (sourcing, symlinks, `bash uninstall.sh` from elsewhere),
# so resolve the real directory of this file. LEON_INSTALL_DIR still wins when
# set, for the genuine "uninstall a tree I am not inside" case.
_SELF="${BASH_SOURCE[0]:-$0}"
_SELF_DIR="$(cd "$(dirname "$_SELF")" 2>/dev/null && pwd -P)"
INSTALL_DIR="${LEON_INSTALL_DIR:-${_SELF_DIR:-$HOME/leon-brain}}"

# ── MARKER GATE — DO NOT REMOVE ──────────────────────────────────────
# INSTALL_DIR can come from LEON_INSTALL_DIR, which is user-supplied, and
# the recursive-force delete below runs on it with no confirmation. A typo,
# a stale exported variable, or a copied script pointed at $HOME, /etc or
# /var would delete that tree instead. --preserve-root only protects "/".
# (Deliberately not quoting the delete command literally here: an ordering
# test greps this file for it, and a copy in a comment gives a false match.)
#
# uninstall.py already learned this the hard way (2026-08-10 near-miss)
# and checks for run.py + brain/ + server/ before it deletes anything.
# uninstall.sh never got the same guard — and uninstall.py forwards
# LEON_INSTALL_DIR straight into this script, so the gap applied to BOTH
# entry points. Refuse to delete anything that is not demonstrably an SI
# install. Fail closed: an aborted uninstall costs a minute, a wrong
# rm -rf costs everything.
_abort_bad_target() {
    printf '\n  REFUSING TO UNINSTALL.\n\n' >&2
    printf '  Target: %s\n' "$INSTALL_DIR" >&2
    printf '  Reason: %s\n\n' "$1" >&2
    printf '  This does not look like an SI install, and this script would\n' >&2
    printf '  have run "rm -rf" on it. Nothing has been deleted.\n\n' >&2
    printf '  Check LEON_INSTALL_DIR, or cd into the install and re-run.\n\n' >&2
    exit 2
}

[ -n "$INSTALL_DIR" ] || _abort_bad_target "path is empty"
[ "$INSTALL_DIR" != "/" ] || _abort_bad_target "path is the filesystem root"
[ "$INSTALL_DIR" != "$HOME" ] || _abort_bad_target "path is your home directory"
case "$INSTALL_DIR" in
    /etc|/etc/*|/usr|/usr/*|/var|/var/*|/bin|/bin/*|/sbin|/sbin/*|/lib|/lib/*|/boot|/boot/*|/opt|/dev|/dev/*|/proc|/proc/*|/sys|/sys/*)
        _abort_bad_target "path is a system directory" ;;
esac
if [ -d "$INSTALL_DIR" ]; then
    # The install marker, stated once explicitly so a reader (or an audit) can
    # see the guard without unrolling the loop below.
    [ -f "$INSTALL_DIR/run.py" ] || _abort_bad_target "no install marker (run.py) in $INSTALL_DIR"
    for _m in run.py brain server; do
        [ -e "$INSTALL_DIR/$_m" ] || \
            _abort_bad_target "missing '$_m' — every SI install has run.py, brain/ and server/"
    done
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
ARCHIVE="$HOME/si-identity-backup-$STAMP.tar.gz"
FAILED=0

size_of(){ [ -e "$1" ] && du -sh "$1" 2>/dev/null | awk '{print $1}' || echo "-"; }

# PIDs of THIS install's interpreter, never including the uninstaller itself.
# If the owner runs this as   .venv/bin/python uninstall.py   (the documented
# command) then their own process matches the pattern, and a bare pkill kills
# the uninstaller mid-run: archive written, autostart still installed, tree
# still on disk, no error shown. Exclude self and parent, always.
_si_pids(){
  pgrep -f "$INSTALL_DIR/.venv/bin/python" 2>/dev/null \
    | grep -vx "$$" | grep -vx "$PPID" | tr '\n' ' '
}

# Stop the SI, scoped to THIS install's interpreter exactly like bootstrap.sh,
# so an unrelated python process is never killed. Idempotent — safe to call
# more than once; returns immediately when nothing is running.
_STOPPED_ALREADY=""
_stop_si(){
  [ -n "$_STOPPED_ALREADY" ] && return 0
  if [ -z "${RUNNING:-}" ] && [ -z "${HAVE_TMUX_SESSION:-}" ]; then
    _STOPPED_ALREADY=1
    return 0
  fi
  say "Stopping the SI..."
  _TARGETS="$(_si_pids)"
  [ -n "$_TARGETS" ] && kill $_TARGETS 2>/dev/null
  tmux kill-session -t leon 2>/dev/null
  sleep 1
  STILL="$(_si_pids)"
  if [ -n "$STILL" ]; then
    kill -9 $STILL 2>/dev/null
    sleep 1
    STILL="$(_si_pids)"
  fi
  if [ -n "$STILL" ]; then
    say "${Y}[WARN]${N} still running: $STILL — remove may leave files behind"
  else
    say "${G}[OK]${N} stopped"
  fi
  _STOPPED_ALREADY=1
}

# ── Inventory ─────────────────────────────────────────────────────────
# Read the machine, do not assume the install looks like the happy path.
say ""
say "${C}Sabr SI — uninstall${N}"
say ""
say "This machine:"

if [ -d "$INSTALL_DIR" ]; then
  say "  install        $INSTALL_DIR  ($(size_of "$INSTALL_DIR"))"
  [ -d "$INSTALL_DIR/.venv" ]       && say "    venv         $(size_of "$INSTALL_DIR/.venv")"
  [ -d "$INSTALL_DIR/brain_state" ] && say "    brain_state  $(size_of "$INSTALL_DIR/brain_state")   ${D}(memories, identity, everything it learned)${N}"
  [ -f "$INSTALL_DIR/.env" ]        && say "    .env         ${D}(its name, your name, keys)${N}"
else
  say "  install        ${D}none at $INSTALL_DIR${N}"
fi

# B4 leaves the previous install behind on purpose (reclaiming that disk is a
# second destructive act, so it belongs to the owner). This is where the owner
# gets to make that call.
# A BASH ARRAY, not a space-joined string. It was a string until 2026-08-11,
# re-split unquoted at the removal loop below — so on any account whose name
# has a space in it (Windows "mr. sabr", macOS "/Users/First Last") each path
# tore into two bogus tokens. rm -rf on a nonexistent path is a silent no-op
# and exits 0, so `[ -d "$d" ]` came back false and the uninstaller printed
# "[OK] removed" over a directory that was still sitting there — with the old
# install's .env, and live API keys, inside it. A false success is worse than
# a failure: nobody goes looking.
ROLLBACKS=()
# leon-brain.failed.<pid> added 2026-08-11. bootstrap.sh parks a broken tree
# there on purpose when an install fails after the swap — but the glob here
# only ever matched the DOT-prefixed staging/previous names, so a failed
# install left a full copy of the customer's .env (API keys, tenant token) and
# brain_state on disk that this uninstaller never even listed. "Uninstalled"
# then meant the credentials were still sitting in the home directory.
for d in "$HOME"/.leon-brain-previous.* "$HOME"/.leon-brain-staging.* "$HOME"/leon-brain.failed.*; do
  [ -d "$d" ] && { ROLLBACKS+=("$d"); say "  leftover       $d  ($(size_of "$d"))"; }
done

RUNNING="$(_si_pids)"
[ -n "$RUNNING" ] && say "  running        pid(s)$([ -n "$RUNNING" ] && echo " $RUNNING")"
if command -v tmux >/dev/null 2>&1 && tmux has-session -t leon 2>/dev/null; then
  HAVE_TMUX_SESSION="1"
  say "  tmux session   leon"
fi

HAVE_NPM_PKG=""
if command -v npm >/dev/null 2>&1; then
  if npm ls -g --depth=0 @anthropic-ai/claude-code >/dev/null 2>&1; then
    HAVE_NPM_PKG="1"
    say "  npm global     @anthropic-ai/claude-code"
  fi
fi

BREW_PKGS=""
if command -v brew >/dev/null 2>&1; then
  for p in portaudio tmux; do
    brew list --formula "$p" >/dev/null 2>&1 && BREW_PKGS="$BREW_PKGS $p"
  done
fi

if [ ! -d "$INSTALL_DIR" ] && [ -z "$ROLLBACKS" ] && [ -z "$HAVE_NPM_PKG" ]; then
  say ""
  say "${G}Nothing to remove — there is no SI installed here.${N}"
  say "${D}If you installed somewhere else: LEON_INSTALL_DIR=/path $0${N}"
  exit 0
fi

# ── Dry run is the default ────────────────────────────────────────────
if [ -z "$DO_IT" ]; then
  say ""
  say "${Y}Nothing has been removed.${N} With --yes this would:"
  say ""
  if [ -n "$RUNNING" ] || [ -n "$HAVE_TMUX_SESSION" ]; then
    say "  · stop the running SI (only processes under $INSTALL_DIR/.venv)"
  fi
  if [ -d "$INSTALL_DIR" ]; then
    if [ -n "$PURGE" ]; then
      say "  · ${R}DELETE brain_state and .env permanently${N} (--purge-memories)"
    else
      say "  · save .env + brain_state to ${C}$HOME/si-identity-backup-<timestamp>.tar.gz${N}"
    fi
    say "  · remove $INSTALL_DIR (tree, venv, helper scripts)"
  fi
  [ -n "$ROLLBACKS" ] && say "  · remove the leftover previous-install directories listed above"
  if [ -n "$HAVE_NPM_PKG" ]; then
    if [ -n "$RM_CLAUDE" ]; then
      say "  · npm rm -g @anthropic-ai/claude-code"
    else
      say "  · ${D}leave @anthropic-ai/claude-code installed (add --remove-claude-code to remove it)${N}"
    fi
  fi
  [ -n "$BREW_PKGS" ] && say "  · ${D}leave brew packages alone:$BREW_PKGS — shared with your machine${N}"
  say ""
  say "Run it for real with:"
  say "    ${C}$0 --yes${N}"
  say ""
  exit 0
fi

# ── Identity first. Nothing is deleted until it is preserved. ─────────
if [ -d "$INSTALL_DIR" ] && [ -z "$PURGE" ]; then
  KEEP=""
  [ -e "$INSTALL_DIR/.env" ]        && KEEP="$KEEP .env"
  [ -e "$INSTALL_DIR/brain_state" ] && KEEP="$KEEP brain_state"
  # ~/.leon holds skills.db, lessons.db, reflection.db, self_repair.db and
  # tool_health.db — everything the SI actually LEARNED — and it lives
  # OUTSIDE the install tree. It was in neither the archive nor the removal,
  # so "identity and memories" was a false promise AND a reinstall silently
  # inherited a dead SI's skills. Detected OUTSIDE the KEEP guard on purpose:
  # a tree with no .env/brain_state yet still has cognition worth saving, and
  # gating on KEEP would delete ~/.leon with no archive behind it.
  COG=""
  [ -d "$HOME/.leon" ] && COG="-C $HOME .leon"
  if [ -n "$KEEP" ] || [ -n "$COG" ]; then
    # STOP THE SI FIRST — this used to happen AFTER the archive, and that
    # ordering made it impossible to uninstall a running SI at all.
    #
    # Caught 2026-08-10 by installing via bootstrap.sh, booting the SI for real,
    # and then uninstalling while it was live — the actual situation every owner
    # is in, since the SI autostarts. A live SI writes brain_state continuously.
    # tar exits non-zero when a file changes underneath it, the archive was
    # judged failed, and rule 1 ("refuse to delete if identity cannot be saved")
    # fired correctly — and blocked the uninstall forever. Observed: [STOPPED],
    # nothing removed, two interpreters still running, no archive. The only way
    # out was for the owner to know to kill the SI by hand first, which is
    # exactly the knowledge an uninstaller exists to not require.
    #
    # Stopping first also makes the snapshot CONSISTENT rather than torn — the
    # archive is now taken of a quiesced brain, not one mid-write.
    _stop_si
    say ""
    say "Saving identity before removing anything..."
    # shellcheck disable=SC2086
    if tar czf "$ARCHIVE" -C "$INSTALL_DIR" $KEEP $COG 2>/dev/null && [ -s "$ARCHIVE" ]; then
      # This tarball contains .env — live API keys in plaintext. Default umask
      # would leave it 0644 in a home directory that other accounts can read.
      # Owner-only, from the moment it exists.
      chmod 600 "$ARCHIVE" 2>/dev/null
      say "${G}[OK]${N} $ARCHIVE  ($(size_of "$ARCHIVE"))"
      say "    ${Y}Contains .env — real API keys. Treat it like a password file.${N}"
    else
      rm -f "$ARCHIVE"
      say ""
      say "${R}[STOPPED]${N} Could not write the identity archive to $ARCHIVE."
      say "Nothing has been removed. Free some space (or pass --purge-memories if"
      say "you genuinely want this SI's memories deleted) and run this again."
      exit 1
    fi
  fi
fi

# Idempotent: called before the archive (so the snapshot is consistent and the
# archive can actually be written) and again here, in case there was nothing to
# archive and the first call never ran. Second call is a no-op once stopped.
_stop_si

# ── Auto-start registration ───────────────────────────────────────────
# MUST run before the tree is deleted. A leftover systemd unit points at a
# start.sh that no longer exists, so systemd retries it on every boot and the
# user gets a permanently failed service for software they uninstalled. The
# launchd equivalent is worse — it respawns on a loop and spams system.log.
UNIT="$HOME/.config/systemd/user/sabr-si.service"
PLIST="$HOME/Library/LaunchAgents/com.sabr.si.plist"
if [ -f "$UNIT" ]; then
  systemctl --user disable --now sabr-si.service >/dev/null 2>&1
  rm -f "$UNIT"
  systemctl --user daemon-reload >/dev/null 2>&1
  say "${G}[OK]${N} removed auto-start (systemd user unit)"
fi
if [ -f "$PLIST" ]; then
  launchctl unload "$PLIST" >/dev/null 2>&1
  rm -f "$PLIST"
  say "${G}[OK]${N} removed auto-start (launchd agent)"
fi
# The GUI installer registers a THIRD autostart artifact on Linux that this
# script never knew about (sabr_installer.py writes ~/.config/autostart/
# sabr-si.desktop). Uninstalling left it behind permanently: a desktop entry
# firing at every login for a deleted install. Same class of ghost as the
# systemd unit above, just written by the other installer.
DESKTOP_AUTOSTART="$HOME/.config/autostart/sabr-si.desktop"
if [ -f "$DESKTOP_AUTOSTART" ]; then
  rm -f "$DESKTOP_AUTOSTART"
  say "${G}[OK]${N} removed auto-start (desktop autostart entry)"
fi

# ── Remove ────────────────────────────────────────────────────────────
if [ -d "$INSTALL_DIR" ]; then
  rm -rf "$INSTALL_DIR"
  if [ -d "$INSTALL_DIR" ]; then
    say "${R}[FAILED]${N} $INSTALL_DIR is still there — check permissions"
    FAILED=1
  else
    say "${G}[OK]${N} removed $INSTALL_DIR"
  fi
fi

# The learned-cognition dir, now that it is safely inside the archive.
if [ -d "$HOME/.leon" ]; then
  rm -rf "$HOME/.leon"
  if [ -d "$HOME/.leon" ]; then
    say "${R}[FAILED]${N} could not remove $HOME/.leon"; FAILED=1
  else
    say "${G}[OK]${N} removed $HOME/.leon (learned skills, lessons, reflections)"
  fi
fi

for d in ${ROLLBACKS+"${ROLLBACKS[@]}"}; do
  rm -rf "$d"
  if [ -d "$d" ]; then
    say "${R}[FAILED]${N} could not remove $d"; FAILED=1
  else
    say "${G}[OK]${N} removed $d"
  fi
done

if [ -n "$HAVE_NPM_PKG" ] && [ -n "$RM_CLAUDE" ]; then
  # install_client.py falls back to `sudo npm install -g`, so the package may
  # be root-owned. Try as this user first and only then ask for sudo, out
  # loud, rather than silently escalating.
  if npm rm -g @anthropic-ai/claude-code >/dev/null 2>&1; then
    say "${G}[OK]${N} removed @anthropic-ai/claude-code"
  elif command -v sudo >/dev/null 2>&1; then
    say "${Y}[i]${N} that package was installed as root — asking for sudo to remove it"
    if sudo npm rm -g @anthropic-ai/claude-code >/dev/null 2>&1; then
      say "${G}[OK]${N} removed @anthropic-ai/claude-code"
    else
      say "${Y}[WARN]${N} could not remove it — do it with: sudo npm rm -g @anthropic-ai/claude-code"
    fi
  else
    say "${Y}[WARN]${N} could not remove it — do it with: npm rm -g @anthropic-ai/claude-code"
  fi
fi

# ── What is deliberately still here ───────────────────────────────────
say ""
say "${C}Left behind, on purpose:${N}"
[ -f "$ARCHIVE" ] && say "  · ${G}$ARCHIVE${N} — this SI's identity and memories."
[ -f "$ARCHIVE" ] && say "    ${D}Delete it yourself when you are sure. Restoring is: reinstall, then${N}"
[ -f "$ARCHIVE" ] && say "    ${D}To bring this SI back: reinstall, then BEFORE its first boot run${N}"
[ -f "$ARCHIVE" ] && say "    ${C}bash ~/leon-brain/restore_identity.sh $ARCHIVE${N}"
[ -f "$ARCHIVE" ] && say "    ${D}Do not just untar it — .leon belongs in your home directory, not${N}"
[ -f "$ARCHIVE" ] && say "    ${D}in the install, and a plain untar puts it where nothing reads it.${N}"
if [ -n "$HAVE_NPM_PKG" ] && [ -z "$RM_CLAUDE" ]; then
  say "  · @anthropic-ai/claude-code — you may use it outside this product."
  say "    ${D}npm rm -g @anthropic-ai/claude-code${N}"
fi
if [ -n "$BREW_PKGS" ]; then
  say "  · brew packages:$BREW_PKGS — installed for the SI but shared machine-wide."
  say "    ${D}brew uninstall$BREW_PKGS${N}"
fi
say "  · Homebrew and python3 themselves, and your Claude Code login (~/.claude)."
say "  · macOS microphone / screen-recording permissions, if you granted them."
say "    ${D}System Settings → Privacy & Security → remove the entry there.${N}"
say ""

if [ "$FAILED" -ne 0 ]; then
  say "${R}Uninstall finished with errors — see the [FAILED] lines above.${N}"
  exit 1
fi
say "${G}Uninstalled.${N}"
say ""
