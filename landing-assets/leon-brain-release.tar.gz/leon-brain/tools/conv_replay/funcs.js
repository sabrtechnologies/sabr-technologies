            function _normUserLine(s) {
                return (s || '').replace(/^\[Attached file:[^\]]*\]\s*/gi, '')
                    .toLowerCase()
                    // Punctuation is NOT signal here. The stored copy comes back
                    // re-punctuated by STT/the brain ("do it" vs "Do it."), so
                    // strict byte equality missed the claim and the poll painted
                    // a second bubble. Strip it and compare content only.
                    // Explicit character class, NOT \p{L}: this file is served to
                    // whatever browser he's holding, and a \p{} escape that fails
                    // to parse takes the ENTIRE module down, not just this line.
                    .replace(/['’]/g, '')                       // don't -> dont (no word split)
                    .replace(/[.,!?;:"()\[\]{}…—–-]/g, ' ')
                    .replace(/\s+/g, ' ').trim()
                    // STT revisions differ by a LEADING filler token and nothing
                    // else — "okay leon do it" vs "do it". Dropping a fixed
                    // filler prefix from both sides is safe in a way that fuzzy
                    // similarity is not: it can never merge two different
                    // instructions, only two renderings of the same one.
                    .replace(/^(?:ok|okay|um|uh|so|and|alright|right|hey|yeah|leon)\s+/g, '')
                    .replace(/^(?:ok|okay|um|uh|so|and|alright|right|hey|yeah|leon)\s+/g, '')
                    .trim();
            }

            function _sameUtterance(a, b) {
                return !!a && !!b && a === b;
            }

            function _userRowText(row) {
                if (!row) return '';
                const label = row.querySelector && row.querySelector('.conv-name-dean');
                if (label) {
                    let out = '';
                    for (const n of row.childNodes) {
                        if (n !== label) out += (n.textContent || '');
                    }
                    return out;
                }
                // Markup with no label node. Only the two labels we have ever
                // shipped, so this can never eat the start of a real message.
                return (row.textContent || '').replace(/^\s*(?:Dean|You)\s*:\s*/i, '');
            }

            function _userLinePainted(text, excludeEl) {
                const body = document.getElementById('conv-body');
                if (!body) return false;
                const want = _normUserLine(text);
                if (!want) return false;
                const kids = Array.from(body.children).slice(-8);
                for (const k of kids) {
                    if (excludeEl && (k === excludeEl || excludeEl.contains(k))) continue;
                    const u = k.querySelector && k.querySelector('.conv-user');
                    if (!u) continue;
                    if (_sameUtterance(_normUserLine(_userRowText(u)), want)) return true;
                }
                return false;
            }

            function _claimUserEcho(text) {
                const body = document.getElementById('conv-body');
                if (!body) return false;
                const want = _normUserLine(text);
                if (!want) return false;
                for (const k of Array.from(body.children).slice(-10)) {
                    if (!k.dataset || k.dataset.echoPending !== '1') continue;
                    // NO wall-clock expiry on the pending marker. A turn can run
                    // for many minutes, and pullConvo is paused for its whole
                    // duration (_turnStreaming), so any timeout measured from
                    // paint time expires the echo before reconcile is even
                    // possible — which guarantees a duplicate on every long
                    // turn. The one-to-one claim below is the only bound needed.
                    const u = k.querySelector('.conv-user');
                    if (!u) continue;
                    if (_sameUtterance(_normUserLine(_userRowText(u)), want)) {
                        delete k.dataset.echoPending;   // reconciled — keep the bubble
                        // Deliberately NOT rewriting the bubble text to the
                        // stored copy: the echo was painted without the
                        // "[Attached file: ...]" prefix and the stored row has
                        // it, so an in-place upgrade pastes that plumbing into
                        // his conversation. What's on screen is what he said.
                        return true;
                    }
                }
                return false;
            }

            function _paintUserEcho(text) {
                const body = document.getElementById('conv-body');
                if (!body || !text) return;
                const div = document.createElement('div');
                div.className = 'conv-turn';
                div.dataset.echoPending = '1';
                div.innerHTML = '<div class="conv-user"><span class="conv-name-dean">Dean:</span>'
                    + escapeHtml(text) + '</div>';
                body.appendChild(div);
                body.scrollTop = body.scrollHeight;
            }

            function appendConvTurn(userText, brainText, _fromRestore) {
                const body = document.getElementById('conv-body');
                if (!body) return;
                const div = document.createElement('div');
                div.className = 'conv-turn';
                if (!userText && !brainText) return;
                const userHtml = userText ? `<div class="conv-user"><span class="conv-name-dean">Dean:</span>${escapeHtml(userText)}</div>` : '';
                const brainHtml = brainText ? `<div class="conv-brain"><span class="conv-name-leon">Leon:</span>${renderConvText(brainText)}</div>` : '';
                div.innerHTML = `
                    ${userHtml}
                    ${brainHtml}
                `;
                // Stick-to-bottom: measure BEFORE appending. After appendChild
                // scrollHeight has already grown, so checking afterward is never
                // true and it would never follow new content.
                const wasAtBottom = body.scrollTop + body.clientHeight >= body.scrollHeight - 40;
                body.appendChild(div);
                if (wasAtBottom) body.scrollTop = body.scrollHeight;
                while (body.children.length > 100) body.removeChild(body.firstChild);
                if (!_fromRestore) _saveConvTurn(userText, brainText);
            }

            function _saveConvTurn(userText, brainText) {
                try {
                    const hist = JSON.parse(localStorage.getItem(CONV_STORAGE_KEY) || '[]');
                    hist.push({ user: userText || '', brain: brainText || '' });
                    while (hist.length > CONV_MAX_TURNS) hist.shift();
                    localStorage.setItem(CONV_STORAGE_KEY, JSON.stringify(hist));
                } catch(e) { /* localStorage full or unavailable */ }
            }

            async function pullConvo() {
                if (_turnStreaming) return;   // don't reconcile mid-stream
                try {
                    const r = await fetch('/api/claude/conversation?since=' + _convLastTs + '&limit=80', { cache: 'no-store' });
                    if (!r.ok) return;
                    const d = await r.json();
                    if (!d.ok || !Array.isArray(d.turns)) return;
                    const body = document.getElementById('conv-body');
                    if (!body) return;
                    const wasAtBottom = body.scrollTop + body.clientHeight >= body.scrollHeight - 60;
                    let appended = false;
                    for (const t of d.turns) {
                        const text = (t.text || '').trim();
                        if (!text) continue;
                        if (t.ts > _convLastTs) _convLastTs = t.ts;
                        if (t.ts <= _convClearedBefore) continue;   // hidden by Clear
                        const key = t.ts + ':' + t.role + ':' + text.slice(0, 48);
                        if (_convSeen.has(key)) continue;
                        _convSeen.add(key);
                        // Was this assistant turn produced on THIS device (we
                        // streamed it live) or somewhere else (your phone)?
                        let remoteTurn = false;
                        if (t.role !== 'user') {
                            if (_pendingPreviewEl) {
                                // local turn — already shown + spoken here; just
                                // swap the live preview for the stored copy.
                                _pendingPreviewEl.remove();
                                _pendingPreviewEl = null;
                            } else {
                                remoteTurn = true;
                            }
                        }
                        _removeThinking();   // a real turn landed — clear the dots
                        // His line is already on screen from the send echo —
                        // don't stack the stored copy under it. Ignore any copy
                        // living inside the preview we're about to delete.
                        if (t.role === 'user' && _claimUserEcho(text)) continue;
                        const div = document.createElement('div');
                        div.className = 'conv-turn';
                        if (t.role === 'user') {
                            div.innerHTML = '<div class="conv-user"><span class="conv-name-dean">Dean:</span>' + escapeHtml(text) + '</div>';
                        } else {
                            div.innerHTML = '<div class="conv-brain"><span class="conv-name-leon">Leon:</span>' + renderConvText(text) + '</div>';
                        }
                        // Hide a back-to-back identical turn (any residual dup
                        // already in the store from before the store-level fix).
                        if (body.lastElementChild &&
                            body.lastElementChild.textContent.trim() === div.textContent.trim()) {
                            _convSeen.add(key);
                            continue;
                        }
                        body.appendChild(div);
                        appended = true;
                        // Speak replies that came from ANOTHER device so this
                        // screen talks too — but never replay old history on load.
                        if (remoteTurn && _convPrimed) { try { _maybeBrowserVoice(text); } catch (e) {} }
                    }
                    if (appended) {
                        while (body.children.length > 140) body.removeChild(body.firstChild);
                        if (wasAtBottom) body.scrollTop = body.scrollHeight;
                    }
                } catch (e) { /* offline / transient — try again next tick */ }
            }
