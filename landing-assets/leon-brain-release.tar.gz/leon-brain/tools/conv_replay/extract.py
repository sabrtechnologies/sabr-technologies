"""Pull the REAL conversation functions out of dashboard/index.html by brace
matching, so the harness tests shipped code rather than a paraphrase."""
import re, sys

SRC = open(sys.argv[1] if len(sys.argv)>1 else '/opt/leon-brain/dashboard/index.html').read()
WANT = ["_normUserLine", "_sameUtterance", "_userRowText", "_userLinePainted", "_claimUserEcho",
        "_paintUserEcho", "appendConvTurn", "_saveConvTurn", "pullConvo"]

out = []
for name in WANT:
    m = re.search(r'^[ \t]*(?:async\s+)?function\s+' + re.escape(name) + r'\s*\(', SRC, re.M)
    if not m:
        print(f"// MISSING {name}", file=sys.stderr)
        continue
    i = SRC.index('{', m.end() - 1)
    depth, j = 0, i
    while j < len(SRC):
        c = SRC[j]
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                break
        j += 1
    out.append(SRC[m.start():j + 1])

print("\n\n".join(out))
