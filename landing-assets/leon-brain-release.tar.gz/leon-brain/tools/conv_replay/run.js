// Replays a real turn through the REAL dashboard functions under jsdom.
// Scenario is taken from live capture: one brain_response_start carrying the
// user text (server emits exactly one), then the store rows pullConvo fetches.
const fs = require('fs');
const { JSDOM } = require('jsdom');

const dom = new JSDOM('<body><div id="conv-body"></div></body>');
global.document = dom.window.document;
global.window = dom.window;

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function renderConvText(s) { return escapeHtml(s); }
function _removeThinking() {}
function _maybeBrowserVoice() {}
const localStorage = { getItem: () => null, setItem: () => {} };
let _pendingPreviewEl = null, _pendingPreviewAt = 0, _turnStreaming = false;
let _convPrimed = true, _convLastTs = 0, _convClearedBefore = 0;
const _convSeen = new Set();
const CONV_STORAGE_KEY = 'k', CONV_MAX_TURNS = 200;
let STORE = { ok: true, turns: [] };
global.fetch = async () => ({ ok: true, json: async () => STORE });

// The browser never receives dashboard/index.html verbatim. server/__init__.py
// rewrites `conv-name-dean">Dean:` to LEON_USER_NAME (default "You") on the way
// out, per-SI branding. Testing the disk bytes therefore tests a file nobody
// loads — which is exactly how the label/guard desync shipped three times.
// LABEL=<name> replays the SERVED form.
const LABEL = process.env.LABEL || 'Dean';
let _funcs = fs.readFileSync(__dirname + '/funcs.js', 'utf8');
if (LABEL !== 'Dean') {
  _funcs = _funcs.split('conv-name-dean">Dean:').join('conv-name-dean">' + LABEL + ':');
}
console.log(`--- replaying with user label "${LABEL}:" ---`);
eval(_funcs);

const body = () => document.getElementById('conv-body');
const deanRows = () => body().querySelectorAll('.conv-user').length;
const dump = () => Array.from(body().children).map(
  c => c.textContent.replace(/\s+/g, ' ').trim().slice(0, 46));

async function scenario(label, { typed, storeText, sendText }) {
  body().innerHTML = '';
  _convSeen.clear(); _convLastTs = 0; _pendingPreviewEl = null; _turnStreaming = false;

  // 1. send path: dashboard paints the echo the instant he hits enter
  if (typed) _paintUserEcho(sendText);

  // 2. brain_response_start (ONE frame, carries `user`) -> onResponseStart guard
  const showUserLine = sendText && !_userLinePainted(sendText);
  if (showUserLine) _paintUserEcho(sendText);
  const s = document.createElement('div');
  s.className = 'conv-turn conv-streaming';
  s.innerHTML = '<div class="conv-brain">Leon:</div>';
  body().appendChild(s);

  // 3. brain_response_end -> preview kept until the stored copy lands
  _turnStreaming = false; _pendingPreviewEl = s;

  // 4. pullConvo reconciles against the store
  const now = Date.now() / 1000;
  STORE = { ok: true, turns: [
    { ts: now, role: 'user', text: storeText },
    { ts: now + 1, role: 'assistant', text: 'ack' },
  ] };
  await pullConvo();
  await pullConvo();   // the second scheduled call (onResponseEnd fires two)

  const n = deanRows();
  console.log(`${n === 1 ? 'PASS' : 'FAIL'}  ${label}\n      Dean rows=${n}  ${JSON.stringify(dump())}`);
  return n;
}

(async () => {
  // Exactly what was captured live today: Dean typed "helllo??" in the box.
  await scenario('typed, store text identical', { typed: true, sendText: 'helllo??', storeText: 'helllo??' });
  // Voice/phone: no local echo, the start frame paints it.
  await scenario('no local echo (voice/other device)', { typed: false, sendText: 'helllo??', storeText: 'helllo??' });
  // STT re-punctuates on the way to the store.
  await scenario('store re-punctuated', { typed: true, sendText: 'do it', storeText: 'Do it.' });
  // Attachment prefix present only in the stored copy.
  await scenario('store carries attachment prefix', { typed: true, sendText: 'look at this',
                                                      storeText: '[Attached file: /tmp/x.png] look at this' });
})();
