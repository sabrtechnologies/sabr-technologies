import socket
import threading
import time


def _server(ready, port_holder, stop):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    port_holder.append(srv.getsockname()[1])
    srv.listen(1)
    ready.set()
    conn, _ = srv.accept()
    conn.setblocking(True)
    while not stop.is_set():
        try:
            conn.recv(4096)
        except Exception:
            break


def _heartbeat(sock, stop):
    """Independent of whatever's stuck below -- fires regardless."""
    while not stop.is_set():
        try:
            sock.send(b"hb")  # 2 bytes, a plausible keepalive/heartbeat size
        except Exception:
            break
        time.sleep(5)


def main():
    ready = threading.Event()
    port_holder = []
    stop = threading.Event()
    t = threading.Thread(target=_server, args=(ready, port_holder, stop), daemon=True)
    t.start()
    ready.wait()
    port = port_holder[0]

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(("127.0.0.1", port))

    hb = threading.Thread(target=_heartbeat, args=(client, stop), daemon=True)
    hb.start()

    # Genuine deadlock: acquire a plain (non-reentrant) Lock, then try to
    # acquire it again on the SAME thread. Real self-contention, not a sleep
    # standing in for one -- the thread is provably, permanently blocked.
    lock = threading.Lock()
    lock.acquire()
    lock.acquire()  # never returns


if __name__ == "__main__":
    main()
