#!/usr/bin/env python3
"""Leon's auto-captioner: raw clip -> word-by-word viral captions burned in."""
import sys, os, json, subprocess, tempfile

inp = sys.argv[1]; out = sys.argv[2]
model_name = sys.argv[3] if len(sys.argv) > 3 else "base"
prog_path = sys.argv[4] if len(sys.argv) > 4 else None

def report(pct, phase):
    if not prog_path:
        return
    try:
        tmp = prog_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"pct": max(0, min(100, int(pct))), "phase": phase}, f)
        os.replace(tmp, prog_path)
    except Exception:
        pass

report(2, "reading clip")

def probe(path):
    r = subprocess.run(["ffprobe","-v","error","-select_streams","v:0",
        "-show_entries","stream=width,height","-of","json",path],
        capture_output=True, text=True)
    s = json.loads(r.stdout)["streams"][0]
    return int(s["width"]), int(s["height"])

W, H = probe(inp)
print(f"[captioner] {W}x{H} | model={model_name}")
report(6, "extracting audio")
wav = tempfile.mktemp(suffix=".wav")
subprocess.run(["ffmpeg","-y","-i",inp,"-vn","-ac","1","-ar","16000",wav], check=True, capture_output=True)

report(12, "loading model")
from faster_whisper import WhisperModel
m = WhisperModel(model_name, device="cpu", compute_type="int8")
report(16, "transcribing")
segments, info = m.transcribe(wav, word_timestamps=True, vad_filter=True)
dur = float(getattr(info, "duration", 0) or 0)
words = []
for seg in segments:
    for w in (seg.words or []):
        t = w.word.strip()
        if t: words.append((w.start, w.end, t.upper()))
    if dur > 0:
        report(16 + 49 * (seg.end / dur), "transcribing")  # 16 -> 65%
print(f"[captioner] {len(words)} words, lang={info.language}")
report(66, "writing captions")

chunks, cur = [], []
for s, e, t in words:
    cur.append((s, e, t))
    if len(cur) >= 4 or t[-1:] in ".!?":
        chunks.append(cur); cur = []
if cur: chunks.append(cur)

def ts(sec):
    h=int(sec//3600); mi=int((sec%3600)//60); s=sec%60
    return f"{h:d}:{mi:02d}:{s:05.2f}"

fs = max(28, int(H*0.064))
mv = int(H*0.30)
posx, posy = W//2, int(H*0.66)
WHITE = r"{\c&HFFFFFF&}"; HI = r"{\c&H00FFFF&}"
head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Pop,Liberation Sans,{fs},&H00FFFFFF,&H00000000,&H00000000,-1,4,1,2,46,46,{mv},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
lines = []
for ch in chunks:
    cend = ch[-1][1]
    for i,(s,e,t) in enumerate(ch):
        seg_end = ch[i+1][0] if i+1 < len(ch) else cend
        parts = []
        for j,(_,_,wt) in enumerate(ch):
            if j == i:
                parts.append(HI + r"{\fscx112\fscy112}" + wt + r"{\fscx100\fscy100}" + WHITE)
            else:
                parts.append(WHITE + wt)
        text = " ".join(parts)
        lines.append(f"Dialogue: 0,{ts(s)},{ts(seg_end)},Pop,,0,0,0,,{text}")

ass = tempfile.mktemp(suffix=".ass")
open(ass,"w").write(head + "\n".join(lines) + "\n")
os.makedirs(os.path.dirname(out), exist_ok=True)
report(70, "rendering video")
proc = subprocess.Popen(["ffmpeg","-y","-i",inp,"-vf",f"ass={ass}",
    "-c:v","libx264","-crf","20","-preset","veryfast","-pix_fmt","yuv420p",
    "-c:a","aac","-b:a","160k","-progress","pipe:1","-nostats",out],
    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
for ln in (proc.stdout or []):
    ln = ln.strip()
    if ln.startswith("out_time_ms=") and dur > 0:
        try:
            done = int(ln.split("=",1)[1]) / 1_000_000.0
            report(70 + 28 * min(1.0, done / dur), "rendering video")  # 70 -> 98%
        except Exception:
            pass
proc.wait()
if proc.returncode != 0:
    raise SystemExit("ffmpeg burn-in failed")
os.remove(wav); os.remove(ass)
report(100, "done")
print(f"[captioner] DONE -> {out}")
