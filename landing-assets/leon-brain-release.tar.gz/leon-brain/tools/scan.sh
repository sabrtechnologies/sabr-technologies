#!/usr/bin/env bash
# Static analysis sweep. Run this before any release.
#
# Until 2026-08-10 this codebase had ZERO static analysis wired in — no linter,
# no security scanner, no shell checker, nothing. Every bug was found by a human
# (or a model) reading code, which is why they kept turning up one at a time.
# The very first run found a guaranteed UnboundLocalError in the outreach email
# path — the one that sends client outreach — that nobody had hit only because
# the SMTP guard returns early on an unconfigured box.
#
#   tools/scan.sh          full report, never fails the build
#   tools/scan.sh --gate   ONLY the crash classes; exit 1 if any are found
#
# The gate is deliberately narrow. A linter that fails on 465 unused imports
# gets switched off in a week; one that only fires on "this WILL raise at
# runtime" gets trusted and kept.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 1

EXCLUDE="workspaces,venv,.venv,node_modules,quarantine,_shadow_quarantine_2026_06_08,backups,checkout-service,brain_state-backups,brain_state-snapshots,code_backups"
GATE=""
[ "${1:-}" = "--gate" ] && GATE="1"

# ── crash classes: code that raises the moment it runs ──
#   F821 undefined name        F823 referenced before assignment
#   E9   syntax / IO errors    F811 redefinition that silently drops a symbol
echo "── crash classes ──"
if ! ruff check --select F821,F823,E9,F811 --exclude "$EXCLUDE" \
       --output-format concise . ; then
  CRASH=1
else
  CRASH=0
fi

if [ -n "$GATE" ]; then
  [ "$CRASH" = "0" ] || { echo "GATE FAILED: code above raises at runtime."; exit 1; }
  echo "GATE PASSED"
  exit 0
fi

echo
echo "── likely bugs (review, not gated) ──"
ruff check --select B --exclude "$EXCLUDE" --statistics . 2>/dev/null | head -20

echo
echo "── shell scripts (the installer is bash; a typo here is a broken install) ──"
if command -v shellcheck >/dev/null; then
  shellcheck -S warning landing/bootstrap.sh uninstall.sh install.sh start.sh 2>&1 | head -40
else
  echo "shellcheck not installed: pip install shellcheck-py"
fi

echo
echo "── security ──"
if command -v bandit >/dev/null; then
  bandit -r brain server business install_client.py run.py -ll -q \
         -f custom --msg-template "{severity} {test_id} {relpath}:{line} {msg}" \
         2>/dev/null | sort | uniq -c | sort -rn | head -20
else
  echo "bandit not installed: pip install bandit"
fi

echo
echo "── dependency CVEs ──"
if command -v pip-audit >/dev/null; then
  pip-audit -r requirements.txt --progress-spinner off 2>&1 | tail -20
else
  echo "pip-audit not installed: pip install pip-audit"
fi
