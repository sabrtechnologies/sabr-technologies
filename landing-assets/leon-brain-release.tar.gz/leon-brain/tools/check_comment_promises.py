#!/usr/bin/env python3
"""Catch comments that promise a function nobody wrote.

Born from a real one: write_env() set LEON_LOCAL_LLM_MODE=fallback next to a
comment saying "provision_local_llm arms it during install". That function had
never existed, so every install advertised an offline backup brain it did not
have, and the only symptom was one log line the owner never reads.

Linters cannot catch this. F821 finds an undefined name in CODE; a promise
made only in a COMMENT is invisible to it. So: collect every `def` in the
tree, then flag any comment that names `something()` which is not defined
anywhere and is not a known library call.

Exit 1 if a new unbacked promise appears. Deliberately conservative — the
point is a signal worth reading, not a wall of false positives.
"""
from __future__ import annotations

import os
import re
import sys

SKIP_DIRS = {
    "workspaces", "installer-recovered", ".git", "node_modules", ".venv",
    "venv", "__pycache__", "brain_state", "brain_state-snapshots", "secure",
    "rust-core", "build", "dist", ".ruff_cache", ".mypy_cache",
    "backups", "brain_state-backups",  # frozen copies; not code we ship
}

# Names that legitimately appear in comments but live in the stdlib or a
# third-party package, not in this tree.
KNOWN_EXTERNAL = {
    "gettempdir", "monotonic", "readline", "weekday", "model_dump",
    "removeprefix", "removesuffix", "get_counts", "eliminate_zeros",
    "write_text", "read_text", "signature", "replace", "isoformat",
    "getdefaultencoding", "startswith", "endswith", "splitlines",
    "asdict", "rename", "unlink", "unlink_", "fdatasync", "flush",
    "mj_step", "mj_forward",  # MuJoCo C API

}

# Comments that explicitly record a REMOVAL are the opposite of the bug —
# they exist so nobody goes looking for the thing again.
# A comment that says the thing is gone, or that explicitly corrects an older
# lie, is the CURE for this bug class — not an instance of it. Don't flag the
# fix. (Missing "used to live here" is what made the first run noisy.)
TOMBSTONE = re.compile(
    r"\b(DELETED|REMOVED|DROPPED|GONE|no longer exists?|used to (be|live|claim|say|exist)"
    r"|does not exist|doesn't exist|never existed|old code|formerly|NOT\b)", re.I)

CALL_IN_COMMENT = re.compile(r"\b([a-z_][a-z0-9_]{5,})\(\)")

# The bug that motivated this file was written WITHOUT parentheses:
#   "Inert until ollama is present; provision_local_llm arms it during install"
# The first version of this scanner required `name()` and therefore sailed
# straight past the one case it existed to catch. So also look for bare
# snake_case identifiers used in a comment as the SUBJECT of a verb of action
# — "X arms/handles/writes/does" — which is how a promise actually gets
# phrased in prose.
PROMISE_VERBS = (
    # "runs" is deliberately absent: "during region_lesion runs" is a NOUN
    # phrase, and it produced most of the first pass's false positives.
    r"arms|handles|writes|reads|does|sets|clears|starts|stops|fetches|"
    r"provisions|installs|registers|ensures|guarantees|takes care of|covers"
)
BARE_PROMISE = re.compile(
    r"\b([a-z][a-z0-9]*(?:_[a-z0-9]+){1,})\s+(?:" + PROMISE_VERBS + r")\b")
DEF_RX = re.compile(r"^\s*(?:async\s+)?def\s+(\w+)", re.M)


def collect(root: str):
    defs: set[str] = set()
    files: list[str] = []
    for cur, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for n in names:
            if not n.endswith(".py"):
                continue
            p = os.path.join(cur, n)
            files.append(p)
            try:
                src = open(p, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            defs.update(DEF_RX.findall(src))
    return defs, files


def main() -> int:
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    defs, files = collect(root)
    hits: list[tuple[str, int, str, str]] = []
    for p in files:
        try:
            src = open(p, encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        # Scan comment BLOCKS, not lines. The original bug wrapped across two
        # lines — "…; provision_local_llm" / "arms it during install." — so a
        # line-at-a-time scan saw a bare name on one line and a bare verb on
        # the next and matched neither. That is the second time this scanner
        # fooled me into thinking it worked; joining the block is the fix.
        blocks: list[tuple[int, str]] = []
        start = None
        buf: list[str] = []
        for i, line in enumerate(src.splitlines(), 1):
            s = line.strip()
            if s.startswith("#"):
                if start is None:
                    start = i
                buf.append(s.lstrip("#").strip())
            else:
                if start is not None:
                    blocks.append((start, " ".join(buf)))
                start, buf = None, []
        if start is not None:
            blocks.append((start, " ".join(buf)))

        for lineno, text in blocks:
            if TOMBSTONE.search(text):
                continue
            found = set(CALL_IN_COMMENT.findall(text)) | set(BARE_PROMISE.findall(text))
            for name in sorted(found):
                if name in defs or name in KNOWN_EXTERNAL:
                    continue
                hits.append((p, lineno, name, text[:110]))

    if not hits:
        print("No unbacked promises in comments.")
        return 0
    print("Comments naming a function that does not exist anywhere:\n")
    for p, i, name, s in hits:
        print(f"  {p}:{i}")
        print(f"    promises {name}()  ->  {s}")
    print(f"\n{len(hits)} unbacked promise(s). Either write the function or "
          f"fix the comment — a comment that lies costs more than no comment.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
