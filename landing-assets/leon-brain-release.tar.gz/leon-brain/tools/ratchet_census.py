#!/usr/bin/env python3
"""Census of inter-region weight matrices — the measurement that makes the
unconditional-ratchet removal falsifiable.

Why this exists: on 2026-08-18 Leon and Makima agreed to remove the
`* 1.001` unconditional strengthen from _prune_weak_synapses. Removing a
mechanism is only an experiment if you wrote down what the brain looked like
before. This writes that down.

Per matrix we record the quantities the failure actually shows up in:
  at_own_max      exact ties to the matrix maximum (a weld, once it's > 1)
  near_max_pct    within 0.1% of own max (the approach; Makima's sawtooth)
  band_frac       fraction inside the old strengthen band (> 0.7 * own max)
  distinct_ratio  distinct values / n  (1.0 = full variance, low = degenerate)
Run before removal and again after N days; diff the JSON.
"""
import glob, json, os, sys, time
# Run-from-anywhere: the census imports the live topology for n_expected, so it
# must find the package whether invoked as tools/ratchet_census.py or by path.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import scipy.sparse as sp

SYN = sys.argv[1] if len(sys.argv) > 1 else "/opt/leon-brain/brain_state/synapses"
out = {"ts": time.time(), "iso": time.strftime("%Y-%m-%dT%H:%M:%S"),
       "source": SYN, "matrices": {}}

tot_n = tot_atmax = tot_band = 0
empty = []
_files = sorted(glob.glob(os.path.join(SYN, "*.npz")))
# Makima, round 14: an empty result set and a real zero are indistinguishable
# in every aggregate we use. Her retroactive sawtooth pass matched a rotated-away
# backup dir, looped zero times, and reported min=0 as a measurement. Refuse to
# proceed rather than emit a legal-looking zero.
if not _files:
    sys.exit(f"REFUSING: no .npz matrices under {SYN!r} — "
             f"an empty glob is not a measurement of zero.")
for f in _files:
    name = os.path.basename(f)[:-4]
    # skip traces AND orphaned .tmp.npz — a tool that dies on litter
    # is a tool nobody runs twice.
    if name.endswith("_traces") or name.endswith(".tmp"):
        continue
    try:
        m = sp.load_npz(f)
        d = np.asarray(m.data, dtype=np.float64)
    except Exception as e:
        out["matrices"][name] = {"error": str(e)}
        continue
    if d.size == 0:
        # Makima's guard refuses an EMPTY GLOB. It cannot see this: a
        # well-formed .npz with the correct shape and zero stored values.
        # Found in my own 2026-08-17 backup -- 37 of 48 matrices like this,
        # and the census printed a clean totals block over the surviving 11
        # with no complaint. A partial result set is worse than an empty one,
        # because it looks plausible. Count them and say so out loud.
        empty.append(name)
        continue
    a = np.abs(d)
    mx = float(a.max())
    if mx <= 0:
        continue
    at_max = int(np.sum(a == mx))
    near = int(np.sum(a >= mx * 0.999))
    band = int(np.sum(a > 0.7 * mx))
    distinct = int(np.unique(d).size)
    out["matrices"][name] = {
        "n": int(d.size), "max": mx, "mean": float(d.mean()),
        "at_own_max": at_max,
        "near_max_pct": round(100.0 * near / d.size, 6),
        "band_frac_pct": round(100.0 * band / d.size, 6),
        "distinct_ratio": round(distinct / d.size, 6),
    }
    tot_n += d.size; tot_atmax += at_max; tot_band += band

# ── n_expected: REFUSE, don't warn (owed to Makima since round 15) ─────
# Her argument, round 16, and I'm taking it whole: a banner above a number is
# still a number, and the letter is where these end up. My old code printed a
# "!!" line under a totals block that any reader could quote in isolation.
# So the totals do not get printed at all unless the census is complete.
#
# n_expected is read through BrainConfig.CONNECTIVITY — the SAME authority the
# brain wires itself from — not a hardcoded 48. A literal would agree with a
# stale tree and disagree with the running mind. If the topology can't be
# imported we refuse too: an unknown expectation is not a satisfied one.
try:
    from brain.config import BrainConfig                      # noqa: E402
except Exception:
    try:
        from brain.brain import BrainConfig                   # type: ignore # noqa: E402
    except Exception as _e:
        sys.exit(f"REFUSING: cannot import the connection topology ({_e}) — "
                 f"without n_expected this is an unbounded census.")
_expected = {f"{s_}__{d_}" for (s_, d_) in BrainConfig.CONNECTIVITY.keys()}
_n_expected = len(_expected)
_measured = set(out["matrices"]) - {k for k, v in out["matrices"].items() if "error" in v}
_missing = sorted(_expected - _measured - set(empty))
_unexpected = sorted(_measured - _expected)
out["census_scope"] = {"n_expected": _n_expected, "n_measured": len(_measured),
                       "n_empty": len(empty), "missing": _missing,
                       "unexpected": _unexpected}
if empty or _missing or _unexpected:
    sys.exit(
        "REFUSING to report a partial census.\n"
        f"  n_expected = {_n_expected}   (from BrainConfig.CONNECTIVITY)\n"
        f"  n_measured = {len(_measured)}\n"
        f"  empty      = {len(empty)}: {', '.join(sorted(empty)[:8])}\n"
        f"  missing    = {len(_missing)}: {', '.join(_missing[:8])}\n"
        f"  unexpected = {len(_unexpected)}: {', '.join(_unexpected[:8])}\n"
        "No totals are printed. A partial census is plausible, and plausible is\n"
        "worse than empty — there is no number here safe to quote.")

if tot_n == 0:
    sys.exit(f"REFUSING: {len(_files)} files matched but zero usable synapses — "
             f"this is a load failure, not a brain with no weights.")

out["empty_matrices"] = empty
out["totals"] = {
    "matrices": len(out["matrices"]), "matrices_empty": len(empty),
    "synapses": tot_n,
    "at_own_max": tot_atmax,
    "at_own_max_pct": round(100.0 * tot_atmax / tot_n, 6) if tot_n else 0,
    "in_strengthen_band": tot_band,
    "in_strengthen_band_pct": round(100.0 * tot_band / tot_n, 6) if tot_n else 0,
}
print(json.dumps(out["totals"], indent=2))
# (the old "!!" warn-print lived here; unreachable now that empty REFUSES —
#  removed rather than left in, so nobody later reads it as the live policy.)
worst = sorted(((v.get("band_frac_pct", 0), k) for k, v in out["matrices"].items()), reverse=True)[:8]
print("\ntop band occupancy:")
for pct, k in worst:
    print(f"  {k:45s} {pct:7.2f}%  distinct_ratio={out['matrices'][k]['distinct_ratio']}")
dest = sys.argv[2] if len(sys.argv) > 2 else None
if dest:
    with open(dest, "w") as fh:
        json.dump(out, fh, indent=1)
    print(f"\nwrote {dest}")
