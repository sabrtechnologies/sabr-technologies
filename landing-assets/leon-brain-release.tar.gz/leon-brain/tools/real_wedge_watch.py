#!/usr/bin/env python3
"""Standing watch for a REAL wedge specimen, per DJ-001's own finding that
none has ever been caught on this box. Does not synthesize anything --
only captures state if a real pane's content genuinely stops changing for
>5s while the pane is not simply idle-and-finished (turn_owed still true).

On trigger: snapshots ps + timestamp + pane capture to
brain_state/real_wedge_captures/<window>-<ts>.json for later analysis.
Read-only. Never sends anything into a pane.
"""
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, "/opt/leon-brain")
from brain.mission import send_ledger  # noqa: E402

SESSION = os.environ.get("LEON_AGENT_TMUX_SESSION", "agents")
OUT_DIR = "/opt/leon-brain/brain_state/real_wedge_captures"
POLL_S = 2.0
# DJ-013: "any turn_owed threshold under ~20 minutes false-positives on
# measured behaviour." 5.0 (the original value here) fired on every normal
# human-response gap -- see DJ-045. 1200s is DJ-013's conservative floor,
# not a corpus-derived number (DJ-016's real p99 still needs its corpus).
STALL_S = 1200.0
os.makedirs(OUT_DIR, exist_ok=True)


def list_windows():
    out = subprocess.run(["tmux", "list-windows", "-t", SESSION, "-F", "#{window_name}"],
                          capture_output=True, text=True).stdout
    return [w.strip() for w in out.splitlines() if w.strip()]


def capture(window):
    return subprocess.run(["tmux", "capture-pane", "-p", "-t", f"{SESSION}:{window}", "-S", "-30"],
                           capture_output=True, text=True).stdout


def resolve_leader_pid(pane_pid):
    """pane_pid is already claude on most panes; 'home' wraps it in bash."""
    if not pane_pid:
        return None
    try:
        comm = open(f"/proc/{pane_pid}/comm").read().strip()
    except Exception:
        return None
    if comm == "claude":
        return pane_pid
    child = subprocess.run(["pgrep", "-P", pane_pid, "-x", "claude"],
                            capture_output=True, text=True).stdout.strip()
    return child.splitlines()[0] if child else None


def sample_voluntary_ctxt(pid, seconds=15.0):
    def read(p):
        try:
            for line in open(f"/proc/{p}/status"):
                if line.startswith("voluntary_ctxt_switches:"):
                    return int(line.split()[1])
        except Exception:
            return None
        return None
    v0 = read(pid)
    if v0 is None:
        return None
    time.sleep(seconds)
    v1 = read(pid)
    return (v1 - v0) if v1 is not None else None


def pane_meta(window):
    out = subprocess.run(["tmux", "display-message", "-p", "-t", f"{SESSION}:{window}",
                          "#{pane_pid}\t#{pane_current_command}"],
                         capture_output=True, text=True).stdout.strip()
    parts = out.split("\t")
    return {"pid": parts[0] if parts else None, "cmd": parts[1] if len(parts) > 1 else None}


def main():
    last_content = {}
    last_change_at = {}
    already_captured = set()

    while True:
        now = time.time()
        for w in list_windows():
            raw = capture(w)
            if w not in last_content:
                last_content[w] = raw
                last_change_at[w] = now
                continue
            if raw != last_content[w]:
                last_content[w] = raw
                last_change_at[w] = now
                already_captured.discard(w)
                continue

            stall = now - last_change_at[w]
            if stall < STALL_S or w in already_captured:
                continue

            status, entry = send_ledger.debt_status(w, None)
            if status != send_ledger.OWED:
                continue  # idle-and-finished, not a wedge candidate -- DJ-001's own rule

            meta = pane_meta(w)
            # DJ-043/044's threshold needs the thread-GROUP-LEADER's own PID,
            # which is not always pane_pid -- 'home' wraps claude in bash,
            # other panes run claude directly as pane_pid. Resolve robustly.
            leader_pid = resolve_leader_pid(meta.get("pid"))

            # n=1 deciding the only real specimen this box may ever produce
            # is the DJ-036/043/044/046 lesson applied to itself. Three
            # consecutive 15s windows, all three logged raw -- not just the
            # verdict -- so a future review can see the spread.
            raw_samples = []
            if leader_pid:
                for _ in range(3):
                    raw_samples.append(sample_voluntary_ctxt(leader_pid, seconds=15.0))
            samples_valid = [s for s in raw_samples if s is not None]
            all_agree_hung = (len(samples_valid) == 3 and all(s <= 5 for s in samples_valid))
            all_agree_healthy_range = (len(samples_valid) == 3 and all(s >= 100 for s in samples_valid))
            finalized = "hung_confirmed" if all_agree_hung else (
                "UNEXPECTED_healthy_range" if all_agree_healthy_range else
                "inconclusive_disagreement")

            ps_out = subprocess.run(["ps", "-ejH"], capture_output=True, text=True).stdout
            capture_path = os.path.join(OUT_DIR, f"{w}-{int(now)}.json")
            with open(capture_path, "w") as fh:
                json.dump({"window": w, "ts": now, "stall_s": round(stall, 1),
                           "pane_meta": meta, "debt_status": status,
                           "leader_pid": leader_pid,
                           "voluntary_ctxt_switches_raw_samples_15s_each": raw_samples,
                           "finalized_verdict": finalized,
                           "pane_content": raw, "ps_ejH": ps_out}, fh, indent=2)
            already_captured.add(w)
            print(f"CAPTURED real wedge candidate: {w} stalled {stall:.0f}s "
                  f"ctxt_samples={raw_samples} verdict={finalized} -> {capture_path}",
                  flush=True)

        time.sleep(POLL_S)


if __name__ == "__main__":
    main()
