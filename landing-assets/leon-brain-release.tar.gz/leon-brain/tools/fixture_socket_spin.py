import socket
import threading


def _server(ready, port_holder):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    port_holder.append(srv.getsockname()[1])
    srv.listen(1)
    ready.set()
    conn, _ = srv.accept()
    # Server side just holds the connection open, never sends/receives either.
    while True:
        pass


def main():
    ready = threading.Event()
    port_holder = []
    t = threading.Thread(target=_server, args=(ready, port_holder), daemon=True)
    t.start()
    ready.wait()
    port = port_holder[0]

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(("127.0.0.1", port))
    # ESTABLISHED now. Spin forever, never touch the socket.
    while True:
        pass


if __name__ == "__main__":
    main()
