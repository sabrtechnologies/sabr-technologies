#!/usr/bin/env python3
"""Token ledger — ingests Claude CLI session logs into a queryable SQLite DB.

Usage:
    python3 -m tools.token_ledger ingest        # scan all session jsonl, upsert new rows
    python3 -m tools.token_ledger report        # last 24h + 7d summary
    python3 -m tools.token_ledger report --days 2
    python3 -m tools.token_ledger daily         # per-day breakdown
    python3 -m tools.token_ledger models        # per-model breakdown
"""
import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

PROJECTS = Path(os.environ.get("CLAUDE_PROJECTS_DIR", Path.home() / ".claude" / "projects"))
DB_PATH = Path(os.environ.get("LEON_TOKEN_DB", "/opt/leon-brain/brain_state/tokens.db"))

# USD per million tokens: (input, output, cache_write_5m, cache_read)
PRICING = {
    "opus":   (15.0, 75.0, 18.75, 1.50),
    "sonnet": (3.0,  15.0,  3.75, 0.30),
    "haiku":  (0.80,  4.0,  1.00, 0.08),
    "fable":  (5.0,  25.0,  6.25, 0.50),
}


def family(model: str) -> str:
    m = (model or "").lower()
    for k in PRICING:
        if k in m:
            return k
    return "unknown"


def cost_usd(model, inp, out, cw, cr):
    rates = PRICING.get(family(model))
    if not rates:
        return None
    i, o, w, r = rates
    return (inp * i + out * o + cw * w + cr * r) / 1_000_000


SCHEMA = """
CREATE TABLE IF NOT EXISTS usage (
    msg_id        TEXT PRIMARY KEY,
    ts            TEXT NOT NULL,
    session_id    TEXT,
    project       TEXT,
    model         TEXT,
    family        TEXT,
    input_tokens  INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    cache_write   INTEGER DEFAULT 0,
    cache_read    INTEGER DEFAULT 0,
    web_searches  INTEGER DEFAULT 0,
    cost_usd      REAL
);
CREATE INDEX IF NOT EXISTS idx_usage_ts ON usage(ts);
CREATE INDEX IF NOT EXISTS idx_usage_project ON usage(project);
CREATE INDEX IF NOT EXISTS idx_usage_family ON usage(family);
CREATE TABLE IF NOT EXISTS ingest_state (
    path      TEXT PRIMARY KEY,
    size      INTEGER,
    mtime     REAL,
    rows_seen INTEGER
);
"""


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.executescript(SCHEMA)
    return con


def ingest(verbose=True):
    con = connect()
    cur = con.cursor()
    state = {r[0]: (r[1], r[2]) for r in cur.execute("SELECT path, size, mtime FROM ingest_state")}
    files = sorted(PROJECTS.rglob("*.jsonl"))
    new_rows = 0
    scanned = 0
    for f in files:
        try:
            st = f.stat()
        except OSError:
            continue
        prev = state.get(str(f))
        if prev and prev[0] == st.st_size and abs(prev[1] - st.st_mtime) < 1e-6:
            continue  # unchanged
        scanned += 1
        project = f.parent.name
        rows = []
        try:
            with f.open(errors="replace") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                    except Exception:
                        continue
                    msg = d.get("message") or {}
                    u = msg.get("usage")
                    if not isinstance(u, dict):
                        continue
                    mid = msg.get("id") or d.get("uuid")
                    if not mid:
                        continue
                    model = msg.get("model") or ""
                    inp = int(u.get("input_tokens") or 0)
                    out = int(u.get("output_tokens") or 0)
                    cw = int(u.get("cache_creation_input_tokens") or 0)
                    cr = int(u.get("cache_read_input_tokens") or 0)
                    stu = u.get("server_tool_use") or {}
                    ws = int(stu.get("web_search_requests") or 0)
                    rows.append((
                        mid, d.get("timestamp") or "", d.get("sessionId"), project,
                        model, family(model), inp, out, cw, cr, ws,
                        cost_usd(model, inp, out, cw, cr),
                    ))
        except OSError:
            continue
        if rows:
            before = cur.execute("SELECT COUNT(*) FROM usage").fetchone()[0]
            cur.executemany(
                "INSERT OR REPLACE INTO usage (msg_id, ts, session_id, project, model, family,"
                " input_tokens, output_tokens, cache_write, cache_read, web_searches, cost_usd)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            after = cur.execute("SELECT COUNT(*) FROM usage").fetchone()[0]
            new_rows += after - before
        cur.execute("INSERT OR REPLACE INTO ingest_state (path,size,mtime,rows_seen) VALUES (?,?,?,?)",
                    (str(f), st.st_size, st.st_mtime, len(rows)))
        con.commit()
    con.commit()
    total = cur.execute("SELECT COUNT(*) FROM usage").fetchone()[0]
    if verbose:
        print(f"ingest: {scanned} file(s) changed, {new_rows} new message(s), {total} total in ledger")
    con.close()
    return new_rows


def _fmt(n):
    return f"{n:,}"


def _window(con, since_iso, label):
    row = con.execute(
        "SELECT COUNT(*), COALESCE(SUM(input_tokens),0), COALESCE(SUM(output_tokens),0),"
        " COALESCE(SUM(cache_write),0), COALESCE(SUM(cache_read),0), COALESCE(SUM(cost_usd),0)"
        " FROM usage WHERE ts >= ?", (since_iso,)).fetchone()
    n, inp, out, cw, cr, cost = row
    billed = inp + out + cw + cr
    print(f"\n{label}")
    print(f"  messages       {_fmt(n)}")
    print(f"  input          {_fmt(inp)}")
    print(f"  output         {_fmt(out)}")
    print(f"  cache write    {_fmt(cw)}")
    print(f"  cache read     {_fmt(cr)}")
    print(f"  TOTAL billed   {_fmt(billed)}")
    print(f"  est. cost      ${cost:,.2f}")
    per = con.execute(
        "SELECT family, SUM(input_tokens+output_tokens+cache_write+cache_read) t,"
        " COALESCE(SUM(cost_usd),0) c FROM usage WHERE ts >= ?"
        " GROUP BY family ORDER BY t DESC", (since_iso,)).fetchall()
    for fam, t, c in per:
        print(f"    {fam:<8} {_fmt(t):>14}  ${c:,.2f}")


def report(days):
    con = connect()
    now = datetime.now(timezone.utc)
    _window(con, (now - timedelta(days=days)).isoformat().replace("+00:00", "Z"),
            f"LAST {days} DAY(S)")
    if days != 7:
        _window(con, (now - timedelta(days=7)).isoformat().replace("+00:00", "Z"), "LAST 7 DAYS")
    con.close()


def daily(days=14):
    con = connect()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat().replace("+00:00", "Z")
    print(f"{'day':<12}{'msgs':>7}{'billed tokens':>16}{'cost':>10}")
    for d, n, t, c in con.execute(
            "SELECT substr(ts,1,10) d, COUNT(*), SUM(input_tokens+output_tokens+cache_write+cache_read),"
            " COALESCE(SUM(cost_usd),0) FROM usage WHERE ts >= ? GROUP BY d ORDER BY d", (since,)):
        print(f"{d:<12}{n:>7}{_fmt(t or 0):>16}{'$%.2f' % c:>10}")
    con.close()


def models(days=7):
    con = connect()
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat().replace("+00:00", "Z")
    print(f"{'model':<28}{'msgs':>7}{'billed tokens':>16}{'cost':>10}")
    for m, n, t, c in con.execute(
            "SELECT model, COUNT(*), SUM(input_tokens+output_tokens+cache_write+cache_read),"
            " COALESCE(SUM(cost_usd),0) FROM usage WHERE ts >= ? GROUP BY model"
            " ORDER BY 3 DESC", (since,)):
        print(f"{(m or '?'):<28}{n:>7}{_fmt(t or 0):>16}{'$%.2f' % c:>10}")
    con.close()


def main():
    ap = argparse.ArgumentParser(description="Leon token ledger")
    ap.add_argument("cmd", nargs="?", default="report",
                    choices=["ingest", "report", "daily", "models"])
    ap.add_argument("--days", type=int, default=1)
    a = ap.parse_args()
    if a.cmd == "ingest":
        ingest()
        return
    ingest(verbose=False)  # always fresh before reporting
    if a.cmd == "report":
        report(a.days)
    elif a.cmd == "daily":
        daily(max(a.days, 14))
    elif a.cmd == "models":
        models(max(a.days, 7))


if __name__ == "__main__":
    main()
