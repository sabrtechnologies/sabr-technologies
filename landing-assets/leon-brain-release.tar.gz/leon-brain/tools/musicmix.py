#!/usr/bin/env python3
"""Leon's music-mixer: lay a sound bed UNDER a captioned clip.

If the clip has speech, the music ducks automatically (sidechain compression)
so the talking always cuts through. If the clip has no/quiet audio, the bed
plays fuller. Writes a progress sidecar like the captioner.

Usage: musicmix.py <video> <music> <out.mp4> [bed_gain] [progress.json]
  bed_gain: 0.0-1.0 baseline music loudness (default 0.45)
"""
import sys, os, json, subprocess, tempfile

vid = sys.argv[1]; music = sys.argv[2]; out = sys.argv[3]
bed_gain = float(sys.argv[4]) if len(sys.argv) > 4 else 0.45
prog_path = sys.argv[5] if len(sys.argv) > 5 else None


def report(pct, phase):
    if not prog_path:
        return
    try:
        tmp = prog_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"pct": max(0, min(100, int(pct))), "phase": phase}, f)
        os.replace(tmp, prog_path)
    except Exception:
        pass


def has_audio(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a",
        "-show_entries", "stream=index", "-of", "csv=p=0", path],
        capture_output=True, text=True)
    return bool(r.stdout.strip())


def duration(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
        "format=duration", "-of", "csv=p=0", path], capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except Exception:
        return 0.0


report(5, "reading clip")
dur = duration(vid)
speech = has_audio(vid)
os.makedirs(os.path.dirname(out) or ".", exist_ok=True)

if speech:
    # music loops to cover the clip, sits low, then ducks under the voice
    fc = (
        f"[1:a]aloop=loop=-1:size=2147483647,atrim=0:{dur:.3f},asetpts=N/SR/TB,"
        f"volume={bed_gain}[bed];"
        f"[bed][0:a]sidechaincompress=threshold=0.04:ratio=8:attack=12:release=260:makeup=1[duck];"
        f"[0:a][duck]amix=inputs=2:duration=first:dropout_transition=0,"
        f"alimiter=limit=0.95[aout]"
    )
else:
    # no speech — let the music carry it, a touch fuller
    fuller = min(1.0, bed_gain + 0.35)
    fc = (
        f"[1:a]aloop=loop=-1:size=2147483647,atrim=0:{dur:.3f},asetpts=N/SR/TB,"
        f"volume={fuller},alimiter=limit=0.95[aout]"
    )

report(20, "mixing audio")
proc = subprocess.Popen(
    ["ffmpeg", "-y", "-i", vid, "-i", music, "-filter_complex", fc,
     "-map", "0:v", "-map", "[aout]",
     "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest",
     "-progress", "pipe:1", "-nostats", out],
    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
for ln in (proc.stdout or []):
    ln = ln.strip()
    if ln.startswith("out_time_ms=") and dur > 0:
        try:
            done = int(ln.split("=", 1)[1]) / 1_000_000.0
            report(20 + 78 * min(1.0, done / dur), "mixing audio")
        except Exception:
            pass
proc.wait()
if proc.returncode != 0:
    # video "copy" can fail if container mismatch — retry re-encoding video
    proc2 = subprocess.run(
        ["ffmpeg", "-y", "-i", vid, "-i", music, "-filter_complex", fc,
         "-map", "0:v", "-map", "[aout]",
         "-c:v", "libx264", "-crf", "20", "-preset", "veryfast", "-pix_fmt", "yuv420p",
         "-c:a", "aac", "-b:a", "192k", "-shortest", out],
        capture_output=True)
    if proc2.returncode != 0:
        report(100, "error")
        sys.stderr.write(proc2.stderr.decode("utf-8", "ignore")[-800:])
        raise SystemExit("musicmix failed")
report(100, "done")
print(f"[musicmix] DONE -> {out}  (speech={speech}, dur={dur:.1f}s)")
