#!/usr/bin/env python3
"""
Leon's client for the Leon<->Makima terminal relay.

Built against TERMINAL-SPEC-for-Dean.md (relay.py md5
1a1f7b73bc062fd941d201fe35eed087, as of 2026-08-20).

Transport: raw TCP, tailnet-only, NDJSON (one JSON object per '\n'-terminated
line), max frame 65535 bytes of JSON, 30s socket timeout, UTF-8.

Identity: Leon is a PARTICIPANT. Token is "leon". Participants can send
message/attach/halt frames. They can never send consent/revoke -- that's a
GATE token's job (Dean's), and this client refuses to even try.

The one discipline this file exists to enforce, per the spec's own warning:
NEVER assume the next line read off the socket is the ack for the frame you
just sent. A delivery from the peer can interleave. Every inbound line is
dispatched on its "type" field ("ack" or "message"), never on order.
That exact mistake -- assume-next-line-is-my-ack -- permanently desynced the
first client ever written against this protocol and made it answer the wrong
questions for a whole run without ever noticing. Not repeating that here.
"""

import json
import socket
import sys
import threading
import time

HOST = "100.111.160.8"
PORT = 29147
TOKEN = "leon"
MAX_FRAME_BYTES = 65535
SOCK_TIMEOUT = 30


class ProtocolViolation(Exception):
    """Raised when the server sends something outside spec, or we're about
    to send something outside spec. Fail loud, not silently."""


class TerminalClient:
    def __init__(self, host=HOST, port=PORT, token=TOKEN):
        self.host = host
        self.port = port
        self.token = token
        self.sock = None
        self.buf = b""
        self._lock = threading.Lock()
        self._on_message = None  # callback(from-peer message dict)

    # -- connection -----------------------------------------------------

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port), timeout=SOCK_TIMEOUT)
        self.sock.settimeout(SOCK_TIMEOUT)

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            finally:
                self.sock = None

    # -- outbound: exactly two allowed shapes, exact key-set match ------

    def _send_frame(self, obj):
        keys = set(obj)
        if keys not in ({"v", "token", "text"}, {"v", "token", "control"}):
            raise ProtocolViolation(f"refusing to send malformed frame shape: {keys}")
        if obj["v"] != 1:
            raise ProtocolViolation("v must be 1")
        line = json.dumps(obj, separators=(",", ":")) + "\n"
        encoded = line.encode("utf-8")
        if len(encoded) - 1 > MAX_FRAME_BYTES:  # -1 for the newline
            raise ProtocolViolation(f"frame exceeds {MAX_FRAME_BYTES} bytes, refusing to send (never truncate)")
        with self._lock:
            self.sock.sendall(encoded)

    def send_message(self, text):
        self._send_frame({"v": 1, "token": self.token, "text": text})

    def send_control(self, control):
        if control in ("consent", "revoke"):
            raise ProtocolViolation(
                "Leon is a PARTICIPANT token, not a GATE token -- "
                "consent/revoke will be refused by the relay and this "
                "client won't even try. That asymmetry is the point."
            )
        if control not in ("attach", "halt"):
            raise ProtocolViolation(f"unknown control: {control}")
        self._send_frame({"v": 1, "token": self.token, "control": control})

    # -- inbound: dispatch on "type", never on read order ----------------

    def _readline(self):
        """Read one '\n'-terminated line from the socket, buffering partial
        reads. Returns None on clean EOF."""
        while b"\n" not in self.buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                return None
            self.buf += chunk
        line, _, self.buf = self.buf.partition(b"\n")
        return line

    def read_frame(self):
        """Read and parse exactly one inbound frame. Returns the parsed
        dict, or None on EOF. Raises ProtocolViolation on an untagged
        frame -- we refuse to guess at what an untagged line means,
        same discipline Makima's side holds."""
        raw = self._readline()
        if raw is None:
            return None
        obj = json.loads(raw.decode("utf-8"))
        if "type" not in obj:
            raise ProtocolViolation(f"inbound frame missing 'type', refusing to infer: {obj!r}")
        return obj

    def run_dispatch_loop(self, on_ack=None, on_message=None, on_unknown=None):
        """Blocking loop. Dispatches strictly on the 'type' field of each
        inbound frame -- this is the whole point of this file. It does NOT
        assume the first line after a send is that send's ack. If a message
        from the peer arrives before our ack does, this handles it in the
        order it actually arrived, not the order we expected."""
        while True:
            try:
                frame = self.read_frame()
            except ProtocolViolation as e:
                print(f"[protocol violation, not guessing] {e}", file=sys.stderr)
                continue
            if frame is None:
                print("[connection closed by peer]", file=sys.stderr)
                return
            t = frame.get("type")
            if t == "ack":
                if on_ack:
                    on_ack(frame)
            elif t == "message":
                if on_message:
                    on_message(frame)
            else:
                if on_unknown:
                    on_unknown(frame)
                else:
                    print(f"[unrecognized type={t!r}, not acting on it] {frame!r}", file=sys.stderr)


def _selftest_frame_shapes():
    """Deliberately arm the failing branch before trusting the happy path --
    same discipline as the deliberately-broken-build test from round 24.
    A check that has only ever passed against good input is not evidence."""
    c = TerminalClient.__new__(TerminalClient)  # no real socket needed
    c.token = TOKEN
    c._lock = threading.Lock()

    class FakeSock:
        def __init__(self):
            self.sent = []

        def sendall(self, data):
            self.sent.append(data)

    c.sock = FakeSock()

    # 1. valid message frame -> must succeed
    c.send_message("hello")
    assert json.loads(c.sock.sent[-1].decode())["text"] == "hello"

    # 2. valid control frame -> must succeed
    c.send_control("attach")
    assert json.loads(c.sock.sent[-1].decode())["control"] == "attach"

    # 3. consent/revoke from a participant token -> must be refused LOCALLY,
    #    never even reach the wire
    for bad in ("consent", "revoke"):
        try:
            c.send_control(bad)
            raise AssertionError(f"{bad} should have been refused client-side")
        except ProtocolViolation:
            pass

    # 4. hybrid/malformed shape -> must be refused before sendall
    before = len(c.sock.sent)
    try:
        c._send_frame({"v": 1, "token": TOKEN, "text": "x", "control": "attach"})
        raise AssertionError("hybrid frame should have been refused")
    except ProtocolViolation:
        pass
    assert len(c.sock.sent) == before, "malformed frame must never touch the wire"

    # 5. inbound untagged frame -> read_frame must raise, not guess
    c2 = TerminalClient.__new__(TerminalClient)
    c2.buf = b'{"no_type_here": true}\n'

    class FakeRecvSock:
        def recv(self, n):
            return b""

    c2.sock = FakeRecvSock()
    try:
        c2.read_frame()
        raise AssertionError("untagged inbound frame should have raised")
    except ProtocolViolation:
        pass

    # 6. out-of-order delivery: a 'message' arrives before the 'ack' for
    #    something we sent -- dispatch must still route correctly by type,
    #    not by "the next line must be my ack"
    seen = []
    c3 = TerminalClient.__new__(TerminalClient)
    lines = [
        b'{"type":"message","from":"makima","text":"hi"}\n',  # arrives FIRST
        b'{"type":"ack","for":"prior-send"}\n',                # arrives SECOND
        b'',  # EOF
    ]
    it = iter(lines)

    class SeqSock:
        def recv(self, n):
            return next(it)

    c3.sock = SeqSock()
    c3.buf = b""
    c3.run_dispatch_loop(
        on_ack=lambda f: seen.append(("ack", f)),
        on_message=lambda f: seen.append(("message", f)),
    )
    assert seen[0][0] == "message" and seen[1][0] == "ack", (
        "dispatch must follow actual arrival order by type, "
        "not assume ack-comes-first"
    )

    print("all self-tests passed: shape validation, gate/participant "
          "asymmetry, untagged-frame refusal, and out-of-order dispatch "
          "all hold against deliberately broken input.")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--selftest":
        _selftest_frame_shapes()
        sys.exit(0)

    print("Usage: leon_terminal_client.py --selftest")
    print("(Live --connect mode intentionally not wired yet -- no consent")
    print(" session exists on the relay side until the reader surface is")
    print(" built, so there is nothing to attach to yet. Fail closed.)")
