            function _showThinking() {
                if (_thinkingEl || _streamingTurnEl) return;
                const body = document.getElementById('conv-body');
                if (!body) return;
                const div = document.createElement('div');
                div.className = 'conv-turn conv-streaming';
                div.innerHTML = '<div class="conv-thinking"><span class="thinking-dots-inline"><span>.</span><span>.</span><span>.</span></span></div><div class="conv-brain"><span class="conv-name-leon">Leon:</span><span class="conv-brain-text"></span></div>';
                body.appendChild(div);
                _thinkingEl = div;
                body.scrollTop = body.scrollHeight;
            }

            function _removeThinking() {
                if (_thinkingEl) { _thinkingEl.remove(); _thinkingEl = null; }
            }

function H_onResponseStart(userText, responseId, msg) {
                _turnStreaming = true;   // pause the store-poll so the live preview doesn't double up
                dashboard.setProcessing(false);
                _setStopVisible(true);
                _leonAudioMuteUntil = 0;   // new turn — lift any post-Stop audio mute
                _gotElevenAudio = false;   // assume free voice until ElevenLabs audio arrives
                _streamingResponseText = '';
                _streamingResponseId = responseId;
                _leonAudioActiveId = responseId;
                // Do NOT _stopLeonAudio() here — it would clear the queued
                // last-sentence audio of the previous turn before it plays.
                // The response_id filter in playLeonAudio already drops stale
                // routing, so the previous turn's audio drains naturally and
                // the new turn's audio enqueues behind it.
                _streamingUserText = userText;
                setAction('Thinking...', 'la-thinking');

                // Proactive/spontaneous messages are Leon speaking unprompted —
                // don't show a "Dean:" line for those
                const isLeonInitiated = msg && (msg.from_proactive || msg.from_spontaneous || msg.from_wake);
                // Only paint his line if nobody already has (local sends paint
                // it on keypress; the store poll paints phone sends).
                const showUserLine = userText && !isLeonInitiated && !_userLinePainted(userText);

                // DUPLICATE FIX: his line NEVER goes inside the streaming turn.
                // It used to — and that turn carries no echoPending marker, so
                // the store poll couldn't claim it and stacked a second
                // "Dean: <text>" underneath. Worse, when the stored reply landed
                // the preview got removed and took his line with it. Paint it as
                // its own claimable echo bubble instead: one line, one owner.
                if (showUserLine) _paintUserEcho(userText);

                // ── ONE owner for the thinking dots (2026-08-12) ────────────
                // Aiden's install showed THREE stacked "<SI>:" loading bars in
                // one turn. Three independent paths paint a .conv-thinking and
                // none of them cleaned up after the others:
                //
                //   (1) the 1.8s processing poll -> _showThinking()  [line ~2799]
                //   (2) this handler, response_start
                //   (3) this handler AGAIN, when a turn emits a second
                //       response_start (tool continuation / reconnect / retry).
                //
                // (1)+(2): _showThinking() guards on _streamingTurnEl, but the
                // poll fires BEFORE response_start arrives, so the guard is
                // false and the dots land. This handler never removed them.
                // (3) is the ugly one: reassigning _streamingTurnEl orphaned the
                // previous div, and every dot-removal below only ever touches
                // the CURRENT _streamingTurnEl — so the orphan kept spinning
                // forever. Self-healing never kicked in. That's the permanent
                // bar a customer sits and stares at.
                //
                // Now: claim ownership before painting. Kill the poll's dots,
                // and retire any live streaming turn — keep it if it has real
                // text (never eat what the SI actually said), drop it if it's
                // an empty shell, but strip its dots either way.
                _removeThinking();
                if (_streamingTurnEl) {
                    const staleTxt = _streamingBrainEl ? (_streamingBrainEl.textContent || '').trim() : '';
                    const staleDots = _streamingTurnEl.querySelector('.conv-thinking');
                    if (staleDots) staleDots.remove();
                    if (staleTxt) {
                        _streamingTurnEl.classList.remove('conv-streaming');
                    } else {
                        _streamingTurnEl.remove();
                    }
                    _streamingTurnEl = null;
                    _streamingBrainEl = null;
                }

                // Create a new conv-turn in the conversation panel with thinking indicator
                const body = document.getElementById('conv-body');
                if (body) {
                    const div = document.createElement('div');
                    div.className = 'conv-turn conv-streaming';
                    div.dataset.responseId = responseId;
                    div.innerHTML = `
                        <div class="conv-thinking"><span class="thinking-dots-inline"><span>.</span><span>.</span><span>.</span></span></div>
                        <div class="conv-brain"><span class="conv-name-leon">Leon:</span><span class="conv-brain-text"></span></div>
                    `;
                    body.appendChild(div);
                    _streamingTurnEl = div;
                    _streamingBrainEl = div.querySelector('.conv-brain-text');
                    body.scrollTop = body.scrollHeight;
                }
            }

function H_onResponseDelta(responseId, chunk) {
                if (responseId !== _streamingResponseId) return;
                if (window.markLeonAwake) window.markLeonAwake();
                _streamingResponseText += chunk;
                setAction('Speaking...', 'la-active');
                if (_streamingBrainEl) {
                    // Measure stick-to-bottom BEFORE writing the new text.
                    const body = document.getElementById('conv-body');
                    const wasAtBottom = body ? (body.scrollTop + body.clientHeight >= body.scrollHeight - 40) : true;
                    _streamingBrainEl.textContent = speakableJs(_streamingResponseText);
                    if (_streamingTurnEl) {
                        const thinking = _streamingTurnEl.querySelector('.conv-thinking');
                        if (thinking) thinking.remove();
                    }
                    if (body && wasAtBottom) body.scrollTop = body.scrollHeight;
                }
            }

function H_onResponseEnd(responseId, fullText) {
                if (responseId !== _streamingResponseId) return;
                const final = fullText || _streamingResponseText;
                // Free browser voice — only if ElevenLabs didn't speak this turn.
                _maybeBrowserVoice(final);
                const body = document.getElementById('conv-body');
                const wasAtBottom = body ? (body.scrollTop + body.clientHeight >= body.scrollHeight - 40) : true;
                if (_streamingBrainEl) {
                    _streamingBrainEl.innerHTML = renderConvText(final);
                }
                if (_streamingTurnEl) {
                    _streamingTurnEl.classList.remove('conv-streaming');
                    const thinking = _streamingTurnEl.querySelector('.conv-thinking');
                    if (thinking) thinking.remove();
                }
                _turnStreaming = false;   // turn done — store-poll may resume and reconcile
                _pendingPreviewEl = _streamingTurnEl;   // keep visible until the stored copy lands
                _pendingPreviewAt = Date.now();         // for the stale-preview reaper (Defect B)
                _streamingTurnEl = null;
                _streamingBrainEl = null;
                // Single source of truth = the SQLite store. Pull the authoritative
                // turn so THIS desktop and the phone show the exact same transcript.
                setTimeout(pullConvo, 900);
                setTimeout(pullConvo, 2200);
                if (body && wasAtBottom) body.scrollTop = body.scrollHeight;
                setAction('Idle', 'la-idle');
                _setStopVisible(false);
            }
