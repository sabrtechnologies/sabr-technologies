"""Pull the REAL thinking-indicator code out of dashboard/index.html.

Two shapes to grab, both by brace matching so this harness replays SHIPPED code
rather than a paraphrase:

  * named functions   -- _showThinking, _removeThinking
  * arrow handlers    -- ws.onResponseStart / Delta / End, which is where the
                         duplicate loading bars are actually born

The arrow handlers are rewritten to plain `function H_onResponseStart(...)` so
run.js can call them directly without constructing a fake ws object.
"""
import re, sys

SRC = open(sys.argv[1] if len(sys.argv) > 1 else
           '/opt/leon-brain/dashboard/index.html').read()

FUNCS = ["_showThinking", "_removeThinking"]
HANDLERS = ["onResponseStart", "onResponseDelta", "onResponseEnd"]


def _match_braces(src, i):
    depth, j = 0, i
    while j < len(src):
        if src[j] == '{':
            depth += 1
        elif src[j] == '}':
            depth -= 1
            if depth == 0:
                return j
        j += 1
    raise SystemExit("unbalanced braces")


out = []

for name in FUNCS:
    m = re.search(r'^[ \t]*function\s+' + re.escape(name) + r'\s*\(', SRC, re.M)
    if not m:
        print(f"// MISSING fn {name}", file=sys.stderr)
        continue
    i = SRC.index('{', m.end() - 1)
    out.append(SRC[m.start():_match_braces(SRC, i) + 1])

for h in HANDLERS:
    m = re.search(r'^[ \t]*ws\.' + re.escape(h) + r'\s*=\s*\(([^)]*)\)\s*=>\s*\{',
                  SRC, re.M)
    if not m:
        print(f"// MISSING handler {h}", file=sys.stderr)
        continue
    i = SRC.index('{', m.end() - 1)
    body = SRC[i:_match_braces(SRC, i) + 1]
    out.append(f"function H_{h}({m.group(1)}) {body}")

print("\n\n".join(out))
