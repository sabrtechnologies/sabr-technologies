// thinking_replay — how many loading bars does one turn paint?
//
// Aiden (real customer, Windows, SI named "Iris") saw THREE stacked blue
// "Iris:" loading bars in a single turn and had no idea what was happening.
// This replays the SHIPPED handlers out of dashboard/index.html under jsdom
// and counts .conv-thinking nodes in the conversation body.
//
//   python3 extract.py [path/to/index.html] > funcs.js && node run.js
//
// Every scenario must end with AT MOST ONE loading bar, and a completed turn
// must end with zero. Text the SI already streamed must never be discarded.

const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');

const dom = new JSDOM('<!doctype html><html><body><div id="conv-body"></div></body></html>');
global.window = dom.window;
global.document = dom.window.document;

// ── shims for everything the handlers touch that isn't the DOM ──────────────
let _streamingTurnEl = null, _streamingBrainEl = null, _thinkingEl = null;
let _turnStreaming = false, _streamingResponseText = '', _streamingResponseId = null;
let _streamingUserText = '', _leonAudioActiveId = null, _leonAudioMuteUntil = 0;
let _gotElevenAudio = false, _pendingPreviewEl = null, _pendingPreviewAt = 0;
let _convPrimed = false;
const dashboard = { setProcessing() {} };
function _setStopVisible() {}
function setAction() {}
function _userLinePainted() { return true; }   // his line is not what we measure
function _paintUserEcho() {}
function _maybeBrowserVoice() {}
function pullConvo() {}
function speakableJs(s) { return s; }
function renderConvText(s) { return s; }
global.setTimeout = () => 0;                   // no deferred pullConvo in replay

const src = fs.readFileSync(path.join(__dirname, 'funcs.js'), 'utf8');
eval(src);

// ── measurement ─────────────────────────────────────────────────────────────
const body = () => document.getElementById('conv-body');
const bars = () => body().querySelectorAll('.conv-thinking').length;
const texts = () => Array.from(body().querySelectorAll('.conv-brain-text'))
    .map(n => n.textContent).filter(t => t.trim());

function reset() {
    body().innerHTML = '';
    _streamingTurnEl = _streamingBrainEl = _thinkingEl = null;
    _pendingPreviewEl = null;
    _streamingResponseText = '';
    _streamingResponseId = null;
}

const results = [];
function scenario(name, steps, check) {
    reset();
    steps();
    const got = { bars: bars(), texts: texts() };
    const why = check(got);
    results.push({ name, ok: !why, why, got });
}

// (1) THE POLL RACE. The 1.8s processing poll paints dots before
// response_start ever arrives, so _showThinking()'s _streamingTurnEl guard is
// false. response_start then painted its own set on top.
scenario('poll dots, then response_start',
    () => { _showThinking(); H_onResponseStart('hey iris', 'r1', {}); },
    g => g.bars === 1 ? null : `${g.bars} loading bars, want 1`);

// (2) THE ORPHAN. A turn that emits a second response_start (tool
// continuation, reconnect, retry) reassigned _streamingTurnEl and abandoned
// the first div. Only the CURRENT turn's dots ever get removed, so the orphan
// spins forever — this is the bar that never goes away.
scenario('two response_starts in one turn',
    () => { H_onResponseStart('hey iris', 'r1', {}); H_onResponseStart('hey iris', 'r2', {}); },
    g => g.bars === 1 ? null : `${g.bars} loading bars, want 1`);

// (3) ALL THREE AT ONCE — exactly what Aiden was looking at.
scenario('poll dots + two response_starts',
    () => { _showThinking(); H_onResponseStart('hey iris', 'r1', {}); H_onResponseStart('hey iris', 'r2', {}); },
    g => g.bars === 1 ? null : `${g.bars} loading bars, want 1`);

// (4) Cleaning up an orphan must NEVER eat words the SI already said.
scenario('orphan carrying real text is preserved',
    () => {
        H_onResponseStart('hey iris', 'r1', {});
        H_onResponseDelta('r1', 'I can see you');
        H_onResponseStart('hey iris', 'r2', {});
    },
    g => g.bars !== 1 ? `${g.bars} loading bars, want 1`
        : g.texts.includes('I can see you') ? null
        : `lost streamed text, got ${JSON.stringify(g.texts)}`);

// (5) A normal completed turn leaves nothing spinning.
scenario('normal turn ends with no bar',
    () => {
        H_onResponseStart('hey iris', 'r1', {});
        H_onResponseDelta('r1', 'hi');
        H_onResponseEnd('r1', 'hi Dean');
    },
    g => g.bars === 0 ? null : `${g.bars} loading bars after turn end, want 0`);

let bad = 0;
for (const r of results) {
    if (r.ok) { console.log(`PASS  ${r.name}`); }
    else {
        bad++;
        console.log(`FAIL  ${r.name}\n      ${r.why}`);
        console.log(`      bars=${r.got.bars} texts=${JSON.stringify(r.got.texts)}`);
    }
}
console.log(`\n${results.length - bad}/${results.length} pass`);
process.exit(bad ? 1 : 0);
