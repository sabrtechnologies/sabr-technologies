#!/usr/bin/env bash
# Sample the brain's own memory so the next climb has EVIDENCE, not a guess.
#
# WHY THIS EXISTS. On 2026-08-10 the service reached 10.7 GB, hung past the
# stop timeout, got SIGKILLed and crash-looped 12 times — about ten minutes
# during which Dean was talking into a dead process. The shutdown race is
# fixed. The CLIMB is not: a static audit checked every long-lived list in
# brain/ and found all three candidates bounded, so the leak is somewhere
# static analysis cannot see it. That means it has to be caught in the act.
#
# Cheap on purpose (a few ms, once a minute) — a profiler that costs enough to
# perturb the thing it measures is its own bug. RSS, threads and fds every
# tick; a py-spy stack dump only when RSS crosses a threshold, because that is
# the moment worth photographing and the only moment worth paying for.
set -uo pipefail

STATE=/opt/leon-brain/brain_state
OUT="$STATE/mem_samples.tsv"
DUMPS="$STATE/mem_dumps"
THRESHOLD_GB="${MEM_WATCH_THRESHOLD_GB:-5}"

PID=$(systemctl show -p MainPID --value leon.service 2>/dev/null)
# NEVER hardcode a PID. A previous session read the environ of an unrelated
# shell script, concluded the brain was stale, and was wrong in a way that
# looked exactly like being right. Resolve it every run, and bail if the
# service is down rather than sampling whatever now owns that number.
[ -n "$PID" ] && [ "$PID" != "0" ] && [ -d "/proc/$PID" ] || exit 0

read -r _ ETIME RSS_KB <<<"$(ps -o pid=,etimes=,rss= -p "$PID")"
THREADS=$(ls "/proc/$PID/task" 2>/dev/null | wc -l)
FDS=$(ls "/proc/$PID/fd" 2>/dev/null | wc -l)
CG=$(cat /sys/fs/cgroup/system.slice/leon.service/memory.current 2>/dev/null || echo 0)
TS=$(date +%s)

[ -s "$OUT" ] || echo -e "ts\tpid\tuptime_s\trss_kb\tcgroup_bytes\tthreads\tfds" > "$OUT"
echo -e "$TS\t$PID\t$ETIME\t$RSS_KB\t$CG\t$THREADS\t$FDS" >> "$OUT"

# Keep the log bounded — a memory watchdog that fills the disk has simply
# moved the outage rather than prevented it.
if [ "$(wc -l < "$OUT")" -gt 20000 ]; then
  tail -10000 "$OUT" > "$OUT.tmp" && mv "$OUT.tmp" "$OUT"
fi

# Above the line: photograph what every thread is actually doing. This is the
# artifact that turns "it grew again" into a specific function.
RSS_GB=$(awk -v k="$RSS_KB" 'BEGIN{printf "%.2f", k/1048576}')
if awk -v r="$RSS_GB" -v t="$THRESHOLD_GB" 'BEGIN{exit !(r>t)}'; then
  mkdir -p "$DUMPS"
  STAMP=$(date +%Y%m%d-%H%M%S)
  # --nonblocking: do NOT pause the process to read it. A stop-the-world dump
  # on a brain already near its stop-timeout budget could cause the very
  # SIGKILL this script exists to prevent.
  timeout 60 py-spy dump --pid "$PID" --nonblocking \
    > "$DUMPS/stacks-${STAMP}-${RSS_GB}GB.txt" 2>&1 || true
  ls -1t "$DUMPS" | tail -n +25 | while read -r old; do rm -f "$DUMPS/$old"; done
  echo "[mem_watch] $RSS_GB GB — stack dump written to $DUMPS/stacks-${STAMP}-${RSS_GB}GB.txt" >&2
fi
