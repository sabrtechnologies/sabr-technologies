#!/usr/bin/env python3
"""Armed-but-waiting spinner floor sampler. Survives a context death mid-run.

Four measurements died void tonight because the pane was not in the state the
sampler assumed. This one does not assume: it will not start the clock until a
human writes a release token naming the window, and it re-verifies the spinner
itself before the first sample AND aborts if the spinner dies mid-run.

APPEND-ONLY with fsync per sample, so a fresh instance can compute the
distribution from the file even if this process is killed at minute 29.

  arm:        python3 tools/spinner_floor_armed.py            (this mode)
  summarize:  python3 tools/spinner_floor_armed.py --summarize
"""
import json, os, subprocess, sys, time

STATE   = "/opt/leon-brain/brain_state"
OUT     = os.path.join(STATE, "spinner_floor_30min.jsonl")
RELEASE = os.path.join(STATE, "spinner_floor_RELEASE")
DURATION, HZ = 1800, 1.0
GLYPHS = ("✻", "✽", "✢", "esc to interrupt")


def summarize():
    rows = [json.loads(l) for l in open(OUT)]
    v = sorted(r["cpu_ticks_per_s"] for r in rows if "cpu_ticks_per_s" in r)
    if not v:
        print("no samples"); return
    p95 = v[min(len(v) - 1, int(round(0.95 * (len(v) - 1))))]
    print(f"n={len(v)}  floor(min)={v[0]:.1f}  median={v[len(v)//2]:.1f}  "
          f"p95={p95:.1f}  max={v[-1]:.1f}  nonzero={sum(1 for x in v if x>0)}/{len(v)}")


if "--summarize" in sys.argv:
    summarize(); raise SystemExit

def cap(w): return subprocess.run(["tmux","capture-pane","-p","-t",f"agents:{w}"],
                                  capture_output=True, text=True).stdout
def leaf(w):
    p = int(subprocess.run(["tmux","display-message","-p","-t",f"agents:{w}","#{pane_pid}"],
                           capture_output=True, text=True).stdout.strip())
    while True:
        k = subprocess.run(["pgrep","-P",str(p)], capture_output=True, text=True).stdout.split()
        if not k: return p
        p = int(k[0])
def ticks(p):
    try:
        d = open(f"/proc/{p}/stat").read(); f = d[d.rindex(")")+2:].split()
        return int(f[11]) + int(f[12])
    except Exception: return None
def emit(row):
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n"); fh.flush(); os.fsync(fh.fileno())

# ── ARMED: wait for the release token, indefinitely ──────────────────
while not os.path.exists(RELEASE):
    time.sleep(5)
token = open(RELEASE).read().strip()
window = token.split()[-1] if token.startswith("SPINNER-LIVE-CONFIRMED") else None
if not window:
    emit({"event": "abort", "why": f"malformed token {token!r}"}); raise SystemExit

# ── RE-VERIFY rather than trust the token ────────────────────────────
screen = cap(window)
if not any(g in screen for g in GLYPHS):
    emit({"event": "abort", "why": "no spinner glyph at release — sampler will "
          "not measure a pane it cannot confirm is thinking", "window": window})
    raise SystemExit

pid = leaf(window)
emit({"event": "start", "ts": time.time(), "window": window, "leaf_pid": pid,
      "token": token, "spinner_verified": True, "duration_s": DURATION})
prev, tp = ticks(pid), time.time()
for i in range(DURATION):
    time.sleep(HZ)
    now = time.time(); cur = ticks(pid)
    if cur is None:
        emit({"event": "abort", "t": i+1, "why": "leaf pid vanished"}); break
    live = any(g in cap(window) for g in GLYPHS)
    emit({"t": i+1, "ts": now, "cpu_ticks_per_s": round((cur-prev)/(now-tp), 2),
          "spinner_live": live})
    if not live:
        emit({"event": "abort", "t": i+1,
              "why": "spinner died — turn ended, remaining samples would be idle"}); break
    prev, tp = cur, now
else:
    emit({"event": "done", "ts": time.time()})
