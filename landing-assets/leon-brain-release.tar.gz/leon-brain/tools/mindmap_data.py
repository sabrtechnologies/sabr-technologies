#!/usr/bin/env python3
"""Build the 3D mind-map graph payload from Leon's cognition graph.

Emits {nodes:[{id,name,type,val}], links:[{source,target,rel,w}]} sized for
a browser: hub noise dropped, singletons dropped, capped at MAX_NODES by
salience so the render stays legible instead of becoming a hairball.
"""
from __future__ import annotations

import json
import re
import sqlite3
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GRAPH_DB = ROOT / "brain_state" / "cognition_graph.db"
OUT = ROOT / "dashboard" / "data" / "mindmap.json"

MAX_NODES = 900
MAX_EDGES_PER_NODE = 6

# Machinery that links to everything and therefore explains nothing.
NOISE = {"null", "none", "true", "false", "", "/dev/null", "t", "status", "usage"}
NOISE_RE = re.compile(r"^(morn|aft|eve|night)-default$|^macro_[0-9a-f]{6,}$")

TYPE_COLOR = {
    "project": "#5ac8fa",
    "concept": "#c792ea",
    "action": "#ffb454",
    "file": "#7fdba0",
    "url": "#ff6b8b",
    "time_pattern": "#8899a6",
}


def _noise(name: str) -> bool:
    low = (name or "").strip().lower()
    return low in NOISE or bool(NOISE_RE.match(low))


def build() -> dict:
    con = sqlite3.connect(f"file:{GRAPH_DB}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row

    ents = {}
    for r in con.execute(
        "SELECT id, type, name, mention_count, salience FROM entities"
    ):
        if _noise(r["name"]):
            continue
        ents[r["id"]] = dict(r)

    edges = []
    deg = defaultdict(int)
    for r in con.execute(
        "SELECT src_id, dst_id, relation, support_count FROM edges"
    ):
        if r["src_id"] in ents and r["dst_id"] in ents and r["src_id"] != r["dst_id"]:
            edges.append(dict(r))
            deg[r["src_id"]] += 1
            deg[r["dst_id"]] += 1
    con.close()

    # Keep only entities that actually connect to something — an isolated
    # dot carries no structure and just adds dust to the render.
    linked = {eid for eid in ents if deg[eid] > 0}

    # Rank by connectedness first, mentions second: a node the brain keeps
    # associating matters more than one it merely saw often.
    ranked = sorted(
        linked,
        key=lambda e: (deg[e], ents[e]["mention_count"] or 0),
        reverse=True,
    )[:MAX_NODES]
    keep = set(ranked)

    nodes = []
    for eid in ranked:
        e = ents[eid]
        nodes.append({
            "id": eid,
            "name": e["name"],
            "type": e["type"],
            "color": TYPE_COLOR.get(e["type"], "#9aa7b4"),
            # Sub-linear so one mega-hub doesn't swallow the screen.
            "val": round(1.0 + (deg[eid] ** 0.5), 2),
            "deg": deg[eid],
            "mentions": e["mention_count"],
        })

    # Every surviving node keeps only its strongest ties. Without this the
    # render is 9k edges over 574 nodes — technically the whole truth, and
    # visually a solid ball of yarn you cannot read anything out of.
    kept, per_node = [], defaultdict(int)
    for ed in sorted(edges, key=lambda x: -(x["support_count"] or 1)):
        s, d = ed["src_id"], ed["dst_id"]
        if s not in keep or d not in keep:
            continue
        if per_node[s] >= MAX_EDGES_PER_NODE and per_node[d] >= MAX_EDGES_PER_NODE:
            continue
        per_node[s] += 1
        per_node[d] += 1
        kept.append({"source": s, "target": d,
                     "rel": ed["relation"], "w": ed["support_count"] or 1})

    return {"nodes": nodes, "links": kept}


if __name__ == "__main__":
    data = build()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data), encoding="utf-8")
    print(f"nodes={len(data['nodes'])} links={len(data['links'])} -> {OUT}")
