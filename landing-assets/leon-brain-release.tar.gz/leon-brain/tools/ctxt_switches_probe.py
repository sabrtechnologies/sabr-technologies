#!/usr/bin/env python3
"""voluntary_ctxt_switches probe, pre-registered per DJ-027.

Ship rule (committed before this ran): zero voluntary_ctxt_switches summed
across the pane's descendant tree, across three consecutive 5s windows,
ships YES. Nonzero in any window is NO. No revisiting after data.

Reuses tools/spinner_floor.py's descendants() walk for the same
foreground-tree scope the rest of this project's probes use, rather than a
single PID.
"""
import json
import subprocess
import sys
import time


def descendants(pid):
    seen, stack = set(), [pid]
    while stack:
        c = stack.pop()
        if c in seen or not c:
            continue
        seen.add(c)
        try:
            with open(f"/proc/{c}/task/{c}/children") as fh:
                stack.extend(int(x) for x in fh.read().split())
        except Exception:
            pass
    return seen


def vctx(pid):
    try:
        for line in open(f"/proc/{pid}/status"):
            if line.startswith("voluntary_ctxt_switches:"):
                return int(line.split()[1])
    except Exception:
        return None
    return None


def pane_pid(session, window):
    return int(subprocess.run(
        ["tmux", "display-message", "-p", "-t", f"{session}:{window}", "#{pane_pid}"],
        capture_output=True, text=True, check=True,
    ).stdout.strip())


def sample_total(pid):
    ds = descendants(pid)
    vals = [vctx(d) for d in ds]
    vals = [v for v in vals if v is not None]
    return sum(vals), len(ds)


def three_windows(session, window, window_s=5.0):
    pid = pane_pid(session, window)
    windows = []
    prev_total, _ = sample_total(pid)
    for i in range(3):
        time.sleep(window_s)
        cur_total, ndesc = sample_total(pid)
        windows.append({"window": i + 1, "delta": cur_total - prev_total,
                         "descendants": ndesc})
        prev_total = cur_total
    return windows


def main():
    hung_s, hung_w = sys.argv[1].split(":")
    healthy_s, healthy_w = sys.argv[2].split(":")
    window_s = float(sys.argv[3]) if len(sys.argv) > 3 else 5.0

    hung = three_windows(hung_s, hung_w, window_s)
    healthy = three_windows(healthy_s, healthy_w, window_s)

    print(json.dumps({"hung": hung, "healthy": healthy}, indent=2))


if __name__ == "__main__":
    main()
