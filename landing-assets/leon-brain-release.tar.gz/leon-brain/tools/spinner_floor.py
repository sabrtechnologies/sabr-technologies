#!/usr/bin/env python3
"""Baseline the spinner floor: per-second CPU of a REAL claude pane mid-wait.

Bare CPU died as a discriminator because a claude pane redraws its spinner
while awaiting an API response — paint reaching CPU through the back door. No
nonzero reading means anything until we know what that floor is. Shell
processes are not a proxy: `sleep` has no TUI.

/proc only. No pane reads anywhere in this file.
"""
import json, subprocess, sys, time

SESSION, WINDOW = sys.argv[1], sys.argv[2]
SECONDS = int(sys.argv[3]) if len(sys.argv) > 3 else 300
OUT = "/opt/leon-brain/brain_state/spinner_floor.log"


def descendants(pid):
    seen, stack = set(), [pid]
    while stack:
        c = stack.pop()
        if c in seen or not c:
            continue
        seen.add(c)
        try:
            with open(f"/proc/{c}/task/{c}/children") as fh:
                stack.extend(int(x) for x in fh.read().split())
        except Exception:
            pass
    return seen


def ticks(pid):
    try:
        d = open(f"/proc/{pid}/stat").read()
        f = d[d.rindex(")") + 2:].split()
        return int(f[11]) + int(f[12])
    except Exception:
        return None


pid = int(subprocess.run(["tmux", "display-message", "-p", "-t",
                          f"{SESSION}:{WINDOW}", "#{pane_pid}"],
                         capture_output=True, text=True).stdout.strip())
prev, t_prev = {d: ticks(d) for d in descendants(pid)}, time.time()
with open(OUT, "a") as fh:
    fh.write(json.dumps({"event": "start", "ts": t_prev, "pane_pid": pid,
                         "seconds": SECONDS}) + "\n")
for i in range(SECONDS):
    time.sleep(1)
    now = time.time()
    ds = descendants(pid)
    cur = {d: ticks(d) for d in ds}
    tot = sum((cur[d] - prev[d]) / (now - t_prev)
              for d in cur if prev.get(d) is not None and cur[d] is not None)
    with open(OUT, "a") as fh:
        fh.write(json.dumps({"t": i + 1, "ts": now, "cpu_ticks_per_s": round(tot, 2),
                             "descendants": len(ds)}) + "\n")
    prev, t_prev = cur, now
with open(OUT, "a") as fh:
    fh.write(json.dumps({"event": "done", "ts": time.time()}) + "\n")
