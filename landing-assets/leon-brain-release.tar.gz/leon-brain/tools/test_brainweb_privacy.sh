#!/usr/bin/env bash
# REGRESSION GUARD. Dean, 2026-08-17: hovering a node must never print a real
# filename — he demos this on video and so will customers. This asserts the
# tooltip renders the anatomical region and NOT the memory's own label.
set -uo pipefail
P="$(dirname "$0")/../dashboard/js/brainweb-page.html"
fail=0
check() { if eval "$2"; then echo "  ok   $1"; else echo "  FAIL $1"; fail=1; fi; }

echo "brainweb privacy audit:"
# Dean, 2026-08-17 (later): hover now shows the REAL memory, Obsidian-style —
# "otherwise it's just a random shape of spikes and no one knows what it means."
# So the boundary moved, and these checks moved with it. The rule is no longer
# "never print anything"; it is:
#   1. the BULK PAYLOAD still carries no names (see DATA LAYER below) — that is
#      the leak that actually mattered, a 1.2MB public JSON with 1,411 paths;
#   2. names arrive one at a time from the keyed endpoint, never from the file;
#   3. a private mode exists so he can film without redacting in post.
check "card is fed by the keyed endpoint" \
  "grep -q 'cognition/graph/node' '$P'"
check "card never reads a payload label" "! grep -qE '\.l\b.*memcard|memcard.*\bd\.l\b' '$P'"
check "renderer still never reads d.l"    "! grep -qE '(^|[^A-Za-z_])d\.l([^A-Za-z0-9_]|$)' '$P'"
check "no live label sprites"          "! grep -qE '^\s*buildLabels\(data' '$P'"
check "sprite builder is disabled"     "grep -q 'function buildLabels() { return; }' '$P'"
check "private mode exists"            "grep -q 'PRIVATE MODE' '$P'"
check "private mode persists"          "grep -q 'leonBrainPrivate' '$P'"
check "private mode redacts names"     "grep -q 'redact(d.name)' '$P'"
check "private mode redacts neighbours" "grep -q 'redact(x.name)' '$P'"
check "card escapes untrusted text"    "grep -q 'esc(name)' '$P'"

# ── DATA LAYER ────────────────────────────────────────────────────────────
# Everything above audits the RENDERER. On 2026-08-17 all five of those passed
# while the payload itself still shipped every label: 2,072 of them, 1,411
# containing a real path, including "secure/install_log_api_key" — in a 1.2MB
# JSON the browser downloads whole and devtools reads in one click. Hiding a
# field in the renderer while still putting it on the wire is a curtain, not
# privacy, and the release tarball would have handed that file to a stranger.
#
# So these checks read the PAYLOAD, not the page. A guard that only audits the
# layer you edited is how the leak survived the fix in the first place.
D="$(dirname "$0")/../dashboard/js/brainweb-data.json"
if [ -f "$D" ]; then
  check "payload carries no label field" \
    "python3 -c \"import json,sys; d=json.load(open('$D')); sys.exit(0 if not any('l' in n for n in d['nodes']) else 1)\""
  check "payload carries no file paths" \
    "! grep -qE '[A-Za-z0-9_-]+/[A-Za-z0-9_-]+\.(py|js|sh|md|json|html|ts)' '$D'"
  check "payload never mentions secure/" \
    "! grep -q 'secure/' '$D'"
  # The fingerprint must survive label removal — it is the layout seed, and if
  # stripping a field reshuffles it, every SI's body silently changes shape.
  check "payload still has a fingerprint" \
    "python3 -c \"import json; d=json.load(open('$D')); assert d.get('fp')\""
else
  echo "  skip payload checks — no brainweb-data.json yet"
fi

exit $fail
