#!/usr/bin/env bash
# Flip Leon's brain between cloud (Claude) and local/router survival brain.
# Usage: local_brain_test.sh on [minutes] | off
set -euo pipefail
ENV=/opt/leon-brain/.env
set_mode() { sed -i -E "s/^LEON_LOCAL_LLM_MODE=.*/LEON_LOCAL_LLM_MODE=$1/" "$ENV"; systemctl restart leon.service; }
case "${1:-}" in
  on)  m="${2:-15}"; set_mode only
       # deadman: always come back, even if nobody says anything
       ( sleep $((m*60)); sed -i -E "s/^LEON_LOCAL_LLM_MODE=.*/LEON_LOCAL_LLM_MODE=fallback/" "$ENV"; systemctl restart leon.service ) >/dev/null 2>&1 &
       echo "LOCAL-ONLY for ${m} min (auto-reverts)";;
  off) set_mode fallback; pkill -f "sleep .*local_brain_test" 2>/dev/null || true; echo "back on cloud";;
  *) grep '^LEON_LOCAL_LLM_MODE' "$ENV";;
esac
