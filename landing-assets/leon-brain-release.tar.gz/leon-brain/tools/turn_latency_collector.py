#!/usr/bin/env python3
"""DJ-016 corpus collector: real turn-latency samples, START -> FINISHED_RX.

Predicate (committed in DJ-016's discussion thread, not invented here):
  START = a send_ledger 'send' row for the window.
  END   = the pane's own FINISHED_RX marker ("Churned for Xm Ys"), read from
          the screen -- not send_ledger's 'replied' mark, which fires on any
          content change and is not agent-latency (see DJ-013).
  A qualifying turn pairs one START with the NEXT FINISHED_RX for that
  window, using the MOST RECENT prior send as the START. If a second send
  landed before FINISHED_RX appeared (a kill-and-retry), the earlier send
  is dropped -- it never reached FINISHED_RX and contributes zero turns;
  only the send immediately preceding the FINISHED_RX qualifies.
  A pane with no send_ledger activity for > SILENCE_GAP_S while other panes
  are active is logged as an instrumentation gap, not silently absent.

Output: brain_state/turn_latency_corpus.jsonl (one row per qualifying turn)
        brain_state/turn_latency_gaps.jsonl   (instrumentation gaps)
"""
import json
import os
import subprocess
import sys
import time

import re

sys.path.insert(0, "/opt/leon-brain")

# Corrected pattern -- see keep_busy_runner.py for the bug this fixes.
# NOT pane_watchdog._FINISHED_RX (unused elsewhere, was the wrong copy to
# begin with -- DJ-016 specified terminal_loop.py's FINISHED_RX) and NOT
# terminal_loop.FINISHED_RX either, since that copy has the same bug and
# is live in production (is_busy(), terminal_loop.py:145) -- not patching
# the shared production regex from a corpus-collection tool.
_FINISHED_RX = re.compile(r"^\s*[✻✢✽◉·*]\s+\w+ for (?:\d+m )?\d+s\s*$")

STATE_DIR = os.environ.get("LEON_BRAIN_STATE", "/opt/leon-brain/brain_state")
LEDGER_PATH = os.path.join(STATE_DIR, "send_ledger.jsonl")
CORPUS_PATH = os.path.join(STATE_DIR, "turn_latency_corpus.jsonl")
GAPS_PATH = os.path.join(STATE_DIR, "turn_latency_gaps.jsonl")
SESSION = os.environ.get("LEON_AGENT_TMUX_SESSION", "agents")
POLL_S = 5.0
SILENCE_GAP_S = 3600.0


def _append(path, row):
    with open(path, "a") as fh:
        fh.write(json.dumps(row) + "\n")
        fh.flush()


def list_windows():
    out = subprocess.run(
        ["tmux", "list-windows", "-t", SESSION, "-F", "#{window_name}"],
        capture_output=True, text=True,
    ).stdout
    return [w.strip() for w in out.splitlines() if w.strip()]


def capture(window):
    return subprocess.run(
        ["tmux", "capture-pane", "-p", "-t", f"{SESSION}:{window}", "-S", "-5"],
        capture_output=True, text=True,
    ).stdout


def finished_rx_text(raw):
    for line in reversed((raw or "").splitlines()):
        if _FINISHED_RX.match(line):
            return line.strip()
    return None


def qualifying_start(window, before_ts, ledger_sends):
    """Most recent send for this window strictly before before_ts."""
    candidates = [s for s in ledger_sends.get(window, []) if s["ts"] < before_ts]
    if not candidates:
        return None
    return max(candidates, key=lambda s: s["ts"])


def load_sends_since(cursor_ts):
    sends = {}
    try:
        with open(LEDGER_PATH) as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                if r.get("event") == "send" and r.get("ts", 0) >= cursor_ts:
                    sends.setdefault(r["window"], []).append(r)
    except FileNotFoundError:
        pass
    return sends


def main():
    last_finished_text = {}   # window -> last FINISHED_RX text seen (dedupe)
    last_activity = {}        # window -> ts of last send OR FINISHED_RX
    paired_starts = set()     # send ts+window already consumed as a START

    _append(CORPUS_PATH, {"event": "collector_start", "ts": time.time(),
                          "predicate": "START=send_ledger send, END=FINISHED_RX, "
                                       "most-recent-prior-send wins on kill/retry"})

    while True:
        now = time.time()
        sends = load_sends_since(now - 7 * 24 * 3600)  # bounded lookback
        windows = list_windows()

        for w in windows:
            raw = capture(w)
            text = finished_rx_text(raw)
            if text and text != last_finished_text.get(w):
                last_finished_text[w] = text
                last_activity[w] = now
                start = qualifying_start(w, now, sends)
                if start is not None:
                    key = (w, start["ts"])
                    if key not in paired_starts:
                        paired_starts.add(key)
                        duration = now - start["ts"]
                        _append(CORPUS_PATH, {
                            "event": "qualifying_turn", "window": w,
                            "start_ts": start["ts"], "end_ts": now,
                            "duration_s": round(duration, 2),
                            "finished_rx_text": text,
                        })

        for w in windows:
            if w in sends and sends[w]:
                last_activity[w] = max(last_activity.get(w, 0),
                                       max(s["ts"] for s in sends[w]))
            gap = now - last_activity.get(w, now)
            if gap > SILENCE_GAP_S:
                any_other_active = any(
                    (now - last_activity.get(o, 0)) < SILENCE_GAP_S
                    for o in windows if o != w
                )
                if any_other_active:
                    _append(GAPS_PATH, {"ts": now, "window": w,
                                        "gap_s": round(gap, 1),
                                        "note": "no send_ledger activity while "
                                                "other panes are active"})
                    last_activity[w] = now  # don't re-flag every poll

        time.sleep(POLL_S)


if __name__ == "__main__":
    main()
