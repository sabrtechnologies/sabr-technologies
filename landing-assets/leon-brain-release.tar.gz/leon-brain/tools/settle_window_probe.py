#!/usr/bin/env python3
"""Measures real latency from prompt-submission to first substantial CPU
activity, for a dedicated settle-window number rather than eyeballing each
trial's series by hand.
"""
import subprocess
import sys
import time
import json

PID = int(sys.argv[1])
WINDOW = sys.argv[2]  # e.g. "fixture:settle"
N = int(sys.argv[3]) if len(sys.argv) > 3 else 8
SAMPLE_S = 0.3
ACTIVITY_TICKS_THRESHOLD = 3  # >3 ticks in 0.3s ~= >10% of one core

PROMPTS = [
    "Explain how a hash table resolves collisions, at length, no tools.",
    "Explain how DNS resolution actually works end to end, at length, no tools.",
    "Explain the CAP theorem and its real tradeoffs, at length, no tools.",
    "Explain how virtual memory and paging work, at length, no tools.",
    "Explain how a B-tree index works in a database, at length, no tools.",
    "Explain how HTTPS/TLS handshakes establish a secure channel, at length, no tools.",
    "Explain how a load balancer picks a backend, at length, no tools.",
    "Explain how consistent hashing works, at length, no tools.",
    "Explain how a bloom filter works and why false positives happen, at length, no tools.",
    "Explain how raft consensus achieves agreement, at length, no tools.",
]


def capture(window):
    return subprocess.run(
        ["tmux", "capture-pane", "-p", "-t", window, "-S", "-8"],
        capture_output=True, text=True,
    ).stdout


def looks_busy(raw):
    """Same signal terminal_loop.is_busy() uses: a spinner glyph line with
    an ellipsis, or a 'tokens)' marker -- not raw CPU, which picks up
    keystroke-echo noise before real generation starts."""
    for line in reversed((raw or "").splitlines()):
        line = line.strip()
        if not line:
            continue
        if "tokens)" in line:
            return True
        if line[:1] in ("✻", "✢", "✽", "·", "*") and "…" in line:
            return True
    return False


results = []
for i in range(N):
    prompt = PROMPTS[i % len(PROMPTS)]
    subprocess.run(["tmux", "send-keys", "-t", WINDOW, prompt, "Enter"])
    time.sleep(1)
    subprocess.run(["tmux", "send-keys", "-t", WINDOW, "Enter"])
    t_submit = time.time()  # actual submit moment

    latency = None
    for _ in range(int(30 / SAMPLE_S)):  # give it up to 30s to start
        time.sleep(SAMPLE_S)
        if looks_busy(capture(WINDOW)):
            latency = round(time.time() - t_submit, 2)
            break
    results.append({"trial": i + 1, "latency_s": latency})
    print(json.dumps(results[-1]))
    # let it run a bit before the next prompt to avoid overlapping turns
    time.sleep(8)

lat = [r["latency_s"] for r in results if r["latency_s"] is not None]
summary = {
    "n": len(lat), "min": min(lat) if lat else None, "max": max(lat) if lat else None,
    "all": lat,
}
print(json.dumps({"SUMMARY": summary}))
