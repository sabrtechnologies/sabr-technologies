//! Leon neural core — Rust hot loop.
//!
//! Stage 0 profiling (2026-07-18) found STDP `update_stdp` = 94% of every
//! tick (synapse propagation was 0%), so the port target is the STDP
//! output-proportional loop, NOT propagation as the original plan assumed.
//!
//! Stage 2: `update_stdp` ported from brain/synapses.py. Numerical contract:
//! the Python loop's scalars (a_plus = STDP_A_PLUS * modulation, etc.) arrive
//! as numpy float64 in production (modulation = dopamine * stage rate), so
//! NumPy promotes every array op to float64 and rounds to float32 only at the
//! store. We reproduce exactly that: all arithmetic in f64, single rounding
//! to f32 at each store. Parity is enforced by tests/test_rust_stdp_parity.py.
use numpy::{PyArray1, PyArrayMethods, PyReadonlyArray1};
use pyo3::prelude::*;
use pyo3::types::{PyList, PyTuple};

#[pyfunction]
fn version() -> &'static str {
    "leon_core 0.4.0 — rust stage-5 (STDP + batch + neuron integrate + noise)"
}

/// Sanity check that real computation crosses the FFI boundary intact.
#[pyfunction]
fn add(a: f64, b: f64) -> f64 {
    a + b
}

/// Shared STDP math (steps 1-4) over already-extracted slices. Single source
/// of truth so update_stdp and update_stdp_batch are bit-identical.
#[allow(clippy::too_many_arguments)]
#[inline]
fn stdp_core(
    data: &mut [f32],
    indices: &[i32],
    indptr: &[i32],
    pre_trace: &mut [f32],
    post_trace: &mut [f32],
    pre_mask: &[bool],
    post_mask: &[bool],
    dt: f64,
    tau_plus: f64,
    tau_minus: f64,
    a_plus: f64,
    a_minus: f64,
    w_min: f64,
    w_max: f64,
) {
    let n_post = post_trace.len();
    // 1. Decay traces. np.exp(python float) is a float64 scalar, so numpy
    // computes f64(x) * decay and rounds once at the f32 store.
    let decay_pre = (-dt / tau_plus).exp();
    let decay_post = (-dt / tau_minus).exp();
    for v in pre_trace.iter_mut() {
        *v = ((*v as f64) * decay_pre) as f32;
    }
    for v in post_trace.iter_mut() {
        *v = ((*v as f64) * decay_post) as f32;
    }

    // 2. Trace bumps.
    let any_pre = pre_mask.iter().any(|&b| b);
    let any_post = post_mask.iter().any(|&b| b);
    if any_pre {
        for (v, &m) in pre_trace.iter_mut().zip(pre_mask) {
            if m {
                *v = ((*v as f64) + a_plus) as f32;
            }
        }
    }
    if any_post {
        for (v, &m) in post_trace.iter_mut().zip(post_mask) {
            if m {
                *v = ((*v as f64) + a_minus) as f32;
            }
        }
    }

    if !(any_pre && any_post) {
        return;
    }

    // 3. LTP over rows of active post neurons.
    for pi in 0..n_post {
        if !post_mask[pi] {
            continue;
        }
        let start = indptr[pi] as usize;
        let end = indptr[pi + 1] as usize;
        for k in start..end {
            let col = indices[k] as usize;
            let dw = (pre_trace[col] as f64) * a_plus;
            data[k] = ((data[k] as f64) + dw).clamp(w_min, w_max) as f32;
        }
    }

    // 4. LTD on the first 50 inactive post rows (not_post[:50] semantics:
    // every inactive index counts toward the 50, empty rows included).
    let a_minus_half = a_minus * 0.5;
    let mut taken = 0usize;
    for pi in 0..n_post {
        if post_mask[pi] {
            continue;
        }
        if taken >= 50 {
            break;
        }
        taken += 1;
        let start = indptr[pi] as usize;
        let end = indptr[pi + 1] as usize;
        for k in start..end {
            if pre_mask[indices[k] as usize] {
                data[k] = ((data[k] as f64) - a_minus_half).clamp(w_min, w_max) as f32;
            }
        }
    }

    let _ = (indptr, indices);
}

/// STDP weight update on a CSR matrix (post x pre), in place.
///
/// Mirrors SynapseMatrix.update_stdp in brain/synapses.py step for step:
///   1. exponential decay of pre/post traces
///   2. trace bump for neurons that fired this tick
///   3. LTP: every row of an active post neuron gets +pre_trace[col]*a_plus
///   4. LTD: the first 50 inactive post rows (ascending index, counted
///      whether or not the row is empty — same as `not_post[:50]`) get
///      -a_minus*0.5 on entries whose pre neuron fired
///
/// `data`, `pre_trace`, `post_trace` are mutated in place. `a_plus`/`a_minus`
/// must already include the modulation factor (caller multiplies, same as
/// the Python loop does).
#[pyfunction]
#[allow(clippy::too_many_arguments)]
fn update_stdp(
    data: &Bound<'_, PyArray1<f32>>,
    indices: PyReadonlyArray1<'_, i32>,
    indptr: PyReadonlyArray1<'_, i32>,
    pre_trace: &Bound<'_, PyArray1<f32>>,
    post_trace: &Bound<'_, PyArray1<f32>>,
    pre_mask: PyReadonlyArray1<'_, bool>,
    post_mask: PyReadonlyArray1<'_, bool>,
    dt: f64,
    tau_plus: f64,
    tau_minus: f64,
    a_plus: f64,
    a_minus: f64,
    w_min: f64,
    w_max: f64,
) -> PyResult<()> {
    // SAFETY: the Python caller passes freshly-materialized mask arrays and
    // holds the GIL for the duration of this call; nothing else aliases
    // data/pre_trace/post_trace while we hold these slices.
    let data = unsafe { data.as_slice_mut()? };
    let pre_trace = unsafe { pre_trace.as_slice_mut()? };
    let post_trace = unsafe { post_trace.as_slice_mut()? };
    let indices = indices.as_slice()?;
    let indptr = indptr.as_slice()?;
    let pre_mask = pre_mask.as_slice()?;
    let post_mask = post_mask.as_slice()?;

    let n_post = post_trace.len();
    if indptr.len() != n_post + 1 {
        return Err(pyo3::exceptions::PyValueError::new_err(format!(
            "indptr len {} != n_post {} + 1",
            indptr.len(),
            n_post
        )));
    }
    if pre_mask.len() != pre_trace.len() || post_mask.len() != n_post {
        return Err(pyo3::exceptions::PyValueError::new_err(
            "mask length does not match trace length",
        ));
    }

    stdp_core(
        data, indices, indptr, pre_trace, post_trace, pre_mask, post_mask,
        dt, tau_plus, tau_minus, a_plus, a_minus, w_min, w_max,
    );
    Ok(())
}


/// Batched STDP: one FFI crossing for ALL active connections in a tick.
///
/// `conns` is a list of 7-tuples, one per active (src,dst) connection:
///   (data, indices, indptr, pre_trace, post_trace, pre_mask, post_mask)
/// with the same dtypes as `update_stdp` (data/traces f32, indices/indptr i32,
/// masks bool). Scalars are shared across the batch — in the real tick
/// modulation = dopamine * stage_rate is identical for every connection, so
/// a_plus / a_minus are passed once. Each connection is processed by the same
/// `stdp_core` as the single-call path, so results are bit-identical; the only
/// thing that changes is 48 border crossings collapse into 1.
#[pyfunction]
#[allow(clippy::too_many_arguments)]
fn update_stdp_batch(
    conns: &Bound<'_, PyList>,
    dt: f64,
    tau_plus: f64,
    tau_minus: f64,
    a_plus: f64,
    a_minus: f64,
    w_min: f64,
    w_max: f64,
) -> PyResult<()> {
    for item in conns.iter() {
        let t = item.cast_into::<PyTuple>()?;
        if t.len() != 7 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "update_stdp_batch: each connection must be a 7-tuple",
            ));
        }
        let data = t.get_item(0)?.cast_into::<PyArray1<f32>>()?;
        let indices = t.get_item(1)?.cast_into::<PyArray1<i32>>()?;
        let indptr = t.get_item(2)?.cast_into::<PyArray1<i32>>()?;
        let pre_trace = t.get_item(3)?.cast_into::<PyArray1<f32>>()?;
        let post_trace = t.get_item(4)?.cast_into::<PyArray1<f32>>()?;
        let pre_mask = t.get_item(5)?.cast_into::<PyArray1<bool>>()?;
        let post_mask = t.get_item(6)?.cast_into::<PyArray1<bool>>()?;

        // SAFETY: each connection owns distinct, freshly-materialized arrays;
        // caller holds the GIL and nothing else aliases them this tick.
        let data_s = unsafe { data.as_slice_mut()? };
        let pre_trace_s = unsafe { pre_trace.as_slice_mut()? };
        let post_trace_s = unsafe { post_trace.as_slice_mut()? };
        let indices_s = unsafe { indices.as_slice()? };
        let indptr_s = unsafe { indptr.as_slice()? };
        let pre_mask_s = unsafe { pre_mask.as_slice()? };
        let post_mask_s = unsafe { post_mask.as_slice()? };

        let n_post = post_trace_s.len();
        if indptr_s.len() != n_post + 1
            || pre_mask_s.len() != pre_trace_s.len()
            || post_mask_s.len() != n_post
        {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "update_stdp_batch: array length mismatch in a connection",
            ));
        }

        stdp_core(
            data_s, indices_s, indptr_s, pre_trace_s, post_trace_s,
            pre_mask_s, post_mask_s, dt, tau_plus, tau_minus,
            a_plus, a_minus, w_min, w_max,
        );
    }
    Ok(())
}

/// Izhikevich neuron integration for one population, in place.
///
/// Mirrors NeuronPopulation.step in brain/neurons.py after the noise term is
/// applied (caller passes `total_i` = I + external + noise already summed).
/// Steps, in order:
///   1. zero total_i on neurons currently in refractory (mask BEFORE decrement)
///   2. decay refractory: r = max(0, r - dt)   (r is f32, matching numpy)
///   3. two 0.5*dt Izhikevich substeps of v,u (all f64, matching numpy)
///   4. fired = v >= v_thresh
///   5. reset fired neurons: v=c, u+=d, last_spike=t, refractory=refractory_period
///   6. clamp v to [v_clip_lo, v_clip_hi]
///
/// `v`, `u`, `refractory`, `last_spike_time`, and `fired` are mutated in place.
/// Returns the spike count. Deterministic given `total_i`, so bit-exact vs the
/// numpy path (tests/test_rust_neurons_parity.py).
#[pyfunction]
#[allow(clippy::too_many_arguments)]
fn integrate_neurons(
    v: &Bound<'_, PyArray1<f64>>,
    u: &Bound<'_, PyArray1<f64>>,
    a: PyReadonlyArray1<'_, f64>,
    b: PyReadonlyArray1<'_, f64>,
    c: PyReadonlyArray1<'_, f64>,
    d: PyReadonlyArray1<'_, f64>,
    refractory: &Bound<'_, PyArray1<f32>>,
    last_spike_time: &Bound<'_, PyArray1<f64>>,
    fired: &Bound<'_, PyArray1<bool>>,
    total_i: PyReadonlyArray1<'_, f64>,
    dt: f64,
    refractory_period: f32,
    t: f64,
    v_thresh: f64,
    v_clip_lo: f64,
    v_clip_hi: f64,
) -> PyResult<usize> {
    // SAFETY: caller holds the GIL and passes distinct, freshly-owned arrays;
    // nothing else aliases these while we hold the slices.
    let v = unsafe { v.as_slice_mut()? };
    let u = unsafe { u.as_slice_mut()? };
    let refractory = unsafe { refractory.as_slice_mut()? };
    let last_spike_time = unsafe { last_spike_time.as_slice_mut()? };
    let fired = unsafe { fired.as_slice_mut()? };
    let a = a.as_slice()?;
    let b = b.as_slice()?;
    let c = c.as_slice()?;
    let d = d.as_slice()?;
    let ti = total_i.as_slice()?;

    let n = v.len();
    if [u.len(), a.len(), b.len(), c.len(), d.len(), refractory.len(),
        last_spike_time.len(), fired.len(), ti.len()].iter().any(|&l| l != n) {
        return Err(pyo3::exceptions::PyValueError::new_err(
            "integrate_neurons: array length mismatch",
        ));
    }

    let half_dt = dt / 2.0;
    let mut total_i_local = vec![0.0f64; n];
    // Step 1: refractory gate (mask uses current refractory, before decay).
    for i in 0..n {
        total_i_local[i] = if refractory[i] > 0.0 { 0.0 } else { ti[i] };
    }
    // Step 2: decay refractory (f32 arithmetic to match numpy's f32 array).
    let dt_f32 = dt as f32;
    for r in refractory.iter_mut() {
        let nr = *r - dt_f32;
        *r = if nr > 0.0 { nr } else { 0.0 };
    }
    // Step 3: two Izhikevich half-steps.
    for _ in 0..2 {
        for i in 0..n {
            let vi = v[i];
            // Match numpy's evaluation order exactly: v**2 is formed first
            // (vi*vi), THEN scaled by 0.04 — writing 0.04*vi*vi would be
            // (0.04*vi)*vi and rounds differently (~2e-9 drift).
            let dv = (0.04 * (vi * vi) + 5.0 * vi + 140.0 - u[i] + total_i_local[i]) * half_dt;
            let du = a[i] * (b[i] * vi - u[i]) * half_dt;
            v[i] = vi + dv;
            u[i] += du;
        }
    }
    // Steps 4-6: spikes, reset, clamp.
    let mut spike_count = 0usize;
    for i in 0..n {
        let f = v[i] >= v_thresh;
        fired[i] = f;
        if f {
            spike_count += 1;
            v[i] = c[i];
            u[i] += d[i];
            last_spike_time[i] = t;
            refractory[i] = refractory_period;
        }
        // np.clip after the reset (matches Python order).
        if v[i] < v_clip_lo {
            v[i] = v_clip_lo;
        } else if v[i] > v_clip_hi {
            v[i] = v_clip_hi;
        }
    }
    Ok(spike_count)
}


/// Fill a float64 array with N(mu, sigma^2) samples, in place, single pass.
///
/// Noise path (brain/quantum.py fill_normal). No bit-exactness contract vs
/// numpy — noise is explicitly non-reproducible — so this uses a self-
/// contained xoshiro256++ PRNG + Box-Muller transform. Quantum lineage is
/// preserved by the caller: `seed` is derived from the IBM quantum buffer
/// (see QuantumRNG), and `stream` keeps each region/tick on a distinct
/// substream. No numpy temporaries, no copy — writes straight into `arr`.
#[inline]
fn splitmix64(x: &mut u64) -> u64 {
    *x = x.wrapping_add(0x9E3779B97F4A7C15);
    let mut z = *x;
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58476D1CE4E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D049BB133111EB);
    z ^ (z >> 31)
}
#[inline]
fn rotl(x: u64, k: u32) -> u64 { (x << k) | (x >> (64 - k)) }
#[inline]
fn xoshiro_next(s: &mut [u64; 4]) -> u64 {
    let result = rotl(s[0].wrapping_add(s[3]), 23).wrapping_add(s[0]);
    let t = s[1] << 17;
    s[2] ^= s[0]; s[3] ^= s[1]; s[1] ^= s[2]; s[0] ^= s[3];
    s[2] ^= t; s[3] = rotl(s[3], 45);
    result
}
/// u64 -> f64 in (0, 1] (never exactly 0, safe for ln()).
#[inline]
fn to_unit(x: u64) -> f64 {
    (((x >> 11) as f64) + 1.0) * (1.0 / 9007199254740992.0)
}

#[pyfunction]
fn fill_normal(
    arr: &Bound<'_, PyArray1<f64>>,
    sigma: f64,
    mu: f64,
    seed: u64,
    stream: u64,
) -> PyResult<()> {
    let a = unsafe { arr.as_slice_mut()? };
    let n = a.len();
    if n == 0 { return Ok(()); }
    // Init xoshiro256++ state from (seed, stream) via splitmix64.
    let mut sm = seed ^ stream.wrapping_mul(0x9E3779B97F4A7C15);
    let mut s = [splitmix64(&mut sm), splitmix64(&mut sm),
                 splitmix64(&mut sm), splitmix64(&mut sm)];
    let two_pi = std::f64::consts::TAU;
    let mut i = 0usize;
    while i + 1 < n {
        let u1 = to_unit(xoshiro_next(&mut s));
        let u2 = to_unit(xoshiro_next(&mut s));
        let r = (-2.0 * u1.ln()).sqrt() * sigma;
        let ang = two_pi * u2;
        a[i]     = r * ang.cos() + mu;
        a[i + 1] = r * ang.sin() + mu;
        i += 2;
    }
    if i < n {
        let u1 = to_unit(xoshiro_next(&mut s));
        let u2 = to_unit(xoshiro_next(&mut s));
        let r = (-2.0 * u1.ln()).sqrt() * sigma;
        a[i] = r * (two_pi * u2).cos() + mu;
    }
    Ok(())
}

#[pymodule]
fn leon_core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(version, m)?)?;
    m.add_function(wrap_pyfunction!(add, m)?)?;
    m.add_function(wrap_pyfunction!(update_stdp, m)?)?;
    m.add_function(wrap_pyfunction!(update_stdp_batch, m)?)?;
    m.add_function(wrap_pyfunction!(integrate_neurons, m)?)?;
    m.add_function(wrap_pyfunction!(fill_normal, m)?)?;
    Ok(())
}
