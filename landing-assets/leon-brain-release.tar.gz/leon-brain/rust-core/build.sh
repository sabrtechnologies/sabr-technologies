#!/usr/bin/env bash
# Reproducible local build of leon_core -> extracted abi3 module in dist/.
# Run from anywhere; paths are resolved relative to this script.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CRATE="$ROOT/leon_core"

export CARGO_HOME="$ROOT/.cargo"
export RUSTUP_HOME="$ROOT/.rustup"
export PATH="$ROOT/.cargo/bin:$PATH"

echo "[build] compiling leon_core (release, abi3)…"
"$ROOT/.venv/bin/maturin" build --release --manifest-path "$CRATE/Cargo.toml"

WHEEL="$(ls -t "$CRATE"/target/wheels/leon_core-*-abi3-*.whl | head -1)"
echo "[build] wheel: $WHEEL"

echo "[build] extracting into dist/…"
rm -rf "$ROOT/dist/leon_core" "$ROOT"/dist/*.whl "$ROOT"/dist/*.dist-info
cp "$WHEEL" "$ROOT/dist/"
python3 - "$ROOT/dist" "$WHEEL" <<'PY'
import sys, zipfile, os
dist, wheel = sys.argv[1], sys.argv[2]
zipfile.ZipFile(wheel).extractall(dist)
# drop pyc cache if present
import shutil
p = os.path.join(dist, "leon_core", "__pycache__")
shutil.rmtree(p, ignore_errors=True)
print("[build] extracted to", os.path.join(dist, "leon_core"))
PY

echo "[build] verifying import + parity…"
python3 -c "import sys; sys.path.insert(0,'$ROOT/dist'); import leon_core; print('[build]', leon_core.version())"
echo "[build] done. Run the parity suites before shipping:"
echo "         python3 tests/test_rust_stdp_parity.py"
echo "         python3 tests/test_rust_neurons_parity.py"
