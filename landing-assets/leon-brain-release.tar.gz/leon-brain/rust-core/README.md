# leon_core — Leon's Rust neural hot-loop

The compute-heavy kernels of Leon's brain tick, moved out of Python into Rust
via [PyO3](https://pyo3.rs) + [maturin](https://www.maturin.rs). This is the
"replace the engine block, keep the driver" plan: the spiking-sim hot loop runs
in Rust; everything else (memory, tool calls, decision routing) stays Python.

## What's in the core (leon_core/src/lib.rs)

| Function | Ports | Python fallback | Flag |
|---|---|---|---|
| `update_stdp` | STDP learning rule (`brain/synapses.py`) — was 94% of every tick | `SynapseMatrix._update_stdp_py` | `LEON_RUST_STDP=1` |
| `integrate_neurons` | Izhikevich neuron integrate (`brain/neurons.py`) | `NeuronPopulation._step_py` | `LEON_RUST_NEURONS=1` |

Both are **bit-exact** against the numpy paths (tests/test_rust_stdp_parity.py,
tests/test_rust_neurons_parity.py). Rust mutates the existing numpy arrays in
place — state stays owned by Python, so the existing `brain_state` save/load is
untouched (no snapshot-format migration).

Design note: `update_stdp` uses f64 arithmetic rounding to f32 at each store to
match numpy's NEP-50 promotion; `integrate_neurons` uses `0.04*(v*v)` (not
`0.04*v*v`) to match numpy's `v**2`-first evaluation order. Both matter for
bit-exactness — the saved brain is calibrated to the numpy behavior.

## Build locally (Linux, this VPS)

Toolchain lives inside `rust-core/` (isolated CARGO_HOME/RUSTUP_HOME):

```bash
cd rust-core/leon_core
export CARGO_HOME=$PWD/../.cargo RUSTUP_HOME=$PWD/../.rustup
export PATH=$PWD/../.cargo/bin:$PATH
../.venv/bin/maturin build --release
# extract the abi3 wheel into dist/ so the brain can import it:
cd ..
rm -rf dist/leon_core dist/*.whl dist/*.dist-info
cp leon_core/target/wheels/leon_core-*-abi3-*.whl dist/
cd dist && python3 -c "import zipfile,os,glob; zipfile.ZipFile(glob.glob('*.whl')[0]).extractall('.')"
```

Or run `rust-core/build.sh` which does exactly the above.

The wheel is **abi3** (`pyo3` feature `abi3-py39`): one wheel works on CPython
3.9+, so no per-Python-version rebuilds. The brain imports it from
`rust-core/dist/` (added to `sys.path` when `LEON_RUST_*` is set).

## Cross-platform builds (CI)

`.github/workflows/leon-core-wheels.yml` builds abi3 wheels for Linux
(x86_64 + aarch64), Windows (x64), and macOS (Intel + Apple Silicon) on every
push touching `rust-core/leon_core/`, plus an sdist and an import smoke-test.
Tagging `leon-core-v*` attaches all wheels to a GitHub Release.

**Requires the repo pushed to a GitHub remote with Actions enabled.** As of
2026-07-20 this checkout has no remote — the workflow is ready but dormant
until the code is pushed. This is what lets an SI be "born on any computer":
the same core installs on Mac/Windows, not just the Linux VPS.

## Verify a build

```bash
python3 tests/test_rust_stdp_parity.py
python3 tests/test_rust_neurons_parity.py
```

Both must print "rust == …". If they fail, the build is wrong — do NOT ship it;
a faster brain that learns wrong is worse than a slow correct one.
