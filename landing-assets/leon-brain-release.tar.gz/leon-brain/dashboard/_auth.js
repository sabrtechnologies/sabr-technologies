// Auth bootstrap — included by all dashboard pages so fetch+WebSocket
// carry the LEON_API_KEY token automatically. Sourced from URL fragment
// (#key=XXX), then cached in sessionStorage.
(function() {
    // Accept the key from the fragment (#key=) OR the query string (?key=).
    // Install scripts, docs and hand-typed URLs all reach for ?key= because
    // that is the only shape a WebSocket can use — when only the fragment
    // was honoured, a correct key pasted into the URL was silently ignored
    // and the user got prompted as if it were wrong.
    var found = (location.hash.match(/[#&]key=([^&]+)/) ||
                 location.search.match(/[?&]key=([^&]+)/));
    if (found) {
        localStorage.setItem("leon_key", decodeURIComponent(found[1]));
        history.replaceState(null, "", location.pathname);
    }
    try{var _m=sessionStorage.getItem("leon_key");if(_m&&!localStorage.getItem("leon_key")){localStorage.setItem("leon_key",_m);}}catch(e){}
    var TOKEN = (localStorage.getItem("leon_key") || sessionStorage.getItem("leon_key") || "");
    window.__LEON_KEY = TOKEN;
    if (!TOKEN) {
        var k = prompt("Leon API key required. Paste it below:");
        if (k) {
            localStorage.setItem("leon_key", k.trim());
            window.__LEON_KEY = k.trim();
        }
    }

    var _origFetch = window.fetch;
    // One prompt at a time. Without this, a page that fires six parallel
    // requests throws six stacked "key invalid" prompts on a single bad key.
    var _prompting = null;

    window.fetch = function(input, init) {
        init = init || {};
        init.headers = new Headers(init.headers || {});
        if (window.__LEON_KEY && !init.headers.has("Authorization")) {
            init.headers.set("Authorization", "Bearer " + window.__LEON_KEY);
        }
        return _origFetch.call(window, input, init).then(function(r) {
            if (r.status !== 401) return r;

            // A 401 does NOT prove the stored key is wrong — a request that
            // bypassed this wrapper, or a server still booting, produces the
            // same status. Retry ONCE with the key we already hold before
            // throwing it away. Discarding a valid key on the first 401 is
            // what made a correct key look permanently invalid.
            if (window.__LEON_KEY) {
                init.headers.set("Authorization", "Bearer " + window.__LEON_KEY);
                return _origFetch.call(window, input, init).then(function(r2) {
                    if (r2.status !== 401) return r2;
                    return _reprompt(input, init, r2);
                });
            }
            return _reprompt(input, init, r);
        });
    };

    function _reprompt(input, init, lastResponse) {
        if (!_prompting) {
            _prompting = new Promise(function(resolve) {
                // Defer so any sibling requests in flight settle first.
                setTimeout(function() {
                    var k = prompt("Leon API key rejected. Paste it again:");
                    if (k) {
                        localStorage.setItem("leon_key", k.trim());
                        window.__LEON_KEY = k.trim();
                    } else {
                        localStorage.removeItem("leon_key");
                        window.__LEON_KEY = "";
                    }
                    _prompting = null;
                    resolve(window.__LEON_KEY);
                }, 0);
            });
        }
        return _prompting.then(function(key) {
            if (!key) return lastResponse;
            init.headers.set("Authorization", "Bearer " + key);
            return _origFetch.call(window, input, init);
        });
    }

    window.wsURL = function(path) {
        var proto = location.protocol === "https:" ? "wss" : "ws";
        var sep = path.indexOf("?") >= 0 ? "&" : "?";
        return proto + "://" + location.host + path + sep + "key=" + encodeURIComponent(window.__LEON_KEY || "");
    };
})();
