/* Native account connection is separate from saved model choices and routing. */
class LeonClaudeConnection {
    constructor(panel) {
        this.panel = panel;
        this.state = {};
        this.busy = false;
        this.checking = false;
        this.nativeVerified = false;
        this.usage = null;
        this.row = document.createElement('section');
        this.row.id = 'cu-claude-connection';
        this.row.setAttribute('aria-label', 'Claude connection');
        this.row.style.cssText = 'padding:10px 0;border-bottom:1px solid #ffffff20;display:grid;gap:7px;min-width:0';
        this.row.innerHTML = `<style>#cu-claude-connection [hidden]{display:none!important}</style><div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center"><strong>Claude</strong><span data-host></span><button type="button" class="lg-btn" data-start disabled>Checking connection…</button><button type="button" class="lg-btn" data-cancel hidden>Cancel</button><button type="button" class="lg-btn" data-refresh>Refresh connection</button></div>
            <span role="status" aria-live="polite" data-status style="overflow-wrap:anywhere">Checking Claude connections…</span>
            <small data-bridge></small>
            <button type="button" class="lg-btn" data-open hidden>Open Claude sign-in</button>
            <form data-form hidden style="display:flex;flex-wrap:wrap;gap:6px"><label style="width:100%" for="cu-claude-code">Paste the code shown by Claude</label><input id="cu-claude-code" class="lg-field" type="password" autocomplete="off" spellcheck="false" maxlength="4096" style="flex:1;min-width:100px"/><button class="lg-btn" type="submit">Connect</button></form>
            <small data-explanation>Claude can run on a signed-in laptop through the bridge, or on the SI's own computer or VPS. These are separate connections; opening this dashboard on a phone does not move the SI.</small>
            <small>Connecting an account does not change saved models or route work to that computer.</small>`;
        panel.querySelector('#cu-model-routing').after(this.row);
        this.el = name => this.row.querySelector('[data-' + name + ']');
        this.el('start').onclick = () => this.start();
        this.el('cancel').onclick = () => this.action('cancel');
        this.el('refresh').onclick = () => this.refresh();
        this.el('open').onclick = () => this.openProvider();
        this.el('form').onsubmit = event => {
            event.preventDefault();
            const input = this.row.querySelector('input');
            const code = input.value.trim(); input.value = '';
            this.action('code', {code});
        };
        new MutationObserver(() => {if (!panel.hidden) this.refresh(); else clearTimeout(this.timer);}).observe(panel, {attributes:true, attributeFilter:['hidden']});
        window.addEventListener('pagehide', () => clearTimeout(this.timer));
    }
    validURL(value) {
        try {
            const url = new URL(value);
            return url.protocol === 'https:' && !url.username && !url.password && (!url.port || url.port === '443') &&
                ['claude.com/cai/oauth/authorize', 'claude.ai/oauth/authorize', 'platform.claude.com/oauth/authorize', 'console.anthropic.com/oauth/authorize'].includes(url.hostname + url.pathname) && url.searchParams.has('state') && url.searchParams.has('code_challenge');
        } catch { return false; }
    }
    openProvider() {
        if (!this.validURL(this.state.auth_url)) return;
        if (this.popup && !this.popup.closed) {
            this.popup.location.replace(this.state.auth_url); this.popup = null;
        } else {
            window.open(this.state.auth_url, '_blank', 'noopener,noreferrer');
        }
    }
    async start() {
        if (this.busy || this.checking || !this.nativeVerified) return;
        // Reserve a window during the click; the fallback remains when popups are blocked.
        this.popup = window.open('about:blank', '_blank');
        if (this.popup) {
            this.popup.opener = null;
            this.popup.document.head.innerHTML = '<meta name="referrer" content="no-referrer">';
            this.popup.document.body.textContent = 'Preparing Claude sign-in…';
        }
        this.autoOpen = true;
        await this.action('start');
    }
    async action(action, extra = {}) {
        if (this.busy || this.checking) return;
        this.error = '';
        this.busy = true; this.render();
        try {
            const response = await fetch('/api/provider/claude/connection/' + action, {
                method:'POST', headers:{'Content-Type':'application/json'},
                body:JSON.stringify({session_id:this.state.session_id, ...extra}), signal:AbortSignal.timeout(20000)});
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'Sign-in unavailable. Retry.');
            this.state = data;
            this.nativeVerified = typeof data.connected === 'boolean' && !data.status_error;
        } catch (error) {
            this.error = error.message;
            if (this.popup) {this.popup.close(); this.popup = null;}
        } finally {this.busy = false; this.render(); this.schedule();}
    }
    async refresh() {
        if (this.busy) return;
        if (this.checking) return this.refreshPromise;
        this.checking = true;
        this.render();
        this.refreshPromise = (async () => {
            const read = async path => {
                const response = await fetch(path, {cache:'no-store', signal:AbortSignal.timeout(16000)});
                const data = await response.json();
                if (!response.ok) throw new Error('Connection check unavailable. Refresh to retry.');
                return data;
            };
            const [native, usage] = await Promise.allSettled([
                read('/api/provider/claude/connection'), read('/api/claude/usage')
            ]);
            this.usage = usage.status === 'fulfilled' ? usage.value : null;
            this.nativeVerified = false;
            if (native.status === 'fulfilled') {
                this.state = native.value; this.error = '';
                this.nativeVerified = typeof this.state.connected === 'boolean' && !this.state.status_error;
                if (this.autoOpen && this.validURL(this.state.auth_url)) {this.openProvider(); this.autoOpen = false;}
            } else {
                this.error = 'Native account status unavailable. Refresh to retry.';
            }
            this.checking = false;
            this.render(); this.schedule();
        })();
        return this.refreshPromise;
    }
    schedule() {
        clearTimeout(this.timer);
        const visible = () => !this.panel.hidden || document.getElementById('settings-overlay')?.hidden === false;
        if (visible()) {
            this.timer = setTimeout(() => {if (visible()) this.refresh();}, ['starting','waiting','verifying'].includes(this.state.state) ? 2000 : 30000);
        }
    }
    bridgeConnected() {
        const age = Date.now() - Date.parse(this.usage?.fetchedAt);
        // A provider choice or a cached model list is not authentication evidence.
        return this.usage?.status === 'ok' && this.usage.source === 'laptop-bridge' && age >= 0 && age <= 90000;
    }
    host() {
        return this.state.target === 'Your server' ? 'VPS / server' :
            this.state.target === 'This computer' ? 'SI computer (local)' : 'SI host';
    }
    summary() {
        const native = this.nativeVerified ? (this.state.connected ? 'connected' : 'not connected') : 'status unverified';
        return `Claude on ${this.host()}: ${native}. ` + (this.bridgeConnected() ?
            'Laptop bridge: connected (authenticated check ' + new Date(this.usage.fetchedAt).toLocaleString() + '). No additional login is needed for that bridge connection.' :
            'Laptop bridge: connection unverified. An unavailable check does not mean the laptop is signed out.');
    }
    render() {
        const value = this.state;
        const pending = ['starting','waiting','verifying'].includes(value.state);
        const bridge = this.bridgeConnected(), host = this.host();
        const accountHost = value.target === 'Your server' ? 'VPS' : value.target === 'This computer' ? 'local' : 'native';
        this.el('host').textContent = host;
        this.el('start').hidden = pending;
        this.el('start').disabled = this.busy || this.checking || !this.nativeVerified;
        this.el('refresh').disabled = this.busy || this.checking;
        this.el('start').textContent = !this.nativeVerified ? (this.checking ? 'Checking connection…' : 'Native connection unavailable') :
            value.connected ? 'Switch ' + accountHost + ' account' : bridge ? 'Connect separate ' + accountHost + ' account' : 'Sign in on ' + host;
        this.el('cancel').hidden = !pending; this.el('cancel').disabled = this.busy || this.checking;
        this.el('open').hidden = !(pending && this.validURL(value.auth_url));
        this.el('form').hidden = !(value.state === 'waiting' && value.code_required);
        this.el('form').style.display = this.el('form').hidden ? 'none' : 'flex';
        this.el('form').querySelector('button').disabled = this.busy || this.checking;
        const labels = {starting:'Preparing official Claude sign-in…', waiting:'Waiting for you to approve in Claude. If the page did not open, use Open Claude sign-in.', verifying:'Verifying native account…', expired:'Sign-in expired. Retry when ready.', failed:'Sign-in failed. Your previous account is preserved.', cancelled:'Sign-in cancelled.', interrupted:'Sign-in interrupted. Retry when ready.'};
        this.el('status').textContent = this.checking ? 'Checking Claude connections…' : this.error || labels[value.state] ||
            (this.nativeVerified ? (value.connected ? 'Connected on ' + host + ': ' + (value.account || 'Claude account') : 'Not connected on ' + host) : value.status_error || 'Native account status unverified');
        this.el('bridge').textContent = bridge ? 'Laptop bridge: connected · checked ' + new Date(this.usage.fetchedAt).toLocaleString() + '. No additional login needed for this connection.' : 'Laptop bridge: connection unverified. This does not mean the laptop is signed out.';
        this.el('explanation').textContent = 'Laptop bridge: Claude runs on the signed-in laptop; the laptop and bridge must stay online. ' +
            'Native connection: Claude runs on the SI’s own ' + (value.target === 'Your server' ? 'VPS / server' : value.target === 'This computer' ? 'local computer' : 'computer or VPS') +
            ' with its own account. The dashboard device is separate. A native login does not switch the existing bridge route.';
        window.dispatchEvent(new CustomEvent('leon-claude-connection', {detail:this.summary()}));
        if (!pending && this.popup) {this.popup.close(); this.popup = null;}
    }
}
document.addEventListener('DOMContentLoaded', () => {
    const panel = document.getElementById('cu-model-panel');
    if (panel) window.leonClaudeConnection = new LeonClaudeConnection(panel);
});
