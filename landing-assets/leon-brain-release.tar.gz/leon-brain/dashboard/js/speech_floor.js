// Leon's speech floor for the dashboard (2026-10-04).
//
// Everything Leon says goes through ONE player (the reply audio queue in
// index.html). Unsolicited lines (coding-job notices, restart announcement,
// proactive messages) are "announcements": their text shows at once, but
// their voice is HELD here and only released once the room has been clear
// for QUIET_MS — Dean not listening on push-to-talk, no transcription in
// flight, no reply pending/streaming, and no reply audio playing. A direct
// reply always wins: when one starts, a playing announcement is stopped.
//
// Order (2026-10-05): Dean read "you look a little worn down" in the box,
// answered it, heard Leon's reply, and only THEN heard the worn-down line,
// because its voice was still held. A held line is voiced only while it is
// still the newest thing in the conversation: once a later line has been
// committed below it (Dean's own message, a reply), its voice is dropped and
// it stays as text where it was shown. opts.stale(entry, batch) answers that
// at release time. Held lines also leave strictly in arrival order: a line
// whose audio is still on its way holds back the ones behind it.
//
// Shown when spoken (2026-10-06): at 22:51 Dean saw "I've been up about 16
// hours straight" in the box but never heard it. Showing a held line at once
// and voicing it later is what let him read it, answer it, and so leave it
// unspoken. index.html now draws a held line's bubble when this floor
// releases it (play), or when it gives up on it (dropped): text and voice are
// committed at the same moment, in the same order. Every line that leaves
// without being played goes through opts.dropped, so none is lost unseen.
//
// Pure logic, no DOM: index.html supplies busy() and play()/stop(), and
// tests/test_speech_floor.py drives it under node with a fake clock.
(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.LeonSpeechFloor = factory();
}(typeof self !== 'undefined' ? self : this, function () {
    'use strict';
    const QUIET_MS = 2000;
    const AUDIO_WAIT_MS = 30000;   // audio promised but never completed: release anyway
    const MAX_HELD = 8;
    const END_WAIT_MS = 30000;     // started but never ended: give up on it

    function isAnnouncement(msg) {
        return !!(msg && (msg.announcement || msg.from_proactive || msg.from_spontaneous));
    }

    // opts.now() -> ms, opts.busy() -> reason string or falsy,
    // opts.play(entries) -> starts playback of released entries (in order),
    // opts.stop(entry)   -> stops a playing announcement.
    // opts.stale(entry, batch) -> true when a newer line is already in the box
    //                    below this one: its voice is dropped (text stays).
    // opts.dropped(entry, why) -> told about each held line not voiced.
    function create(opts) {
        const now = opts.now || (() => Date.now());
        const held = new Map();        // response_id -> entry (insertion ordered)
        const gone = new Set();        // ids voiced, dropped or cancelled (bounded)
        function retire(id) {
            gone.add(id);
            if (gone.size > 64) gone.delete(gone.values().next().value);
        }
        let clearSince = 0;
        let playing = null;            // entry currently being voiced
        let lastReason = null;

        function entry(id) { return held.get(id) || null; }

        function start(id, text) {
            if (held.size >= MAX_HELD) {
                const oldest = held.values().next().value;
                held.delete(oldest.id);
                retire(oldest.id);
                if (opts.dropped) opts.dropped(oldest, 'too many held');
            }
            const e = {id: id, text: text || '', clips: [], ended: false, endedAt: 0,
                       startedAt: now(), audioPending: false, audioDone: false,
                       cancelled: false, superseded: false};
            held.set(id, e);
            return e;
        }

        function ready(e, t) {
            if (!e.ended || e.cancelled) return false;
            if (!e.audioPending || e.audioDone) return true;
            return t - e.endedAt > AUDIO_WAIT_MS;
        }

        return {
            QUIET_MS: QUIET_MS,
            isAnnouncement: isAnnouncement,
            has: (id) => held.has(id) || !!(playing && playing.id === id),
            // An announcement this floor already voiced, dropped or cancelled:
            // a late frame for it must not be played as if it were a reply.
            retired: (id) => gone.has(id),
            get: (id) => entry(id) || (playing && playing.id === id ? playing : null),
            start: start,
            delta(id, chunk) { const e = entry(id); if (e) e.text += (chunk || ''); },
            end(id, finalText, audioPending) {
                const e = entry(id);
                if (!e) return;
                if (finalText) e.text = finalText;
                e.ended = true;
                e.endedAt = now();
                e.audioPending = !!audioPending;
            },
            // A finished line with no server audio at all: play() gets no clips
            // for it, and the dashboard leaves it as text (never a browser voice).
            textOnly(id, text) {
                const e = start(id, text);
                e.ended = true;
                e.endedAt = now();
                return e;
            },
            audio(id, clip) {
                const e = entry(id);
                if (!e || e.cancelled || !clip) return;
                // The same frame twice is one clip, never voiced twice.
                const len = String(clip.audio_b64 || '').length;
                if (e.clips.some((c) => c.sentence_index === clip.sentence_index &&
                                        String(c.audio_b64 || '').length === len)) return;
                e.clips.push(clip);
            },
            audioComplete(id) { const e = entry(id); if (e) e.audioDone = true; },
            cancel(id) {
                const e = entry(id);
                if (e) { e.cancelled = true; held.delete(id); }
                retire(id);
                if (e && opts.dropped) opts.dropped(e, 'cancelled');
                if (playing && playing.id === id) {
                    const p = playing; playing = null;
                    if (opts.stop) opts.stop(p);
                }
            },
            // A direct reply began: it owns the voice. Stop the announcement
            // that is playing (if any) and restart the quiet clock.
            replyStarted() {
                clearSince = 0;
                if (playing) {
                    const p = playing; playing = null;
                    if (opts.stop) opts.stop(p);
                    return p;
                }
                return null;
            },
            playbackFinished(id) { if (playing && (id === undefined || playing.id === id)) playing = null; },
            playingId: () => (playing ? playing.id : null),
            pending: () => Array.from(held.values()).filter((e) => !e.cancelled).map((e) => e.id),
            holdingFor: () => lastReason,
            // One scheduling step; call every ~250 ms. Returns the entries it
            // released (possibly several, voiced back to back) or [].
            tick() {
                const t = now();
                if (playing) { clearSince = 0; return []; }
                const reason = opts.busy ? opts.busy() : null;
                lastReason = reason || null;
                if (reason) { clearSince = 0; return []; }
                // The ready lines at the front, in arrival order. One still
                // waiting for its audio keeps the later ones behind it, so
                // nothing is ever voiced ahead of a line shown above it.
                const due = [];
                for (const e of Array.from(held.values())) {
                    if (e.cancelled) continue;
                    if (!e.ended && t - e.startedAt > END_WAIT_MS) {
                        held.delete(e.id);
                        retire(e.id);
                        if (opts.dropped) opts.dropped(e, 'never finished');
                        continue;
                    }
                    if (!ready(e, t)) break;
                    due.push(e);
                }
                if (!due.length) { clearSince = 0; return []; }
                if (!clearSince) { clearSince = t; return []; }
                if (t - clearSince < QUIET_MS) return [];
                for (const e of due) { held.delete(e.id); retire(e.id); }
                clearSince = 0;
                // A newer line already sits below it: voicing it now would put
                // the speakers behind the box. It stays text, unspoken.
                const voiced = due.filter((e) => {
                    let stale = false;
                    try { stale = !!(opts.stale && opts.stale(e, due)); } catch (err) { stale = false; }
                    if (stale) {
                        e.superseded = true;
                        if (opts.dropped) opts.dropped(e, 'superseded');
                    }
                    return !stale;
                });
                if (!voiced.length) return [];
                playing = voiced[voiced.length - 1];
                if (opts.play) opts.play(voiced);
                return voiced;
            },
        };
    }

    return {create: create, isAnnouncement: isAnnouncement, QUIET_MS: QUIET_MS};
}));
