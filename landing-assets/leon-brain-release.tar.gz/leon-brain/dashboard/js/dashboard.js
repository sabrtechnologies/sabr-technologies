export class Dashboard {
    constructor() {
        this._processing = false;
    }

    // Look up elements fresh every tick — DON'T cache in constructor.
    // The neural readouts live inside #brain-info-popover; if the popover
    // is added/removed/replaced in the DOM (or if it's added after this
    // constructor runs in some load order), cached refs would become
    // stale and silently stop updating. Re-querying each tick is cheap
    // and guarantees the visible DOM node always gets the latest value.
    updateState(state) {
        if (!state) return;
        const set = (id, val) => {
            const el = document.getElementById(id);
            if (el) el.textContent = val;
        };

        set('rate-val',  (state.steps_per_second || 0).toFixed(0));
        set('m-stage',   state.development_stage || '—');
        set('m-neurons', this._fmtExact(state.total_neurons));
        set('m-synapses', this._fmtExact(state.total_synapses));
        set('m-steps',   this._fmtExact(state.step));

        const leon = state.leon;
        if (leon) {
            const calls = leon.call_count || 0;
            const lastAgo = leon.last_call_ago;
            const last = lastAgo == null ? null : (lastAgo < 5 ? 'just now' : `${this._shortDur(lastAgo)} ago`);
            const parts = [`${calls} call${calls!==1?'s':''}`];
            if (last) parts.push(last);
            set('claude-status-meta', parts.join(' · '));

            if (!this._processing && leon.is_processing) this.setProcessing(true);
        }
    }

    setProcessing(active) {
        this._processing = active;
        const dot = document.getElementById('claude-dot');
        if (dot) {
            dot.classList.toggle('processing', active);
            dot.classList.toggle('idle', !active);
        }
        const status = document.getElementById('claude-status-text');
        if (status) {
            status.textContent = active ? 'processing' : 'idle';
            status.classList.toggle('processing', active);
        }
    }

    _fmtExact(n) {
        if (n === undefined || n === null) return '—';
        return Number(n).toLocaleString('en-US');
    }

    _shortDur(sec) {
        if (sec < 60) return `${sec}s`;
        if (sec < 3600) return `${Math.floor(sec/60)}m`;
        return `${Math.floor(sec/3600)}h`;
    }
}
