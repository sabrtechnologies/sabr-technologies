/* Conversation links operate on formatted text nodes, never message HTML. */
(function () {
    'use strict';
    const token = /"[^"\n]+"|'[^'\n]+'|file:\/\/\/[^\s<>"'`]+|https?:\/\/[^\s<>"'`]+|[A-Za-z]:[\\/][^\s<>"'`]+|(?:~[\\/]|\.?\.?[\\/]|\/)[^\s<>"'`]+|[A-Za-z0-9_-]+(?:[\\/][A-Za-z0-9_.-]+)+[\\/]?|[A-Za-z0-9_-]+\.(?:md|txt|pdf|csv|json|html|png|jpg|jpeg|docx|xlsx)\b/gi;

    function trimEnd(value) {
        value = value.replace(/[.,;:!?]+$/, '');
        for (const [close, open] of [[')', '('], [']', '['], ['}', '{']]) {
            while (value.endsWith(close) && value.split(close).length > value.split(open).length) {
                value = value.slice(0, -1);
            }
        }
        return value;
    }

    function classify(value) {
        if (/^file:\/\/\//i.test(value)) {
            // Browsers block file:// from this http page, so a file URL opens
            // through the laptop like a plain path (same server-side checks).
            let path;
            try { path = decodeURIComponent(value.slice(8)); } catch { return null; }
            return /^[A-Za-z]:[\\/]/.test(path) ? {kind: 'path', scope: 'laptop', path} : null;
        }
        if (/^https?:\/\//i.test(value)) {
            try {
                const url = new URL(value);
                if (url.username || url.password || !url.hostname) return null;
                return {kind: 'url', href: url.href};
            } catch { return null; }
        }
        if (/^[A-Za-z]:[\\/]/.test(value) || /^~[\\/]/.test(value)) {
            return {kind: 'path', scope: 'laptop'};
        }
        if (/^\/(?!\/)[A-Za-z0-9_.-]+(?:\/[^<>\x00-\x1f]*)?$/.test(value)) {
            return {kind: 'path', scope: 'vps'};
        }
        // A slash-delimited relative path or a small set of document extensions.
        if (/^(?:\.?\.?[\\/])?[A-Za-z0-9_-]+(?:[\\/][A-Za-z0-9_ .()-]+)+[\\/]?$/.test(value) ||
            /^[A-Za-z0-9_-]+\.(?:md|txt|pdf|csv|json|html|png|jpg|jpeg|docx|xlsx)$/i.test(value)) {
            return {kind: 'path', scope: 'laptop'};
        }
        return null;
    }

    function linkify(root) {
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                return node.parentElement && node.parentElement.closest('a, pre, code, script, style, textarea, button')
                    ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
            }
        });
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        for (const node of nodes) {
            const text = node.data;
            const fragment = document.createDocumentFragment();
            let cursor = 0;
            token.lastIndex = 0;
            for (const match of text.matchAll(token)) {
                let start = match.index;
                // Do not link substrings of unsafe schemes, identifiers or UNC paths.
                if (start && /[\w./:@\\]/.test(text[start - 1])) continue;
                const quoted = /^["']/.test(match[0]);
                const value = quoted ? match[0].slice(1, -1) : trimEnd(match[0]);
                // "</script>" or "</div>" quoted in a message is a tag name, not a VPS path.
                if (!quoted && start && text[start - 1] === '<' && /^\/[A-Za-z][\w-]*$/.test(value)) continue;
                const type = classify(value);
                if (!type) continue;
                if (quoted) start++;
                fragment.append(document.createTextNode(text.slice(cursor, start)));
                const anchor = document.createElement('a');
                anchor.className = 'conv-link';
                anchor.textContent = value;
                if (type.kind === 'url') {
                    anchor.href = type.href;
                    anchor.target = '_blank';
                    anchor.rel = 'noopener noreferrer';
                } else {
                    anchor.href = '#';
                    anchor.dataset.convPath = type.path || value;
                    anchor.dataset.scope = type.scope;
                    anchor.title = type.scope === 'vps' ? 'VPS: private read-only preview' : 'Open on Windows laptop (relative to home)';
                    anchor.setAttribute('aria-label', value + ' — ' + anchor.title);
                    if (type.scope === 'vps') anchor.classList.add('conv-vps-link');
                }
                fragment.append(anchor);
                cursor = start + value.length;
            }
            if (cursor) {
                fragment.append(document.createTextNode(text.slice(cursor)));
                node.replaceWith(fragment);
            }
        }
        return root;
    }

    function showResult(title, text) {
        let dialog = document.getElementById('conv-path-preview');
        if (!dialog) {
            dialog = document.createElement('dialog');
            dialog.id = 'conv-path-preview';
            const heading = document.createElement('h3');
            const body = document.createElement('pre');
            const close = document.createElement('button');
            close.textContent = 'Close';
            close.addEventListener('click', () => dialog.close());
            dialog.append(heading, body, close);
            document.body.append(dialog);
        }
        dialog.querySelector('h3').textContent = title;
        dialog.querySelector('pre').textContent = text;
        if (!dialog.open) dialog.showModal();
    }

    document.addEventListener('click', async event => {
        const anchor = event.target.closest('a[data-conv-path]');
        if (!anchor) return;
        event.preventDefault();
        if (anchor.dataset.pending) return;
        anchor.dataset.pending = '1';
        try {
            const response = await fetch('/api/open_path', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({path: anchor.dataset.convPath, scope: anchor.dataset.scope}),
                signal: AbortSignal.timeout(20000)
            });
            const result = await response.json();
            if (!response.ok || !result.ok) throw new Error(result.error || 'Path could not be opened');
            if (result.scope === 'vps') {
                showResult('VPS · ' + result.path, result.text + (result.truncated ? '\n\n[Preview truncated]' : ''));
            } else {
                showResult(result.revealed ? 'Selected on Windows laptop' : 'Opened on Windows laptop', result.path);
            }
        } catch (error) {
            showResult('Could not open path', error.message);
        } finally { delete anchor.dataset.pending; }
    });
    window.ConversationLinks = {linkify};

    function observe() {
        const root = document.getElementById('conv-body');
        if (!root) return;
        const observer = new MutationObserver(() => {
            observer.disconnect();
            linkify(root);
            observer.observe(root, {childList: true, subtree: true, characterData: true});
        });
        linkify(root);
        observer.observe(root, {childList: true, subtree: true, characterData: true});
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', observe);
    else observe();
})();
