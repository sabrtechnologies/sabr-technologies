/* Local model: configured under Models → Conversation → Provider → Local, usage shown on the card's Local view.
   Routing is NOT decided here: model-preferences.js turns Local on/off through setEnabled() when the owner saves.
   This file owns the Local section (source, key, model, download catalog) and publishes its state through
   window.leonLocalModel plus the 'leon-local-ai' window event. Every DOM write comes from cached state; nothing
   observes the DOM (the 10-20 render loop came from observers re-triggering fetches). */
(() => {
    const $ = id => document.getElementById(id);
    const SOURCES = [
        {value: 'laptop', label: 'Laptop (LM Studio)', detail: 'Private · the laptop must be on with a model loaded'},
        {value: 'ollama', label: 'Ollama (this computer)', detail: 'Runs where the SI runs · download models here'},
        {value: 'hosted', label: 'Hosted API (paid backup)', detail: 'Needs an API key · spend is tracked'},
    ];
    const sourceLabel = value => (SOURCES.find(s => s.value === value) || {}).label || value || 'Local';
    async function call(path, payload) {
        const r = await fetch(path, {signal: AbortSignal.timeout(15000), ...(payload === undefined ? {} :
            {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)})});
        let d; try { d = await r.json(); } catch { throw new Error('Invalid server response'); }
        if (!r.ok || d.ok === false) throw new Error(d.error || d.detail || ('HTTP ' + r.status));
        return d;
    }
    const setText = (el, text) => { if (el && el.textContent !== text) el.textContent = text; };

    // ---- state ----
    let saved = null;            // /api/local_ai/settings: {enabled, endpoint, model, base_url, hosted_key_set}
    let models = [];             // model ids reachable on the selected source
    let modelsError = '';        // why the list is empty, in plain words
    let usage = null, lastUsageFetch = 0, usageBusy = false;
    let ollama = null;           // /api/local_ai/ollama: {reachable, url, models, catalog, pulls}
    let pullTimer = null, lookupBusy = false;
    let combos = null, loading = null;

    function state() {
        return {ready: !!saved, settings: saved, models: [...models], modelsError, usage, ollama};
    }
    function announce() { window.dispatchEvent(new CustomEvent('leon-local-ai', {detail: state()})); }
    const status = text => setText($('cu-local-status'), text);

    // ---- Models panel: source, key, model ----
    function keyRows(endpoint) {
        const hosted = endpoint === 'hosted';
        $('cu-local-key-row').hidden = !hosted; $('cu-local-key-actions').hidden = !hosted;
        setText($('cu-local-key-state'), saved && saved.hosted_key_set ? 'Key saved' : 'No key yet');
    }
    function paintFields() {
        if (!combos || !saved) return;
        combos.endpoint.setOptions(SOURCES, saved.endpoint || 'laptop');
        const items = models.map(id => ({value: id, label: id}));
        if (saved.model && !models.includes(saved.model)) items.unshift({value: saved.model, label: saved.model, detail: 'Saved, but not connected right now', disabled: true});
        if (!items.length) items.push({value: '', label: 'No model connected', disabled: true});
        combos.model.setOptions(items, saved.model || '');
        $('cu-local-model').disabled = !models.length;
        keyRows(saved.endpoint);
    }
    async function load() {
        if (loading) return loading;
        loading = (async () => {
            try { saved = await call('/api/local_ai/settings'); }
            catch (e) { status('Local settings unavailable: ' + e.message); loading = null; return; }
            paintFields(); announce(); fetchUsage(true);
            await refresh();
            loading = null;
        })();
        return loading;
    }
    async function refresh() {
        if (!saved) return;
        const endpoint = saved.endpoint;
        status('Checking ' + sourceLabel(endpoint) + '…');
        models = []; modelsError = '';
        try {
            models = ((await call('/api/local_ai/models?endpoint=' + endpoint)).models || []).filter(id => !/embed/i.test(id));
        } catch (e) { modelsError = e.message; }
        if (saved.endpoint !== endpoint) return;            // the owner switched source meanwhile
        if (models.length && (!saved.model || !models.includes(saved.model))) {
            // the saved model is gone: keep the saved value only if it exists; otherwise take the first connected one
            try { saved = {...saved, ...(await call('/api/local_ai/settings', {model: models[0]}))}; } catch { /* keep */ }
        }
        if (models.length) status(models.length + ' model' + (models.length === 1 ? '' : 's') + ' connected on ' + sourceLabel(endpoint) + '.');
        else if (endpoint === 'hosted') status('Hosted API: ' + (modelsError || 'no models listed') + '.');
        else status('No local model is connected on ' + sourceLabel(endpoint) + (modelsError ? ': ' + modelsError : '') + '.');
        paintFields();
        await paintCatalog();
        announce();
    }
    async function write(payload) {
        saved = {...saved, ...(await call('/api/local_ai/settings', payload))};
        usage = null; paintFields(); announce(); fetchUsage(true);
        return saved;
    }
    async function setEnabled(enabled) {
        if (!saved) await load();
        if (enabled && !saved.model) throw new Error('Pick a local model first.');
        if (enabled && !models.includes(saved.model)) throw new Error('No local model is connected on ' + sourceLabel(saved.endpoint) + '; connect or download one first.');
        return write({enabled: !!enabled});
    }

    // ---- No model connected: say so, then offer models to download (Ollama) ----
    function pullRow(name, pull) {
        const done = pull.done, pct = pull.total ? Math.round(100 * pull.completed / pull.total) : null;
        const gb = n => (n / 1e9).toFixed(1) + ' GB';
        return '<div class="cu-row"><div class="cu-row-top"><span class="cu-row-label">' + name + '</span><span class="cu-row-pct">' +
            (done ? (pull.error ? 'failed' : 'installed') : (pct === null ? pull.status : pct + '%')) + '</span></div>' +
            (done ? '' : '<div class="cu-bar-track"><div class="cu-bar-fill" style="width:' + (pct || 0) + '%"></div></div>') +
            '<div class="cu-row-reset">' + (pull.error ? pull.error : done ? 'Ready to use.' : pull.total ? gb(pull.completed) + ' of ' + gb(pull.total) : pull.status) + '</div></div>';
    }
    async function paintCatalog() {
        const box = $('cu-local-catalog'), intro = $('cu-local-catalog-intro'), list = $('cu-local-catalog-list');
        const useOllama = $('cu-local-use-ollama');
        const showCatalog = saved && saved.endpoint !== 'hosted' && !models.length;
        useOllama.hidden = !(showCatalog && saved.endpoint === 'laptop');
        box.hidden = !showCatalog;
        if (!showCatalog) { stopPullPolling(); return; }
        if (saved.endpoint === 'laptop') {
            intro.textContent = 'Start LM Studio on the laptop and load a model, then Refresh models. Or use Ollama on this computer and download a model here.';
            list.replaceChildren(); $('cu-local-lookup').hidden = true; $('cu-local-pull').hidden = true;
            return;
        }
        try { ollama = await call('/api/local_ai/ollama'); } catch (e) { ollama = {reachable: false, url: '', models: [], catalog: [], pulls: {}, error: e.message}; }
        if (!ollama.reachable) {
            intro.textContent = (ollama.error || 'Ollama is not running on this computer.') + ' Install it from ollama.com or start it, then Refresh models.';
            list.replaceChildren(); $('cu-local-lookup').hidden = true; $('cu-local-pull').hidden = true;
            return;
        }
        intro.textContent = 'Pick a model to download into Ollama, or look one up by name. Sizes are approximate; the model is ready when the download finishes.';
        $('cu-local-lookup').hidden = false;
        list.replaceChildren(...(ollama.catalog || []).map(entry => {
            const row = document.createElement('div'); row.className = 'cu-local-row'; row.setAttribute('role', 'listitem');
            const text = document.createElement('div');
            const name = document.createElement('strong'); name.textContent = entry.name;
            const note = document.createElement('small'); note.textContent = '~' + entry.size_gb + ' GB · ' + entry.note;
            text.append(name, note);
            const button = document.createElement('button'); button.type = 'button'; button.className = 'lg-btn';
            const pull = (ollama.pulls || {})[entry.name];
            button.textContent = entry.installed ? 'Installed' : pull && !pull.done ? 'Downloading…' : 'Download';
            button.disabled = entry.installed || (pull && !pull.done) || !!activePull();
            button.addEventListener('click', () => startPull(entry.name));
            row.append(text, button);
            return row;
        }));
        paintPulls();
    }
    function activePull() { return Object.entries((ollama && ollama.pulls) || {}).find(([, p]) => !p.done)?.[0] || null; }
    function paintPulls() {
        const el = $('cu-local-pull'), pulls = (ollama && ollama.pulls) || {};
        const names = Object.keys(pulls);
        el.hidden = !names.length;
        el.innerHTML = names.map(name => pullRow(name, pulls[name])).join('');
        if (activePull()) startPullPolling(); else stopPullPolling();
    }
    function startPullPolling() {
        if (pullTimer) return;
        pullTimer = setInterval(async () => {
            try { ollama = await call('/api/local_ai/ollama'); } catch { return; }
            const active = activePull();
            paintPulls();
            if (!active) {                       // finished: the new model is connected now; select it
                stopPullPolling();
                const finished = Object.entries(ollama.pulls).find(([, p]) => p.done && !p.error)?.[0];
                await refresh();
                if (finished && models.includes(finished)) { try { await write({model: finished}); } catch { /* status shows it */ } }
            }
        }, 2000);
    }
    function stopPullPolling() { if (pullTimer) { clearInterval(pullTimer); pullTimer = null; } }
    async function startPull(name) {
        setText($('cu-local-lookup-result'), '');
        try {
            const result = await call('/api/local_ai/ollama/pull', {name});
            ollama = {...(ollama || {}), pulls: {...((ollama && ollama.pulls) || {}), [name]: result.pull}};
            status('Downloading ' + name + ' into Ollama…');
            await paintCatalog();
        } catch (e) { setText($('cu-local-lookup-result'), 'Download not started: ' + e.message); }
    }
    async function lookup(event) {
        event.preventDefault();
        if (lookupBusy) return;
        const name = $('cu-local-lookup-name').value.trim(), out = $('cu-local-lookup-result');
        if (!name) { setText(out, 'Type a model name first, for example llama3.2:3b.'); return; }
        lookupBusy = true; setText(out, 'Looking up ' + name + '…');
        try {
            const r = await call('/api/local_ai/ollama/lookup?name=' + encodeURIComponent(name));
            out.replaceChildren();
            if (!r.found) { out.textContent = r.tag ? 'No tag "' + r.tag + '" for ' + r.name + '. Tags: ' + (r.tags.slice(0, 12).join(', ') || 'none') + '.' : 'No model named ' + r.name + ' in the Ollama library.'; return; }
            if (r.tag) {
                out.append(name + (r.size_gb ? ' · ~' + r.size_gb + ' GB' : '') + ' ');
                const button = document.createElement('button'); button.type = 'button'; button.className = 'lg-btn'; button.textContent = 'Download ' + name;
                button.disabled = !!activePull(); button.addEventListener('click', () => startPull(name)); out.append(button);
            } else {
                out.append(r.name + ' exists. Pick a tag: ');
                r.tags.slice(0, 10).forEach(tag => {
                    const button = document.createElement('button'); button.type = 'button'; button.className = 'lg-btn cu-local-tag'; button.textContent = tag;
                    button.addEventListener('click', () => { $('cu-local-lookup-name').value = r.name + ':' + tag; $('cu-local-lookup').requestSubmit(); });
                    out.append(button);
                });
            }
        } catch (e) { setText(out, 'Lookup failed: ' + e.message); }
        finally { lookupBusy = false; }
    }

    // ---- Usage card (Local view) ----
    async function fetchUsage(force) {
        if (!saved || usageBusy) return;
        const now = Date.now();
        if (!force && now - lastUsageFetch < 15000) return;
        if (force && now - lastUsageFetch < 2000) return;
        usageBusy = true; lastUsageFetch = now;
        try { usage = await call('/api/local_ai/usage'); announce(); } catch { /* keep the cached card */ }
        usageBusy = false;
    }
    function renderUsage(quotasEl, planEl) {
        if (!saved) return false;
        const source = sourceLabel(saved.endpoint), model = saved.model || 'no model selected';
        const connected = models.includes(saved.model);
        const routing = saved.enabled ? 'Answers conversation now.' : 'Not answering conversation; switch Provider to Local under Models.';
        if (saved.endpoint !== 'hosted') {
            planEl.textContent = 'free';
            quotasEl.innerHTML = '<div class="cu-row"><div class="cu-row-top"><span class="cu-row-label">' + source + '</span><span class="cu-row-pct">' + (connected ? 'connected' : 'offline') + '</span></div>' +
                '<div class="cu-row-reset">' + model + ' · no usage limits</div><div class="cu-row-reset">' + routing + '</div></div>';
            return true;
        }
        if (!usage || usage.endpoint !== 'hosted') {
            planEl.textContent = '—';
            quotasEl.innerHTML = '<div class="cu-row-empty">hosted balance loading</div>';
        } else if (usage.error) {
            planEl.textContent = '—';
            quotasEl.innerHTML = '<div class="cu-row-empty">' + usage.error + '</div>';
        } else {
            planEl.textContent = 'credit';
            quotasEl.innerHTML = '<div class="cu-row"><div class="cu-row-top"><span class="cu-row-label">Credit left</span><span class="cu-row-pct">$' + Number(usage.balance_usd).toFixed(2) + '</span></div><div class="cu-row-reset">Spent today $' + Number(usage.spent_today_usd).toFixed(3) + ' · ' + model + '</div><div class="cu-row-reset">' + routing + '</div></div>';
        }
        return true;
    }

    window.leonLocalModel = {state, sourceLabel, load, refresh, setEnabled, refreshUsage: fetchUsage, renderUsage};

    function init() {
        if (!$('cu-local') || typeof LeonGlassCombobox !== 'function') return;
        combos = {endpoint: new LeonGlassCombobox($('cu-local-endpoint')), model: new LeonGlassCombobox($('cu-local-model'))};
        $('cu-local-endpoint').addEventListener('change', async e => {
            try { await write({endpoint: e.target.value}); } catch (err) { status(err.message); return; }
            await refresh();
        });
        $('cu-local-model').addEventListener('change', async e => { try { await write({model: e.target.value}); } catch (err) { status(err.message); } });
        $('cu-local-refresh').addEventListener('click', () => refresh());
        $('cu-local-use-ollama').addEventListener('click', async () => {
            try { await write({endpoint: 'ollama'}); } catch (err) { status(err.message); return; }
            await refresh();
        });
        $('cu-local-lookup').addEventListener('submit', lookup);
        $('cu-local-key-save').addEventListener('click', async () => {
            const field = $('cu-local-key'), key = field.value.trim();
            if (!key) { status('Paste the key first.'); return; }
            try { await call('/api/local_ai/key', {key}); field.value = ''; saved.hosted_key_set = true; keyRows('hosted'); await refresh(); }
            catch (e) { status('Key not saved: ' + e.message); }
        });
        const mb = $('cu-model-button'); if (mb) mb.addEventListener('click', () => { if (!$('cu-model-panel').hidden) refresh(); });
        setInterval(() => fetchUsage(false), 60000);
        load();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
