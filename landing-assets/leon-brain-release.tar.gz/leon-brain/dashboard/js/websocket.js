/**
 * BrainWebSocket - Manages WebSocket connection to the Leon brain server.
 */
export class BrainWebSocket {
    constructor(url) {
        // `url` may be a STRING or a FUNCTION returning one.
        //
        // 2026-09-05: it used to be a plain string, resolved ONCE by the
        // caller as window.wsURL('/ws') at page-construction time. wsURL
        // bakes in `key=` + (window.__LEON_KEY || ""), so if the socket was
        // built before the key resolved, the URL froze as `/ws?key=` — empty
        // — and connect() reused that exact frozen string on EVERY reconnect,
        // forever. The server answered 403 every time and the page could
        // never recover without a full reload. Measured on Dean's box: a
        // steady drip of `WebSocket /ws?key=` 403s while all his HTTP calls
        // were authenticating fine, because HTTP reads the key per-request
        // and only the socket had it frozen.
        //
        // Passing a function makes the URL resolve per-connect. Strings still
        // work, and _resolveUrl() additionally re-stamps a stale/empty key
        // into them, so callers that were never updated also heal.
        this._urlSource = url;
        // Guarded: a resolver that throws during construction would take the
        // whole page's init down, which is strictly worse than the frozen-URL
        // bug this change exists to fix. connect() re-resolves anyway.
        this.url = '';
        try {
            this.url = (typeof url === 'function') ? url() : url;
        } catch (e) {
            console.error('[WS] URL resolver threw during construction:', e);
        }
        this.ws = null;
        this.reconnectDelay = 1000;
        this.maxReconnectDelay = 10000;
        this.onInit = null;    // callback(positions)
        this.onState = null;   // callback(state)
        this.onDisconnect = null;
        // Two-message binary init: server sends init_meta JSON first,
        // then a single ArrayBuffer with packed Float32 LE positions.
        this._pendingInitMeta = null;
        // Reconnect guards. Without these, every close/error path scheduled
        // its OWN timer, each timer called connect(), and the previous
        // socket's handlers were never detached — so one page ended up with
        // N live sockets all wired to the same callbacks. Every server event
        // (including brain_response_start, which paints Dean's own bubble)
        // got rendered N times. That was the duplicate-message bug.
        this._reconnectTimer = null;
        this._closed = false;
    }

    /** Resolve the socket URL fresh for THIS connect attempt. */
    _resolveUrl() {
        let u;
        try {
            u = (typeof this._urlSource === 'function') ? this._urlSource() : this._urlSource;
        } catch (e) {
            u = this.url;
        }
        if (typeof u !== 'string' || !u) return this.url;
        // Re-stamp the key even for string sources: the whole failure mode is
        // a URL that captured an empty key before auth finished. If a key is
        // available now, use it. If it is still empty, leave the URL alone
        // rather than inventing one — a 403 is honest, a silent wrong key is not.
        try {
            const live = (typeof window !== 'undefined' && window.__LEON_KEY) || '';
            if (live) {
                u = u.replace(/([?&]key=)[^&]*/, '$1' + encodeURIComponent(live));
            }
        } catch (e) { /* non-browser context — leave as-is */ }
        return u;
    }

    connect() {
        // Kill any prior socket completely before opening a new one.
        if (this.ws) {
            try {
                this.ws.onopen = null;
                this.ws.onmessage = null;
                this.ws.onclose = null;
                this.ws.onerror = null;
                if (this.ws.readyState === WebSocket.OPEN ||
                    this.ws.readyState === WebSocket.CONNECTING) {
                    this.ws.close();
                }
            } catch (e) { /* already dead */ }
            this.ws = null;
        }
        if (this._reconnectTimer) {
            clearTimeout(this._reconnectTimer);
            this._reconnectTimer = null;
        }
        try {
            this.url = this._resolveUrl();
            this.ws = new WebSocket(this.url);
            // Binary init payload (neuron positions) arrives as a Float32
            // blob — request raw ArrayBuffer so we can build a typed
            // array view with zero copies.
            this.ws.binaryType = 'arraybuffer';
        } catch (e) {
            console.error('[WS] Failed to create WebSocket:', e);
            this._scheduleReconnect();
            return;
        }

        this.ws.onopen = () => {
            console.log('[WS] Connected');
            this.reconnectDelay = 1000;
            this._pendingInitMeta = null;  // fresh handshake each connect
            // Anything that needs to re-announce client state on
            // (re)connect can hook in here. Critical for the webcam:
            // each new WS connection has its own id() server-side, so
            // the dashboard MUST re-tell it whether the cam is ready.
            if (this.onConnected) {
                try { this.onConnected(); } catch (e) { console.error('[WS] onConnected hook error:', e); }
            }
        };

        this.ws.onmessage = (event) => {
            // Binary frame → either the init positions blob (if meta
            // already arrived) or unexpected — warn and ignore.
            if (event.data instanceof ArrayBuffer) {
                this._handleBinaryFrame(event.data);
                return;
            }
            try {
                const msg = JSON.parse(event.data);
                if (msg.type === 'init_meta') {
                    // Two-message binary init: stash meta, wait for blob.
                    this._pendingInitMeta = msg;
                } else if (msg.type === 'init' && this.onInit) {
                    // Legacy JSON init (fallback path / older servers).
                    this.onInit(msg.positions);
                } else if (msg.type === 'state' && this.onState) {
                    this.onState(msg.data);
                } else if (msg.type === 'brain_response' && this.onResponse) {
                    // Legacy non-streaming path
                    this.onResponse(msg.user, msg.response, msg);
                } else if (msg.type === 'brain_response_start' && this.onResponseStart) {
                    this.onResponseStart(msg.user, msg.response_id, msg);
                    // Phase 6 — fire a custom event when this is a spontaneous
                    // thought so the Cognition Monitor can flash its indicator.
                    if (msg.from_spontaneous) {
                        window.dispatchEvent(new CustomEvent('leon-spontaneous-thought', {
                            detail: { response_id: msg.response_id, memory_id: msg.memory_id },
                        }));
                    }
                } else if (msg.type === 'brain_response_model' && this.onResponseModel) {
                    this.onResponseModel(msg.response_id, msg.model, msg.tier);
                } else if (msg.type === 'brain_response_delta' && this.onResponseDelta) {
                    this.onResponseDelta(msg.response_id, msg.text);
                } else if (msg.type === 'brain_response_end' && this.onResponseEnd) {
                    this.onResponseEnd(msg.response_id, msg.response);
                } else if (msg.type === 'brain_tool_use' && this.onToolUse) {
                    this.onToolUse(msg.response_id, msg.tool, msg.input, msg.tool_id, msg.risk);
                } else if (msg.type === 'brain_tool_result' && this.onToolResult) {
                    this.onToolResult(msg.response_id, msg.tool, msg.summary, msg.tool_id);
                } else if (msg.type === 'brain_tool_confirm_request' && this.onToolConfirmRequest) {
                    this.onToolConfirmRequest(msg.confirm_id, msg.tool, msg.input, msg.risk);
                } else if (msg.type === 'brain_response_text' && this.onProactiveText) {
                    this.onProactiveText(msg.text, msg.source);
                } else if (msg.type === 'brain_audio' && this.onAudio) {
                    this.onAudio(msg);
                } else if (msg.type === 'mic_toggle' && this.onMicToggle) {
                    // Wheel-click push-to-talk, relayed from the PC. Arrives
                    // over the socket precisely BECAUSE a socket needs no
                    // window focus — the OS remap sends its synthetic Space
                    // to whatever is focused, which often isn't us.
                    this.onMicToggle(msg);
                } else if (msg.type === 'wake_listening' && this.onWakeListening) {
                    this.onWakeListening(!!msg.listening);
                } else if (msg.type === 'wake_triggered' && this.onWakeTriggered) {
                    this.onWakeTriggered(msg.wake_word, msg.score);
                } else if (msg.type === 'wake_transcribed' && this.onWakeTranscribed) {
                    this.onWakeTranscribed(msg.transcript || '', !!msg.rejected);
                } else if (msg.type === 'webcam_capture_request' && this.onWebcamCaptureRequest) {
                    this.onWebcamCaptureRequest(msg.request_id);
                } else if (msg.type === 'presence_event' && this.onPresenceEvent) {
                    this.onPresenceEvent(msg.event);
                } else if (msg.type === 'presence_status' && this.onPresenceStatus) {
                    this.onPresenceStatus(msg.status);
                } else if (msg.type === 'activity_status' && this.onActivityStatus) {
                    this.onActivityStatus(msg.activity);
                }
            } catch (e) {
                console.error('[WS] Parse error:', e);
            }
        };

        const _thisSock = this.ws;
        this.ws.onclose = () => {
            if (this.ws !== _thisSock) return;  // stale socket, ignore
            console.log('[WS] Disconnected');
            if (this.onDisconnect) this.onDisconnect();
            this._scheduleReconnect();
        };

        this.ws.onerror = (e) => {
            console.error('[WS] Error:', e);
        };
    }

    _scheduleReconnect() {
        // Single-flight: if a reconnect is already pending, do nothing.
        // onclose and onerror both used to land here and each scheduled a
        // separate timer, which is how sockets multiplied.
        if (this._reconnectTimer || this._closed) return;
        this._reconnectTimer = setTimeout(() => {
            this._reconnectTimer = null;
            console.log('[WS] Reconnecting...');
            this.connect();
        }, this.reconnectDelay);
        this.reconnectDelay = Math.min(this.reconnectDelay * 1.5, this.maxReconnectDelay);
    }

    sendTextInput(text) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ type: 'text_input', text }));
        }
    }

    sendCommand(cmd) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({ type: 'command', cmd }));
        }
    }

    sendToolConfirm(confirmId, approved) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'tool_confirm',
                confirm_id: confirmId,
                approved: !!approved,
            }));
        }
    }

    // ---------- Binary init handler ----------
    _handleBinaryFrame(buf) {
        const meta = this._pendingInitMeta;
        if (!meta) {
            console.warn('[WS] Unexpected binary frame (no pending init_meta)', buf.byteLength);
            return;
        }
        this._pendingInitMeta = null;

        if (meta.magic !== 'NPOS') {
            console.warn('[WS] init_meta magic mismatch:', meta.magic);
            return;
        }
        if (buf.byteLength !== meta.byte_size) {
            console.warn(
                '[WS] init blob size mismatch:',
                'expected', meta.byte_size, 'got', buf.byteLength
            );
            // Fall through anyway — slice what we can.
        }

        // Build positions dict in the same shape brain3d.initNeurons
        // already understands (region name → {center, count, positions, spread}),
        // but with `positions` as a Float32Array(n*3) instead of an array of
        // [x,y,z] triplets. brain3d's updated initNeurons accepts both.
        const positions = {};
        for (const [name, r] of Object.entries(meta.regions)) {
            const n = r.n_points;
            const view = new Float32Array(buf, r.byte_offset, n * 3);
            // Copy the slice so it owns its memory (the underlying buf
            // can be GC'd; we hand the copy to THREE which keeps it).
            const owned = new Float32Array(view);
            positions[name] = {
                center: r.center,
                count: r.count,
                spread: r.spread,
                positions: owned,         // Float32Array — fast path
            };
        }

        if (this.onInit) {
            try { this.onInit(positions); }
            catch (e) { console.error('[WS] onInit error:', e); }
        }
    }
}
