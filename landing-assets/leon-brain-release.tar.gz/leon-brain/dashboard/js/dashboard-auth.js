// Shared login for the dashboard and its route aliases. Never retry a mutation.
(function () {
    const originalFetch = window.fetch.bind(window);
    const read = store => { try { return store.getItem('leon_key') || ''; } catch (_) { return ''; } };
    let token = window.__LEON_KEY_INJECT || window.__LEON_KEY || '';
    try { token ||= read(localStorage) || read(sessionStorage); } catch (_) {}
    function parseKey(value) {
        const text = value.trim();
        try {
            const url = new URL(text);
            return new URLSearchParams(url.hash.slice(1)).get('key') || url.searchParams.get('key') || '';
        } catch (_) { return text; }
    }
    const query = new URLSearchParams(location.search);
    const fragment = new URLSearchParams(location.hash.slice(1));
    const supplied = fragment.get('key') || query.get('key');
    if (supplied) {
        token = parseKey(supplied);
        query.delete('key'); fragment.delete('key');
        history.replaceState(null, '', location.pathname + (query.size ? '?' + query : '') + (fragment.size ? '#' + fragment : ''));
        try { localStorage.setItem('leon_key', token); } catch (_) {}
    }
    window.__LEON_KEY = token;
    window.__leonNormKey = parseKey;
    // HTTP uses headers; credentials never need to be appended to fetch URLs.
    window.__leonWithKey = value => value;
    window.wsURL = path => {
        const url = new URL(path, location.href);
        url.protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
        url.searchParams.set('key', window.__LEON_KEY || '');
        return url.href;
    };
    let login, pendingMessage = token ? '' : 'Enter your dashboard key to connect.';
    function showLogin(message) {
        pendingMessage = message;
        if (!login) return;
        login.hidden = false;
        login.querySelector('[role=status]').textContent = message;
    }
    window.fetch = function (input, init) {
        const url = new URL(input instanceof Request ? input.url : input, location.href);
        if (url.origin !== location.origin) return originalFetch(input, init);
        const options = Object.assign({}, init);
        options.headers = new Headers(init?.headers || (input instanceof Request ? input.headers : undefined));
        if (window.__LEON_KEY && !options.headers.has('Authorization')) {
            options.headers.set('Authorization', 'Bearer ' + window.__LEON_KEY);
        }
        return originalFetch(input, options).then(response => {
            if (response.status === 401 && (!login || login.hidden)) showLogin('Sign in with your current dashboard key to continue.');
            return response;
        });
    };
    function mount() {
        const style = document.createElement('style');
        style.textContent = `#dashboard-login[hidden]{display:none}#dashboard-login{position:fixed;inset:0;z-index:2147483647;background:#080a0c;display:flex;align-items:center;justify-content:center;overflow:auto;padding:20px;color:#fff;font:16px/1.5 -apple-system,system-ui,sans-serif}#dashboard-login form{display:block;width:100%;max-width:380px;padding:24px;border:1px solid #303438;border-radius:20px;background:#101316}#dashboard-login h1{font-size:24px;margin:0 0 12px}#dashboard-login label{display:block;margin:16px 0 8px}#dashboard-login input,#dashboard-login button{box-sizing:border-box;width:100%;min-height:48px;border-radius:10px;font:inherit;padding:10px 12px}#dashboard-login input{background:#080a0c;color:white;border:1px solid #60686e}#dashboard-login button{margin-top:16px;background:#00ffc8;border:0;color:#001710;cursor:pointer}#dashboard-login a{color:#00ffc8}#dashboard-login [role=status]{min-height:48px;font-size:14px;color:#bac4c9}#dashboard-login :focus-visible{outline:2px solid #00ffc8;outline-offset:3px}`;
        document.head.appendChild(style);
        login = document.createElement('section');
        login.id = 'dashboard-login';
        login.setAttribute('role', 'dialog');
        login.setAttribute('aria-modal', 'true');
        login.setAttribute('aria-labelledby', 'dashboard-login-title');
        login.innerHTML = `<form><h1 id="dashboard-login-title">Dashboard sign in</h1><p role="status" aria-live="polite"></p><label for="dashboard-key">Dashboard key or sign-in link</label><input id="dashboard-key" type="password" autocomplete="current-password" autocapitalize="none" spellcheck="false" required><button type="submit">Sign in</button></form>`;
        login.hidden = !pendingMessage;
        document.body.appendChild(login);
        if (pendingMessage) showLogin(pendingMessage);
        login.querySelector('form').addEventListener('submit', async event => {
            event.preventDefault();
            const key = parseKey(login.querySelector('input').value);
            if (!key) { showLogin('Paste your dashboard key or a link containing it.'); return; }
            const button = login.querySelector('button');
            button.disabled = true;
            showLogin('Checking key…');
            try {
                const response = await originalFetch('/api/sleep/state', {headers: {Authorization: 'Bearer ' + key}, cache: 'no-store'});
                if (!response.ok) {
                    showLogin(response.status === 401 ? 'Key not accepted. Use your current dashboard key.' : 'Unable to sign in right now. Try again shortly.');
                    return;
                }
                window.__LEON_KEY = key;
                try { localStorage.setItem('leon_key', key); } catch (_) {
                    try { sessionStorage.setItem('leon_key', key); } catch (_) {
                        showLogin('Allow browser storage for this site, then sign in again.'); return;
                    }
                }
                location.reload();
            } catch (_) { showLogin('Could not connect. Check your connection and try again.'); }
            finally { button.disabled = false; }
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount, {once: true});
    else mount();
})();
