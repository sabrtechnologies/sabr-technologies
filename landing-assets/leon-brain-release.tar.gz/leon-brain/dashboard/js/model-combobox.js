/* Shared glass listbox for compact conversation controls and role preferences. */
class LeonGlassCombobox {
    static active = null;
    static instances = new Map();
    constructor(button) {
        this.button = button;
        this.items = [];
        this.index = -1;
        this.query = '';
        this.lastTyped = 0;
        button.type = 'button';
        button.classList.add('model-combobox');
        button.setAttribute('role', 'combobox');
        button.setAttribute('aria-haspopup', 'listbox');
        button.setAttribute('aria-expanded', 'false');
        this.menu = document.createElement('div');
        this.menu.id = button.id + '-listbox';
        this.menu.className = 'model-listbox lg-surface';
        this.menu.setAttribute('role', 'listbox');
        this.menu.setAttribute('aria-label', button.getAttribute('aria-label') || button.id);
        this.menu.hidden = true;
        button.setAttribute('aria-controls', this.menu.id);
        document.body.append(this.menu);
        LeonGlassCombobox.instances.set(button.id, this);
        button.addEventListener('click', () => this.menu.hidden ? this.open() : this.close());
        button.addEventListener('keydown', event => this.key(event));
        this.menu.addEventListener('pointerdown', event => event.preventDefault());
        this.menu.addEventListener('click', event => {
            const option = event.target.closest('[role=option]');
            if (option) this.choose(Number(option.dataset.index));
        });
        document.addEventListener('pointerdown', event => {
            if (!this.menu.hidden && !this.menu.contains(event.target) && !button.contains(event.target)) this.close();
        }, true);
        window.addEventListener('resize', () => this.position());
        window.visualViewport?.addEventListener('resize', () => this.position());
        window.visualViewport?.addEventListener('scroll', () => this.position());
        // The listbox is portaled to <body> and positioned in viewport space. When a scroll container holding the
        // button (the Models panel) scrolls and the button actually moves, following it would drag the open menu
        // over the panel's edges, so the menu closes instead; the button keeps focus and reopens on Enter or a
        // click. A scroll event that leaves the button where it was (content above it reflowed) just repositions.
        window.addEventListener('scroll', event => {
            if (this.menu.hidden || this.menu.contains(event.target)) return;
            const inContainer = event.target instanceof Element && event.target !== document.documentElement && event.target.contains(button);
            if (inContainer && Math.abs(button.getBoundingClientRect().top - this.anchorTop) > 2) this.close();
            else this.position();
        }, true);
    }
    setOptions(items, selected) {
        const signature = JSON.stringify([items, selected]);
        if (signature === this.signature && this.button.value === (selected || '')) return;
        this.signature = signature;
        this.items = items;
        this.button.value = selected || '';
        this.button.textContent = items.find(item => item.value === selected)?.label || selected || 'Choose a model';
        this.button.title = this.button.textContent;
        this.menu.replaceChildren(...items.map((item, index) => {
            const option = document.createElement('div');
            option.id = this.menu.id + '-' + index;
            option.setAttribute('role', 'option');
            option.setAttribute('aria-selected', String(item.value === selected));
            option.setAttribute('aria-disabled', String(!!item.disabled));
            option.dataset.index = index;
            const name = document.createElement('span'); name.textContent = item.label;
            option.append(name);
            if (item.detail) {const detail = document.createElement('small'); detail.textContent = item.detail; option.append(detail);}
            return option;
        }));
        this.index = items.findIndex(item => item.value === selected && !item.disabled);
        if (!this.menu.hidden) {this.highlight(this.index); this.position();}
    }
    open() {
        if (this.button.disabled || !this.items.length) return;
        LeonGlassCombobox.active?.close();
        LeonGlassCombobox.active = this;
        this.menu.hidden = false;
        this.button.setAttribute('aria-expanded', 'true');
        this.index = this.items.findIndex(item => item.value === this.button.value && !item.disabled);
        if (this.index < 0) this.index = this.items.findIndex(item => !item.disabled);
        this.position(); this.highlight(this.index); this.button.focus({preventScroll: true});
    }
    close() {
        this.menu.hidden = true;
        this.button.setAttribute('aria-expanded', 'false');
        this.button.removeAttribute('aria-activedescendant');
        this.query = '';
        if (LeonGlassCombobox.active === this) LeonGlassCombobox.active = null;
    }
    highlight(index) {
        this.index = index;
        [...this.menu.children].forEach((option, i) => option.classList.toggle('is-active', i === index));
        const option = this.menu.children[index];
        if (option) {
            this.button.setAttribute('aria-activedescendant', option.id);
            option.scrollIntoView({block: 'nearest'});
        }
    }
    choose(index) {
        const item = this.items[index];
        if (!item || item.disabled) return;
        this.button.value = item.value;
        this.close(); this.button.focus();
        this.button.dispatchEvent(new Event('change', {bubbles: true}));
    }
    key(event) {
        const open = !this.menu.hidden;
        if (event.key === 'Tab') {this.close(); return;}
        if (event.key === 'Escape' && open) {event.preventDefault(); event.stopPropagation(); this.close(); return;}
        if (event.key === 'Enter' || (event.key === ' ' && !this.query)) {
            event.preventDefault(); event.stopPropagation();
            if (open) this.choose(this.index); else this.open();
            return;
        }
        if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
            event.preventDefault(); event.stopPropagation();
            if (!open) {this.open(); if (event.key.startsWith('Arrow')) return;}
            const enabled = this.items.map((v, i) => v.disabled ? -1 : i).filter(i => i >= 0);
            let pos = enabled.indexOf(this.index);
            if (event.key === 'Home') pos = 0;
            else if (event.key === 'End') pos = enabled.length - 1;
            else pos = Math.max(0, Math.min(enabled.length - 1, pos + (event.key === 'ArrowDown' ? 1 : -1)));
            this.highlight(enabled[pos]);
            return;
        }
        if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
            event.preventDefault();
            if (!open) this.open();
            const now = Date.now();
            this.query = (now - this.lastTyped > 750 ? '' : this.query) + event.key.toLocaleLowerCase();
            this.lastTyped = now;
            const query = [...this.query].every(c => c === this.query[0]) ? this.query[0] : this.query;
            const start = query.length === 1 ? this.index + 1 : this.index;
            for (let step = 0; step < this.items.length; step++) {
                const i = (Math.max(0, start) + step) % this.items.length, item = this.items[i];
                if (!item.disabled && [item.label, item.value].some(s => s.toLocaleLowerCase().startsWith(query))) {this.highlight(i); break;}
            }
        }
    }
    position() {
        if (this.menu.hidden) return;
        const box = this.button.getBoundingClientRect(), viewport = window.visualViewport;
        this.anchorTop = box.top;
        const leftEdge = (viewport?.offsetLeft || 0) + 8, topEdge = (viewport?.offsetTop || 0) + 8;
        const width = viewport?.width || innerWidth, height = viewport?.height || innerHeight;
        const bottomEdge = topEdge + height - 16;
        this.menu.style.width = Math.min(Math.max(box.width, 280), width - 16) + 'px';
        this.menu.style.left = Math.max(leftEdge, Math.min(box.left, leftEdge + width - 16 - this.menu.offsetWidth)) + 'px';
        const below = bottomEdge - box.bottom - 6, above = box.top - topEdge - 6;
        const upwards = below < 180 && above > below;
        const space = Math.max(48, upwards ? above : below);
        this.menu.style.maxHeight = Math.min(350, space) + 'px';
        this.menu.style.top = (upwards ? Math.max(topEdge, box.top - this.menu.offsetHeight - 6) : Math.max(topEdge, box.bottom + 6)) + 'px';
    }
}
