// One dashboard, with phone-only on-demand panels and movable camera; desktop stays unchanged.
(() => {
    const compact = matchMedia('(max-width: 900px), (max-width: 1100px) and (pointer: coarse)');
    const nav = document.getElementById('dashboard-panels');
    for (const [name, label, target] of [
        ['conversation', 'Conversation', 'conv-panel'],
        ['activity', 'Activity Log', 'activity-panel'],
    ]) {
        if (!nav || nav.querySelector('[data-panel="' + name + '"]')) continue;
        const button = document.createElement('button');
        button.type = 'button'; button.dataset.panel = name; button.textContent = label;
        button.setAttribute('aria-controls', target);
        button.setAttribute('aria-expanded', 'false'); nav.appendChild(button);
    }
    const buttons = [...document.querySelectorAll('#dashboard-panels button')];
    function select(panel = '') {
        const focused = document.activeElement;
        if (compact.matches && focused?.closest('#conv-panel') && panel !== 'conversation') focused.blur();
        document.body.dataset.dashboardPanel = panel;
        buttons.forEach(button => button.setAttribute('aria-expanded', String(button.dataset.panel === panel)));
        if (panel === 'workspaces' || panel === 'agents') document.getElementById('ws-tab-' + panel)?.click();
        requestAnimationFrame(() => window.dispatchEvent(new Event('dashboard-panel-change')));
    }
    buttons.forEach(button => button.addEventListener('click', () => {
        select(document.body.dataset.dashboardPanel === button.dataset.panel ? '' : button.dataset.panel);
    }));
    document.addEventListener('keydown', event => {
        if (compact.matches && event.key === 'Escape' && document.body.dataset.dashboardPanel) {
            const button = buttons.find(b => b.dataset.panel === document.body.dataset.dashboardPanel);
            select(); button?.focus();
        }
    });
    function viewport() {
        const view = window.visualViewport;
        document.documentElement.style.setProperty('--dashboard-height', (view?.height || innerHeight) + 'px');
        document.documentElement.style.setProperty('--dashboard-top', (view?.offsetTop || 0) + 'px');
    }
    window.visualViewport?.addEventListener('resize', viewport);
    window.visualViewport?.addEventListener('scroll', viewport);
    window.addEventListener('resize', viewport);
    compact.addEventListener('change', viewport);
    select(); viewport();
    // The push-to-talk pill sits above the input bar on phones; the bar grows
    // with the textarea and staged attachments, so publish its height.
    const inputPanel = document.getElementById('input-panel');
    function measureInput() {
        if (!inputPanel) return;
        document.documentElement.style.setProperty('--input-h-phone', (inputPanel.offsetHeight || 52) + 'px');
    }
    if (inputPanel) new ResizeObserver(measureInput).observe(inputPanel);
    window.addEventListener('dashboard-panel-change', measureInput);
    measureInput();

    // Capture-phase handlers replace the legacy camera drag, whose phone CSS
    // pinned all four edges. No camera permissions or stream lifecycle changes.
    const camera = document.getElementById('webcam-preview');
    if (!camera) return;
    camera.title = 'Drag to move camera · drag the corner to resize';
    let drag = null, rect = null, desktopStyle = null, managed = false;
    const key = 'leon-floating-camera-v1';
    try { rect = JSON.parse(localStorage.getItem(key)); } catch {}
    if (!rect || !['x','y','w','h'].every(k => Number.isFinite(rect[k]))) rect = null;
    function bounds() {
        const v = window.visualViewport;
        return {x: v?.offsetLeft || 0, y: (v?.offsetTop || 0) + 8,
            w: Math.min(v?.width || innerWidth, document.documentElement.clientWidth),
            h: Math.max(1, Math.min(v?.height || innerHeight, innerHeight) - 16)};
    }
    function place(save = false) {
        if (!compact.matches) {
            if (managed) {
                if (desktopStyle === null) camera.removeAttribute('style');
                else camera.setAttribute('style', desktopStyle);
                managed = false; drag = null; camera.classList.remove('dragging');
            }
            return;
        }
        if (!camera.classList.contains('visible')) return;
        if (!managed) { desktopStyle = camera.getAttribute('style'); managed = true; }
        const b = bounds();
        if (!rect) rect = {x: b.x + b.w - 184, y: b.y + (innerWidth < 600 ? 102 : 54), w: compact.matches ? 160 : 200, h: compact.matches ? 100 : 150};
        rect.w = Math.max(Math.min(120, b.w - 16), Math.min(rect.w, b.w - 16));
        rect.h = Math.max(Math.min(70, b.h), Math.min(rect.h, b.h));
        rect.x = Math.max(b.x + 8, Math.min(rect.x, b.x + b.w - rect.w - 8));
        rect.y = Math.max(b.y, Math.min(rect.y, b.y + b.h - rect.h));
        const composer = document.getElementById('input-panel');
        if (composer && composer.getClientRects().length) {
            const c = composer.getBoundingClientRect();
            if (rect.x < c.right && rect.x + rect.w > c.left && rect.y < c.bottom && rect.y + rect.h > c.top) {
                if (c.right + rect.w + 8 <= b.x + b.w) rect.x = c.right + 8;
                else {
                    rect.h = Math.min(rect.h, Math.max(40, c.top - b.y - 8));
                    rect.y = Math.max(b.y, c.top - rect.h - 8);
                }
            }
        }
        for (const [prop, value] of Object.entries({position:'fixed', left:rect.x+'px', top:rect.y+'px',
            width:rect.w+'px', height:rect.h+'px', right:'auto', bottom:'auto', minWidth:'0', minHeight:'0', transform:'none'})) {
            const css = prop.replace(/[A-Z]/g, c => '-' + c.toLowerCase());
            camera.style.setProperty(css, value, 'important');
        }
        if (save) try { localStorage.setItem(key, JSON.stringify(rect)); } catch {}
    }
    camera.addEventListener('pointerdown', e => {
        if (!compact.matches || e.button !== 0 || drag) return;
        place();
        if (!rect) return;
        drag = {id:e.pointerId, x:e.clientX, y:e.clientY, start:{...rect},
            resize: !!e.target.closest('.webcam-resize-handle')};
        camera.classList.add('dragging');
        camera.setPointerCapture(e.pointerId); e.preventDefault(); e.stopImmediatePropagation();
    }, true);
    camera.addEventListener('pointermove', e => {
        if (!drag || e.pointerId !== drag.id) return;
        const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        rect = {...drag.start};
        if (drag.resize) { rect.w += dx; rect.h += dy; }
        else { rect.x += dx; rect.y += dy; }
        place(); e.preventDefault(); e.stopImmediatePropagation();
    }, true);
    function release(e) {
        if (!drag || e.pointerId !== drag.id) return;
        drag = null; camera.classList.remove('dragging'); place(true);
        if (camera.hasPointerCapture(e.pointerId)) camera.releasePointerCapture(e.pointerId);
        e.stopImmediatePropagation();
    }
    for (const type of ['pointerup','pointercancel','lostpointercapture']) camera.addEventListener(type, release, true);
    new MutationObserver(() => place()).observe(camera, {attributes:true, attributeFilter:['class']});
    new ResizeObserver(() => place()).observe(document.getElementById('input-panel'));
    window.addEventListener('resize', () => { place(); requestAnimationFrame(() => place()); });
    compact.addEventListener('change', () => place());
    window.addEventListener('dashboard-panel-change', () => place());
    window.visualViewport?.addEventListener('resize', () => place());
    window.visualViewport?.addEventListener('scroll', () => place());
    place();
})();
