/* Real dashboard settings; system audio belongs to the owner's Windows session. */
(() => {
    const $ = id => document.getElementById(id);
    const overlay = document.createElement('div');
    overlay.id = 'settings-overlay'; overlay.hidden = true;
    overlay.innerHTML = `<div id="settings-panel" class="lg-surface" role="dialog" aria-modal="true" aria-labelledby="settings-title" tabindex="-1">
      <div class="settings-heading"><h2 id="settings-title">Settings</h2><button id="settings-close" class="lg-btn" aria-label="Close Settings">×</button></div>
      <p id="settings-message" role="status" aria-live="polite"></p>
      <section aria-labelledby="settings-audio-title"><h3 id="settings-audio-title">Audio</h3>
        <div class="settings-heading"><label for="settings-pc-output">PC sound output</label><button id="settings-audio-refresh" class="lg-btn">Refresh devices</button></div>
        <p>Controls the Windows device linked to this SI, when available. These are not the VPS's audio devices. Only connected devices appear.</p>
        <button id="settings-pc-output" class="lg-field" aria-label="PC sound output" disabled>Loading devices…</button>
        <label class="settings-row" for="settings-volume">PC volume <output id="settings-volume-value">—</output></label>
        <input id="settings-volume" type="range" min="0" max="100" step="0.1" aria-label="PC volume" disabled>
        <label class="settings-row">Mute PC sound<input id="settings-pc-mute" type="checkbox" disabled></label>
        <label for="settings-mic-input">PC microphone input</label><button id="settings-mic-input" class="lg-field" aria-label="PC microphone input" disabled>Loading devices…</button>
        <p>Changes the Windows default microphone. An app already recording may need to reopen its microphone.</p>
        <p id="settings-audio-message" role="status" aria-live="polite"></p>
        <label for="settings-voice-output">Leon's voice output</label><button id="settings-voice-output" class="lg-field" aria-label="Leon's voice output">Same as system</button>
        <p>Saved in this browser, whether the SI runs locally or on a VPS. On another device, this routes voice on that device; PC controls still affect the linked Windows device.</p>
        <div class="settings-actions"><button id="settings-output-permission" class="lg-btn">Allow output devices</button><button id="settings-test-voice" class="lg-btn">Test voice</button></div>
        <p id="settings-voice-message" role="status" aria-live="polite">Test voice plays a short, quiet tone through your chosen voice output.</p>
      </section>
      <section aria-labelledby="settings-listening-title"><h3 id="settings-listening-title">Voice and listening</h3>
        <label class="settings-row">Leon speaks replies in this browser<input id="settings-speak" type="checkbox"></label>
        <label class="settings-row">Wake word<input id="settings-wake" type="checkbox" disabled></label>
        <label class="settings-row">Proactive speech and room watching<input id="settings-proactive" type="checkbox" disabled></label>
        <p>Wake word and proactive watching are shared SI settings. Voice replies are saved per browser.</p>
        <button id="settings-tts" class="lg-btn">Voice provider &amp; voice choice</button>
        <p>Voice configuration is in Integrations. A separate camera/microphone privacy switch is unavailable here; proactive watching is not a camera permission switch. Use browser site permissions to block camera or microphone access.</p>
      </section>
      <section aria-labelledby="settings-accounts-title"><h3 id="settings-accounts-title">Accounts</h3><div id="settings-accounts">Loading account status…</div>
        <p id="settings-claude-connection" role="status">Checking Claude connections…</p>
        <p>Models shows Claude's laptop bridge and native account separately. A laptop bridge uses the laptop's login; a native login belongs to the computer or VPS running the SI. For Codex, use its client on the machine that runs your tasks. Cached model lists do not verify current sign-in.</p>
        <button id="settings-models" class="lg-btn">Models &amp; reasoning</button>
        <button id="settings-status-refresh" class="lg-btn">Refresh account status</button>
        <button id="settings-integrations" class="lg-btn">API keys &amp; integrations</button>
      </section>
      <section aria-labelledby="settings-localai-title"><h3 id="settings-localai-title">Local AI</h3>
        <label class="settings-row">Answer with Local AI (LM Studio on the laptop)<input id="settings-localai-enabled" type="checkbox" disabled></label>
        <label class="settings-row" for="settings-localai-model">Model<select id="settings-localai-model" disabled style="background:rgba(0,0,0,.35);color:#e8fff9;border:1px solid rgba(0,255,200,.35);border-radius:8px;padding:4px 8px;max-width:60%;accent-color:#00ffc8"></select></label>
        <p id="settings-localai-status" role="status">Checking Local AI…</p>
        <p>Local AI uses an 8K context window with a smaller memory slice and only safe read-only tools. If it is unreachable, Leon says so and answers with the normal provider. No billing applies.</p>
        <button id="settings-localai-refresh" class="lg-btn">Refresh local models</button>
      </section>
      <section aria-labelledby="settings-appearance-title"><h3 id="settings-appearance-title">Appearance and behavior</h3>
        <label class="settings-row">Reduce motion<input id="settings-motion" type="checkbox"></label>
        <label class="settings-row" for="settings-glass">Glass intensity<output id="settings-glass-value"></output></label>
        <input id="settings-glass" type="range" min="0" max="100" step="1" aria-label="Glass intensity">
        <p>Appearance preferences are saved in this browser.</p>
        <p id="settings-notifications"></p>
      </section>
      <section aria-labelledby="settings-about-title"><h3 id="settings-about-title">About</h3><div id="settings-about">Loading build information…</div>
        <p>Update channel selection, data export and restart are unavailable in Settings. A restart must be scheduled when conversation is idle.</p>
      </section>
    </div>`;
    document.body.append(overlay);
    const combos = {};
    for (const id of ['settings-pc-output','settings-mic-input','settings-voice-output']) {
        combos[id] = new LeonGlassCombobox($(id));
        // Keep portaled listboxes inside the modal's focus/inert boundary.
        overlay.append(combos[id].menu);
    }
    let audioData = null, busy = false, opening = 0, returnFocus = null, inertElements = [];
    window.addEventListener('leon-claude-connection', event => {
        $('settings-claude-connection').textContent = event.detail;
    });
    let voiceGeneration = 0;
    const stored = (key, fallback) => {try {return localStorage.getItem(key) ?? fallback;} catch {return fallback;}};
    function persist(key, value) {
        try {localStorage.setItem(key, String(value)); return true;}
        catch { $('settings-message').textContent='Browser storage is unavailable. This preference could not be saved.'; return false; }
    }
    function appearance() {
        const reduce = stored('leon-reduce-motion', '0') === '1';
        const raw = Number(stored('leon-glass-intensity', '50'));
        const intensity = Number.isFinite(raw) ? Math.max(0, Math.min(100, raw)) : 50;
        document.documentElement.classList.toggle('leon-reduce-motion', reduce);
        if (intensity !== 50) {
            document.documentElement.style.setProperty('--lg-blur', `saturate(${140 + 2 * intensity}%) brightness(1.10) contrast(1.04) blur(${8 + .24 * intensity}px)`);
            document.documentElement.style.setProperty('--lg-tint', `rgba(255,255,255,${.008 + .0002 * intensity})`);
        } else {
            document.documentElement.style.removeProperty('--lg-blur'); document.documentElement.style.removeProperty('--lg-tint');
        }
        $('settings-motion').checked = reduce; $('settings-glass').value = intensity;
        $('settings-glass-value').textContent = intensity + '%';
    }
    appearance();
    async function request(path, payload) {
        const response = await fetch(path, {signal: AbortSignal.timeout(path.startsWith('/api/audio/') ? 30000 : 16000), ...(payload === undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})});
        if (response.status === 401 || response.status === 403) throw new Error('Settings access is unavailable. Check dashboard sign-in and installation permissions.');
        if (response.status === 404) throw new Error('Settings backend needs a server restart. Browser voice and appearance settings already work.');
        let data; try {data = await response.json();} catch {throw new Error('Settings server returned an invalid response.');}
        if (!response.ok || data.ok === false) throw new Error(data.error || 'Could not apply settings.');
        return data;
    }
    function audioControls(enabled) {
        for (const id of ['settings-pc-output','settings-mic-input','settings-volume','settings-pc-mute']) $(id).disabled = !enabled;
    }
    function renderAudio(data) {
        audioData = data;
        for (const [kind,id] of [['Playback','settings-pc-output'],['Recording','settings-mic-input']]) {
            const list = data.devices.filter(d => d.Type === kind);
            const current = list.find(d => d.Default);
            combos[id].setOptions(list.map(d => ({value:d.ID,label:d.Name + (d.Default ? ' · Windows default' : ''),detail:d.Name.includes('voice-audio') ? 'AR glasses · USB audio' : d.Name.includes('Realtek') ? 'Laptop audio' : ''})),current?.ID || '');
            $(id).disabled = busy || !list.length;
        }
        $('settings-volume').value = data.volume;
        $('settings-volume-value').textContent = Math.round(data.volume * 10) / 10 + '%';
        $('settings-pc-mute').checked = !!data.mute;
        const hasOutput = data.devices.some(d => d.Type === 'Playback' && d.Default);
        $('settings-volume').disabled = $('settings-pc-mute').disabled = busy || !hasOutput;
    }
    async function refreshAudio() {
        if (busy) return;
        busy = true; audioControls(false); $('settings-audio-refresh').disabled = true;
        $('settings-audio-message').textContent = 'Reading laptop audio devices…';
        try {const data = await request('/api/audio/devices'); busy = false; renderAudio(data); $('settings-audio-message').textContent = 'Windows audio devices refreshed.';}
        catch (e) {
            audioData = null; audioControls(false);
            for (const id of ['settings-pc-output','settings-mic-input']) {combos[id].setOptions([], ''); $(id).textContent='Devices unavailable';}
            $('settings-volume-value').textContent='Unavailable';
            $('settings-audio-message').textContent = e.message;
        }
        finally {busy = false; $('settings-audio-refresh').disabled = false;}
    }
    async function writeAudio(path, payload) {
        if (busy || !audioData) return;
        busy = true; audioControls(false); $('settings-audio-refresh').disabled = true;
        $('settings-audio-message').textContent = 'Applying and verifying Windows audio…';
        try {const data = await request(path,payload); busy = false; renderAudio(data); $('settings-audio-message').textContent = 'Windows audio updated and verified.';}
        catch (e) {busy = false; renderAudio(audioData); $('settings-audio-message').textContent = e.message + ' Refresh devices before trying again.'; audioControls(false);}
        finally {busy = false; $('settings-audio-refresh').disabled = false;}
    }
    for (const [id,kind] of [['settings-pc-output','Playback'],['settings-mic-input','Recording']]) $(id).addEventListener('change',()=>writeAudio('/api/audio/default',{device_id:$(id).value,kind}));
    const currentOutput = () => audioData?.devices.find(d=>d.Type==='Playback' && d.Default)?.ID;
    $('settings-volume').addEventListener('input',()=>{$('settings-volume-value').textContent=$('settings-volume').value+'%';});
    $('settings-volume').addEventListener('change',()=>writeAudio('/api/audio/volume',{device_id:currentOutput(),volume:Number($('settings-volume').value)}));
    $('settings-pc-mute').addEventListener('change',()=>writeAudio('/api/audio/mute',{device_id:currentOutput(),mute:$('settings-pc-mute').checked}));
    $('settings-audio-refresh').addEventListener('click',refreshAudio);
    const voiceMessage = message => {$('settings-voice-message').textContent=message;};
    async function refreshVoiceDevices() {
        const generation = ++voiceGeneration;
        const supported = window.isSecureContext && !!navigator.mediaDevices?.enumerateDevices && 'setSinkId' in HTMLMediaElement.prototype;
        $('settings-voice-output').disabled = $('settings-output-permission').disabled = !supported;
        if (!supported) {
            combos['settings-voice-output'].setOptions([{value:'',label:'Same as system'}],'');
            voiceMessage('This browser cannot select voice outputs. Use current Chrome, Edge or Brave over HTTPS (or localhost). Voice uses the system output here.'); return;
        }
        try {
            const devices = (await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audiooutput' && d.deviceId && d.deviceId!=='default' && d.deviceId!=='communications');
            if (generation !== voiceGeneration) return;
            const saved=stored('leon-voice-sink','');
            const items=[{value:'',label:'Same as system'},...devices.map((d,i)=>({value:d.deviceId,label:d.label || `Output ${i+1} · permission needed`}))];
            if(saved && !devices.some(d=>d.deviceId===saved)) {items.push({value:saved,label:'Saved output unavailable',disabled:true}); voiceMessage('Your saved voice device is disconnected or permission is missing. Voice temporarily uses system output. Choose Allow output devices to grant access.');}
            else if(devices.some(d=>!d.label) || !devices.length) voiceMessage('Choose Allow output devices and approve the browser prompt to reveal device names. Microphone access, if requested, is used only to list devices and is immediately released.');
            else if (/^(Your saved voice device|Could not read browser output devices)/.test($('settings-voice-message').textContent)) voiceMessage('Voice output is saved in this browser. Test voice plays a short, quiet tone.');
            combos['settings-voice-output'].setOptions(items,saved);
        } catch(e) {voiceMessage('Could not read browser output devices: '+e.message);}
    }
    $('settings-output-permission').addEventListener('click',async()=>{
        const old=stored('leon-voice-sink','');
        try {
            if(navigator.mediaDevices.selectAudioOutput) {
                const selected=await navigator.mediaDevices.selectAudioOutput();
                await window.LeonVoiceSettings.apply(selected.deviceId);
                if(!persist('leon-voice-sink',selected.deviceId)) throw new Error('Output preference could not be saved.');
            } else {
                const stream=await navigator.mediaDevices.getUserMedia({audio:true}); stream.getTracks().forEach(t=>t.stop());
            }
            voiceMessage('Output access granted. Choose where Leon speaks.'); await refreshVoiceDevices();
        } catch(e) {try {await window.LeonVoiceSettings.apply(old);} catch {} voiceMessage('Output access or saving failed. Check browser permissions and storage. '+e.message);}
    });
    $('settings-voice-output').addEventListener('change',async()=>{
        const old=stored('leon-voice-sink',''), next=$('settings-voice-output').value;
        $('settings-voice-output').disabled=true;
        try {await window.LeonVoiceSettings.apply(next); if(!persist('leon-voice-sink',next)) throw new Error('Output preference could not be saved.'); voiceMessage('Voice output saved for this browser.');}
        catch(e) {try {await window.LeonVoiceSettings.apply(old);} catch {} voiceMessage('Voice output could not be changed. '+e.message);}
        finally {$('settings-voice-output').disabled=false; await refreshVoiceDevices();}
    });
    navigator.mediaDevices?.addEventListener('devicechange',()=>{if(!overlay.hidden) refreshVoiceDevices();});
    function toneWav() {
        const rate=16000, count=8000, buffer=new ArrayBuffer(44+count*2), view=new DataView(buffer);
        const str=(offset,s)=>{[...s].forEach((c,i)=>view.setUint8(offset+i,c.charCodeAt(0)));};
        str(0,'RIFF'); view.setUint32(4,36+count*2,true); str(8,'WAVE');str(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,rate,true);view.setUint32(28,rate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);str(36,'data');view.setUint32(40,count*2,true);
        for(let i=0;i<count;i++)view.setInt16(44+i*2,Math.sin(2*Math.PI*440*i/rate)*2200*Math.min(i/300,(count-i)/300,1),true);
        return new Blob([buffer],{type:'audio/wav'});
    }
    $('settings-test-voice').addEventListener('click',async()=>{
        const button=$('settings-test-voice');button.disabled=true;
        const element=new Audio(), url=URL.createObjectURL(toneWav());
        try {
            if(window.LeonVoiceSettings?.playing) throw new Error('Wait until Leon finishes speaking, then test.');
            const sink=stored('leon-voice-sink',''); if(sink && element.setSinkId) await element.setSinkId(sink);
            element.src=url; element.volume=window.LeonVoiceSettings?.volume ?? .5;
            await element.play(); voiceMessage('Test tone sent to your voice output.');
            await new Promise((resolve,reject)=>{element.onended=resolve;element.onerror=()=>reject(new Error('Test tone could not play.'));setTimeout(resolve,2000);});
        } catch(e) {voiceMessage('Test voice: '+e.message);}
        finally {element.pause();element.src='';URL.revokeObjectURL(url);button.disabled=false;}
    });
    $('settings-speak').addEventListener('change',()=>{
        try {window.LeonVoiceSettings.setMuted(!$('settings-speak').checked);} catch(e){$('settings-speak').checked=!window.LeonVoiceSettings?.muted;$('settings-message').textContent=e.message;}
    });
    async function voiceSwitch(id,key) {
        const input=$(id), value=input.checked;input.disabled=true;
        try {await request('/api/settings',{[key]:value}); $('settings-message').textContent='Listening preference saved.';}
        catch(e) {
            // A timeout can happen after the server saved the value. Read back
            // instead of claiming the opposite value is still in effect.
            try {const data=await request('/api/settings'); input.checked=!!data.voice[key]; input.disabled=key==='proactive_enabled' && !data.voice.proactive_available;}
            catch {input.disabled=true;}
            $('settings-message').textContent=e.message+' Reopen Settings to refresh the current state.';
            return;
        }
        input.disabled=false;
    }
    $('settings-wake').addEventListener('change',()=>voiceSwitch('settings-wake','wake_enabled'));
    $('settings-proactive').addEventListener('change',()=>voiceSwitch('settings-proactive','proactive_enabled'));
    $('settings-motion').addEventListener('change',()=>{persist('leon-reduce-motion',$('settings-motion').checked?'1':'0');appearance();});
    $('settings-glass').addEventListener('input',()=>{persist('leon-glass-intensity',$('settings-glass').value);appearance();});
    async function loadLocalAI() {
        const status=$('settings-localai-status'), select=$('settings-localai-model'), toggle=$('settings-localai-enabled');
        status.textContent='Checking Local AI…';
        let saved;
        try {saved=await request('/api/local_ai/settings');}
        catch(e) {status.textContent='Local AI settings unavailable: '+e.message; return;}
        toggle.checked=!!saved.enabled; toggle.disabled=false;
        let models=[];
        try {models=(await request('/api/local_ai/models')).models || []; status.textContent=`${models.length} model${models.length===1?'':'s'} at ${saved.base_url}.`;}
        catch(e) {status.textContent=`Local AI is unreachable at ${saved.base_url || 'the configured URL'}. Showing the saved model.`;}
        if (!models.includes(saved.model)) models=[saved.model, ...models];
        select.replaceChildren(...models.map(id=>{const o=document.createElement('option');o.value=o.textContent=id;return o;}));
        select.value=saved.model; select.disabled=false;
    }
    async function writeLocalAI(payload) {
        try {const data=await request('/api/local_ai/settings', payload); $('settings-localai-status').textContent=(data.enabled?'Local AI on':'Local AI off')+' · '+data.model;}
        catch(e) {$('settings-localai-status').textContent=e.message; loadLocalAI();}
    }
    $('settings-localai-enabled').addEventListener('change', e=>writeLocalAI({enabled:e.target.checked}));
    $('settings-localai-model').addEventListener('change', e=>writeLocalAI({model:e.target.value}));
    $('settings-localai-refresh').addEventListener('click', ()=>loadLocalAI());
    async function loadSettings(generation) {
        loadLocalAI();
        $('settings-message').textContent='Loading settings…';
        $('settings-accounts').textContent='Checking account information…';
        $('settings-claude-connection').textContent='Checking Claude connections…';
        if (window.leonClaudeConnection) window.leonClaudeConnection.refresh();
        else $('settings-claude-connection').textContent='Claude connection status unavailable. Open Models to check the SI host and laptop bridge.';
        $('settings-status-refresh').disabled=true;
        $('settings-wake').disabled=$('settings-proactive').disabled=true;
        try {
            const data=await request('/api/settings'); if(generation!==opening) return;
            $('settings-wake').checked=!!data.voice.wake_enabled;$('settings-wake').disabled=false;
            $('settings-proactive').checked=!!data.voice.proactive_enabled;$('settings-proactive').disabled=!data.voice.proactive_available;
            $('settings-accounts').replaceChildren(...data.accounts.map(account=>{
                const row=document.createElement('p');
                const client=['claude','codex'].includes(account.provider) || /Claude|Codex/.test(account.label);
                row.textContent=account.label+' · '+(client?(account.provider==='claude' || account.label==='Claude'?'See Claude connection status below':'Current sign-in unverified'):account.status)
                    +(client?' · '+(account.catalog_status || 'Cached model information only'):'')
                    +(account.checked_at?' · Catalog checked '+new Date(account.checked_at*1000).toLocaleString():'');
                return row;
            }));
            const info=data.about;
            $('settings-about').textContent=`Disk checkout ${info.commit} · ${info.date || 'date unavailable'} · Running code revision unverified · Server uptime ${Math.floor(info.uptime_seconds/3600)}h ${Math.floor(info.uptime_seconds/60)%60}m`+(Number.isInteger(info.automatic_service_restarts)?` · Automatic service restarts ${info.automatic_service_restarts}`:'')+` · Settings UI 20261009-settings-qa-v4 · Version file: ${info.version || 'unavailable until a safe server restart'}`+(info.checkout_branch?` · Checkout branch: ${info.checkout_branch} (not an update channel)`:'');
            $('settings-message').textContent=data.settings_schema===2?'Settings ready.':'Existing controls are ready. Additional version and account details need a safe server restart.';
        } catch(e) {if(generation===opening){$('settings-message').textContent=e.message;$('settings-accounts').textContent='Account status unavailable. Refresh after dashboard access is restored.';$('settings-about').textContent='Settings UI 20261009-settings-qa-v4 · Server build and uptime unavailable.';}}
        finally {if(generation===opening)$('settings-status-refresh').disabled=false;}
    }
    function close() {
        if(overlay.hidden)return;
        opening++; Object.values(combos).forEach(c=>c.close()); overlay.hidden=true;
        $('settings-btn').setAttribute('aria-expanded','false');
        inertElements.forEach(([e,value])=>{e.inert=value;});inertElements=[];
        returnFocus?.focus();
    }
    function open() {
        if(!overlay.hidden)return;
        returnFocus=document.activeElement;
        overlay.hidden=false;$('settings-btn').setAttribute('aria-expanded','true');
        inertElements=[...document.body.children].filter(e=>e!==overlay && !['SCRIPT','STYLE'].includes(e.tagName)).map(e=>[e,e.inert]);
        inertElements.forEach(([e])=>{e.inert=true;});
        $('settings-close').focus();$('settings-speak').checked=!window.LeonVoiceSettings?.muted;
        $('settings-speak').disabled=typeof window.LeonVoiceSettings?.setMuted!=='function';
        $('settings-notifications').textContent='Notification permission: '+('Notification' in window?Notification.permission:'unavailable in this browser')+'. Change notification access in browser site settings; a separate notification switch is unavailable here.';
        appearance();loadSettings(++opening);refreshAudio();refreshVoiceDevices();
    }
    $('settings-btn').addEventListener('click',open);
    $('settings-close').addEventListener('click',close);
    $('settings-integrations').addEventListener('click',()=>{close();$('integrations-btn').click();});
    $('settings-tts').addEventListener('click',()=>{close();$('integrations-btn').click();});
    $('settings-models').addEventListener('click',()=>{close();$('cu-model-button').click();});
    $('settings-status-refresh').addEventListener('click',()=>loadSettings(++opening));
    overlay.addEventListener('click',e=>{if(e.target===overlay)close();});
    overlay.addEventListener('keydown',e=>{
        if(e.key==='Escape'){e.preventDefault();close();}
        if(e.key==='Tab') {
            const focusable=[...$('settings-panel').querySelectorAll('button:not(:disabled),input:not(:disabled),[tabindex="0"]')].filter(e=>e.getClientRects().length);
            const first=focusable[0],last=focusable[focusable.length-1];
            if(e.shiftKey && document.activeElement===first){e.preventDefault();last.focus();}
            else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first.focus();}
        }
    });
})();
