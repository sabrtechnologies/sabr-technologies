// One line, one bubble, for the conversation box (2026-10-05).
//
// Dean, 00:56: "just chilling in bed with the phone, huh — I'll ping you..."
// was spoken once but shown twice. Unprompted lines reach the screen twice by
// design: live over the websocket (through the announcement hold) and again
// as the stored row the store poll pulls. The two copies shared nothing, and
// the stored one usually landed first (the hold waits ~2 s of quiet), so the
// live bubble was simply painted underneath it.
//
// Now both copies carry the same utterance id (data-uids on the bubble,
// utterance_id on the stored row), and whichever arrives second adopts the
// bubble the first one drew. Safety net for anything without an id: a Leon
// line whose exact text is already on screen, painted moments ago and not yet
// matched to its other copy, is the same line.
//
// Pure logic, no DOM access of its own: index.html / mobile.html pass in the
// bubbles and a text reader; tests/test_conv_once.py drives it under node.
(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.LeonConvOnce = factory();
}(typeof self !== 'undefined' ? self : this, function () {
    'use strict';
    // The announcement hold can keep a line up to 10 min before it is shown.
    const TWIN_WINDOW_MS = 15 * 60 * 1000;
    const MAX_BACK = 12;   // only the last few bubbles can be the other copy

    function norm(text) {
        return String(text || '')
            .replace(/```[\s\S]*?```/g, ' ')
            .replace(/`([^`\n]+)`/g, '$1')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function uids(el) {
        const raw = el && el.dataset ? el.dataset.uids : '';
        return String(raw || '').split(' ').filter(Boolean);
    }

    function byUid(els, uid) {
        if (!uid) return null;
        for (let i = els.length - 1; i >= 0; i--) {
            if (uids(els[i]).indexOf(uid) !== -1) return els[i];
        }
        return null;
    }

    function byAnyUid(els, ids) {
        for (const id of ids || []) {
            const el = byUid(els, id);
            if (el) return el;
        }
        return null;
    }

    // opts.textOf(el) -> shown text; opts.accept(el) -> may this bubble be
    // the other copy; opts.now -> ms; opts.ids -> the incoming copy's ids.
    // Two copies that both carry ids, none shared, are different lines (Leon
    // can say the same words twice). Returns the newest matching bubble.
    function twin(els, text, opts) {
        const want = norm(text);
        if (!want) return null;
        const now = opts && opts.now != null ? opts.now : Date.now();
        const windowMs = (opts && opts.windowMs) || TWIN_WINDOW_MS;
        const ids = ((opts && opts.ids) || []).filter(Boolean);
        for (let i = els.length - 1, n = 0; i >= 0 && n < MAX_BACK; i--, n++) {
            const el = els[i];
            if (opts && opts.accept && !opts.accept(el)) continue;
            const at = +((el.dataset && el.dataset.paintedAt) || 0);
            if (!at || now - at > windowMs) continue;
            const have = uids(el);
            if (ids.length && have.length && !ids.some(id => have.indexOf(id) !== -1)) continue;
            if (norm(opts.textOf(el)) === want) return el;
        }
        return null;
    }

    return {norm: norm, uids: uids, byUid: byUid, byAnyUid: byAnyUid, twin: twin,
            TWIN_WINDOW_MS: TWIN_WINDOW_MS};
}));
