// Sleep is owned by DreamEngine. Speech (including "going to sleep") is
// neither a wake transition nor evidence that a sleeping engine has woken.
(function () {
    let stateSince = -Infinity;
    let requestId = 0;
    let failures = 0;

    function render(state) {
        const known = state === 'awake' || state === 'sleeping' || state === 'napping';
        const asleep = state !== 'awake';
        if (known) {
            window.__leonAsleep = asleep;
            document.body.classList.toggle('leon-sleeping', asleep);
        }
        const badge = document.getElementById('leon-status');
        if (!badge) return;
        badge.classList.toggle('sleeping', known && asleep);
        badge.classList.toggle('online', known && !asleep);
        const text = badge.querySelector('.ls-text');
        if (text) text.textContent = known ? (asleep ? 'sleeping' : 'online') : 'status unavailable';
    }

    function apply(snapshot, allowLegacy = false) {
        if (!snapshot || snapshot.ok === false ||
            !['awake', 'sleeping', 'napping'].includes(snapshot.sleep_state)) return false;
        if (!Number.isFinite(snapshot.state_since)) {
            // During a rolling restart an older server can still answer HTTP.
            // Only accept it before any ordered snapshot has been observed.
            if (!allowLegacy || stateSince !== -Infinity) return false;
            failures = 0;
            render(snapshot.sleep_state);
            return true;
        }
        if (snapshot.state_since < stateSince) return true; // delayed pre-transition response
        stateSince = snapshot.state_since;
        failures = 0;
        render(snapshot.sleep_state);
        return true;
    }

    async function pollSleep() {
        const id = ++requestId;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        try {
            const response = await fetch('/api/sleep/state', {cache: 'no-store', signal: controller.signal});
            if (!response.ok) throw new Error('sleep state unavailable');
            const snapshot = await response.json();
            if (id !== requestId) return;
            if (!apply(snapshot, true)) throw new Error('invalid sleep state');
        } catch (_) {
            if (id === requestId && ++failures >= 3) render(null);
        } finally {
            clearTimeout(timeout);
        }
    }

    window.addEventListener('leon-sleep-state', event => {
        if (apply(event.detail)) ++requestId; // invalidate older in-flight polls
        else if (event.detail && !Number.isFinite(event.detail.state_since)) pollSleep();
    });
    window.addEventListener('leon-ws-connected', pollSleep);
    // Kept for existing speech/audio callers: refresh truth, never force awake.
    window.markLeonAwake = function () {
        // Streaming token bursts must not start a request for every token.
        if (!window.__leonSleepRefreshPending) {
            window.__leonSleepRefreshPending = true;
            pollSleep().finally(() => { window.__leonSleepRefreshPending = false; });
        }
    };
    render(null);
    pollSleep();
    setInterval(pollSleep, 5000);
})();
