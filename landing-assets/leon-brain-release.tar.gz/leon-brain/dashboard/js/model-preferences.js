/* Separate saved role preferences, local drafts, and observed launches. */
class LeonModelPreferences {
    static roles = {chat: 'Conversation', job: 'Coding', hermes: 'Hermes'};
    static efforts = {default: 'Provider default', low: 'Quick', medium: 'Balanced', high: 'Deep', xhigh: 'Extra deep', max: 'Maximum', ultra: 'Ultra'};
    constructor({onSaved}) {
        this.onSaved = onSaved;
        this.role = 'chat';
        this.drafts = {};
        this.state = null;
        this.available = false;
        this.loaded = false;
        this.saving = false;
        this.refreshing = false;
        this.refreshAttempted = false;
        this.notice = '';
        this.get = id => document.getElementById('cu-model-' + id);
        this.panel = this.get('panel');
        this.button = this.get('button');
        this.tabs = [...this.panel.querySelectorAll('[data-role]')];
        this.combos = {};
        ['provider', 'name', 'effort'].forEach(field => {
            this.combos['cu-model-' + field] = new LeonGlassCombobox(this.get(field));
        });
        this.controls = document.getElementById('cu-model-controls');
        this.home = this.controls.parentElement;
        this.phone = matchMedia('(max-width: 900px)');
        this.routeMenu = document.getElementById('cu-provider-menu');
        document.body.append(this.panel, this.routeMenu);
        this.placeControls = () => {
            // The responsive dashboard keeps these in its Controls panel.
            this.home.insertBefore(this.controls, document.getElementById('cu-refresh'));
            this.position();
        };
        this.phone.addEventListener('change', this.placeControls);
        this.placeControls();
        this.button.addEventListener('click', () => this.panel.hidden ? this.open() : this.close());
        this.get('close').addEventListener('click', () => this.close(true));
        this.tabs.forEach(tab => {
            tab.addEventListener('click', () => this.switchRole(tab.dataset.role));
            tab.addEventListener('keydown', event => {
                let index = this.tabs.indexOf(tab);
                if (event.key === 'ArrowRight') index = (index + 1) % this.tabs.length;
                else if (event.key === 'ArrowLeft') index = (index + this.tabs.length - 1) % this.tabs.length;
                else if (event.key === 'Home') index = 0;
                else if (event.key === 'End') index = this.tabs.length - 1;
                else return;
                event.preventDefault(); this.tabs[index].focus(); this.switchRole(this.tabs[index].dataset.role);
            });
        });
        ['provider', 'name', 'effort'].forEach(field => this.get(field).addEventListener('change', () => this.change(this.role, field, this.get(field).value)));
        this.get('manual').addEventListener('input', () => this.change(this.role, 'name', this.get('manual').value.trim()));
        this.get('save').addEventListener('click', () => this.save());
        document.addEventListener('pointerdown', event => {
            const inside = this.panel.contains(event.target) || this.button.contains(event.target) ||
                Object.values(this.combos).some(combo => combo.menu.contains(event.target));
            if (!this.panel.hidden && !inside) this.close();
        }, true);
        // The brain and terminals are frames: their pointer events cannot bubble here.
        // Defer until the browser updates activeElement; opening Claude in a new tab
        // must not close the dialog containing its authorization-code field.
        window.addEventListener('blur', () => setTimeout(() => {
            if (!this.panel.hidden && document.activeElement?.tagName === 'IFRAME' &&
                !this.panel.contains(document.activeElement)) this.close();
        }, 0));
        this.panel.addEventListener('keydown', event => {
            if (this.panel.hidden) return;
            if (event.key === 'Escape') {
                event.preventDefault(); event.stopImmediatePropagation(); this.close(true); return;
            }
            if (event.key === 'Tab') {
                const focusable = [...this.panel.querySelectorAll('button:not(:disabled), input:not(:disabled)')].filter(e => e.tabIndex >= 0 && e.getClientRects().length);
                const first = focusable[0], last = focusable.at(-1);
                if (event.shiftKey && document.activeElement === first) {event.preventDefault(); last.focus();}
                else if (!event.shiftKey && document.activeElement === last) {event.preventDefault(); first.focus();}
            }
        });
        window.addEventListener('resize', () => this.position());
        window.visualViewport?.addEventListener('resize', () => this.position());
        window.addEventListener('scroll', event => {if (!this.panel.contains(event.target)) this.position();}, true);
        const banner = document.getElementById('insecure-banner');
        if (banner && window.ResizeObserver) {
            this.bannerObserver = new ResizeObserver(() => this.position());
            this.bannerObserver.observe(banner);
        }
        this.render();
    }
    signature(value) {return JSON.stringify([value?.provider, value?.model, value?.effort]);}
    saved(role = this.role) {
        const value = this.state?.roles?.[role];
        return {provider: value?.provider, ...(value?.[value?.provider] || {})};
    }
    draft(roleName = this.role) {
        if (!this.state?.roles?.[roleName]) return null;
        if (!this.drafts[roleName]) {
            const role = this.state.roles[roleName];
            this.drafts[roleName] = {provider: role.provider, choices: structuredClone({codex: role.codex, claude: role.claude}), baseline: this.signature(this.saved(roleName)), dirty: false, feedback: ''};
        }
        return this.drafts[roleName];
    }
    selection(role = this.role) {
        const draft = this.draft(role);
        return draft ? {provider: draft.provider, ...draft.choices[draft.provider]} : {};
    }
    change(role, field, value) {
        const draft = this.draft(role);
        if (!draft) return;
        if (value === '__manual__') {
            draft.manual = true; this.role = role; this.open(); this.render(); this.get('manual').focus(); return;
        }
        if (field === 'provider') draft.provider = value;
        else {
            const choice = draft.choices[draft.provider];
            choice[field === 'name' ? 'model' : 'effort'] = value;
            if (field === 'name') {
                const model = this.models(draft.provider).find(m => m.model === value);
                if (!model && draft.provider === 'claude') choice.effort = 'default';
            }
        }
        draft.dirty = this.signature(this.selection(role)) !== draft.baseline;
        draft.feedback = ''; this.notice = ''; this.render();
    }
    models(provider) {return this.state?.catalog?.[provider] || [];}
    valid(selection, role) {
        const model = this.models(selection.provider).find(m => m.model === selection.model);
        if (model) return (model.lanes || Object.keys(LeonModelPreferences.roles)).includes(role) && model.efforts.includes(selection.effort);
        return selection.provider === 'claude' && this.state?.catalog?.manual?.claude?.enabled && /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$/.test(selection.model || '') && selection.effort === 'default';
    }
    dirtyRoles() {return Object.keys(LeonModelPreferences.roles).filter(role => this.drafts[role]?.dirty);}
    update(state) {
        this.loaded = true;
        this.available = !!state?.roles && !!state?.catalog;
        if (this.available && !this.saving) {
            this.state = state;
            for (const [role, draft] of Object.entries(this.drafts)) {
                if (!draft.dirty && (!draft.feedback || draft.baseline !== this.signature(this.saved(role)))) delete this.drafts[role];
            }
        }
        this.render();
        if (!this.panel.hidden && this.state?.catalog?.stale && !this.refreshAttempted && !this.refreshing) {
            this.refreshAttempted = true;
            this.refreshCatalog();
        }
    }
    options(button, values, selected, label = value => value) {
        const items = values.map(value => typeof value === 'string' ? {value, label: label(value)} : value);
        if (!items.some(item => item.value === selected)) items.unshift({value: selected || '', label: selected ? 'Unavailable: ' + label(selected) : 'Choose a supported option', disabled: true});
        this.combos[button.id].setOptions(items, selected);
    }
    modelOptions(provider, role, selection) {
        const items = this.models(provider).map(model => ({value: model.model, label: model.display_name || model.model,
            detail: [model.model, model.unavailable_reason || model.description].filter(Boolean).join(' · '),
            disabled: !(model.lanes || Object.keys(LeonModelPreferences.roles)).includes(role)}));
        if (provider === 'claude' && this.state?.catalog?.manual?.claude?.enabled) {
            if (selection.model && !items.some(item => item.value === selection.model)) items.unshift({value: selection.model, label: selection.model, detail: 'Manual ID · unverified account access and capabilities'});
            items.push({value: '__manual__', label: 'Enter a model ID…', detail: 'Manual ID · unverified until the provider accepts a launch'});
        }
        return items;
    }
    renderFields(prefix, role) {
        const get = field => document.getElementById(prefix + field), selection = this.selection(role);
        this.options(get('provider'), ['codex', 'claude'], selection.provider, v => v === 'codex' ? 'Codex (OpenAI)' : 'Claude (Anthropic)');
        this.options(get('name'), this.modelOptions(selection.provider, role, selection), selection.model);
        const model = this.models(selection.provider).find(m => m.model === selection.model);
        const efforts = model?.efforts || (selection.provider === 'claude' ? ['default'] : []);
        this.options(get('effort'), efforts, selection.effort, v => LeonModelPreferences.efforts[v] || v);
        ['provider', 'name', 'effort'].forEach(field => get(field).disabled = this.saving || !this.available || (field === 'effort' && efforts.length === 1));
        return model;
    }
    description(value) {
        return [value.provider === 'codex' ? 'Codex' : value.provider === 'claude' ? 'Claude' : 'Unknown provider', value.model || 'No model selected', LeonModelPreferences.efforts[value.effort] || value.effort || 'No reasoning selected'].join(' · ');
    }
    render() {
        const label = LeonModelPreferences.roles[this.role];
        this.tabs.forEach(tab => {
            const active = tab.dataset.role === this.role;
            tab.setAttribute('aria-selected', String(active)); tab.tabIndex = active ? 0 : -1; tab.disabled = this.saving;
        });
        this.get('heading').textContent = label + ' preferences';
        this.get('form').setAttribute('aria-labelledby', 'cu-model-tab-' + this.role + ' cu-model-heading');
        const selection = this.selection();
        const draft = this.draft();
        const model = this.renderFields('cu-model-', this.role);
        const manual = selection.provider === 'claude' && (!!draft?.manual || (!!selection.model && !model));
        this.get('manual-row').hidden = !manual;
        if (document.activeElement !== this.get('manual')) this.get('manual').value = selection.model || '';
        this.get('manual').disabled = this.saving || !this.available;
        const metadata = this.state?.catalog?.providers?.[selection.provider];
        this.get('catalog').textContent = (manual && !model ? 'Manual ID: unverified account access and capabilities. ' : '') + (metadata ? `${metadata.stale ? 'Stale' : 'Fresh'} catalog · ${metadata.catalog_at ? new Date(metadata.catalog_at * 1000).toLocaleString() : 'No successful discovery'} · ${metadata.source}. ${metadata.error || 'Advertised models; entitlement is checked on launch.'}` : 'Catalog provenance unavailable.');
        const dirtyRoles = this.dirtyRoles();
        const invalidRoles = dirtyRoles.filter(role => !this.valid(this.selection(role), role));
        this.get('save').disabled = this.saving || !this.available || !dirtyRoles.length || !!invalidRoles.length;
        this.get('selected').textContent = 'Selection: ' + this.description(selection) + (draft?.dirty ? ' · Unsaved' : '');
        this.get('saved').textContent = this.state ? 'Saved: ' + this.description(this.saved()) : 'Saved preferences are loading…';
        const next = this.state?.roles?.[this.role]?.next_provider;
        this.get('next').textContent = next && next !== this.saved().provider ? 'Next launch routes to ' + this.description({provider: next, ...this.state.roles[this.role][next]}) + '.' : '';
        const loaded = this.state?.effective?.[this.role];
        this.get('effective').textContent = loaded ? 'Last launched (requested): ' + this.description(loaded) + ' · ' + new Date(loaded.loaded_at * 1000).toLocaleString() + (loaded.effective_model ? ' · Effective: ' + loaded.effective_model : ' · Effective model: unknown') + (loaded.error ? ' · ' + loaded.error : '') : 'Last launched: no launch recorded for this role.';
        if (loaded) this.get('effective').textContent += ' · Tokens: ' + (loaded.usage?.input_tokens ?? 'unknown') + ' in / ' + (loaded.usage?.output_tokens ?? 'unknown') + ' out · Elapsed: ' + (Number.isFinite(loaded.elapsed_s) ? loaded.elapsed_s.toFixed(1) + 's' : 'unknown');
        this.get('message').textContent = this.saving ? 'Saving changes…' : !this.available ? (this.state ? 'Settings are unreachable. Your selections are kept; retry when connected.' : this.loaded ? 'Model preferences are unavailable from this SI’s provider connection. Account connections are shown separately above.' : 'Loading model preferences…') : invalidRoles.length ? 'Unsupported model or reasoning for ' + invalidRoles.map(role => LeonModelPreferences.roles[role]).join(', ') + '. Choose supported options before saving.' : this.notice || draft?.feedback || (dirtyRoles.length ? 'Unsaved changes: ' + dirtyRoles.map(role => LeonModelPreferences.roles[role]).join(', ') + '.' : 'Saved preferences apply to the next turn or new task.');
        if (draft?.dirty && draft.baseline !== this.signature(this.saved())) this.get('message').textContent += ' Saved preferences changed elsewhere; your draft is kept.';
        this.get('overview').replaceChildren(...Object.keys(LeonModelPreferences.roles).map(role => {
            const line = document.createElement('div');
            line.textContent = LeonModelPreferences.roles[role] + ': ' + this.description(this.saved(role)) + (this.drafts[role]?.dirty ? ' · Unsaved draft' : '');
            return line;
        }));
        this.panel.setAttribute('aria-busy', String(this.saving));
        if (!this.panel.hidden) this.position();
    }
    switchRole(role) {if (!this.saving) {LeonGlassCombobox.active?.close(); this.role = role; this.render();}}
    open() {
        this.refreshAttempted = false;
        this.routeMenu.hidden = true;
        document.getElementById('cu-provider-mode').setAttribute('aria-expanded', 'false');
        this.panel.hidden = false; this.button.setAttribute('aria-expanded', 'true');
        this.render(); this.tabs.find(tab => tab.dataset.role === this.role).focus();
        if (!this.state) this.onSaved();
        else if (this.state.catalog?.stale) {this.refreshAttempted = true; this.refreshCatalog();}
    }
    close(focus = false) {LeonGlassCombobox.active?.close(); this.panel.hidden = true; this.button.setAttribute('aria-expanded', 'false'); if (focus) this.button.focus();}
    position() {
        if (this.phone.matches) {
            const banner = document.getElementById('insecure-banner');
            const bottom = banner && !banner.hidden ? banner.getBoundingClientRect().bottom + 8 : 0;
            this.controls.style.top = Math.max(16, bottom) + 'px';
        } else this.controls.style.removeProperty('top');
        const width = window.visualViewport?.width || innerWidth;
        const height = window.visualViewport?.height || innerHeight;
        const offset = window.visualViewport?.offsetTop || 0;
        for (const [popover, anchor] of [[this.panel, this.button], [this.routeMenu, document.getElementById('cu-provider-mode')]]) {
            if (popover.hidden) continue;
            const box = anchor.getBoundingClientRect();
            const top = Math.max(offset + 8, Math.min(box.bottom + 8, offset + height - 180));
            popover.style.left = Math.max(12, Math.min(box.left, width - popover.offsetWidth - 12)) + 'px';
            popover.style.top = top + 'px'; popover.style.maxHeight = Math.max(150, offset + height - top - 12) + 'px';
        }
    }
    async save() {
        const roles = this.dirtyRoles();
        if (this.saving || !this.available || !roles.length || roles.some(role => !this.valid(this.selection(role), role))) return;
        this.saving = true; this.notice = ''; this.render();
        const saved = [];
        try {
            for (const role of roles) {
                const selected = this.selection(role);
                const payload = {role, provider: selected.provider, model: selected.model, effort: selected.effort};
                const headers = {'Content-Type': 'application/json'};
                if (this.state.revision) headers['If-Match'] = this.state.revision;
                const response = await fetch('/api/provider/models/set', {method: 'POST', headers, body: JSON.stringify(payload), signal: AbortSignal.timeout(8000)});
                const value = await response.json();
                if (!response.ok || !value.roles || !value.catalog) throw new Error(value.error || 'Save was not confirmed.');
                this.state = value;
                const actual = {provider: value.roles[role]?.provider, ...value.roles[role]?.[payload.provider]};
                if (this.signature(actual) !== this.signature(payload)) throw new Error('The returned preferences differ from your selection. Review and retry.');
                delete this.drafts[role]; saved.push(LeonModelPreferences.roles[role]);
            }
            this.notice = 'Saved ' + saved.join(', ') + ' for the next turn or task.';
        } catch (error) {
            const reason = error.name === 'TimeoutError' || error.name === 'AbortError' ? 'confirmation timed out' : error.name === 'SyntaxError' || error.name === 'TypeError' ? 'save was not confirmed; retry when connected' : error.message || 'save failed';
            const failed = LeonModelPreferences.roles[roles[saved.length]];
            this.notice = (saved.length ? 'Saved ' + saved.join(', ') + '. ' : '') + failed + ' failed: ' + reason + '. Unsaved changes are kept for retry.';
        } finally {this.saving = false; this.render(); this.onSaved();}
    }
    async refreshCatalog() {
        if (this.refreshing || this.saving) return;
        this.refreshing = true; this.render();
        try {
            const response = await fetch('/api/provider/models/refresh', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}', signal: AbortSignal.timeout(150000)});
            const value = await response.json();
            if (!response.ok || !value.catalog || !value.roles) throw new Error(value.error || 'Catalog refresh was not confirmed.');
            this.update(value); this.onSaved();
        } catch (error) {
            this.notice = (error.message || 'Catalog refresh failed') + '; previous catalog and selections are kept.';
        } finally {this.refreshing = false; this.render();}
    }
}
