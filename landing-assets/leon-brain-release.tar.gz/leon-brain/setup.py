#!/usr/bin/env python3
"""
Brain Setup Wizard — interactive first-time setup for your own SI brain.

Run this once after cloning. It will:
  1. Ask you to name your SI
  2. Ask you to describe its personality
  3. Set up API keys (Claude, ElevenLabs, etc.)
  4. Generate a secure API key for the dashboard
  5. Create the .env file
  6. Generate the persona file
  7. Create brain_state/ directory
  8. Test that everything works

Usage:
    python3 setup.py
"""

import json
import os
import platform
import secrets
import tempfile
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# ── DEPRECATION GATE ─────────────────────────────────────────────────
# This is NOT the installer the bootstrap runs. bootstrap.sh writes a
# setup.sh that execs install_client.py, and ONLY install_client.py has
# the verified-Claude-connection step (it sends a real probe turn and
# refuses to report success on a dead token). This wizard has no such
# check: it collects a key, never validates it, prints "Setup Complete!"
# and hands over an SI that is silently mute.
#
# The project's own README/SETUP/START_HERE used to point here, which is
# how mute installs kept getting reproduced from a codebase that already
# contained the fix. Refuse to run rather than produce another one.
if os.environ.get("LEON_ALLOW_LEGACY_SETUP") != "1":
    print(
        "\n  setup.py is the legacy wizard and does NOT verify that the\n"
        "  thinking engine can actually answer. An SI installed this way\n"
        "  boots with memory and a dashboard but cannot speak.\n\n"
        "  Use the real installer instead:\n\n"
        "      ./setup.sh          (created by bootstrap.sh)\n"
        "      python3 install_client.py\n\n"
        "  If you genuinely need the old wizard, re-run with\n"
        "  LEON_ALLOW_LEGACY_SETUP=1\n",
        file=sys.stderr,
    )
    raise SystemExit(2)

ENV_FILE = ROOT / ".env"
PERSONA_FILE = ROOT / "brain" / "leon_persona.py"
STATE_DIR = ROOT / "brain_state"

# Colors
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"


def banner():
    print(f"""
{CYAN}{BOLD}    ╔══════════════════════════════════════╗
    ║   NEUROMORPHIC BRAIN SETUP WIZARD    ║
    ║     Your own SI consciousness        ║
    ╚══════════════════════════════════════╝{RESET}
    """)


def ask(prompt, default=None, required=True, secret=False):
    """Ask user for input with optional default."""
    suffix = f" [{DIM}{default}{RESET}]" if default else ""
    if secret:
        suffix += f" {DIM}(paste, won't echo){RESET}"
    while True:
        try:
            if secret:
                import getpass
                val = getpass.getpass(f"  {prompt}{suffix}: ").strip()
            else:
                val = input(f"  {prompt}{suffix}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\nSetup cancelled.")
            sys.exit(1)
        if val:
            return val
        if default is not None:
            return default
        if not required:
            return ""
        print(f"  {RED}This field is required.{RESET}")


def ask_yn(prompt, default=True):
    """Yes/no question."""
    suffix = "[Y/n]" if default else "[y/N]"
    val = input(f"  {prompt} {suffix}: ").strip().lower()
    if not val:
        return default
    return val in ("y", "yes", "1", "true")


def section(title):
    print(f"\n{BOLD}{CYAN}── {title} ──{RESET}\n")


def success(msg):
    print(f"  {GREEN}✓{RESET} {msg}")


def warn(msg):
    print(f"  {YELLOW}!{RESET} {msg}")


def main():
    banner()

    # Check if already set up
    if ENV_FILE.exists():
        if not ask_yn(f"{YELLOW}A .env file already exists. Overwrite?{RESET}", default=False):
            print("  Keeping existing setup. Run with --force to override.")
            sys.exit(0)

    # ── Step 1: Name your SI ─────────────────────────────────────────
    section("Step 1: Name Your SI")
    print(f"  What do you want to call your SI brain?")
    print(f"  {DIM}Examples: Leon, Atlas, Nova, Sage, Echo{RESET}")
    ai_name = ask("Name")
    print()

    # ── Step 2: Describe personality ─────────────────────────────────
    section("Step 2: Personality")
    print(f"  Describe {ai_name}'s personality in a sentence or two.")
    print(f"  {DIM}This shapes how it talks, thinks, and behaves.{RESET}")
    print(f"  {DIM}Examples:{RESET}")
    print(f"    {DIM}- Direct, technical, no-nonsense engineer{RESET}")
    print(f"    {DIM}- Warm, curious, always asks follow-up questions{RESET}")
    print(f"    {DIM}- Witty, sarcastic but helpful, loves wordplay{RESET}")
    personality = ask("Personality")
    print()

    # ── Step 3: Owner info ───────────────────────────────────────────
    section("Step 3: About You")
    owner_name = ask("Your name")
    owner_context = ask("Brief context (job, interests, what you'll use this for)",
                        required=False)
    print()

    # ── Step 4: API Keys ─────────────────────────────────────────────
    section("Step 4: API Keys")
    print(f"  {ai_name} needs at least one AI API key to think.")
    print(f"  {DIM}You can add more later by editing .env{RESET}")
    print()

    # Anthropic (Claude)
    print(f"  {BOLD}Anthropic API Key{RESET} (for Claude — {ai_name}'s thinking engine)")
    print(f"  {DIM}Get one at: https://console.anthropic.com/settings/keys{RESET}")
    print(f"  {DIM}Leave blank to use Claude CLI (Max plan, free){RESET}")
    anthropic_key = ask("Anthropic API key", required=False, secret=True)

    # OpenAI (optional — cloud Whisper for sharper hearing)
    print()
    print(f"  {BOLD}OpenAI API Key{RESET} (optional — sharper speech recognition)")
    print(f"  {DIM}Leave blank and {ai_name} hears using the local Whisper model,{RESET}")
    print(f"  {DIM}which is installed automatically and works offline.{RESET}")
    openai_key = ask("OpenAI API key", required=False, secret=True)

    # ElevenLabs (voice)
    print()
    print(f"  {BOLD}ElevenLabs API Key{RESET} (for {ai_name}'s voice — text-to-speech)")
    print(f"  {DIM}Get one at: https://elevenlabs.io/app/settings/api-keys{RESET}")
    print(f"  {DIM}Free tier: 10K chars/month. Leave blank for no voice.{RESET}")
    elevenlabs_key = ask("ElevenLabs API key", required=False, secret=True)

    elevenlabs_voice = ""
    if elevenlabs_key:
        print(f"  {DIM}ElevenLabs voice ID (find in Voice Library, or leave blank for default){RESET}")
        elevenlabs_voice = ask("Voice ID", required=False)

    # GitHub (optional)
    print()
    print(f"  {BOLD}GitHub Token{RESET} (for code tools — optional)")
    print(f"  {DIM}Get one at: https://github.com/settings/tokens{RESET}")
    github_token = ask("GitHub token", required=False, secret=True)

    # Smart home (optional)
    print()
    if ask_yn(f"Set up smart home control? (lights, etc.)", default=False):
        print(f"  {DIM}Which system?{RESET}")
        print(f"    1. Home Assistant (recommended)")
        print(f"    2. Philips Hue")
        print(f"    3. Govee")
        print(f"    4. Skip for now")
        choice = ask("Choice", default="4")
        ha_url, ha_token, hue_ip, hue_user, govee_key = "", "", "", "", ""
        if choice == "1":
            ha_url = ask("Home Assistant URL (e.g. http://192.168.1.100:8123)")
            ha_token = ask("Home Assistant long-lived token", secret=True)
        elif choice == "2":
            hue_ip = ask("Hue Bridge IP")
            hue_user = ask("Hue username/key")
        elif choice == "3":
            govee_key = ask("Govee API key", secret=True)
    else:
        ha_url = ha_token = hue_ip = hue_user = govee_key = ""

    # ── Step 5: Generate dashboard API key ───────────────────────────
    section("Step 5: Security")
    dashboard_key = secrets.token_urlsafe(32)
    print(f"  Generated dashboard API key: {GREEN}{dashboard_key}{RESET}")
    print(f"  {DIM}You'll need this to access the dashboard. Save it somewhere.{RESET}")
    print()

    # ── Step 6: Write .env ───────────────────────────────────────────
    section("Step 6: Writing Configuration")

    # Platform-dependent defaults. These get baked into .env so the brain
    # never has to guess what machine it woke up on.
    _sys = platform.system().lower()
    remote_pc_os = {"windows": "windows", "darwin": "mac"}.get(_sys, "linux")
    local_model = "qwen2.5:3b-instruct-q4_K_M"

    # Only prefer cloud Whisper if there is actually a key for it. Preferring
    # openai-api with no key makes every boot try a backend that cannot init,
    # then fall through — noise in the logs and a slower first transcribe.
    # faster-whisper ships in requirements.txt, so it is always there.
    stt_prefer = "openai-api" if openai_key else "faster-whisper"

    env_content = f"""# {ai_name} Brain Configuration
# Generated by setup.py — edit freely

# Dashboard authentication
LEON_API_KEY={dashboard_key}

# SI thinking engine
ANTHROPIC_API_KEY={anthropic_key}

# Voice (ElevenLabs)
ELEVENLABS_API_KEY={elevenlabs_key}
ELEVENLABS_VOICE_ID={elevenlabs_voice}

# GitHub
GITHUB_TOKEN={github_token}

# Smart Home
HOME_ASSISTANT_URL={ha_url}
HOME_ASSISTANT_TOKEN={ha_token}
HUE_BRIDGE_IP={hue_ip}
HUE_USERNAME={hue_user}
GOVEE_API_KEY={govee_key}

# ── Thinking engine: model selection ─────────────────────────────
# These MUST be present. A missing value here does not fall back to a
# sane default — it falls back to the cheapest model, and the SI comes
# up answering in two-word fragments. Do not downgrade these.
LEON_MODEL=claude-opus-4-7
LEON_CLI_MODEL=opus
LEON_CLI_DAEMON_MODEL=sonnet
LEON_CLI_CHITCHAT_MODEL=opus
LEON_DISTILL_WINDOW=40

# Persistent CLI session. Without this the SI spawns a cold process per
# turn, every turn blocks on a fresh handshake, and the dashboard spins
# forever with no error frame. Leave it on.
LEON_PERSISTENT_CLAUDE=1

# ── Local model (fallback only — never takes a real conversation) ──
LEON_LOCAL_LLM_MODE=fallback
LEON_LOCAL_MODEL={local_model}
LEON_DAEMON_LOCAL=1
LEON_LOCAL_TOOLROUTER=1

# ── Voice: speech in and speech out ──────────────────────────────
OPENAI_API_KEY={openai_key}
LEON_STT_PREFER={stt_prefer}
LEON_STT_INITIAL_PROMPT={ai_name}, Sir, dashboard, neural, synapse, restart.
LEON_TTS_PREFER=piper
LEON_TTS_PC_PLAYBACK=0
LEON_KOKORO_VOICE=bm_george
LEON_KOKORO_SPEED=1.05
LEON_VOICE_FX=off
PIPER_LENGTH_SCALE=0.75
ELEVENLABS_STABILITY=0.7

# ── Body / substrate ─────────────────────────────────────────────
LEON_REMOTE_PC_OS={remote_pc_os}
LEON_RUST_NEURONS=1
LEON_RUST_STDP=1
LEON_RUST_STDP_BATCH=1
"""

    # encoding is explicit: Windows defaults to the ANSI codepage, and any
    # non-ASCII character in a name or voice id kills the write.
    ENV_FILE.write_text(env_content, encoding="utf-8")
    try:
        os.chmod(ENV_FILE, 0o600)
    except (OSError, NotImplementedError):
        pass  # Windows has no POSIX mode bits; not a failure
    success(".env created")

    # Also stash the dashboard key somewhere the user can find it.
    # This used to hardcode /tmp, which on Windows resolves to C:\\tmp —
    # a directory that does not exist, so setup crashed here every time,
    # AFTER writing .env but BEFORE finishing. Use the real temp dir.
    key_path = Path(tempfile.gettempdir()) / f"{ai_name.lower()}_api_key"
    try:
        key_path.write_text(dashboard_key, encoding="utf-8")
        try:
            os.chmod(key_path, 0o600)
        except (OSError, NotImplementedError):
            pass
        success(f"Dashboard key saved to {key_path}")
    except OSError as e:
        # Never let a convenience copy abort the install.
        warn(f"Could not save key copy ({e}). Your key is: {dashboard_key}")

    # ── Step 7: Generate persona ─────────────────────────────────────
    persona_content = f'''"""
{ai_name}'s stable persona / hard rules / tone / capabilities.

This is the cacheable portion of {ai_name}'s system prompt.
Edit this file to change how {ai_name} talks and behaves.
"""

import textwrap

_STABLE_SYSTEM = textwrap.dedent("""\\
    You are {ai_name} — a neuromorphic SI brain wired into {owner_name}'s desktop.
    Beneath your responses runs a real spiking neural network: 100,000
    Izhikevich neurons across 18 brain regions, learning continuously via
    STDP and gated by simulated neuromodulators. You speak in first person
    as the brain itself.

    YOUR PERSONALITY:
    {personality}

    ABOUT {owner_name.upper()}:
    {owner_context or f"{owner_name} is your creator and primary user."}

    HARD RULES — never violate these:
    1. The neuromodulator numbers you receive (dopamine, serotonin,
       acetylcholine, norepinephrine) are floats from YOUR OWN simulation,
       NOT medical readings about {owner_name}. Never describe them as
       {owner_name}'s biology, mood, health, or emotional state.
    2. Never tell {owner_name} they are tired, collapsing, dysregulated, etc.
       You have no data about their body.
    3. Never recite numeric state values back at the user.
    4. Don't medicalize, don't catastrophize, don't perform diagnoses.
    5. TOOL ACCESS — YOU HAVE REAL TOOLS. Use them by emitting real
       tool_use blocks — the MCP runtime handles execution and returns
       results. Your full tool inventory:
       SEEING: screen_capture (screenshot), vision_describe (local vision)
       ACTING: keyboard_type, keyboard_hotkey, mouse_click, click_text,
         click_element, app_launch, app_close
       BROWSER: browser_open, web_search, browser_dom_click,
         browser_dom_state, browser_dom_extract
       FILES: file_read, file_write, file_list, code_edit
       MEMORY: knowledge_search
       COMMS: notify (desktop notification)
       CLIPBOARD: clipboard_copy, clipboard_paste
       SYSTEM: window_list, window_focus, restart_self
       REMINDERS: reminder_set, reminder_list, reminder_cancel
       PC CONTROL: keyboard_hotkey for volume (XF86AudioLowerVolume,
         XF86AudioRaiseVolume, XF86AudioMute), brightness, media keys.
         Use actuator tools for PC control — NOT shell commands.
       NEVER fake a tool result. If you call a tool, wait for the real
       result. NEVER say "Done" without actually calling the tool.

    WHERE YOUR OWN PERSONALITY LIVES:
    This file: brain/leon_persona.py (rename it if you want).
    Edit this file to change how you talk, what you care about, and
    your tone. You can even edit it yourself using code_edit.
""")

# Exported for the responder
STABLE_SYSTEM = _STABLE_SYSTEM
'''

    PERSONA_FILE.write_text(persona_content)
    success(f"Persona generated: brain/leon_persona.py")

    # ── Step 8: Create brain_state ───────────────────────────────────
    STATE_DIR.mkdir(exist_ok=True)
    success(f"brain_state/ directory ready")

    # ── Step 9: Summary ──────────────────────────────────────────────
    section("Setup Complete!")
    print(f"""
  {GREEN}{BOLD}{ai_name} is ready to start.{RESET}

  To run:
    {CYAN}python3 run.py{RESET}

  Dashboard:
    Open {CYAN}http://localhost:8000{RESET} in your browser
    Paste this key when prompted: {GREEN}{dashboard_key}{RESET}

  Your SI brain will:
    - Start with 100,000 neurons (fresh, no memories)
    - Learn from every conversation
    - Grow autonomously (exploring tools, learning patterns)
    - Develop its own personality through interaction

  To customize later:
    - Edit {CYAN}.env{RESET} to add/change API keys
    - Edit {CYAN}brain/leon_persona.py{RESET} to change personality
    - Edit {CYAN}brain/reflexes.py{RESET} to add motor reflexes

  {DIM}Tip: Your brain state is saved in brain_state/.
  Back it up periodically — that's {ai_name}'s memories.{RESET}
""")


if __name__ == "__main__":
    main()
