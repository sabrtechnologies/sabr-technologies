#!/usr/bin/env python3
"""
PC Relay — bridges the actuator Unix socket to a TCP port for remote access.
Listens on a TCP port and forwards JSON-RPC calls to /tmp/leon-actuator.sock

Usage:
    python3 pc_relay.py --port 9100 --bind 127.0.0.1
    python3 pc_relay.py --port 9100 --bind 0.0.0.0
"""

import argparse
import json
import socket
import sys
import threading
import time
from typing import Optional

SOCKET_PATH = "/tmp/leon-actuator.sock"
BUFFER_SIZE = 65536

def forward_to_socket(data: bytes) -> bytes:
    """Connect to Unix socket, send data, receive response."""
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(SOCKET_PATH)
        sock.sendall(data)
        response = b""
        while True:
            chunk = sock.recv(BUFFER_SIZE)
            if not chunk:
                break
            response += chunk
        sock.close()
        return response
    except Exception as e:
        error_resp = {
            "jsonrpc": "2.0",
            "error": {"code": -32603, "message": str(e)},
            "id": None
        }
        return json.dumps(error_resp).encode() + b"\n"

def handle_client(client_sock: socket.socket, addr: str):
    """Handle a single client connection."""
    try:
        # Read request (expect single JSON-RPC call)
        request = b""
        while True:
            chunk = client_sock.recv(BUFFER_SIZE)
            if not chunk:
                break
            request += chunk
            # Check if we have a complete JSON-RPC message (ends with \n)
            if b"\n" in request:
                break

        if request:
            # Forward to socket
            response = forward_to_socket(request)
            client_sock.sendall(response)
    except Exception as e:
        print(f"Error handling client {addr}: {e}", file=sys.stderr)
    finally:
        client_sock.close()

def main():
    parser = argparse.ArgumentParser(description="PC Relay — Unix socket to TCP bridge")
    parser.add_argument("--port", type=int, default=9100, help="TCP port to listen on")
    parser.add_argument("--bind", type=str, default="127.0.0.1", help="Address to bind to")
    args = parser.parse_args()

    # Create TCP server socket
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    try:
        server_sock.bind((args.bind, args.port))
        server_sock.listen(5)
        print(f"PC Relay listening on {args.bind}:{args.port} -> {SOCKET_PATH}", file=sys.stderr)

        while True:
            try:
                client_sock, addr = server_sock.accept()
                addr_str = f"{addr[0]}:{addr[1]}"
                # Handle in background thread so we don't block on one client
                thread = threading.Thread(target=handle_client, args=(client_sock, addr_str), daemon=True)
                thread.start()
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Error accepting connection: {e}", file=sys.stderr)
    except Exception as e:
        print(f"Failed to bind to {args.bind}:{args.port}: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        server_sock.close()

if __name__ == "__main__":
    main()
