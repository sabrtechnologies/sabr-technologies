# Leon PC Bridge Setup — connects PC body to VPS brain
# This script configures the PC as a remote actuator connected to the VPS brain
# Usage: powershell -ExecutionPolicy Bypass -File pc-bridge-setup.ps1

$VPS_TAILSCALE_IP = $env:LEON_BRAIN_HOST
$VPS_BRAIN_PORT = 8000
$LOCAL_BRIDGE_PORT = 9100
$LEON_DIR = "$env:USERPROFILE\leon-brain"
$ACTUATOR_LOG = "$LEON_DIR\actuator.log"

Write-Host "Leon PC Bridge Setup — connecting body to brain"
Write-Host "VPS Brain: $VPS_TAILSCALE_IP`:$VPS_BRAIN_PORT"
Write-Host "Local Bridge: localhost`:$LOCAL_BRIDGE_PORT"
Write-Host ""

# 1) Create a config that tells the brain where it is
$config = @"
{
  "is_body": true,
  "brain_host": "$VPS_TAILSCALE_IP",
  "brain_port": $VPS_BRAIN_PORT,
  "local_port": $LOCAL_BRIDGE_PORT,
  "mode": "remote_actuator"
}
"@

$configPath = "$LEON_DIR\config.json"
Write-Host "[1] Writing bridge config to $configPath"
$config | Out-File -FilePath $configPath -Encoding UTF8
Write-Host "    Done. Bridge will connect to $VPS_TAILSCALE_IP`:$VPS_BRAIN_PORT"

# 2) Create a launcher script that connects to the VPS brain
$launcher = @"
#!/usr/bin/env python3
import os
import sys
import json
import subprocess
import time
import socket

# Load config
config_path = os.path.join(os.path.expanduser("~"), "leon-brain", "config.json")
with open(config_path) as f:
    config = json.load(f)

brain_host = config["brain_host"]
brain_port = config["brain_port"]
local_port = config["local_port"]

print(f"[BRIDGE] Connecting {brain_host}:{brain_port} <- localhost:{local_port}")

# Check if the brain is reachable
def check_brain():
    try:
        s = socket.create_connection((brain_host, brain_port), timeout=2)
        s.close()
        return True
    except:
        return False

# Wait for brain to be reachable
attempts = 0
while attempts < 30:
    if check_brain():
        print(f"[BRIDGE] Brain is reachable")
        break
    attempts += 1
    print(f"[BRIDGE] Waiting for brain... ({attempts}/30)")
    time.sleep(1)

if attempts == 30:
    print(f"[BRIDGE] Brain not reachable after 30s — giving up")
    sys.exit(1)

# Now start the actuator, which will connect to the VPS brain via the local bridge port
# The actuator looks for the brain at localhost:9100 (or whatever LEON_BRAIN_URL is set to)
os.environ["LEON_BRAIN_URL"] = f"http://localhost:{local_port}"
os.environ["LEON_API_KEY"] = os.environ.get("LEON_API_KEY", "")

actuator_path = os.path.join(os.path.dirname(__file__), "leon-actuator", "actuator.py")
if os.path.exists(actuator_path):
    print(f"[BRIDGE] Starting actuator at {actuator_path}")
    # Run actuator in foreground
    os.execv(sys.executable, [sys.executable, actuator_path])
else:
    print(f"[BRIDGE] ERROR: actuator.py not found at {actuator_path}")
    sys.exit(1)
"@

$launcherPath = "$LEON_DIR\start-as-body.py"
Write-Host "[2] Writing actuator launcher to $launcherPath"
$launcher | Out-File -FilePath $launcherPath -Encoding UTF8
Write-Host "    Done"

# 3) Create a Windows batch script that starts the SSH tunnel and actuator
$batchScript = @"
@echo off
REM Leon Body Launcher — starts SSH tunnel to VPS and then actuator
setlocal enabledelayedexpansion

set VPS_IP=$VPS_TAILSCALE_IP
set VPS_PORT=$VPS_BRAIN_PORT
set LOCAL_PORT=$LOCAL_BRIDGE_PORT
set LEON_DIR=%USERPROFILE%\leon-brain

echo [BATCH] Starting Leon as PC body...
echo [BATCH] Tunneling VPS %VPS_IP%:%VPS_PORT% to localhost:%LOCAL_PORT%

REM Start SSH tunnel in background using plink (PuTTY) or natively if available
REM For now, assume Python and the launcher will handle the connection
cd /d %LEON_DIR%
python start-as-body.py

if errorlevel 1 (
    echo [BATCH] Actuator failed with code !errorlevel!
    pause
    exit /b 1
)
"@

$batchPath = "$LEON_DIR\start-as-body.bat"
Write-Host "[3] Writing batch launcher to $batchPath"
$batchScript | Out-File -FilePath $batchPath -Encoding UTF8
Write-Host "    Done"

# 4) Set up auto-start via Task Scheduler
Write-Host "[4] Setting up auto-start task..."
$taskName = "Leon-Body-Auto-Start"
$taskPath = "\Leon\"

# Check if task already exists
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($task) {
    Write-Host "    Removing old task..."
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false | Out-Null
}

$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c cd $LEON_DIR && python start-as-body.py >> $ACTUATOR_LOG 2>&1"
$trigger = New-ScheduledTaskTrigger -AtLogOn
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Write-Host "    Task '$taskName' registered for auto-start at login"

Write-Host ""
Write-Host "[OK] Bridge setup complete!"
Write-Host "     PC is now configured as a remote body connected to the VPS brain."
Write-Host "     Auto-start task will launch on next login."
Write-Host "     Log: $ACTUATOR_LOG"
Write-Host ""
Write-Host "To start manually: cd $LEON_DIR && python start-as-body.py"
