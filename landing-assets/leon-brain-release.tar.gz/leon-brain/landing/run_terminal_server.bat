@echo off
REM Leon Terminal Server Launcher for Windows
REM Double-click this file to start the terminal server on port 8200

echo Installing websockets if needed...
pip install websockets >nul 2>&1

echo Starting Leon terminal server...
python3 "%~dp0leon_body_term_windows.py"

pause
