@echo off
REM Leon Terminal Server Setup - Self-contained for Windows
setlocal enabledelayedexpansion

echo Installing websockets library...
pip install websockets -q

echo Creating Leon terminal server...
set "SCRIPT_PATH=%TEMP%\leon_term.py"

(
echo import asyncio, json, os, sys, struct, urllib.parse, ctypes, ctypes.wintypes
echo from ctypes import windll, WINFUNCTYPE, c_void_p, c_int, c_uint, c_bool
echo from websockets.asyncio.server import serve
echo import subprocess, time
echo.
echo kernel32 = windll.kernel32
echo WORKDIR = os.getcwd^(^)
echo PORT = 8200
echo.
echo class COORD^(ctypes.Structure^):
echo     _fields_ = [^("X", ctypes.c_short^), ^("Y", ctypes.c_short^)]
echo.
echo class ConPTYSession:
echo     def __init__^(self, name^):
echo         self.name = name
echo         self.process = None
echo     def create^(self^):
echo         try:
echo             self.process = subprocess.Popen^("cmd.exe", stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE^)
echo             return True
echo         except:
echo             return False
echo.
echo sessions = {}
echo.
echo async def handle^(ws^):
echo     session_id = "main"
echo     if session_id not in sessions:
echo         session = ConPTYSession^(session_id^)
echo         if not session.create^(^):
echo             await ws.send^(b"Terminal failed"^)
echo             return
echo         sessions[session_id] = session
echo     try:
echo         async for message in ws:
echo             try:
echo                 cmd = json.loads^(message^)
echo                 if cmd.get^("type"^) == "input":
echo                     session.process.stdin.write^(cmd.get^("data", ""^).encode^(^)^)
echo                     session.process.stdin.flush^(^)
echo             except:
echo                 pass
echo     except:
echo         pass
echo.
echo async def main^(^):
echo     print^(f"Leon terminal server on port {PORT}"^)
echo     async with serve^(handle, "0.0.0.0", PORT^):
echo         print^(f"Listening on 0.0.0.0:{PORT}"^)
echo         await asyncio.Future^(^)
echo.
echo if __name__ == "__main__":
echo     asyncio.run^(main^(^)^)
) > "!SCRIPT_PATH!"

echo Starting Leon terminal server...
python "!SCRIPT_PATH!"

pause
