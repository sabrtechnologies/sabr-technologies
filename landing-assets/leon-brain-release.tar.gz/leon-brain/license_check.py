"""
License validation — checks with Sabr license server on startup.

If LEON_LICENSE_KEY is set in .env, the brain validates its license
before starting. If the license server is unreachable, a 48-hour
grace period allows offline operation.

Skip entirely by not setting LEON_LICENSE_KEY (for development / Dean's
own instance).
"""

import hashlib
import json
import os
import platform
import socket
import time
import urllib.request
import urllib.error
import uuid

LICENSE_SERVER = os.environ.get("LICENSE_SERVER", "https://license.sabr.co")
LICENSE_KEY = os.environ.get("LEON_LICENSE_KEY", "").strip()
GRACE_FILE = os.path.join(os.path.dirname(__file__), "brain_state", ".license_grace")
GRACE_HOURS = 48


def _machine_id() -> str:
    """Generate a stable machine fingerprint."""
    parts = []
    # Hostname
    parts.append(socket.gethostname())
    # MAC address
    mac = uuid.getnode()
    parts.append(format(mac, '012x'))
    # Platform
    parts.append(platform.node())
    parts.append(platform.machine())
    # CPU count as a rough differentiator
    parts.append(str(os.cpu_count() or 0))

    raw = "|".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def _machine_name() -> str:
    return f"{platform.node()} ({platform.system()} {platform.machine()})"


def _validate_online(license_key: str, machine_id: str) -> dict:
    """Call the license server to validate."""
    data = json.dumps({
        "license_key": license_key,
        "machine_id": machine_id,
        "machine_name": _machine_name(),
    }).encode()

    req = urllib.request.Request(
        f"{LICENSE_SERVER}/api/license/validate",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        try:
            return json.loads(body)
        except Exception:
            return {"ok": False, "error": f"HTTP {e.code}: {body[:200]}"}
    except Exception as e:
        return {"ok": False, "error": f"Connection failed: {e}", "offline": True}


def _activate_online(license_key: str, machine_id: str) -> dict:
    """First-time activation."""
    data = json.dumps({
        "license_key": license_key,
        "machine_id": machine_id,
        "machine_name": _machine_name(),
    }).encode()

    req = urllib.request.Request(
        f"{LICENSE_SERVER}/api/license/activate",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        try:
            return json.loads(body)
        except Exception:
            return {"ok": False, "error": f"HTTP {e.code}: {body[:200]}"}
    except Exception as e:
        return {"ok": False, "error": f"Connection failed: {e}", "offline": True}


def _save_grace():
    """Save a grace period timestamp."""
    os.makedirs(os.path.dirname(GRACE_FILE), exist_ok=True)
    with open(GRACE_FILE, "w") as f:
        f.write(str(time.time()))


def _check_grace() -> bool:
    """Check if we're within the grace period."""
    if not os.path.exists(GRACE_FILE):
        return False
    try:
        with open(GRACE_FILE) as f:
            ts = float(f.read().strip())
        elapsed_hours = (time.time() - ts) / 3600
        if elapsed_hours < GRACE_HOURS:
            return True
        return False
    except Exception:
        return False


def check_license() -> bool:
    """
    Validate the license. Returns True if OK to proceed.

    If LEON_LICENSE_KEY is not set, returns True (dev mode).
    If license server is unreachable, allows 48-hour grace period.
    If license is invalid/expired, prints error and returns False.
    """
    if not LICENSE_KEY:
        # No license key = developer mode (Dean's own instance)
        return True

    mid = _machine_id()
    print(f"[LICENSE] Validating... (machine={mid[:12]}...)")

    # Try validation first
    result = _validate_online(LICENSE_KEY, mid)

    if result.get("ok"):
        _save_grace()  # Refresh grace period on success
        plan = result.get("plan", "unknown")
        print(f"[LICENSE] Valid — plan={plan}")
        return True

    # If it's a "not activated" error, try activation
    if "not activated" in result.get("error", "").lower():
        print("[LICENSE] First-time activation...")
        result = _activate_online(LICENSE_KEY, mid)
        if result.get("ok"):
            _save_grace()
            print(f"[LICENSE] Activated — welcome, {result.get('client_name', 'client')}!")
            return True

    # If offline, check grace period
    if result.get("offline"):
        if _check_grace():
            print(f"[LICENSE] Server unreachable — running on grace period ({GRACE_HOURS}h)")
            return True
        else:
            print("[LICENSE] Server unreachable and grace period expired.")
            print("[LICENSE] Connect to the internet and restart.")
            return False

    # License is explicitly invalid/expired
    error = result.get("error", "Unknown error")
    status = result.get("status", "")
    print(f"[LICENSE] DENIED — {error}")
    if status in ("canceled", "suspended"):
        print("[LICENSE] Your subscription is no longer active.")
        print("[LICENSE] Contact Sabr to renew: dean@sabr.co")
    return False
