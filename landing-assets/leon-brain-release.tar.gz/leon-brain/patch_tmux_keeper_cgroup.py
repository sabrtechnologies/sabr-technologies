#!/usr/bin/env python3
"""
PATCH — keep the tmux server (and Dean's terminals) alive across leon.service restarts.

PROBLEM
-------
The tmux server is currently running inside /system.slice/leon.service. Every time
leon.service restarts, systemd tears down that cgroup and kills the tmux server with
it -- taking every window in the `agents` session, i.e. all of Dean's terminals.

agents-tmux-keeper.service was created exactly to prevent this, but nothing ever
joins it. It has been up since boot running `sleep infinity` in an empty cgroup.

FIX
---
Move the tmux server process AND all of its descendants (the pane shells) into the
keeper's cgroup. Processes spawned afterwards inherit the keeper cgroup automatically,
so new windows are protected for free. leon.service restarts then leave tmux untouched.

Idempotent. Safe to run repeatedly. Applies:
  1. a live migration right now (optional -- see --no-live), and
  2. a source patch to server/routers/workspaces.py so it self-heals on every
     _ensure_agents_session() call, including after a cold boot.

USAGE
-----
    python3 patch_tmux_keeper_cgroup.py            # patch source + migrate live tmux
    python3 patch_tmux_keeper_cgroup.py --dry-run  # show what would change
    python3 patch_tmux_keeper_cgroup.py --no-live  # patch source only, don't touch running tmux

NOTE: the live migration writes pids into cgroup.procs. It does not stop, signal, or
restart anything -- no terminal should even flicker. But it does touch the process
Dean is typing in, so run it when he is not mid-command.
"""

import os
import re
import shutil
import subprocess
import sys
import time

REPO = "/opt/leon-brain"
TARGET = os.path.join(REPO, "server/routers/workspaces.py")
KEEPER_CGROUP = "/sys/fs/cgroup/system.slice/agents-tmux-keeper.service/cgroup.procs"

DRY = "--dry-run" in sys.argv
NO_LIVE = "--no-live" in sys.argv


# --------------------------------------------------------------------------
# the code we inject
# --------------------------------------------------------------------------

HELPER = '''
_KEEPER_CGROUP_PROCS = (
    "/sys/fs/cgroup/system.slice/agents-tmux-keeper.service/cgroup.procs"
)


def _pid_descendants(pid):
    """Return [pid, ...all descendants], parents before children."""
    out = [pid]
    frontier = [pid]
    seen = {pid}
    while frontier:
        nxt = []
        for p in frontier:
            try:
                with open("/proc/%d/task/%d/children" % (p, p)) as fh:
                    kids = [int(x) for x in fh.read().split()]
            except (OSError, ValueError):
                continue
            for k in kids:
                if k not in seen:
                    seen.add(k)
                    out.append(k)
                    nxt.append(k)
        frontier = nxt
    return out


def _reparent_tmux_to_keeper():
    """Move the tmux server out of leon.service's cgroup and into the keeper's.

    leon.service restarts destroy their own cgroup, which kills every process in
    it -- including the tmux server and therefore all of Dean's terminals.
    agents-tmux-keeper.service exists solely to hold them somewhere systemd will
    not sweep. Nothing ever joined it, so this does the joining.

    Children spawned after the move inherit the keeper cgroup, so future windows
    and panes are protected without further work. Best-effort and silent: a
    failure here must never break terminal launch.
    """
    if not os.path.exists(_KEEPER_CGROUP_PROCS):
        return False
    try:
        srv = subprocess.run(
            ["tmux", "display-message", "-p", "#{pid}"],
            capture_output=True, text=True, timeout=5,
        )
        if srv.returncode != 0 or not srv.stdout.strip():
            return False
        root = int(srv.stdout.strip())
    except Exception:
        return False

    try:
        with open("/proc/%d/cgroup" % root) as fh:
            if "agents-tmux-keeper" in fh.read():
                return True  # already safe
    except OSError:
        return False

    moved = 0
    for pid in _pid_descendants(root):
        try:
            with open(_KEEPER_CGROUP_PROCS, "w") as fh:
                fh.write("%d\\n" % pid)
            moved += 1
        except OSError:
            continue  # exited, or kernel refused -- keep going
    try:
        log.info("[WORKSPACES] tmux reparented to keeper cgroup (%d procs)", moved)
    except Exception:
        pass
    return moved > 0

'''

ANCHOR = "def _ensure_agents_session():"

# call sites inside _ensure_agents_session
OLD_EARLY = """        if has.returncode == 0:
            return True"""
NEW_EARLY = """        if has.returncode == 0:
            _reparent_tmux_to_keeper()
            return True"""

OLD_LATE = """        chk = subprocess.run(
            ["tmux", "has-session", "-t", _TMUX_SESSION],
            capture_output=True, timeout=5,
        )
        return chk.returncode == 0"""
NEW_LATE = """        chk = subprocess.run(
            ["tmux", "has-session", "-t", _TMUX_SESSION],
            capture_output=True, timeout=5,
        )
        if chk.returncode == 0:
            _reparent_tmux_to_keeper()
            return True
        return False"""


def fail(msg):
    print("FAILED: %s" % msg)
    sys.exit(1)


def patch_source():
    src = open(TARGET).read()

    if "_reparent_tmux_to_keeper" in src:
        print("source: already patched, skipping")
        return False

    if ANCHOR not in src:
        fail("anchor %r not found in %s -- file changed, re-check by hand" % (ANCHOR, TARGET))
    if OLD_EARLY not in src:
        fail("early-return block not found -- refusing to guess")
    if OLD_LATE not in src:
        fail("late-return block not found -- refusing to guess")

    new = src.replace(ANCHOR, HELPER.lstrip("\n") + "\n" + ANCHOR, 1)
    new = new.replace(OLD_EARLY, NEW_EARLY, 1)
    new = new.replace(OLD_LATE, NEW_LATE, 1)

    if DRY:
        print("source: would insert helper + 2 call sites (%d -> %d bytes)" % (len(src), len(new)))
        return False

    bak = TARGET + ".bak-tmuxcgroup-%d" % int(time.time())
    shutil.copy2(TARGET, bak)
    open(TARGET, "w").write(new)

    chk = subprocess.run([sys.executable, "-m", "py_compile", TARGET], capture_output=True, text=True)
    if chk.returncode != 0:
        shutil.copy2(bak, TARGET)
        fail("syntax check failed, reverted from %s\n%s" % (bak, chk.stderr))

    print("source: patched (backup: %s)" % bak)
    return True


def migrate_live():
    if not os.path.exists(KEEPER_CGROUP):
        print("live: keeper cgroup missing -- is agents-tmux-keeper.service running?")
        return
    r = subprocess.run(["tmux", "display-message", "-p", "#{pid}"],
                       capture_output=True, text=True)
    if r.returncode != 0 or not r.stdout.strip():
        print("live: no tmux server running, nothing to migrate")
        return
    root = int(r.stdout.strip())
    before = open("/proc/%d/cgroup" % root).read().strip()
    print("live: tmux server pid %d currently in %s" % (root, before))

    if "agents-tmux-keeper" in before:
        print("live: already in keeper cgroup, nothing to do")
        return
    if DRY:
        print("live: would move tmux server + descendants into keeper cgroup")
        return

    sys.path.insert(0, REPO)
    moved = 0
    pids = [root]
    frontier = [root]
    seen = {root}
    while frontier:
        nxt = []
        for p in frontier:
            try:
                kids = [int(x) for x in open("/proc/%d/task/%d/children" % (p, p)).read().split()]
            except (OSError, ValueError):
                continue
            for k in kids:
                if k not in seen:
                    seen.add(k); pids.append(k); nxt.append(k)
        frontier = nxt
    for pid in pids:
        try:
            with open(KEEPER_CGROUP, "w") as fh:
                fh.write("%d\n" % pid)
            moved += 1
        except OSError:
            continue
    after = open("/proc/%d/cgroup" % root).read().strip()
    print("live: moved %d/%d procs; tmux server now in %s" % (moved, len(pids), after))
    if "agents-tmux-keeper" not in after:
        print("live: WARNING -- server did not land in the keeper cgroup")


if __name__ == "__main__":
    if os.geteuid() != 0:
        fail("must run as root (writing cgroup.procs)")
    print("=== tmux keeper-cgroup patch %s===" % ("[DRY RUN] " if DRY else ""))
    patch_source()
    if NO_LIVE:
        print("live: skipped (--no-live)")
    else:
        migrate_live()
    print("done. verify with:  cat /proc/$(tmux display-message -p '#{pid}')/cgroup")
