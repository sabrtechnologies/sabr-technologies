"""
Update check — Sabr SI

WHY THIS WAS REWRITTEN (2026-08-10)
----------------------------------
The previous version checked for updates with `git fetch` / `git merge` against
a release branch. The shipped release tarball contains no .git directory — the
build excludes it — so on EVERY real customer machine the very first check was
`os.path.isdir(".git")`, which was False, and the function returned immediately.
Verified on a clean container install: no .git, and therefore no update has ever
been detected on any install that was not a developer checkout. It was dead code
wearing the shape of a feature.

WHAT IT DOES NOW
----------------
An install is identified by the sha256 of the release it was built from, which
bootstrap.sh writes to ~/leon-brain/.sabr-release after it has already verified
that digest. The published release advertises its digest in a .sha256 sidecar
next to the tarball. Different digest => a newer release exists.

WHAT IT DELIBERATELY DOES NOT DO
--------------------------------
It does not apply the update. Rewriting the tree underneath a running SI is how
you corrupt a mind mid-thought, and bootstrap.sh already does the safe version of
this properly — staging, digest verification, atomic swap, rollback, and it
carries .env and brain_state/ across. So this reports, and the owner runs one
command. Notify, don't surprise.

WHY IT ALSO KEEPS THE ANSWER (2026-09-06)
-----------------------------------------
check_for_updates() reports by calling print(), and run.py calls it exactly
once, at startup. On Windows the SI boots HIDDEN — no console is attached —
so those lines have been written to a handle nobody owns on every Windows
install we have ever shipped. The check ran, found the newer release, and
told no one. And being boot-only, an SI that stays up for three weeks never
learns about the release that shipped on day two.

So the answer is now kept as DATA rather than spent as output: update_status()
computes it, start_periodic_check() refreshes it on an interval, cached_status()
hands back the last copy with no network I/O, and server/routers/misc.py serves
it at GET /api/update/status — somewhere an owner can actually look. Nothing
here applies anything; that contract is unchanged and deliberate.

Skip entirely with LEON_AUTO_UPDATE=0.
"""

import os
import ssl
import threading
import time
import urllib.request

AUTO_UPDATE = os.environ.get("LEON_AUTO_UPDATE", "1").strip()
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
STAMP = os.path.join(PROJECT_ROOT, ".sabr-release")

SIDECAR_URLS = (
    "https://sabrtechnologies.com/landing-assets/leon-brain-release.tar.gz.sha256",
    "https://sabr-technologies-production.up.railway.app"
    "/landing-assets/leon-brain-release.tar.gz.sha256",
)
INSTALL_CMD = (
    "curl -fsSL https://sabrtechnologies.com/landing-assets/bootstrap.sh"
    " -o bootstrap.sh && bash bootstrap.sh"
)


def installed_release() -> str:
    """The digest this install was built from, or '' if unknown."""
    try:
        with open(STAMP, "r", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("release_sha256="):
                    return line.split("=", 1)[1].strip()
    except OSError:
        pass
    return ""


def published_release(timeout: float = 8.0) -> str:
    """The digest currently published, or '' if no source answered."""
    # TLS is required, exactly as in bootstrap.sh. A digest fetched over a link
    # anyone can rewrite is not evidence of anything.
    ctx = ssl.create_default_context()
    for url in SIDECAR_URLS:
        try:
            with urllib.request.urlopen(url, timeout=timeout, context=ctx) as r:
                first = r.read(256).decode("utf-8", "replace").split()
                if first and len(first[0]) == 64:
                    return first[0].strip().lower()
        except Exception:
            continue
    return ""


def check_for_updates() -> bool:
    """Report whether a newer release is published. Never modifies anything.

    Returns False always: the old contract was "True means restart to apply",
    and nothing here applies anything, so returning True would make run.py
    restart into the identical version forever.
    """
    # The licensing heartbeat rides this hook because it is the one piece of
    # phone-home machinery every install runs at boot (run.py calls this
    # before the server comes up). Armed BEFORE the LEON_AUTO_UPDATE=0 early
    # return on purpose: disabling update NOTICES must not disable licence
    # checks — setup-prompt writes LEON_AUTO_UPDATE=0 into every .env it
    # generates, which would otherwise turn the heartbeat off fleet-wide.
    # ensure_started() is idempotent, spawns a daemon thread (check now,
    # then daily), and check_in() itself can only ever write a state file —
    # see brain/license_heartbeat.py for the grace rules.
    try:
        from brain.license_heartbeat import ensure_started
        ensure_started()
    except Exception:
        pass  # a broken heartbeat must never block startup or updates

    if AUTO_UPDATE == "0":
        return False

    have = installed_release()
    if not have:
        # A developer checkout, or an install from before stamping existed.
        # Silence is right here — there is nothing trustworthy to compare.
        return False

    live = published_release()
    if not live or live == have:
        return False

    print("[UPDATE] A newer release of your SI is available.")
    print(f"[UPDATE]   installed:  {have[:12]}...")
    print(f"[UPDATE]   published:  {live[:12]}...")
    print("[UPDATE] Your memories, name and settings are carried across. To update:")
    print(f"[UPDATE]   {INSTALL_CMD}")
    return False


# =============================================================================
# Cached status — the notice a hidden process can still deliver
# =============================================================================
#
# Everything below is read-only and additive. check_for_updates() above is
# untouched on purpose: it is the hook the licensing heartbeat rides, and
# tests/test_license_heartbeat_client.py pins that contract.

#: Guards _STATUS. Held only around a dict swap and a dict copy — never
#: across the network call, or one slow sidecar fetch would block every
#: request that asks what version this box is on.
_STATUS_LOCK = threading.Lock()

#: Separate from _STATUS_LOCK so "is the thread up?" and "what did it find?"
#: can never wait on each other.
_LOOP_LOCK = threading.Lock()
_loop_started = False

#: Floor on the refresh interval. A caller passing 0 (or a config file that
#: parses to one) would otherwise turn every install in the fleet into a
#: tight loop against sabrtechnologies.com.
_MIN_INTERVAL_SEC = 3600.0

#: 'not checked yet' is deliberately an error string rather than "": a
#: dashboard has to be able to tell "checked, you are current" apart from
#: "nothing has looked". Silence reads as good news, and here it is not news.
_STATUS = {
    "installed": "",
    "published": "",
    "stale": False,
    "checked_at": 0,
    "error": "not checked yet",
}


def _updates_enabled() -> bool:
    """Is the update-NOTICE path switched on?

    Two sources, on purpose. AUTO_UPDATE is the snapshot taken at import —
    the same value check_for_updates() gates on, and the one tests flip —
    while os.environ is re-read so a value exported after import is honoured
    too. Either saying "0" disables. This gate covers notices ONLY: the
    licensing heartbeat is armed before it inside check_for_updates() and
    must stay that way.
    """
    if AUTO_UPDATE == "0":
        return False
    return os.environ.get("LEON_AUTO_UPDATE", "1").strip() != "0"


def _is_digest(value: str) -> bool:
    """True only for something that could really be a sha256: 64 hex chars.

    "unknown", "", a half-written stamp file and an HTML error page that a
    captive-portal wifi served instead of the sidecar all fail this — and
    every one of them must read as "no evidence", never as "different from
    published", because different is exactly what makes us nag the owner.
    """
    v = (value or "").strip().lower()
    return len(v) == 64 and all(c in "0123456789abcdef" for c in v)


def update_status(timeout: float = 8.0) -> dict:
    """What this install knows about its own freshness. Never raises.

    Every key is always present, because callers (the HTTP endpoint, the
    dashboard, support scripts) branch on them and a missing key is a
    KeyError in somebody else's process:

        installed   sha256 this install was built from, "" if unknown
        published   sha256 currently advertised, "" if nothing answered
        stale       True only when both digests are known AND differ
        checked_at  unix seconds at which this dict was computed
        error       "" on success, a short human reason otherwise

    stale is a claim, and a claim needs evidence on both sides. A developer
    checkout has no .sabr-release, and an unreachable sidecar says nothing
    about the installed version — so both are stale=False. Telling a dev box
    it is out of date, or crying "update!" every time hotel wifi eats a
    request, is how a real notice gets trained into background noise.

    The published digest is fetched even when the installed one is unknown:
    it is one 64-byte GET, and "what is current" is worth answering to a
    fleet owner looking at a dev checkout.
    """
    problems = []
    status = {
        "installed": "",
        "published": "",
        "stale": False,
        "checked_at": int(time.time()),
        "error": "",
    }

    have = ""
    try:
        have = (installed_release() or "").strip().lower()
    except Exception as exc:
        # installed_release() catches OSError, but a stamp file full of
        # binary decodes into UnicodeDecodeError, which is not an OSError.
        problems.append(f"cannot read release stamp: {type(exc).__name__}")
    if _is_digest(have):
        status["installed"] = have

    live = ""
    try:
        live = (published_release(timeout=timeout) or "").strip().lower()
    except Exception as exc:
        # published_release() swallows per-URL failures, but building the
        # TLS context can fail before the loop is ever entered.
        problems.append(f"update check failed: {type(exc).__name__}")
    if _is_digest(live):
        status["published"] = live
    elif not live:
        problems.append("no release digest could be fetched")
    else:
        problems.append("published digest was not a sha256")

    status["stale"] = bool(
        status["installed"]
        and status["published"]
        and status["installed"] != status["published"]
    )
    status["error"] = "; ".join(problems)
    return status


def cached_status() -> dict:
    """The last computed status. Never touches the network.

    This is what the HTTP endpoint serves. A request must never be able to
    make the SI sit on a DNS lookup for sabrtechnologies.com — one hung
    handler is how a dashboard that was merely uninformative becomes a
    dashboard that is hung. A copy, not the live dict, because callers add
    fields to whatever they are handed.
    """
    with _STATUS_LOCK:
        return dict(_STATUS)


def refresh_status(timeout: float = 8.0) -> dict:
    """Recompute the status and publish it to the cache. Returns the copy."""
    global _STATUS
    fresh = update_status(timeout=timeout)
    with _STATUS_LOCK:
        _STATUS = fresh
    return dict(fresh)


def start_periodic_check(interval_hours: float = 6.0) -> bool:
    """Arm the one background refresh thread. Returns True only if it started.

    Idempotent: run.py calls it at boot, and anything else that decides it
    wants fresh status may call it too, without ever getting a second thread
    quietly doubling the fleet's request rate against the release host.

    Daemon, so it can never hold the process open at shutdown. It checks
    IMMEDIATELY before its first sleep — a laptop rebooted every evening
    would otherwise never reach the first interval, and /api/update/status
    would answer "not checked yet" forever on exactly the machines that
    reboot most.

    LEON_AUTO_UPDATE=0 means no thread at all: the switch exists to stop
    unsolicited network chatter. It does not stop anyone calling
    update_status() by hand, and it deliberately has no effect on the
    licensing heartbeat armed inside check_for_updates().
    """
    global _loop_started

    if not _updates_enabled():
        return False

    try:
        interval = max(float(interval_hours) * 3600.0, _MIN_INTERVAL_SEC)
    except (TypeError, ValueError):
        interval = 6 * 3600.0

    with _LOOP_LOCK:
        if _loop_started:
            return False
        _loop_started = True

    def _loop():
        while True:
            try:
                refresh_status()
            except Exception:
                # refresh_status() already swallows everything; this is the
                # belt for those braces. A dead update thread is invisible —
                # nothing watches it — so it must not be able to die.
                pass
            time.sleep(interval)

    try:
        threading.Thread(target=_loop, daemon=True, name="update-check").start()
    except Exception:
        # Thread creation can fail on an exhausted box. Losing the update
        # NOTICE is survivable; failing to boot the SI over it is not.
        with _LOOP_LOCK:
            _loop_started = False
        return False
    return True
