# Dashboard Settings and Windows audio

The header Integrations button beside Auto/Models opens the existing integrations popup. The bottom-left gear is now `settings-btn` and opens the separate liquid-glass Settings panel. The onboarding target follows the header Integrations button.

## Activation

Frontend assets are served directly from `/opt/leon-brain` on the Leon process at port **8000**. Port 8500 belongs to `/opt/license-server`; do not restart that service for this change. The dashboard asset version is `20261008-settings-v2`.

**The running Leon process was deliberately left untouched. The new settings/audio HTTP routes need a restart before PC audio, shared listening settings, account status, and server About information become available.** Until then, the panel explains this and disables PC/shared controls. Browser voice selection, reply mute, and appearance preferences work immediately after reloading the dashboard.

When Dean is clear of his guest and Leon authorizes the restart, restart the existing **`leon.service`**, whose current process is `python3 run.py` on port 8000. This job did not restart it. Reload the dashboard afterward. Check that authenticated `GET /api/settings` and `GET /api/audio/devices` return `ok: true`.

## Audio behavior

- PC output and microphone list only active Windows endpoints. `voice-audio` is the AR glasses; Realtek is the laptop. Disconnected AirPods are excluded; refresh after reconnecting them.
- Default-device changes affect Windows system audio. Microphone changes affect the Windows default; an already-recording application may need to reopen its microphone.
- Volume/mute requests include the observed default output ID. If Windows changed it in the meantime, the request fails and asks for a refresh rather than changing the wrong device.
- The SSH hop uses the existing VPS-to-laptop key authentication at `pazzo@100.97.136.115`, with a 12-second subprocess timeout, off the event loop. A unique hidden scheduled task runs a fixed PowerShell template in `DESKTOP-3AE6T26\pazzo`'s interactive session. It re-enumerates devices, validates the requested endpoint, skips no-op writes, verifies the result, atomically publishes JSON, and cleans up its task and temporary files. Dean must be signed in. Unreachable/offline/disconnected conditions return clear JSON errors.
- Leon's voice output is independent of the Windows default and is stored per browser in `leon-voice-sink`. The existing persistent audio element and shared AudioContext use `setSinkId` where supported. Permission/device loss temporarily falls back to system output without erasing the saved choice.
- Use current Chrome/Edge/Brave over HTTPS or localhost for browser output selection. Allow output devices uses `selectAudioOutput` when available; otherwise it requests microphone permission only to expose device labels and immediately stops the permission stream. Unsupported browsers explain the limitation and use system output.
- Test voice plays a quiet, half-second local tone through the selected output, at the dashboard voice volume. It refuses while Leon is speaking. **Do not click it during Dean's guest conversation. No audible test was performed in this job.**
- There is no automatic device pin: Windows may change its default when the glasses reconnect. Browser voice preference remains separate.

## Persistence and accounts

Reply speech reuses the existing browser mute store. Wake word and proactive speech reuse the existing real control endpoints; changes from those endpoints and Settings persist atomically under `brain_state/dashboard_settings.json` and restore after normal brain initialization. Nothing is written into `landing/`.

Reduced motion and glass intensity are browser-local preferences. Reduced motion suppresses CSS animation/transitions and the conversation/activity wobble transforms; the live memory visualization remains independent. Glass intensity adjusts the existing neutral `--lg-blur` and `--lg-tint` material.

Accounts projects only Claude/Codex authenticated catalog status and its last-check timestamp from the existing provider relay. A catalog is not a fresh sign-in check; unavailable/failed metadata is labeled unverified. OpenAI API health uses the existing credential-health tool's read-only models probe with a bounded timeout. Secrets/tokens and usage totals are never returned. API keys & integrations opens the existing key manager. No new OAuth, reconnect, or sign-out flow was invented.

About shows the current git hash/date, actual server-process uptime, dashboard asset version, and systemd automatic restart count when available. It has no reset, wipe, or restart button.

## Verification and evidence

Evidence is private under `/opt/leon-brain/brain_state/private_out/settings_menu/`:

- `backend-tests.txt`: 42 Python checks (24 new settings/audio cases plus 18 existing auth/assets/catalog/websocket cases); both existing JavaScript suites and JS syntax validation pass. Backend tests run in the required isolated production sandbox with a fake Windows runner and temporary state.
- `audio-session0.json`, `audio-noop-evidence.json`: session 0 and interactive-session enumeration both match reality. Realtek speakers/microphone are current defaults, volume 50.05816%, unmuted. Default, volume, and mute no-op round-trips leave the snapshot unchanged.
- `real-endpoint-evidence.json`: the new HTTP routes tested in a separate ASGI process **without running startup or shutdown**, against real laptop enumeration and no-op writes. Bad authentication is rejected. OpenAI API health was verified; isolated Claude/Codex relay status was honestly unverified.
- `browser-evidence.json`: 55 checks on actually served assets at 1440x900 and 390x844, with fake API/WebSocket/media output backends. It covers both button positions/popups, five sections, shared comboboxes, fake audio round-trips, both sink hooks, persistence, keyboard focus/Esc, mobile overflow, and the restart-needed state. CSS/JS bytes match disk; HTML matches disk after the existing server branding and injected build hash.
- `regression-browser-evidence.json` and `conversation-browser-tests.txt`: drag/resize persistence, glass brain search inside its iframe, model menu, usage header, console errors, and the existing conversation arrival-order browser suite.
- Screenshots: `header-1440.png`, `header-390.png`, `settings-audio-1440.png`, `settings-audio-390.png`, `settings-dropdown-1440.png`, `settings-dropdown-390.png`, `settings-sections-1440.png`, `settings-sections-390.png`, `settings-restart-needed-390.png`, and `regression-desktop.png`. Interactive changes in screenshots are fake, including the glasses default/63% volume/mute examples.

`python3 tools/check_dashboard_settings.py` reproduces the read-only served-dashboard browser check. It launches and closes its own silent headless browser, substitutes fake API/WebSocket/output backends, and never controls Dean's browser or actual Windows audio.

Backend regression worktree: `/opt/leon-v2-worktrees/settings-menu-1008`. Run tests through `/opt/leon-v2-tools/ops_sandbox_run.sh`, never the unsandboxed legacy suite. Browser tests in that sandbox need `PLAYWRIGHT_BROWSERS_PATH=/root/.cache/ms-playwright` because sandbox HOME is isolated.

Not included: automatic output pinning, speech speed, invented account login/logout flows, destructive actions, or usage controls. Real device-switch and audible-output tests remain deliberately deferred until Dean is clear; fake backends exercise switching, and real no-op writes verify the interactive Windows path.

## Settings QA recovery — 2026-10-09

This section supersedes the historical activation snapshot above. At recovery start the existing `/api/settings` and `/api/audio/*` routes were already loaded in `leon.service`; no restart was performed by this recovery job.

Settings UI `20261009-settings-qa-v4`:

- Claude/Codex catalogs are explicitly cached model metadata, never evidence of a current login. Open the installed client to sign in again, then refresh Models. In-panel reconnect is unavailable. The existing Models panel remains the sole editor of independent role selections; no provider/model/reasoning defaults are changed.
- The current disk commit is labeled **Disk checkout**. It is not asserted to be the running process revision. The improved server response adds the literal VERSION file and checkout branch (which is not an update channel). These added fields require the next safe brain restart. The UI handles the old response without claiming the additions are live.
- Voice provider/choice links to the existing Integrations UI. Notification permission is read from the browser. A separate camera/microphone privacy control, update-channel selector, data export and restart are explicitly unavailable; no inert toggles or credential changes are introduced.
- Audio failures clear stale device names and disable controls until refreshed. A failed shared-switch response reads back the server state, since a timeout can happen after persistence. Browser-storage failure is shown, and failed voice-output persistence restores the prior sink.

Verification artifacts are under `brain_state/private_out/recovery-20261009/settings/` on the VPS and the recovery laptop job's `work/settings_qa/`. New account/build tests are `tests/test_settings_truth.py`; existing audio/persistence/auth tests remain `tests/test_settings_audio.py`. Run backend tests only through `/opt/leon-v2-tools/ops_sandbox_run.sh` in a dedicated worktree. Browser checks run silently in a fresh headless context with all brain websockets and mutating APIs mocked; live reads and validation failures are recorded separately.

Real audio enumeration succeeded at the start, then the existing interactive scheduled-task path became unavailable: a bounded diagnostic took 15.326 seconds and reported `Interactive audio session unavailable or timed out`; the live route's 12-second guard returned 503. No successful mutation was issued during that failure, and no old volume snapshot was restored over the owner's independent changes. Treat physical device switching, mute transitions and audible playback as unverified on this deployment. Mocked roundtrips and explicit unavailable-state recovery are covered; they do not substitute for working live audio.

After a safe later restart, verify `GET /api/settings` contains `settings_schema: 2`, VERSION and branch fields, and the account catalog freshness labels. Recheck `/api/audio/devices`, then use a quiet window for real write/readback tests with immediate restoration. A successful HTTP status alone is insufficient. No service restart, hot module reload, brain initialization, credential mutation or paid voice generation is part of this rollout.

Rollback: revert the recovery Settings commit using a normal git revert under `brain_state/private_out/recovery-20261009/integrate.lock`, preserve unrelated changes, push normally, and reload the dashboard. Reverting disk Python code only affects the running backend after the next safe restart; do not restart during an active conversation.


## Audio deadline follow-up — 2026-10-09

Frontend `20261009-settings-audio-v5` gives audio requests 30 seconds while other Settings requests keep their 16-second limit. The candidate SSH runner allows 25 seconds for startup, registration, the unchanged eight-second result deadline, and cleanup; the Windows task still has a ten-second execution cap. No automatic retry is added. An SSH timeout cannot prove a requested write did not happen: refresh devices before retrying.

The running backend must be reloaded at a safe, separately approved time to use this new SSH deadline and error text. Deployment of the JavaScript does not reload Python. Current live enumeration was verified against all four local active devices, Realtek defaults, 60% volume and unmuted state; no audio write or speech test was issued. The earlier exact failure was devices enumeration: no result within the interactive task's eight-second deadline, 15.326 seconds including SSH and cleanup. This path uses a separate VPS-to-Windows SSH connection, not the coding bridge. Current reads succeed, so the historical cause of the missing task result (scheduler/load/session) remains unproven; the deadline envelope defect is directly established. Private follow-up evidence and a manual restart handoff are in `brain_state/private_out/recovery-20261009/settings-followup-7086/`.
