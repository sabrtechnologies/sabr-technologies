# Completion follow-through

Owner-goal continuation additionally reads the Leon-only, root-owned private
`brain_state/private_out/owner-goal-plan.json`. This is trusted operator input:
no worker result, thought, completion marker, model tool or review endpoint
creates it. Record the actual owner instruction, existing goal ID, objective,
checkpoint, saved coding provider/model/effort, expiry and finite decision/child
budgets. Each approved step names an exact predecessor job or parent step,
actual host/folder, useful dependency and bounded next action. Do not put secrets
in the plan. Keep it outside customer/release inputs, root-owned and mode 0600
or stricter. This trust boundary is a supported-workflow boundary, not an OS
sandbox against an arbitrary root shell. Workers must not modify authority.

The normal watcher collects receipts, reconciles them with that parent plan,
and only then admits one approved step. A child returns to its parent goal; it
does not inherit permission to spawn. A rejected review or failed terminal job
is blocked on its dependency. A different pre-authorized dependency with an
explicit changed cause may proceed; uncertain dispatch never takes that path.
Step identities, decisions and budget usage are durable cue records. Scope or
saved coding-setting changes fail closed. The existing owner pause/stop,
sleep/conversation gates, proactive hourly cap, subscription quota/auth checks,
queue concurrency and 180-second cadence remain in force. Expiry and fixed root
budgets prevent indefinite continuation. General background inference stays off.

VPS dispatch uses the existing deterministic request ID. Laptop dispatch uses
an exact request marker at the beginning of the queued task plus host, folder,
provider, model and effort checks. Because the installed laptop API does not
provide native request-ID idempotency, an attempted laptop dispatch with no
visible exact match blocks; it is never resubmitted or moved to VPS. Duplicate
matches and incomplete queue visibility also block. This conservative recovery
does not require changes to the independently owned laptop worker/broker.

Queue-confirmed handoffs record `handoff_verified`, `tool_events_observed` and
the basis of `tools_fired` separately. A missing streamed tool event cannot hide
an actual registered child. Admitted subscription turn identity is immutable
for fallback suppression, even when stop/pause revokes permission mid-error.
The watcher also cancels its turn token when those controls change.

Parent reconciliation never marks the objective complete, reannounces a job,
or enrolls unlisted historical cues. When the root plan has no useful next step,
its exact `next_dependency` remains blocked and the task stays open. A finite
live-acceptance budget of one child is a particular owner grant, not a global
production restriction: tests exercise two sequential children on each host.

Additional executable coverage: `test_owner_goal_continuation.py` and
`test_followthrough_no_fallback.py`; preserved owner transport/auth and session
regressions must run against the combined installed source, in the supported
production-host test sandbox.

The existing action-cue watcher now distinguishes a job announcement from its
completion review. Previously, a notification or any conversation tool could
close the cue; three turns without a tool dropped it. None required reading the
checkpoint, checking adoption or deciding the next bounded step.

New job cues carry a persistent `work_id` and stable native `request_id`. On the
next watcher tick, a read-only step collects the actual result and its hash into
the existing `action_cues.jsonl` row. Notification delivery, conversation turns,
TTL and ordinary cue retention cannot discard that receipt. No extra scheduler,
queue runner, paid service or provider fallback is introduced.

A subsequent tool turn uses the existing responder lock, autonomous guard and
cadence. General background work still requires `LEON_BACKGROUND_CLAUDE=1`.
A managed completion instead requires an explicit owner grant on that existing
checkpoint: `owner_instruction`, `objective`, `checkpoint`, `next_step`,
`provider`, `max_decisions=1`, and `max_children=1`. Supply it as `authorization`
on the authenticated review endpoint. Worker output and candidate next steps
cannot create grants. Grants do not propagate to children or other SIs.
Owner stop and proactive pause prevent work. The prompt treats worker output/thoughts as evidence, requires
existing owner authority, and requests one finite next step or a specific
blocker/rejection/idle reason. Failed result reads and failed/rejected decisions
stop; they are not periodically retried. Decisions never mark a goal complete.
Tests/adoption in a model response are reported evidence, not independently
verified objective success.

After a crashed/uncertain tool turn, the watcher checks the deterministic native
child identity. It records an admitted child without resubmitting it. If no
child can be established, the checkpoint stays blocked for side-effect review.
This intentionally does not promise exactly-once arbitrary shell operations.

Authenticated operator surfaces:

- `GET /api/action-cues/state`: active, queued, runnable, blocked and reviewed
  completion work with reasons; no worker summaries or private state are exposed.
- `POST /api/action-cues/review/{job_id}` with `changed_cause`: reopens an existing
  legacy/read-only checkpoint after an explicit cause change. It cannot create
  tasks or replay an attempted decision. An unchanged cause is rejected.

Old notifications are not mass-replayed on upgrade. Select one existing
checkpoint to resume explicitly. No useful work remaining is a genuine idle
state. Missing authorization is a visible blocker. The bounded exception reads the
actual subscription provider and saved model/effort through the existing bridge,
checks reported exhaustion and responder auth/quota cooldown, and never switches
providers or enables the broad background flag. The historical flag prevented
unattended subscription burn (including the August 21 unlimited-loop incident);
it remains intact for goals, thoughts and unrelated work. A grant permits one
model decision, not repeated retries or a recurring goal.

The normal watcher reconciles the stable native identity before inference as
well as after it. Unknown lookup results block; only an explicit queue
"no such job" establishes absence. The turn retains the shared responder lock,
autonomous guard, 180-second cadence, 300-second timeout and daemon cancellation
channel. Pending owner conversation wins, including a second check under the
lock. Persistent-session errors do not fall through to a fresh transport.
Sleep is a visible queued pause; the durable grant and receipt remain for wake.
No sleep flag is cleared. A failed decision requires side-effect review, not
an automatic replay. Native queue admission, concurrency and request-fingerprint
checks remain unchanged. The one-child scope is carried in the decision prompt;
this is not a new sandbox for arbitrary shell side effects.

Acceptance suite: `tests/test_job_followthrough.py`, alongside action-cue,
goal-pursuit non-starvation and native activity tests. Regression cases cover
completion without user input, notification independence, duplicate suppression,
read checkpoint resume, interrupted dispatch reconciliation, rejection/blocker
stopping, existing quota gate, explicit owner stop and genuine idle.

Rollback: revert this feature commit locally, preserving unrelated changes, and
use the normal safe service restart. Keep completion receipts and brain state;
do not clear the ledger. Native workers are separate systemd services and must
not be stopped for a brain-code reload. No customer build/publish is needed.
