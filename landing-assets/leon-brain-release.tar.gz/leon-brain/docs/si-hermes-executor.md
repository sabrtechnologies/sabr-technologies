# Customer Hermes execution

The customer payload includes a reviewed subset listed in
`landing/CUSTOMER-EXECUTOR-FILES.txt`. Everything else under `tools/native_jobs`
is excluded, including the original installation's queue, provider router,
relays, job records, model settings and future files. Privacy scans still apply
to every retained source file. No runtime, credential or brain state is bundled.

The GUI installer, terminal installer and bootstrap provision the same upstream
Hermes revision (`e6cf2a9b1e8f98d40408b09a9a55993c8459b4b4`) with its frozen
lockfile, managed Python 3.14 and `uv==0.9.2`. Git and network access are required
for provisioning. Missing dependencies, a dirty source checkout, wrong revision
or failed imports stop readiness. Provisioning never logs into a provider or
starts a service. Existing runtime revisions are not silently replaced.

Sign into the selected Codex or Claude CLI using that provider's normal local
login flow. Select provider, model and effort explicitly. A runtime check does
not claim provider authentication or successful inference:

```sh
python tools/native_jobs/si_executor.py --check --provider codex --model MODEL --effort high
python tools/native_jobs/si_executor.py --project /absolute/project --task-file request.txt --provider codex --model MODEL --effort high
```

The foreground command runs Hermes planning, implementation and review. Hermes
owns tools and sessions; the provider CLI supplies inference with its native
tools disabled. There is no owner-host routing or provider fallback. A failed
plan cannot implement, and a failed or unclear review cannot approve. Review
changes allow two bounded fix rounds retaining the original task and project
memory. Runtime failure leaves the files and receipts for inspection.

For the authenticated local `/api/coding-jobs/native/start` endpoint, configure
`SI_CODING_ROOTS` as a JSON array of explicitly authorized project directories.
Send `folder`, `task`, `provider`, `model`, `effort`, and a stable `request_id`.
Reuse that ID after a transport error; changing its arguments is refused.
Customer jobs run one at a time on this device. Hosted tenants cannot start
local jobs. The same endpoint supports status, list and cancellation. The
chat coding tool uses this local queue, including Windows project paths, and
requires the same stable request ID. The customer queue rejects research jobs;
the original installation's research helper is not a customer coding fallback.
The Agents feed reports this device and execution evidence; an admission requirement
or planning/review session alone never becomes an implementation receipt.

Jobs, upstream sessions and project memory live under
`brain_state/coding-jobs`; the runtime lives under `brain_state/hermes-runtime`.
Updates preserve this state and the customer's identity. A failed GUI dependency
step participates in the existing program rollback. Runtime source is never
included in the public payload or overwritten by a payload swap.

Regression fixtures are not native platform certification. Each release report
must separately identify archive auditing, dependency provisioning, actual
provider execution, update/state preservation, OS coverage and publication.
