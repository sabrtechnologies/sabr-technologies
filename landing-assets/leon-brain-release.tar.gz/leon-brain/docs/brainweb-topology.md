# Shared brain anatomy

`dashboard/js/brainweb-topology.json` is the release-safe geometry template. Its
strict schema permits node positions, community indices, fixed anatomical
region/lobe names, degrees and edge endpoints/control points. It contains no
entity IDs, names, paths, snippets, activity statistics, fingerprint or dates.

`tools/export_brainweb.py` selects the existing original-install exporter when
the private origin marker is present. Customer installs use
`tools/brainweb_shape.py`, without modifying their cognition database:

- Existing local entities receive slots first. Remaining slots bind to files
  in the install's workspaces and source directories, cycling when necessary.
- These are anatomical slots, not a claim that a fresh install already has
  thousands of learned memories or relationships. Synthetic slots carry zero
  mentions, no remembered text, and a distinct ID range. Their drawn strands
  are labeled `anatomy`.
- Only the authenticated graph routes resolve names, search and folder details.
  The private `brain_state/brainweb_map.json` never belongs in an archive.
- A clean install creates its own random fingerprint, birth timestamp and
  daily snapshots. Existing customer history is preserved. Nothing scans a
  user's whole home directory or reads file contents for this inventory.
- The viewer can render the anonymous full template immediately, then swaps
  in the local export when available. Historical/saved views do not fall back
  to today's template.

To regenerate deliberately from an approved private source export:

```sh
python3 tools/export_brainweb.py --write-shape-template \
  /path/to/private/brainweb-data.json dashboard/js/brainweb-topology.json
python3 tools/check_brainweb_template.py
```

The command constructs a new allowlisted object; adding private fields to the
source cannot copy them into the output. Unknown regions and invalid geometry
fail. Regeneration is a reviewed release change, never an automatic live export.

Release builders must include `tools/brainweb_shape.py`, the exporter, the
template, and both viewer pages. Exclude instance-generated `brainweb-data.json`,
`brainweb-stamp.json`, `brainweb-history/`, `brainweb-shapes.json`, `shapes-saved/`,
and all runtime state. Rebuild from the integrated commit; copying a live
checkout into a customer archive is not safe.

Run `bash tools/test_brainweb_privacy.sh` and the disposable checks in
`tests/test_brainweb_shape.py` plus `tests/test_brainweb_exporter_ships.py`.
On the production host use its required sandbox wrapper. Browser tests use
headless Chromium with real WebGL, actual route functions and the production
auth middleware, without starting a brain or opening a visible file manager.

Static viewer changes take effect when reloaded. New Python route/startup
behavior takes effect on a subsequent normal process start. No running brain
needs to be restarted to preserve its existing positive-ID graph behavior.

Rollback: revert the feature commit, retaining customer state and all existing
history; do not delete or replace a customer's database or original live data.
