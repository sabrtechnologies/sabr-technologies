# SI update and release procedure

The installer binary and the downloaded SI payload are separate artifacts.
Rebuilding only the binary does not update the SI offered by the website.

1. Fetch the canonical `windows-conpty` branch and use a clean checkout of its
   current commit. Initialize `landing` at the commit pinned by that checkout.
   Record the full source SHA. Do not build from an old upstream fork or a live
   instance with uncommitted changes.
2. Run the `installer-lifecycle` workflow, or the same disposable fixture tests
   through the host's installed sandbox. The binary build workflow requires
   this gate. These Linux fixtures simulate Windows/macOS commands; they do not
   certify native operating-system behavior.
3. Run `python3 tools/prepare_si_release.py --ref windows-conpty
   --expected-commit FULL_SHA --output NEW_PRIVATE_DIRECTORY` as one command.
   On a production host run it through the installed sandbox, with output in
   that sandbox's permitted results directory. This exports committed source
   and the pinned landing commit, runs the existing privacy/packaging gates,
   and checks the payload version, installer source and bootstrap digest.
   It never publishes or writes to a live serving directory. A failed gate
   produces a blocked `candidate.json`; inspect its private `build.log`.
   Do not waive privacy gates to make a candidate pass.
4. Repeat preparation into another new directory and compare the payload
   SHA-256. Keep the candidate manifest, test results and platform receipts
   private. Native acceptance must cover install, update, failed dependencies,
   rollback, restart/reboot, version reporting and uninstall on Linux, Windows,
   Apple Silicon macOS and Intel macOS, using disposable machines only.
5. Once the candidate passes, tag that exact source commit for the binary build.
   Verify every binary's build stamp and digest. Publish the audited payload,
   pinned bootstrap and matching digests together through the existing release
   publication process. Keep the previous release for rollback. Verify bytes
   downloaded through the customer URLs, including the configured payload URL,
   against the manifest. Never call a source push a customer release.

`prepare_si_release.py` resolves local refs and makes no network requests. Fetch
before choosing a commit and recheck the branch before publication. If the branch
has moved, prepare and test the new commit. Publication is still an operational
step; this command deliberately cannot promote an unaccepted candidate.

Updates preserve saved SI/owner names, local/hosted mode, dashboard key,
accumulated state, snapshots and customer additions. The GUI installer copies
the previous program and Python environment before an update; allow disk space
for that extra copy. A dependency or readiness failure restores program,
identity and environment while keeping current memory in place. Failed files
are retained privately. An interrupted recovery blocks subsequent updates until
recovered. Bootstrap keeps the previous full tree until verification succeeds.
Recovery does not guarantee reversal of external package-manager changes or
every platform's startup registration; native acceptance remains required.

`uninstall.py`, `uninstall.sh` and the downloaded installer's uninstall verb use
the same lifecycle checks. Normal removal archives customer files before
removing the installation. Purge omits that new archive for the selected
destination. Shared cognition, Python runtimes, shared Ollama/models, unowned startup entries and
unattributed historical backups are retained and reported. Purge is not a
whole-computer erasure guarantee. Provider login storage is never removed.

Packaging excludes the owner's `tools/v2` deployment utilities and
`tools/native_jobs` orchestration, including future files in those directories.
The generic `tools/native_jobs/claude_cli.py` is retained byte-for-byte because
Windows native sign-in imports it; the required-file gate checks it. Its exact
path is classified in the manifest. Customer packages do not provision the
owner's native coding queue. This does not certify the separately installed
bridge or make the owner's machine configuration portable to customers.
Privacy gates still inspect all staged content, including this retained helper.
The standalone owner incident notes in `brain/learn_from_failures.py` are also
excluded; no customer runtime module imports that file.

See [native acceptance](installer-native-acceptance.md) for the required
platform receipts and the distinction between build runners and desktop tests.

Runtime project labels, original-only verification presets and private job
continuation instructions live in `OWNER_RUNTIME_CONFIG` in the already excluded
`brain/owner_facts.py`. `brain.origin.owner_runtime_config` returns customer
fallbacks unless this is the original SI; a configured customer SI name also
disables these settings. Customer checkout verification uses
`verify_payment_integration` with explicit URLs and expected evidence. The
original's named verification entry points remain available through its private
presets. Audit records go under the current installation's `brain_state`.

After preparing a full candidate, run `tests/test_candidate_runtime_privacy.py`
with `SI_TEST_CANDIDATE` set to its payload path, inside the approved test sandbox.
This checks the actual packaged runtime in a fresh process with no owner files
and compares the repaired modules with the tested checkout. The packaging suite
also injects forbidden content into each repaired runtime path and requires the
unchanged gate to reject it. These checks supplement native acceptance; they do
not certify a frozen executable or authorize publication.

Development receipts (`artifacts/`), private work notes (`work/`) and the
standalone `connectome-sim/` research experiment are excluded from the customer
payload. No runtime imports these directories. New unclassified top-level paths
still fail the existing manifest gate; no acknowledgement flags are used.

The manifest explicitly classifies `tools/brainweb_shape.py` and
`tools/check_brainweb_template.py`: the server imports the first for customer
anatomy and private local labels; the existing visualization privacy check imports
the second. Both contain generic geometry validation and installation-local
bindings, and packaging tests retain their exact source bytes. Offline state
replay/seed builders, local dashboard diagnostics, claim/latency probes, the
original-host CLI relay and an owner verification script are excluded. The
unclassified-tool rejection gate remains unchanged and is tested with an injected
unknown tool; no new-tool acknowledgement flag is used.
