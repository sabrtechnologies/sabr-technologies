# Ledger 17: CI regression causes and local verification

Job: `vps-871c263682c5b99ba392f5de`, based on `cb36f44c`.
Read the actual failure with `gh run view 40934683811 -R sabrtechnologies/leon-brain-vps --log-failed`.
No push, deployment, live-service change, persona edit, or fivepad/GTA work.

## Retained work

Inspected the retained `vps-1d8136f8f88116759f57deb7` worktree's status
(including untracked/ignored files), working and staged diffs, and last five commits.
It has the same base. Its only change is LF -> CRLF in `brain/inner_voice.py`:
`git diff --ignore-space-at-eol` is empty. Reused that file byte-for-byte;
left the retained checkout untouched. There were no untracked job artifacts or
log files in that checkout, only ignored Python caches. External job-store logs
were not located or inspected; no credentials/provider storage was read.

## Verdicts

“Environment” means the original CI setup cannot satisfy an existing test contract.
“Regression” includes defective test setup/synchronization, identified explicitly below.
No assertions were removed or relaxed; no new skips were added.

| Module | Original CI evidence | Classification | Fix | Local result |
| --- | --- | --- | --- | --- |
| `test_v2_phase2_structure` | `inner_voice.py`: 0 CRLF vs 1151 LF | Regression: file format | Reuse retained CRLF restoration | 10 passed |
| `test_thought_realization` | `prefer_local=False` vs expected `True`; same CRLF failure | Regression: stale local-route fixture plus file format | Explicitly select `LEON_INNER_VOICE_CLAUDE=0` in the local legacy fixture; keep exact kwargs assertions and production Claude default; restore CRLF | 20 passed |
| `test_task_check_snapshot` | `operator_owned_source_directory_required` | Environment: runner-owned source tree | Root-owned disposable `/opt/leon-ci/repo`, including its parents; production source-pin validation unchanged | 26 passed, 1 existing skip; 41 subtests |
| `test_task_check_containment` | `/usr/bin/bwrap` missing | Environment: missing OS dependency | Install bubblewrap; execute suite in actual isolation | 24 passed, 1 existing skip |
| `test_task_check_bridge` | `operator_owned_source_directory_required` | Environment: runner-owned source tree | Same root-owned CI checkout | 19 passed; 7 subtests |
| `test_snn_profile` | `SystemExit: 64`, sandbox launcher required | Environment: unisolated execution | New CI bubblewrap launcher; marker set only inside isolation | 6 passed |
| `test_snn_buffers` | `SystemExit: 64`, sandbox launcher required | Environment: unisolated execution | Same isolated launcher | 10 passed |
| `test_providers_swap` | `provider swap fixture requires the isolated test sandbox` | Environment: unisolated execution | Same isolated launcher | 1 passed |
| `test_ops_strict_preflight` | Analyzer unavailable / exits 1; workflow omits pyflakes; checker invokes `sys.executable -m pyflakes` | Environment: missing analyzer | Install pyflakes alongside pytest in the selected Python | 21 passed; 26 subtests |
| `test_memory_shadow` | Owner still present immediately after nonblocking retirement | Regression: test race | Join idle fixture worker with timeout, assert termination, then tick to reap; keep ownership, queue and telemetry assertions | 13 passed |
| `test_inference_narration` | Failed selected social call invokes fallback with empty text | Regression: scheduler ownership escaped | Do not wrap selected event streams in hosted fallback; suppress empty social completion; no hosted retry after selected glance/spontaneous failure | 15 passed |
| `test_conversation_lane_scheduler` | Three spontaneous callbacks never reach routing/transport within 2s | Regression: first-use cooldown tied to uptime | Use `None` for no previous attempt; explicit 10-second-uptime test also asserts second attempt is suppressed | 36 passed |
| `test_autonomous_proactive` | Model error emits empty `brain_response_start/end` | Regression: fallback synthesizes empty completion | Same selected-failure fix; three additional site-specific tests prove no hosted fallback call or visible event | 32 passed |

Existing skip limitations: the immutable snapshot integration test requires an
explicit pinned operator runtime (`LEON_IMMUTABLE_CHECK_FIXTURE`); the containment
integration test skips when nested user namespaces are unavailable under the
unchanged outer sandbox. Synthetic passes do not establish live confinement.

## Verification

All Python tests ran through `/opt/leon-v2-tools/ops_sandbox_run.sh` (the same
isolation/policy entry point used by `sandbox_suite.sh`) in linked checkout
`/opt/leon-v2-worktrees/ci-871c2636`. The launcher implementation and policy were
read first. No guard was disabled and no sandbox marker was set on the host.

Results: `/opt/leon-v2-tools/test-results/ci-871c2636/`.

- `baseline.log`: all 13 original modules, 9/13 passed; reproduced file-format,
  thought-fixture, narration, and proactive failures. Installed VPS dependencies,
  root ownership, and real isolation already satisfy the environment-only cases.
  The memory race did not reproduce on this run; the long-running VPS also did
  not reproduce CI's low-uptime cooldown without an explicit clock fixture.
- `after.log`: all 13 modules passed, including new regressions (26.60 seconds).
- An initial broad glob baseline was deliberately terminated while running an
  unrelated module, then replaced with the exact 13-module selection.
- An initial full run (`full.log`) inherited VPS umask 0077 and failed manifest
  mode checks in `test_improvement_bridge`; it was terminated and replaced by
  `full-ci-umask.log`, using `bash -c 'umask 022; exec python3 tests/run_all.py'`
  inside the approved sandbox. The CI launcher explicitly uses umask 022 too.
- `full-ci-umask.log`: **157/158 modules passed in 336.52 seconds**, including
  all 13 reported failures. The remaining module, `test_conversation_links`,
  initially could not find Chromium in the sandbox's ephemeral HOME. Downloaded
  Playwright's headless browser into the dedicated test-results directory only
  (no host package/service change), then set `PLAYWRIGHT_BROWSERS_PATH` inside
  the approved sandbox for the targeted retry.
- `final-targeted.log`: proactive (32 tests) and conversation scheduler (36 tests)
  pass again. Browser tests now run: 8 pass, while
  `test_escaping_xss_schemes_and_code_exclusion` fails because a `file://` link is
  rendered despite the test expecting no links. This is outside the original
  13; no dashboard/link implementation or assertion was changed. CI does not
  install Playwright and the browser fixture already uses `importorskip`.
- `browser-unchanged-base.log`: reproduced the identical browser assertion
  failure (8 passed, 1 failed) in a second, untouched linked checkout at
  `cb36f44c`, confirming this repair did not introduce it.
- `new-regressions-before.log`: the three new selected-fallback cases and the
  explicit low-uptime callback case all fail with the original production code
  restored in the disposable sandbox checkout. Restored the fixes before the
  final targeted retry, where both complete modules pass.
- The pinned landing submodule was initialized in the disposable test checkout.
  Workflow submodule checkout and fail-loudly release-file checks are preserved.
- Workflow YAML and every embedded shell step parse successfully; launcher passes
  `bash -n` and ShellCheck; diff whitespace
  check uses `core.whitespace=cr-at-eol` to honor the asserted CRLF contract.

The CI-only launcher refuses production hosts. It uses read-only host mounts,
writable disposable source, private /tmp and /run, hidden /home, fresh namespaces,
no network, no capabilities, and a cleared environment. It has not run on GitHub
in this job; a fresh Actions result remains necessary before claiming CI green.

Hermes provided the initial read-only brief; no post-change Hermes review has run
in this job. Departure from the suggested sequence: use the sandbox's supported
command entry point to run the exact selected modules and the full maintainer
launcher, rather than invoking one glob per file. This preserves pytest's separate
per-module processes and gives the same execution shape as CI.

## Handoff

All 13 requested modules have verdicts and fixes, with passing sandbox results.
Ready for review and an authorized merge/push to exercise GitHub Actions, not a
claim that CI is already green or that live deployment is validated. A push to
`windows-conpty` triggers the tests workflow; this job makes no push or deployment.
The unrelated browser regression remains outside this repair's scope.

## Delivery verification: vps-4afd847cdb9c6b303eb2e231

This follow-up supersedes the previous handoff's browser scope and verification
limits. Retained commit `b092f086` was fast-forwarded intact onto the delivery
branch; `git diff --ignore-space-at-eol b092f086^ b092f086 -- brain/inner_voice.py`
is empty. Original GitHub run `40934683811` was inspected directly: its SHA is
`cb36f44c7d97568568f298f704e25266f28de38a`, conclusion failure, 145/158 modules.
No ancestor or nested AGENTS.md applied to the changed paths.

Fresh disposable linked checkouts under `/opt/leon-v2-worktrees/ci-4afd847c-*`
were created for untouched `cb36f44c` and the candidate. Both initialize the
unchanged landing submodule pin `66a2065fa9809242f88467fa598b8335c28a6fac`.
The sandbox launcher, driver and path/memory policy were read before execution.
No test ran outside the required isolation or with a host-side sandbox marker.

Both base and retained candidate reproduced the same real Chromium failure:
`test_escaping_xss_schemes_and_code_exclusion`, 8 passed / 1 failed. The renderer
converted a `file:///C:/...` URL to a clickable laptop path, violating the
existing assertion. The minimal fix consumes file URLs as plain text. Four
additional cases cover Windows, case/encoding, quoted spaces, and Linux file
URLs. Existing assertions remain intact. The corrected browser module passed
13/13 tests, with no skips. GitHub now installs Playwright plus headless Chromium
and its OS dependencies; the CI launcher exposes the dedicated browser path
inside its existing isolation, so CI exercises the browser checks.

All 13 original modules independently passed in this delivery job using the
literal `tests/test_<module>.py` selections through `sandbox_suite.sh`. Counts
match the table above. The two existing integration skips remain: immutable
operator runtime fixture and nested containment. These are not live-confinement
proof. Browser runs use the runner's inspected `ops_sandbox_run.sh` command
entry point with `PLAYWRIGHT_BROWSERS_PATH` set inside isolation, reusing the
same installed browser on base and candidate. This is the only deviation from
the brief's literal browser `sandbox_suite.sh` command, whose cleared environment
cannot pass a browser location to the driver.

Receipts are retained outside this disposable job checkout at
`/opt/leon-brain/brain_state/private_out/ci-item17/4afd847c/`; working test output
is `/opt/leon-v2-tools/test-results/ci-4afd847c/`. Original GitHub failure logs,
main-checkout preservation snapshots, base/candidate browser output, targeted
module logs and final review/CI evidence belong in that receipt directory.
Workflow YAML, every embedded shell step, `bash -n`, ShellCheck and CRLF-aware
`git diff --check` passed. Full-suite, review and push results follow below.

The complete maintainer suite passed **158/158 modules in 311.36 seconds** through
`ops_sandbox_run.sh`, with `umask 022` and the browser path set inside isolation.
The full-run browser module passed all 13 cases. This is fresh worker execution,
not a claim that Hermes itself executed tests. Local Python is 3.14.8; GitHub's
Python 3.12 gate subsequently passed, as recorded in the final verification below.

Genuine NousResearch Hermes pre-push review returned **APPROVE**, session
`local-8da3cebb47d47a57468181b9c8a5bc5a696a6b3a3b0da0e04f8fc61edd888f2d`:
12 inspection tool calls, code/diff and copied full-suite logs inspected.
Hermes explicitly did **not** execute tests; its allowlist cannot invoke the
mandatory external sandbox. At that stage, approval covered integration and push,
with GitHub Python 3.12 verification still required; that gate is now complete.
The exact verdict and tool
receipts are in `prepush-review-result.json` and `prepush-review/hermes/` under
the receipt directory. Final integration SHA, GitHub run URL/conclusion and live
status are recorded there in `delivery-result.md` and in Dean's item 17 ledger.

### First pushed run and runner follow-up

Run [40942661188](https://github.com/sabrtechnologies/leon-brain-vps/actions/runs/40942661188)
for `3f1c978042e4e2859ff77ac8650ac51c7e3c768e` completed **155/158** (352.86s),
not green. Chromium executed and all 13 browser tests passed. Failures remained
in snapshot, bridge and containment. Its image was Ubuntu 24.04, despite the
workflow warning about an upcoming Ubuntu 26 migration.

Snapshot/bridge still failed `operator_owned_source_directory_required`: copying
and chowning the checkout did not normalize all ancestry and copied permissions.
The follow-up makes `/opt`, `/opt/leon-ci`, and the copied tree root-owned and
removes group/other write permission throughout the disposable checkout.
A controlled sandbox reproduction with a group-writable checkout root produced
the same snapshot failure; restoring the required mode made the module pass.
The production source-pin validator remains unchanged.

The independent nested namespace probe failed with `bwrap: loopback: Failed
RTM_NEWADDR: Operation not permitted`, rather than passing or reaching its two
existing skip conditions. This matches Ubuntu's AppArmor user-namespace
restriction, documented by [Ubuntu](https://ubuntu.com/blog/ubuntu-23-10-restricted-unprivileged-user-namespaces)
and handled for disposable GitHub runners by the
[upstream Codex action](https://github.com/openai/codex-action/blob/main/action.yml).
The workflow now enables that feature with the same sysctl only when
`runner.environment == 'github-hosted'`. No VPS kernel or AppArmor setting was
changed. Explicit read-only mounts, private namespaces, no network, cleared
environment and dropped capabilities remain mandatory. No new skip or relaxed
assertion was introduced. Subsequent Actions run `40944367613` verified this
runner-specific correction; the VPS cannot independently reproduce the runner's
AppArmor configuration. Targeted sandbox retries and workflow syntax checks are
recorded with `retry-*` receipts. All other application code is unchanged.

### Final delivery verification — complete

Delivered commit **`cf9e7b64ffec92dc1af47071fed10baf02913b40`** was integrated
and pushed to `windows-conpty`. GitHub run
[40944367613](https://github.com/sabrtechnologies/leon-brain-vps/actions/runs/40944367613)
completed **successfully**, on that exact SHA, with **158/158 modules in 340.07s**.
Its browser module executed all **13 tests**, with no browser skips. Snapshot
and containment retained their existing integration skips; this is not proof of
live containment. The failed first push is preserved in the preceding section.

The post-delivery reviewer could not inspect GitHub or private receipts under its
policy, so its CHANGES_REQUESTED verdict identified an evidence-access gap, not
a code defect. This documentation follow-up resolves that gap with a
[sanitized, review-accessible packet](verification/ci-item17-delivery/README.md).
Fresh foreground checks retrieved the successful run and original log again,
verified remote/main HEAD, compared installed files with the delivered commit,
retrieved the live JavaScript asset, and checked item 17's closed checkbox and
recorded SHA/run. The packet preserves exact selected log lines and structured
observations without copying private request text or authentication data.

CI is live and verified green. The running server returned HTTP 200 with the
exact committed `dashboard/js/conversation-links.js` bytes. The Python files
match the delivered commit on disk, but the brain service was not restarted and
their loaded runtime state is not verified. No installer or application release
was published. Item 17 is closed for the CI delivery. Unrelated work remains
preserved.

These are worker-captured receipts made available for reviewer inspection.
Neither earlier Hermes approval included test execution. The successful Actions
SHA above remains the exact tested version; later documentation-only commits
must not be described as having run in that historical Actions job.
