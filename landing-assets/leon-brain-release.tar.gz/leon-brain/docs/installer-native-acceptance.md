# Native customer installer acceptance (not completed)

No customer release is approved by a Linux fixture run or a source push. All
checks below require disposable machines and synthetic identity/state. Never
use an existing customer installation, provider login store, or a production
brain as the fixture. Do not publish or recommend updating while any required
receipt is missing or a packaging/privacy gate fails.

## Runners observed on 2026-10-17

Read-only GitHub API inspection found **zero registered self-hosted runners**
for `sabrtechnologies/leon-brain-vps`. The existing `build-installer.yml`
configures the following hosted labels. Run `33971342537` (2026-09-05, source
`6743f6508917a6df92123e5f292095b6fcebd713`) completed all four builds successfully.
That is historical build evidence, not a reservation, a current availability
check, or native lifecycle acceptance of the new source.

| Platform | Existing hosted label | Additional required environment |
| --- | --- | --- |
| Linux x86-64 | `ubuntu-22.04` | Disposable desktop VM with a login session, systemd, reboot and package-manager tests |
| Windows x86-64 | `windows-latest` | Disposable supported Windows desktop VM with a normal user account, elevation, interactive desktop and reboot |
| macOS Apple Silicon | `macos-latest` | Disposable arm64 Mac account/VM with interactive desktop, quarantine/Gatekeeper and reboot |
| macOS Intel | `macos-15-intel` | Disposable x86-64 Mac account/VM with the same desktop checks |

This job has a Linux x86-64 VPS sandbox only; it is not a disposable desktop
or reboot runner. No native desktop runner was connected or provisioned.
No paid capacity was purchased and no workflow was dispatched.

**Do not dispatch the current `build-installer.yml` to obtain private acceptance
binaries:** it contains release publication steps. Use an isolated build-only
workflow or private local build with the existing stamp/freeze/sign/validation
steps and artifact retention only. Do not run its release-upload or website
staging steps. Native acceptance remains separate work.

## Exact receipts required for each platform

Record OS/version/architecture, source SHA, pinned landing SHA, frozen installer
SHA-256, payload SHA-256 and bootstrap SHA-256. Use the same audited candidate
on every runner, and repeat its clean build to verify matching payload hashes
before acceptance. Configure an isolated onboarding endpoint to serve that
candidate; the test must not fetch the public, older payload accidentally.

1. **Frozen executable and GUI:** verify the build stamp via `--version` before
   any network access. Start the actual downloaded/frozen executable by double
   click, with Python absent from PATH. Confirm readable buttons, destination
   choice, error/progress reporting and successful dashboard launch. A source
   script, `--dry-run`, or headless smoke test does not replace this receipt.
2. **Fresh install:** install both local and hosted/body modes into clean
   destinations, including a path with spaces and a non-ASCII username. Record
   every created path, process, startup registration, shortcut and external
   dependency. Confirm health/readiness, selected port, unique customer identity
   and the candidate version. No owner identity or saved state may appear.
3. **Update preservation:** seed synthetic state, identity, configuration,
   snapshots and customer-added files into the previous supported release.
   Record their hashes and permissions. Run `--update --dest TEST_DEST` against
   the candidate. Confirm current program/version and dependencies, unchanged
   customer files and existing memory, and no duplicate process/startup entry.
4. **Failed update and recovery:** separately inject download/digest failure,
   extraction failure, dependency-install failure after the swap, readiness
   failure and an interrupted swap/recovery. Verify nonzero/error outcomes,
   restoration of the previous executable code and working environment,
   preservation of current memory and identity, and private retention of failed
   files. Restart the prior version and make a test request. A second update
   must refuse an unresolved recovery rather than overwrite it.
5. **External dependencies/startup rollback:** force package-manager and
   startup-registration failures; compare before/after inventories and verify
   the previous installation still starts. Existing rollback fixtures do not
   prove restoration of changes outside the SI directory.
6. **Login/reboot:** close the installer, log out/in, then reboot the disposable
   machine. Verify the correct mode, port, version, identity and state, exactly
   one owned startup entry/process, and a usable desktop/dashboard. Record the
   platform's actual service/task/LaunchAgent state, not a mocked command list.
7. **Uninstall/archive:** in a separate disposable snapshot run the frozen
   installer's `--uninstall --dest TEST_DEST` and the installed `uninstall.py`
   (also `uninstall.sh` where supported). Verify owned processes, startup entries,
   shortcuts and program files are removed; normal removal creates a readable
   archive whose identity/state/customer hashes match. Verify that shared
   runtimes, shared models, unrelated startup entries, historical archives and
   provider login storage survive. No surviving owned resource may be reported
   as removed.
8. **Purge/ownership:** in another disposable snapshot run
   `--uninstall --purge --dest TEST_DEST`. Verify only the selected owned
   installation is purged, with unrelated files and archives retained. Exercise
   symlink/reparse destinations, missing receipts, foreign startup entries,
   open executable/file locks and uninstall from inside the selected directory.
   Locked or ambiguous removal must fail safely and explain retained resources.

## Platform-specific acceptance

- **Windows:** use the real `.exe`, validate Authenticode status and the actual
  download/SmartScreen experience, check ACLs and non-admin/elevated behavior,
  actual task/startup registration, locked executables and Python/npm CLI shim
  resolution. The packaged `tools/native_jobs/claude_cli.py` must import and
  resolve a synthetic `.cmd` shim without shell interpretation. Do not sign in
  to or inspect a customer's provider account to test this.
- **macOS, both architectures:** verify the executable architecture with `file`,
  run `codesign --verify --deep --strict --verbose=2` on the app, record
  `spctl --assess --type execute --verbose=4` and notarization/stapling results,
  and launch a quarantined download in Finder. Record actual signing status;
  ad-hoc signing or a successful `--version` is not Gatekeeper acceptance.
  Verify real LaunchAgent registration, logout/reboot, path permissions and
  cleanup. An arm64 result does not certify Intel, or vice versa.
- **Linux:** test the frozen binary's glibc floor and a real desktop session,
  user/system systemd behavior, headless behavior and the `.deb` install,
  upgrade, remove and purge paths. Specifically seed unrelated historical
  archives before `.deb` purge: current package maintainer-script cleanup has
  not been certified against the lifecycle ownership rules. Treat any deletion
  beyond owned paths as a release blocker.

Keep the receipts and detailed logs private. Only after all required checks and
privacy gates pass may the exact matched artifacts be considered for approved
publication. Then verify actual customer-URL bytes, provenance and rollback
availability; source commits alone do not change the website download.
