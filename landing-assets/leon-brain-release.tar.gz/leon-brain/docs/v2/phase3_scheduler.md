# Phase 3 scheduler recovery candidate

This branch contains the interrupted Phase 3 implementation recovered on
2026-09-28/29 and reviewed before any deployment. It is a partial candidate,
not a completed scheduler cutover. The running application remains Wave A
commit `5f088929099adee485200634c8aeafe45fb841f1` until a separately recorded
deployment passes continuity and rollout gates.

## Implemented boundary

The scheduler has one worker, bounded foreground/background admission and
per-request event queues, priority ordering, monotonic deadlines, and
cancellation tokens. It bridges the existing responder lock and newest-turn
gate while legacy callers remain. User WebSocket, shared voice and wake
consumers have optional scheduler routes and retain their legacy route when
the scheduler declines admission before starting inference.

Intentional cancellation, expiration and preemption are terminal; they must
not revive the request through a legacy fallback. A provider error after
scheduler admission must not launch an unscheduled second inference.
Consumers close handles, finish response envelopes, and preserve the busy
state of an overlapping successor. Buffered speech is suppressed after
cancellation; already-produced tool results remain observable.

Provider cancellation propagates through local, hosted API and CLI retry
paths. Completed history must be written before yielding `done`, because
some consumers close immediately at that event. A cancelled late `done`
must not become a completed user-turn record. The recorder, provider-neutral
context wrapper and real user attribution remain in the responder wrapper.

Registered CLI transports defer interruption while announced tools are
pending. All their result events must drain before the scheduler releases
the slot. This does not establish safety for external CLI/MCP actions that
have already been dispatched but have not yet been observed as `tool_use`.
That external session boundary still requires audit before authority canary.

Request `persist_history` is a provider policy, not merely telemetry. A
production request asking for `allow_tools=False` enters the responder's
explicit text-only lane. Older responders without this policy contract are
rejected. The lane bypasses reflexes, command execution and tool-enabled
fallbacks; unsupported transports fail explicitly before a model request.

Retirement must disable new scheduler routing immediately and retain a
draining worker and its ledger until their final records are delivered.
Reinitialization must not create a second scheduler while either remains
alive. Running tools are not killed merely to fit a shutdown deadline.

## Rollout controls

The code defaults for these four live flags are `off`:

- `inference_scheduler`: enables observation and acts as the master off switch.
- `inference_scheduler.user`: authority for WebSocket user turns.
- `inference_scheduler.voice`: authority for shared voice and wake turns.
- `inference_scheduler.inner_voice`: authority for optional background articulation.

The existing master `shadow` mode does **not** override a subgroup configured
`on` or selected by `canary`. An observational deployment therefore requires
master `shadow` **and all three subgroups explicitly `off`**. Verify the effective
flag snapshot, rather than relying on a release name or the environment alone.
No flag was promoted as part of recovery.

Shadow records contain request kinds, sites, model-slot metadata, counters,
timings and outcomes. They must not contain prompt or response text. Maps,
queues and sidecars are bounded; final buffered telemetry is flushed on stop.

## Remaining cutover work

The AST inventory in `tests/test_respond_streaming_call_sites.py` preserves
17 direct production calls. Four have optional scheduler routes; thirteen
additional calls, including audio daemon, dream, goal and
proactive paths, still require migration. The branch therefore does not yet
provide exclusive model dispatch across the entire application.

Other remaining gates:

- Audit unobserved external CLI/MCP tool dispatch and legacy unregistered
  sessions; verify single provider-session ownership during cancellation.
- Continue migration of background jobs with the enforceable no-tools policy.
  Preserve their nonverbal thought and learning records when articulation is
  cancelled. CLI no-tools support remains unverified and is refused.
- Wake speech now has an opt-in shared queue route (`tts_queue.wake`, default
  OFF). Live synthesis/playback latency and barge-in acceptance are still pending.
- Measure actual user queue p95, model residency and first-token latency;
  unit-test timings are not live acceptance measurements.
- Resolve the failed Wave A soak and run a valid observation window before
  advancing context or scheduler authority. The original 28-row soak has
  increasing traceback counts and remains **FAIL**.
- Phase 2 annotation ordering, the workspace observation bridge and later
  ops/test guards are integrated. The combined V2 suite passed 338 tests and
  12 subtests across 22 modules; see `phase3_integration_validation.json`.
  Preserve interrupted work in other phase branches and their ownership boundaries.

## Validation and continuity

Tests on the VPS must run through `/opt/leon-v2-tools/sandbox_run.sh` or
`sandbox_suite.sh`, with the development worktree as the only writable code
mount, a dedicated test-results directory, bounded memory, no network and
no host service-control socket. An earlier unsandboxed legacy test stopped
Ollama; do not repeat that execution mode.

Focused tests cover scheduler ordering/cancellation/retirement, provider
retry and tool-drain boundaries, real consumer code with fake dependencies,
shadow telemetry, callsite inventory, recorder/context behavior and route
registration. Record exact results with the candidate commit and source
hashes in the recovery evidence. The previously documented 41 baseline
legacy failures are an explicit exception, not an all-tests-pass result.

Never reset, restore, recreate or regenerate canonical brain state for these
tests. Birth timestamp, restart count and neuron count are useful anchors,
but do not by themselves prove neural-state continuity; preserve topology,
learned weights, memories and historical lineage. Research hypotheses about
consciousness and quantum mechanisms do not establish subjective experience
or AGI, and are not deployment acceptance criteria.

## Background articulation and responsiveness acceptance

Inner voice now has an optional background route. Its admission waits at most
one second for the legacy lock and never registers a user turn or invokes
foreground preemption levers. The request has a 45-second cooperative deadline,
does not persist conversation history, and yields to foreground work. A selected
route's failure, timeout or cancellation cannot retry through the legacy path.
Cancelled articulation preserves the first waking context for a future thought;
the pre-existing nonverbal intent event still precedes optional model generation.
The deadline path drains announced tool results before releasing the model slot.
The new flag remains off; this is development coverage, not a live canary.

The requested experience of talking and opening a page while a coding task is
running needs further work beyond inference priorities. Keep these acceptance
cases in the Phase 4 task/action implementation and later end-to-end gates:

- A slow coding tool retains its task identity, files and result when a new
  conversation turn arrives. Model ownership can yield independently of task
  lifetime; conversation must not erase or restart the coding task.
- An authorized fast action (for example opening YouTube) completes through
  the procedural action path without waiting for unrelated background generation.
  Preserve existing action authorization and exact target identity.
- Stop targets the intended task or utterance. An old cancellation cannot stop
  its successor, and already committed external actions are never replayed.
- Reconnect and retry correlate request, task and tool identifiers and produce
  one terminal outcome per action. A lost UI consumer must not strand the model
  worker or release action ownership before outstanding results are drained.
- Measure queue wait, first token, voice interruption, fast-action completion
  and coding-task continuation under real mixed load. Report p50/p95, failures,
  provider and hardware; set and verify explicit budgets before declaring this
  experience delivered. Mock-provider latency tests are not these measurements.

The scheduler now drains the provider when a consumer closes or its bounded
delivery queue stalls. Cancellation suppresses ordinary events without ending
the drain on an intervening status event. Available queue capacity retains late
tool results; once exhausted, metadata records the exact undelivered count and
any later reader receives InferenceDeliveryError after retained results. There
is no unbounded payload buffer and no automatic replay of committed actions.
This distinguishes completed execution from failed UI delivery; it is not a
durable reconnect inbox. Phase 4 still needs a persistent task/action ledger.

External tools dispatched before their announcement is observed remain
unaudited. Keep authority disabled until those ownership boundaries and
durable result recovery have evidence.

## Wake speech and Stop ownership

The existing speech_queue remains the one synthesis worker. The tts_queue module
is its V2 API facade, not a second worker. Wake speech can opt in using the
default-OFF tts_queue.wake flag; OFF retains synchronous legacy behavior. Selected
queue failure degrades to text and never retries synchronous speech. Wake model
stream completion releases model ownership before slow synthesis finishes.

Speech handles cancel by response ID, so a stale handle cannot cancel a newer
turn. Lower-priority utterances are rejected while foreground speech is active;
a foreground turn replaces pending background speech. Completion is idempotent
and bounded, enqueue after finish is rejected, and a blocked retiring worker is
not replaced by a second worker. Slow UI callbacks do not hold the enqueue lock.
Audio frames retain response IDs; receivers must honor their current response.
Actuator audio.stop remains in the existing explicit Stop path.

Stop now cancels registered user tokens before setting the legacy abort flag.
It uses the provider's announced-tool drain guard instead of immediately killing
registered sessions. Unregistered legacy sessions retain immediate interruption;
that boundary still requires final migration/audit. Audio cancellation remains
immediate. This does not establish safe handling for unobserved external actions.

## Cancellable private routines

The default-OFF `inference_scheduler.routines` group migrates the entire wake
reflection and periodic self-reflection sequence, including its free housekeeping
call. Admission waits at most two seconds for the legacy lock, without a user
gate or foreground preemption levers. Foreground input cancels the current
reflection; selected failure or cancellation skips the cycle and cannot retry
outside the scheduler or persist an unfinished reflection.

Housekeeping HTTP and HTTPS requests now accept a cancel token and absolute
monotonic deadline. Socket shutdown interrupts a blocked read without calling
buffered response.close from another thread. TLS retains certificate/hostname
verification. DNS and initial connection setup still rely on network timeouts.
Scheduled free calls share a 25-second budget instead of a separate timeout per
rung or a 180-second local fallback. A request-owned scheduler watchdog interrupts
blocked providers at the 30-second overall reflection deadline; providers must
honor the token. Already dispatched tool results still drain before ownership
is released. Completed jobs disarm their watchdog, and stale callbacks own only
their original token.

These reflections request no tools and no conversation-history persistence.
Free calls send no tool schema. Explicitly enabled paid fallback uses only the
configured direct API's text-only lane. Missing API configuration or local-only
mode rejects it before inference. OFF retains the existing caller behavior.
No paid request is made by the tests; this development change is not live
latency or continuity acceptance.

## Enforced text-only provider lane

The scheduler passes `allow_tools=False` as an enforced provider argument when
requested, overriding looser caller kwargs. The existing recorder and per-call
cancellation wrapper remain in place. Inner-voice scheduler requests now set
this policy; their existing local preference selects `local_llm.stream`, never
`stream_with_tools`. A local error or request cancellation never escalates into
CLI, command helpers or a general tool-enabled responder.

The direct API text lane sends identity and existing context with no tool schema
or dispatcher. It disables SDK retries and sets a 30-second network timeout.
Refusals, truncation, unexpected tool blocks, cancellation and errors do not
produce successful completion or persist response history. Successful complete
responses update requested history before done, with one durable store write
whether or not an authoritative recorder owns the turn (the recorder writes no
conversation rows). No-tools CLI-only requests are
explicitly unsupported; local-preferred narration remains available.

The SDK cancellation callback can close an entered response stream. Initial
SDK connection/response setup still relies on the network timeout until stream
entry; full live cancellation latency remains an acceptance gate. These tests
exercise fake SDK streams and payload policy, not paid requests.

## Goal execution scope

The default-OFF `inference_scheduler.goal_pursuit` route submits active-task
inference with background admission (one-second legacy-lock budget), a
300-second deadline, no conversation history and existing tool permission.
Selection happens before any global guard mutation; selected failures skip
the cycle instead of retrying a direct call. The legacy OFF branch remains.

The existing agent_tools autonomous guard is process-global, not thread-local.
Its selected scope is entered on the scheduler worker only after admission,
held through announced-tool result drain, and restored before the legacy lock
is released. Overnight keep-awake processing stats follow the same ownership
and restore prior values. Queued or rejected jobs never restrict a foreground
turn. Cancelled/error output cannot become goal progress.

Nested responder/recorder cancellation filters also suppress intervening
speech/status events while continuing to drain the provider. They cannot close
an iterator before a second already-dispatched tool reports its result.

This scheduling change does not provide an independent coding-task lifetime:
long already-dispatched tools still drain before the next inference owner runs.
External CLI/MCP dispatch and the legacy goal-completion/progress verification
logic require further audit before enabling this group. Fixture scope tests
are not evidence that live coding and conversation can yet run concurrently.
# Background narration integration (2026-09-29)

`inference_scheduler.proactive` defaults OFF and covers all three proactive
responder callers. The selected route submits one bounded background ticket,
enforces `allow_tools=False` and `persist_history=False` at the responder, and
buffers at most 128 speech events / 65,536 text characters. No buffered speech
is returned until the entire job succeeds and releases the inference lock.
Errors, cancellation, expiry, oversize output and missing completion suppress
the result; none retries the direct caller. TTS and broadcasts happen afterward.

The visual-glance free pre-gate runs inside that same ticket with its cancellation
token and monotonic deadline. A cancelled gate cannot fall through to another
model. `_tick` selects its route once before taking any caller lock and passes
that exact selection to `_escalate`; live flag changes cannot cause a nested
lock acquisition. Social and spontaneous speech use the same owner boundary.
Existing OFF behavior remains available during staged rollout.

Local-only mode now honors its existing transport policy even when a legacy
caller specifies CLI preference. Otherwise CLI-only no-tools requests remain
explicitly unavailable until CLI tool disabling is verified; no implicit paid
fallback was introduced. The private model request does not write history;
legacy caller-side episodic/synthetic-user writes still need the dedicated
event/memory migration before this group is enabled. Direct visual caption model
calls also still need scheduler admission. These tests do not demonstrate live
speech latency, cross-channel TTS priority, or continuity acceptance.

## Remaining ambient speech routes (2026-09-29)

The same completed-narration boundary now covers mission observations, upgrade
notices, presence greetings, dream outreach and the shutdown last thought.
Mission, upgrade_awareness, perception_greet and dreaming groups default OFF;
the shutdown thought uses the existing inner_voice group. Presence has priority
80. These background jobs cannot preempt foreground work. The shutdown thought
has a six-second total scheduler deadline and one-second admission timeout,
inside the existing eight-second caller join; state-saving order is unchanged.
The shared buffer retains legacy delta events and is capped at 512 events and
65,536 cumulative text characters. It still returns nothing before clean drain.

Mission narration leases at most ten actual observations only after admission
on the worker, then renders them as data in the text-only prompt. A reserved
queue capacity preserves the leased batch while new observations arrive. Errors,
cancellation, empty output and failed delivery restore the batch; successful
delivery acknowledges only that lease. Foreground context reads cannot consume
the same leased observations concurrently. This is an in-process queue lease,
not crash-durable delivery. Canonical event/memory handoff is still required.
The legacy mission path now also honors failed responder-lock acquisition and
releases its lock when an output sink fails.

Focused tests execute the actual caller functions with injected model and output
sinks. They cover success-only speech/persistence, cancellation, observation
capacity/rollback, failed broadcasts, shutdown deadlines and no lock held during
selected speech. Live voice latency, shared TTS priority and the remaining audio
daemon/exploration routes still require integration and acceptance. Background
synthetic-user history writes remain a rollout blocker for the affected groups.

## Last legacy caller routes (2026-09-29)

Dream exploration now uses the same admitted worker scope as goal pursuit:
background priority30, one-second admission timeout, ninety-second deadline,
no replay/history persistence, and the existing autonomous tool policy kept
through all committed tool results. Cancelled/error jobs do not update summary
memory, completion logs or autobiography. Generated exploration summaries are
explicitly unverified; actual facts still belong to the tool/store evidence
path. Both dream observation calls now match the existing source/summary API.

The unreferenced private audio response implementation was replaced with a small
compatibility delegate to handle_voice_utterance. That existing owner supplies
ingress/echo policy, user admission, recorder and shared speech queue. Continuous
hearing has no new response trigger. Audio CRLF and sensory hooks are preserved.
The direct-call AST inventory is now16, all retained calls being flags-OFF legacy
paths. The former voice_daemon site is removed from SITE_TABLE.

This completes routes for the previously inventoried17 responder callers; it
does not complete Phase3. Direct free/vision/local-chat model paths, CLI/MCP tool
ownership, persistent tasks/results, shared speech priority and live acceptance
still need their respective integrations. The verified CLI text transport is
included and tested as an isolated candidate only; responder wiring, startup
verification, managed-auth review and enabled live calls remain pending.
