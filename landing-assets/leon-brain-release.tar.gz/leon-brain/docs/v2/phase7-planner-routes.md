# Authenticated supervised-plan HTTP ingress

The existing `/api/v2/tasks` router now exposes bounded supervised planning through
the existing executive and owned PlannerRuntime. It creates no model provider,
thread pool, queue, background loop, workspace, database or action grant. The
runtime, scheduler, trusted scope registration and durable approval authority must
already be installed. Missing capabilities refuse the request.

The server middleware alone supplies the verified installation principal. This is
the subject of the installation credential, not proof of an individual human's
identity. Caller fields never select a principal, workspace root, command, resource,
grant, approval reference or expiry timestamp. These routes are not model tools and
no inference output is interpreted as an approval request.

All endpoints require the existing authenticated middleware context, reject extra
or duplicate query/body fields, use bounded streamed JSON decoding (4 KiB), and
accept only finite exact types. Existing query-key authentication remains reserved
to middleware and is not forwarded to task authority. Goal size is at most 2048
UTF-8 bytes, scope 1000 bytes and idempotency keys 200 bytes. Reviews may return
private exact proposed code/specification to this authenticated caller; they are
never broadcast to WebSocket viewers or copied into route telemetry. Successful
plan responses carry `Cache-Control: no-store`.

| Method and path after `/api/v2/tasks` | Exact body | Behavior |
| --- | --- | --- |
| `POST /plans` | `scope`, `goal`, `idempotency_key`, `approved: true` | Register planning permission only. |
| `GET /plans/{id}` | None | Read the current bounded proposal. |
| `GET /plans/{id}/review` | None | Obtain the durable authority's exact proposal/spec and review digest. |
| `POST /plans/{id}/advance` | `retry_interrupted: false` or explicit `true` | One blocking bounded planner decision on the existing framework worker. |
| `POST /plans/{id}/poll` | Empty or `{}` | Checkpoint retained child receipts; no action or outbox acknowledgment. |
| `POST /plans/{id}/approve` | `proposal_sha256`, `review_sha256`, `idempotency_key`, `validity_s`, `approved: true` | Persist exact authority approval then delegate that step; returns 202. |
| `POST /plans/{id}/cancel` | Empty or `{}` | Persist parent/future-child cancellation through the owned planner. |
| `POST /plans/{id}/complete` | `proposal_sha256`, `approved: true` | Explicit receipt-backed completion acknowledgment. |

Plan IDs are exactly 32 lowercase hexadecimal characters. Digests are exactly 64
lowercase hexadecimal characters. Approval validity is an integer from 1 to 900
seconds, further constrained by the authority's configured maximum and parent
deadline. A retry needs an explicit boolean; no route automatically retries an
interrupted inference, failed effect, timeout or lost HTTP response.

Planning authorization references are deterministic hashes of the authenticated
principal, scope, exact goal and idempotency key. They identify that authenticated
request's planning permission and confer no action approval. `approve_review`
uses the existing durable authority to issue the server-owned reference and exact
issued/expiry times, then delegates approval using the retained receipt. Reusing
an idempotency key with changed input conflicts; replay never renews expiry or
reexecutes an existing child. These semantics belong to the authority/runtime,
not an in-memory HTTP cache.

## Ownership and execution

`Executive.coding_planner_handle(principal=..., expected_runtime=...)` verifies the
exact captured `state.task_runtime` identity before returning its bound
PlannerRuntime. The route calls that handle's `register`, `proposal`, `review`,
`advance`, `poll`, `approve_review`, `cancel` and `acknowledge_completion` APIs.
It never looks up a replacement owner after admission or exposes the authority
object itself. The runtime's existing operation counters, scheduler handles,
workers and retirement barriers own draining and keep stores alive through calls.

All endpoint functions are synchronous framework handlers; only body decoding is
asynchronous. FastAPI/Starlette's existing worker pool runs the blocking methods,
so no inference wait or SQLite work executes on ASGI's event-loop thread. Each
captured runtime has one weakly keyed, nonblocking advance semaphore. Busy
requests get 429 without waiting on a new queue. The semaphore remains held until
the actual worker call returns, including client cancellation/disconnection; its
`finally` releases exactly once. A replacement runtime has a distinct gate, while
the existing owner lifecycle must first establish safe replacement. The gate does
not replace TaskPlanner's own admission or shutdown barriers.

Historical reads never acknowledge the shared outbox. Polling uses only the
planner's retained-receipt API; the existing runtime tick owns durable checkpoint
and outbox acknowledgment. Request failure returns sanitized 403/409/422/429/503
responses without raw exception messages, provider output or credentials.

## Validation and integration dependencies

Tests use the actual ASGI middleware and route module without importing live server
startup. The final module passed **150 tests in 5.04 seconds** using:

```text
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase5 /opt/leon-v2-tools/test-results/planner-routes-20260930-c --mem 768M -- python3 -m pytest -q tests/test_task_routes.py
```

The installed fixtures use actual TaskRuntime startup, ExecutiveController,
PlannerRuntime, PlannerAuthority, immutable ingress, scheduler, TaskStore, grant
policy and TaskWorker. Only inference and containment authority are synthetic,
inside the mandatory external test sandbox. They cover authenticated
read, replace, check and explicit completion; stale review refusal; expired
lost-reply approval recovery without another grant, mutation or parent revision;
OFF admission; and cancellation/shutdown while inference remains owned. Existing
single-check tests and the HTTP gate tests also cover principal binding, strict
fields, owner replacement, concurrent refusal/reads, disconnect, and no-store.
Client reads leave the outbox retained until the existing runtime tick consumes it.

The integration dependencies are ingress lock fix `110dc7a6`, installed planner/
executive `d705fbce`, durable authority `82c0a42b`, and owned operator configuration/
controller hooks `b579d377`. Each was cherry-picked separately into this isolated
branch with exact HEAD, dirty-file hash and scope guards; the original sensory
branch at `5201eb65` remains unchanged. The routes use the existing router mount
and test-module registration; no shared server startup edits are required.

This is a tested development candidate. No production server, flags, deployment,
service configuration or service restart changed, and no model request ran.
