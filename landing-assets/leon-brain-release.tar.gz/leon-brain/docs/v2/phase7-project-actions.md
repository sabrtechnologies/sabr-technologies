# Registered project action candidate

This module supplies three handlers to the existing TaskWorker. It does not
install itself, admit tasks, grant permissions, call a model, resume planning,
detach CLI-owned tools or replace the existing executive. Runtime, authenticated
ingress, durable grants, scheduler checkpoints and result handling remain root
integration work. All defaults require explicit configured workspaces and a
literal-true authority decision. Missing authority denies every action.

## Public contract

`ProjectActions(workspaces, authority=None, check_abort=None)` exposes:

* `canonical_resource_spec(name, arguments, task)` returns immutable
  `CanonicalResourceSpec(name, arguments, resources, minimum_tier, scope,
  root_identity, input_sha256, configuration_sha256)`.
* `resources(name, arguments, task)` is the same spec's exact sorted key tuple.
  Use those keys when enqueueing an action; do not accept model resource keys.
* `policy(action, task)` returns TaskWorker's strict `PolicyDecision`.
* `handlers` maps the three registered names to TaskWorker-compatible handlers.

`Workspace(scope, root, checks=(), shared_resources=())` is trusted local
configuration. Scope is an opaque `workspace:<id>`, not a caller-provided path.
The absolute root is opened without following any symlink and its device/inode
identity is pinned. Every action takes the whole workspace exclusion key. Two
configured names referring to the same inode use the same key. Additional keys
must cover any shared Git directory, cache or other resources a check can touch;
they apply conservatively to all actions in that workspace.

| Registered name | Exact string argument keys | Minimum tier |
| --- | --- | --- |
| `project.read_text` | `path` | 1 |
| `project.replace_text` | `path`, `expected_sha256`, `text` | 2 |
| `project.run_check` | `check` | 3 |

`input_sha256` hashes UTF-8 encoded compact, sorted JSON of the argument object,
using Python JSON's default `ensure_ascii=True`. The configuration hash binds
scope, root path and inode identity, all fixed check configurations including
containment references, and shared keys. Changing a check or workspace requires
new matching authorization evidence. Arguments in the spec are a sorted tuple
of string pairs; it cannot be modified by an authority callback.

The injected `authority(action, task, spec)` must return **literal True**. It
receives isolated copies of persisted action/task snapshots and must validate
the trusted principal, durable grant, stable task/submission/step identity,
scope, exact arguments, resource set, tier, configuration, expiry, revocation
and approval. A bare authorization reference is never sufficient. The backend
checks row/task identity, RUNNING state, dispatch boundary, exact resources,
minimum tier, task cancellation/deadline and TaskStore's action fingerprint.
Authority runs during policy, at handler entry and again immediately before a
replacement or process launch. Identical checks must be safe while the grant
is valid; this is not permission to replay a completed action. TaskWorker and
TaskStore remain the sole action attempt owners.

## Filesystem effects and limits

Paths must be strict relative components. Absolute paths, dot/dotdot/empty
components, backslashes, colons, NUL and `.git`/`.hg`/`.svn` components fail.
All directories and files are opened through no-follow directory descriptors;
symlinks, multiply-linked files, FIFOs and other special files fail. The backend
rewalks root/parent identities before effects and checks them afterward. A
configured root inode change is denied even if the replacement path is ordinary.

Reads inspect at most 64 KiB of one regular UTF-8 file, return at most 2 KiB of
text, and include the full inspected file SHA-256, size and truncation flag.
Replacement supports an existing single file only. It requires a 64-character
lowercase expected SHA-256, accepts at most 8 KiB of replacement text, preserves
ordinary permissions, writes a same-directory temporary file, fsyncs it,
rechecks preimage/inode and authority, then atomically replaces and fsyncs the
directory. It verifies final content and identity before success. There is no
automatic rollback, new-file creation, append or directory mutation API.

**Required external gate:** only an exclusively managed checkout is supported.
The integrator must exclude uncoordinated external writers and renamers, and
checks must share its workspace/resource locks. Directory descriptors prevent
a swapped symlink from redirecting an operation; identity checks detect parent
replacement. They cannot provide a filesystem transaction against a hostile
same-UID process renaming directories between verification and a syscall.
Post-effect drift or unverifiable durability returns UNKNOWN and therefore
retains the TaskStore resource fence. No claim of adversarial namespace
isolation or distributed compare-and-swap is made.

## Fixed checks and process ownership

`Check(name, argv, cwd='.', env=(), timeout_s=30, containment_ref=...)` requires
a fixed tuple with an absolute executable, fixed relative cwd and explicit
environment entries, a finite timeout up to 120 seconds, and an explicit
reviewed containment reference. Model arguments select only a configured name.
There is no shell interpolation, argument substitution, inherited application
environment, model root, model cwd or model environment. The child gets a small
fixed PATH/locale environment plus trusted configuration entries.

**Required external gate:** fixed argv and a process group are not an OS
sandbox. The integrator's authority must verify the referenced filesystem,
network and process containment before authorizing repository code. That
containment must prohibit escaping the owned process group (including daemon
double-fork/setsid) and touching undeclared resources. This module does not
grant network, service or desktop operations, but cannot make arbitrary code
safe merely by naming it. No production check is authorized by fixture config.

The backend starts a new session, closes stdin and owns stdout/stderr pipes.
Combined output is limited to 2 KiB; overflow aborts the check. Nonzero exit is
FAILED. A timeout or explicit check-abort requests TERM of the owned group,
waits 250 ms, then KILL and waits 500 ms. The leader must be reaped and the group
absent before a known result is returned. Surviving descendants, inaccessible
process state or another inability to prove drain return UNKNOWN; the retained
action receipt fences every resource. There is no implicit retry or fence
release. Process cleanup is bounded and may be attempted again in finalization;
an unproven first outcome stays UNKNOWN even if later cleanup succeeds.

`check_abort(action_id)` is an optional trusted **explicit check-stop** hook,
not a speech cancel token. Do not connect it to UI disconnect, inference
preemption or ordinary `cancel_task`: those normally stop future units while a
committed check drains. If this hook is used, approval of the named check must
include this process termination policy. An aborted check's prior authorized
filesystem effects are not rolled back. Grant revocation prevents new effects;
it does not silently rewrite an already committed check's result.

## Initial integration and acceptance

The smallest runtime slice is one explicitly approved `project.run_check`
submitted by the existing executive. It runs in TaskWorker while a separate
foreground no-tools scheduler job can answer chat. Existing unknown CLI tools
are not detachable through this module. Read/replace handlers can remain
unexposed until their grants, proposal validation and checkpoint wiring pass.

For multi-step coding, the runtime persists WAITING_INFERENCE, submits a short
no-tools ACTIVE_TASK job, validates a strict proposal, CAS-enqueues one registered
action, and releases the model. A durable result receipt advances the checkpoint;
only then may the executive schedule the next reasoning unit. Inference
preemption preserves the checkpoint. Runtime deduplicates before acknowledging
its outbox; authenticated reconnect reads retained receipts without consuming it.

Hermetic tests use temporary workspaces and fixed synthetic Python commands
inside the hardened test sandbox. They exercise configured identity/resource
derivation, literal authority, scope/argument rejection, bounded reads, hash
conflicts, symlink/hardlink/FIFO rejection, root/parent replacement, last-boundary
revocation, atomic replacement, fixed environments, nonzero/timeout/abort/output
limits, whole process-group cleanup and UNKNOWN resource fencing. They do not
establish live task routing, user authorization, process containment or coding
continuation acceptance.

## Candidate evidence, 2026-09-29

Branch `v2/phase7-project-actions` reuses the clean phase10 checkout on base
`3e5564320ddab61407deab9981b63dfb7ca8e1e8`. The resource-fence, conversation and
earlier task branches remain preserved. The three allocated files were absent
at the base; the stage record captures clean status/diff, base identity and
file absence. No pre-existing files were replaced by this candidate.

All **74 project-action, task-lifecycle and worker tests passed in 1.82 seconds**
with no warnings through the serialized 768 MiB launcher:

```
bash /opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase10 \
  /opt/leon-v2-tools/test-results/project-actions-tests-20260929c --mem 768M -- \
  python3 -m pytest -q tests/test_task_project_actions.py \
  tests/test_task_lifecycle.py tests/test_task_worker.py \
  --junitxml=/opt/leon-v2-tools/test-results/project-actions-tests-20260929c/tests.xml
```

JUnit SHA-256:
`b05da7c3f0b144535aa1e7776312f54eae5cab8085b095a85509976d8bde26a7`.
Adjacent `tested-source.sha256` SHA-256:
`2b8cf52c2a7b0e7e2fe730660b3a6ff4812fc6ea38bdabc56f0a1ba79291bb0e`.
The guarded staging manifest is
`/opt/leon-v2-tools/test-results/project-actions-stage-20260929/source.sha256`.
This evidence text was added after the passing run; Python source was unchanged.

The first run passed 72 tests but exposed a cleanup SyntaxWarning. Two additional
regressions cover errors after a possible rename and after descriptor cleanup;
these now report UNKNOWN instead of a false assertion that no effect occurred.
No user workspace, live provider, deployed service or production state was used.
