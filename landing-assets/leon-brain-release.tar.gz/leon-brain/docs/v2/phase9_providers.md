# Phase 9 provider package and integration contract

This package implements replaceable inference and typed decisions. It never opens
Leon's identity, memory, goals, procedures, SNN state, or conversation stores.
Constructors perform no network requests, environment/key discovery, model
loading, health probes, thread startup, or brain initialization. The only storage
is an explicitly constructed, content-free budget ledger.

## Scheduler integration

The existing InferenceScheduler remains the single global inference authority.
Create one ProviderRouter for that scheduler, and consume `router.stream(request,
cancel_token)` inside its provider dispatch slot. Router locks serialize each
registered provider within that router; multiple routers are not a substitute
for the scheduler. `select()` is inspection only: it does not reserve a budget.

Build ProviderRequest from the caller's rendered context, capability set, trace
ID, monotonic deadline, history policy, and explicit tool permission. A decision
request uses Capability.DECISION and named questions. The other eight runbook
capability names are represented, but an adapter advertises only implemented
capabilities. Missing vision/embedding/speech adapters fail selection rather than
pretending text inference implements them. Deep/tier-2 providers require an
explicit deep flag or deep_reasoning capability.

ClaudeAdapter and OllamaAdapter accept existing bound callables; they do not
replace BrainAPIResponder, sessions, prompts, or local_llm. The shim signature is
`shim(prompt, rendered_context, *, persist_history, cancel_token, **kwargs)`.
It must translate context, preserve channel selection and confirmation callbacks,
and delegate once to the existing implementation. ProviderRequest.persist_history
overwrites contradictory legacy kwargs. The default no-tools Claude path is
unavailable: supply the integration's verified no-tools callable. Ollama's
plain_stream must enforce no tools; tool_use is advertised only when a separate
tool_stream is explicitly supplied. An emitted forbidden tool event is an error,
not a reason to retry. These checks cannot undo an action a broken shim already
performed; prevention belongs in the verified producer.

ProviderEvent.raw preserves each original legacy event including confirmation
and tool metadata. The compatibility boundary can return `event.raw` unchanged;
hosted events require explicit translation to existing public stream shapes.
There is no automatic public WebSocket or history schema change in this package.
Do not recursively route a legacy shim back through the scheduler or router.

Cancellation is checked before dispatch and between events. Already-dispatched
tool_result events drain after cancellation; other output is suppressed. Producers
must stop when those committed results finish. Closing/abandoning a generator is
not a safe tool-drain protocol. The scheduler must consume the drain before
releasing its slot. Unknown/unregistered legacy tools are not made safely
interruptible by this adapter. Failed legacy calls are never replayed on another
provider; safe text-only hosted calls may fail over only before any observable
reply or decision. Failure logs include trace_id, subsystem, exception type,
provider ID, and recovery action, without prompts, keys, or remote error bodies.

## Health, budget, and configuration

Selection first checks all required capabilities, configured state, and passive
health circuit status. Background requests prefer local providers; normal turns
prefer tier 1; explicitly deep turns prefer tier 2. Measured successful latency
breaks ties. Admission then atomically reserves budget; an unaffordable candidate
is skipped. Health learns from actual calls and starts no probes.

BudgetLedger takes explicit daily/monthly token and micro-USD limits and optional
per-capability limits. Every admitted call counts against global and each relevant
capability limit. Use a persistent SQLite path outside identity/memory storage
for restart-persistent enforcement; `:memory:` is explicitly process-local.
UTC admission date determines the accounting period. Atomic SQLite reservations
also coordinate separate ledger instances using the same file. Unknown usage,
errors, cancellations after dispatch, and orphan reservations retain their full
charge. Usage explicitly marked `usage_final=True` by the adapter and followed by
clean stream completion reconciles the charge, including overruns, so future calls
cannot hide an underestimate. No automatic reset or reservation refund on restart.
Intermediate usage from a cancelled, errored, or abandoned multi-round call is
not proof of complete accounting and never refunds its conservative reservation.

Prices are caller configuration in USD per million tokens. Unknown prices fail
closed before dispatch; local adapters explicitly cost zero. No guessed current
model prices or built-in model defaults are supplied. OpenAI reserves the
enforced max_output_tokens plus a conservative text input estimate. Legacy shims
need an explicit full-call input bound and output_token_bound covering all rounds,
hidden prompt material, and reasoning. Jev's documented protocol has no output
token cap; its router path requires an explicit output_token_bound. Missing bounds
fail admission. Deployment must establish those bounds against the configured
provider/shim. These are admission ceilings backed by configured estimates, not
a guarantee against incorrect provider usage reports or an unbounded upstream
tool/model loop. Upstream account limits remain necessary for an absolute spend
cap. A lexical baseline generates no model tokens and has no external cost.

Optional hosted adapters require `enabled=True` and an explicit API key. OpenAI
also requires an explicit model; capabilities and prices are explicit. No model
downloads or paid requests are part of tests. The JSON transport delegates socket
lifecycle to Phase 3 `brain.inference_http.open_cancellable` and unregisters and
closes in finally. It fails unavailable if that shared helper is absent. Test
fixtures inject the opener/transport. Requests use a fixed HTTPS host and bounded
response body; endpoint JSON remains stateless (`store:false`, no conversation
ID, no tools for OpenAI). Hosted adapters currently buffer one bounded response
and emit the common event sequence; they do not promise token-by-token network
streaming. The HTTP timeout is capped by the remaining monotonic deadline and
events recheck that deadline. Strict whole-response deadlines against a dribbling
peer also require the scheduler's deadline watchdog to cancel the shared token;
a socket-operation timeout by itself is not a total elapsed-time limit.

## Jev protocol verification and baseline

On 2026-09-29 the primary [AIMLAPI Jev API reference](https://docs.aimlapi.com/api-references/decision-models/typesafe/jev)
documented POST https://api.aimlapi.com/v1/decisions with model `typesafe/jev`,
`state`, and `questions`. It describes noul, choice, and score questions and
answers, confidence/distribution fields, and input/output token usage. The adapter
validates requested answer keys, types, bounded finite numbers, distributions,
choices, score indices, and legends. It records the resolved model from responses.
The [vendor integration article](https://aimlapi.com/blog/what-is-jev) notes the
need for a non-default User-Agent; the transport supplies one.

This verifies a published protocol, not paid account access, availability,
accuracy, calibration, current pricing, latency, or independent vendor benchmark
claims. No live Jev request was made. Reported confidence is retained as provider
data, not used as autonomous action authorization. DecisionBaseline provides a
local lexical choice comparator that explicitly abstains on ties/no match and
has `confidence:null`; it makes no probability or calibration claim.

The optional OpenAI adapter follows the primary [text generation guide](https://developers.openai.com/api/docs/guides/text)
and [Responses migration guide](https://developers.openai.com/api/docs/guides/migrate-to-responses).
It rejects incomplete, refusal, malformed, and unexpected non-message outputs.

## Evidence and remaining cutover work

`tools/v2/provider_swap_test.py` requires LEON_TEST_SANDBOX=1. It creates one
synthetic snapshot, restores it independently for two fixture providers, and
compares identity/facts/goals/memories/procedures separately from task correctness.
It deliberately gives the second fixture a different arithmetic answer. The
report explicitly sets fixture_only=true and live_provider_parity_verified=false.
It never accepts or opens canonical state paths and creates no real identity.

The sandbox unit tests cover capability/no-tools admission, cancellation and tool
drain, serialization, health/failover, atomic and persistent budget accounting,
HTTP cleanup/redaction, hosted opt-in/payload validation, Jev schema validation,
and isolated state-swap evidence. Shared HTTP cancellation itself is owned and
tested in Phase 3. Package success is not Phase 9 cutover: integration still must
wire the scheduler and compatibility facade, verify shim bounds/no-tools/session
behavior, configure persistent budgets and prices, and perform separately
authorized live provider parity/quality evaluation on isolated snapshots.
