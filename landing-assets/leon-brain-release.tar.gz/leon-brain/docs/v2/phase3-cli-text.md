# Verified Claude CLI text lane

`brain/inference_cli_text.py` is an isolated transport for root's
`BrainResponder._respond_text_only`. It imports only the standard library and
the inert cancellation exception; it does not import the responder, server,
brain runtime, tools, recorder, or canonical stores. No integration files are
changed by this candidate.

## Verified contract

Read-only local inspection on 2026-09-29 found `/usr/bin/claude` resolving to
`/usr/lib/node_modules/@anthropic-ai/claude-code/bin/claude.exe`, version
`2.1.278`. Its `--help` explicitly documents empty `--tools`, safe mode,
strict MCP configuration, disabled session persistence and denied permission
prompts. The [official CLI reference](https://code.claude.com/docs/en/cli-reference)
also distinguishes tool availability (`--tools`) from prompt-free permission
rules (`--allowedTools`). This transport uses the former and never enables a
permission bypass. The primary source was read for flag semantics, not used as
evidence of a successful model call.

`verify_cli(executable, env=..., cwd=...)` runs only bounded `--help` and
`--version` probes. Required flags, documented disabling behavior and the reviewed
version must match. A realpath/device/inode/size/mtime stamp binds the contract
to the executable; replacement requires reverification. No global verification
cache, automatic installation or model call is performed. New CLI versions are
refused until their behavior has been reviewed and explicitly added.

Every inference argv includes safe mode, an empty built-in tool list, strict
empty MCP JSON, disabled skills and Chrome, `dontAsk` with permission prompts
`none`, and `--no-session-persistence`. No `--resume`, `--continue`, fallback
model, API transport, `--bare` or permission bypass is available. The
installation's managed policy remains in effect: safe mode is not an OS sandbox
and does not override administrator policy. Deployment review must establish
that this managed configuration itself is compatible with the no-tools lane.

The stream must begin with init metadata explicitly declaring `tools=[]` and
`mcp_servers=[]`. A reported bypass mode, hook activity, tool content, tool input
deltas, tool stop reason or permission denial fails closed and kills the owned
process. Init must preserve `dontAsk`; nonempty reported plugins/skills refuse.
Unknown unsupported record types and system events also refuse. This provides transport
enforcement and observation, not proof against a compromised CLI executable.

## Identity, sessions and billing

`TextRequest` takes the caller's exact `system_prompt` and already-composed
`prompt`, including the requested history, brain state, profile and memory.
The transport does not rebuild identity or silently drop history. Large user
prompts travel over nonblocking stdin; identity uses the verified system-prompt
flag and rejects more than 64 KiB instead of truncating it.

The caller supplies model, effort, cwd and environment explicitly. Existing
HOME/config/OAuth settings are retained. As in the current one-shot responder,
a stale `ANTHROPIC_API_KEY` is removed so it cannot override subscription OAuth.
Explicit API/proxy/third-party provider settings are refused. Bare/simple mode
is refused because its authentication behavior differs. Nested-session markers
and administrator policy are preserved.

`subscription_auth_verified` defaults false and must be true only after the
integrator verifies subscription authentication for the chosen environment.
The flag is a caller trust contract, not an independent billing audit: managed
auth policy can still require rejection at integration. No API fallback or paid
provider is selected here.

An optional UUID `session_id` supplies explicit transient CLI session identity;
it is never resumed or persisted by this transport. `conversation_id` is opaque
correlation metadata for the canonical responder session. History/recorder
ownership stays entirely with the caller. Only a `done` event may trigger the
existing persistence path, guarded again against cancellation and double writes.

## Process ownership and events

Each call creates its own POSIX session/process group. Nonblocking selectors
feed stdin and drain stdout/stderr without pipe deadlocks or reader threads.
A bounded watchdog enforces absolute and stdout-idle deadlines even while the
consumer pauses at a yielded event. One token callback kills only this group's
processes and returns promptly; final cleanup removes it, joins the watchdog,
closes pipes and reaps the child. Generator close, malformed output, output
floods, callback failures and timeouts use the same cleanup path. This candidate
fails before spawning on non-POSIX platforms; Windows job-object acceptance is
not claimed.

`on_spawn(proc)` and `on_exit(proc)` allow root's process registry/lifecycle
integration. Exit cleanup is invoked even if registration fails, so registry
removal must be idempotent. These callbacks must be prompt and must never write
completed-turn history. No callback gets raw stderr; transport errors expose
sanitized codes only.

`stream_text` yields dictionaries with `model`, `delta` and `done` types.
Root maps these into its `StreamEvent` and sentence/TTS flow. A terminal success
JSON record and clean process exit are both required before `done`; failed,
incomplete, contradictory or cancelled streams cannot produce it. Deltas can
precede a later failure, as with other streaming transports. There are no retry,
fallback, tool-dispatch or persistence methods. This describes application-level
behavior; the verified flags do not establish that the CLI's internal network
retry mechanism is disabled. Always close a partially consumed generator.

## Root integration and tests

The caller should reuse its existing identity/profile/memory composition and
model routing, verify the CLI contract at a safe lifecycle boundary, then pass
the per-call scheduler token and registry callbacks. A cancelled or unsupported
CLI request must remain terminal in this lane. It must not flow into the old
tool-enabled CLI or API branch. `persist_history` and `recorder_owned` remain
root-owned, and no cancelled turn should reach a completed-turn write.

`tests/test_inference_cli_text.py` imports modules in a private package and
spawns only local Python fake children. It covers flag construction, exact
identity/history stdin, read-only capability probing, tool/hook/permission
refusal, malformed streams, output bounds, large stdin, cancellation, generator
close, deadlines while paused and registry cleanup. No installed CLI model call,
auth login or network service is used in tests. On the VPS root must stage the
three owned files with hash guards and run:

```
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase3 /opt/leon-v2-tools/test-results/phase3-cli-text-20260929-a --mem 768M -- python3 -m pytest -q tests/test_inference_cli_text.py
```

Local source/CLI-help snapshots and the SHA256 manifest are under
`C:/Users/pazzo/Desktop/leon-takeover/cli-text-candidate-20260929/reference/`.
All 24 transport tests passed in root's serialized sandbox run at
`/opt/leon-v2-tools/test-results/phase3-final-callers-a` on 2026-09-29.
This proves the fake-child contract; live authentication and responder wiring
remain separate integration gates. No production
flags, sessions, history, auth, service or deployment changes are part of this
candidate.
