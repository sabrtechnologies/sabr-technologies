# Task runtime check-service boundary

TaskExecutionConfig can select one trusted remote handler factory instead of
the existing local containment wrapper. Startup binds that factory to fresh
parent policy authority; an absent or invalid handler cannot use raw local
check execution. Initial task OFF remains cold. The existing startup owner
passes the selected boundary and owns its workers through retirement.

Private LEON_TASK_CONFIG schema 2 uses exactly `schema`, `operational_dir`,
and `check_service`. The endpoint contains exactly `socket_path`,
`service_uid`, `cgroup_path`, `config_path`, `configuration_sha256`,
`entrypoint`, and `python_path`. The separately pinned operator service
configuration supplies one managed workspace and fixed checks. Parent and
service must pin the same installed source objects, service JSON and socket.
Its forbidden roots must cover the actual canonical persistence, private
parent metadata/configuration, service configuration and installed source.
Service metadata directories are disjoint from parent metadata, actual
canonical persistence, private configuration and installed source. Loading does not
start or probe the service. Schema 1 keeps the existing containment contract.

Immediately before execute IPC, the authenticated bridge invokes a callback
that rereads the durable task, action and grant. It rejects changed attempts,
cancellation, revocation, expired authority, disabled flags and retiring
owners. The callback does no bridge RPC, avoiding recursion on the service's
single protocol owner. A refusal before send is definitively unexecuted;
lost replies after send remain UNKNOWN and use lookup without replay.
Preview and admission release the parent lock before service IPC, then
recheck local configuration and retained submission state afterward. A
concurrent preview cannot block an executing check's final authority read.

Tests combine real TaskRuntime, policy, store, worker and bridge handler with
a synthetic transport, including revocation during handshake, lost replies,
durable receipts, idempotence and prohibition of local execution. Those tests
do not establish process confinement. The dedicated service identity,
cgroup, real namespace boundary and live approval path still require their
separate operator acceptance gates before activation.

Validation: 280 tests and 19 subtests pass across ten isolated modules,
with two explicit skips for unavailable cross-UID capability and nested
namespace execution. The 24 adapter tests include actual installer OFF-to-ON
activation, single factory/worker ownership, expiry during handshake, and
parallel preview/submission while another action reaches final authority.


## Private planner configuration

Schema 3 retains schema 2's required check_service boundary and adds exactly
planner: {enabled: boolean, scopes: [...]}. Each scope must provide exactly
project_scope, allowed_actions, allowed_paths, allowed_checks, max_steps,
max_rounds, lifetime_s and authorization_revision. Lists become immutable
tuples. Actions must be registered, paths must be explicit valid relative
paths, and check names must exist in the pinned service workspace. Duplicate
scopes, implicit budgets, unknown fields and truthy non-booleans are rejected.
The private operator file remains owner-only and is loaded only on task opt-in.
Loading validates local configuration but creates no registry, worker, model
request, check launch, or service connection. Actual service readiness and
confinement remain separate execution-time gates.
