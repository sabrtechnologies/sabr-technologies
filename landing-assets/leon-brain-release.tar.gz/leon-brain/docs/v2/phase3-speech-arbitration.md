# Shared speech interruption candidate

Default OFF. This extends the existing `speech_queue` worker, its real voice
consumers, and browser playback. It adds no inference owner, action executor,
microphone loop or synthesis worker. Streaming sentences remain independent of
inference; final speech completion does not wait for audio drain while owning a
model slot. Committed TaskWorker actions remain entirely separate.

## Cold install seam (root-owned startup)

```python
from brain.voice import speech_queue
from brain.cognition.speech_runtime import SpeechRuntime
speech = SpeechRuntime(queue=speech_queue, configured_mode=configured_mode,
    live_mode=lambda: flags.live_mode("speech_arbitration"),
    runtime_accepting=runtime_accepting).start()
# Existing runtime tick calls speech.tick(); hot paths read its cached bool.
```

The `enabled` callback must return literal True for active configured operation;
OFF, SHADOW, errors, missing installation and truthy non-booleans are inactive.
Installing only stores callbacks and starts no worker. Root owns the OFF flag,
trusted lifecycle binding, and existing actuator adapter. `stop_audio(event)`
receives only `type`, `response_id`, `speech_session`, `speech_generation`, and
`reason`. It should invoke the existing audio.stop actuator with a short bounded
timeout. It must not call speech queue APIs recursively, wait for synthesis, or
cancel a task/check. The queue emits browser cancellation itself using the
interrupted turn's existing send callback; the adapter must not duplicate it.

At retirement, `speech.quiesce()` first closes admissions without waiting for
synthesis, ownership-transition fences, or sink callbacks. `speech.stop()`
returns promptly and retains one background cleanup caller until the existing
queue drains. Existing runtime ticks retry an incomplete drain; there is no
new persistent loop. `stop(join_timeout=...)` optionally waits for that caller,
and retirement is complete only after it exits. Root must retain the owner and
refuse replacement until `speech.retired` is true.

The lower-level `speech_queue.stop(timeout=...)` timeout bounds its worker join,
not transition-fence or sink-callback time. Never invoke it directly on the
runtime tick or ASGI event consumer. `clear_arbitration()` rejects an open or
draining worker. Clearing preserves the admission freeze so old consumers
cannot resurrect speech during replacement. Only an explicit cold install
unfreezes admission, and install rejects every existing binding until its owner
clears it. Existing initial OFF behavior remains available without a binding.
The runtime's retired handle becomes inert so repeated shutdown calls cannot
freeze or clear a replacement. These are process lifecycle guarantees, not
physical playback-stop receipts.

Root creates a `SpeechRuntime` for configured ON, or to reopen a previously
frozen queue after its prior owner has fully retired. Initial OFF/SHADOW leaves
the queue untouched and requires no audio import or speech owner. An OFF/SHADOW
replacement may install a false-predicate binding to reopen legacy speech;
the prior binding must be cleared and its worker drained first.

## Ownership and actual hooks

Each selected speech turn gets a process session and monotonically increasing
generation. It emits `brain_audio_owner`, tags audio/completion, and emits one
`brain_audio_cancel` when replaced, stopped or interrupted. A queue transition
fence prevents a delayed sink-stop callback from crossing into a newly admitted
speech generation. The condition used by sentence submission and synthesis is
never held while calling the UI, inference cancellation callback, or actuator.
Old turn objects cannot cancel successors, even when response IDs are reused.
The audio daemon closes the existing speaker ledger through `interrupt`'s
bounded `after_stop` callback inside that same fence; closing the old playback
window after releasing the fence could otherwise truncate a newer reply.

Server helpers recheck tagged ownership at actual asynchronous WebSocket
delivery. Browser handlers stop the interrupted audio queue and browser fallback,
reject stale/cancelled generations, and ignore late cancellation of a successor.
They retain at most 16 retired process sessions; if full, new sessions fail
closed until page reload rather than forgetting a cancelled owner. Untagged
legacy traffic retains the existing behavior. This is local process/output
coordination, not a durable playback receipt.

Existing PTT/audio-daemon barge-in and pipeline VAD edges now reach this shared
owner when selected. Pipeline edges preserve capture-time speaker rejection;
accepted final voice/wake utterances and dashboard text also suppress previous
speech. This does not add acoustic echo cancellation or prove that a muted mic
can detect real speech over playback. Explicit push-to-talk/Stop remains the
reliable interruption signal where hardware does not provide duplex separation.

The accepted inference consumer binds only its own scheduler handle to its
SpeechTurn. Cancellation requests that handle to stop while its existing
provider guard continues draining committed tool results. Local conversation
binds its captured token/handle. Selected HTTP/WebSocket Stop coordinates these
conversation handles and the responder's user channel; it never calls
TaskRuntime.cancel, TaskStore.cancel_task or a project check-abort callback.
Explicit durable task cancellation remains a separate authorized task endpoint.

Selected unsolicited `broadcast_response` uses priority 30 through the same
speech worker and yields to active foreground speech. Direct user speech has
priority 100. Foreground priority includes the expected queued clip durations,
capped at 120 seconds; completed synthesis alone does not allow background
speech to replace audio still expected to be playing. This bounded estimate is
not a physical playback acknowledgment. Selected wake speech uses the shared queue even when the older
independent wake-queue migration flag is OFF. Queue failure stays text-only.
No new synthesis loop or inference fallback is added.

## Verification

The lifecycle follow-up run
`/opt/leon-v2-tools/test-results/phase3-speech-lifecycle-20260929-a` passed
**131 tests in 2.80s** across the same modules plus `test_speech_runtime.py`.
It exercises the real queue with the runtime under blocked sink callbacks,
worker-construction races, late publication after quiesce, incomplete drain,
retirement-thread start failure, stale retired handles, and ON-to-OFF/SHADOW
replacement. Follow-up staging verified clean parent
`41341fcfb13448f5adff689eff94d30e4c219fad` and every changed source hash;
prior versions are preserved at
`/opt/leon-v2-tools/source-backups/handoff-speech-lifecycle-20260929/before`.

The serialized 768M sandbox run
`/opt/leon-v2-tools/test-results/phase3-speech-arbitration-20260929-c` passed
**117 tests in 2.51s** across speech arbitration/queue, inference admission
consumers, local conversation scheduler, TaskWorker, pipeline-send gate and
audio-gate modules. Original file hashes were checked against base
`c050b54d01f08428444cbdc4497b36d8cfd58b21` before staging; backups remain at
`/opt/leon-v2-tools/source-backups/handoff-speech-arbitration-20260929/before`.
The existing CRLF encoding in `brain/audio_daemon.py` is preserved; whitespace
verification uses `git -c core.whitespace=cr-at-eol diff --check` so legitimate
CRLF line endings are recognized without changing repository configuration.
Tests use fixture
synthesizers, actual AST-loaded ingress/broadcast/Stop functions, real browser
ownership code executed by Node inside the guarded sandbox, and a real
TaskStore/TaskWorker fixture whose committed action finishes and retains its
receipt after speech interruption. There are no real models, microphones,
actuators, credentials, workspace actions or canonical state writes.

This candidate does not demonstrate physical playback latency, echo separation,
or live acceptance. Actual devices still require the established gated rollout
before claiming those properties. Root lifecycle wiring is described below.

## Runtime installation and disablement (2026-09-29)

`LEON_SPEECH_ARBITRATION` and the live `speech_arbitration` flag both default
OFF. Only configured ON plus live ON and an accepting cognitive runtime select
arbitration. SHADOW and CANARY do not take audio ownership. The existing runtime
tick refreshes this cached selection; audio hot paths never read the flag file.

The root installer attaches `SpeechRuntime` before publishing the cold queue
binding, and before starting the cognitive consumer. It starts no synthesis,
inference or periodic worker. Shutdown immediately freezes admission and late
output, while one owned cleanup thread performs potentially blocking sink
callbacks and drains the existing speech worker. Reinitialization retains the
old runtime until that cleanup actually finishes. A stale retired handle cannot
quiesce the replacement.

Initial OFF/SHADOW imports no audio module and creates no speech owner; it only
probes metadata if the queue is already loaded. After a prior ON
lifecycle, a new runtime can explicitly reopen legacy speech. If the whole
cognitive runtime is disabled, the successful root installer instead invokes
`resume_legacy_after_retirement`, which refuses a remaining arbitration binding
or undrained worker, clears only the admission fence and starts no worker.
Ordinary stop/clear operations remain frozen; late consumers never call this
installer-only transition. Invalid configuration and installation-error cleanup
also restore legacy speech after confirmed complete retirement. Incomplete
cleanup retains the old owner and fence, so a failure cannot admit a successor.

`test_speech_hooks.py` exercises real startup and OFF-to-ON live changes,
runtime pause, blocked sink shutdown, retained owners, startup/shutdown races,
ON-to-OFF replacement and complete runtime disablement. These tests establish
software lifecycle behavior, not physical microphone/playback latency. The
original Wave A soak remains FAIL; no production speech flag was changed.
