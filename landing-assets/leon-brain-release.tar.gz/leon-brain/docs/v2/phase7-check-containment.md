# Confined named-check candidate

This is a default-deny factory and integration adapter for registered
`project.run_check` actions. It does not install software, create cgroups, change
services/sysctls, grant permission, open private state, run models or activate
TaskRuntime. Existing workspace exclusivity and exact durable grants remain
mandatory. The candidate requires Linux and an already available non-setuid
bubblewrap binary. There is no unconfined subprocess fallback.

## Root integration contract

`ContainedCommand(name, argv, cwd='.', timeout_s=30)` is trusted fixed
configuration. `CheckContainment(scope, root, checks=tuple(...),
forbidden_roots=tuple(...), bwrap='/usr/bin/bwrap', python=None,
shared_resources=())` produces:

* `.workspace`: the immutable Workspace containing factory-built Checks. Use
  this exact object when creating ProjectActions; adding/replacing checks changes
  its canonical configuration digest and fails containment validation.
* `.authorize(action, task, spec) -> bool`: compare the entire canonical spec,
  verify pinned files/root, actual resource boundary and mandatory namespace
  probe. Compose this with TaskPolicy.authorize; containment is not permission.
* `.validate_spec(spec) -> bool`: the equivalent preview gate before task/action
  identities exist. Do not pass None identities to authorize; that always denies.
* `.wrap_handler(handler)`: install this around the registered run-check handler.
  It verifies the trusted supervisor completion protocol. **The authorization
  callback alone is insufficient.**
* `.availability()`: sanitized availability/reason information. No arbitrary
  command runs during probing; a fixed read-only probe runs at most once every
  30 seconds per factory, including failed probes.

The factory hashes the fixed manifest into `Check.containment_ref`; this includes
the exact command/cwd/timeout, approved root device/inode, forbidden paths,
runtime mounts, and binary/interpreter/runner identity and SHA-256. The containing
Workspace's normal configuration hash also binds these generated Check argv.
These are revalidated before effects. An attestation string supplied by a caller
cannot replace the factory's actual verification. A changed binary, source file,
workspace identity or configuration requires new finalized configuration/grants.

The root must include operational metadata, canonical state and every other
private workspace that could overlap runtime directories in `forbidden_roots`.
The factory rejects overlap with the approved workspace or exposed system runtime
directories. It rejects runner source inside the mutable approved workspace.
Path/name/command inputs are trusted local configuration, never request body or
model-selected launch flags.

## Filesystem, network and process policy

The bubblewrap filesystem starts empty. Only the approved workspace is mounted
read/write at `/workspace`. Fixed system binary/library directories are mounted
read-only: `/usr/bin`, `/usr/lib`, `/usr/lib64` when an ordinary directory,
`/usr/local/bin` and `/usr/local/lib`. The conventional `/usr/lib64 -> lib` alias
is reconstructed when present. `/bin`, `/lib` and `/lib64` are sandbox symlinks.
The trusted runner is mounted as one read-only file. No host root, `/opt`, `/var`,
`/run`, `/home`, `/root`, `/sys` or host `/proc` is exposed. The sandbox receives
private `/proc`, minimal `/dev`, temporary `/tmp` and an empty temporary HOME.
The launcher closes extra inherited descriptors before exec. The environment is
cleared and contains only fixed PATH/locale/HOME/TMPDIR settings.

A bounded no-follow workspace audit rejects sockets/FIFOs/devices, symlinks,
multiply-linked files, nested host mounts and group/world-writable entries.
Otherwise a workspace bind could expose a host service socket or a hardlink to
private state despite its mount layout. The audit allows at most 10,000 entries,
16 directory levels and one second; exceeding a bound denies the check. It is
repeated immediately before launching. Exclusivity is still required to exclude
uncoordinated host changes between validation and namespace construction.

Mandatory new user, mount, PID, network, IPC and UTS namespaces are combined with
disabled further user namespaces, no capabilities, no-new-privileges, a new
session and parent-death cleanup. Bubblewrap is a policy-building tool; these
restrictions come from the exact argv, not from its executable name.
[Bubblewrap's security documentation](https://github.com/containers/bubblewrap/blob/main/README.md).

The check itself is never namespace PID 1. A trusted read-only Python supervisor
owns PID 1, disables its dumpability and keeps parent-death SIGKILL. It runs the
fixed command as a child. On completion, timeout or termination request it kills
remaining namespace children and reaps until ECHILD before emitting an accepted
exit code. This includes double-fork and setsid descendants. Linux PID namespaces
limit which processes are visible/signallable; terminating their init also kills
remaining namespace members.
[Linux PID namespace documentation](https://man7.org/linux/man-pages/man7/pid_namespaces.7.html).

Only supervisor codes 0 (successful command, drained descendants) and 10
(unsuccessful/aborted command, drained descendants) are recognized, together with
ProjectActions' process-group proof. Arbitrary child exit codes never pass
through; setup/supervisor failures use 125. A killed outer launcher, outer timeout,
output-limit abort, missing group proof, unexpected code or other ambiguous
completion becomes UNKNOWN and retains all TaskStore resource fences. Neither
stdout nor an action-provided assertion is accepted as a termination proof.
Bubblewrap's documented PID-1 and parent-death behavior is part of this protocol.
[Bubblewrap options](https://github.com/containers/bubblewrap/blob/main/bwrap.xml).

The inner command timeout is at most 118 seconds; the outer fixed Check adds two
seconds for teardown. PID 1's reap budget is one second. The existing backend's
2 KiB output limit and bounded TERM/KILL remain in force. Per-process core dumps
are disabled, open files limited to 64 and individual file sizes limited to
8 MiB. This is not a workspace aggregate disk quota.

## Resource and readiness gates

The actual calling cgroup-v2 hierarchy must already impose finite effective
limits no greater than 768 MiB memory, 64 processes/threads and one CPU of quota.
The adapter reads real membership/mount/control files and includes ancestor
limits; supplied labels or booleans cannot satisfy this check. It never writes
cgroup controls or provisions a host boundary. The limits constrain the caller's
boundary, not a newly created per-check cgroup. Deployment must choose an
appropriate isolated task execution boundary: sharing a constrained cgroup with
the brain does not provide independent memory/CPU availability guarantees.

The production Leon process hosts SNN/model memory above this candidate's
768 MiB ceiling. Direct in-process TaskRuntime execution therefore cannot pass
this readiness gate. Integration requires a separate trusted check-execution
service in an already provisioned bounded cgroup; it must not lower Leon's
service limits to satisfy the check. That service/bridge and host provisioning
are outside this commit. Preview must obtain readiness from the execution
boundary, and the actual check must reverify it there before effects.

Live acceptance additionally requires proving the namespace probe, mount privacy,
network separation, same-UID supervisor integrity and descendant teardown in the
intended execution environment. Read-only runtime directories are trusted host
software; the approved workspace remains exclusively managed, since filesystem
namespace construction cannot make hostile concurrent host renames transactional.
No kernel exploit protection, aggregate disk quota, host setup or live acceptance
is claimed by the command-builder tests.

## Observed test-environment limitation

An allowed probe through the existing serialized 768 MiB launcher found installed
**bubblewrap 0.12.0**, with all required options and no setuid bit. Mandatory
nested user namespace setup failed with `setting up uid map: Operation not
permitted`. The outer test cgroup reported memory.max 805306368, pids.max 38478,
and cpu.max `max 100000`. Those PID/CPU limits also fail this candidate's runtime
readiness gate. The launcher was not weakened and no host settings were changed.

The real namespace regression first runs an independent minimal vendor probe.
Only the identified namespace permission restriction permits a reported skip;
other failures must fail the regression. If the environment permits it, the test
checks private-path invisibility and a setsid descendant that must not survive
the supervisor. Pure configuration, resource-parser and result-proof tests use
temporary fixtures and explicit fakes; they are not evidence of live confinement.

The fixed trusted namespace probe uses `communicate(timeout=3)` and validates
output lengths after reading. That is a time-limited trusted probe, not a general
streaming output bound. Configured check output uses the separate backend limit.

## Candidate evidence

The unchanged serialized 768 MiB sandbox ran the containment and project-action
modules together: **59 passed, 1 skipped in 1.27 seconds**. The skipped test is
the mandatory real nested-namespace fixture described above. No live confinement
or deployment readiness is claimed.

* Checkout base: `0c72af262e6d8e6bbf54509971427dff4973a84a`.
* Receipt: `/opt/leon-v2-tools/test-results/check-containment-tests-20260929a/tests.xml`.
* Receipt SHA-256: `4362113d54ae75aea8d0985eb5c3053eb434fc7896238e0a838f4e7a580d05bb`.
* Tested-source manifest: the same directory's `tested-source.sha256`, covering
  containment, project actions, their tests, TaskWorker and TaskStore.
* Manifest SHA-256: `54ad929bf31dbf3edaea9125c7074dd6d6a1652c86ea7c60713e9b8cfddf010a`.
* Preservation/staging evidence: `/opt/leon-v2-tools/test-results/check-containment-stage-20260929/`.
