# Phase 5 sensory runtime integration candidate

This candidate connects the existing SensoryHub/SceneModel to the existing
CognitiveRuntime, publisher and ExecutiveController. It has no capture, model,
tool, TTS, executive or additional bus consumer. Legacy perception remains
authoritative in every enabled mode.

Base: `b8d99672db7d2f308559861ca6fc055dc707c2df`, branch
`v2/phase5-runtime`, reused development checkout `/opt/leon-v2-worktrees/phase8`.
Phase 12 is preserved on its own branch at
`4ae2376d953a2288aab0dff772a0f9874e05b0f1`.

## Ownership and activation

`install_from_server_state(..., state_dir=...)` accepts the actual loaded
persistence owner's absolute directory. Missing/relative paths disable sensory
activation; this adapter never guesses from cwd, a worktree path, or an environment
variable. The original runtime still requires explicit `LEON_V2_RUNTIME` opt-in.
`LEON_SENSORY_HUB=off` is an independent upper gate. The live `sensory_hub` flag
must be shadow/canary/on, and the runtime must be accepting. Unknown flags and
flag-read exceptions fail closed. Canary/on both mean observe-only SHADOW here.

Construction is inert. The first enabled existing runtime tick loads the derived
scene, installs a single hub and starts the existing SceneModel persister. No
scene file, persistence thread or hub is created under the default live OFF
setting. The runtime ticks the adapter at most once per second using its existing
consumer loop. Meaningful observations publish immediately through the installed
helper; the tick also flushes final debounced changes without requiring another
capture. A live pause cuts off new observations without rebuilding the scene;
the persister may still finish previously accepted dirty data. Re-enable reuses
the same hub, scene, freshness and deduplication buffers.

Only `scene_model_v2.json` and its existing bounded changes log are written by
the existing SceneModel APIs. Legacy stores and legacy scene files are neither
read nor migrated. Historical observations survive restart, while current
occupancy still follows the existing freshness rules. Root-owned dashboard
readers must use `state.scene_model.state()` or `snapshot()['fresh_state']`;
the persisted last-observed snapshot is not a current occupancy assertion.

## Event projection

`sensory_hub.change` maps to `PERCEPTION_CHANGE` with source
`sensory_hub.<modality>`, priority 80, bounded observation metadata and up to 32
scalar scene changes. It preserves the observation ID, source timestamps,
confidence, change score, entity/field, old/new value, change sequence and
per-change observation ID. No caption, transcript, arbitrary features,
content reference or media is copied into the event. Runtime decision/sidecar
references carry only kind, observation ID, modality and change count.

The hub already debounces per entity/field. The publisher does not add coarse
modality coalescing, which would discard unrelated changes in different batches.
All events continue through the existing EventBus and existing executive's
`plan_event(..., dry_run=True)` interlock. No focus request causes inference or
capture; focus remains an advisory request for a future executive integration.

This integration does not add a durable event outbox. Existing publisher
backpressure/refusal can drop an offered change, and shutdown does not replay
queued observation events. The persisted scene remains a derived current-state
view. Do not claim reliable delivery of every transition or exactly-once delivery
across restart from this candidate.

## Stop, re-entry and persistence ownership

`runtime.stop(join_timeout=0)` immediately quiesces sensory admission and signals
the existing runtime worker. It does not join or flush the scene on the server's
nonblocking shutdown caller. The existing worker's `finally` block drains the
sensory owner and closes the sidecar. A small subclass of the existing SensoryHub
tracks admission across the full ingest -> scene.apply -> publish operation,
including calls through ingest_batch, so an in-flight producer cannot mutate
the scene after the final save or make a successor miss the last observation.
Previously obtained old hub references reject input after quiesce.

A producer still running, a persister join timeout, or a failed final save keeps
the runtime, hub, scene and global facade handles. Re-entry returns None with
`state.v2_runtime_reason == 'retirement_pending'`; it does not construct a new
consumer or replace the scene. Installation is serialized. Clearing server
handles is identity guarded so retiring an old owner cannot clear successor
handles. An unrelated installed hub is never replaced by this adapter.

Observe `runtime.stats()['sensory']` (mode, reason, ownership, in-flight count,
stopping/retired and failures) and `runtime.retirement_complete()`. Completion
requires the actual consumer thread to have exited and the scene owner to have
confirmed final persistence. A stale heartbeat is not evidence of retirement.
If the worker's first retirement attempt fails, the retained owner deliberately
requires an explicit lifecycle retry: `runtime.stop(join_timeout=...)` on a
management/lifecycle caller, or a subsequent installation attempt. Positive
timeouts bound thread joins, not the underlying atomic save; do not call these
retry operations on a latency-sensitive request or nonblocking shutdown caller.
No replacement or process-exit completion is implied by a zero-time stop.

## Root-owned integration patches

These files are outside this candidate's allocation and must be completed by
the integrator before the runtime integration gate is claimed:

1. `brain/v2_live_flags.py`: add `"sensory_hub": "off"` to DEFAULTS. Do not change
   live flag files as part of source integration.
2. `server/init_brain.py`: at its existing single V2 installation site, resolve
   `SAVE_DIR` from the already loaded `brain.persistence` module and call
   `_v2_install(state, state_dir=that_module.SAVE_DIR)`. Use the owning module
   attribute at call time so a configured/overridden path is honored.
3. If server state declarations/status APIs require explicit fields, add
   `sensory_hub` and `scene_model` handles initialized to None. The adapter sets
   them at activation and clears only its own handles at successful retirement.
4. Wire desired websocket scene readers to fresh derived state only; retaining
   legacy authority is intentional. Do not add a capture or independent model.
5. `tests/test_v2_phase2_structure.py`: add
   `"sensory_hub.change": "brain/sensory_hub.py"` to EXPECTED_SITES. The existing
   helper already meets the wrapped lazy-publisher call-site contract.
6. `tests/test_cognitive_runtime.py`: extend the exact all-site fixture table
   with `observation=SensorObservation(...)` (or a SimpleNamespace with ID,
   modality, source, created_wall/mono, confidence and change_score) and
   `changes=[{"entity_id":"person", "field":"present", "old":False,
   "new":True, "salience":0.9, "observation_id":"fixture-1", "seq":1}]`.
   The candidate's new tests independently verify this real builder.
7. Existing `server/__init__.py` calls `runtime.stop(0)`. That now quiesces and
   initiates the worker drain; a continuity-sensitive maintenance/restart path
   must additionally observe retirement completion before exiting/replacing the
   process. A failed drain must preserve handles and be reported, not treated
   as a successful save. This candidate does not change server lifecycle code.

## Validation

All execution occurs only through the serialized hardened VPS test sandbox at
768M, using temporary fixture scene paths and stand-in module loading. There is
no production initialization or real state access. Before edits, exact existing
source files and SHA-256 hashes were captured under
`C:/Users/pazzo/Desktop/leon-takeover/phase5-runtime-candidate/before` and
`source_hashes.json`; modified shared-file hashes were rechecked on the VPS.

The candidate tests cover lazy OFF and missing paths, all enabled modes staying
shadow, runtime/live pause, one hub/persister, final debounced change delivery,
bounded media-free projection, actual executive dry-run routing, restart
persistence, unchanged legacy fixture hashes, clean re-entry, failed final save,
in-flight producer shutdown, blocked persister retention, identity-safe handle
clearing, worker failure and unknown-hub refusal.

Run `tests/test_sensory_runtime.py`, `tests/test_sensory_hub.py`,
`tests/test_scene_model.py`, `tests/test_cognitive_runtime.py`, plus event bus and
event/executive tests after integration. The exact all-site test requires the
root-owned fixture update above; excluding it on this isolated branch is an
explicit allocation gap, not evidence that its full gate has passed.

Final candidate validation: **168 passed, 1 deselected in 14.03s**, with results
under `/opt/leon-v2-tools/test-results/phase5-runtime-20260929-d`:

```sh
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase8 \
  /opt/leon-v2-tools/test-results/phase5-runtime-20260929-d --mem 768M -- \
  python3 -m pytest -q tests/test_sensory_runtime.py tests/test_sensory_hub.py \
  tests/test_scene_model.py tests/test_cognitive_runtime.py tests/test_events.py \
  tests/test_event_bus.py tests/test_executive_dry_run.py \
  -k "not every_site_builds_json_only_payloads"
```

Remaining live gates are unchanged from phase5-sensory.md: source-ID parity,
multiple-dashboard capture counts, real-world false positives/misses, hot-path
latency/RSS, bounded persistence drain under actual I/O, and rollback/continuity.
Synthetic fixture outcomes demonstrate software behavior only; no improved
perception, calibration, consciousness or scientific hypothesis is established.
