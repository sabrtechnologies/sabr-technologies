# Improvement registry and proof-service composition

`test_improvement_bridge.py` connects the existing installed TaskRuntime and
ImprovementRuntime to CheckServiceBridge, the Unix CheckService protocol and its
durable ExecutionBroker. The actual operator planner, immutable child ingress,
approval registry, TaskStore, worker, parent effect authority, artifact validation,
sealed memfd transport and historical proof resolver participate in every case.
The sole service broker executor is the existing implementation; the tests add no
application runtime owner, action loop, promotion or deployment capability.

The service's parent-side peer/cgroup attestation and its snapshot executor are
explicit synthetic fixtures. The actual service verifies the connecting client's
kernel uid; the parent performs the real nonce/source-manifest protocol against a
synthetic operator endpoint. This establishes component composition, **not actual
production service identity, namespace confinement, mutation exclusion, descendant
drain or model improvement quality**. Those remain separate acceptance gates.

The positive case registers and captures an exact private artifact, approves a
baseline check, applies the approved replacement through the real backend, and
approves the candidate check. The synthetic trusted executor receives independently
validated baseline/candidate contents and creates its fixture proof only after the
broker's STARTED claim is durable. The unchanged bridge verifies its terminal
receipt, TaskWorker persists the exact result, and ImprovementRuntime hydrates
evidence through `bridge.resolve_input_proof`. READY_FOR_REVIEW retains
`promotion_allowed=False`; it confers no promotion authority.

Regressions cover lost execute replies with lookup-only recovery; ordinary checks
skipping reserved material; revocation during final material capture preventing an
execute send and broker claim; first historical proof lookup after approval
revocation/expiry and feature OFF without authority renewal; offline cached
history; failed, unknown, absent and mismatched completion proof; and a candidate
proof mismatch retaining the successful baseline. Deliberate service-store fault
injection verifies that a missing or substituted historical broker receipt cannot
qualify the parent's already-persisted result.

Only the new test and this documentation are owned by this change. Application
implementation and shared test runners are unchanged. Validation must use the
unchanged serialized sandbox launcher; no production endpoint is contacted.

Validation: **155 passed, 60 subtests passed, 1 skipped in 8.40 seconds** across
the new composition module, owner receipt/runtime/hooks and check bridge/service/
snapshot modules. The skip is the explicit real immutable namespace fixture gate,
not synthetic evidence of confinement. The new module independently passed
**18 tests in 4.38 seconds**. A 768 MiB isolated retry was refused by the unchanged
host-reserve guard; the authorized 512 MiB test cap then passed under stricter
MemoryMax while retaining the same fixed host reserve and overhead checks.

```text
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase5 /opt/leon-v2-tools/test-results/improvement-bridge-20260930-d --mem 768M -- python3 -m pytest -q tests/test_improvement_bridge.py tests/test_improvement_receipts.py tests/test_improvement_runtime.py tests/test_improvement_hooks.py tests/test_task_check_bridge.py tests/test_task_check_service.py tests/test_task_check_snapshot.py
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase5 /opt/leon-v2-tools/test-results/improvement-bridge-20260930-f --mem 512M -- python3 -m pytest -q tests/test_improvement_bridge.py
```
