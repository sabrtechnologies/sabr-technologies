# Installed development proposal ownership

The existing TaskRuntime owns the optional ImprovementRuntime. Startup prepares
the operator planner, then binds immutable parent constraints and the proposal
registry before workers may claim retained actions. Initial task OFF creates no
registry or proof boundary. Executive.improvement_handle authenticates and
captures the exact installed task owner for a request. Proposal calls remain
explicit and supervised; no additional planner, scan loop or outbox consumer is
installed. Retirement fences proposals before draining planner calls and keeps
the existing stores owned until those calls finish.

TaskExecutionConfig can select a proof_check_handler_factory instead of its
ordinary check factory or containment wrapper. The proof factory receives the
fresh parent effect callback and the prepared registry's exact classifier and
material resolver. It returns typed execution and receipt-verification
capabilities. Startup binds the receipt resolver before starting workers. A
missing, malformed or failed proof factory cannot fall back to another executor.

Private LEON_TASK_CONFIG schema 4 adds exactly `improvement` to schema 3.
Its fields are `enabled` and `workspaces`; each workspace supplies `key`,
`project_scope`, `source_revision`, `isolation_ref`, `input_files`,
`editable_paths`, `protected_paths` and `required_checks`. Each input entry
contains exactly a relative `path` and numeric `mode`. The loader freezes these
allowlists and checks them against the existing planner and service workspace.
It derives forbidden canonical, application and private metadata paths from
trusted installation context. Requests cannot choose another root or inject an
evidence callback. Loading configuration starts no model, worker or check.

Source revision and isolation references are operator provenance, not proof that
a Git revision was independently verified. Captured artifact bytes are not
execution evidence. A successful check without verified immutable input evidence
remains EVIDENCE_REQUIRED; ordinary writable checks cannot establish readiness.
The current pipeline requires a passing baseline. Expected-failure repair policy,
full autonomous event admission and promotion remain separate work.

Installed improvement configuration requires the proof-aware factory even when disabled. Legacy local wrappers and ordinary remote factories cannot substitute for it. Schema 4 also requires the validated service configuration to contain an explicit pinned immutable runtime file closure. Lower-level synthetic owner tests do not establish read-only execution.
