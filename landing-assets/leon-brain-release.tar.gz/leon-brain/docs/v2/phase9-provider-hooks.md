# Provider routing inside the admitted responder call

The existing scheduler's `responder_provider` now enters an optional
`ProviderHooks.admitted` scope around the existing `respond_streaming` facade.
The existing no-tools responder branch consumes that scope only after rendering
its messages and system context. The user-turn recorder, history lock, history
append closure, channel cancellation token, and scheduler worker remain the
existing owners. No new model thread, queue, scheduler, context builder, or
conversation store is created.

Default OFF, SHADOW, and unmatched scopes execute the baseline callback once.
SHADOW does not duplicate inference, construct adapters, open a ledger, or probe
credentials/endpoints. Calls consult cached admission only; flag reads and lazy
ledger construction belong to the existing runtime tick. A selected call that
has consumed its transport scope never falls back or replays after a transport,
protocol, cancellation, or accounting error. Before that point a route that
cannot dispatch is the unchanged baseline (see "Selection, baseline and the
breaker").

## Selection, baseline and the breaker

Production defect, 2026-10-03: with the dashboard scope routed, every dashboard
turn ended with `UnsupportedPolicy: provider routing requires this admitted
no-tools call`. The foreground consumers submitted the default tool-bearing
request, the hook selected by scope alone and then refused it, and a selected
route never fell back. The rules below replace that.

1. **Only a no-tools request can be selected.** `capture_submission` returns
   `None` (baseline) for a tool-bearing request in a routed scope. It is not a
   refusal; the legacy path with tools runs unchanged.
2. **The foreground consumers decide the tool policy per turn.**
   `inference_scheduler.foreground_allow_tools(sched, text, site=, group=,
   admission=)` answers `False` only when the hooks attached to the scheduler's
   responder would select this exact scope for a no-tools request right now
   (`ProviderHooks.selects_plain_turn`), the text is a plain conversation turn
   (`provider_hooks.plain_text_turn`), and the newest-wins gate holds no older
   pending text that would be merged into the turn. The three submit helpers
   pass the answer to `submit_foreground(..., allow_tools=)`. With no hooks,
   OFF/SHADOW, an unrouted scope or a non-canary route under CANARY the answer
   is `True` before the text is examined, and the request is the same as before.
3. **`plain_text_turn(text)` is pure and conservative.** It is `False` (keep
   tools) for: `local_llm.should_use_tools`, a `_maybe_command_action` match, a
   reflex match (`reflexes.would_reflex`, which never executes a handler; the
   learned-reflex match is `reflex_learning.matches_learned_reflex`), a Tesla
   fast-path match or its system note, a leading `/` (all override prefixes), a
   leading `[` relay marker, an attachment marker, an empty or oversized text,
   a missing recogniser, and any exception. A multi-line turn is plain only
   when every line is.
4. **Pre-dispatch unavailability is baseline.** Checked when the consumer asks,
   again at submission and again at admission: owner not ready (including an
   unverified or expired policy at activation), credential missing, policy
   expired, breaker open, budget. The budget check is
   `BudgetLedger.would_admit`, a read-only preview of the exact reservation
   the router makes (the reviewed input plus output bounds); nothing is
   reserved. `stats()["baseline_reasons"]` counts `tools`, `not_ready`,
   `credential`, `policy`, `budget`, `breaker`, `merged`, `oversize` and
   `retiring`; the counters carry no content. A foreground turn that was
   already submitted without tools and can no longer be routed is answered on
   the local no-tools transport (`prefer_local`), never on another hosted lane.
5. **The rendered context stays inside the reviewed input bound.** The routed
   lane keeps the system context and the current turn, adds the Leon V2 context
   package to the system context when its live flag is active for the turn and
   it fits, and drops the oldest replayed history first. When even the system
   context and the current turn cannot fit, the lane declines the unused scope
   before any transport call (`ProviderHooks.decline`), the turn continues on
   the local no-tools baseline and the route backs off for one cooldown. The
   reviewed bound is compared with bytes, so `max_input_tokens` must exceed the
   size of the stable system context for a route to be usable at all.
6. **Post-dispatch failure is terminal and opens the breaker.** A selected call
   that consumed its transport scope and did not complete ends the turn with
   the existing terminal error and is never replayed. The provider is marked
   unhealthy (`providers.health.route_breaker`, one failure, 120 s by default;
   `ProviderHookConfig.breaker_cooldown_s` is trusted code only and the operator
   file cannot carry it), so the following turns are baseline until the
   cooldown passes; the next routed call closes the breaker on success.
7. **Typed hosted text is spoken.** A typed adapter returns text without
   sentence envelopes; the lane derives `sentence` events from the completed
   text so the dashboard and voice consumers speak it. Original legacy envelope
   streams are passed through unchanged.
8. **One durable history write.** The no-tools lane writes the conversation
   rows once whether or not the user-turn recorder owns the turn; the recorder
   owns the post-turn bookkeeping, not the conversation rows.

Retirement and operator revocation are unchanged: a retiring owner keeps its
already selected no-tools scopes terminal, and a selected submission whose
route the operator removed before admission is refused.

## Root installation API

The installer now integrates the hook with the existing cognitive runtime,
scheduler and responder. A trusted operator integration may provide exactly a
`ProviderHookConfig` instance as `state.v2_provider_config`, then call:

```python
from brain.cognition.v2_install import install_provider_from_server_state
owner = install_provider_from_server_state(state)
```

Absent typed configuration remains unavailable. A mapping, credential-bearing
object, model-generated route or inferred provider is never converted into
configuration. The installer does not open a ledger, read flags, construct a
transport or invoke a model. It records a content-free `v2_provider_reason`.

`CognitiveRuntime.attach_providers` registers ownership under its shutdown lock
before publishing `state.provider_hooks` and the exact responder's
`_v2_provider_hooks`. The private binding retains the exact runtime, scheduler,
responder and configuration identities. Repeated installation returns the same
owner only when those identities and the configured mode still match. Foreign
bindings are refused. Runtime ticks activate the cold owner; no second timer,
inference queue or model worker is added.

Shutdown quiesces selection immediately. Runtime retirement requires facade
drain, router unregistration, owned-ledger closure and identity-checked hook
release. The terminal responder attachment remains until its exact scheduler
worker has exited, so queued selected scopes cannot slip into baseline transport.
A failed drain or release keeps the old owner reachable and prevents replacement. Release clears only its own references, never a newer or foreign
attachment. Full runtime initialization quiesces the old runtime, stops its exact bound
scheduler, and finishes hook release before constructing replacements. Runtimes
without provider ownership keep the scheduler's independent lifecycle. Independent scheduler installation also retires the bound provider
first and rebinds a cold owner to the replacement only after successful drain.
The server initialization hook retries installation after canonical initialization;
it does not discover provider policy or credentials. Replacing typed provider
configuration on a live binding first quiesces that binding; installation remains
pending until the explicit scheduler installer drains and replaces its worker.

Use existing `LEON_PROVIDER_ROUTER` / `provider_router`, both default OFF. The
existing runtime calls `owner.tick()`, `owner.quiesce()`, `owner.stop(timeout=0)`
and checks `owner.retired`. No timer is created here. Enabled ON/CANARY modes
can execute explicitly reviewed routes; SHADOW never does. CANARY selects only
routes whose frozen `canary` field is True, without model selection or invented
sampling authority. Other scopes retain baseline behavior.

`ProviderHookConfig` is frozen root-owned configuration containing:

- The existing frozen `ProviderPolicy`, with explicit provider specifications,
  pricing, full-call bounds, cancellation/no-tools evidence, expiry, allowed
  request scopes, and global/per-capability budget limits.
- Existing explicitly configured adapters. They must implement the original
  typed provider contract and declare `accepts_prepared_messages=True`; setting
  this attribute alone is not evidence that an opaque transport is verified.
- `ProviderRoute(scope, provider_id, capabilities, max_output_tokens,
  canary=False)` entries. Scope is the exact `RequestScope(site, group, channel)`.
  Language/coding/reasoning capabilities must actually exist on the adapter.
- Exactly one injected existing `ledger` or explicit `ledger_factory`. Injected
  ledgers remain externally owned. A factory creates an owned ledger only in
  an enabled lifecycle tick after policy validation. It is closed only after
  all admitted scopes, provider drain, and settlements retire.

The root config must come from trusted operator configuration, never model text,
tool arguments, inferred credentials, or a channel-derived user identity. Root
must validate any persistent ledger path against canonical stores and supply a
dedicated sidecar. No path, price, model, credential, paid permission, token cap,
or provider evidence is guessed by this implementation. In-memory ledgers are
fixtures or deliberate process-local accounting, not restart-persistent budgets.

Quiesce immediately stops new selection while retaining the cached selected-route
authority. Idle or queued requests for those scopes fail before entering the
responder facade, even after a later tick or completed stop; retirement never
silently chooses baseline transport. Explicit live OFF/SHADOW observed before
quiesce and unmatched scopes retain baseline behavior. Stop cancels only owned request tokens,
retains the exact scheduler registration until the entire facade scope exits,
then retires the router and owned ledger. This includes the interval before a
transport begins. The installer does not replace the responder attachment, scheduler, or
ledger while retirement is pending. Live OFF drains the old owner; a later ON
can build a replacement only after that retirement. Failed installation never
uninstalls another owner's scheduler registration.

## Exact caller path and accounting

The scheduler admission verifies the existing scheduler class, real worker
thread/context, running request identity, and exact cancellation-token object.
The resulting scope is private to that thread and responder. Its request ID,
trace, site/group/channel, tools/history policy, kind, and deadline are checked
again at the transport boundary. An already-used, foreign, changed, copied, or
unscheduled scope cannot dispatch a provider. No user-controlled provider ID is
read from the request; the frozen route supplies it.

`_respond_text_only` uses the selected route before importing or opening the
baseline local/CLI/API transports. `_respond_provider_text_only` passes the
existing `_build_messages` result and existing system/profile context through
the scope. The prepared messages are bounded JSON copied into
`ProviderRequest.legacy_kwargs["prepared_messages"]`, with explicit channel and
history policy. The full prepared-message/system byte bound must fit the reviewed
input-token reservation. The ordinary prompt remains available as the current
turn text; it does not replace the rendered history.

The original `ProviderRuntime` creates the single `ProviderRouter`, pinned to
that route under the existing inference slot. Budget reservations cover the
reviewed whole-call bounds. Only actual typed `Usage` with `usage_final=True`
can settle below the conservative reservation after normal completion. Unknown,
cancelled, failed, or abandoned calls retain their full reservation.

Raw original legacy event objects are returned unchanged after type/text
consistency checks. Typed events without a raw envelope are projected to the
existing `StreamEvent` shape. Usage events stay in accounting. Tool envelopes
are forbidden in this lane. The completed `done` event is held until the adapter
exhausts, closes, and settles; only then does the existing history closure run
and the outer recorder receive completion. Cancellation or a later protocol
failure prevents the completed-turn write. Events after done are rejected,
except accounting-only usage. No retry or alternate transport follows a selected
error.

A routed scope with invalid, expired, or still-initializing configuration runs
its unchanged baseline and counts `not_ready`; nothing is sent, opened or
reserved. Requested mode and its route list are published atomically; unmatched
scopes and OFF/SHADOW retain baseline behavior.

## Supported and unavailable transport contracts

The existing `OpenAIAdapter` now accepts the prepared message list with unchanged
user/assistant roles and text content, alongside the existing system context.
It includes those messages in input bounds and sends `store=False`, no tools,
and an explicit output cap. Rich content, unsupported roles, or extra message
fields are rejected before transport instead of being silently flattened. Its
activation still requires explicit root paid policy, model/pricing, credentials,
bounds/cancellation evidence, and budget; none is enabled by this candidate.

The current Claude facade is not a pinned provider: it may choose local/CLI/API
internally. CLI is unavailable without real whole-call token/billing evidence,
even though its no-tools transport exists. The current local stream may use a
remote FreeLLM endpoint chain and retry with a larger `num_predict`, so it cannot
be certified as local or fully bounded merely by its module name. Neither legacy
shim declares prepared-message support here and neither is silently wrapped.

Tool-bearing requests are never selected: in a routed scope they run the
unchanged baseline with tools. Routing them needs a separately verified
integration with the existing tool/history loop; this candidate does not bypass
it. Jev remains an optional typed decision advisor
requiring separate explicit paid policy and caller integration, never a language
or failure fallback. No credential or capability is fabricated for these gaps.

## Validation

Tests exercise the real `responder_provider`, actual responder no-tools method
bodies, existing scheduler/runtime/router, fixture ledgers, and deterministic
fake adapters. They never import application startup or send a model/network
request. Cases cover OFF/SHADOW, explicit canary/scope selection, exact admission,
prepared context and raw events, history ownership, unsupported transports/tools,
budget rejection, protocol/failure behavior, accounting-before-done, cancellation,
pre-transport retirement, live disable/resume, singular ownership, lazy ledger
cleanup, and prepared OpenAI request projection through a fake transport.

On the VPS use only the installed serialized sandbox launcher with 768M. The
lifecycle attachment is integrated; independently verified live configuration
is still required before any enabling. Production state, flags, services, identity,
and records are unchanged by this development candidate.

Final sandbox verification: `phase9-provider-hooks-20260929-e`, **242 passed in
15.72s**, exit 0. Coverage includes the new hooks, existing provider runtime and
five provider suites, scheduler, no-tools, cancellation plumbing, CLI responder,
user-turn recorder, Phase 3 structure, and response call-site inventory. Four
existing FastAPI lifecycle deprecation warnings came from the recorder test's
server import; the sandbox process exited cleanly. Exact module list and source
hashes are retained in the local candidate validation evidence.

Lifecycle integration regression verification: `phase9-provider-lifecycle-20260929-e`,
**367 passed in 40.18s**, exit 0, with the same four existing recorder/FastAPI
warnings. Coverage adds runtime ownership-before-publication, blocked facade
drain, owned-ledger cleanup, scheduler-before-detach barriers, replacement of
exact scheduler/responder/configuration identities, shutdown/attachment races,
and independent scheduler behavior when no provider is owned. Both maintained
test runners register the provider hooks and lifecycle suites.

The selected-route retirement regression was reproduced as three failures in
`phase9-provider-lifecycle-20260929-b` before the fix. Idle and queued selected
requests now fail explicitly after quiesce, tick or stop; genuine live OFF/SHADOW
and unmatched requests retain baseline behavior. All validation uses fixture
transports and temporary ledgers; no live provider was activated.

After the final stale-owner identity guard, the hook and lifecycle suites passed
again: `phase9-provider-lifecycle-20260929-f`, **56 passed in 13.01s**, exit 0.
A stale binding cannot quiesce or stop a foreign runtime owner.

## Submission authority and terminal refusal

The production responder callback now captures its exact responder once and
records a frozen selected-route capability before scheduler admission. This is
a private job field, never a request kwarg or model-authored policy. It binds the
existing request identity and route; the submitted callback is fixed for that
job. Worker admission verifies the capability again before the facade begins.
A queued selected request cannot turn into baseline inference when the hook is
replaced or live policy changes before execution.

For a selected request, shutdown, queue overflow, missing/dead worker and failed
user-gate registration/admission produce a terminal cancellation handle. They do
not escape through `submit_foreground`'s ordinary exception-to-legacy fallback.
The dead-worker waiter and all FALLBACK finalizations also respect the frozen
capability. Registration is not retried; the existing gate retains pending text
under its normal cancellation semantics, and acquired bridge locks still release
once. Actual WebSocket and voice handler tests verify one terminal response and
no legacy/provider replay.

While the singleton retains a retiring or failed scheduler, the route facade
keeps it reachable only for cached selected provider groups, so exact-site
submission can refuse safely. Explicit live scheduler OFF, provider OFF/SHADOW,
and unmatched scopes keep their baseline permission. The new provider probes use cached
route authority and the existing in-memory responder reference; they do not read
flags, build context, open a ledger or call a provider. After worker retirement,
the installer must also confirm singleton uninstallation before detaching the
terminal hook, because the same scheduler object is otherwise restartable.

Fallback validation: `phase9-provider-fallback-20260929-c`, **277 passed in
30.28s**, exit 0, with four existing recorder/FastAPI warnings. Final isolated
module validation used the maintained per-file driver in the same hardened
sandbox: `phase9-provider-fallback-20260929-d`, **4/4 modules passed in 23.08s**
(provider hooks 50, provider lifecycle 20, scheduler 38, admission consumers 11;
119 tests total). These fixtures exercise the actual voice submission wrapper,
voice/WebSocket terminal handlers, queued callback immutability and exactly-once
acquired-lock release after an admission exception. No models or live services
were used.
