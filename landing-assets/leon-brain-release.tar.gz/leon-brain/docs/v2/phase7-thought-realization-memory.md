# Private canonical realization attempts and receipts

This extends the same existing KnowledgeStore database and explicit owned
MemoryService capability introduced by the ThoughtIntent snapshot prerequisite.
It adds no database owner, model/provider, scheduler, thread, autonomous loop,
effect dispatcher, FTS row or identity update. Executive/InnerVoice cutover and
provider cleanup remain separate integration responsibilities.

`ThoughtRealizationRequest` is a frozen version-1 descriptor in
`brain.memory_service`: caller, channel, prompt_sha256, configuration_sha256,
priority, max_output_tokens, deadline_wall, tools_allowed=False and
persist_history=False. It exposes `canonical_dict()` and `sha256()`. Root supplies
the digest of the exact bounded private prompt and the installed policy/config,
never raw prompts, credentials or model-proposed permissions. Both boolean fields
must be literal False. Descriptor size is at most 2,048 UTF-8 bytes; output token
limit is 1..1,024 and priority 0..100. New admission requires a wall deadline in
the next 15 seconds; the installed scheduler must independently enforce its
monotonic deadline. The descriptor does not prove a provider obeyed it.

The captured ON MemoryService exposes:

- `admit_thought_realization(thought_id, *, snapshot_sha256, attempt_id,
  request_sha256, request_descriptor)`: persist ADMITTED before scheduler
  submission, after checking exact canonical thought/provenance and descriptor.
- `finish_thought_realization(attempt_id, *, thought_id, snapshot_sha256,
  request_sha256, outcome, text='', reason_code='')`: persist a terminal result
  after the caller has observed provider cleanup. COMPLETED requires nonempty
  private text of at most 8,192 UTF-8 bytes. CANCELLED, FAILED and UNKNOWN permit
  no partial text. This method does not itself observe or stop a provider.
- `recall_thought_realization(attempt_id)`: exact private retained lookup.

All return `ThoughtRealizationReceipt` (lookup may return None), with exact
thought/snapshot/attempt/request binding, typed request descriptor, state,
private text/reason, original admission and terminal timestamps, result SHA256,
principal/identity/producer, freshly_admitted, journal_mode, schema_version=1,
store='knowledge', record_id and terminal properties. These are private values;
they must not be placed in public telemetry or generic conversation history.
Canonical reference: `knowledge / thought_realization:<attempt_id>`.

Only a successful OWN fresh insert plus exact committed readback returns
freshly_admitted=True. A retained admission, replay, lookup or terminal result
always returns False. A missing result after commit raises; retry with the
original ID/value recovers False and MUST NOT resubmit inference. The existing
executive and installed scheduler still decide whether a fresh receipt may be
used now. A receipt by itself grants no model/action/speech authority.

There is exactly one attempt per thought in this initial slice. ADMITTED after
restart is ambiguous, not resumable permission. UNKNOWN is a retained terminal
fence. Neither state may be replaced by another attempt ID. No terminal state
can be rewritten, renewed or pruned, and no automatic retry method is supplied.
Same terminal state/text/reason replays idempotently; changed output or binding
conflicts. Historical recovery and terminal cleanup remain possible after the
request deadline. Any later retry policy needs its own explicit review.

The lazy `thought_realizations` and `thought_realization_limits` extension tables
are in canonical knowledge.db. Existing snapshot/legacy tables are untouched.
BEGIN IMMEDIATE, bounded owner/service/SQLite locks, exact private principal and
producer, inode/single-link checks, FULL synchronous connection policy, rollback
and separate committed readback follow the snapshot seam. No journal-mode
change, WAL checkpoint or universal power-loss guarantee is claimed. Deployment
must supply filesystem confidentiality; application private ACLs do not verify
UID/mode/parent-directory permissions.

Capability quotas add max_realization_attempts=4,096 and
max_realization_bytes=16 MiB, pinned at first successful admission. Each admitted
attempt reserves 16 KiB of payload capacity so a full registry cannot refuse its
bounded terminal output for lack of quota. The reservation excludes SQLite page,
index and journal overhead. No implicit pruning/quota increase occurs; default
byte quota therefore admits at most 1,024 attempts. The maximum configured byte
quota is 64 MiB. Descriptor/content validation precedes canonical locking.

The lifecycle adapter must deny NEW public admissions after quiesce while
retaining a captured ON service/capability for already-admitted provider leases.
Those leases may finalize CANCELLED/UNKNOWN/completed private output before
retirement. Turning that captured service OFF early correctly makes it refuse
the terminal write. This module does not install the adapter or dispatch queued
neural/memory effects; such effects need the canonical receipt and their own
current executive admission and replay policy.

Hermetic tests use actual canonical owner objects and temporary SQLite files.
They cover fresh/replayed admission, restart ambiguity, request/parent identity,
concurrent writers, quota reservation, expiry, immutable terminal results,
commit/readback failures, disabled mode, private retrieval isolation and database
replacement. No real model, provider, scheduler or production database runs.
