# Phase 6 memory runtime candidate

`brain/memory_runtime.py` supplies OFF/SHADOW background memory proposals over
already-created canonical owners. It does not construct stores, expose writers,
enable embeddings, render context, modify identity, or choose actions. Shared
startup/context/flag/event-runtime files are deliberately outside this commit.

## Root integration API

Create one instance after canonical initialization, or attach it earlier and let
each submit discover late handles. Root retains the instance and explicitly owns
shutdown/reconfiguration:

```python
from brain.memory_runtime import install_from_state
from brain.memory_service import SourcePolicy

source_policy = SourcePolicy(
    principal=authenticated_owner_id,
    identity_id=canonical_identity_id,
    allowed_sources=approved_read_sources,
    authority_by_source=trusted_authority_weights,
    authorize=source_specific_evidence_predicate,
)
memory_runtime = install_from_state(
    state, existing=previous_runtime,
    mode="shadow", policy=source_policy, policy_revision=reviewed_policy_revision,
    sidecar_path=approved_optional_v2_sidecar,
)
ticket = memory_runtime.submit(
    query, principal=authenticated_owner_id, identity_id=canonical_identity_id,
    policy_revision=reviewed_policy_revision, trace_id=trace_id,
)
proposal = memory_runtime.poll(
    ticket, principal=authenticated_owner_id, identity_id=canonical_identity_id,
    policy_revision=reviewed_policy_revision,
)
# A miss/pending/full queue returns None. Do not wait on the user path.
# SHADOW: log bounded proposal metadata; preserve baseline ContextPackage output.
stopped = memory_runtime.close(timeout=1.0)
```

Until a trusted owner/identity binding exists, root may explicitly construct
`SourcePolicy(principal=None, identity_id=None, authorize=...)` for legacy
unscoped SHADOW records and submit/poll with those exact None values. Restricted
principal/identity rows still fail closed. Never derive an authenticated ID from
a channel name, speaker label, source string or model output. Create and retain
one policy object per runtime configuration; repeatedly constructing a new policy
object is a reconfiguration and requires close first.

`existing` is reused only with the same state and configuration. A changed mode,
policy object/revision, sidecar or bounds requires explicit close first. A worker
that has not stopped cannot be replaced. Changes inside a policy object are
fingerprinted per request, but callback-internal policy changes also require the
caller to advance `policy_revision`. Root must not infer authenticated IDs or
authority from source labels, memory contents or model assertions.

OFF returns before path discovery, sidecar construction or thread start. SHADOW
creates one daemon worker with a bounded pending queue, bounded metadata cache
and bounded result map. Shutdown clears pending/results/cache, suppresses late
completion and joins for the requested bounded time. A false result means the
worker still owns its current read/callback; retain the instance and close again
after it drains. Read-only SQLite work has query deadlines; arbitrary injected
authorization callbacks must themselves be bounded. Thread cancellation cannot
forcibly stop a blocking callback, and the adapter does not claim otherwise.

## Canonical ownership

Paths come exclusively from these actual initialized objects:

| Adapter | Owner/path |
| --- | --- |
| knowledge | `state.claude_bridge.knowledge.db_path` |
| episodes | `state.cognition.episodes.path` |
| graph | `state.cognition.graph.path` |
| skills | `state.cognition.skills.path` |
| autobiography | `state.autobiography._path` |
| goals | `state.goal_system._path` |

Missing handles/files are reported as missing; no default path or constructor is
used. Skills can live outside brain_state. Goals use the existing GoalSystem,
not the separate persistent-goals service. Late autobiography/goals are detected
on subsequent submissions. Adapter writers are always absent. Sidecar aliases
are rejected by resolved path and existing-file identity, including symlinks and
hardlinks, before creating a worker or schema. Alias checks repeat as owners
change. The optional SemanticIndex is constructed only on the worker, only with
existing canonical bindings, and always with embeddings disabled. No backfill,
model load/download, canonical reinforcement or memory creation is started.

## Proposal and stale-cache semantics

A proposal contains request/trace IDs, an opaque scope hash, timestamps and frozen
references. Each reference contains canonical store/ID, text SHA256, source,
memory type, observation timestamp, separate score components and the original
unverified marker (null when absent, never invented as verified). It has no text
or arbitrary canonical metadata. There is no
confidence field and no action authorization.

The scope includes principal, identity, policy revision/configuration/callback
identity, actual owner identities, resolved canonical paths and file/WAL stamps.
Scope changes clear pending results and cached references; a worker result from
an old generation cannot publish. Cache keys additionally include the query hash.
Queries are capped at 4096 bytes, trace IDs at 128 characters, references at 16,
queues at 64 and result/cache maps at 128 entries; smaller defaults apply.

Every submission performs a fresh bounded candidate search on the worker, even
if its query is cached. Previously cached references are independently
rehydrated/authorized; final hits are rehydrated again before projection. This
avoids trusting unchanged timestamps as proof that no new matching records were
inserted. Canonical text is never retained in cache/results or returned by this
API. Poll invalidates changed source/policy scopes and expired proposals. A
proposal is dated observation metadata, not a guarantee that a record cannot
change immediately after return. Any future text-consuming API must rehydrate
and enforce the same policy at its own use boundary.

## Context and lifecycle gates

Root owns the memory flag, source policy and context hook. SHADOW must preserve
the existing rendered ContextPackage byte-for-byte; MemoryService's “legacy”
ranking is not equivalent to today's context package. Use proposals only for
metadata comparison. No runtime method renders memory text, so this module
cannot silently replace the conversation or identity components.

Only `stats()` summaries belong in a WebSocket status payload. Canonical IDs,
digests, references, query text and canonical text are internal proposal data,
not user-facing WebSocket telemetry.

Preserve the existing autobiography policy (conversation category, approved
speaker prefixes and current affect/self-narrative restrictions) through the
root-owned evidence predicate. SourcePolicy alone is broader for old unscoped
records. Unknown/unverified observations never become authenticated facts,
self/value authority or action permission. Episode arguments and side effects
need a separate redaction/formatting review before any later text integration.

Submit/poll perform bounded handle discovery and filesystem metadata checks,
but no canonical text reads or model calls. They are not a real-time guarantee
on an arbitrary slow/network filesystem. Actual user-path latency, live shadow
parity, configured principal/identity, managed paths and continuity evidence
remain rollout gates. No production changes are part of this candidate.

## Validation

`tests/test_memory_runtime.py` loads the three pure modules in a private package,
uses manual temporary canonical fixtures, and imports no server/brain startup.
Coverage includes OFF no filesystem access, exact handle paths and late stores,
immutable canonical bytes, reference-only proposals, absent writers/embeddings,
symlink/hardlink alias rejection, principal/identity/policy partitioning, changed
and revoked records, insertions despite unchanged file stamps, bounded queues/
caches, TTL, late-result suppression and non-overlapping shutdown/reinstallation.
The validation artifact records the dedicated 768 MB serialized sandbox result.
