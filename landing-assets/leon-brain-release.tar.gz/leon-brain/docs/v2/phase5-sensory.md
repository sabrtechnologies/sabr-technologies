# Phase 5 sensory candidate and takeover evidence

This branch preserves the interrupted SensoryHub, SceneModel and four daemon/relay
adapter edits found on takeover at base `9f070d26`. Before any edits, all six
changed files, tracked baseline blobs, binary diffs, SHA-256 values, file modes,
mtimes and status were captured byte-for-byte in
`C:/Users/pazzo/Desktop/leon-takeover/phase5-candidate-20260929/reference/interrupted-original.zip`.
The matching `original-manifest.json` records provenance as pre-existing
interrupted work; individual authorship was not independently established. No
reset, stash, discard, production deployment or live-state modification occurred.

## What was completed

The retained implementation has bounded rings (screen/webcam 120; audio/telemetry
500), bounded source-ID/timestamp/hash deduplication, feature/media hygiene,
scene differencing and bounded focus requests. It publishes meaningful change
batches through the existing V2 publisher only when that publisher/site is
installed. OFF is inert. SHADOW is observe-only. CANARY/ON intentionally retain
SHADOW semantics; legacy perception remains authoritative pending parity gates.
Neither hub nor scene performs capture, model inference, tool dispatch or TTS.

Behavioral corrections made during takeover:

- Distinct stable captions now reach the scene even when ring retention is
  coalesced. Presence/expression debounce and freshness no longer wait for the
  60-second caption heartbeat. A duplicate physical event cannot supply a second
  confirmation vote.
- Source confidence is bounded by configurable `(source, kind)` ceilings;
  repeated captions cannot increase confidence beyond their source evidence.
  Very low confidence, stale/future timestamps and out-of-order events are
  rejected before state changes. Described people remain unidentified.
- Relay and daemon frame hashes use the same decoded bytes. The hub deduplicates
  frame content across dashboard/daemon sources. Caption observations reference
  the frame; they are derived descriptions, not additional raw capture owners.
- Source IDs and confidence now survive relay speech/caption adapters. Audio
  hooks retain only transcript length/hash and acoustic metadata, never raw
  samples or transcript text. Adapter processing has bounded payload sizes.
- Public observation/feature snapshots are detached copies; callers cannot alter
  the hub's retained records. Batch ingestion processes at most 64 supplied
  metadata observations without materializing an unbounded iterable.
- Changes arriving inside the publish debounce window retain the latest pending
  value and can be flushed later. Previously such state changes disappeared
  permanently from the event stream.
- Scene read views expose stale evidence and confidence decay. Fresh audio cannot
  make old visual presence appear fresh. Public `state()` excludes stale current
  occupancy/application/acoustic claims while persisted historical entity
  observations remain available. `snapshot()['fresh_state']` is the derived view;
  its other fields retain the persisted last-observed representation.
- Keyword boundaries prevent `video` matching `ide` and headphones matching
  phone objects. Basic explicit person-negation captions are handled.
- Persister shutdown retains a still-running thread handle after a timeout and
  avoids starting a second worker or blocking on a concurrent flush. Hub
  replacement is refused until the previous persister has stopped successfully.

## Persistence and freshness

Only the new `scene_model_v2.json` and capped `.changes.jsonl` are written, via
temporary files/fsync/atomic replacement. Ordinary changes save no more often
than 30 seconds, confirmed high-salience changes may save after 2 seconds, and
stable last-seen touches default to 300 seconds. Restart preserves the save
throttle using elapsed wall time. Newer schemas remain read-only; malformed
scene files are retained under a unique corrupt-file name on an explicit save.
No historical knowledge, autobiography, hippocampus, spatial or temporal store
is loaded or rewritten by this module.

Current source freshness thresholds are 120 seconds for screen/webcam/telemetry
and 60 seconds for audio, with at most 5 seconds of future timestamp skew.
Persisted confidence/last-seen evidence survives restarts, but current occupancy
expires until refreshed. These thresholds require live SHADOW calibration.
Frame deduplication is bounded (IDs 10 minutes, content hashes 10 seconds); the
relay must supply stable capture IDs/timestamps for stronger replay guarantees.
Hash-only legacy input cannot distinguish two physically distinct captures with
identical bytes. No claim of unbounded exactly-once delivery is made.

## Integrator hooks and scheduler ownership

The integrator owns `server/init_brain.py`, runtime lifecycle, flags,
`brain/cognition/v2_publish.py`, websocket readers and scheduler call paths.

1. Register the `sensory_hub` live flag and publisher site
   `sensory_hub.change`, mapping structured `observation` and `changes` to
   `PERCEPTION_CHANGE`. Import/install the hub once, using the actual canonical
   state directory and SHADOW mode. Missing registration is counted, not imported
   implicitly from daemon hot paths.
2. Attach one SceneModel persister at lifecycle startup; stop/flush it at owned
   shutdown and inspect the boolean result before replacing it. Call
   `hub.flush_pending()` from an existing bounded runtime tick so
   a final debounced change is delivered even if no later sensor event arrives.
3. Dashboard/websocket readers should consume `scene.state()` or
   `snapshot()['fresh_state']`, not make their own captures or interpret an old
   persisted `room_occupancy` as a current observation.
4. `request_focus(source, region, reason, ttl)` currently records bounded,
   expiring requests only. The executive may select a local crop/OCR/query after
   ambiguity/salience checks. Deeper model escalation belongs to the provider
   and inference scheduler. This candidate does not dispatch focus requests.
5. Existing direct `respond_streaming` paths in `audio_daemon.py` (greeting) and
   `perception_floors.py` (higher-level visual/social reactions) are deliberately
   unchanged. Root is migrating their inference ownership. Merge the sensory
   helper/call additions with those scheduler edits; do not replace whole files
   from this branch. Existing audio SNN injection/self-hearing protections and
   visual capture-owner logic remain intact.
6. Perception floors currently publish parity telemetry; they do not yet read the
   scene as authoritative, and their private persistence remains. Retire duplicate
   private state only after the runbook's parity/continuity gate. The existing
   vision daemon still controls the single capture owner and ScreenObserver pause.

## Validation and remaining gates

Hermetic tests load only the new modules and AST-selected real adapter helper
functions with injected fixtures. They cover replay/duplicates, source confidence,
freshness, presence and activity diffs, coalescing/debounce/batches, media exclusion,
bounded rings/logs, focus TTL, atomic save/restart, failure retry, thread shutdown
and untouched historical fixture hashes. Tests run through the serialized VPS
sandbox launcher with a 768M memory limit; no real application startup occurs.

Live gates remain: validate source IDs/timestamps against actual relay clients;
observe parity and real-world false-positive/missed-change rates; verify frame and
audio capture counts with multiple dashboards; measure hot-path latency/RSS;
wire the publisher/runtime/shutdown/reader hooks; and demonstrate continuity and
rollback before any authority change. No production flags, services, models or
state were changed by this development candidate.
