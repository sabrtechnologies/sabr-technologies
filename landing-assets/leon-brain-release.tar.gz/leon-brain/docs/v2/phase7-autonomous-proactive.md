# Proactive speech through the installed queue

This slice fixes the three real `ProactiveLoop` output paths: observation,
social outreach, and spontaneous association. It does not complete Phase 7's
executive/ThoughtIntent cutover.

When the installed SpeechRuntime selects arbitration, each candidate reserves a
priority-30 SpeechTurn after local candidate gates and before narration. Barge-in invalidates this generation,
including a candidate whose model is still running. The existing narration
preflight binds that job's cancellation token; no task cancellation is added.
The existing scheduler must fully drain narration before output is enqueued.
All selected response frames retain the same response ID and generation.
Synthesis uses the existing speech worker only. Queue failure, retirement,
selection changes, and cancellation cannot choose inline TTS or retry inference.

The adapter creates no owner, store, thread, or queue. OFF and SHADOW preserve
legacy output shapes and synthesis behavior. Selected candidates also avoid the
separate headless notification fallback, which has no speech-generation fence.
Generated narration retains the existing unverified provenance metadata; it is
not an action receipt or a durable structured thought.

`ProactiveLoop.stop()` marks the active candidate retired without waiting on
speech callbacks. It joins the existing thread for its original two-second
bound and retains that thread if still alive. `start()` refuses to clear the
stop signal while the old thread drains. A candidate's retirement fence survives
restart of the same loop, preventing old synthesis from becoming visible later.
SpeechRuntime remains responsible for global speech worker/sink retirement.
The effect-free proactive stop fence suppresses future frames; by itself it
does not retract audio already delivered to a client. Explicit user interruption
or SpeechRuntime retirement owns the cancellation frame and existing sink-stop
callback. Neither a queued frame nor the estimated playback window proves that
physical playback completed.

Tests use actual ProactiveLoop methods, InferenceScheduler, SpeechRuntime and
SpeechTurn with synthetic providers and audio sinks inside the hardened test
sandbox. They cover all three selected paths, model and synthesis interruption,
concurrent candidates, stop/restart, OFF/SHADOW parity, and selected failures.

Remaining Phase 7 work: bind structured ThoughtIntent to the existing executive
and canonical memory owner before language realization; then cut over dream,
inner voice, goal, and reflection candidates. No private thought database or
additional executive/model loop is introduced here. No live acceptance,
scientific result, or production deployment is asserted.
