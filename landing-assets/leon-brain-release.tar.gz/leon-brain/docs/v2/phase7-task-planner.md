# Bounded supervised coding planner candidate

This candidate is an adaptive planning core beneath the existing executive. It
must not create a model worker, action worker, independent planning loop,
canonical memory store, or brain-step owner. Runtime integration remains OFF
until the root-owned registration, approval, dispatch and lifecycle hooks are
implemented and tested.

## Ownership contract

The existing TaskRuntime owns the TaskStore, TaskPolicy, ProjectActions backend,
worker pool and trusted registration records. The planner receives those
existing references, a trusted immutable plan-context resolver and a narrow
durable child-step ingress. The installed InferenceScheduler supplies actual
priority-70 active-task tickets with tools and history disabled. No provider
fallback is permitted.

TaskPolicy currently binds one task's authorization_ref to one immutable exact
grant. A parent planning task therefore owns checkpoints, and each reviewed
action uses a separate child task with its own grant. All children use the
existing worker pool. Root must extend trusted registration and ingress for
read_text, replace_text and run_check; accepting a parent UUID or a model-created
checkpoint as authorization is forbidden.

Immutable plan context binds the server-resolved principal, parent identity,
submission identity, authorization revision, configured scope, goal digest,
explicit allowed actions/paths/checks, finite step/round budgets and deadline.
The resolver must read trusted durable registration. Caller text, generated
JSON, mutable checkpoint fields and legacy confirmations provide no authority.

`goal_digest(goal)` is the SHA-256 of the bounded goal's UTF-8 bytes. The
registration deadline is at most one hour after issuance. Steps are limited to
1–8, inference rounds to 1–16, explicitly allowed paths/checks/actions to 16
entries each, and concurrent executor calls to 1 by default (maximum 4).

## API and progression

- initialize validates the registered goal and creates the parent checkpoint.
- advance performs at most one bounded inference decision. It checkpoints its
  request identity and consumed round before scheduler submission, consumes and
  validates structured output, then pauses on an exact canonical proposal.
- proposal returns the reviewable action and digest to the authorized caller.
- approve_step requires explicit approval of that digest, persists dispatch
  intent, then calls idempotent trusted ingress. It never invokes handlers.
- poll reads retained child receipts and checkpoints parent progress; only
  then may the existing runtime acknowledge its shared result outbox.
- cancel stops future planning/queued units while committed child actions drain
  through the existing TaskStore/TaskWorker cancellation contract.
- completion remains a reviewable proposal grounded in receipts, requiring
  trusted acknowledgment before the parent is marked successful.

The public completion method is `acknowledge_completion`. Each method takes the
registered task ID and a server-resolved `principal`; approvals require literal
`approved=True`, the exact `proposal_sha256`, and a trusted `approval_ref` for
action admission. These are trusted service APIs, not model-callable tools.
Only the injected `enabled()` predicate returning literal True admits work.

`DurableStepIngress` has exactly these keyword interfaces:

```python
lookup_step(context, step_key) -> StepIdentity | None
submit_step(context, step_key, spec, proposal_sha256, approval_ref,
            parent_revision) -> StepIdentity
cancel_future(context, step_key) -> None
```

`StepIdentity(task_id, action_id, proposal_sha256)` must come from immutable
child registration. The digest must never be copied from the mutable parent
checkpoint. Step keys are `planner-step:1`, `planner-step:2`, and so forth.
History entry N is checked against the trusted lookup for step N, child scope,
finite deadline and retained receipt identity/hash before it can enter a prompt
or support completion. A valid receipt belonging to another parent is rejected.

Proposal digests use SHA-256 over compact, sorted JSON of
`[asdict(context), round, step, request_id, history, proposal]`, with nonfinite
numbers forbidden. Action proposals contain decision/name/arguments/reason and
canonical spec metadata: resources, minimum tier, scope, root identity, input
digest and configuration digest. Name/arguments are not duplicated in metadata,
so an 8192-byte backend replacement can fit in the bounded checkpoint. The
canonical spec is recomputed at approval and passed to trusted ingress.

An inference decision proposes one action or completion; it is not a list of
instructions that bypasses individual approvals. Each later decision receives
bounded durable prior receipts, permitting behavior to depend on observed
results. FAILED, UNKNOWN, cancellation and expiry stop future actions. UNKNOWN
resource fences remain owned by TaskStore without implicit reconciliation.

## Required root integration seams

1. Create immutable parent registrations and resolve their context independently
   of checkpoints; register approved children so existing TaskPolicy can resolve
   each exact principal/submission/revision/scope.
2. Provide idempotent child submission and lookup keyed by parent and step.
   Persist exact finalized approval before enqueue, atomically coordinate parent
   cancellation with new child admission, and preserve all partial-submission
   identities across restart. Replaying a submission must return the retained
   action, including UNKNOWN; it must never create another attempt.
3. Invoke blocking inference advancement only from an existing owned executor,
   never the ASGI or event consumer. Keep the planner's active handles in the
   runtime retirement barrier and cancel only those handles on planner stop.
4. Extend TaskRuntime's result dispatch: its current tick recognizes only
   approved_single_check. A planner child result must reach the planner's durable
   checkpoint before the shared outbox is acknowledged. Reconnect reads never
   acknowledge results.
5. Expose review/approval through authenticated executive methods. Model tools
   cannot call trusted approval ingress or choose principal, scope, resource,
   tier, command, environment, containment configuration or root paths.

## Crash and capacity boundaries

Checkpoint intent precedes inference and action submission. A lost inference
request is paused for explicit retry, which consumes a new remaining round; no
automatic model replay is claimed. A lost child-submission reply is recovered
by stable identity lookup or an explicit idempotent continuation under the same
approval. A retained action receipt remains authoritative even after outbox
acknowledgment. No operation deletes identity history to reclaim capacity.

Finite prompt/output/checkpoint bytes, steps, rounds, active calls, task-store
quotas and deadlines must reject excess work. Releasing the scheduler slot means
the actual handle completed after provider cleanup, not merely receiving a
model `done` event. Checks and patches must never execute while that planning
handle still owns inference.

`quiesce()` closes new admission and cancels owned scheduler handles. If its
publication lock is busy, it returns False promptly; the existing runtime must
retain and retry the owner. `drained` also checks active executor calls so a
finished model does not let the runtime close a store still being checkpointed.
The runtime must reject new service calls during retirement and retain its
TaskStore until both planner executors and the existing TaskWorker pool drain.

## Verification and remaining gates

The serialized 768M sandbox run
`/opt/leon-v2-tools/test-results/task-planner-20260929-d` passed **226 tests in
8.43s** across planner, task runtime, policy, project actions, worker, lifecycle
store and inference scheduler. Tests use real operational SQLite stores,
immutable grants, scheduler tickets and the existing worker pool with synthetic
providers and temporary projects. The fixture TaskRuntime subclass implements
the proposed durable ingress for testing; that subclass is not production wiring.

Coverage includes receipt-dependent read→hash-bound replacement→fixed check,
explicit completion, provider cleanup after `done`, scheduler fallback with no
escape, bounded prompts/output/rounds/steps, duplicated approvals, changed
principal/scope, lost enqueue reply and restart, UNKNOWN resource fences,
cross-parent receipt substitution, and conversation during committed check drain.
Original development commits remain preserved on `v2/assets-not-found`; this
candidate branches from pinned `a71b2e9a078decdfa1f642d93521472d1e7f49e1` and
adds only the planner module, its tests and this document.

This is a supervised adaptive core, not full autonomous coding. Default-OFF
runtime registration/ingress, executive approval routes, real provider policy,
shared outbox dispatch and lifecycle integration remain root-owned gates. No
live check, successful model reasoning, new scientific evidence or production
acceptance is claimed.
