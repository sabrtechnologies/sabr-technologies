# Approved check runtime integration

The existing ExecutiveController now exposes review and submission of one
explicitly approved named project check. It delegates to one TaskRuntime bound
to the existing CognitiveRuntime lifecycle. The finite TaskWorker pool executes
the action without owning the model scheduler. There is no new planning loop,
inference thread, speech owner or automatic free-form coding agent.

Both `LEON_TASKS` and live `tasks` default OFF. This first action service requires
both ON, trusted immutable TaskExecutionConfig, verified server installation
identity, an existing executive, and a mandatory confinement authority. Missing
confinement never becomes authorization merely because a check has a label.
SHADOW/CANARY do not execute. Configuration loading and real confined launcher
acceptance remain separate integration gates.

Preview exposes the fixed command, relative working directory, timeout and
configuration digest without environment secrets. Explicit approval binds that
exact digest, authenticated principal, scope, stable task/step and a 15-minute
grant. Inputs cannot supply root, argv, resources, tier or another principal.
The immutable submission registry resides in operational state, disjoint from
approved workspaces; database symlinks/hardlinks are refused. Registry and grants
are independent of the model's mutable task checkpoint.

Submission commits each recovery stage before proceeding: immutable submission,
task, trusted identity binding, exact grant, action enqueue. Repeating the same
request recovers the original action; changed requests conflict. An accepted
attempt can be recovered even after configuration changes, without issuing a
new grant or executing it again. Faulted action pools refuse new admission.

The existing runtime tick completes a successful single-check task durably
before acknowledging its result outbox. Failure/cancellation/unknown state and
receipt already share the TaskStore transaction. Reconnect reads retained
receipts and never acknowledge the runtime outbox. UNKNOWN retains resource
fences, even after result acknowledgement. No learning or next action is
inferred from a check result.

Shutdown immediately closes admission and retains all handles through worker
drain. Ordinary task cancellation stops future work; committed checks keep
their result receipt. Speech cancellation and UI disconnect do not stop checks.
An incomplete startup retains its owner before the first worker starts, so a
partially running pool cannot be silently replaced.

A configured-ON owner installed while the live flag is OFF remains cold. A
later live OFF-to-ON transition is picked up by the existing runtime tick,
which starts one owned, one-shot activation thread. Store initialization does
not block the event consumer. Repeated ticks cannot create another pool;
shutdown retains the owner until activation and action workers have drained.
An activation failure is exposed by `activation_error` and is not retried by
ticks. After activation, live OFF closes action admission while preserving
receipts and the existing pool for a later ON transition.

Hermetic tests use temporary sibling operational/project directories and fixed
synthetic Python checks inside the required VPS sandbox. A slow check remains
RUNNING while the real scheduler completes a separate no-tools response. These
tests establish component concurrency, not deployed interaction latency or
arbitrary-code containment. Real check confinement, authenticated route wiring,
checkpointed multi-step reasoning, procedural quick actions, autonomy proposals
and live continuity/performance/soak acceptance remain pending.


## Explicit configuration and confinement composition

Optional `LEON_TASK_CONFIG` names an existing private operator JSON file. It is
read only when tasks are explicitly ON and no typed startup configuration was
already injected. The loader requires actual canonical persistence roots from
the existing persistence owner, an existing private operational directory, and
disjoint explicit workspaces.
The operational directory is also disjoint from canonical persistence in both
directions, so task metadata cannot be placed inside the live brain state.
Schema1 contains exactly `schema`,
`operational_dir`, and `workspaces`; each workspace contains exactly `scope`,
`root`, and `checks`; each fixed check contains `name`, `argv`, `cwd`, and
`timeout_s`. It cannot set identity or provide callable authority via JSON.

One retained configuration bundle supplies preview validation, actual-action
authority, and the namespace-completion result wrapper. All three are required;
the runtime cannot fall through to a raw check handler without the wrapper.
SQLite databases and their WAL/SHM/journal sidecars must be private regular
single-link files. A missing installation principal is denied, including preview.

The initial loader constructs the local bounded-service containment factory.
Its actual cgroup and namespace prerequisites are mandatory. It cannot execute
inside Leon's larger SNN/model cgroup. The separate execution-service bridge is
still required for production; never reduce Leon's service memory limit to make
this check pass. Synthetic identity wrappers in tests prove composition and
receipt handling only, not a production sandbox. All features remain OFF until
the configured execution boundary and live acceptance gates pass.
