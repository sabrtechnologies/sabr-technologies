# Private thought composition (runbook 11.2)

This is the last Phase 7 piece: the inner voice's thought *intent* (a typed
internal-state snapshot) is split from its *language realization* (one
bounded private local model call). It builds on the four integrated
prerequisites: canonical intent snapshots, realization receipts, the
`MemoryShadow`-owned intent lifetime, the private startup configuration and
the private thought transport. It adds no thread, store, provider, model
route, autobiography write, history write or publication path.

`brain/cognition/thought_realization.py` provides one cold `ThoughtRealizer`.
Trusted startup constructs it from already-owned handles: the installed
`MemoryShadow` (`open_thought_intent()`), the typed `ThoughtConfiguration`,
the installed inference scheduler (admission + cancel), the responder,
bounded `foreground_busy()` / `local_budget_available()` / `principal()`
callbacks, the live-flag reader and a wall clock. Importing the module is
cold.

## One lease, in order

`realize(intent)` runs entirely inside ONE `ThoughtIntentLease`:

1. `remember_thought_intent` — a confirmed snapshot receipt (the nonverbal
   intent is now retained whatever happens next).
2. `ThoughtAdmissionContext` from trusted values only: the receipt's thought
   id and digest, `lease.current()`, the busy/budget callbacks (a raising or
   non-`True` busy callback reads as busy; only literal `True` is budget),
   `now` and `expires = intent.created_wall + policy.deadline_s`.
3. `decide_thought` (pure). `defer` and `retain_nonverbal` close the lease and
   return a `ThoughtRealizationResult` with the decision and no model call.
4. `realize_local`: `compose_thought_prompt(intent)` builds the exact bounded
   prompt from the intent only (no autobiography, goal, dream or prior thought
   text; references are counted, never read). The
   `ThoughtRealizationRequest` binds `caller=inner_voice`, `channel=internal`,
   the prompt SHA-256, `ThoughtConfiguration.sha256()`, priority 30, the
   policy token bound and `deadline_wall <= created_wall + policy.deadline_s`.
   `admit_thought_realization` persists ADMITTED; dispatch happens only on
   `freshly_admitted=True`. A retained or replayed admission raises without
   any model call.
5. One scheduler submission: `make_request("background", …, group="inner_voice",
   admission="background", can_preempt=False, allow_tools=False,
   persist_history=False, provider=responder_provider(responder))` with
   responder kwargs `private_thought_policy=PrivateThoughtPolicy(tokens, bytes)`,
   `replay_history=False`, `persist_history=False`, `supervised=False`,
   `bypass_consciousness=True`, `prefer_local=True`, `force_api=False`,
   `force_cli=False`, `channel="internal"`. The scheduler's one worker, legacy
   lock bridge, monotonic deadline and foreground preemption stay in charge.
6. Provider cleanup first (`handle.close()` plus a bounded wait for the job to
   finish), then `finish_thought_realization`: COMPLETED with the nonempty
   text; CANCELLED (reason: `preempted`, `stopped`, `expired`, `timeout`,
   `cancelled`, …) when a foreground turn, a cancel token, the deadline or
   admission ended it; FAILED (reason: the exception type, `invalid_event`,
   `empty_output`, `output_bounds`) for a provider fault; UNKNOWN
   (`provider_drain_unconfirmed`) when the job cannot be shown to have ended.
7. Lease close.

`realize()` returns the result for COMPLETED and CANCELLED. FAILED and UNKNOWN
are terminal receipts and are raised as `ThoughtRealizationUnavailable` (the
result rides on `.result`). Every failure before admission (owner unavailable,
principal mismatch, transport unsupported, unselected flag) raises the same
exception. The exception is never permission to replay the legacy generation,
retry, persist history or publish. A failed terminal write leaves the attempt
ADMITTED for explicit recovery; nothing resubmits inference. `observe(intent)`
persists the snapshot only (shadow). `stats()` exposes fixed booleans and
counts: no text, identifiers, digests or paths; results hide the private text
from `repr`.

`quiesce()` refuses new work and cancels the active handle (`stopping`);
`stop()` returns True only once no realization, and therefore no lease, is in
flight. The memory slot's `stop()` already stays False while the lease is
open, so retirement cannot falsely complete.

## InnerVoice hook and flag semantics

`InnerVoice._generate_thought` begins with one guard: when
`self._v2_thought_realizer` (default `None`, attached by the installer) is
set, `_v2_compose_thought` consults `realizer.selected_mode()`, the live flag
`thought_intents` (new default `off` in `brain/v2_live_flags.py`):

- `off` (or an unattached realizer, or `canary`, which has no turn key here):
  the legacy path runs byte-for-byte unchanged, including its own optional
  `inference_scheduler.inner_voice` route and the legacy responder lock.
- `shadow`: `_v2_thought_intent` builds the typed `ThoughtIntent` from the
  same internal state the legacy path reads (trigger, dominant region, goal
  ids, recent thought timestamps, body urge/urgency/free energy,
  consciousness streak, neuromodulators, `privacy="private"`,
  `created_wall=time.time()`), `realizer.observe(intent)` persists the
  snapshot, and the legacy path then runs unchanged. A snapshot failure is
  logged by exception type only.
- `on`: the same intent goes to `realizer.realize(intent, brain_state)`. A
  COMPLETED text takes the place of the legacy generation (same `< 5`
  guard and quote cleanup, same downstream handling in `think()`); any
  other outcome or exception returns `None`. The legacy model call is never
  entered on the selected path.

The intent carries references and bounded scalars only; narrative, goal
text, dream text and prior thought text never enter the snapshot or the
realized prompt. `brain_state` is handed to the local transport exactly as
the legacy call does; it is not hashed into the request.

## Installation seam (`brain/cognition/v2_install.py`)

Applied in this worktree behind the env opt-in; no existing default changes.

- `thought_intents_opted_in(env)`: only the literal `LEON_THOUGHT_INTENTS=on`.
- `load_thought_configuration_from_env(state)`: reads
  `LEON_THOUGHT_INTENT_CONFIG` only after that opt-in, loads it with
  `server.installation_principal()`, retains it on `state.thought_configuration`
  and records `state.thought_intent_reason` (`not_opted_in`,
  `configuration_or_identity_missing`, `configuration_unverified`,
  `configured`). Never raises; an invalid file leaves the selected path
  unavailable without legacy retry.
- `install_memory_from_server_state`: passes
  `thought_intent_config=configuration.intent`,
  `thought_intent_requested=lambda: live.live_mode("thought_intents") in ("shadow", "on")`
  and `thought_principal=server.installation_principal` to `MemoryShadow` when
  configured; a reused live owner is checked with
  `thought_configuration_matches` and never rebound
  (`thought_intent_reason=owner_rebinding_refused`).
- `install_thought_realizer_from_server_state(state)`: after the scheduler,
  responder, memory owner and `state.inner_voice` exist, builds the
  `ThoughtRealizer` (`foreground_busy=make_user_turn_probe(state)`,
  `local_budget_available`: scheduler alive and the loaded local transport
  not `off` and `is_available()`), attaches it as
  `state.inner_voice._v2_thought_realizer` and `state.thought_realizer`;
  reasons: `installed_cold`, `not_opted_in`, `owners_unavailable`,
  `memory_owner_unbound`, `identity_missing`, `voice_already_bound`,
  `binding_mismatch`, `installation_failed`.
- `retire_thought_realizer(state)`: quiesce then stop; False while the lease
  drains; detaches from the InnerVoice. `_retire_previous` calls it before
  `rt.stop()`, i.e. before the runtime quiesces and stops `MemoryShadow`.

Exact integrator step (`server/init_brain.py`, not changed here): after
Layer 8 constructs `state.inner_voice`, add

```python
    try:
        from brain.cognition.v2_install import install_thought_realizer_from_server_state
        install_thought_realizer_from_server_state(state)
    except Exception as exc:
        log.warning("[V2] thought realizer install failed exc=%s", type(exc).__name__)
```

Process shutdown needs no coordinator change: `begin_shutdown` stops the
runtime (memory quiesces, the open lease retains its captured service),
retires the scheduler facade (the scheduler's `stop()` cancels the active
background job with `stopping`, the provider drains, the realizer records
CANCELLED and closes the lease), then its retry loop completes
`MemoryShadow.stop()`. An optional earlier `retire_thought_realizer(state)`
call at the top of the coordinator's helper would shorten that path; it is
left to the integrator.

## Validation

`tests/test_thought_realization.py` (registered in `tests/run_all.py` and
`tests/run_v2.py`) uses real `KnowledgeStore`, `SelfModel`, `MemoryShadow`,
`ThoughtIntentRuntime` and `InferenceScheduler` objects in temporary
directories with a fake responder; the ambiguous path uses a scheduler
stand-in. It covers every decision branch, exactly one admission and one
model call per realized thought, stored and returned COMPLETED text, a
priority-100 foreground preemption (CANCELLED, no text, lease closed), a
provider exception (FAILED, raised, no legacy fallback), an ambiguous commit
(UNKNOWN), flag off/shadow/on through the real `InnerVoice` methods,
retirement blocked until the lease drains, no private text in stats, records,
logs or stdout, prompt determinism and bounds, and the CRLF guard for
`brain/inner_voice.py`, and a realization queued behind foreground work past
its deadline (CANCELLED/timeout, no model call). Run only through the
serialized sandbox launcher (`--mem 768M`).

Recorded runs on this branch: focused modules `test_thought_realization`,
`test_thought_intent_runtime`, `test_thought_configuration`,
`test_thought_transport`, `test_inference_scheduler`,
`test_inference_background`, `test_v2_phase2_structure`,
`test_user_turn_recorder`, `test_memory_hooks`, `test_memory_shadow`,
`test_v2_flags`, `test_v2_phase3_structure`,
`test_respond_streaming_call_sites`, `test_runtime_shutdown`: 14/14 modules,
19+32+70+21+38+7+10+29+9+13+8+9+3+25 tests passed (results dir
`agent-thought-focused-1`, commit 8375637d). Full `tests/run_v2.py`: 102/102
modules, 2344 tests passed at 8375637d (`agent-thought-runv2-1`) and 102/102
modules, 2345 tests passed at 57254844 (`agent-thought-runv2-2`, this module
20 passed). The strict undefined-name check passed on every changed file at
each commit.
