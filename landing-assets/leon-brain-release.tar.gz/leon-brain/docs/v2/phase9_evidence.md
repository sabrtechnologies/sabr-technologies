# Phase 9 isolated evidence — 2026-09-29

Base: `9f070d26eeec4b53ed35905fe2878fb1e06f93bc`, branch
`v2/phase9-providers`, worktree `/opt/leon-v2-worktrees/phase9`.
No production paths, state, services, flags, or external model requests changed.

The required `sandbox_run.sh` used its shared serialized lock, network namespace,
and 768 MB memory ceiling. The initial package suite passed **38 tests**:

```sh
bash /opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase9 \
  /opt/leon-v2-tools/test-results/phase9-providers-20260929d --mem 768M -- \
  python3 -m pytest -q -p no:cacheprovider \
  --junitxml=/opt/leon-v2-tools/test-results/phase9-providers-20260929d/providers.xml \
  tests/test_providers_core.py tests/test_providers_budget.py \
  tests/test_providers_http.py tests/test_jev_adapter.py tests/test_providers_swap.py
```

Receipts (SHA-256):

- `phase9-providers-20260929d/providers.xml`:
  `ce73485cee521cd01c37ab8207ae401499f4e349e2f830d79c513f5b60863066`
- `phase9-providers-20260929d/source.sha256` (every tested source file):
  `26606e65596c3d90b552826e222f68320422432f47b407f350918209336e0066`
- `phase9-swap-20260929/provider-swap.json`:
  `d6dc62bf5676f2311b066dc638efebfdf54e1e10d1797808ddd9935a5cc58df2`

All receipt paths are under `/opt/leon-v2-tools/test-results/`. This evidence note
was added after the final test run; tested implementation files were unchanged.
Guarded staging verifies the expected branch, base commit, prior file hashes,
owned paths, and creates backup archives before overwriting draft files.

The separate swap command, also through the same sandbox launcher, ran
`python3 tools/v2/provider_swap_test.py --output` against that results directory.
Both fixture providers preserved the identical five-file synthetic snapshot and
returned matching identity, facts, goals, memories, and procedures. Their
arithmetic quality intentionally differed. The result is `passed:true`,
`fixture_only:true`, `live_provider_parity_verified:false`.

This is package and fixture evidence. Scheduler/facade integration, shared HTTP
deadline watchdog behavior with these adapters, verified legacy no-tools shims,
deployment token bounds/prices, and authorized live model parity remain separate
acceptance gates. See [phase9_providers.md](phase9_providers.md).

## Integration-review regressions

The follow-up suite passed **46 tests** in
`/opt/leon-v2-tools/test-results/phase9-drain-budget-20260929c`, using the same
sandbox launcher, arguments, and test files above with that results directory.
Both the router and legacy wrapper now suppress ordinary events after cancellation
or deadline expiry while continuing to consume every committed tool result.
Regressions announce two tools, cancel/expire, interleave status/model/delta/done
between results, and verify that the provider lock and budget reservation remain
held through the second result. Cancellation neither triggers failover nor poisons
provider health.

Usage reconciliation now requires explicit whole-call provenance
(`usage_final=True`) and clean stream completion. Cancelled, failed, and abandoned
calls retain their conservative reservation despite intermediate usage events.
Only validated completed single-request hosted responses attest final usage.

- `phase9-drain-budget-20260929c/providers.xml` SHA-256:
  `6bd0fa66ec6ce229e80a339b7581ea2e56e2fb26c5c9f2beb58b38039f15927f`
- `phase9-drain-budget-20260929c/source.sha256` SHA-256:
  `930754ec2f100c064c7c6f511cc0762c9114d7c744d7558e82052f83457a2b7a`

This evidence note was updated after that run; implementation/test bytes remain
identical to its source manifest. No live providers or production state were used.
