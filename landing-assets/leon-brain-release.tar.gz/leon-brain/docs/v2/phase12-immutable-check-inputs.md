# Immutable check input candidate

This mode is distinct from ordinary writable project checks. It does not enable
improvement execution, grant approval, provision a service, or prove that the
host supports the required namespaces. The existing TaskWorker remains the
action/resource owner and the existing check broker remains the sole executor.

The trusted parent registry supplies a complete captured artifact and an exact
historical planner/action binding. The paired bridge callbacks are
`proof_required(action, task, spec)` and `resolve_check_material(action, task,
spec)`. A reserved check with absent, malformed, or revoked material fails
before dispatch; it cannot fall through to the writable runner. Only literal
False from the trusted classifier permits an ordinary unreserved check. An
improvement-enabled factory must supply both callbacks. The final parent-only
grant callback and exact material check run again after peer/hello verification,
immediately before the execute send.

One bounded sealed memfd carries the canonical private artifact over the already
authenticated Unix connection. JSON carries only bounded identity and inventory
metadata. The receiver requires exactly one CLOEXEC descriptor, a regular inode,
the complete write/grow/shrink/seal seal set, and the exact full bundle digest.
Malformed/truncated ancillary messages close every received descriptor. Partial
send/lost reply remains ambiguous and permits only durable receipt lookup.

The service revalidates the bundle against its fixed local canonical check and
the exact request. It durably records STARTED before its one executor starts.
The bundle bytes are not stored in the receipt database. Restarted STARTED stays
UNKNOWN, and existing uncertain resources remain fenced. No retry, TTL or
approval refresh is introduced.

`immutable_runtime` is an optional operator service configuration object:

```
{"version":1,"python":"/usr/bin/python3","files":[
  {"source":"/operator/actual/regular/file","path":"/usr/bin/python3",
   "sha256":"<exact 64 hexadecimal digits>","mode":365}
]}
```

The example is a schema illustration, not a usable Python closure. All required
interpreter, loader, libraries and standard-library files must be explicitly
listed by the operator. The mode is a JSON integer (365 = 0555). The closure is
bounded to 256 regular unaliased files and 64 MiB, with 32 MiB per file. Missing
dependencies fail closed; there is no broad `/usr` mount, dependency download or
model-selected path. Source policy and all transitive application source files
are covered by the existing immutable service startup manifest.

Bubblewrap 0.12.0 `--ro-bind-data` copies sealed source bytes into private tmpfs
backing, mounts each copy read-only, unlinks its private backing name and closes
the setup descriptor. The implementation does not claim those copied inodes
inherit memfd seals. A private read-only root prevents directory/file insertion,
replacement or mode changes. The trusted PID1 verifies the exact complete
workspace inventory and runtime closure before executing the fixed command. It
sets itself nondumpable, passes no proof/source descriptors to check children,
and accepts no proof from stdout. The trusted supervisor's writer is normalized
to standard descriptor 0, which survives bubblewrap; the check child receives
DEVNULL for stdin, with all extra descriptors closed. It kills/reaps every descendant in the private
PID namespace, remeasures the immutable inventory, and writes a bounded result
only on its private supervisor descriptor. The parent requires matching
supervisor exit semantics and exact same-attempt proof. Any uncertain completion
is UNKNOWN and cannot make a proposal ready.

The authenticated retained receipt contains an `input_proof` and
`immutable_receipt` with exact request and proof digests. Historical
`resolve_input_proof(action, task, spec)` accepts only the exact terminal
SUCCEEDED TaskStore result and returns `VerifiedInputProof`; it never calls an
active grant/material resolver or executes again. The improvement owner must
perform this RPC outside runtime/store/pipeline locks, then match the historical
registration, proposal, artifact, tree and unchanged result sequence/digest
before caching evidence immutably. Later status/reconciliation uses the cached
evidence offline. Missing initial proof remains EVIDENCE_REQUIRED; a late broker
answer cannot turn a TaskStore UNKNOWN outcome into success.

Synthetic tests exercise seals, FD transfer/error cleanup, immutable binding,
single durable execution, no writable fallback, final-authority races, and
historical receipt validation. They are not namespace acceptance evidence.
`ActualNamespaceGate` requires an explicitly supplied pinned runtime fixture and
the unchanged outer sandbox to permit the mandatory namespace/cgroup boundary;
otherwise it reports an explicit skip. Production remains gated on a separately
provisioned nonroot service/cgroup and an actual successful immutable namespace
test. Host root and the trusted operator remain part of the threat model.
