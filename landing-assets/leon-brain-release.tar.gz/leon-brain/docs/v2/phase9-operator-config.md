# Phase 9 operator configuration: routing dashboard turns to a hosted model

`brain.cognition.provider_configuration.load_provider_configuration(path,
environ=..., canonical_roots=...)` reads one private operator JSON file and
returns the exact frozen `ProviderHookConfig` that the already deployed
`install_provider_from_server_state` consumes. Startup calls it through
`load_provider_configuration_from_env(state)` only after the
`LEON_PROVIDER_ROUTER` env opt-in. The loader builds the real typed objects
(`ProviderSpec` -> `ProviderRule` -> `ProviderPolicy`, one cold `OpenAIAdapter`,
`ProviderRoute`s with exact `RequestScope`s, and a lazy persistent
`BudgetLedger` factory). It opens no ledger, makes no request, and reads the
credential only through the environment variable NAME the file declares. A
missing or invalid file leaves the hook uninstalled: the baseline transport
is unchanged and nothing is retried. No JSON field can supply a credential
value, a callable, a tool permission, another host, or a scope the installed
hook does not match exactly.

The example file is `docs/v2/provider_config.example.json`. Every value marked
`REVIEW` is a placeholder; the pricing there is deliberately 1.0/1.0 and
must be replaced with the reviewed price for the exact model before use.

## Exact schema 1

All fields are required unless noted. Unknown fields, duplicate keys,
non-finite numbers, booleans where numbers are expected, and any
schema other than `1` are rejected.

| Field | Meaning and bounds |
| --- | --- |
| `schema` | integer `1` |
| `policy_revision` | nonblank control-free string, at most 128 bytes; becomes `ProviderPolicy.revision` |
| `valid_until_wall` | finite epoch seconds in the future, at most 366 days ahead; converted to the monotonic `valid_until_mono` of every rule, so an expired file makes every route unavailable |
| `providers[]` | 1..16 entries; each must be referenced by at least one route |
| `providers[].provider_id` | must be `"openai"` (the adapter's fixed spec identity; one provider of this kind per policy) |
| `providers[].kind` | `"openai"` (the only wired transport) |
| `providers[].model` | explicit model id, `[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}` |
| `providers[].credential_env` | NAME of the environment variable holding the key, `[A-Z][A-Z0-9_]{0,63}`; a missing/empty/whitespace value makes the provider unavailable (never an error, never an invented key) |
| `providers[].base_url` | optional; if present it must be exactly `https://api.openai.com` (the JSON transport pins that host) |
| `providers[].pricing.input_per_million_usd`, `.output_per_million_usd` | finite, greater than 0, at most 1000; copied to the `ProviderSpec` prices used for reservations and settlement |
| `providers[].bounds.max_input_tokens` | integer 256..2,000,000; the reviewed full-call input bound (`ProviderRule.input_token_bound`); the rendered history + system context + 1024 bytes must fit it |
| `providers[].bounds.max_output_tokens` | integer 16..32768; `ProviderRule.output_token_bound` and the ceiling for every route cap |
| `providers[].bounds.max_call_seconds` | 1..120; becomes the transport's socket timeout (`JsonTransport(timeout_s=...)`) |
| `providers[].evidence_ref` | nonblank string, at most 256 bytes, naming the review record |
| `providers[].verified.{billing, full_call_bounds, transport_cancellation, no_tools, tool_drain}` | explicit booleans copied to the rule's attestations. The runtime activates a no-tools route only when `billing`, `full_call_bounds`, `transport_cancellation` and `no_tools` are true; `tool_drain` is irrelevant for text routes. These are operator attestations, not checks performed by the loader. |
| `routes[]` | 1..128 entries, unique `(site, group, channel)` |
| `routes[].site`, `.group`, `.channel` | exact scheduler scope strings (nonblank, at most 256 bytes); see the table below |
| `routes[].provider_id` | a declared provider |
| `routes[].capabilities` | 1..3 unique names from `fast_language`, `coding`, `deep_reasoning`; `tool_use`, `vision` and others are rejected |
| `routes[].max_output_tokens` | integer 16..the provider's `bounds.max_output_tokens`; sent as the explicit output cap |
| `routes[].canary` | boolean; live mode `canary` selects only routes with `true` |
| `limits.global_usd_per_day` | greater than 0, at most 10000 |
| `limits.reserve_usd` | optional, at least 0; subtracted from the global daily figure, which must stay positive |
| `limits.per_capability_usd_per_day` | map of text capability -> USD/day, each greater than 0 and at most the effective daily budget |
| `ledger_path` | absolute unaliased path `<canonical root>/v2/<name>.sqlite3` (see below) |

Budget mapping: `Limits(daily_tokens, monthly_tokens, daily_micro_usd,
monthly_micro_usd)` is derived from USD/day. Micro-USD = USD x 1,000,000.
Token ceilings are the number of tokens that reach the USD ceiling at the
cheapest configured per-token price, so they never admit more than the USD
ceiling does. Schema 1 has no monthly field: the monthly ceiling is 31 daily
ceilings. Per-capability entries map the same way.

The ledger must be a dedicated SQLite sidecar directly inside the `v2`
directory of an actual canonical persistence root (`state.v2_canonical_roots`,
the persistence owner's `SAVE_DIR`, which on the production host is
`/opt/leon-brain/brain_state`). It cannot be a root, a canonical store, a
nested path, or any name not ending in `.sqlite3`; the `v2` directory must
exist, be owner-owned and not group/other writable, and an existing ledger
file must be a private (0600) single-link regular file. The file is created
with mode 0600 by the factory, only on an enabled lifecycle tick, and closed
by hook retirement. The probe's live mode records its spend in the same file.

## File installation

```sh
install -d -m 0755 /etc/leon
install -m 0600 -o root -g root provider_config.json /etc/leon/provider_config.json
```

The loader requires an absolute unaliased path, a parent directory owned by
the service user and not group/other writable, a single-link regular file
with mode 0600 owned by the service user, at most 16 KiB, and it re-checks
the file identity after reading. `/etc/leon` (0755 root) satisfies this for a
service running as root.

## Environment variables (unit drop-in)

Add to the existing `/etc/systemd/system/leon.service.d/20-leon-v2.conf`
(the only drop-in that already carries `LEON_V2_RUNTIME`):

```ini
[Service]
Environment=LEON_V2_RUNTIME=shadow
Environment=LEON_PROVIDER_ROUTER=on
Environment=LEON_PROVIDER_CONFIG=/etc/leon/provider_config.json
```

* `LEON_PROVIDER_ROUTER` is parsed by `brain.v2_config` (`off`/`shadow`/`on`,
  default `off`; `canary` is NOT a legal env value and makes the whole V2 flag
  set invalid). `shadow` loads the file and installs the hook cold but never
  routes; `on` lets the live flag enable routing. Absent/`off`: the file is
  not read and nothing changes.
* `LEON_PROVIDER_CONFIG` is read only after that opt-in.
* `LEON_V2_RUNTIME` must be explicitly set (`shadow`) because
  `install_provider_from_server_state` needs `state.cognitive_runtime`; the
  provider hook is ticked by that runtime (`brain/cognition/v2_install.py`,
  `flag_explicitly_set` guard in `_install_from_server_state`).
* `LEON_INFERENCE_SCHEDULER` must not be `off` (runbook default `shadow`
  builds the scheduler).
* The credential is read from the process environment by the NAME in
  `credential_env` (`OPENAI_API_KEY` in the example). On the production host
  `run.py` loads `/opt/leon-brain/.env` with `load_dotenv`, which is where
  that variable already lives; `/etc/leon/secrets.env` is also an
  `EnvironmentFile` of `leon.service`. The loader never prints, hashes or
  derives the value.

Startup records `state.v2_provider_config_reason` (`configured`,
`configured_credential_missing`, `not_opted_in`, `invalid_flag`,
`configuration_missing`, `canonical_roots_unavailable`,
`configuration_unverified`) and prints one `[V2] provider configuration ...`
line; `state.v2_provider_reason` then carries the installer's outcome
(`installed_cold` on success).

## Live flags and enablement order

Live flags live in `/etc/leon/v2_flags.json` (`brain/v2_live_flags.py`,
re-read within 2 s, bad file keeps the last good flags). A dashboard text
turn is routed only when ALL of the following hold, found in code:

1. The scheduler owns the turn. `server/routers/websocket.py:_v2_sched_submit_user`
   calls `inference_scheduler.route("user", channel=_v2_turn_channel(...))`,
   which requires the master live flag `inference_scheduler` not `off` and
   `inference_scheduler.user` active (`on`, or `canary` whose channel list
   names the turn channel; `_v2_turn_channel` yields `dashboard` for the
   dashboard, `discord`, `loopback_ws` or `synthetic`). `GROUP_FEATURES` in
   `brain/cognition/inference_scheduler.py` maps group `user` ->
   `inference_scheduler.user` and group `voice` -> `inference_scheduler.voice`.
2. The provider hook is enabled. `ProviderHooks.tick` (ticked by the cognitive
   runtime) requires the configured env mode (`LEON_PROVIDER_ROUTER`) not
   `off`, `runtime.accepting` (live flag `runtime` not `off`; it defaults to
   `shadow`), and live flag `provider_router` in `shadow`/`canary`/`on`. The
   effective mode is `shadow` if either side says shadow, else `canary` if
   either says canary, else `on`. Only `canary`/`on` route; `canary` routes
   only `canary: true` entries.
3. The request scope matches a route exactly and the request carries no tools
   (the no-tools responder branch).

Minimal live file for dashboard routing in canary:

```json
{"schema": 1,
 "flags": {"runtime": "shadow", "user_turn_recorder": "on", "context_package": "shadow",
           "inference_scheduler": "shadow",
           "inference_scheduler.user": "canary",
           "provider_router": "canary"},
 "canary": {"inference_scheduler.user": {"channels": ["dashboard"], "fraction": 0.0}}}
```

Then `provider_router: on` (with `canary: false` routes also selected) once
the canary is reviewed. Keep the existing flags (`runtime`,
`user_turn_recorder`, `context_package`) exactly as deployed.

Order: install the file (0600) -> add the three env lines to the drop-in ->
restart through the continuity gate -> confirm the startup line says
`reason=configured` and `v2_provider_reason=installed_cold` -> run the probe
dry run -> set `inference_scheduler`/`inference_scheduler.user` live flags ->
set `provider_router` to `canary` -> observe one dashboard turn -> `on`.
Setting `provider_router` back to `off` drains and retires the owner without
a restart; `shadow` keeps it cold.

## Exact scheduler scopes (from code)

| Turn | `site` | `group` | `channel` | Evidence |
| --- | --- | --- | --- | --- |
| Dashboard / Discord / loopback text via `/ws` | `server/routers/websocket.py:_respond_async` | `user` | `user` | `server/routers/websocket.py` lines 82-85 pass `site=... group="user"`; `inference_scheduler.submit_foreground` (`brain/cognition/inference_scheduler.py` lines 1115-1116) hardcodes `channel="user"` |
| Voice utterance | `server/helpers.py:handle_voice_utterance` | `voice` | `user` | `server/helpers.py` lines 1551-1554; same `submit_foreground` `channel="user"` |
| Wake orchestrator | `brain/voice/wake_orchestrator.py:_handle_utterance` | `voice` | `user` | `brain/voice/wake_orchestrator.py` line 413; same submission wrapper |

Note the difference between the two channel notions: the scheduler request's
`channel` (`user` for every foreground turn, `daemon` for background) is what
`RequestScope` matches; the responder kwarg `channel` (`dashboard`, `voice`,
`wake`, ...) and the canary channel list for `inference_scheduler.user` use the
turn-source labels. `ProviderHooks.requires_admission` maps `voice`/`wake`
to `user` for the same reason.

## Verification harness

`tools/v2/provider_probe.py --config /etc/leon/provider_config.json
--canonical-root /opt/leon-brain/brain_state --env-file /opt/leon-brain/.env`
(dry run, default) loads the file through the real loader, renders the exact
request the adapter would send for a one-sentence turn and prints sizes,
hashes, bounds and the reservation; the transport opener refuses, so no
request leaves the host. `--env-file` reads only the variables the file
names. `--live --i-have-operator-approval` performs exactly one bounded
request through the real adapter, router and the configured ledger and
prints the resolved model, reported usage, cost estimate and latency. The
live mode is for the integrator with explicit approval; it was not run for
this change.

## What this change does not do

It does not verify billing, bounds, cancellation or no-tools behaviour of
any hosted model (the `verified` flags are attestations), does not install a
live configuration, does not change defaults (no env opt-in means the file
is never read), and does not add tool-bearing, decision or non-OpenAI
routes.
