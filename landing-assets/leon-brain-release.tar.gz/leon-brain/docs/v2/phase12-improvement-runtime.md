# Owned supervised development proposals

`ImprovementRuntime` combines the existing TaskRuntime registry, TaskStore,
PlannerRuntime, PlannerAuthority, ImprovementArtifacts and ImprovementPipeline.
It adds no database connection, worker, model transport, loop, deployment or
promotion API. Construction is cold and selection defaults OFF. Root must assign
`runtime._improvement_owner` and prepare this exact owner after the operator
planner, before constructing TaskWorker. Runtime/executive/configuration hooks
are a separate integration change.

## Registration and private storage

`ImprovementWorkspace` is a frozen trusted operator declaration. Its fields are
`key`, `project_scope`, `source_revision`, `isolation_ref`, `input_files` (tuple of
InputFile), `editable_paths`, `protected_paths`, `required_checks`, and
`forbidden_roots`. The actual existing workspace root, inode/owner and configuration
are obtained from TaskRuntime's configured backend. Forbidden roots must cover the
actual operational directory and application source; root also supplies actual
canonical/configuration/service-private roots. This owner provisions no checkout
and verifies no Git revision. `source_revision` and `isolation_ref` are trusted
operator provenance, while tree/diff/artifact hashes come from an actual bounded
complete file capture.

`ImprovementRuntimeConfig(workspaces=tuple, enabled=lambda:False,
resolve_check_evidence=None, resolve_trigger=None)` also bounds retained proposal
count (default 8, maximum 32), total private artifact bytes (default 16 MiB,
maximum 32 MiB) and combined approvals (default 128, maximum 1024). Each bundle
retains the artifact validator's existing per-bundle/file/tree limits. Artifact
bytes are private BLOBs in the existing registry; operational checkpoints contain
metadata and digests only. Constraint callbacks read bounded metadata, never BLOBs.
Capture, full validation/hashing and proof lookup run outside runtime/store/pipeline
locks. Immutable BLOB reads use the existing SQLite connection outside those locks;
the planner operation counter keeps it alive, and metadata is revalidated afterward.

`register(principal, workspace_key, goal, replacements, idempotency_key,
trigger_kind, trigger_ref, approved=True)` reserves a dedicated parent before any
proposal/child, stages immutable registration metadata, creates its TaskStore
proposal, captures the exact source and candidate bundle, and finalizes registration.
Lost replies retain identity; changed input conflicts. Partial registrations deny
all action authority. Only explicit executive requests need no event resolver.
Failure/maintenance triggers require a trusted resolver returning the exact typed
RetainedImprovementTrigger; an asserted event string alone is denied.

## Combined approval and immutable parent reservation

The ingress reservation is ParentConstraint('development_improvement', reference,
binding_sha256), included in immutable parent registration and idempotency before
parent creation. `_approval` checks it before and after containment preview, at
child submission, and at active effect authorization. A missing callback after
restart refuses reserved actions; ordinary plans remain unchanged. Root binds
`approval_constraint(context, reservation, validated_operator_receipt)` once in the
pre-worker startup window. Callback replacement while workers exist is refused.

`advance` uses only the existing admitted scheduler path and stops while any receipt
or evidence is unresolved. `review` returns the exact pipeline review, operator
review and their combined digest. `approve(task_id, principal, review_sha256,
idempotency_key, validity_s, approved=True)` obtains the actual server-minted operator
receipt, persists a combined approval bound to the registration, artifact, both
reviews and original expiry, then delegates Pipeline.approve_step. The constraint
also requires the exact durable pipeline DISPATCH_INTENT journal, so generic
planner approval cannot dispatch in the interval before that journal exists.
Expired/revoked replies with retained children recover metadata without new grants,
expiry renewal or replay. FAILED and UNKNOWN remain NEEDS_REVIEW.

`proposal`, `reconcile`, `cancel`, and authenticated private `artifact` retrieval
are explicit calls, not background work. Root's existing tick remains the sole
outbox consumer. `quiesce` immediately cuts off new work; `drained` and the existing
PlannerRuntime operation counter retain ownership through capture, inference,
private reads and proof hydration. No automatic completion or promotion is exposed.

## Check material, execution exclusion and evidence

`proof_required(action, task, spec)` classifies actual immutable task/child/parent
registration. Unreserved ordinary checks return False, including while improvement
selection is OFF. Reserved missing/inactive material refuses; it cannot downgrade
to an ordinary writable check. `check_material` returns frozen
ImprovementCheckMaterial(registration, development_binding, exact bundle bytes,
step_key, planner_proposal_sha256, role) after current effect authorization.
`historical_check_material` verifies retained identity for receipt lookup without
renewing current approval. Neither material object is execution evidence.

The strong execution boundary must be selected separately: an immutable complete
input snapshot and pinned runtime closure, supervised by the verified check service
until all descendants drain. Private schema4 startup should require that proof-aware
factory. A trusted legacy-wrapper development fixture can run an explicitly approved
writable baseline; **EVIDENCE_REQUIRED does not mean that execution was read-only**.
This owner makes no mutation-exclusion claim for such a check. Missing proof prevents
it from qualifying as a baseline or unlocking edits/promotion. Production/default
embedded integrations should require the proof-aware factory; a callback alone
cannot establish execution exclusion.

Root can cold-bind `bind_input_proof_resolver(resolve_input_proof)` before workers,
mutually exclusive with the trusted external `resolve_check_evidence` callback.
The broker resolver must return the exact task_check_snapshot.VerifiedInputProof
from an authenticated persisted receipt, or None. The owner maps it to CheckInputProof,
checks registration/artifact/role/tree/action/proposal/configuration and persisted
result sequence/hash, and retains immutable CheckEvidence plus request/proof/runtime
hashes. The optional external callback receives `(action, task, spec,
historical_material)` and must supply independently trusted CheckEvidence. It is
never called under pipeline/runtime/store locks. Subsequent pipeline history reads
use retained evidence offline. UNKNOWN/FAILED results never request success proof.

Missing first proof leaves public phase EVIDENCE_REQUIRED (the underlying pipeline
step also records EVIDENCE_REQUIRED). Exact typed proof hydration is covered by a
synthetic trusted broker fixture using actual TaskRuntime actions and retained
receipts. The fixture does not authenticate a real broker, execute a check namespace,
or establish actual mutation exclusion. Positive service-proof hydration remains
an explicit integration gate until the snapshot service/broker and owner are tested
together. Production evidence still comes only from the configured trusted resolver.
The current pipeline also requires a SUCCEEDED baseline: an expected failing test
remains NEEDS_REVIEW. Supporting diagnosed repairs needs a future explicit expected
baseline-outcome policy with the same isolation/drain evidence; this slice does not
weaken that rule.

## Validation

Tests use actual TaskRuntime, TaskStore, grants, PlannerRuntime, PlannerAuthority,
immutable ingress, InferenceScheduler and TaskWorker with synthetic model and
containment fixtures inside the hardened external sandbox. They cover cold/OFF,
real artifact persistence, registration/approval idempotence, generic/pre-intent
approval refusal, negative/UNKNOWN receipts, active/historical material, missing
proof, ordinary checks while OFF, concurrent capture versus committed effects,
proof callback lock availability, and retirement while capture is in flight.
No production state, model request, host provisioning, deployment or restart occurs.

`test_improvement_receipts.py` exercises the exact VerifiedInputProof dataclass via
a synthetic trusted receipt resolver. It covers baseline and candidate qualification
ending at READY_FOR_REVIEW without promotion; offline evidence after expiry,
revocation, feature OFF and restart with no resolver; mismatched typed proofs and
persisted broker receipts; receipt/registration changes during lookup; later
TaskStore receipt changes despite cached evidence; and FAILED/UNKNOWN exclusion.
Blocked proof lookup, capture and artifact validation prove that actual planner and
improvement operation counts retain both SQLite connections after workers stop.
Only after the operation returns may retirement close those connections. These
tests are independent of any claim that a real namespace or broker was exercised.

Final baseline validation: **221 passed in 5.64 seconds** across the owner, pipeline,
artifacts, constraint, ingress, planner-runtime and operator-authority modules.

```text
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase5 /opt/leon-v2-tools/test-results/improvement-owner-20260930-d --mem 768M -- python3 -m pytest -q tests/test_improvement_runtime.py tests/test_improvement_pipeline.py tests/test_improvement_artifacts.py tests/test_planner_constraints.py tests/test_task_planner_ingress.py tests/test_task_planner_runtime.py tests/test_task_planner_authority.py
```

Receipt/lifetime follow-up: **253 passed in 7.23 seconds** across those seven modules
plus 32 new receipt tests. No owner production-code change was needed. In the isolated
development tree, the snapshot module was copied only to import its exact proof
dataclass (SHA256 `5829e289e9c890c8d17930eb58f08aaba8116b73291d493f51d5e30d09d48be5`);
it is explicitly excluded from the receipt-test commit. The combined root tree must
integrate the snapshot owner's reviewed implementation separately before running
this new test module.

```text
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase5 /opt/leon-v2-tools/test-results/improvement-receipts-20260930-c --mem 768M -- python3 -m pytest -q tests/test_improvement_receipts.py tests/test_improvement_runtime.py tests/test_improvement_pipeline.py tests/test_improvement_artifacts.py tests/test_planner_constraints.py tests/test_task_planner_ingress.py tests/test_task_planner_runtime.py tests/test_task_planner_authority.py
```
