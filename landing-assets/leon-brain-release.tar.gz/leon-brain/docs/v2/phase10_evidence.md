# Phase 10 isolated receipts — 2026-09-29

All paths below are under `/opt/leon-v2-tools/test-results/`. Worktree base was
`9f070d26eeec4b53ed35905fe2878fb1e06f93bc`. Tests and profiling ran only through
the shared serialized `sandbox_run.sh`, with 768 MB, no network, and fixture state.
One earlier launch was refused by the memory guard; no test executed in that
attempt. The next admitted run passed. No guard was bypassed.

The final suite passed **30 tests** in 1.38 s:

```sh
bash /opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase10 \
  /opt/leon-v2-tools/test-results/phase10-tests-20260929c --mem 768M -- \
  python3 -m pytest -q -p no:cacheprovider \
  --junitxml=/opt/leon-v2-tools/test-results/phase10-tests-20260929c/tests.xml \
  tests/test_activity_controller.py tests/test_snn_buffers.py tests/test_snn_profile.py
```

The baseline and candidate profiling commands used `python3
tools/v2/snn_profile.py --synthetic --neurons 1024 --steps 40 --warmup 10
--cprofile 0 --rust prod`, with `--scratch` set to their corresponding results
directory and `--json` set to its `profile.json`, under the same sandbox launcher.
The candidate additionally includes a paired reference/derived-buffer experiment.
The installed Rust kernels were available; no compilation/download occurred.

| Receipt | SHA-256 |
|---|---|
| `phase10-tests-20260929c/tests.xml` | `802078e556db49c8e0fb273625d4758f67b1b92428bb5478da41087f15b1671a` |
| `phase10-tests-20260929c/source.sha256` | `5dddf2fde7a86c2f9de436b85c4802bfce190ded5909acac1e22decbf632dfbb` |
| `phase10-baseline-20260929/profile.json` | `860d450e7f192622b8f7441f088517842aa98655624b62ccedce9343914c954a` |
| `phase10-candidate-20260929a/profile.json` | `171cb69648ff713e1e940dd0dc6f66fc694c92532d5ee2dd005a52c5441b8b48` |
| `phase10-interrupted-20260929/dirty-files.tar` | `89d51aa1bfc75021110ae00c157fb30fd8b5c10b2d0d701a51676cf92cedc5dc` |
| `phase10-interrupted-20260929/backup-manifest.sha256` | `79dc79eb60b9279a7ce0e45c3650451c82598d424098edce55b251786ee7d8d5` |

The source manifest lists exact tested file hashes. This evidence note was added
after testing; implementation and test bytes were unchanged afterward. Staging
verified all expected previous hashes and created another byte/mode backup before
every update. The preserved original profiler remains mode 755 in the candidate.

The paired fixture retained exact numeric state at all 40 steps. Mean timing was
1.1477 ms reference versus 1.1605 ms candidate: **no performance gain is claimed**.
Both experimental rates and derived buffers remain disabled by default. These
receipts do not validate live 100K behavior, full copied-state profiling, or live
workspace/self-model/sensory/server costs. See [phase10_snn.md](phase10_snn.md)
for integration hooks and remaining acceptance requirements.
