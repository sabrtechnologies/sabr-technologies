# Supervised development improvement proposals

This core records and checks bounded improvement proposals under the existing
executive, TaskStore, TaskPlanner, durable child ingress and TaskWorker. It has
no scan, timer, consumer loop, model call, action executor, database connection,
grant issuer, outbox acknowledgment, deployment or promotion operation. Selection
defaults OFF; construction only stores supplied references and allocates a lock.
It is not installed in runtime event handling by this change.

The existing self-repair routines and tool-failure callbacks have effectful legacy
paths. Their mere existence does not authorize automatic repair. An integrating
executive must select this proposal path explicitly and retire overlapping legacy
authority; it must never call `retry_last_failure`, snapshot restore, config_set
or direct prompt-comparison clients as a pipeline backend. UNKNOWN receipts keep
their existing TaskStore resource fences. This core never replays them.

## Required trusted registration

Root supplies an existing operational TaskStore, actual TaskPlanner and its
DurableStepIngress. Each proposal uses a separate externally registered metadata
task so the pipeline cannot overwrite the planner parent's checkpoint. The parent
must be a dedicated unused plan with its own immutable `PlanContext` registration.

`ImprovementRegistration` binds the principal, both task identities, submission
and authorization references, parent context digest, isolated development
workspace scope, root device/inode identity, configuration digest, isolation
attestation reference, exact base revision, source and candidate tree digests,
reviewed diff digest/private artifact reference and full `artifact_sha256`, per-file before/after SHA256,
explicit editable/protected paths, required named checks, existing event reference
and a bounded deadline. Protected paths are exact paths or directory prefixes.
The trusted development registry must enumerate canonical stores, identity and
risk-policy targets as protected and must exclude live aliases from the workspace.
The existing project backend rechecks workspace/path identity at effect time.

Candidate generation, private artifact storage, exact diff verification and
development-checkout isolation are external integration gates. This module does
not infer them from a model suggestion or invent a manifest from current files.
Operational checkpoints store only bounded metadata and digests, never source
bodies, prompts, raw check output, debug logs or secrets. Replacement text is
compared in memory against the registered after digest and remains in the existing
reviewed planner/action records rather than being copied into this proposal.

## API and ownership

Construct `ImprovementPipeline(store=..., planner=..., ingress=...,
resolve_registration=..., resolve_plan_context=..., resolve_approval=...,
resolve_check_evidence=..., enabled=...)` only with trusted adapters. These are
explicit integration inputs, not model-callable authority or guessed credentials.
The existing executive invokes bounded calls outside the user-context hot path.

1. `offer(proposal_task_id, principal=...)` creates an idempotent metadata checkpoint
   for an already registered failure/maintenance/executive event. It does not
   submit inference or actions.
2. The existing executive invokes TaskPlanner.advance under its scheduler policy.
   `review_step` compares the public proposal and opaque planner proposal digest
   with the exact improvement manifest. Read/replace/named-check are the only
   accepted actions. Successful source-attested baseline checks precede edits;
   every exact replacement precedes candidate checks. No step self-approves.
3. A trusted approval service records an immutable `ImprovementApproval` binding
   registration, review digest and planner proposal digest. `approve_step` records
   DISPATCH_INTENT first, then delegates exact approval to TaskPlanner.approve_step.
   Before delegation the pipeline requires
   `ingress.record_approval(parent_id, principal=..., proposal_sha256=...,
   approval_ref=..., approved=True, expires_wall=...)`. Its exact retained expiry
   comes from `ImprovementApproval`; an opaque reference never creates a new TTL.
   The return must bind the same `step_key` and `proposal_sha256`. The pipeline
   re-resolves the unchanged active approval after both its intent checkpoint and
   the ingress record, immediately before planner delegation. The ingress must
   independently resolve trusted approval/revocation authority, make repeated
   records idempotent without extending expiry, set the child grant expiry to
   `min(approval expiry, parent deadline)`, and recheck it/revocation at dispatch
   and final effect authority. Parent deadline alone is insufficient.
   The planner recomputes its private digest and the shared ingress durably grants
   and queues the child action. An explicit repeated approval after a lost reply
   resolves that same retained child identity before delegating again, including
   when the existing executive already polled its receipt. It does not create
   another action.
4. `reconcile` obtains each `StepIdentity(task_id, action_id, proposal_sha256)` from
   immutable ingress registration, checks TaskStore receipts and saves only
   outcome/sequence/digest metadata. It also polls the existing planner to advance
   its receipt checkpoint. It never enqueues, acknowledges the shared outbox or
   discards prior evidence. Journal metadata is bound back to the immutable
   reviewed approval, so checkpoint relabeling cannot turn baseline into candidate.
   Every status read also revalidates saved terminal outcomes against their actual
   retained receipts and immutable child registrations; checkpoint edits cannot
   manufacture success or replace a child with another parent's action.

Successful checks additionally require `CheckEvidence` from a trusted immutable
execution-owner receipt: exact proposal/parent/step/action/proposal digest,
configuration, source tree, result sequence/hash and evidence reference. Its
nested frozen `CheckInputProof` must bind that same action, planner proposal,
configuration and complete `artifact_sha256`, a retained snapshot reference,
input tree and completion tree. Both trees must equal the expected registered
source/candidate tree. The proof requires mode `immutable_readonly_snapshot`,
literal `mutation_excluded`, `held_until_drain`, `namespace_drained` and
`process_drained` fields all True.

Those fields are an explicit trusted resolver contract, not a proof obtainable
by passing strings/booleans or caller-provided hashes. The execution owner must
verify and retain an actual complete immutable input snapshot, independently
enforce exclusion of source mutation/substitution throughout the check, capture
completion under the same authority, and bind all evidence to the exact attempt
and its drained descendants. Matching pre/post hashes alone cannot rule out a
transient source rewrite. The full artifact hash maps to
`improvement_artifacts` bundle metadata `artifact_sha256`, not `binding_sha256`
(the latter hashes registration and does not identify the full byte-exact bundle).

The existing general project check and writable-workspace check service do not
establish this stronger input boundary and cannot issue qualifying proofs.
General checks may still write their approved workspace. A successful check that
rewrites tracked improvement input cannot qualify READY_FOR_REVIEW. A green
receipt without evidence stays EVIDENCE_REQUIRED; malformed, incomplete or changed
accepted proof is refused. Production immutable-snapshot creation, exclusion,
completion measurement and durable attestation issuance remain unbuilt external
integration gates. The synthetic proof records in tests establish no live
namespace or mutation exclusion capability.

Any FAILED, CANCELLED or UNKNOWN result remains in the journal and yields
NEEDS_REVIEW. This includes a failing baseline; it cannot silently reset or
replan that attempt. Root must review a new authorization/plan if further work is
warranted. `cancel` preserves metadata and delegates future-action cancellation
to the existing planner; late receipts remain reconcilable. `quiesce` stops new
pipeline admission without stopping or closing any external owner. OFF permits
explicit receipt reconciliation, while offer/review/approval are disabled.

The only successful terminal proposal state is READY_FOR_REVIEW after every
registered edit and source-bound candidate check succeeds. The metadata task
remains PAUSED and `promotion_allowed` is always false. The pipeline never
acknowledges planner completion, merges, deploys, restores, rewrites canonical
identity/policy, or interprets an internal signal as evidence of consciousness.

## Validation and remaining integration gates

Tests use the real TaskPlanner, scheduler, TaskRuntime, grant policy, TaskStore,
TaskWorker and project actions with temporary development files, fixed Python
checks and a synthetic proposal provider. Trusted artifact/approval/source-tree
registration is a fixture service, not production wiring. Tests must run only
through the installed serialized sandbox launcher with 768M; no model, paid API,
production store, service or live repair path is invoked.

The candidate is based on root commit `2ae57a060a43edc4caea7789a90e8fc6c60bb47a`
plus the separate planner dependency `71d18993c6c1474f86abe909254b8cde54aa68b5`
(cherry-picked here as `8edb447e7f81f88ac049c8e854b3664014b125d3`). The original
`v2/self-improvement` branch at `9f070d26eeec4b53ed35905fe2878fb1e06f93bc` is
preserved. Validation through the unchanged 768M serialized launcher:

- `improvement-pipeline-20260929-b`: improvement, planner, project-action, policy
  and task-runtime modules, **175 passed in 3.44s**.
- `improvement-pipeline-20260929-c`: improvement module in a fresh process,
  **26 passed in 1.07s**.
- `improvement-planner-20260929-b`: planner module in a fresh process,
  **25 passed in 0.65s**. Its first isolated launch was refused by the unchanged
  host reserve check; a later normal launch passed without lowering the threshold.

Fixtures cover exact source/candidate bindings, actual approved child effects and
receipts, principal and cross-candidate denial, missing/changed source attestations,
FAILED/UNKNOWN preservation, lost replies, cancellation, OFF and shutdown. They
do not establish a production registry or source-attestation service.

Root still owns event selection, isolated workspace/artifact registration, trusted
approval-service exposure, durable dispatch-source attestations, duplicate legacy
repair prevention, and deployment/continuity gates. This candidate does not claim
autonomous improvement or live acceptance.

The subsequent evidence/approval review hardens the three-file core without
changing planner, runtime, project actions or the general check service. Historical
receipt reconciliation stays available after ordinary approval expiry and never
refreshes a grant. Old dispatch-only check attestations fail the new contract;
they must not be upgraded by inventing an isolation claim after execution.

Review-fix verification on base `6f7b7dc6f5380d3c1d7c40a8160456e89b107f91`:
the unchanged serialized 768M launcher ran improvement, planner, policy and task
runtime modules, **162 passed in 3.16s**. This is separate from the earlier
175-test baseline and does not include root's later service/ownership integration.
New fixtures cover tracked input rewritten by a successful candidate check,
matching hashes without exclusion, altered/missing same-attempt proof, approval
expiry/revocation/replacement during intent/registration, missing bounded ingress,
and actual shorter-lived TaskPolicy grants held queued until expiry/revocation.
One first-run test fixture incorrectly withheld already accepted baseline evidence
along with the new candidate evidence; the fixture was narrowed to withhold only
the pending candidate record before the successful run. No boundary was loosened.

Receipt: `/opt/leon-v2-tools/test-results/improvement-review-tests-20260929b/tests.xml`,
SHA256 `48ccd8f85ceaca4a0bfcf6fb99e5d6f43e944b791daec854f0f76ca693210a28`.
The adjacent `tested-source.sha256` has SHA256
`19292db5fa13fa693425b49b79bb634f280ef4a25de279a4bbc745a16c0b20dc`.
Documentation was updated after the tested code/test bytes were captured.
