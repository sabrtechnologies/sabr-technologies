# Durable supervised planner ingress

This candidate implements durable parent registration, exact per-step approval,
child admission and receipt lookup for `TaskPlanner`. It opens no database
connection and owns no worker, scheduler, model, action handler or periodic loop.
It adds three tables to the existing task registry connection in `tasks.sqlite`:
configuration metadata, immutable plan registrations and immutable reviewed
step records with recoverable child identities. Quotas reject new records;
expiry and cancellation never prune idempotency or UNKNOWN evidence.

## Root installation contract

Construct `PlannerIngress(runtime, resolve_scope=..., resolve_approval=...,
enabled=...)` and call `prepare()` after the existing store, registry, policy
and backend exist, BEFORE the existing TaskWorker starts. Attach this exact
instance for the runtime lifetime. Preparing later could let a restarted worker
reject retained children before their authority resolver is installed.

`resolve_scope(principal, scope)` returns a frozen `PlanScope(project_scope,
allowed_actions, allowed_paths, allowed_checks, max_steps=8, max_rounds=16,
lifetime_s=900, authorization_revision=1)`. Collections are explicit tuples,
with at most sixteen members each. The resolver is trusted startup policy,
never a deserializer for request/model fields. `enabled` must be a fast, pure
literal boolean selector, with no scheduler, worker-health, RPC or database call.
Admission defaults OFF.

`register_plan(*, principal, scope, goal, idempotency_key, authorization_ref,
approved)` requires literal True and verified installation identity. This
registers planning permission only. The returned immutable `PlanContext` binds
goal digest, exact scope, lifetime and budgets independently of checkpoints.
Use `resolve_context(parent_id)` as the existing TaskPlanner resolver.
Before new planning inference or completion acknowledgment, root also calls
`require_active_parent(parent_id, principal=...)` to recheck current scope
revision, cancellation, revocation, expiry and selection. Historical reads
continue to use the immutable resolver. The gate releases its locks before
the caller performs any inference or completion work.

The trusted approval service must expose `resolve_approval(approval_ref)` as
a current durable `PlanStepApproval(principal, parent_id, project_scope,
proposal_sha256, approval_ref, issued_wall, expires_wall, revoked=False)`.
The approval service owns authentication and explicit human authorization;
neither an approval reference string nor an unverified boolean creates it.
The resolver must consult actual durable revocation/expiry metadata without
network/model effects or locks that invert the runtime/store order. A matching
observed external revocation is also retained locally and cannot be cleared by
a later resolver error. `revoke_step(parent_id, principal=..., step_key=...,
revocation_ref=...)` explicitly installs the same permanent fence. Before
`TaskPlanner.approve_step`, call
`record_approval(parent_id, principal=..., proposal_sha256=..., approval_ref=...,
approved=True, expires_wall=<the original reviewed expiry>)`.

Recording binds the exact canonical action, reviewed proposal digest and
source digest (request, round, step and verified receipt history). It performs
no action. Dispatch rechecks all of these against the parent's exact revision
and `DISPATCH_INTENT`, plus current trusted scope/approval. It never regenerates
an approval lifetime. Child/grant expiry is the minimum of the original approval
expiry and parent deadline. Reusing a reference with a changed expiry conflicts.

Root TaskPolicy's resolver should first resolve normal task registrations,
then `ingress.resolve_child(child_id, active=True)`. The latter rechecks parent
cancellation/revocation/expiry and the current trusted per-step approval even
when the action is already dispatched and awaits a final effect boundary.
Actual handlers still perform their existing exact grant/resource/hash checks.
For authorized historical task views use `active=False`; that path does not
authorize any effect. Missing/changed/revoked authority fails closed.

## Transactions, cancellation and recovery

Admission uses the existing lock order: runtime then TaskStore. Worker-health
inspection happens before taking the store lock, avoiding inversion with worker
claim. The store lock serializes parent revision/checkpoint/cancel with child
grant/enqueue in this single-owner process. No SQL transaction spans a grant
database operation, model inference, RPC or action effect. Worker notifications
happen after releasing the store lock. Separate process writers bypassing the
existing runtime and worker lease are unsupported.

Containment preview is a bounded remote operation outside both runtime and store
locks. Otherwise a check already holding the service's sole protocol connection
could be denied its final parent authority while another approval waits for that
connection. New approval recording and child submission therefore validate local
authority, release both locks for one preview, then reacquire and fully validate
again before writing. The exact parent revision, proposal/source/intent, scope,
canonical resources, original approval identity and current expiry must still
match. A changed snapshot is refused without retry or a new grant/action. The
existing worker also checks current authority at its final effect boundary.
Retained child/approval lookups perform no preview, refresh, or effect replay.

Each registration stage is durable before the next. A crash after parent or
child creation, grant issuance, enqueue or before reply recovers the same
deterministic submission and exact retained action. An accepted child lookup
does not re-grant or re-enqueue after expiry/configuration change. A partial
submission with no accepted action must satisfy current authority before it
can continue. UNKNOWN actions retain the existing TaskStore resource fence.

For user cancellation, root calls `cancel_plan(parent_id, principal=...)`
before `TaskPlanner.cancel` cancels its inference handle. The first call
serializes parent and all undispatched child cancellations; a dispatched child
is left to drain and retain its result. Its later authority check still denies
new effects after parent cancellation. Already completed external effects
cannot be undone; ambiguity is retained by the existing worker as UNKNOWN.
Direct planner cancellation also invalidates parent authority, but its two
calls cannot atomically cancel parent and already queued child together.

`lookup_step` and `receipts(child_id, principal=..., after_seq=0, limit=100)`
read immutable child identity and retained receipts independently of active
authority. `lookup_approved_step(parent_id, principal=..., proposal_sha256=...,
approval_ref=..., expires_wall=<original expiry>)` recovers the exact accepted
child even after parent polling, cancellation, expiry or revocation. Unknown
digests return None; reference/expiry mismatch conflicts. It makes no writes,
and never refreshes approval or changes the current parent checkpoint.
Root's existing result loop calls `checkpoint_result(result)` for
planner child results and acknowledges consumer `runtime` only when it returns
literal True. That helper verifies the immutable action identity and exact
receipt, then checkpoints successful child completion. It never acknowledges
the outbox or advances the parent. TaskPlanner.poll separately consumes retained
receipts; reconnect reads cannot steal delivery capacity or authority.

## Validation and limits

Tests use the real TaskRuntime, TaskStore, TaskPolicy, ProjectActions and
TaskWorker with temporary sandbox workspaces. Proposals and approval records
are explicit synthetic fixtures; no model or production action runs. The root
factory/resolver wiring is prototyped by the test startup seam, because those
shared files are separately owned. The core remains a supervised bounded
planner, not an autonomous coding service. Live installation and evaluation
remain separate integration gates.

The serialized 768M run `planner-ingress-20260929-d` passed 262 tests in 9.05s
across ingress, planner, runtime, policy, project actions, worker, lifecycle and
inference scheduler. The runner retained its JUnit XML. Exact before/after
manifests and candidate snapshots are preserved under
`/opt/leon-v2-tools/source-backups/handoff-planner-ingress-20260929`.

The follow-up lock repair, based on `8d79eb9eaa864955999aea8e22146b1109f28799`,
passed **173 tests in 2.56s** across ingress, planner, runtime and policy through
the unchanged serialized 768M launcher. Receipt:
`/opt/leon-v2-tools/test-results/planner-ingress-locks-tests-20260930b/tests.xml`.
New cases cover serialized remote preview, both parent locks remaining available,
and revision, intent, scope, source, canonical resources, revocation, expiry,
cancellation, OFF and unavailable containment during the unlocked interval.
The service-connection fixture models the separately owned parent-only final
authority callback explicitly; it does not attest a real namespace or service.
Its first version incorrectly invoked the older base runtime's recursive preview
while holding the simulated service connection. That fixture was corrected;
the ingress implementation was unchanged between the failed and passing runs.
Before/candidate source hashes and diffs are retained under
`/opt/leon-v2-tools/test-results/planner-ingress-locks-stage-20260930`.
