# Strict deploy-name preflight repair

`tools/v2/ops_pyflakes_strict.py` mirrors installed
`/opt/leon-v2-tools/pyflakes_strict.py`; `ops_deploy_wave.sh` mirrors installed
`deploy_wave.sh`. Deployment of these standalone operator tools is separate
from shipping application code. No application deployment or service action was
performed for this repair.

Star imports are expanded by replacing AST aliases, preserving adjacent
statements. Generated-source diagnostics can have different line numbers.
Analyzer absence, launch/timeout/status errors, malformed output, cyclic or
unresolved star imports fail closed. `--compare-base` compares normalized
diagnostic multisets rather than total counts: line shifts are tolerated, while
substituted names or additional repeated defects reject. This is a static name
check, not proof of runtime import availability or all control-flow behavior.

Preflight-only exits return before all service repair, rollback and drop-in
cleanup operations, including failure exits while a service was already down.
Staging, logs and analysis artifacts remain intentional preflight writes.

Twenty-one hermetic tests and twenty-six subtests passed in the unchanged serialized
768 MiB sandbox. They cover analyzer failures, resolved-star inline statements,
same-count name changes, repeated defects and mocked preflight exits 0/1/2 with
an inactive service and existing drop-in. No real deploy script was invoked.

All 185 changed Python files in candidate
`70b009b295ab51d8a68f4f1dfcacef113ac9364b` passed versus deployed base
`5f088929099adee485200634c8aeafe45fb841f1`. Original negative-control commit
`540399fda408a2a0849414f9d927a59e5d36d802` still rejected both undefined names.

Evidence lives under `/opt/leon-v2-tools/test-results/checker-repair-20260929a/`
(source, diff), `checker-repair-20260929d/tests.xml` (regressions) and
`checker-repair-20260929e/` (candidate/negative controls). Original installed
sources and modes are preserved in
`/opt/leon-v2-tools/source-backups/checker-repair-20260929a/`.

Installed checker SHA256:
`591d9ce3975c85e21a86d937f9ecf888d7b8f62ccf6c7af038bb886ccde35cbe`.
Installed deploy script SHA256:
`c13e59a2bb90612b5cd301f455e14df12e621c14ede41f7ad8faad3035a71436`.
Regression receipt SHA256:
`9ad1798db2f968103f6f91a5353dcbd7c7d60455277aa0bd15e435f03ae402d3`.
Validated installed-tool diff SHA256:
`84604b9c1ced2a98b142d092a22216ef6e594b7f8fff978dbf8fd59e7a3d9e0b`.

Local preservation includes all before/after sources, tests, receipts and a
SHA256 manifest at `C:/Users/pazzo/Desktop/leon-takeover/checker-repair-20260929`.

The follow-up export audit rejects annotation-only bindings, deleted bindings,
conditional bindings, mutable/aliased `__all__` and explicit exports without
proven bindings. These conservative refusals avoid silently treating type hints
or conditional assignments as guaranteed runtime values. Runtime side effects,
dependency availability and arbitrary module control flow still require tests;
static success is not a general guarantee against NameError or ImportError.

Follow-up source/backup evidence is under `checker-export-20260929a`; the
21-test/26-subtest receipt is
`/opt/leon-v2-tools/test-results/checker-export-tests-20260929a/tests.xml`, SHA256
`1a63f6df1f261618679aecc9f6dd9015657afe93881553e50edd0916389b91c5`.
The same 185-file parity and original negative controls are retained under
`checker-export-parity-20260929a`.
