# Phase 8 prospective observer integration candidate

This candidate adds a cold callback registry and one `PredictionRuntime` for
the existing cognition event consumer. It creates no thread, bus consumer,
model, canonical store, action path or identity state. OFF creates no observer.
All enabled flag modes (`shadow`, `canary`, `on`) select SHADOW observation.
The existing result-time `CognitionLoop.record_tool_call` prediction remains
retrospective and its existing episode, drive, WorldModel update and SNN reward
behavior is preserved. Its legacy result/PE events explicitly carry
`prediction_timing='retrospective'`, `prospective=False` and
`calibration_eligible=False`.

## Root-owned lifecycle wiring

The root owns shared runtime/install/context/init/flags and caller dispatch
instrumentation. None is changed by this candidate.

The inspected base has no dedicated prediction-error config/live-flag field.
Root should add an explicit default-OFF `prediction_error` feature, or keep
`configured_mode='off'`. This adapter reads no environment or flag file and
does not infer activation from the memory, sensory or scheduler flags.

```python
owner = PredictionRuntime(
    clock_id=process_clock_id,       # explicit, unique for this process lifetime
    configured_mode=cfg_mode,       # default OFF
    live_mode=bounded_live_flag,
    runtime_accepting=lambda: runtime.accepting,
    publish=runtime.publish,
    budget=None,                   # no curiosity publication without explicit budget
)
assert v2_publish.install_prediction_owner(owner)  # cold singular binding
# Existing runtime tick:
owner.tick()
# Existing sole consumer, once per dequeued event:
owner.observe_event(event)
# Immediate shutdown cutoff, then bounded retirement on runtime worker:
owner.quiesce()
if owner.stop():
    assert v2_publish.uninstall_prediction_owner(owner)
```

Tick checks live policy and sweeps a bounded registry/observer. It creates the
observer only when requested, and retries refused advisory publications with
stable event IDs. Default capacity is 256 retained capture slots (hard maximum
1024), retention 3600 seconds and forecast horizon 300 seconds. Filled capacity
refuses new records rather than evicting active slots or deduplication tombstones.
Callbacks must be bounded. Live-mode checks belong to the existing tick and
consumer; capture readiness and caller hooks use cached admission and never
invoke flag callbacks. Runtime event dispatch must gate these methods exactly
once; no additional consumer or polling thread is permitted.

`stop(join_timeout=0) -> bool` is compatible with runtime retirement. There is
no thread to join; false means a tick/consumer callback is still in flight.
Retain the owner until `retired` is true, then explicitly uninstall its callback
binding. New owners cannot replace a bound instance, even while draining.
Quiesce prevents later captures and publication admission. A callback already
admitted can finish, and stop remains false until its consumer call retires.

## Exact before-dispatch and terminal hooks

No current producer has been silently made prospective. The root must wire the
Claude tool execution sites and actuator dispatch boundary with the same opaque
ticket; nested actuator calls must not create another ticket for the same action.
Pass that ticket through the actual execution path. Never join by tool name,
latency, global current-request state or approximate time.

```python
ticket = None
if v2_publish.prediction_capture_ready():
    # Ask the EXISTING WorldModel before dispatch. This is its local frequency
    # forecast, not a hosted model request. No new predictor is installed.
    pred = cognition.world_model.predict(kind, tool_name, tool_args, context)
    predicted_at = time.monotonic()
    ticket = v2_publish.capture_world_prediction(
        pred, latency_scale_ms=explicit_latency_scale,
        prediction_id=prediction_id, request_id=request_id,
        action_id=action_id, trace_id=trace_id, clock_id=process_clock_id,
        predicted_mono=predicted_at, deadline_mono=explicit_deadline,
        evidence="unverified",     # caller must justify any stronger provenance
    )
# Immediately before the actual execution call, after action authorization:
started_at = time.monotonic()
v2_publish.mark_prediction_dispatched(ticket, action_started_mono=started_at)
result = existing_authorized_execution()
observed_at = time.monotonic()
cognition.record_tool_call(
    tool_name, tool_args, result, (observed_at-started_at)*1000,
    prediction_ticket=ticket, prediction_observed_mono=observed_at,
    prediction_evidence="unverified", prediction_evidence_ref=None,
)
```

Instrumentation failures must never change action authorization, retries,
execution, existing episode recording or tool result delivery. Prediction
capture is optional: never repeat an action to recover a missing annotation.
The root should isolate failures in its dispatch hook. A forecast obtained after
dispatch/result is not eligible; do not call the capture hook from
`record_tool_call`. The latter still computes its own legacy retrospective
forecast for existing learning, and never substitutes it into the captured pair.
Top-level legacy forecast fields in its event remain labeled retrospective;
separate versioned `prediction_v1` / `outcome_v1` contain the prospective pair.

For cancellation before or after dispatch, send an explicitly nonfailure
terminal observation; do not invoke record_tool_call merely to generate it:

```python
v2_publish.emit_prediction_outcome(ticket, status="cancelled", observed={},
    observed_mono=time.monotonic(), evidence="unverified", evidence_ref=None)
```

The same terminal helper handles non-episode actions or `status='missing'`.
Successful/noncancelled results require actual bounded scalar measurements
through `observed` and an explicit observation timestamp. The generic
`capture_prediction(PredictionRecord)` hook can accept caller-captured state,
scene or goal forecasts with explicit metric scales; this allocation wires no
such source and does not invent their evidence. Capture stores the forecast
before the caller's dispatch marker, requires matching process clock, enforces
capture <= dispatch <= observation and retains full request/action/trace IDs.
The returned ticket is an in-process object, not serializable authorization.

## Single prediction-error owner and honest missing evidence

For a registered ticket, the publisher projects a detached versioned pair and
sets `pe_child=False`. The existing observer is the only producer of its
standardized prediction-error child. Unregistered/raw annotations, a foreign
clock/trace, modified pair, missing dispatch marker, future timestamp, mismatched
identity or expired generation cannot create prospective evidence. A recognized
ticket still suppresses the legacy child after annotation loss, cancellation,
disable, expiry or backpressure. This avoids a second retrospective event being
mistaken for a recovered prospective observation. Missing evidence remains
missing; it never becomes a measured failure.

Identical event redelivery deduplicates; conflicting outcomes are refused.
Cancellation/missing and outcomes beyond the forecast deadline do not create a
prediction-error sample. Consumer processing happens after action completion,
but eligibility comes from the earlier capture and dispatch marker, not event
arrival time. Fabric delivery does not prove real-world execution; the root must
instrument the actual dispatch boundary and preserve its IDs/timestamps.

PredictionErrorObserver's existing eligibility requires both ends explicitly
`measured`, an outcome evidence reference, and a prospective temporal chain.
This is eligibility for descriptive retained-pair scoring, not a calibration
claim. No effect size, accuracy, quantum benefit or measured real-world samples
are claimed by this implementation or its synthetic tests. Public `stats()`
contains counts/status only, `calibrated=None`, `improvement_established=False`;
it excludes identifiers, model histories and metric payloads. Emitted learning
events remain advisory SHADOW proposals; no canonical confidence, skill,
neuron, procedure, memory or goal is changed by this adapter.

## Validation and pending gates

Hermetic fixtures load the actual prediction observer/event/publisher modules
under a private package, with fake clocks and bus. The real loop method is
tested without importing server/brain startup. No production files or stores,
network, models or paid APIs are invoked. On VPS run only the serialized
sandbox launcher, with the assigned development checkout and unique results:

```sh
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase6 /opt/leon-v2-tools/test-results/phase8-runtime-UNIQUE --mem 768M -- python3 -m pytest -q tests/test_prediction_runtime.py tests/test_prediction_error.py tests/test_curiosity_prediction_error.py
```

Before a live shadow gate: root must wire runtime lifecycle and exactly one
consumer hook, configure the shared process clock, propagate tickets through
each actual tool dispatcher (including cancellation and nested actuator paths),
and validate lost/late/cancelled samples on trace fixtures. Source-specific
SNN/scene/goal prospective hooks and authoritative skill decompilation remain
separate work. No live flags, deployments, restarts, state mutations or model
calls are performed by this candidate.

The pre-existing exact-site structure manifest needs a root-owned update for
`prediction.outcome`. This site is internal to the publish helper, unlike legacy
`_v2.emit` callsites; keep those two AST inventories explicit. Before that shared
fixture update, its builder-equality assertion is an expected integration failure,
not a claim that the full existing structure suite passes unchanged.

Validation on the scoped candidate: 189 tests passed in 5.85s in the serialized
768M sandbox (`phase8-runtime-20260929-d`), covering runtime/observer/curiosity,
sensory lifecycle/hub, event schema and event bus. The earlier structure run
was 84 passed / 1 failed solely at the unchanged exact-site manifest described
above (`phase8-runtime-20260929-c`). No executable code changed after validation.

Nested dispatch records pass `prediction_parent_ticket` to preserve canonical episodes while suppressing only the duplicate shadow PE. Exact issued ticket identities are weakly retained across disable/expiry/drain; constructed or copied ticket fields have no ownership. Parent records never project a terminal outcome. The outer wrapper alone supplies the measured completion or an explicit missing/cancelled terminal.
