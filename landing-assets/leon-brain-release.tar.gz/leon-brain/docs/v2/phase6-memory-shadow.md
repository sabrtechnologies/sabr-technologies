# Memory SHADOW cognition bridge

`brain.cognition.memory_shadow.MemoryShadow` owns one `MemoryRuntime`; it adds
no loop. Import and construction perform no I/O or worker creation. OFF stays
lazy. Configured and live `shadow`, `canary` and `on` all select **SHADOW only**.
Unknown modes, missing authorization, or a nonaccepting runtime fail closed.

Root integration (shared files are intentionally outside this candidate):

1. Attach after the actual autobiography/goals owners exist, under the runtime's
   lifecycle lock. Pass `state`, `configured_mode`, `live_mode`,
   `runtime_accepting`, `authorize`, and optional `telemetry` callbacks. Retain
   that exact wrapper until `stop()` returns true. `policy_revision` defaults
   to `legacy-shadow-v1`; changing source policy requires a new wrapper after
   the old one retires.
2. Call `tick()` from the existing cognition tick. Only this method imports the
   runtime, discovers actual existing handle paths, submits and polls. Default
   work per tick is at most two submissions and four polls; no blocking result
   waits. Canonical filesystem metadata calls can still be slow on a degraded
   filesystem. No such calls occur in the context/user response path.
3. Context calls only `offer(query, trace_id='') -> bool` and `stats() -> dict`.
   Both avoid source/flag/runtime callbacks and filesystem access. Offer uses
   tick-cached admission and a nonblocking mailbox lock. It returns false
   before first activation, when stopped, full or contended, or for invalid
   input. The query is limited to 4096 UTF-8 bytes, trace to 128 characters,
   and queue to 16 items by default (hard maximum 64). Queued queries are
   discarded when the tick observes OFF; none are submitted by that OFF tick.
4. Keep baseline context `rendered` and `components` unchanged. There is no
   context rendering, record rehydration or proposal text API here. Compare
   only cached content-free metadata in the root's shadow diagnostics.
5. `quiesce()` immediately cuts admission without waiting. On the runtime
   retirement path call `stop(join_timeout=.25) -> bool`. False means retain
   the wrapper and retry. True and `retired` prove its active tick and owned
   worker are drained. Runtime retirement must require both memory and
   sensory owners to retire.

The wrapper lazily creates exactly one `SourcePolicy(principal=None,
identity_id=None, authorize=authorize)` per wrapper. These explicit None values
mean unscoped legacy access, never a guessed principal or identity. The
existing SourcePolicy rejects principal/identity-bound records. Root must
inject its existing autobiography category/summary/source predicate; this
candidate does not broaden it. Authorization executes only on the retrieval
worker and must be bounded, without network or canonical write effects. Live
mode and runtime acceptance callbacks run only on the cognition tick and may
perform its controlled flag metadata checks. Telemetry also runs on that tick
and may write the root's bounded diagnostic sidecar; it must not synchronously
do network I/O. The clock must be pure and bounded. Offer/stats never invoke
the lifecycle, authorization or telemetry callbacks. Policy closure mutations
need a new owner/revision, not silent reuse.

Sidecar is explicitly `None`; embeddings and canonical writes remain disabled.
No default paths, canonical constructors, model calls, sidecar schema changes
or background backfills are introduced. Reference objects remain inside
MemoryRuntime and are counted transiently; no IDs, digests, paths, trace IDs,
queries, texts or arbitrary source strings enter wrapper stats or telemetry.

Telemetry callback gets exactly this fixed scalar shape, emitted only for a
completed/expired batch while still enabled:

```python
{"mode": "shadow", "scope": "unscoped_legacy", "completed": 1,
 "references": 2, "expired": 0, "metadata_only": True}
```

Errors increment a generic failure counter and cut admission; private exception
messages are never logged. A later tick closes/drains the retained runtime
before retrying. OFF/disable clears both pending tickets and queued requests,
calls owned `close(0)`, and retains a still-draining worker. Re-enable cannot
create a replacement until that worker exits. A telemetry callback admitted
before concurrent quiesce can finish; `stop()` stays false until that tick
finishes. No later tick batch is emitted after observed revocation.

Pending work is limited to eight tickets by default (hard maximum 32) with a
15-second monotonic request lifetime (maximum 60 seconds). Queued text is
released on submission, expiry, disable or stop. Pending stores only ticket
and deadline; the underlying runtime independently bounds reference caches
and revalidates canonical records. File/policy churn may cause a ticket to
expire without a result; it cannot authorize an action or alter context.

Tests use actual MemoryRuntime over disposable SQLite/JSONL fixtures and a
private import package, never brain/server startup or production stores.
Run on a VPS only through the serialized hardened sandbox launcher:

```sh
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase6 /opt/leon-v2-tools/test-results/phase6-memory-shadow-UNIQUE --mem 768M -- python3 -m pytest -q tests/test_memory_shadow.py tests/test_memory_runtime.py tests/test_memory_service.py tests/test_semantic_index.py
```

Shared lifecycle/context integration, canary acceptance, and any future trusted
principal binding remain root-owned live gates. This candidate performs no
deployment, feature-flag, state, service or authentication changes.
