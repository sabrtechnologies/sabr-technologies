# CLI text responder and explicit lifecycle

This candidate connects `BrainAPIResponder._respond_text_only` to the existing
verified `inference_cli_text` transport. Only an explicit `force_cli` request,
with no `force_api`, local-only or prefer-local selection, reaches this lane.
An absent/unverified runtime raises `UnsupportedInferencePolicy` terminally.
No legacy tool-enabled CLI, local/API retry, auth ping or paid fallback is added.
Existing local-only and forced-API routing remains intact.

## Conversation and completion ownership

The adapter uses `_build_messages` and `_brain_state_preamble` for current brain
state, memories, recent conversation and requested history. The new optional
`allow_tools=False` preamble changes only the capability paragraph. Existing
callers retain the default. User turns retain `_STABLE_SYSTEM`, the existing
user profile, active/warm context, model routing, augmentation and canonical
session correlation. Autonomous turns retain their existing daemon persona
choice. Role-labelled JSON preserves message boundaries; a turn-specific system
instruction states that tools/actions and fresh observations are unavailable.

Prompts are not silently truncated. The transport's 64 KiB system and 2 MiB
input limits still apply. CLI session persistence/resume is disabled: canonical
conversation history comes from Leon, not a second CLI history store.

The responder maps model/delta events into existing `StreamEvent`s and produces
sentences through the existing fence/speech filtering. A clean, consistent
terminal completion is required before history or `done`; auth failures,
unsupported output, stream close and cancellation do not complete the turn.
Cancellation is rechecked inside the history lock and after persistence before
yielding completion. The durable conversation pair is appended once per
completed turn whether or not the user-turn recorder owns the turn: the
recorder owns the post-turn bookkeeping (reward, concepts, autobiography) and
writes no conversation rows, so skipping the append for an owned turn left it
out of the durable history (corrected 2026-10-03). A per-call latch prevents a
duplicate terminal event from repeating the legacy write. These are per-call
guarantees; the legacy two-row append is not a crash-atomic exactly-once store.

## Root lifecycle hooks required

Root owns startup/shutdown wiring, runtime flags and any test-runner registry.
No automatic installation occurs on import or on a request.

1. At the safe explicit startup boundary, construct the exact final CLI child
   environment from the in-process environment builder, after any dotenv load;
   retain HOME/config/managed-policy settings. Use the chosen absolute CLI path
   and absolute working directory. The inherited one-shot path uses `/tmp`.
2. Optionally call `collect_auth_status(executable=..., cwd=..., env=...)` at this
   boundary. It verifies version/help and the auth help before bounded
   `auth status --json`. Each subprocess has a 10-second deadline, 256 KiB output
   cap and the existing process-group cleanup. It never invokes a model or
   login. The CLI's internal network I/O is not claimed to be absent.
3. Establish `SubscriptionEvidence` for that exact environment/cwd and effective
   policy. It requires authenticated subscription, disabled API-key helper,
   compatible managed policy, complete policy review, an opaque evidence receipt,
   a caller-selected finite expiry, and absolute provenance paths. Defaults are
   false. Neither `loggedIn=true`, installed CLI, key absence nor the diagnostic
   object satisfies this contract. Positive auth enums have not been observed
   here; unknown enums are returned as `unrecognized`, never accepted as proof.
4. Call `install(executable=..., cwd=..., env=..., evidence=...)` once. It checks
   evidence before bounded capability probes and binds the owner to file stamps,
   env and cwd. Failure leaves the lane unavailable/previous owner retained.
5. During shutdown, call `uninstall()`. A false result means owned streams must
   still close; retain the helper and retry at the existing drain boundary.
   `get_runtime().stats()` exposes only stopping/call/process counts/retired.
   No replacement is permitted before retirement. Scheduler admission and its
   per-call cancellation tokens remain the existing authority.

The helper tracks at most 32 active call receipts and identity-matched process
callbacks. It cancels owned tokens at retirement; the transport generator owns
final reaping. Consumers must close partially consumed generators. There is no
new scheduler, inference queue or brain-step owner.

## Effective-policy evidence checklist

This is an integrator review contract, not an automated audit. The actual
child's config directory, user, working directory, parent project/git roots,
managed sources and credential precedence must be resolved before attestation.
The helper does not read credential contents or execute configured helpers.

Review user `settings.json`, project `.claude/settings.json` and
`.claude/settings.local.json`, applicable checkout/starting-directory local
settings, and `~/.claude.json`. `CLAUDE_CONFIG_DIR` relocates the normal Claude
configuration directory. Review merged `env` as well as top-level settings;
higher-precedence policy may override the child environment. Explicit custom
settings inputs must also be included if an integrator later adds them.
[Settings reference](https://code.claude.com/docs/en/settings)

On this Linux installation, review `/etc/claude-code/managed-settings.json`,
`/etc/claude-code/managed-settings.d/*.json`, `/etc/claude-code/managed-mcp.json`
and any applicable organization-managed remote policy/cache or `policyHelper`.
Managed policy must remain effective; disabling it to admit this lane is not an
integration option. A remote policy source that cannot be fully established
keeps `policy_review_complete` false.
[Managed settings reference](https://code.claude.com/docs/en/managed-settings)

Review `apiKeyHelper`, provider/gateway selection, OAuth provenance, Linux
`.credentials.json` under the effective Claude config directory, and applicable
Anthropic profile/federation configuration (`~/.config/anthropic`, including
active selection/configs). Helpers and higher-priority credentials can take
precedence over subscription login. The adapter removes the inherited
`ANTHROPIC_API_KEY` as the existing responder does, rejects transport provider
overrides and refuses explicit `ANTHROPIC_PROFILE`, federation-rule,
organization and identity-token-file selectors. File-based selectors, managed
env and proxies still require review. OAuth env presence itself proves nothing.
[Authentication reference](https://code.claude.com/docs/en/authentication)

Include reviewed absent candidate files so later creation invalidates admission.
Include the managed drop-in directory to detect additions/removals, not only
currently present files. Up to 32 provenance paths are allowed; a directory
receipt covers at most 128 immediate regular files. Nested/nonregular entries
fail closed. File stamps include realpath, device/inode, size and nanosecond
mtime/ctime. Any change or expiry requires explicit lifecycle re-review; OAuth
refresh can therefore temporarily close this strict lane. This is a change
guard, not a lock against hostile concurrent configuration mutation or proof
that a remote policy stayed unchanged during a child invocation.

## Observed auth gate, 2026-09-29

Read-only installed CLI `2.1.278` help exposes `auth status --json`; its JSON
output and logged-in/not-logged-in exit convention are also documented.
[CLI reference](https://code.claude.com/docs/en/cli-reference)

Both the SSH environment and the service startup environment, with the legacy
CLI cwd `/tmp` and API-key removal, returned exit 1: `loggedIn=false`,
`authMethod=none`, `apiProvider=firstParty`. Observed additional field names/types
were `analyticsDisabled:bool`, `configDirectory:str`, `projectsDirectory:str`;
no subscription field appeared. Only sanitized status/schema was retained.

The running service was UID 0, cwd `/opt/leon-brain`, HOME `/root`, with
`CLAUDE_CONFIG_DIR` and `XDG_CONFIG_HOME` unset. Checked startup markers for
API key, auth token, base URL/custom headers, OAuth env token, helper TTL,
alternate provider flags and HTTP/HTTPS/ALL proxy were absent. `/proc` exposes
startup environment and may omit later Python dotenv changes. Therefore this
does not prove the current responder child has identical effective settings.

Live subscription acceptance remains an external credential/effective-policy
gate. No login, credential mutation, model request, production flag change,
restart or deployment was performed. The supplied metadata collector enables
bounded diagnostics at the correct lifecycle boundary; it intentionally cannot
turn an unobserved positive schema into subscription authority.

## Tests and limits

`test_inference_cli_responder.py` AST-loads the actual selected responder and
outer recorder/cancellation wrapper methods with fixture context/providers.
It tests exact context composition, event/sentence flow, terminal/history
ownership, overlap-safe lifecycle receipts, cancellation during completion,
policy changes, metadata redaction/refusal and real transport cleanup using a
Python fake child. Transport tests cover framing, tools/policy violations and
process-group bounds. No live authentication or model acceptance is implied.

Run only through the guarded VPS launcher; test data remains sandbox fixtures:

```
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase8 /opt/leon-v2-tools/test-results/phase3-cli-runtime-20260929-d --mem 768M -- python3 -m pytest -q tests/test_inference_cli_responder.py tests/test_inference_cli_text.py tests/test_inference_no_tools.py tests/test_inference_cancel_plumbing.py tests/test_user_turn_recorder.py
```

Final targeted result: **125 passed in 5.98 seconds**, four existing FastAPI
startup/shutdown deprecation warnings, launcher exit 0. The interleaved two-call
regression confirms that finishing the earlier call retains the successor's
registry entries and labels each legacy history pair with its own model.

Pre-change source captures/hashes are under
`C:/Users/pazzo/Desktop/leon-takeover/cli-responder-candidate/before/` and
`source_hashes.json`; shared source base is
`30db169cbca48624b7b0d7acdcd8c79f6bb95247`.
