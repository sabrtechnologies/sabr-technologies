# Phase 7 exact project-action grants

`task_policy.py` supplies durable authorization to the existing TaskWorker and
the narrow `task_project_actions.py` backend. It owns no authentication, model,
action execution, scheduler, brain step, event consumer or service lifecycle.
Importing it performs no I/O. No shared runtime/server files are changed.

## Exact public seam

```
context = TrustedTaskContext(
    principal=server_resolved_principal,
    task_id=task["task_id"],
    submission_id=task["idem_key"],
    authorization_revision=immutable_approval_revision,
    project_scope=task["project_scope"],
)
policy = TaskPolicy(absolute_operational_db,
                    resolve_context=trusted_submissions.lookup)
project = ProjectActions(reviewed_workspaces, authority=policy.authorize)
spec = project.canonical_resource_spec(action_name, finalized_arguments, task)
policy.create_grant(
    grant_ref=task["authorization_ref"], context=context,
    action_key=stable_step_key, spec=spec, tier=approved_tier,
    approval_ref=server_approval_receipt, expires_wall=explicit_expiry,
    limits=GrantLimits(max_dispatches=1, max_argument_bytes=16384, maximum_tier=3),
)
action = store.enqueue_action(
    task["task_id"], idempotency_key=stable_step_key, name=spec.name,
    arguments=dict(spec.arguments), resources=spec.resources,
    tier=approved_tier, expected_revision=task["revision"],
)
# Existing single TaskWorker: handlers=project.handlers, policy=project.policy.
```

This illustrates argument wiring, not an instruction to create live grants or
start workers. Root must perform it only at the explicit authorized lifecycle.
OFF and SHADOW must not create operational DBs, issue grants or start workers.
An explicit absolute operational path under the configured state owner is
required; never use a canonical memory/neural database or infer a path from cwd.

`resolve_context(task_id)` is mandatory and must return this module's frozen
`TrustedTaskContext` from an independently trusted, durable task-submission
registry. It must not reconstruct a principal from a grant UUID, task checkpoint,
model output, request-body `principal`/`approved`, or a legacy confirmation
boolean. Missing/invalid context denies issuance and authorization. A server
installation principal can be used only after the actual authentication layer
establishes it; this module does not guess who a shared API key represents.

`create_grant` is a trusted approval-service mutation. The caller must already
have established explicit authorization for the finalized canonical action.
An exact, unambiguous user request may itself supply that authorization where
the existing policy allows it; this library does not require a new modal for
every grant. `approval_ref` records the server's evidence; merely naming a UUID
or passing a nonempty reference does not establish authorization. Never expose
this method directly to a model or accept its context/approval fields from an
unvalidated network payload.

The task can be created with a stable server-issued reference before issuing
the grant; without a valid grant no action can dispatch. Persist the trusted
submission registration before issuance. Duplicate transport delivery must reuse
the same namespaced submission ID, grant reference and step key. Randomly making
a new approval/reference on retry defeats idempotency and is not supported.

## What is bound and checked

The adapter snapshots the backend's frozen `CanonicalResourceSpec` fields:
name, exact sorted string arguments, exact sorted resource tuple, minimum tier,
workspace scope, root device/inode identity, canonical input SHA-256 and complete
configuration SHA-256. It recomputes the compact/sorted JSON argument hash using
the backend's default ASCII escaping. Supported actions and minimum tiers are:

| Action | Exact arguments | Tier floor |
|---|---|---|
| `project.read_text` | `path` | 1 |
| `project.replace_text` | `path`, `expected_sha256`, `text` | 2 |
| `project.run_check` | `check` | 3 |

A grant additionally binds principal, task ID, namespaced task submission ID,
immutable authorization revision, step key, exact approved tier, approval
receipt, explicit expiry and limits. Authorization revision is distinct from
`TaskStore.revision`, which necessarily changes on enqueue, claim and completion.
Changing the trusted authorization revision invalidates the old grant. The
backend's configuration hash binds configured workspace/check settings and
shared resources; changing those invalidates admission. Path/check scope is the
exact finalized argument, not a wildcard or prefix grant.

Issuance is immutable: an identical reference/input returns the same reference;
different input conflicts. One task/step cannot receive a second grant by
changing only its reference. Revoked or expired grants retain their identity.
The policy returns literal `True` only for exact matching RUNNING task/action
snapshots with a valid TaskStore fingerprint, exact resource list, no requested
cancellation, valid task deadline and grant expiry, and a matching trusted
registration. Tier 4, malformed snapshots, changed arguments, configuration or
principal, missing policy and SQLite errors deny. The backend independently
validates resources and paths before dispatch.

## Atomic consumption and revocation boundary

The first pre-dispatch policy check atomically reserves the grant for one
`action_id`. A second distinct action cannot consume it, including through a
different grant. The handler cannot skip this pre-dispatch check. Repeated
identical checks are allowed because the backend checks at policy, handler entry
and immediately before `os.replace`/process spawn. Every check rereads the
trusted context and durable revocation/expiry and verifies the same binding.
After a dispatched check, an old undispatched snapshot is refused.

`receipt(...)["consumed"]` means the one-action authorization reservation was
made. It does not claim the action ran. `dispatch_seen` means the policy received
and validated a dispatched TaskStore snapshot, not that the external effect
completed. TaskStore owns attempts/results; a repeated policy success is **not**
permission to rerun a completed handler. Only its worker may invoke the backend
with fresh persisted snapshots. Direct calls with stale RUNNING dictionaries
are outside this installation contract.

`revoke(grant_ref, principal=trusted_principal, revocation_ref=...)` is durable,
irreversible and denies other principals without changing anything. Revocation
before the backend's final authority check denies the effect. Revocation or
expiry after that check cannot undo an operation already admitted or running.
The grant transaction, TaskStore dispatch commit and filesystem/subprocess
effect are distinct boundaries; no distributed exactly-once guarantee is
claimed. A reserved grant whose action was cancelled cannot be reassigned.
Task cancellation remains separate from speech cancellation and UI disconnect.

Wall expiry relies on the trusted host clock. Checks earlier than issuance or
the previous accepted check fail closed. This is not an independent trusted
time source. There are no refresh/renew, prune, reset, replay or automatic retry
APIs.

## Durability, limits and receipts

The SQLite ledger uses WAL, synchronous FULL, transactions and unique grant/
task-step/action bindings. Concurrent connections cannot consume one grant for
different actions. New files are created mode 0600; nonregular, symlink and
hardlink database aliases are refused. Existing DB configuration must match.
The integrator must place it in trusted storage and preserve the DB/WAL together;
these checks are not protection against an adversarial process with the same
OS identity.

Defaults are 2048 retained grants, 32 KiB grant payload, 16 KiB approved argument
JSON, one unique action per grant, and a maximum 24-hour grant lifetime. Explicit
configuration can reduce bounds; retained quota exhaustion rejects new grants.
Expiry/revocation never silently frees keys. SQLite lock waits are bounded to
200 ms; authorization errors return `False` and cannot select another executor.
Close the policy only after TaskWorker stops/drains; a closed policy denies.

`receipt(grant_ref, principal=trusted_principal)` returns authorized metadata
only, including task/action IDs, digest/resource bindings and consumption/
revocation flags. It returns `None` for another principal or an unknown grant.
It omits action arguments, replacement content and approval details. The ledger
itself retains exact private arguments needed for matching. This API protects
grant receipts only: root must also authorize access before calling the separate
TaskStore task/result/reconnect APIs.

Trusted configuration must establish that fixed checks run with the required
filesystem/network/process containment. A `containment_ref`, fixed argv or
process group alone is not a sandbox or permission. The policy binds reviewed
configuration; it does not independently audit the referenced containment.
Expected-hash replacement also requires the managed checkout's exclusive
cooperating-writer discipline. Existing legacy shell/CLI/desktop actions are
outside these grants.

## Smallest root integration slice

Read-only trace of root `eb99eb5e` found these concrete boundaries; this policy
candidate starts from newer `b1aa606f`, which also retains UNKNOWN resource fences.

* `runtime.py:_dispatch` and `route_shadow` currently call
  `ExecutiveController.plan_event(..., dry_run=True)`. Add an owned TaskRuntime
  attachment and a narrow task-admission method that resolves a durable proposal
  and this policy, then asks the **same executive** for an admission decision.
  Add a `GOAL_EVENT` task-proposal subtype with ID-only payload and trusted
  resolved context; leave unrelated event routing shadow-only. Do not globally
  flip `dry_run` or add a second executive/bus consumer.
* Admit only one exact authorized `project.run_check` first. The worker runs it
  outside provider iteration. The existing API responder dispatch at
  `_respond_streaming_core` currently calls local/actuator tools inline while
  retaining scheduler ownership. Do not detach arbitrary `tool_use` or CLI
  processes through this slice. Commit `81b9b8d6` already supplies the separate
  no-tools conversation path; no new responder edit is needed for one check.
* Before accepting task submissions, root must attach a server-established
  principal at the successful `server/__init__.py` auth boundary. Current auth
  validates an installation token but does not attach a principal. Current
  `_make_confirm_callback`/`_resolve_confirm` only carry transient booleans and
  cannot directly issue these grants. Introduce typed task submit/status/cancel
  ingress carrying client idempotency/cursor fields; resolve authority and exact
  configured scope on the server. Never use a network `approved=true` field.
* `server/routers/workspaces.py:get_workspaces` is a forever-session display tree,
  not the trusted execution registry. Use the backend's configured workspace
  registry and canonical inode resource identity; include trusted shared-repo/
  check resources where they can conflict. No arbitrary path from the dashboard
  becomes a configured root.
* Task admission returns its stable ID immediately. Existing WS `/chat` selection
  occurs before `_responder_lock`; scheduled conversation uses priority 100,
  direct no-tools admission. A priority-70 task action owns no inference slot or
  responder lock, so conversation can run while the check drains. Do not tie
  disconnect or `abort_response` to task cancellation. Do not add concurrent
  provider ownership to make this work.
* Drain bounded `pending_results` from the existing runtime tick, with a
  nonblocking/short-budget store adapter; TaskStore currently has blocking lock/
  SQLite paths unsuitable for an unbounded bus callback. Record a durable
  per-result executive consumption receipt before outbox acknowledgment, ideally
  atomically in that operational store. Current `checkpoint` rejects terminal
  FAILED/NEEDS_REVIEW tasks, so a result-consumption API must handle those states
  explicitly. Publish metadata-only TOOL_RESULT wakeups; failed notification is
  recovered by the durable outbox. Reconnect reads retained action receipts by
  task/cursor after principal checks. Do not duplicate legacy reward/memory
  effects until their owning APIs support idempotent action/result IDs.

Root still owns flag registration (default OFF/SHADOW), lifecycle/replacement,
authenticated ingress, trusted task-context persistence, executive admission,
result consumption and conversation integration. This file is an authorization
component, not completed runbook Phase 7 or demonstrated live concurrency.

## Validation

Tests use temporary ledgers, fixture principals/configuration and synthetic
actions. They cover restart/replay, exact input/resources/scope/revision binding,
concurrent atomic consumption, principal-restricted receipts/revocation,
post-policy expiry/revocation, bounds, alias/config refusal and fail-closed busy
stores. An actual TaskWorker/TaskStore test revokes after dispatch commit and
proves the handler's final authority check prevents its fixture effect.

Guarded final run on 2026-09-29: **107 passed in 1.14 seconds**, launcher exit 0:

```
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase8 /opt/leon-v2-tools/test-results/phase7-task-policy-20260929-b --mem 768M -- python3 -m pytest -q tests/test_task_policy.py tests/test_task_lifecycle.py tests/test_task_worker.py
```

Root integration must additionally test real backend + policy composition,
actual runtime/executive admission, an action blocked on a fixture event while
the existing conversation scheduler completes, reconnect/cursor replay,
outbox-loss windows and failed-stop replacement retention. No live grant,
authentication, external action or production state was exercised here.

Base/source-preservation receipt:
`C:/Users/pazzo/Desktop/leon-takeover/task-policy-candidate/before.json`.
The prior CLI candidate remains on `v2/phase3-cli-runtime` at
`81b9b8d6887f56e1a00fdbc78b324a2642be6793`.
