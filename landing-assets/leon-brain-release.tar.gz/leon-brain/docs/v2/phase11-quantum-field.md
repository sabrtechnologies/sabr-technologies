# Phase 11 development candidate

This is a default-OFF, signal-only quantum/counterfactual development candidate.
It does not establish quantum advantage, subjective experience, or consciousness.
No hardware job, deployment, live flag, restart, canonical-state mutation, or
dependency installation was performed during this recovery.

## Recovery and ownership

Recovered from `v2/phase11-quantum-field`, base
`f332c576dd83a17523ea93633d3d37ae72f498e3`. The pre-existing 30 interrupted
files were preserved byte-for-byte, including base versions of the five modified
tracked files, binary diff, modes, timestamps and SHA256 manifest. Individual
authorship of that interrupted work is unverified. The immutable local backup is
`C:/Users/pazzo/Desktop/leon-takeover/phase11-candidate-20260929/reference/interrupted-original.zip`;
the corresponding `original-manifest.json` records every original hash.

Only the new `brain/quantum_decision_field/` package, its tests and this document
belong to this candidate. These nine interrupted files remain dirty, unchanged,
and excluded from the scoped commit:

| Residual | Integrator disposition |
| --- | --- |
| `brain/global_workspace.py` | Useful provenance fix: count a selection as quantum only when the decision says so; root must reconcile against its workspace authority changes. |
| `run.py` | Shutdown `close()` hook; coordinate with the existing lifecycle owner. |
| `server/__init__.py` | Router registration plus duplicate shutdown hook; root should install one deliberate lifecycle path. |
| `server/init_brain.py` | OFF-gated construction and legacy facade injection. Does not yet provide the required dynamic candidate validator; authoritative mode must remain disabled. |
| `requirements.txt` | Interrupted comments claim verified library versions; those claims were not established by this recovery. |
| `requirements-quantum.lock` | Optional proposed pins, unverified. Do not install as part of recovery. |
| `server/routers/quantum_v2_routes.py` | Read-only status/recent endpoints; needs root's current authentication and route integration review. |
| `deploy/systemd/leon-qv2-diagnostic.service` | Proposed 100,000-shot Aer diagnostic with 1 GB cap, separate from this 768 MB test sandbox. No install/run approval. Its Python path and load/activity behavior need review. |
| `deploy/systemd/leon-qv2-diagnostic.timer` | Uninstalled proposed schedule; no activation. |

## Implemented behavior

The recovered facade retains its existing proportional baseline, exact positive
RY preparation, classical sampling, optional lazy Aer adapter, append-only V2
journals, local diagnostics, counterfactual analysis, quota ledger and inert IBM
experiment machinery. Legacy quantum modules and their journals are untouched.
Historical comments mentioning a numbered “spec” or previous observed results
are inherited design notes, not newly verified evidence.

The new `field.py` provides frozen `QuantumCandidate` and `QuantumDecisionV2`
records, plus `LocalPossibilityField(enabled=False)`. Candidates carry stable IDs,
labels, values, logits, phases, compact features and explicit risk. Unknown or
non-low risk rejects the entire request before policy evaluation, entropy, or
provider work. Optional caller authorization must return literal `True` for every
candidate. Results never authorize an action. Diagnostics have no chosen ID.

The field uses a softmax over finite logits, prepares complex amplitudes
`sqrt(p_i) * exp(i * phase_i)`, and pads to `2**ceil(log2(N))` with exact zero
amplitudes. Its optional Qiskit adapter uses `StatePreparation`. Invalid padded
measurements fail; they are never folded modulo N, retried, or replaced by a
hidden draw. Aer is labeled a classical simulator and may run only in a declared
experiment worker. The caller must bound that worker as a process because native
simulator work cannot be stopped by a Future timeout. This typed API does not
submit IBM jobs.

`ContextualBanditPolicy` is a bounded NumPy contextual reward predictor. Features
are caller-defined values scaled to [-1,1]; the field appends six explicit
channels (perception, memory, goals, reward, uncertainty and self_state). The
policy learns only from supplied observed task rewards or prediction errors on
explicitly verified non-safety-critical, low-risk decisions. Prediction error
also trains an auxiliary phase signal. Phases alone do not alter computational
basis probabilities; no interference or advantage is claimed. Snapshotting keeps
one decision's policy version consistent under concurrent training.

Policy persistence is opt-in, atomic, versioned `.npz`, without pickle. The
runbook's recommended sidecar is `brain_state/v2/quantum_policy.npz`; callers must
explicitly choose an approved path. Constructors/imports perform no I/O and never
load, overwrite, or migrate a legacy artifact.

`matched_comparison` retains the legacy distribution, learned local distribution,
identical matched-classical baseline, and any supplied Aer/IBM counts. Supplied
counts are labeled unverified external evidence. Missing hardware data and task
effects stay missing. Identical empirical distributions retain a descriptive
null; there is no fabricated counterfactual reward or significance claim.

Recovery fixes include malformed/negative/wrong-width measurement rejection,
entropy range validation, bounded provider output and request size, provider-child
cleanup on callback failure, closed-router refusal, late-result suppression after
close, and prevention of a second writer while the prior writer is stopping.
NaN/future activity timestamps no longer satisfy the quiet-machine diagnostic
gate; nonfinite quota values cannot authorize a submit. Policy array headers are
bounded before allocation, causal identifiers/expiry dates are validated, and
queued shadow evidence is detached from mutable legacy inputs. Record/shadow
queues have hard capacities; the causal audit queue refuses
new consumption at the preregistered maximum. No field output bypasses ActionGate.

## Integration and remaining live gates

1. Keep `LEON_QUANTUM_V2=off` and `LEON_QV2_CAUSAL=off`. Default imports and OFF
   construction do not load Qiskit, start workers or write V2 state.
2. Integrate `build_from_env(..., candidate_validator=...)` only through the
   root-owned lifecycle. Every new authoritative/guard/causal selection requires
   a dynamic callback validating the predeclared low-risk candidate set and
   returning literal `True`; a static ActionGate contract is insufficient. Refusal
   escapes before all emergency or legacy fallbacks. External actions still need
   the real ActionGate after ranking.
3. Shadow mode now returns the original legacy object without changing an IBM
   decision into classical entropy. Therefore shadow rollout requires the legacy
   engine's existing real-time hardware protections; shadow itself cannot provide
   both bit-for-bit legacy behavior and a new hardware bypass prohibition. The
   real-time IBM replacement guard operates only in explicitly enabled V2 mode,
   with candidate validation. Do not enable a legacy hardware source on a user
   thread while evaluating shadow.
4. Map real read-only state to the six compact field channels and candidate
   features. Training needs verified outcome linkage and safe reward semantics;
   no live training or state-to-consciousness interpretation is installed here.
   The typed field is an explicit API and does not silently replace the recovered
   proportional facade.
5. Physical experiments remain inert: `CAUSAL_SIGNER_FPR=None`, no allowed signer,
   no entry approvals, and no approved migration ledger entries were added.
   Existing reservoirs contain individual measurements from predeclared uniform
   circuits, not freshly prepared learned candidate circuits. Before any hardware
   causal trial, the integrator must bind candidate IDs/ordering and circuit hash
   to the preregistration and verify one physical shot per consumed choice, quota,
   source provenance, stop behavior and risk checks. Diagnostic many-shot results
   must never control actions. No hardware efficacy evidence exists from these tests.
6. The recovered background Aer executor uses a thread; its deadline falls back
   but cannot stop a hung native call. Hardware paths and native Aer lifecycle
   require separate process-level acceptance before activation. No claimed
   timeout guarantee extends beyond the tested fake child/worker boundaries.
7. Review status endpoint authorization and integrate provenance counters,
   scheduler/lifecycle hooks, shadow latency, continuity evidence and rollback
   evidence before any deployment. The phase is a scoped development candidate,
   not a claim of completed live migration.

## Validation

`tests/test_quantum_field.py` loads the package in an isolated namespace without
brain/server startup. It uses temporary state, local fake provider children, and
no network/SDK calls. Coverage includes N=3 padding, larger bounded candidate sets,
one-shot causal decisions, diagnostic non-selection, risk/authorization refusal,
policy learning and checkpoint reload, null/missing counterfactual evidence,
legacy shadow identity, writer close, and provider timeout/flood/callback cleanup.
On the VPS execute this file only through the serialized sandbox launcher with
768 MB. The final code sandbox run was
`/opt/leon-v2-tools/test-results/phase11-quantum-20260929-b`: **58 passed in 1.12s**.
This includes fake-QPU single-sample consumption, malformed checkpoint shape
rejection before allocation, quota/activity fail-closed checks and a fake Qiskit
StatePreparation wiring test. It does not establish installed Qiskit/Aer/IBM
compatibility or physical hardware outcomes. The first development run passed
43 tests; the additional review regressions increased the suite to 58.
