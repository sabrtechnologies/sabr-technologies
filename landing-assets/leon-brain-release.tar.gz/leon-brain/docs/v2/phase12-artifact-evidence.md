# Private development artifacts and the check-evidence boundary

`improvement_artifacts.py` captures a bounded, complete registered input tree and
derives a candidate from up to four exact UTF-8 replacements. It creates no files,
database, grant, process, model call, action queue or loop. Construction is cold
and selection defaults OFF. This candidate is not installed in the executive or
check service.

An operator-owned immutable registry resolves `DevelopmentBinding` by opaque
registration ID. It supplies the principal, proposal/parent identities, workspace
scope, canonical root path/device/inode/owner, configuration digest, development
isolation and artifact-authorization references, source revision, every input
file's path and mode, editable/protected paths, and fixed required check names.
The binding's source revision is an operator assertion; this module measures
bytes and does not infer Git provenance. Artifact authorization grants no action,
promotion or deployment permission. Models cannot supply a root to `capture`.

`ImprovementArtifacts(resolve_binding=..., enabled=...).capture(registration_id,
principal=..., replacements=(Replacement(path, content), ...))` reads the actual
registered tree using directory descriptors and no-follow opens. All ancestors
are checked for symlink traversal. Files must be regular, singly linked, on the
registered device, and owned/mode-matched; directories must be exclusively
managed. Every on-disk entry must match the full registered inventory or its
required parent directories. Unknown files, empty extra directories, missing
inputs, VCS metadata, symlinks, hardlinks, special files and mode changes refuse
capture. Use an already prepared bounded development input export: this module
does not provision, trim or modify a checkout to make it eligible.

The limits are 128 files, 64 subdirectories, depth eight, 64 KiB per source file,
2 MiB total source/candidate bytes, four replacements of at most 8 KiB each,
6 MiB private serialized artifact and two seconds for both input passes. The
first pass checks descriptor/path identity and metadata before/after each read;
the second compares all bytes, modes and observed inode/timestamp metadata. The
registry and admission are checked again before returning an artifact. All
inputs of the named check must be covered by this tree or separately pinned
read-only runtime/configuration dependencies; operator registration must establish
that contract. A test's dynamic imports are not guessed or silently omitted.

`PrivateArtifact.bundle` contains private base64 source bytes and exact before/
after replacement bytes. Store it only in reviewed private artifact storage.
`metadata()` returns bounded references, counts, changes and SHA256 values with
`check_evidence=False` and `executed=False`; it does not copy source bodies or tool
logs. The source and candidate tree digests cover a canonical sorted list of
directory paths/modes and file paths/modes/sizes/content hashes, including root
directory mode. The diff digest covers canonical sorted replacement objects with
the exact before/after bytes, preserving trailing newlines and encoding. This is
a byte-exact replacement document, not a lossy rendered unified diff. Root may
render a private review view separately without changing the approved digest.

`validate_bundle(binding, bytes)` is a pure consistency check: it re-derives every
inventory, replacement, candidate and digest, requiring the exact binding and
canonical encoding. It proves neither origin nor execution. A caller can create
an internally consistent blob; therefore an existing trusted registry must pin
the hash returned by the real authorized capture before using it for a reviewed
improvement registration. The adapter adds no database/TaskStore owner. Existing
TaskRuntime/TaskStore metadata should retain only that immutable reference and
hash; raw artifact bytes stay outside operational checkpoints.

The coordinated improvement evidence repair's `ImprovementRegistration.artifact_sha256` and
`CheckInputProof.artifact_sha256` must use this full `metadata()['artifact_sha256']`.
`binding_sha256` only hashes the trusted registration row and does not distinguish
different captured source/candidate contents under that row. It must not substitute
for the private bundle digest in check-source evidence or approval binding.

## Required execution-evidence integration

Double-read detection is not writer exclusion. It does not prove that content
remained unchanged between observations or after capture. `PrivateArtifact` is
never `CheckEvidence`, and a caller-supplied `passed` or source hash is never an
attestation.

The current `task_check_containment._bwrap_argv` mounts the general workspace
using writable `--bind`. `task_check_service.ExecutionBroker` durably binds an
action/task/canonical spec, but its request does not currently bind an improvement
artifact or immutable check-input snapshot. Current success/drain receipts cannot
establish the stronger improvement-source contract. No general check semantics
are changed by this candidate.

Root must coordinate a distinct check-service boundary before qualifying
improvement evidence: authenticate the exact approved child attempt and artifact
hash; construct or open a separately verified complete immutable input snapshot;
measure its expected source/candidate inventory immediately before execution;
enforce read-only inputs and exclude external mutation until all descendants and
the namespace/cgroup have drained; retain the same-attempt snapshot identity,
configuration/approval/request identities, completion inventory and drain proof
in the existing durable service receipt. Checks needing outputs require separate
bounded writable scratch space which cannot alias inputs. Host-side read-only
binds alone do not stop outside writers to the underlying files.

Only the trusted receipt adapter may then produce improvement `CheckEvidence`,
after verifying the parent TaskStore action receipt and immutable ingress/approval
registration. Missing exclusion proof, changed inventory, uncertain drain or an
ambiguous attempt must remain unavailable/UNKNOWN, never be reconstructed from
a green result or identical pre/post hashes. The independent pipeline repair
requires this stronger execution proof; this artifact module grants none of it.

## Validation

Tests exercise real temporary input files, descriptor traversal, complete-input
rejection, mutation detection, bounds, exact diff/content binding, cross-parent
substitution, OFF/quiesce and pure validation. They must run only through the
unchanged serialized sandbox launcher with 768M. No model, check subprocess,
production store or service is invoked by these tests.

Validation on isolated branch `v2/phase12-improvement-artifacts`, based on
`6f7b7dc6f5380d3c1d7c40a8160456e89b107f91`:

- `/opt/leon-v2-tools/test-results/improvement-artifacts-20260930-c`:
  **33 passed in 0.10s** in a fresh test process through the unchanged 768M launcher.
- The preceding run detected a fixture assertion expecting a later root-identity
  rejection; the implementation already refused the root rename through its
  earlier directory-change check. The assertion now accepts either safe refusal.

The original improvement-core branch remains unchanged. No shared service files,
production state, flags, running services or host provisioning were changed.
