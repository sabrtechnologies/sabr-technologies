# Existing V2 owner retirement at process shutdown

The FastAPI shutdown hook and `run.py` signal handler now call the same
`begin_shutdown(state, timeout_s=5.0)` coordinator before persistence. It captures
the current cognitive runtime, scheduler facade, scheduler and shadow ledger.
Repeated calls reuse the retained session; a changed owner is refused. It builds
no runtime, model, task pool, database, action queue or inference request.

One finite daemon helper invokes the existing runtime stop methods off the ASGI
and signal threads. It first requests quiescence of the runtime's task/planner, provider and
other attached owners, then retires the scheduler facade and retries runtime
retirement in short slices under one monotonic five-second deadline. The facade
keeps its ledger until the captured scheduler worker drains. Provider callbacks
remain installed until that exact scheduler cannot dispatch again. TaskRuntime
retains its store/policy while an active planner call or committed worker drains.
No shutdown code acknowledges outbox results or changes task/action outcomes.

Returning from `begin_shutdown` means retirement was requested, not that
admission is synchronously fenced. If the helper has not run or the runtime's
owned lock is blocked, its stopping bit may not yet be set. Such a session is
`PENDING`; the caller must not treat it as proven quiescence. A real runtime-lock
fixture tests this boundary. No parallel admission flag or replacement owner is
introduced to bypass the existing ownership protocol.

Scheduler identity inspection and `uninstall` share the existing facade
`_LIFECYCLE` lock. A successor scheduler, ledger or runtime is never selected for
retirement by an older session. Captured state references are not cleared by this
coordinator. Existing facade methods may clear their own references after actual
drain; a call already blocked inside that code can finish after the caller's
budget. This is not a promise that all owner internals stop at the deadline.

`wait()` and `wait_async()` are strictly bounded caller waits. Blocking owner
methods remain on the single retained daemon helper; they never migrate back to
the caller or spawn another owner. If an owner call blocks beyond the deadline,
the receipt is `PENDING`, names only bounded subsystem metadata, and reports that
the helper is still alive. It must not be treated as a clean drain or permission
to replace an owner. `COMPLETE` requires the captured runtime's actual
`retirement_complete()` plus the facade's actual scheduler/ledger retirement.
Legacy threads outside those registered owners are not covered by that receipt.

## Signal and persistence budget

The installed service was inspected read-only: its stop signal is SIGUSR1 and its
systemd stop timeout is 90 seconds. That signal bypasses FastAPI and uses an
existing 15-second process dead-man in `run.py`; this candidate changes neither
the unit nor the dead-man limit. V2 retirement overlaps existing persistence
instead of consuming a new five seconds before the saves. The final signal wait
is limited to the original retirement deadline and at most 12 seconds from signal
entry, leaving three seconds before the unchanged dead-man.

When any V2 owner is captured, or its identity cannot be established, optional
final distillation and the eight-second final thought are skipped. Distillation
can invoke housekeeping inference and an opted-in CLI fallback; it must not
start a new model call after quiescence. The journal/recap compressor is offline
and remains enabled. Previously recorded canonical state and existing save calls
are retained. Save success/failure is logged separately;
neither a V2 completion receipt nor the dead-man claims canonical persistence
succeeded. If process exit interrupts an attempt, its existing durable STARTED /
RUNNING recovery and UNKNOWN resource fence remain authoritative. No automatic
replay, reconciliation, process kill or new approval is introduced.

ASGI shutdown also starts early and asynchronously waits for the same bounded
receipt after its existing sensor cleanup, including when sensor cleanup raises.
Body mode still skips canonical saves while retiring any installed V2 owner.
This change does not make existing persistence/sensor implementations themselves
interruptible or certify arbitrary legacy shutdown hooks as bounded.

## Isolated validation

Tests use synthetic fixtures only: the actual scheduler and shadow ledger with
a delayed foreground tool result; actual installed TaskRuntime/PlannerRuntime
with an in-flight synthetic model call; successor identity drift, missing facade,
repeated shutdown, stop exceptions, an intentionally blocked stop, and event-loop
progress during the bounded async wait. AST-extracted server and signal handlers
verify ordering without importing the canonical server or sending signals.
The signal fixture never runs a real dead-man or process exit. All app imports
and tests run through the unchanged serialized 768M sandbox launcher.

The final focused run passed **116 tests in 10.14 seconds** across shutdown,
installed planner runtime, service hooks, inference scheduler and shadow ledger.
Receipt: `/opt/leon-v2-tools/test-results/runtime-shutdown-tests-20260930c/tests.xml`.
The extra committed-effect fixture initially returned a nested mapping rather
than TaskWorker's declared top-level `ok` contract; the worker correctly retained
UNKNOWN. The fixture now uses the actual return contract and outbox schema.
Both successful and uncertain results are reopened from the durable test store
after retirement, without replay or result acknowledgment. Source backups and
exact candidate hashes are under
`/opt/leon-v2-tools/test-results/runtime-shutdown-stage-20260930`.

No live service, host unit, production state, flags or provisioning are changed.
