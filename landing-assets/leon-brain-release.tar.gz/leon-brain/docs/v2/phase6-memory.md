# Phase 6 memory service candidate

The existing six memory stores remain canonical. These new modules do not wire
themselves into runtime, change flags, start workers, load a brain, or create
canonical stores. Default mode is `shadow`; embedding execution is separately
disabled unless explicitly requested. This is a development candidate, not a
completed production migration.

## Integration

The integrator should construct adapters from the live instances' actual paths:
`SQLiteAdapter('knowledge', knowledge.db_path, writer=knowledge)`, equivalent
`episodes`, `graph`, and `skills` adapters using `.path`,
`AutobiographyAdapter(autobiography._path, writer=autobiography)`, and
`GoalsAdapter(goals._path, writer=goals)`. `canonical_adapters(state_dir,
skills_path=..., writers=...)` is also available for explicit file discovery.
Skills normally lives in `~/.leon/skills.db`; it must be supplied explicitly.
Missing sources are skipped by discovery, never initialized. Read-only adapters
do not call constructors, mutating semantic reads, goal cache refreshes, or tools.

Construct `SemanticIndex(state_dir / 'v2/semantic_index.sqlite',
canonical_paths=[a.path for a in adapters], enable_embeddings=False)` and pass it
to `MemoryService(adapters, index, mode='shadow', policy=..., shadow_log=...)`.
The writer instances are used only by explicitly enabled ON-mode calls.
Integrate `retrieve()` at the canonical context builder; `remember()` at new V2
memory producers; `reinforce()` only after a verified skill outcome; and
`record_outcome(trace_id, verified_success=...)` at the later task-result hook.
Context, server, cognition and store changes belong to the integrator.

`SourcePolicy` is configured from trusted integration policy. Registering a store
grants read access to its historical unscoped rows. `allowed_sources` is an
optional allowlist; denied sources, malformed metadata, revocations, mismatched
owner/principal/identity IDs, and nonmatching `allowed_principals` are rejected.
A source string does not authenticate a principal. Authority defaults to zero
unless explicitly configured, and machine captions are marked unverified and
capped at .1 authority. Supply an additional `authorize(record)` predicate where
the deployment has stronger source rules. Backfill and retrieval use the same
policy. Every indexed result is rehydrated and reauthorized before reranking.

## Retrieval and writes

The service collects canonical lexical/FTS candidates and semantic top-50,
unions by `(store, record_id)`, and provides every score component and fixed
weight in the returned `MemoryHit`. The weights are .50 semantic, .20 lexical,
.10 authority, .08 salience, .07 recency and .05 state match. Components lie in
0..1. Semantic similarity is nonnegative cosine, lexical is token coverage,
recency decays over 30 days, and state is optional cosine. The legacy 18-D neural
fingerprint can only enter the separate state feature. It is never embedded as
meaning. SHADOW returns the canonical lexical results and logs proposed V2
results, overlap, latency and trace ID, without logging query or memory text.
With no usable semantic candidates, ON preserves lexical order too.

The lexical compatibility path uses the canonical KnowledgeStore FTS table and
bounded lexical adapters for the other stores. It does not claim to reproduce
every context-builder or graph-neighbor policy in existing callers. The index
also contains rebuildable FTS text for full indexed history. Its results are
used for the V2 comparison/rerank only and always rehydrated. Unindexed JSONL
lexical fallback examines at most the last 1 MiB; full history is streamed by
backfill. Graph entities are indexed by canonical entity ID; edges/episode links
remain in GraphMemory and are not duplicated as independent memory records.

Writes route through the existing KnowledgeStore.store, EpisodeStore.record,
GraphMemory.entity_get_or_create, Autobiography.record, GoalSystem.add, or approved
SkillMemory.add_from_chain APIs. Episode writes require actual prediction,
context and action fields; procedural writes require explicit approved steps.
Unsupported per-row ACL fields are rejected for stores unable to persist them.
Autobiography/goal writes are reread because those legacy APIs can swallow disk
errors. Autobiography references are byte-offset plus full-line SHA-256, since
the canonical file has no IDs. Goal IDs and all existing SQLite IDs are retained.
If a sidecar update fails after a canonical write, the receipt reports
`canonical_written=True, indexed=False`; never retry that canonical write.
Backfill can repair its reference. The existing GoalSystem has no cross-writer
lock and can retire goals as part of its source-specific caps; integrators must
serialize new goal writes with existing writers before enabling them.

Only SkillMemory provides the dedicated safe single-record reinforcement API
used here. Knowledge/graph strength is not updated with invented SQL or by
calling mutating searches. Graph chain reinforcement requires explicit verified
entity-chain integration. Consolidation requires caller-verified canonical
evidence and makes an ordinary explicit canonical write; it never rewrites an
identity record autonomously.

## Sidecar and backfill

The sidecar is SQLite WAL with a 2-second busy timeout, schema validation,
documents keyed by canonical store/ID, per-model float32 embeddings, optional
separate state vectors, rebuildable FTS text, and per-store cursors in `meta`.
Deleting/rebuilding it cannot delete canonical records. Embeddings are loaded
lazily on CPU from an already cached model only, with `local_files_only=True`
and `trust_remote_code=False`. The default model is
`sentence-transformers/all-MiniLM-L6-v2` (384 dimensions); `LEON_EMBED_MODEL` or a
constructor/CLI override selects another local model. Older libraries lacking
the offline argument fail closed. Missing packages/models and invalid vectors
leave the canonical lexical path usable. No download is attempted.

`tools/v2/memory_backfill.py` accepts explicit `--state-dir`, `--skills-path` and
`--sidecar` paths, with default 25-row pages, 120 rows/minute, 10% CPU duty,
500 rows and 60 seconds per run. It lowers its own POSIX priority. Every canonical
DB read uses a short read-only connection and a query deadline. Encoding happens
after that connection closes. Rate is paced per row and CPU duty between rows;
an individual local embedding call is not interruptible, so external resource
limits remain required. A cursor is saved after a complete page. Interrupted
pages are replayed idempotently; completed passes reset the cursor so later
passes find edited records and new IDs behind earlier cursors. A malformed JSONL
line is skipped without modifying it; incomplete final lines are retried, and
oversize lines/files fail visibly. Stable deleted references are rejected during
retrieval and removed by a sidecar rebuild.

Semantic search streams 512-vector pages and optionally accelerates cosine
scoring with NumPy. It caps the corpus at a configurable 250,000 model-compatible
vectors and reports capacity exhaustion rather than searching only a prefix.
This is exact search, not an ANN index. Corpus-scale warm latency and RSS must be
measured before enabling semantic retrieval; p95 below 150 ms is not yet proven.

## Validation and remaining live gates

Run fixture tests only through the dedicated VPS sandbox launcher. They load
individual canonical modules by path, create every canonical store in pytest's
temporary directory, and never import server/brain startup. Tests cover real
adapters/writers, canonical file hashes across repeated/rebuilt backfill,
authorization/identity rejection, stale/deleted sources, synonym retrieval,
shadow behavior, missing models/no download, state/meaning separation, bounded
cursors/rate/CPU/interruption, and write-failure receipts.

Before rollout: reconcile deployed store paths/schema and source policy; capture
continuity hashes and counts; verify restore/rollback and sidecar-only rebuild;
rehearse representative read-only backfill under host resource limits; measure
warm p95/RSS and compare wrong-identity/false-memory regressions; then wire and
observe SHADOW with later verified outcomes. Any ON-mode enablement, model-cache
provisioning, real backfill, background scheduling, flag changes, restart or
deployment is outside this candidate. No production state was modified by its
implementation/tests.
