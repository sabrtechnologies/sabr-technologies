# Phase 4 procedural router and local command spotter

This development change implements runbook section 8. Runtime integration and
live acceptance remain separate gates. No production service, feature flag,
canonical learned store, or deployment is changed. The router defaults to `off`;
the existing reflex entry point remains legacy until explicitly configured.

## Implemented behavior

- `ProceduralRouter` projects the existing built-in regex handlers, learned
  reflex JSON, and an existing `SkillMemory` instance into stable Procedure IDs.
  Source refresh is read-only and idempotent. A malformed/disappeared previously
  loaded source retains its last good projection and records `source_errors`.
- `SkillMemory.procedural_snapshot()` reads all rows without its public query
  limit, mining, invocation reinforcement, or schema changes. Deprecated rows
  survive projection but require the explicit `allow_deprecated` precondition.
- Built-ins preserve their existing tool/argument and successful reply behavior.
  Follow-up commands reuse the preceding successful built-in plan and recheck
  policy. `reflex_learning.log_success` and both learned files are unchanged;
  refresh imports newly promoted records instead of introducing another motor
  execution path in `on` mode.
- Learned templates never silently discard arguments. Missing strings and skill
  placeholders require explicit bindings, keyed by step index and argument name.
  Legacy numeric `delta` templates require a binding because the old template
  discarded the direction. Invalid/out-of-range arguments fail closed.
- `shadow` emits predictions and never dispatches. The compatibility wrapper
  then lets the existing legacy path execute once for parity observation.
  `on` delegates to the router and never falls back into the legacy learned
  executor. Receipt/storage exceptions in this wrapper produce an uncertainty
  response rather than invite another executor to repeat the same action.
- Risk floors derive from actual tool names and arguments. Unknown tools and
  arbitrary hotkeys require R3 authorization. R2 always waits for final text
  and an executive gate; R3 additionally requires explicit confirmation. Imported
  learned/skill procedures are at least R2, regardless of historical counts.
- R0 partials need confidence >= 0.99; R1 partials need confidence >= 0.995 and
  `reversible=True`. Both need wake context or an explicitly supplied voice-policy
  authorization. All steps are gated before the first action. Only `tool_ok`
  verification with expected `{"ok": true}` is currently executable; other
  verification policies block. Rollback specifications remain descriptive and
  are never automatically executed without a separate policy-controlled action.

Known built-ins take precedence over fuzzy learned patterns. Negated, unresolved,
ambiguous, or unsafe partials wait. This deliberately tightens legacy learned
matching: an exact example or all required keywords (at least two) is necessary.
It does not remove the original learned data.

## Local voice lane

`VoskCommandRecognizer` reuses an already loaded local Vosk model. It receives
mono 16-bit 16000 Hz PCM chunks of at most one second; it neither downloads a
model nor sends partial audio to a cloud service. Its versioned finite grammar
comes from safe router triggers, excludes ambiguous phrases, and includes
`[unk]`. Volume aliases cover spoken numbers in steps of five from zero to one
hundred and map to the same numeric parameters as final digit transcripts.

`CommandSpotter` requires two consecutive matching partial hypotheses with the
minimum reported word confidence above threshold. Missing/non-finite confidence,
ambiguity, confidence drops, and grammar changes reset/wait safely. An endpoint
from the small grammar recognizer is not full-STT final text and does not replace
the two-partial requirement. Old Vosk versions lacking partial word confidence
will safely wait for the normal full-STT route.

Use one shared router/spotter per voice lane. Preserve the same `trace_id` and
`utterance_id` through every PCM partial, full transcript, and final command
consumer. The action latch claims the entire utterance before dispatch, including
failed or uncertain attempts, so a changed final command cannot dispatch again.
Full STT must keep running alongside the spotter.

## Concrete integration contract (root-owned hooks)

Construct handles only at the existing composition root, using its existing skill
instance, action bridge, executive/confirmation policy, and event infrastructure:

```python
ledger = SQLiteUtteranceLedger(reviewed_derived_receipt_path)
router = ProceduralRouter.from_existing(
    skill_memory=existing_skill_memory,
    mode="shadow",  # off is constructor default; on requires acceptance gates
    ledger=ledger,
    dispatch=existing_synchronous_action_adapter,
    action_gate=existing_policy_adapter,
    emit=durable_event_adapter,
)
recognizer = VoskCommandRecognizer(existing_vosk_model, router.safe_grammar())
spotter = CommandSpotter(router, recognizer=recognizer)
configure_procedural_router(router)
```

The action adapter accepts `(tool, args)` and returns a dict with boolean `ok`.
The policy adapter accepts `(Procedure, ActionStep, context)` and returns
`GateDecision(allowed=..., confirmed=...)`; arbitrary truthy objects cannot grant
permission. It must preserve the existing R2 executive decision and R3 explicit
confirmation policy. These interfaces are synchronous: do not pass an async
function without an explicit adapter. The event adapter accepts `(kind, payload)`
and returns `False` or raises when durable acceptance fails. A normal return
acknowledges delivery. It must deduplicate stable `payload["event_id"]` values.

1. After wake detection, call `spotter.begin(trace_id=..., utterance_id=...,
   wake_context=True)`. Supply `always_on_authorized=True` only from existing
   voice policy. Fan PCM frames to `spotter.feed_pcm()` alongside normal STT.
   Missing recognizer/low confidence leaves the full-STT pipeline functioning.
2. On full STT, call `spotter.final_text(text, trace_id=..., utterance_id=...)`.
   This persists and emits `VOICE_FINAL`, including `already_executed`,
   `suppress_procedural`, and comparison to the final interpretation. When
   `suppress_procedural` is true, retain normal cognition/episode handling but
   skip every second command executor, including `_maybe_command_action`.
   Otherwise continue the existing final action-gate pipeline with the same IDs.
   `final_text` itself never executes an action.
3. Pass the same IDs to `try_reflex` or `router.route` in final consumers.
   The legacy wrapper's generated UUID fallback is for callers without a voice
   utterance; it cannot establish cross-consumer voice idempotency.
4. Retain `_COMMAND_INTENTS/_maybe_command_action` for shadow comparison during
   the required release. Compare their predicted plans without executing a
   second action. Their macro/browser/system commands are not silently imported
   here; root owns their policy-aware migration and parity checks.
5. Route `REFLEX_RESULT`, `TOOL_RESULT`, and `EFFERENCE_COPY` to the existing
   episode/autobiographical/action-feedback consumers. Each carries intent,
   parameters, expected and actual outcome, confidence, latency, and trace IDs.
   Tool outputs are reduced to success/error-type summaries, without copying
   screenshot/audio payloads. At this base, the event enum contains REFLEX_RESULT,
   TOOL_RESULT, and VOICE_FINAL but lacks EFFERENCE_COPY and PROCEDURE_PREDICTED.
   Root must add or explicitly bridge those two names before cutover.

## Durable receipts and recovery

The default `UtteranceLedger` is process-local and appropriate for tests/shadow.
`SQLiteUtteranceLedger(path)` has no canonical-state default and creates only its
two receipt tables at an explicitly selected derived-store path. It commits the
running action claim before dispatch with SQLite synchronous FULL. A crash after
the physical action but before completion leaves an uncertain/running receipt;
it must never automatically replay the action. This is at-most-once dispatch
attempts, not an atomic guarantee about physical effects.

Action feedback remains pending until acknowledged. Full final text is committed
in a separate durable outbox before VOICE_FINAL emission, including utterances
with no early action. That namespace does not consume the action latch or block
the normal final route. The first final payload wins; replayed/changed finals
cannot overwrite it. A retained final also blocks later partial action claims.

On startup or sink recovery, inspect `ledger.pending_feedback()`:

- `kind="action"`: call `router.retry_feedback(trace_id=..., utterance_id=...)`.
- `kind="voice_final"`: call `spotter.retry_final_feedback(...)`; no `begin` or
  recognizer state is needed, and it cannot dispatch.
- `kind="uncertain_action"`: retain for explicit reconciliation; never replay.

The recovery inventory contains IDs/kinds only. Retries after a crash between
sink delivery and acknowledgment can redeliver the same stable event ID; sink
deduplication is required. If persistence fails, surface that failure and prevent
an alternate motor path from retrying an uncertain action.

Capacity exhaustion fails closed and never evicts another utterance. Retirement
is an explicit producer acknowledgment, never an elapsed-time cleanup. Only call
`spotter.retire(...)` after every partial/final producer guarantees it cannot
replay that utterance. It refuses running actions, pending action feedback, or
undelivered final feedback and atomically retires both namespaces. IDs must never
be reused. Pure text-only action receipts may use `ledger.retire(...)` under the
same producer guarantee. Store retention/access must follow the existing policy
because final receipts include the user's final transcript and action arguments.

## Validation and remaining gates

Tests load the actual module bodies with fake package boundaries and scratch
SQLite/JSON stores. They cover built-in action/reply parity, read-only idempotent
imports, more than 100 skills, policy floors, confidence/wake/stability gates,
finite Vosk grammar, early synthetic dispatch, in-flight duplicate prevention,
failure latching, cross-connection claims, restart recovery, outbox retry, changed
final text, and explicit retirement.

The isolated launcher must be used for every VPS test:

```text
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase4 /opt/leon-v2-tools/test-results/<unique-name> --mem 768M -- python3 -m pytest -q tests/test_procedural_router_parity.py tests/test_command_spotter_latch.py
```

Final run `phase4-procedural-20260929-d` passed 68 tests in 1.69 s, including
spoken-number and retained-final partial-claim coverage. These tests use a fake Vosk engine
and deterministic timing; they do not establish acoustic calibration or live
latency. Before enabling `on`, root must validate real model confidence output,
measure median actuator dispatch before full-STT completion, prove one execution
through actual voice/final/server consumers, and verify fast-action/final events
reach episode and autobiographical stores. Keep shadow/off until those gates pass.

## Source preservation

Base commit: `9f070d26eeec4b53ed35905fe2878fb1e06f93bc`, development branch
`v2/phase4-procedural`, worktree `/opt/leon-v2-worktrees/phase4`.
Before copies are preserved under the local Phase 4 candidate `before/` directory;
the original versions also remain in the base Git commit. SHA256 before editing:

| File | SHA256 |
| --- | --- |
| brain/reflexes.py | bc80894608330e9fd3d28e62130980d99d075c1bdf65b6c899a5d4886c1b854d |
| brain/reflex_learning.py (unchanged) | cfa56cbdafe8ff80e70ca5303365a48f4975113fc04ea52ac80868d06aaf51b2 |
| brain/cognition/skills.py | a2b58bbe72a1897d65b49a5e61c03da3263ae054567a9dcabe8d3e4ba35d2baa |

Rollback of integration is `configure_procedural_router(None)` plus removal of
the root-owned PCM hook; the original learned stores remain authoritative.
