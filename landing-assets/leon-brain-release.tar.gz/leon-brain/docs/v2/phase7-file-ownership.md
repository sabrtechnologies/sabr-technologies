# Atomic replacement ownership

`project.replace_text` now copies the existing file's UID and GID to its temporary
replacement inode before setting the original mode and syncing the file. It skips
`fchown` when ownership already matches, so same-owner replacement needs no chown
privilege. If ownership cannot be preserved or verified, the target is not renamed;
the temporary file must still be cleaned up successfully to report known failure.
No workspace-wide chmod/chown or ownership migration is performed.

After the final authority callback, the backend rereads the target and checks its
content, device/inode, owner, group, full mode, link count, size and modification/
change timestamps. It also checks the temporary inode and permissions before
rename. A successful rename is followed by directory fsync and checks of the new
content, inode, UID, GID and mode. Missing proof after a rename attempt yields
UNKNOWN, retaining the task's existing uncertainty fence and prohibiting replay.

This remains a managed-workspace operation: the task resource lock and exclusion
of uncoordinated writers are required. Filesystem pathname replacement is not an
atomic compare-and-swap against a hostile writer between the final check and
rename. Extended attributes, ACLs and other inode attributes are not copied by
this backend; UID/GID/mode preservation does not claim their preservation.

Tests use temporary synthetic files only. Same-owner replacement, rejected owner
copy, ineffective owner copy, metadata drift before/after rename and cleanup are
covered without adding capabilities. A separate real cross-UID/GID private-file
fixture explicitly skips when the unchanged hardened launcher cannot chown or
read that fixture. A skip is not evidence of live cross-UID deployment readiness.

The unchanged serialized launcher ran project-action, lifecycle, worker and
containment tests: **108 passed, 2 skipped**. The skips were the actual cross-UID
ownership fixture and the existing nested-user-namespace containment fixture.
No test capability, host ownership, service or workspace provisioning was changed.

Receipt: `/opt/leon-v2-tools/test-results/file-ownership-tests-20260929a/tests.xml`,
SHA256 `ee1963c1d201f6089fd6d2804790197d9438fa546d252e80d830e4a855cc620a`.
The adjacent `tested-source.sha256` manifest has SHA256
`04f0d2fd9a4ad541357aa158b1915d928fa7ac8c60c4879842b9517e036747e5`.
The isolated check service pins this backend's source, so integration must use
the updated immutable source manifest in both parent and service configuration.
