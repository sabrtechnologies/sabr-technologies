# Phase 7 authenticated task ingress

This candidate adds four bounded HTTP endpoints for the existing task runtime.
It performs no installation, enables no flags, starts no jobs on import, and
does not introduce a task executor or a second executive. The server's existing
authentication still validates the configured key before any task identity is
attached. None of these routes is exempt from that middleware.

## Installation seam

After server authentication is initialized, root startup must call
`server.installation_principal()` and pass the returned string as the trusted
`installation_principal` to `TaskRuntime`. Attach that runtime to
`server.state.task_runtime` and the same object to the existing
`server.state.cognition.executive._task_runtime`. The existing executive must
expose these synchronous keyword methods:

```python
preview_project_check(*, principal, scope, check)
submit_project_check(*, principal, scope, check, idempotency_key,
                     approval_sha256, approved)
```

The executive delegates to its installed runtime's `preview_check` and
`submit_approved_check`, respectively. Routes require that both owners refer to
the same runtime; absent/stale wiring yields 503. Root owns these lifecycle and
executive changes. Read/cancel call the installed runtime's `task` and `cancel`
with the authenticated principal; those runtime methods must continue enforcing
their durable per-task ownership checks before returning metadata or results.

Identity is `installation:v1:` followed by SHA256 of the domain separator
`leon.installation-principal.v1\0` and the server's canonical lowercased configured
key, encoded as UTF-8. This deliberately matches existing case-insensitive
credential validation. It identifies one installation credential, not an
individual human. Rotating the credential changes identity and does not transfer
old grants or task access. No raw key is returned or logged by this change.

Successful auth installs an in-process marker and canonical principal in ASGI
scope state. The route accessor checks marker identity plus the canonical
principal. A request field, a state label, or a boolean `verified` flag cannot
create that context. Auth clears stale identity before failed or exempt paths,
including WebSocket paths. The accessor fails closed if middleware is bypassed.

## HTTP contract

All runtime/SQLite calls run in ordinary synchronous route functions, dispatched
by FastAPI's threadpool. Only bounded body reads and decoding dependencies are
async. Body and raw query are each limited to 4096 bytes. Actual streamed size is
checked independently of Content-Length. JSON requires application/json,
rejects duplicate keys/non-finite values/invalid UTF-8, and is never echoed in
errors. Extra or repeated query fields are rejected. The existing reserved
authentication query field `key` is permitted but never forwarded to task APIs;
Bearer authentication avoids putting credentials in URLs.

| Endpoint | Accepted task fields | Owner |
| --- | --- | --- |
| GET `/api/v2/tasks/check-preview` | query `scope`, `check`; no body | executive preview |
| POST `/api/v2/tasks/checks` | exact JSON `scope`, `check`, `idempotency_key`, `approval_sha256`, `approved` | executive submit |
| GET `/api/v2/tasks/{task_id}` | query `after_seq` (default 0), `limit` (1..100); no body | runtime authorized read |
| POST `/api/v2/tasks/{task_id}/cancel` | no fields; empty body or `{}` | runtime authorized cancellation |

Scope is a configured opaque scope label, never a filesystem root. Checks are
configured names, never argv. Scope/check/idempotency fields must be nonblank
bounded strings without control characters. Approval is literal JSON `true` and
the exact lowercase 64-hex finalized preview digest. IDs are 32 lowercase hex
characters. Submission returns 202 only after the synchronous executive method
accepts it; this is not proof of action completion. The runtime remains the
owner of review freshness, containment, approval replay, quotas, and durable
authorization. Cancellation reports the runtime's actual state and must not
claim a running action has already stopped.

Private task errors are sanitized: missing authentication 401, missing verified
context/access denial 403, incompatible reviewed submission 409, malformed task
input 422, oversized transport 413, unsupported body media type 415, unavailable
runtime 503. Existing framework query validation may provide ordinary field
validation details; runtime exception text is never exposed.

Receipt reads pass principal and cursor to the runtime on every reconnect. They
do not acknowledge or consume its durable outbox, mutate receipts, or publish
private results to WebSockets. Outbox delivery remains the existing executive's
responsibility. Shared installation credentials do not provide separate person
or client isolation; no stronger identity claim is made here.

## Evidence and remaining gates

`tests/test_task_routes.py` executes the real router and the actual auth
middleware/functions extracted from server source into an isolated ASGI app.
Only unrelated live startup/car-code filesystem lookup is excluded. Tests cover
every protected endpoint, auth variants, stale state and WebSocket provenance,
forged fields, bypassed middleware, strict JSON/query/transport limits, owner
mismatch, receipt reconnect, cancellation truthfulness, sanitized errors, and
real off-loop runtime invocation. Server registration and request schema are
also checked against source/OpenAPI.

The guarded 768M sandbox run at
`/opt/leon-v2-tools/test-results/phase7-task-routes-20260929-b` passed **82 tests
in 1.94s**, including the five pre-existing query-key regression functions run
against the actual extracted middleware with a fixture key. `git diff --check`
passed. The source base is `52cca686fa3aac63e4fcd26e30b1f222ed3a3e88`;
the original `server/__init__.py` SHA256 is
`099cba83f2935e025541e79f6fb2a347113eb1e282b411cad6e71cdd000df66a`,
preserved before guarded staging at
`/opt/leon-v2-tools/source-backups/handoff-task-routes-20260929/server_init.before.py`.
This is fixture evidence, not a deployed/live task-acceptance result. Root must still
integrate the runtime/Executive lifecycle, trusted workspace and containment
configuration, feature flags, durable operational paths and production
acceptance gates. No live action is needed to validate this transport candidate.
