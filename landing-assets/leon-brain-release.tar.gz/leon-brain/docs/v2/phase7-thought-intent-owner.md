# Canonical thought intent lifetime

This change extends the existing `MemoryShadow` lifecycle slot. It creates no
thread, model owner, KnowledgeStore, SelfModel, canonical path or second memory
lifecycle owner. Existing retrieval modes remain SHADOW. The independent
`thought_intents` feature requires an explicit typed startup binding and a
trusted callback returning literal `True`; missing configuration never enables
private writes. The root installer and InnerVoice/executive integration are
separate changes.

`ThoughtIntentRuntimeConfig` binds the installation principal, policy revision,
producer, row/byte quotas and maximum simultaneous operation leases.
`CanonicalThoughtIdentity(name, version, born_ts)` binds the complete stable
canonical tuple, including fractional birth time. Its `identity_id` uses all
256 SHA bits, compact sorted-key UTF-8 JSON, `ensure_ascii=False`, and a
`self-model:v1:` prefix. It does not reuse the old 12-character drift label.
The operator's expected identity must be checked against the already-loaded
canonical SelfModel; converting whatever happens to be loaded into a newly
approved identity is not a continuity check. No identity file is created or
repaired by this seam.

The late installer supplies `MemoryShadow(thought_intent_config=...,
thought_intent_requested=..., thought_principal=...)`. Both callbacks must be
bounded, free of side effects and non-reentrant. The requested callback combines
the explicit thought feature configuration/live selection with runtime
admission. Principal comes from trusted server installation authentication, not
model output, a channel label or an HTTP body. The facade captures the actual
`state.claude_bridge.knowledge` and `state.cognition.self_model` handles at
construction and checks their exact types and identity before canonical access.
No capability or database open occurs while the thought feature is unselected.

The installer must serialize first installation and use
`owner.thought_configuration_matches(config)` before reusing an owner. This
accepts an identical binding while the feature is temporarily OFF, but never
rebinds a stopped/draining owner. A changed config or owner requires existing
quiesce/drain/replacement discipline. The CognitiveRuntime memory slot already
refuses overlapping lifecycle owners.

## Operation lease

`owner.open_thought_intent()` returns a context-managed narrow lease. It exposes
`current()`, `remember_thought_intent`, `recall_thought_intent`,
`admit_thought_realization`, `finish_thought_realization` and
`recall_thought_realization`; it does not expose generic memory writes. One lease
pins one complete thought and at most one attempt descriptor. A lost snapshot
reply pins the original ID/value but requires confirmed exact readback before
attempt admission. A replayed realization receipt is never fresh permission to
generate again.

Keep the lease across durable snapshot/readback, the executive decision,
realization admission, scheduler submission, provider cleanup and durable
terminal bookkeeping. `current()` is a cheap current selection/reference/identity
check: no database/path access, canonical owner lock, model call or thread.
Observed revocation permanently fences that lease. The caller must also bind
the current executive and scheduler, enforce descriptor limits, and recheck
before model entry and any later effects. No memory receipt alone authorizes
inference, tools, speech, SNN mutation or public activity text.

Quiescence immediately rejects new leases and new remember/admit calls.
Already leased terminal bookkeeping retains the exact private ON MemoryService
and canonical capability so CANCELLED/UNKNOWN can be persisted after provider
cleanup, even if the public principal/selection changes. This is bookkeeping
under the old captured scope; no authority transfers to the successor. Storage
still verifies the captured canonical inode, scope and complete attempt binding.
Never switch this retained service OFF before leases drain.

`stop()` returns false and the existing memory slot remains non-retired until
every admitted lease closes. Close is explicit/idempotent, with a bounded wait;
closing concurrently with a canonical method raises and retains ownership until
the method drains and close is retried. A leaked lease deliberately prevents a
false retirement receipt. A lease is not proof that external/provider work is
drained: the caller must close it only after that work and terminal persistence.
There is no timer that kills provider work or releases uncertain ownership.
Bounded shutdown expiry can leave an admitted attempt unresolved for explicit
recovery; it never replays the model or deletes canonical state.

The facade uses one private MemoryService on the existing KnowledgeStore. The
older SHADOW retrieval worker may continue using its writer-free ephemeral read
facades; it receives no new canonical authority. Public stats contain fixed
booleans/counts only. No thought content, principal, identity, path or digest is
published.

## Verification boundary

Fixtures create real KnowledgeStore and SelfModel owners in temporary sandbox
directories. Tests cover exact owner reuse, inert unselected paths, full identity
binding, quotas, lost commit replies, paused commit/shutdown races, retained
terminal writes, no replay, private stats and actual CognitiveRuntime retirement.
They make no live canonical writes, provider calls or activation claims. Root
startup configuration, InnerVoice, executive and installed scheduler integration
must be validated separately before enabling this feature.
