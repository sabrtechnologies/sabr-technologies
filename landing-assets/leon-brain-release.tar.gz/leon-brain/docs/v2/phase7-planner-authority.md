# Durable operator authority for supervised planning

`PlannerAuthority` replaces a synthetic approval callback with an operational
registry under the existing TaskRuntime. Its constructor is cold. It creates
no database connection, worker, model owner, action handler, service connection
or periodic loop. It uses the runtime's existing `tasks.sqlite` registry
connection and the existing runtime/store lock order.

## Trusted startup and lifecycle

```python
authority = PlannerAuthority(runtime, scopes=explicit_plan_scope_tuple,
    enabled=pure_operator_flag_predicate).prepare()
ingress = PlannerIngress(runtime,
    resolve_scope=authority.resolve_scope,
    resolve_approval=authority.resolve_approval,
    enabled=pure_planner_flag_predicate).prepare()
authority.bind_ingress(ingress)
```

Root owns this installation and must perform it before the existing TaskWorker
starts. The exact same authority/ingress instances belong to that TaskRuntime
lifetime. The typed startup tuple contains one to sixteen `PlanScope` records;
paths, checks, actions and budgets are explicit configuration. They are never
inferred from a model proposal or deserialized from an HTTP body.

Preparation binds each scope to actual backend configuration and directory
identity. All configured allowed paths and check names are validated. Retained
scope bindings are immutable; a changed startup scope or backend configuration
gets a different fingerprint and cannot authorize a previous approval. The
active resolver verifies the currently prepared binding and actual root
directory identity. Historical receipts remain available to the authenticated
installation principal. Scope bindings and approvals have finite quotas;
expiry and revocation never delete them.

Selectors must be fast pure booleans, without worker-health, scheduler, database
or RPC calls. Authority callbacks may run while ingress already holds the
runtime/store locks; they perform local registry/configuration checks only.
`review` checks active parent authority before taking its own store lock, then
rechecks exact identity, revision, scope, cancellation, lifetime and proposal
under the lock. Neither review nor approval invokes containment preview RPC.
The separately owned ingress must perform containment checks outside parent
locks and revalidate before granting/enqueuing.

## Executive API and human approval

`review(parent_id, principal=verified_principal)` returns the exact current
proposal, full canonical action spec, immutable workspace/scope fingerprint,
`proposal_sha256`, `review_sha256`, parent revision/deadline and maximum validity.
For a fixed check it shows its executable, full-command digest, argument count,
working directory, timeout, containment reference and environment key names.
Raw argv is not returned: a containment wrapper can carry an encoded launch
manifest containing environment values. The exact command remains bound by the
configuration digest and belongs to the separately reviewed startup definition.
The review creates no approval, grant or action.

`approve(parent_id, principal=..., proposal_sha256=..., review_sha256=...,
idempotency_key=..., validity_s=..., approved=True)` requires the exact reviewed
digests and literal True from the authenticated executive. `validity_s` is an
integer from 1 through configured `max_validity_s` (at most 900); booleans and
floats are rejected. The authority generates the approval reference and issue
time. Expiry is the minimum of issue time plus validity and the original parent
deadline. HTTP/model input cannot choose an approval reference or timestamps.

The returned frozen `PlanStepApproval` is a durable receipt. Approval alone
performs no dispatch. Root passes its original reference and expiry to the
existing planner approval controller, which persists the exact ingress review,
issues the grant, and enqueues through the established worker.

The same idempotency key and exact input returns the original receipt after a
lost reply, restart, parent progress, expiry, configuration change or revocation.
It never extends expiry. Changed input conflicts. A second idempotency key
cannot issue a replacement approval for the same parent/proposal, including
after expiry or revocation. A new reviewed proposal requires explicit approval.

`lookup(reference, principal=...)` returns authenticated historical metadata.
`resolve_approval(reference)` is the internal current-policy callback and
returns None when the installed scope/configuration or selection differs.
Both preserve original issue/expiry and report persisted revocation in the
frozen receipt. `revoke(reference, principal=...)` is irreversible and idempotent;
it denies future authority without trying to erase committed effects, receipts
or UNKNOWN resource fences. The existing final-effect authority callback reads
this state again before a still-pending effect.

Principal identity must come from existing validated server authentication;
the authority rechecks it against TaskRuntime. These APIs are never model tools.
Root owns routes, executive wiring, startup configuration and result delivery.
Errors use `AuthorityDenied`, `AuthorityConflict` and `AuthorityCapacity`, all
derived from the existing `PlannerDenied` family; underlying task authentication
and ingress validation errors remain fail-closed.

## Validation boundary

Tests exercise real TaskRuntime, TaskStore, TaskPolicy, ProjectActions and
TaskWorker under the hardened test sandbox, using synthetic reviewed proposals
and temporary files. They cover exact review/configuration binding, replay after
restart/progress/expiry/revocation, immutable deadlines, cross-parent and forged
principal rejection, retained quotas, and final-boundary revocation. No live
model, service, credentials, production state or deployment is exercised.

The serialized 768M run `planner-authority-20260929-c` passed **252 tests in
4.40s** across authority, ingress, planner, runtime, policy, project actions,
worker and lifecycle. This includes 28 authority regressions. JUnit is retained
in that run directory. Source manifests and prior candidates are preserved at
`/opt/leon-v2-tools/source-backups/handoff-planner-authority-20260929`.

This candidate's parent is ingress commit `8d79eb9e`. Root integration must
also include ingress lock fix `110dc7a6`, which moves containment preview outside
runtime/store locks and revalidates afterward. That fix is separately owned;
this authority module itself never invokes containment RPC.
