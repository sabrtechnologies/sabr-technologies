# Phase 12: scheduled consolidation units

This candidate implements runbook section 16 in the new, separately owned
`brain/cognition/consolidation_v2.py`. It reuses the installed Phase 3 scheduler
and existing store/learning owners. It defaults to **off**, supports **shadow**
proposal generation, and provides gated owner commits for a later explicit
integration. No live jobs, canonical state, runtime flags, services, or deployment
are changed by this development work.

The existing free development checkout `/opt/leon-v2-worktrees/phase8` is reused
on branch `v2/phase12-consolidation`, based on integrated Phase 3 commit
`ccb2b25333ca7ce3ddb6cddd9b46c314805418f9`. The earlier Phase 8 commit remains
preserved on `v2/phase8-prediction-error` at
`4b11bebfc5c55f25e7706758e179ca6f290aac5d`. The checkout was verified clean before
branching. There were no interrupted Phase 12 files to overwrite. Copies and
hashes of the relevant existing sources are in local `phase12-candidate/before`;
all original sources also remain in the base commit.

## Existing ownership and why full passes are not scheduled wholesale

Source inspection covered DreamEngine, SleepConsolidator, WakeReplay,
MemoryConsolidationDaemon, CognitionConsolidator, and the Phase 3 scheduler/cancel
API. GraphMemory's public read/write APIs were inspected without constructing a
store or inspecting live state.

- SleepConsolidator owns a separate idle/hourly loop and a whole pass that reads
  knowledge, computes cross-references, appends insights, and rewrites its log on
  rotation. The current pass has no cancellation boundaries.
- CognitionConsolidator's pass reinforces/compresses graph chains, decays edges,
  optionally calls a model for explanations, updates identity/archetypes, saves
  the self-model, and prunes/rotates stores. Its sleep wrapper adds this work to
  SleepConsolidator.consolidate. Calling this method as one unit would hide several
  writes and model calls behind a single uninterruptible boundary.
- MemoryConsolidationDaemon promotes and deduplicates knowledge and can rewrite
  owner facts. Its whole pass is not a reversible derived-index operation.
- DreamEngine and WakeReplay already own their local mechanics and queued neural
  signals. This module never calls their step/replay/weight-update paths, injects
  currents, constructs a brain, or takes ownership of neural plasticity.

Those owners remain intact. Root must split or expose safe operations through
their existing APIs and retire duplicate scheduling at cutover. A scheduler wrapper
around an unbounded legacy pass is not a safe integration.

## Scheduler and cancellation contract

`ConsolidationCoordinator` never starts a thread, creates/installs a scheduler,
or owns an inference session. It fetches the installed scheduler, constructs a
DREAM request, verifies priority **10**, and submits it. There is no direct/legacy
fallback when admission or the scheduler is unavailable. The existing caller must
drain and close the returned handle and call `record_terminal(job_id, handle)`
to record queued refusal/cancellation where the provider never started.

Local consolidation requests have empty prompts, `allow_tools=False`,
`persist_history=False`, and `can_preempt=False`. Direct admission is used for
their local units; they do not acquire an extra legacy inference session. Each
`WorkUnit` has one existing owner, a declared operation, and a cooperative budget
of at most 100 ms (50 ms default). Its callback receives `UnitContext.check()`
and must use that check at bounded iteration boundaries. A cancellation, deadline,
or active-user probe stops new units. Probe failures defer work conservatively.

The scheduler's real user preemption sets the same cancel token. Already dispatched
canonical owner writes are allowed to return their receipt; that receipt is saved
even after cancellation and delivered as a `tool_result` event so the scheduler's
existing drain rule retains it. No further units start. This namespaced event is a
consolidation owner receipt, not a new actuator command; the root consumer should
handle it accordingly. There is no TTS or user-response ownership here.

A callback that exceeds its declared budget stops the remainder of the pass and
records the overrun while preserving completed receipts. This cannot forcibly
interrupt a noncooperative Python callback or roll back an already dispatched
atomic write. Immediate yielding therefore requires the root-owned APIs to be
bounded/cooperative; wrapping a long database lock wait or full neural pass does
not meet that contract. Preemption tests demonstrate the cooperative path only.

Optional `submit_reflection` submits a separate priority-10 request to the
**installed scheduler's provider** with background admission, no tools, no history
replay/persistence, and a bounded deadline. Shadow/off cannot invoke it. It creates
no private provider or fallback. The existing owner consumes its handle; any
generated text remains an unverified proposal.

## Lightweight checkpoints, interrupted work, and commits

`CheckpointJournal(path)` requires an explicitly selected derived metadata path;
there is no canonical-state default. It uses SQLite synchronous FULL, bounded
metadata, and a short database-lock timeout. It stores:

- Job manifest: trace/job IDs, mode, supplied source revision references, ordered
  unit metadata, proposal evidence, pre-commit versions and rollback references.
- Unit receipts: running claim before calling the owner, deterministic idempotency
  key, owner/operation, prior version, review reference, result references, actual
  duration, and completion/uncertainty status.
- Derived candidate proposals and their eligibility assessment; no raw memory
  text, weights, canonical memory table, or competing semantic index.

The checkpoint commits before the first unit runs. Reusing a job ID with a changed
manifest fails. Duplicate submission cannot repeat active/completed units; explicit
`resume=True` is required after interruption. Completed/proposed units are skipped.
Known cancellation between claim and callback is recorded as `not_started` and
can safely resume. Explicitly declared idempotent read/derived units may resume
after cancellation/failure; canonical units can never declare automatic retry safety.

A running or uncertain canonical receipt survives reopen and blocks replay. The
root-owned API must resolve whether it committed by its idempotency key.
`journal.reconcile(..., owner_receipt_id=..., version_after=...)` records a verified
existing commit without invoking it. Exceptions, including TypeError after an
effect, never trigger a retry/fallback. If an owner reports failure without a
verified commit receipt, the canonical unit remains uncertain.

In on mode a canonical unit additionally requires:

1. An eligible evidence-backed Proposal.
2. Explicit `CommitAuthorization` from the existing executive/policy adapter,
   matching the unit's expected version and carrying a review reference.
3. An existing owning API callback that atomically checks that version, applies
   its own policy and idempotency key, commits, and returns a durable owner receipt
   plus the resulting version.
4. For destructive merges, a rollback/provenance reference already present in
   the manifest. Actual backup/version support belongs to that existing owner.

The coordinator does not independently grant permission or implement a generic
canonical writer. Its metadata checkpoint is **not a backup of canonical content**
and does not claim to restore brain/store state. If the journal fails before a call,
the call does not happen; if receipt persistence fails afterward, the durable
running claim prevents replay pending reconciliation.

Job/proposal retention is capacity-bounded and fails closed. No automatic expiry,
silent eviction, canonical pruning, or checkpoint deletion is implemented. Root
must explicitly archive completed derived journals under its existing retention
policy. Do not close a journal while its submitted job still runs.

## Complementary learning policy

The policy implements the runbook's different durability thresholds:

| Target | Proposal eligibility | Canonical owner |
| --- | --- | --- |
| Immediate experience | Existing append-only episode/raw-outcome path remains immediate | EpisodeStore/action feedback; unchanged |
| Fast procedural | Reversible; at least three distinct verified successful invocations and >= 80% success among supplied distinct invocations | SkillMemory/Procedure owner |
| Slow semantic | Verified authoritative source, two independent verified origins, or repeated verified observations across history | Existing knowledge/lesson owner |
| Identity | At least three verified observations across multiple sessions/times; generated sentences never count as evidence | Existing versioned self-model owner |
| Neural plasticity | No consolidation job writes or steps neural state here | Existing STDP/reward/sim-loop owner and its checkpoints |

Evidence references are deduplicated. Conflicting copies do not add support;
multiple references for one action cannot manufacture successful invocations.
Unknown origins do not qualify. Root adapters are responsible for trustworthy
verification, invocation, origin/session and version metadata. These thresholds
are conservative implementation policy, not validated laws of learning or proof
of a cognitive/scientific improvement.

`existing_source_units(episodes=..., knowledge=..., limit=64)` provides working
bounded adapters using **existing live handles**. Reads occur after scheduler
admission. Episode rows group action/signature evidence; `action_id`,
`outcome_verified=True`, and `reversible=True` must come from the actual owning
action policy. Historical success counts alone cannot enable automatic promotion.
Knowledge rows group equal content fingerprints while storing only references;
verified authority/origin/session metadata must come from their existing owner.
Oversized raw text and malformed metadata cannot become promoted evidence.

These adapters produce actual derived proposals through the checkpoint journal.
They do not instantiate stores, mine a new semantic index, copy raw experience
into another canonical store, invoke the full legacy passes, or modify the rows.
`proposal_unit(proposal)` also accepts candidate output from existing
SleepConsolidator/CognitionConsolidator owners after their API split.

## Root-owned integration requirements

No existing file is modified by this commit. The root integrator owns these hooks:

1. At the existing composition root, create a coordinator only under the reviewed
   consolidation mode, pass the explicit derived journal path, existing user-turn
   probe, authorization adapter, and source revision references. Leave off/shadow
   until the remaining gates pass. Do not create another periodic loop.
2. The existing runtime/sleep scheduler calls `submit(...)`, drains/closes its
   handle, and records its terminal outcome. On cutover, disable/delegate the
   matching legacy idle/hourly scheduling owner so the same pass cannot run twice.
3. Expose bounded candidate/read operations from SleepConsolidator and
   CognitionConsolidator; keep graph decay, knowledge pruning, deduplication,
   fact promotion and identity writes separate. Model explanation steps use
   `submit_reflection`/the installed inference scheduler, never call a responder
   inside a local unit or synchronously resubmit from its scheduler worker.
4. Add owner-level version-checked, idempotent commit APIs where missing. Existing
   GraphMemory.reinforce_chain, knowledge promotion/deduplication, and self-model
   save are not automatically assumed to provide atomic receipts or rollback.
   A callback must honor the exact `ctx.receipt["version_before"]` and
   `ctx.idempotency_key`; mere declaration in the WorkUnit cannot enforce its
   internal implementation.
5. Root's EpisodeStore/knowledge adapters supply explicit verified evidence and
   invocation/provenance metadata. The current episode schema lacks some of
   these fields, so existing history remains ineligible until the owner can
   attest them; this candidate never rewrites historical evidence to fill gaps.
6. Rebuild any derived search index through its existing Phase 6 owning API as
   an idempotent bounded unit. Preserve existing index/persistence ownership.
   Neural plasticity, DreamEngine/WakeReplay cadence, and versioned neural
   checkpoints remain with their current owners; no cross-thread brain.step.
7. Route checkpoint/proposal/owner receipts into the existing event and episode
   observability path with job/trace/unit IDs. Keep private text out of general
   logs. Establish explicit archival/recovery and owner receipt reconciliation.

Acceptance still needs real owner-API cancellation/latency measurements, single
sleep scheduling authority, checkpoint/receipt recovery against the real owners,
and verification that no legacy inference or destructive pass bypass remains.
The tests demonstrate scheduling and data-policy behavior; they establish no
subjective experience, biological mechanism, or learning-performance improvement.

## Validation

All VPS tests must use the hardened launcher and a unique result directory:

```text
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase8 /opt/leon-v2-tools/test-results/<unique-name> --mem 768M -- python3 -m pytest -q tests/test_consolidation_v2.py tests/test_inference_scheduler.py tests/test_inference_scheduler_lifecycle.py
```

Final isolated run `phase12-consolidation-20260929-b` passed 70 tests in 5.77 s
after the evidence/queued-cancellation refinements. The suite uses scratch SQLite, fake owning APIs and the actual
Phase 3 scheduler, including foreground preemption, cancellation result drain,
reopen/no-replay, explicit reconciliation/resume, source-read timing, capacity,
version/provenance gates, and refusal to promote generated/unverified evidence.
