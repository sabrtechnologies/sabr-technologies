# Canonical private ThoughtIntent snapshots

This is the persistence prerequisite for runbook 11.2. No executive admission,
inner-voice cutover, inference, publication, flags, startup installation or
autonomous loop is added. The existing KnowledgeStore owner and database remain
canonical. No alternate database, writer lifecycle, embedding or neural encoder
is created or invoked.

Trusted startup may construct a frozen `ThoughtIntentWriteCapability` with the
already-owned KnowledgeStore, installation principal, identity, producer, and
finite quotas. Pass that capability to `MemoryService(...,
thought_intent_capability=capability)`, with its exact existing knowledge adapter
and writer and matching SourcePolicy principal/identity. The capability pins the
existing nonsymlink single-link regular database's path and device/inode; a replacement at
the same path cannot silently inherit it. Identity is rechecked around database
opens, commit and readback. This is an owner-continuity check, not a sandbox
against an adversarial same-UID filesystem writer. Both the capability and
explicit `mode="on"` are required. Ordinary MemoryService construction and
OFF/SHADOW calls do not open/create snapshot tables. Capabilities are never
deserialized from a request, event, model response or mutable thought metadata.

`MemoryService.remember_thought_intent(intent)` requires the existing exact frozen
ThoughtIntent type and private privacy setting. It validates and bounds the full
canonical JSON before taking the canonical owner lock. A confirmed fresh
readback returns `ThoughtIntentReceipt` with the stable thought ID, snapshot
SHA256, private principal/identity/producer, persisted timestamp, replay status,
and canonical reference `knowledge / thought_intent:<id>`. This is evidence of
storage only; it does not authorize a model, action, identity claim or utterance.
`recall_thought_intent(id)` supplies the full typed snapshot and its provenance
through this same capability. Exact ID lookup is separate from general search.

Two extension tables live INSIDE the existing knowledge.db:

- `thought_intent_snapshots`: immutable ID, full JSON and SHA256, exact private
  provenance metadata, byte count, and original persistence timestamp.
- `thought_intent_limits`: schema version and immutable global row/byte quotas.

They are lazily created in the first authorized write transaction. Existing
knowledge rows, schema initialization, FTS triggers, ordinary search and neural
encoding behavior are unchanged. Private snapshots never enter the knowledge
table, FTS, semantic sidecar, autobiography, or identity evidence. Legacy code
that bypasses MemoryService can still access the same database; this API is a
private capability boundary, not an OS-level database access-control mechanism.
This seam does not verify/change file UID, permission modes or parent-directory
permissions. Deployment's existing canonical storage policy must provide any
required filesystem confidentiality. Hardlinked aliases are rejected because
distinct pathnames can create incompatible SQLite journal/WAL ownership.

BEGIN IMMEDIATE serializes independent SQLite writers. Same ID, full canonical
snapshot and provenance returns the original row after readback. Changed
content, producer, identity or principal raises a non-disclosing conflict. No
overwrite, pruning or implicit quota extension occurs. Default bounds are 4,096
snapshots, 16 MiB combined snapshot/metadata bytes, and 64 KiB per complete
snapshot. Limits are pinned on first successful commit; a full store refuses
new IDs while allowing exact replay. Changing pinned limits requires a separate
reviewed maintenance operation; this implementation provides none.

Each write uses a bounded .25-second owner/SQLite lock wait, opens the existing
database with mode=rw, and requests/verifies synchronous=FULL for its connection.
It accepts existing delete/truncate/persist/WAL journal modes and never changes
the database's journal policy or checkpoints the WAL. Rollback covers schema,
quota and row writes before commit. A separate mode=ro connection must confirm
the exact committed row before a receipt is returned. This establishes SQLite
commit/readback behavior, subject to SQLite/VFS/filesystem/storage guarantees;
it is not a universal power-loss guarantee.

Any validation, busy, disk, commit, readback or post-I/O policy failure produces
no successful receipt. A commit may nevertheless have succeeded before a lost
reply. Retain the original thought ID and full value for recovery; never create
a fresh ID merely to retry an ambiguous write. The future executive must refuse
articulation without a confirmed receipt and retain committed nonverbal intent
when articulation is deferred or preempted. That integration remains separate.

Hermetic tests use actual KnowledgeStore owners and SQLite databases only in
temporary sandbox paths. They cover complete readback, restart replay/conflict,
concurrent owners, private retrieval isolation, no encoder/index invocation,
OFF/SHADOW inertness, capability mismatch, quotas, bounded contention, simulated
disk/commit/readback failures, and existing journal-mode preservation. They do
not establish subjective experience or scientific efficacy.
