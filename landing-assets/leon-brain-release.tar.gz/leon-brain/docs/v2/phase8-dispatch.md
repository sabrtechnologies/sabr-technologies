# Prospective observation at existing tool dispatch wrappers

This candidate adds a cold hook to the real local-tool and actuator wrappers in
`brain/cognition/bootstrap.py`. It preserves their original execution, return
values, exception identity, timeouts, and canonical episode recording. It adds
no tool call, context construction, database read, model request, worker, queue,
or consumer before dispatch. The observer is OFF by default and is not installed
by this candidate. Production configuration is unchanged.

## Read-only forecast source

`WorldModel.peek_cached(tool, args, context_bucket=..., max_age_s=...,
now_mono=...)` returns an immutable detached `CachedForecast` or `None`.
The lookup uses the existing cache key: tool name, existing normalized argument
signature, and the supplied known context bucket. That signature is deliberately
coarse: different URLs share `<url>`, and different numbers share `<num>`.
This is not a claim of raw argument equality, an exact action-specific forecast,
or empirical calibration. Source confidence remains data-depth metadata.

The lookup does not call `WorldModel.predict`, `_tool_risk`, the episode store,
or `_build_context`; does not change counters, LRU ordering, expiry, or cache
entries; and does not wait for a contended cache lock. Unknown, stale, malformed,
oversized, or contended inputs return `None`. Only bounded builtin top-level
argument shapes are inspected, avoiding user-object conversion callbacks.
Forecast methods carry a `cached_` prefix and retain the original cache timestamp.
The timestamp is never changed to make old evidence appear fresh. The runtime
may reject a cached forecast whose age plus deadline exceeds its horizon.

## Root-owned installation and admission contract

Shared runtime, loop, publisher, flags, and caller changes belong to root.
Install one owner on the existing cognition namespace only after the matching
publisher/loop capability seam is present:

```python
from brain.cognition.prediction_dispatch import DispatchScope, PredictionDispatch
from brain.cognition import v2_publish

cognition.prediction_dispatch = PredictionDispatch(
    world_model=cognition.world_model,
    clock_id=prediction_runtime.clock_id,
    capture=v2_publish.capture_world_prediction,
    mark_dispatched=v2_publish.mark_prediction_dispatched,
    terminal=v2_publish.emit_prediction_outcome,
    ready=lambda: prediction_runtime.ready,
    enabled=True,  # Explicit root decision; constructor default is False.
)
```

Enable only the metadata observer governed by the existing `prediction_error`
mode, with all enabled modes retaining SHADOW behavior. `ready` must return
cached lifecycle state without filesystem or other I/O. `capture` and `mark`
must remain bounded in-memory operations. Terminal publication uses the existing
publisher; no second event consumer is introduced. Constructing this class does
not inspect flags, credentials, filesystem state, canonical stores, or tools.

On the actual authorized execution thread, immediately around the existing
wrapped tool call, the root caller may supply an explicit scope:

```python
with cognition.prediction_dispatch.scope(DispatchScope(
    request_id=request_id,
    action_id=action_id,
    prediction_id=prediction_id,
    trace_id=trace_id,
    clock_id=prediction_runtime.clock_id,
    tool_name=actual_tool_name,
    context_bucket=already_known_context_bucket,
    deadline_mono=explicit_action_deadline,
    latency_scale_ms=explicit_latency_metric_scale,
    max_cache_age_s=explicit_cache_age_limit,
    cancel_token=actual_admitted_request_cancel_token,
    evidence="unverified",
    evidence_ref=None,
)):
    result = existing_wrapped_tool_call()
```

The caller owns all identities and metric contracts. Use the actual request,
action, prediction, trace, clock, deadline, and cancellation token. Never infer a
user identity from a channel, substitute a random ID for a missing request, or
invent a latency normalization scale. The scope is single-use for its exact
tool name and execution thread. Context copying to a different thread does not
grant admission. Distinct scopes need distinct observation identities.

The context bucket must already be known for this action. Calling the current
`loop._build_context()` to obtain it would violate this contract because it can
call `window.list`. Do not recompute a forecast or read a database to populate a
missing cache entry. If the caller cannot establish the bucket, identity, clock,
metric, and deadline, leave the call unscoped. No forecast or unavailable scope
means no prospective evidence. The existing result-time canonical context and
prediction behavior is preserved and remains retrospective.

The injected monotonic clock and the wrapper's `time.monotonic()` must refer to
the same process clock domain. Captured forecasts are marked dispatched just
before the original callable executes, and observations use its completion
timestamp. The observer does not authorize, abort, retry, or replace a tool;
existing caller cancellation and permission checks continue to own execution.

## Single prediction-error ownership and canonical continuity

The required root seam is precisely
`loop.record_tool_call(..., prediction_parent_ticket=<opaque outer ticket>)`,
forwarded unchanged to `v2_publish.emit`. The publisher must verify the actual
registered `PredictionTicket` capability, suppress the legacy PE child, and
omit prospective annotations for this nested record. A raw boolean suppression
flag is not used.

For a local tool that calls the actuator, both existing canonical episodes are
still recorded. Only the outer wrapper captures a forecast. The nested actuator
record carries `prediction_parent_ticket`; the outer completed record carries
`prediction_ticket`, `prediction_observed_mono`, `prediction_evidence`, and
`prediction_evidence_ref`. Only that outer observation can own a PE result.
Do not enable the hook before these shared seams are integrated; otherwise the
new keyword could reject a canonical record on an older loop implementation.

Cancellation uses the actual injected token, emits a standalone `cancelled`
outcome with empty observations, and retains parent-ticket suppression on the
canonical record. A dispatch mark failure, quiesce, or non-ordinary exception
emits `missing`, not an invented failure measurement. If canonical recording
raises or returns no episode ID, the hook emits at most one standalone `missing`
terminal attempt without retrying or changing the actual tool result. Ordinary
tool exceptions retain the existing canonical error semantics and re-raise the
same exception object. Observer exceptions are contained and never cause a
second tool execution.

`quiesce()` cuts off new captures immediately. Existing nested records retain
the outer capability even after quiesce. `stop()` is nonblocking and returns
False until all owned outer frames retire in wrapper `finally` blocks. Root
must retain that owner and its prediction-runtime capability registry until
`retired` is true before replacement. `stats()` reports only bounded counts and
lifecycle states; it contains no IDs, queries, tool arguments, or context text.

## Validation and remaining gates

The hermetic tests load the actual wrapper bodies without application startup,
use fake local tools and a fake actuator, and seed only an in-memory cache. They
cover read-only lookup, expiry/contention/shape bounds, causal ordering, missing
scope, cancellation, nested ownership, quiesce during nested dispatch, unchanged
errors and return values, record failures, observer failures, context restoration,
single-use/thread-bound scopes, lazy tool insertion, and in-flight retirement.

Run on the VPS only through the installed serialized sandbox launcher:

```sh
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase6 \
  /opt/leon-v2-tools/test-results/phase8-dispatch-20260929-a --mem 768M -- \
  python3 -m pytest -q tests/test_prediction_dispatch.py tests/test_prediction_runtime.py
```

Root must still integrate the parent-ticket capability seam, lifecycle attachment,
and genuine before-dispatch caller scopes, then validate against the shared
runtime and publisher. No live observation, calibration improvement, consciousness,
or quantum effectiveness is established by these fixture tests. No production
flags, services, model transports, canonical records, or live state were changed.

Sandbox results: `phase8-dispatch-20260929-a`, **66 passed in 1.63s**, exit 0;
`phase8-dispatch-20260929-b`, **108 passed in 2.39s**, exit 0. The latter runs the
command above plus `tests/test_prediction_error.py` and `tests/test_prediction_hooks.py`.
The parent-ticket publisher integration is intentionally owned and tested
separately by root; the wrapper fixtures verify the exact argument contract.
