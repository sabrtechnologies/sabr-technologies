# Local conversation and spontaneous inference ownership

Candidate based on `36361d3e4dc2021bb844e11d93367e5a251c44b8`. This changes only
`brain/conversation_lane.py`, `server/conversation_lane.py`,
`server/spontaneous_speech.py`, its isolated tests and this document. It does not
enable a flag, contact a model, or establish live acceptance by itself.

## Root-owned registry contract

Add these entries to existing live flag defaults and scheduler GROUP_FEATURES:

| Group | Feature | Default | Priority |
|---|---|---|---|
| conversation | inference_scheduler.conversation | off | USER/VOICE 100 |
| spontaneous_speech | inference_scheduler.spontaneous_speech | off | BACKGROUND 30 |

Add `inference_scheduler.in_worker_context() -> bool`, exposing the existing
`_WORKER.in_worker` thread-local marker. Root owns these additions; this branch
does not edit the scheduler or flags. Tests supply that exact wrapper and the
two registry entries because its base predates the root wiring commit.

Selection checks the master kill switch plus `is_active(feature, channel, key)`
before asking `route(group, channel, key)` for an installed live scheduler. The
same stable key is used for both checks and the transport guard. An OFF or
unselected canary retains the existing direct route. A selected route with no
available scheduler, refused admission, expiry, cancellation, malformed model
response or other error never re-enters the direct route. Selection exceptions
also invoke no model.

The existing `LEON_CONVERSATION_LANE` text-selection gate remains unchanged.
The existing spontaneous-speech disable switch and 900-second rate limit remain
unchanged. Neither new flag creates an inference worker; both use custom
providers submitted to the one installed scheduler with direct admission,
`allow_tools=False` and `persist_history=False`. Conversation requests use
USER/VOICE priority 100; spontaneous requests use background priority 30.
Conversation canary channels are normalized to dashboard/voice; spontaneous
uses daemon. Legacy OFF/unselected routes remain outside the scheduler. Both
local groups must be selected (or spontaneous speech disabled), with old calls
drained, before claiming all local inference is serialized. A mixed canary is
not proof of global nonconcurrency.

The custom provider checks actual scheduler worker context and the native
per-job CancelToken, then establishes a thread-local token/group identity for
the transport. Selected direct calls to `chunks` are refused without that
context. A global threading.Event is not evidence of admission. This is an
internal ownership invariant, not a security boundary against arbitrary
Python code inside the process.

## Cancellation, completion and transport

GATE remains the channel cancellation coordinator. Binding a handle after
its gate token was cancelled immediately cancels that handle. New conversation
input cancels prior conversation/spontaneous work through the same scheduler
token; the gate's private lock is used only on legacy OFF routes. No provider
call on the selected paths is made by the caller or speech thread.

The transport reuses root's SocketHolder and TrackedHTTPConnection. Only direct
HTTP to numeric loopback is used; localhost is normalized to 127.0.0.1. Userinfo,
paths, query strings, fragments, non-loopback hosts and redirects are unsupported.
Socket shutdown handles blocked I/O; only the owning thread closes its response.
One bounded watcher combines external-event cancellation with a monotonic total
deadline and is stopped/joined in every exit path. Connection/silence timeout is
at most eight seconds; conversation/spontaneous total deadlines are 35/30 seconds.
Connection setup still has its bounded OS/network timeout. There are no retries.

Bounds: 16 text messages, 64 KiB encoded input, 64 KiB per stream line, 256 KiB total
stream, 2048 events, 32 KiB output, and at most 512 requested tokens. Actual selected
requests retain the prior 160/80-token limits. Invalid JSON, duplicate keys,
non-finite numbers, malformed text/done values, tool/function output, premature
EOF and empty completed replies are failures. No tool schema or dispatcher is
available. Only a valid completion can update recent conversation or history.

Consumers drain scheduler events through the terminal outcome. Transport/model
ownership is released before final speech draining or spontaneous surfacing.
A failed consumer cancels and drains its existing handle, without opening a
replacement provider. Existing public response event shapes remain unchanged.
Partial text may already have been streamed/spoken before an error or stop;
such text is never treated as a completed history entry.

## Explicit recorder and history ownership

`run(..., user_history_owned=False, recorder_turn=None)` adds two separate
ingress contracts. Only the literal `user_history_owned=True` suppresses the
manual ConversationStore user append. An authoritative user_turn_recorder turn
does not imply SQL history ownership: at this base the recorder writes neural,
presence and autobiographical effects, not conversation_history.

For a supplied recorder_turn, the selected path notes presence after admission
and finalizes it as replied/cancelled/aborted. The recorder's own exactly-once
finalization remains authoritative. This adapter does not create a turn from an
unverified source label: root must supply a verified ingress turn if recording
is desired, preserving synthetic/loopback exclusions. Root must pass the
user-history marker only after an existing owner actually wrote that user row.
Without that proof, successful replies append both user and assistant as before.

No task is created, resumed, retried or cancelled by this work. Long action/tool
draining can still occupy the single scheduler slot. Durable task/action
separation belongs to the independent task lifecycle integration; local chat
does not bypass model ownership to simulate task concurrency.

## Candidate evidence, 2026-09-29

The clean reused checkout `/opt/leon-v2-worktrees/phase10` now holds branch
`v2/phase3-local-conversation`; prior Phase 7 and Phase 10 commits remain on
their own branches. Original bytes and modes of the three edited files were
saved in `/opt/leon-v2-tools/test-results/conversation-stage-20260929/` as
`originals.tar` and `base-modes-hashes.txt`, alongside the base revision.

**36 tests passed in 0.38 seconds** through the serialized launcher:

```
bash /opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase10 \
  /opt/leon-v2-tools/test-results/conversation-tests-20260929c --mem 768M -- \
  python3 -m pytest -q tests/test_conversation_lane_scheduler.py \
  --junitxml=/opt/leon-v2-tools/test-results/conversation-tests-20260929c/tests.xml
```

JUnit SHA-256:
`51ed90317833271f43c657e2c37ab0dbc2ccf73b85fd19689eefb5cccb06b8c3`.
The adjacent `tested-source.sha256` manifest has SHA-256:
`ed6c964359ae4a57086b01d921b2f14aae826ea007c8fd2edf8d178c6dbe573b`.
This evidence and documentation clarification were appended after the run;
Python code was unchanged.

Tests use the real scheduler with fixture HTTP connections and temporary history
DBs. They cover foreground/background ownership, cross-path preemption with
prior transport closure before next dispatch, cancellation before/after admission,
recorder/history ownership, no-fallback failures, malformed/tool-bearing streams,
input/output/total bounds, transport timeout cleanup and OFF conversation behavior.
No paid/local model calls, production state, flags or services were exercised.
