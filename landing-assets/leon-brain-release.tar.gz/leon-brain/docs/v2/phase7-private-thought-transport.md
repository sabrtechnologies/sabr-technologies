# Private thought transport prerequisite

`PrivateThoughtPolicy` constrains one local text stream to 1–256 output tokens
and 1–8192 UTF-8 bytes. The public responder requires no tools, no replay,
no history persistence, no supervised user turn, explicit local preference,
and the private background channel policy. Invalid combinations fail before
registering or calling a provider.

Private policy calls bypass the user-turn recorder, ordinary core context
enrichment, user-model updates, reflexes and conversation finalizers. The
existing local `stream` transport receives the exact token bound. Events have
individual and cumulative delta byte bounds and a finite count. An oversized,
invalid or tool event closes the stream. A selected provider route is refused
instead of silently changing route or escalating to CLI/API.

The existing inference scheduler continues to own model admission and
cancellation. A priority-100 foreground request preempts private background
work and waits for its provider to drain. No history is written on completion,
error, preemption or late output.

This change is a prerequisite, not the InnerVoice cutover: durable intent and
realization receipts, Executive admission, explicit startup configuration and
selected-call ownership are wired separately. Nothing is activated or deployed.
