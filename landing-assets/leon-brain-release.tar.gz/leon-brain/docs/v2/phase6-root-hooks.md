# Memory shadow ownership and context parity

The server attaches `MemoryShadow` only after autobiography and goal owners have
initialized. It passes the actual state object; canonical stores are not rebuilt.
The live `memory_service` flag defaults OFF and the configured memory mode also
applies. All enabled modes remain SHADOW. The initial policy permits only legacy
unscoped rows and supplies no authenticated principal or identity; restricted rows
remain inaccessible. The existing autobiography category/prefix/content predicate
is shared with proposed retrieval. No authority weights or verified facts are
inferred from source names.

Context construction only offers bounded work to the existing owner. Filesystem
metadata discovery, canonical retrieval and proposal polling occur from the
existing runtime tick and the bounded retrieval worker. No query waits on the
user path. Shadow leaves components, ordering, drop decisions and rendered text
unchanged. Telemetry contains queue status and proposal counts, never text,
canonical references, digests, principals or query contents.

The runtime owns late attachment, ticks, admission cutoff and worker retirement.
Zero-time shutdown only quiesces; the existing runtime worker performs the first
drain. Incomplete retirement retains the owner and prevents replacement. Explicit
management retries may join after the read finishes. No second cognitive loop or
event-bus consumer is introduced.

This wiring does not enable embeddings, backfill, semantic sidecar creation,
canonical writes, retrieval text injection or a live rollout. Those require their
remaining runbook gates. Initial shadow observations use the adapter without a
sidecar. Existing live parity and p95 retrieval acceptance remain unmeasured.
