# Phase 7 durable task candidate

This is a subordinate operational task mechanism, not a second executive or a
completed Phase 7 cutover. Nothing auto-installs or starts. Existing runtime,
responder, mission, actuator and WebSocket paths are unchanged. Synthetic tests
do not establish live coding concurrency or reconnect acceptance.

## Existing authority and precise integration hooks

The existing ExecutiveController remains the only decision authority. At base
`b8d99672`, CognitiveRuntime always calls `plan_event(..., dry_run=True)`;
turning this candidate into active work requires an integrator-owned admission
bridge. Existing `workspace.ignition` metadata publication is already present.
Do not add another brain step loop or another workspace.

1. After an authorized task is admitted, create one TaskStore task using a stable
   submission idempotency key, explicit project scope and authorization reference.
   The reference is evidence to validate, not permission by itself. Use an explicit
   new operational database path; do not point at a memory DB or live state in tests.
2. Persist the reasoning cursor/input references in `checkpoint(...,
   state="WAITING_INFERENCE", expected_revision=...)`. Submit a short ACTIVE_TASK
   job to the existing InferenceScheduler. On preemption retain that checkpoint;
   the executive can resubmit reasoning later. Resume to READY only with the
   current revision. One task has at most one pending action. Separate tasks can
   make progress concurrently.
3. Enqueue a registered action with stable step idempotency key, exact arguments,
   tier and verified resource keys. The worker never asks a model to decide its
   next step. A mandatory per-action policy callback receives fresh persisted
   task/action snapshots and returns PolicyDecision with the exact resource set.
   It must validate authorization, project boundaries, tier, approval scope,
   tool/argument safety and resource ownership. No policy defaults to allow.
4. The worker records RUNNING then durably commits `dispatched=1` after policy
   and cancellation/deadline rechecks, before invoking the handler. One handler
   invocation is one unit; long-lived CLI agents with internally owned unknown
   tools are not safely detachable through this interface. Bridge only tools
   whose execution and resource ownership are understood.
5. A handler's result is durably saved before notification. The runtime reads
   `pending_results(consumer="runtime")`, handles events idempotently using their
   sequence/action IDs, then acknowledges individual results. Reconnect reads
   `receipts_after(task_id, after_seq=...)`; acknowledgments never erase action
   receipts or cause a tool to run again. WebSocket task/cursor messages and any
   result authorization checks are integrator hooks, not implemented here.
6. The executive can checkpoint and plan the next unit only after success returns
   the task to READY. Explicit task success is a checkpoint transition, not an
   inference `done` event. User speech cancellation is separate from
   `cancel_task(task_id)`; disconnecting a UI must not cancel durable work.

State examples:

```
READY -> WAITING_INFERENCE -> READY -> WAITING_ACTION -> RUNNING -> READY
                                                               -> FAILED
                                                               -> NEEDS_REVIEW
READY -> SUCCEEDED
cancel while running -> drain action receipt -> CANCELLED (or NEEDS_REVIEW)
```

`ThoughtIntent` is a bounded immutable runbook Stage A snapshot, with an adapter
for existing speech_intent.ThoughtIntention. The executive should put its
serialized record/ID in a task checkpoint or canonical MemoryService entry;
articulation remains optional and independently preemptible. This candidate
does not persist a separate identity or autobiographical memory store.

## Concurrency and lifecycle

TaskWorker defaults to two finite workers and at most one background action.
This leaves a lane for priority-100 actions while a coding action waits, provided
resource keys do not conflict. Keys are exact exclusion identities, not pathname
prefix matching: policy must map aliases, nested paths, desktop sessions and
shared repositories onto the same canonical lock key when they conflict.
Unknown legacy actions should use a common exclusive resource or remain outside
this candidate. More than one inference request is still serialized by the
existing scheduler; no worker makes a provider call by itself.

Cancellation stops future units. It cancels queued/claimed-but-undispatched work
and records that result. Already dispatched work drains; a cancellation cannot
rewrite its real result as cancelled or kill it. Its task becomes CANCELLED after
success, while the action receipt remains SUCCEEDED. Uncertain results take
precedence and leave the task NEEDS_REVIEW. Normal stop prevents new claims,
waits for a bounded caller-supplied timeout and retains the exclusive lease until
all workers drain. Keep the old worker/store reference if stop returns false.
Do not create a replacement or close its DB. Startup is explicit and one-shot.

The worker lease uses POSIX flock on the DB inode (production Linux). It is never
stolen by a timer. Another process/store cannot acquire a pool while the old one
is active. A fresh exclusive owner changes every abandoned RUNNING action to
UNKNOWN and saves a receipt. Even a crash before actual handler dispatch is
conservatively uncertain. Every retained UNKNOWN action permanently fences its
resource keys against new claims. This includes historical UNKNOWN rows,
acknowledged receipts, cancelled tasks and process-loss recovery: an external
tool may still be running. Acknowledgment is delivery evidence, not proof that
an external action ended. The fence does not consume a background worker slot,
so authorized actions on different resources can still proceed. There is no
expiry, automatic release, replay or reconciliation API; a future release bridge
must verify process/outcome evidence before an explicit reviewed transition.
Retained-action quotas bound fence storage. Windows action-worker startup is unsupported and
fails closed; pure data types remain importable. Do not replace an open DB or
create hardlink aliases. Each new DB is created mode 0600.

## Failure, budgets and durability

* Every tier is persisted. Missing handlers, denied/malformed policy, tier 4 and
  explicit `ok: false` are failures; no synthetic success is generated.
* Handler exceptions, malformed/unrepresentable results, `uncertain: true`, or
  `ActionResult("UNKNOWN", ...)` produce UNKNOWN. A legacy transport bridge must
  map lost acknowledgments/timeouts after possible dispatch to UNKNOWN; raw
  `ok: false` alone cannot prove an external effect did not happen. Neither
  FAILED nor UNKNOWN is automatically retried. No API resets either terminal
  task to READY. Reconciliation requires a separately reviewed future bridge.
* SQLite uses WAL, synchronous FULL, foreign keys and atomic immediate
  transactions. Claim/resource assignment and checkpoint revisions are atomic.
  Database commit failure fences the worker and retains its lease/RUNNING
  evidence; it must not execute subsequent work or claim successful delivery.
  Restart recovery is conservative. No distributed exactly-once external action
  guarantee is claimed without the remote tool accepting/querying a stable ID.
* Defaults: 256 retained tasks, 2048 retained actions, 128 unacknowledged/reserved
  result slots, 16 KiB object payloads, 16 resource keys, eight workers maximum.
  Every queued action reserves one result slot, so cancellation/recovery can
  always save its bounded receipt. Outbox acknowledgment releases capacity;
  retained task/action quotas eventually reject new work. This version has no
  automatic pruning, and never silently deletes idempotency keys. Operational
  archival/retention is a later explicit policy, not implicit replay permission.
* Notifications are best effort; receipts are authoritative. The single configured
  logical outbox consumer must acknowledge only after durable handling/dedup.
  Exactly-once cognition/memory effects are a consumer integration requirement.
  UI cursors use retained receipts and do not consume the runtime outbox.
* Operational arguments/results can be private. The bridge must minimize/redact
  secrets, persist large content as authorized references, and enforce caller
  access to task reads. Stored authorizations and IDs are not public endpoints.

## Existing paths that require integrator changes

* `brain/claude_api_responder.py`: separate registered external action dispatch
  from the provider generator, preserving tool-call history/protocol correctly.
  Current synchronous dispatch holds the inference slot while the scheduler
  correctly drains tools; this candidate alone does not fix that wait.
* `brain/mission/autonomy.py`: preserve policy/handlers, but bridge proposals
  instead of calling its inline executor for newly durable tasks. Current
  approval does not persist/recover handler context, missing handlers count as
  success, Tier 1 successes are unrecorded, and there is no atomic claim.
* `brain/mission/autopilot.py`: planners/fixer/operator must submit proposals
  through one executive instead of independently dispatching actions.
* `brain/cognition/runtime.py`, executive, v2_install and server routes: active
  admission, safe checkpoints, result acknowledgment, foreground task routing,
  shutdown ordering and reconnect APIs. Do not move a process-global autonomous
  context guard around concurrent foreground actions; use explicit per-action
  policy/context in the bridge.

Hermetic tests exercise duplicate/concurrent submission, action/result bounds,
process-loss recovery on both sides of dispatch, per-action policy, every tier,
explicit failure/uncertainty, foreground independent actions during a blocking
coding fixture, shared-resource exclusion, cancellation drain, lease retention,
durable notification/reconnect behavior and immutable nonverbal intents.

## Candidate evidence, 2026-09-29

The clean Phase 10 checkout at `570483ef675b2d45c6198556596c8f75b44112c3`
was reused; that commit remains on `v2/phase10-snn`. The new branch is
`v2/phase7-task-lifecycle`, based on clean integrated
`b8d99672db7d2f308559861ca6fc055dc707c2df`. No pre-existing files in the
new allocation were present; the initial status/diff was clean.

The final code passed **45 tests in 0.62 seconds** through the serialized
768 MiB launcher, with synthetic actions and temporary SQLite fixtures only:

```
bash /opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase10 \
  /opt/leon-v2-tools/test-results/phase7-tasks-tests-20260929c --mem 768M -- \
  python3 -m pytest -q tests/test_task_lifecycle.py tests/test_task_worker.py \
  tests/test_thought_intent.py \
  --junitxml=/opt/leon-v2-tools/test-results/phase7-tasks-tests-20260929c/tests.xml
```

JUnit SHA-256:
`16e114372204b716e91b4c0c23544c0aee8cd7846edc9b9b5eac3537770eed9b`.
Tested source manifest at `phase7-tasks-tests-20260929c/tested-source.sha256`
under the same test-results root:
`f6531125d4e772cf2cadd1a214270df2fb1186a69df740e4acf81e464ee8b68b`.
This evidence section was appended after the run; Python source was unchanged.

The first test invocation ran its assertions but exited nonzero because its
JUnit destination incorrectly used read-only `/results`. It is not a passing
receipt. The subsequent valid 44-test run was followed by a bounded-stop fix and
the 45-test final run. No production state, flags, services, providers or tools
were exercised. Live task continuation and full runbook Phase 7 acceptance still
require the integrator hooks above.

## UNKNOWN resource fence evidence, 2026-09-29

The follow-up branch `v2/phase7-resource-fence` uses integrated base
`eb99eb5e565c71336439f34fee59a421a10bb28c`. The clean checkout was reused after
preserving the conversation and original task branches. Original file bytes,
modes and base hashes are backed up under
`/opt/leon-v2-tools/test-results/task-fence-stage-20260929`.

All **48 task/worker/intent tests passed in 0.74 seconds** through the serialized
768 MiB launcher. The process-loss regression uses a temporary SQLite database
and an independent synthetic external executor that remains alive after the
worker exits. Conflicting claims remain queued after recovery and acknowledgment;
an unrelated background action completes. A separate regression checks old
UNKNOWN receipts after restart and prevents cancellation/failure from clearing
the fence. No production process or task was used.

```
bash /opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase10 \
  /opt/leon-v2-tools/test-results/task-fence-tests-20260929a --mem 768M -- \
  python3 -m pytest -q tests/test_task_lifecycle.py tests/test_task_worker.py \
  tests/test_thought_intent.py \
  --junitxml=/opt/leon-v2-tools/test-results/task-fence-tests-20260929a/tests.xml
```

JUnit SHA-256:
`2c1ffbb71daf87462699d4f29bf5ca5683cf7e01b70054317c23e9004c3b9f53`.
Adjacent `tested-source.sha256` SHA-256:
`5ac79b000cb951eb8a6a4847eb51d2bdab75ded7408641cd556fe17edb3934d7`.
This evidence text was appended after testing; Python source was unchanged.
