# Existing runtime owns supervised coding plans

TaskExecutionConfig may carry a typed TaskPlannerRuntimeConfig with trusted
scope and approval resolvers and an explicit selection predicate. Missing
configuration adds no planner. Initial task OFF opens no store or registry.
The existing task startup owner prepares the ingress resolver before starting
its worker pool, so retained approved children never race an absent resolver.
After authenticating an active call, the planner binds the exact installed
InferenceScheduler once. A cold optional planner without a scheduler leaves
standalone approved checks available. It never rebinds after replacement. It creates
no provider, database connection, worker pool or recurring planning loop.

Executive APIs register planning permission, advance one bounded inference,
show a proposal, approve an exact step through a separately resolved approval,
poll retained receipts, cancel, and acknowledge completion. Advance is blocking
and must run on an existing executor, never an ASGI/event-consumer tick. These
are trusted APIs; model text and an approval reference alone grant no authority.
Per-step expiry/revocation is enforced by durable ingress and the real child
grant. No HTTP endpoint or automatic approval path is introduced here.

Read/replace/check steps use the same TaskRuntime policy, resource ownership,
worker and result store as approved single checks. The runtime tick first asks
ingress to validate/checkpoint a planner child receipt, then acknowledges its
outbox sequence. TaskPlanner only reads retained receipts and advances the
parent checkpoint. Historical ownership permits receipt access after cancellation
or approval expiry; active policy resolves current parent and step authority.

Planner calls are counted before entering any runtime/planner lock. Retirement
closes admission, cancels inference handles and retains the operational store
until both worker actions and all planner calls/handles drain. It does not stop
or replace the shared inference scheduler. No runtime lock is held while waiting
for model output. Ingress receives a pure selection predicate because its own
lock ordering checks worker health before acquiring the result-store lock.

Tests exercise the actual installed executive, scheduler, ingress, policy and
workers with synthetic model/check fixtures: read/replace/check/completion,
post-install OFF-to-ON, approval lookup/idempotence, retained receipts after
parent cancellation, and blocked inference during retirement. Process isolation,
authenticated user-facing approval integration, automatic event selection and
live latency remain separate acceptance work.


## Owned operator approvals

TaskPlannerOperatorConfig installs explicit immutable PlanScope values and a
pure default-OFF selector. TaskRuntime constructs PlannerAuthority using its
existing task registry, binds the ingress and available installed scheduler
before workers may claim retained children, and owns all API calls through
retirement. Missing or unselected planning does not disable standalone checks.
The existing callback-based trusted configuration remains supported.

The captured planner handle exposes review and approve_review. Authenticated
approval binds exact proposal/review hashes and an idempotency key. The owned
registry creates the reference and lifetime; request/model timestamps and
approval references are not accepted by this path. Replay recovers an existing
child after polling, expiry or revocation without renewing its grant. This is
explicit supervised advancement, with no automatic planner or approval loop.
