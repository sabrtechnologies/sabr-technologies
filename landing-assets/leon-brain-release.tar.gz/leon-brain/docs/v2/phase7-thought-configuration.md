# Private thought startup configuration

`brain.cognition.thought_configuration.load_thought_configuration(path,
installation_principal=...)` reads one explicit private operator file. It returns
a frozen `ThoughtConfiguration(intent=ThoughtIntentRuntimeConfig(...),
articulation=ThoughtArticulationPolicy(...))`. The actual principal is supplied
by trusted installation startup. `expected_principal`, when present, checks
equality; it cannot choose the actual principal.

The loader is independent of `TaskExecutionConfig` and the task/check service.
It neither creates a canonical store nor enables a feature. Root installation
must call it only after explicitly selecting the new thought feature, retain
the exact typed configuration and existing canonical owners, and publish the
hook only after lifecycle ownership is attached. Missing or invalid selected
configuration must leave the selected path unavailable, without legacy retry.
No live configuration is installed by this change.

The proposed integration uses `LEON_THOUGHT_INTENT_CONFIG` as the path and the
separate startup/live `thought_intents` selection; the installer owns that
binding. Neither `memory_service` mode nor the existing runtime's shadow mode
confers authority. The canonical intent owner independently verifies the
existing SelfModel's stable identity tuple and existing KnowledgeStore handle
before writing or realizing an intent. Declared identity is not evidence that
those checks have succeeded.

## Exact schema

All shown fields are required except `expected_principal`. Producer is fixed
to `inner_voice`; provider routing, URLs, credentials, canonical paths, tools, history, live
mode and grant fields are not accepted. Use the installation's real reviewed
identity values; the following values are illustrative fixtures only.

```json
{
  "schema": 1,
  "expected_principal": "trusted-installation",
  "expected_identity": {"name": "Leon", "version": 2, "born_ts": 1750000000.125},
  "policy_revision": "phase7-reviewed-1",
  "quotas": {
    "max_snapshots": 4096,
    "max_total_bytes": 16777216,
    "max_realization_attempts": 4096,
    "max_realization_bytes": 16777216,
    "max_leases": 4
  },
  "articulation": {
    "local_model": "fixture-local:1b",
    "min_urgency": 0.25,
    "deadline_s": 15,
    "max_output_tokens": 128,
    "max_output_bytes": 2048
  }
}
```

Snapshot/attempt quotas are positive integers up to 100,000; each byte quota
is at most 64 MiB; leases are 1–16. Urgency is finite 0–1, deadline is finite
and greater than zero through 15 seconds, tokens are 1–256, and output bytes
are 1–8192. Boolean values do not count as numbers. Policy revision, principal
and identity name must be nonblank, control-free, and at most 200 UTF-8 bytes.
Identity version is an integer 1–1,000,000 and birth timestamp is finite and
positive. It is normalized by the canonical identity type without rounding.
The local model must be explicitly named, bounded to 128 ASCII characters, and
pass the transport's model-name validation. This is a declaration of the
operator-selected installed local model, not proof of daemon provenance or
network confinement; those remain deployment gates. The loader performs no
availability probe, model download, or inference.

`ThoughtConfiguration.sha256()` hashes a canonical descriptor containing the
actual principal, full expected identity, producer, revision, every quota and
every articulation policy field. It is private request-binding material, not
an authorization grant or public telemetry. Equivalent JSON formatting/key
order and the optional equality guard do not change the normalized authority.

## File and lifecycle boundary

The loader requires POSIX ownership/no-follow primitives. It accepts only an
existing unaliased absolute path, a current-user-owned directory without group
or other write permission, and a single-link regular file owned by that user
without group or other permissions. It creates no directories or files.
Directory-relative opens reject symlink components. Reads are capped at 16 KiB;
duplicate JSON keys, nonfinite numbers, unknown/missing fields, invalid UTF-8,
and file/parent changes during reading are rejected. Descriptors are closed on
success and failure. Unsupported platforms fail closed on explicit loading;
module import performs no configuration I/O or owner import.

File validation is a bounded startup snapshot, not a persistent filesystem
lock. Later file editing does not mutate the installed frozen configuration;
replacement/reload belongs to the root lifecycle installer. The loader makes
no claim about local transport enforcement, model behavior, budget accounting,
canonical persistence, or installed/live feature completion. Those remain
separate owner and scheduler contracts.

## Validation

The focused fixture suite covers exact real typed contracts, private descriptor
binding, trusted principal mismatch, schema and quota bounds, aliases/hardlinks/
special files, ownership/mode restrictions, short reads, changing files and
parents, descriptor cleanup and cold import. Tests use temporary private files
and no model, service, production configuration, or canonical store. Run only
through the unchanged serialized development sandbox launcher. Exact results
and dependency hashes are recorded in the accompanying takeover evidence.
