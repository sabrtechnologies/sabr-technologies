# Separate confined check-execution candidate

This candidate supplies a private Unix broker and parent bridge for one approved
`project.run_check` action. It neither installs/starts a service nor grants task
permission. The parent TaskWorker remains the only task/grant/resource owner;
the broker owns process execution and retained receipts only. There is no model,
planning loop, arbitrary request-selected command/path, local execution fallback
or automatic replay.

## Parent integration

Construct `VerifiedServiceEndpoint.from_operator_configuration` with trusted
`socket_path`, dedicated non-root `service_uid`, exact `cgroup_path`, pinned
`config_path`/`configuration_sha256`, `entrypoint` and optional `python_path`.
Then construct `CheckServiceBridge(endpoint=..., workspaces=...)`.
The frozen endpoint exposes these socket, config and entrypoint references for
the trusted parent loader; construction performs no effectful service discovery.

* `validate_spec(spec)` is the preview readiness gate and asks the service to
  recompute and match that exact canonical spec before approval.
* `authorize(action, task, spec)` checks exact canonical configuration and remote
  execution readiness. It never calls the parent permission callback.
* `bind_handler(parent_effect_authority)` returns the remote run-check handler.
  Bind this only after TaskRuntime owns its backend and durable grant policy.
  The callback must return literal True immediately before dispatch; absence,
  exception, mutation of the exact request or any other return denies.
  The final callback runs after the verified peer/hello exchange and immediately
  before execute bytes are attempted. It must check parent runtime/task/grant
  state only, without nested bridge RPC. Source/peer/config checks have already
  run at this boundary; a callback that recursively calls bridge authorization
  would block the service's single request owner. Revocation or expiry during
  hello therefore denies with known nonexecution. Only an attempted execute
  write starts the ambiguous-outcome path.

Keep ProjectActions' existing policy/canonical-spec owner. Replace only the
registered check handler. Compose structural bridge authorization with the
existing TaskPolicy in the parent. Never wire speech/barge-in, UI disconnect or
generic task cancellation to process interruption. Once dispatched, the action
drains; task cancellation stops future units.

Parent and service must use the same immutable installed source objects and
configured workspace. CheckContainment embeds its runner path, inode and digest
in generated Check argv, so making a second source copy would produce a different
canonical spec. The proposed entrypoint uses the same `/opt/leon-brain` code
objects, with a private source-only package loader that bypasses canonical brain
startup. Its transitive application modules are explicitly pinned; cached
application bytecode and unknown sibling imports are rejected. Standard Python,
stdlib and read-only system runtime directories remain operator-trusted software.

## Durable execution and uncertainty

The service recomputes the full canonical spec from its operator-configured
registry. It accepts only a committed RUNNING action/task with exact IDs,
arguments, fingerprint, resources, tier, scope and deadline. Authentication of
the parent process is required; a body `authorization_ref` is never permission.

SQLite uses synchronous FULL and an exclusive process lease. STARTED is committed
before the sole executor starts. At most one action executes, there is no queue,
and at most 256 receipts are retained. Duplicate exact requests only retrieve the
original row. Altered input under an existing action ID rejects. No receipt
purging, replay TTL or automatic reconciliation exists.

On startup every previously STARTED row becomes UNKNOWN. UNKNOWN resource keys
remain fenced indefinitely, independently of parent reconnect or outbox ack.
Unrelated canonical resources can still execute. The parent also retains its
normal UNKNOWN fence. If IPC is lost, the bridge sends only read-only lookups
for the exact action/digest; NOT_FOUND is uncertainty, not permission to repeat.

Existing CheckContainment authorization and result wrappers remain mandatory
inside the executor. Successful or executed-failure receipts require its trusted
PID-1 namespace-drain proof and backend process-group proof. Missing/ambiguous
proof becomes UNKNOWN. Shutdown closes admission and drains the active check
before releasing the broker lease or database. It does not kill committed work.
The service unit has a bounded eventual cgroup stop; an interrupted receipt stays
UNKNOWN after recovery.

## Authentication and readiness

Socket and directory ownership/mode are checked, and both sides use kernel Unix
peer credentials. The service accepts only its configured parent UID. The bridge
checks the dedicated service UID, stable PID start time, exact isolated command,
executable object, zero capabilities/no-new-privileges, source/config object
identity in the peer mount namespace, startup-compiled module manifest and a
fresh challenge. A claimed `ready` value alone never passes.

The client reads the actual target process cgroup and effective ancestor limits:
at most 768 MiB memory, 64 processes/threads and one CPU. The executor rechecks
the same actual boundary and the mandatory bubblewrap namespace probe before
effects. Leon's own larger SNN/model cgroup is untouched. Root-owned code/config,
exclusive service identity and operator-controlled cgroup membership are the
trust boundary; these checks are not remote attestation against malicious host
root or arbitrary hostile code already running as the dedicated service UID.

Frames are capped at 32 KiB, with total receive deadlines. Results are capped at
8 KiB (the check backend separately caps command output at 2 KiB). One bounded
socket request and one executor avoid thread-per-connection growth. Each check
retains its existing maximum 120-second outer process timeout, with finite IPC
recovery and shutdown allowances.

## Operator configuration and external gates

The JSON file has exactly these fields: `version` (1), `socket_path`,
`broker_path`, `client_uid`, `scope`, `root`, `checks`, `forbidden_roots`,
`shared_resources`, `source_sha256`. Each fixed check has exactly `name`, `argv`,
`cwd`, `timeout_s`; request bodies cannot override them. `source_sha256` maps
every `SOURCE_FILES` basename to its installed SHA256. The file itself is pinned
by the launch argument and parent endpoint, and code/config remain unchanged
for that service lifetime. The launch environment contains only the operator's
`LEON_CHECK_CONFIG_SHA256` value; it is not a grant or a runtime ready assertion.
Service JSON contains no secrets. Keep it root-owned, immutable for the service
lifetime and readable by the dedicated service UID (for example mode 0644).
The parent's separate `LEON_TASK_CONFIG` remains private mode 0600; its permission
rule must not be copied onto JSON that the unprivileged service needs to read.

Use disjoint directories: for example broker metadata in
`/var/lib/leon-v2-checks-broker`, private socket in `/run/leon-v2-checks`, and an
exclusively managed workspace below `/var/lib/leon-v2-check-workspaces`.
Forbid broker/runtime metadata, canonical state, parent task metadata and other
private workspaces. Configured forbidden roots must include the broker and socket
parents. The existing containment factory rejects overlap with the workspace.
The trusted parent loader must additionally verify that `forbidden_roots` covers
every actual canonical state root and the parent's task metadata directory;
example paths in this document cannot establish the deployment's real roots.

The systemd unit is a review artifact only. A dedicated non-root account,
appropriate workspace ownership, immutable installed source/config, filesystem
capacity policy, actual resource limits and working user namespaces must be
provisioned and reviewed separately. No account, unit, cgroup, source deployment,
flags or service start is performed by this candidate.

Current hardened test launcher blocks nested user namespace UID mapping and lacks
the required PID/CPU limits. The real containment fixture therefore remains an
explicit skip/fail-closed external gate. Synthetic broker/protocol/peer-parser
tests do not establish live namespace confinement or production readiness.

## Candidate verification

The unchanged serialized hardened launcher ran the service, bridge, containment,
project-action, lifecycle and worker tests: **134 passed, 1 skipped, 19 subtests
passed**. The one skip explicitly reports blocked nested user namespaces; it does
not count as containment acceptance. Synthetic peer fixtures and a real Unix
socket with mocked operating-system identity checks verify protocol behavior,
not a live service identity or namespace boundary.

The receipt is
`/opt/leon-v2-tools/test-results/check-service-tests-20260929b/tests.xml`, SHA256
`cb58e738c964448ce85833e3e693d6ffc53e876cab718144cc2a8dece44670a1`.
The adjacent `tested-source.sha256` records the tested application, test and unit
bytes; its SHA256 is
`e0c078d7b8f3632aa5a02d187b83f050eeaa36a2c017c9a38fa80b2c4759f0ca`.
This documentation-only evidence update followed that run.

`systemd-analyze verify` also exited 0 through the same hardened launcher for the
unit artifact. It emitted warnings about two unrelated pre-existing host units
(a DNS watcher and a terminal keeper), not this unit. No unit
was installed or started. Dedicated UID/workspace provisioning, actual service
peer visibility and cgroup limits, and mandatory working bubblewrap confinement
remain external acceptance gates.
