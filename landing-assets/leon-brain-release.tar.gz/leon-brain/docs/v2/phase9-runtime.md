# Phase 9 provider runtime candidate

`brain.cognition.provider_runtime` connects the existing ProviderRouter to an
already admitted InferenceScheduler call. It creates no scheduler, model queue,
thread, credentials, provider adapters or budget ledger. OFF/SHADOW construct no
router and cannot run inference. ON/CANARY require explicit installed ownership
and a reviewed immutable policy. The root owns scheduler/responder/startup/live
flag wiring; none is changed in this candidate.

## Explicit policy and ownership

`ProviderPolicy(revision, rules, scopes, limits, per_capability=())` is frozen.
Each `RequestScope(site, group, channel)` must match the admitted request exactly.
Each frozen `ProviderRule` includes the exact existing `ProviderSpec`, positive
full-call input/output bounds, evidence reference, monotonic validity deadline,
billing kind, and explicit verification markers for billing, full-call bounds,
transport cancellation, no-tools behavior and tool drain. Defaults are unverified.
These are root-supplied review attestations, not verification magically performed
by this module. Empty, expired, inconsistent or unknown policy stays unavailable.

The exact adapter spec must retain its real capabilities, model, price and
no-tools contract. Adding a flag cannot grant vision, tools, history support or
safe cancellation. Unknown pricing is never inferred from a local/subscription
label. A subscription rule requires an explicit reviewed zero incremental cost
contract; this does not claim that a subscription is free or that limits vanish.
Full-call bounds cover hidden prompt material, reasoning and every tool/model
round, not just visible text. Both the adapter's reported bounds and the frozen
reviewed bounds must cover the request.

Root injects its already-created `BudgetLedger`, with exactly the frozen global
and capability limits. The runtime never opens, closes or invents its path.
OFF can therefore receive no ledger and performs no ledger I/O. Execution checks
limits before reservation; mutations cannot silently increase approved limits.
One installed owner belongs to one scheduler. `install(scheduler)` returns false
on conflicting ownership. Retirement requires `stop() -> True`, then
`uninstall()`. Neither method stops the scheduler or closes the injected ledger.

## Admitted per-call seam

```python
owner = ProviderRuntime(policy=reviewed_policy, adapters=existing_adapters,
                        ledger=existing_budget_ledger, mode="off")
assert owner.install(existing_scheduler)
```

The owner mode is read-only. Explicitly retire and replace the owner to change
mode/policy; a live OFF transition first quiesces the existing owner. Root's live
flag hook must not mutate this module's private fields.

For a selected ON/CANARY scope, root's existing scheduler provider callback can
bind the request **after prepare/coalescing** using the actual prepared options:

```python
def admitted_provider(req, prepared_prompt, prepared_kwargs, cancel_token):
    callback = owner.provider_for(
        req, provider_id=explicit_provider_id, capabilities=explicit_capabilities,
        context=existing_rendered_context, max_output_tokens=explicit_limit,
        legacy_kwargs=prepared_kwargs, questions=typed_questions_or_none,
        deep=explicit_deep_policy,
    )
    yield from callback(req, prepared_prompt, prepared_kwargs, cancel_token)
```

Alternatively assign the returned callback to `req.provider` before submission
when prepare will not change options. The callback matches the exact request
object, immutable request identity/trace/scope/tools/history/deadline/kind,
prepared options, installed scheduler, actual scheduler worker thread, worker
context, active job and actual token. A worker-context boolean alone is not
authorization. Direct calls, another request's token, privilege mutations or
second invocation of the same callback fail before provider dispatch. Root must
also not recreate a callback to reuse the same admission: the runtime remembers
the last admitted token and refuses a second provider call for that slot. Root must
not catch a dispatched error and replay it through the legacy or paid path.

Prompt/context and JSON option snapshots remain outside identity ownership.
Non-JSON opaque options require an explicit root shim; they are refused rather
than silently dropped. Conflicting `allow_tools`, `persist_history` or `channel`
options cannot override admitted policy. Root shims must preserve actual session,
history, recorder, cancellation and original tool dispatch behavior without
calling the routed facade recursively. This candidate does not migrate those
responsibilities into the provider router.

One ProviderRouter is lazily constructed for execution. Its bound adapter views
use a request-local selection context, so only the explicitly selected provider
is eligible. No fallback order, second model call or paid escalation is chosen
by model output. Health/budget/provider failure terminates that routed call;
other configured providers are never tried implicitly. Deep-tier policy still
requires the existing explicit deep/capability contract.

## Usage, event envelopes and cancellation

The exact `ProviderEvent` is returned unchanged, including its original `.raw`
tool-bearing event. Tool use/confirmation/result envelopes require that original
raw event; adapters cannot claim tool support with an incomplete payload. Root
consumer adaptation must preserve existing raw tool fields and dispatch policy.
This module does not dispatch tools or synthesize confirmation events.

Only typed observed `Usage` is passed to the router. No usage is inferred from
raw CLI dictionaries, character counts, desired output size or a done event.
The existing router settles to actual counts only for a completed call whose
adapter explicitly reports final full-call usage. Missing/partial/failed or
cancelled accounting retains the full conservative reservation. The ledger can
record actual reported usage above an estimate; the next admission checks its
remaining limits. Such an overrun is a failed bound assumption, not permission
to invent a smaller usage number.

Cancellation continues consuming committed tool results while suppressing later
speech/status through the existing router/scheduler contract. All pending tool
results retain their raw envelopes. The runtime's active ownership remains
until producer drain, iterator close and budget settlement complete; another
scheduler job cannot overlap that slot. `quiesce()` immediately refuses new
calls. `stop()` cancels only tokens in this owner's active calls, returns false
while they drain, and never closes shared adapters, channels or the ledger.
Cancellation callbacks themselves must obey the existing prompt/bounded contract.

## Current verified limitations

The existing Claude/Ollama `LegacyAdapter` requires explicit input/output bounds;
output is None when no full-call bound is configured. It wraps original events
but does not convert raw usage into typed final Usage. Claude CLI deadline and
output-byte limits do not demonstrate a full billed-token cap. Consequently CLI
routing remains unavailable until real reviewed bounds/billing/shim guarantees
exist. Do not set arbitrary large numbers just to bypass this gate. Missing
no-tools enforcement or pending-tool drain review also prevents admission.

Jev is optional and `DECISION` only: mixed language/tool capabilities, tool use,
or persisted conversation history are refused. Typed decision payloads remain
advisor data. Their confidence is neither calibration evidence nor action
authorization. This module instantiates no Jev transport, reads no credentials,
and makes no paid request. Policy and actual configured adapter must explicitly
authorize any later decision call.

Public stats contain lifecycle/counters only, with no prompts, contexts,
credentials, trace IDs, tool payloads or invented usage totals. The ledger is the
accounting authority; actual provider evidence remains required for runtime
enablement. SHADOW only reports ownership/readiness metadata and never duplicates
legacy inference for comparison.

## Validation and root integration gates

Tests run the actual scheduler/router over fake generators and in-memory fixture
ledgers. They cover admission identity, frozen policy, unavailable bounds/cost,
no implicit fallback, typed usage, raw tool envelopes, multi-result cancellation
drain and retention until retirement. No server, model or production store is
started. VPS tests must use the serialized launcher:

```sh
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase6 /opt/leon-v2-tools/test-results/phase9-runtime-UNIQUE --mem 768M -- python3 -m pytest -q tests/test_provider_runtime.py tests/test_providers_core.py tests/test_providers_budget.py
```

Root must supply reviewed provider/billing/bound evidence, configured adapters,
an isolated explicit budget sidecar, scope allowlist, startup/retirement and live
mode hooks, correct prepared context/options, and consumer raw-event adaptation.
No production deployment, feature flag, state, auth or service change is made by
this candidate. No real pricing, credential, capability or performance claim is
established by synthetic tests.

Scoped validation: 100 tests passed in 6.23s through the serialized 768M
sandbox at `phase9-runtime-20260929-c`, covering this runtime, provider
core/budget/HTTP/swap and the existing inference scheduler. Cancellation usage
counters observe typed events before delivery suppression; settlement remains
conservative. No executable code changed after that run.
