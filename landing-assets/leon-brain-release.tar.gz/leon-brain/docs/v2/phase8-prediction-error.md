# Phase 8: bounded prediction/outcome alignment

This implements runbook section 12 in `brain/cognition/prediction_error.py`, the
exact path assigned by FILE_OWNERSHIP.md. The component defaults to **off** and
supports **shadow** only. It is an observer and event producer, with no executive,
tool executor, model invocation, background thread, network call, canonical-store
write, neuron update, or schema migration.

The development branch is `v2/phase8-prediction-error`, based on
`9f070d26eeec4b53ed35905fe2878fb1e06f93bc`, in
`/opt/leon-v2-worktrees/phase8`. Only the new module, Phase 8 tests, and this
document are changed. Source captures and hashes are retained in the local
`phase8-candidate/before` directory; original sources remain in the base commit.

## Existing owners and important evidence limits

The source inspection found these existing mechanisms:

- `cognition/world_model.py`: predicts success probability, latency, side-effect
  probability, and data-depth confidence from hand-set priors and episode rows.
  The adapter accepts the existing `Prediction` object. It does not construct a
  new WorldModel, query its database, retrain it, or introduce another predictor.
- `cognition/episodes.py`: stores predictions/outcomes, computes surprise and
  Brier score; existing storage and learning remain unchanged.
- `brain/self_model.py`: predicts the next internal state using the existing MLP,
  compares it on a later tick, updates weights, and injects its own ACC signal.
  None of that logic or state is changed. The shared layer can project its
  existing scalar predictions/observations using explicit per-feature scales.
- `brain/body_deep.py:ActiveInference`, used by embodiment/pc_body: compares
  need predictions with current values, updates a running estimate, and produces
  existing drive/motor/autonomic outputs. Those remain its owners. Capture a copy
  of the pre-update forecast for annotation; copying its post-update predictions
  would contaminate the comparison. No `prediction_engine` source owner was found.
- `cognition/v2_publish.py` already owns tool prediction-error child emission
  (`PE_SURPRISE_THRESHOLD`, D15). `ExecutiveController.plan_event` already routes
  PREDICTION_ERROR and LEARNING_INTENT. The event bus has one runtime consumer;
  this module must not drain that queue independently.

Crucially, `CognitionLoop.record_tool_call` currently calls WorldModel.predict
after it receives the tool result. Those records are retrospective, even though
the episode schema calls the field a prediction. They cannot establish prospective
calibration. The new comparison excludes them from measured calibration unless a
separate trusted pre-dispatch capture is supplied and its timestamp precedes the
reported action start. Existing historical metrics are not rewritten or relabeled.

No live evidence was collected by this development work. Tests use fixtures;
their expected scores demonstrate arithmetic/protocol behavior only. Source words
such as "calibrated", "Bayesian", "free energy", or self-awareness do not establish
empirical validity or subjective experience.

## Record and comparison contract

Every prediction and outcome carries `prediction_id`, `request_id`, `action_id`,
`trace_id`, and `clock_id`. IDs must be explicit, unique, and never recycled. An
action ID identifies one invocation, not a tool name. A prediction ID additionally
distinguishes different domain/model forecasts for the same action. Joins never
guess from temporal proximity, user text, or similar tool names.

The root composition owner supplies a process/clock-domain ID. Prediction capture,
action start, and outcome measurement use the same monotonic clock. A foreign or
restarted clock domain is rejected; stored monotonic timestamps must not be compared
across processes. Prediction records include an explicit deadline, confidence,
uncertainty, information-gain estimate, provenance, and source model/method.

Supported metrics are deliberately explicit:

| Kind | Error | Additional evidence |
| --- | --- | --- |
| bernoulli | absolute probability residual against a strict boolean outcome | squared residual/Brier |
| numeric | absolute native-unit residual, normalized by a positive supplied scale and clipped to one | raw residual and scale retained |
| categorical | zero for equal type/value, one otherwise | original bounded scalar values |

The overall error is the weighted mean of normalized component errors. Scales and
weights are design choices, not evidence that different domains have scientifically
equivalent error units. Inputs are limited to 32 bounded scalar metrics, finite
numbers, and short category/identifier strings; no audio, images, document text,
large nested state, or media arrays can enter this contract.

The standardized PredictionErrorPayload contains all runbook fields plus explicit
IDs, clock/timing information, per-metric errors, uncertainty, provenance, method,
and calibration eligibility. A measured comparison needs both producer provenance
tags and an outcome `evidence_ref`. Prospective eligibility additionally requires
`prospective=True` and `predicted_mono <= action_started_mono <= observed_mono`.
These are trusted producer attestations and references, not independent evidence
verification performed by the observer.

`calibration()` reports retained, eligible Bernoulli pairs separately by domain,
source model, prediction method, and metric: sample count, Brier score, and populated
reliability bins. Missing evidence yields no score. Simulated, retrospective,
unverified, cancelled, incomplete, timed-out, and missing-start-time cases cannot
enter that summary. Brier describes predictive accuracy; it alone proves neither
calibration nor improvement. The result explicitly leaves `calibrated=None` and
`improvement_established=False`.

## Bounded lifecycle and transport behavior

The observer accepts final outcome records, not streaming fragments. Cancelled or
missing outcomes are terminal without invented failure/error values. A completed
record with absent/invalid required measurements is terminal and unscored. Real
tool failure is represented by a measured boolean `success=False`.

Outcomes may arrive before their prediction event. Pairing waits within the bounded
horizon and verifies identity and measurement timestamps. A configurable arrival
grace allows bus delivery after the outcome deadline when the outcome itself was
measured within that deadline. After deadline plus grace, an unresolved prediction
becomes `missing_outcome`; an unpaired outcome becomes `orphan_outcome` after the
configured horizon. Late data remains diagnostic and does not retroactively invent
a result. Explicit `sweep()` runs from the existing runtime's periodic work; there
is no additional timer/thread.

Default capacity is 1024 records, retention one hour, prediction horizon five
minutes, and arrival grace up to 30 seconds. Completed/cancelled/error records remain
as deduplication tombstones throughout the acceptance window. Full capacity rejects
new IDs instead of evicting a live record or deduplication slot. Expired input is
rejected, so removing old tombstones does not admit replay of their old timestamps.
Duplicate/conflicting delivery cannot score, publish, or update a skill twice.

Publication uses stable event IDs and retries only retained advisory events when
`retry_publications()` is called. A sink must return exactly `True` to acknowledge.
Rejected/failed events remain pending until retention expires, when a loss counter
records them. The sink should deduplicate IDs. This shadow buffer is process-local;
it does not claim crash-durable delivery, and must not become the sole durable
learning record. Root can retain the same annotations/events through the existing
event/episode persistence owner before any authoritative use.

## Curiosity and skill decompilation

Curiosity score is exactly `error * uncertainty * expected_information_gain`.
At the configured threshold, `budget.available("curiosity") is True` permits a
shadow LEARNING_INTENT proposal. A budget exception, absent budget, or arbitrary
truthy return cannot grant permission. This does not reserve inference capacity or
execute anything; ExecutiveController, the scheduler, user priority, and existing
action policy still decide whether work may happen.

The intent specifies the required investigation order:
memory/logs/local state, cheap tools, model reasoning, external research. The
existing executor reports each authorized step with `record_investigation`, an
evidence reference, and its new uncertainty estimate. The recorder enforces order
and reports whether uncertainty fell, including negative progress. It will not
advance after uncertainty reaches zero. Uncertainty reduction is based on supplied
estimates and evidence; it is not an invented scientific measurement.

For a supplied `skill_id`, three consecutive eligible measured action failures
produce `skill_guard(...).requires_deliberation=True` and a lower confidence ceiling.
The guard orders retained observations by measurement time, is advisory only, and
never modifies SkillMemory or Procedure records. It persists in the bounded guard
map after comparison retention expires and is not cleared by one later success.
The existing planning/skill owner applies the guard to the next attempt and decides
when correction/relearning supports `acknowledge_skill_review(..., evidence_ref=...)`.
If the guard map is full, untracked skills conservatively require deliberation.
Restart durability belongs to the existing SkillMemory owner; the root integration
must persist any accepted confidence/decompilation decision there.

## Concrete root-owned integration hooks

No shared source hook is edited in this commit. The following changes require the
root integrator's ownership and review:

1. **Pre-dispatch tool capture:** at the existing action boundary, call the existing
   WorldModel before dispatch, then project its returned Prediction:

   ```python
   observer = PredictionErrorObserver(
       mode="shadow", clock_id=process_clock_id,
       publish=existing_runtime.publish, budget=existing_budget,
   )
   record = from_world_prediction(
       existing_prediction, latency_scale_ms=reviewed_latency_scale,
       prediction_id=prediction_id, request_id=request_id, action_id=action_id,
       trace_id=trace_id, clock_id=process_clock_id,
       predicted_mono=capture_time, deadline_mono=outcome_deadline,
       prospective=True, evidence="measured", skill_id=procedure_id,
   )
   ```

   Publish `prediction_v1=record.to_dict()` as an annotation on the existing
   appropriate event; an existing BACKGROUND_THOUGHT with
   `kind="prediction_captured"` is supported when a dedicated action event is
   unavailable. Do not create another executive or a competing WorldModel.
2. **Outcome annotation:** add `outcome_v1=OutcomeRecord(...).to_dict()` to the
   existing TOOL_RESULT/REFLEX_RESULT, using the same IDs, actual action-start
   and observation timestamps, boolean success, measured latency, provenance,
   and an episode/tool-result evidence reference. Cancellation emits a cancelled
   record, never a fake tool failure. Avoid duplicate call sites recording one
   physical action under multiple new IDs.
3. **Single PE owner:** for annotated tool invocations, replace/disable the old
   `v2_publish._b_cognition_tool_closed` child emission atomically when installing
   this path. The observer refuses events carrying `pe_child=True`; unannotated
   legacy traffic stays with its current owner. Append-only SITES changes alone
   are insufficient for this ownership transition, so they are deliberately left
   to root rather than silently duplicating D15.
4. **Runtime observation:** the existing runtime consumer calls
   `observer.observe_event(event)` once (it is fail-open and ignores its own
   children), calls `sweep/retry_publications` from existing bounded maintenance,
   and continues normal ExecutiveController routing. No second bus consumer.
   Root may extend runtime's safe payload-reference allowlist with the IDs/domain/
   source/error scalars; do not add raw observed content to general logs.
5. **Other domains:** annotate pre-update SNN/ActiveInference forecasts through
   `from_state_prediction(..., scales=...)` and subsequent scalar observations.
   Scene transitions can use categorical expectations; goal milestones use
   explicit expected outcomes and milestone/action IDs. Preserve each existing
   specialized model's state, weights, cadence, and update ownership.
6. **Skill and investigation consumers:** the existing executive/procedural owner
   reads `skill_guard` before automation, applies accepted confidence changes via
   its existing store, and routes guarded attempts back to deliberate planning.
   Authorized curiosity workers report evidence through `record_investigation`;
   every model step still acquires the existing scheduler's admission.

Before any authoritative use, validate those real call-site timings/IDs and single
publisher ownership, verify retained events reach existing episode/autobiographical
paths, and gather a prospective measured cohort with baseline/comparison protocol.
No scientific improvement, calibration result, or live learning effect is claimed.

## Validation

The required isolated command is:

```text
/opt/leon-v2-tools/sandbox_run.sh /opt/leon-v2-worktrees/phase8 /opt/leon-v2-tools/test-results/<unique-name> --mem 768M -- python3 -m pytest -q tests/test_prediction_error.py tests/test_curiosity_prediction_error.py tests/test_events.py tests/test_event_bus.py tests/test_executive_dry_run.py
```

Final run `phase8-prediction-20260929-c` passed 137 tests in 1.08 s, including
the action-start-time eligibility refinement. Tests exercise numeric/categorical/Bernoulli errors, all five
domains, duplicate/concurrent/out-of-order delivery, foreign clocks/identity,
cancellation/missing outcomes, bounded retention, retry, evidence exclusions,
curiosity ordering/budget, skill decompilation, and the actual existing EventBus
and ExecutiveController dry-run route. No experiments or live cognition were run.
