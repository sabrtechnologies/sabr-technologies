# Phase 10: compatible pacing, derived buffers, and profiling

This candidate changes neither canonical topology nor neuron count, learned
weights, persistence schemas, or neural update order. `simulation_loop` remains
the only production `Brain.step()` owner. No production state, services, flags,
or deployment changed during development.

## Interrupted work preserved

The worktree started on `v2/phase10-snn` at
`9f070d26eeec4b53ed35905fe2878fb1e06f93bc`, with one untracked file:
`tools/v2/snn_profile.py`, 31,216 bytes, mode 755, SHA-256
`b70bc4e03b442754c32a08fa50f799faa268cd150171ebbff8c2db12e909123b`.
Its exact bytes/mode are preserved in
`/opt/leon-v2-tools/test-results/phase10-interrupted-20260929/dirty-files.tar`.
That directory also contains base HEAD, Git index/base object hashes and modes,
NUL-delimited status/path lists, staged/unstaged/combined binary diffs (empty for
the initially untracked file), source SHA-256/mode records, and a backup manifest.
No reset, stash, discard, or replacement of the interrupted work was used.

The existing profiler was extended and hardened: sandbox admission is mandatory;
scratch/output paths are restricted; state-copy symlinks cannot escape; missing
weights, traces, or regions invalidate a copied-state profile; rejected pathways
are never randomly regenerated; temporary probe directories are unique; and
instrumentation is restored on exceptions. Its original component wrappers,
serialization measurements, microbenchmarks, cProfile path, and pacing model
remain available. Copied-state mode still uses the existing loader, including
its existing normalization and partial historical persistence semantics; it is
not a claim that every neuronal parameter/RNG state was historically persisted.

## Integrator-owned hooks

`BrainActivityController` is pure scheduling policy. It owns no brain, thread,
sleep loop, timer, persistence, or step call. Instantiate behind the activity
flag, initially with `experimental=False`. Supply the configured `LEON_SIM_HZ`
as idle_hz, existing active_hz=60, and existing yield floor/fraction. Call
`decide(has_input)` at the same point, with the same signal the existing loop
uses; use its target_seconds and `sleep_seconds(elapsed, decision)`. Measure
elapsed time monotonically. Do not move the input observation during the initial
compatibility integration: the current code observes pending input after step
has usually cleared it. Correcting that behavior is a separate pacing change.

REST/ATTEND initially retain existing rates (defaults 20/60 Hz). A bounded
`request_burst(seconds)` changes the mode label, but changes no rate unless both
enabled and experimental are true. The experimental rest/attend/burst rates
are explicit configuration. No expensive neural, STDP, safety, workspace, or
self-model tick is skipped; semantically safe event-based tick gating requires
its own profile and acceptance evidence.

Optional `DerivedStepBuffers(enabled=True)` can be attached as
`brain._v2_step_buffers` behind a separate default-off flag. The step hot path
reuses a float32 spike conversion per source per tick and a modulation output
per region. Cache epochs advance each step, independently of restored step_count;
shape/dtype changes rebuild only scratch arrays. The class is single-simulation-
thread scratch and must not be shared across brains. Disabling/clearing it drops
only derived data. No new serialized fields or state migration are needed.

The baseline propagation path also avoids a redundant float32 copy when its
input already has that dtype and avoids copying the fresh sparse-matvec result
again. It preserves output ownership and all arithmetic. Step duration tracking
uses perf_counter instead of wall-clock subtraction. No neuron/STDP kernels,
synapse generation, pruning policy, or Rust implementation changed.

## Fixture tests and limits

All execution goes through the serialized hardened sandbox with 768 MB, disabled
network, and no new dependencies. The profiler's `--synthetic` mode creates a
small, explicitly seeded network using existing region/synapse/neuron kernels.
Its entropy implementation is a fixture PRNG, never a hardware/quantum service.
It attaches no real body, sensory, workspace, or self-model service. Serialization
uses actual existing save/state-tick functions redirected only to temporary
fixture paths. No saved Leon state is read or written in this mode.

Tests cover exact compatibility pacing/overrun behavior, bounded bursts and two
explicit experimental gates, invalid rates, buffer reuse/resize/dtype/ownership,
unchanged synapse indices/weights, numeric/RNG trajectory parity, and old-format
checkpoint load/save compatibility. The paired profile alternates reference and
candidate order from identical seeded fixtures, comparing numeric state every
step. It exits unsuccessfully on a parity mismatch and preserves timing results
even when the candidate is slower.

The initial 1,024-neuron/41,692-synapse fixture profile measured propagation at
24.4% of instrumented step time; existing Rust neuron, STDP, and batch kernels
were available and active. This motivated measuring conversion/output allocation
changes, not replacing Rust or sparse/STDP algorithms.

The paired candidate run (40 steps, same 1,024-neuron fixture, existing Rust) found
exact numeric state equality every step. Reference mean was 1.1477 ms versus
candidate 1.1605 ms; p95 was 1.6105 ms versus 1.4921 ms. These small, shared-host
synthetic measurements do **not** establish a speedup. Keep derived buffers and
experimental rates disabled until representative copied-state/live acceptance.
The separate instrumented runs are not directly comparable speed benchmarks.

No live 100K timing, live saved-state round trip, substantive workspace/self-model
tick cost, or real sensor/server-loop overhead was measured. Copied-state mode
provides those optional measurement hooks but was not run against Leon's state.
Further sparse/event-driven updates are deliberately absent: the runbook requires
representative profiling and semantic evidence before that experiment.
