# Sensory runtime and shadow dashboard status

The existing startup owner passes the already-loaded `brain.persistence.SAVE_DIR`
to V2 installation. No checkout-relative state location is inferred. The live
`sensory_hub` flag defaults OFF; the configured sensory gate also applies. All
enabled modes remain SHADOW. Existing captures and response context are unchanged.

The existing simulation tick makes a content-free projection at most once per
second. A contended scene lock returns unavailable immediately. Dashboard readers
copy only this cached metadata, refuse it after three seconds or owner replacement,
and recheck pause state. No caption, transcript, entity label, brightness, path,
raw confidence or context text is published. Evidence ages and occupancy explicitly
distinguish unknown/stale observations from a freshly observed empty room. No
status read captures a frame, calls a model, writes memory or starts a thread.

The sensory change publisher is registered in both exact-site acceptance fixtures.
Combined runners now include sensory lifecycle/status and the durable task tests.
The latter candidate is integrated but the executive/tool/reconnect bridge is
still pending; these registrations are not a claim of live task concurrency.

The scheduler additionally exposes `in_worker_context()` for admitted transport
adapters. It is a thread marker, not authorization; each adapter must also check
its own admitted request token. Local conversation and spontaneous speech groups
are registered OFF for the separate caller migration.

Live parity, capture latency, sensor provenance and continuity remain rollout
gates. No production flags or services change as part of this commit.
