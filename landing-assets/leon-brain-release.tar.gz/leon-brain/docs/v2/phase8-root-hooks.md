# Prospective observer runtime ownership

`LEON_PREDICTION_ERROR` and the live `prediction_error` flag both default OFF.
The existing install path cold-binds one observer before its event consumer
starts. All enabled observer modes remain SHADOW. There is no model request,
new thread, event consumer, canonical writer or curiosity publication budget.

The existing runtime tick owns observer sweeps and readiness. Each dequeued
event reaches the observer exactly once, including text later parked for
executive planning. Observer errors leave that legacy planning path intact.
The process clock ID is stable across runtime replacement in the same process.

Zero-wait shutdown only quiesces. Worker cleanup or a positive retirement retry
retires the observer and its publisher binding. A draining callback or refused
binding release retains ownership and blocks runtime replacement.

Source forecasts captured after execution remain retrospective. Production
before-dispatch instrumentation and its explicit measurement contracts are
still pending. Synthetic lifecycle/event tests do not establish predictive
accuracy, calibration, learning benefit or live acceptance.
