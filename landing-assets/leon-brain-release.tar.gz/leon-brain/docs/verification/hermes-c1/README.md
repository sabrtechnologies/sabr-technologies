# C1 reviewed guidance

Source scope: two inert adaptations in `tools/native_jobs/hermes_guidance.py`,
attribution under `tools/native_jobs/guidance/`, and foreground-query delivery.
No discovery, upstream script execution, plugins or tool-policy changes.

**Read-only reviewer: start with [REVIEW_PACKET.md](REVIEW_PACKET.md).**
It maps the exact [C1 acceptance excerpt](ACCEPTANCE.md) to committed, sanitized
[receipts](receipts/manifest.json): sandbox commands/results, baseline reproduction,
genuine review, source and skill hashes, remote/CI readbacks and the ledger scope.
These files are inside the job root and require no private-state access.
Do not run writing tests from a read-only review; inspect the recorded sandbox
execution instead. Private-ledger preservation is explicitly a worker attestation,
not a claim that the restricted reviewer independently read protected state.

Full private evidence and final delivery status are retained in the main checkout:
`/opt/leon-brain/brain_state/private_out/hermes-c1/REPORT.md`.
That report distinguishes sandbox fixture checks, genuine Hermes review, source
integration and runtime activation. The full private report, ledger, prompts,
memory and auth configuration are never committed; only allowlisted sanitized
verification receipts are included here.

The regression entry point is `tools/native_jobs/tests/test_hermes_guidance.py`.
Use the mandatory linked checkout and sandbox for VPS tests, with a dedicated
results directory. Existing native, conversation and runs-feed tests also apply.
The citation fixture is synthetic supplied evidence for semantic review, not an
automated citation validator. No laptop verification is claimed.
