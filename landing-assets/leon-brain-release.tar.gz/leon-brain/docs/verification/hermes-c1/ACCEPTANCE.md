# Canonical C1 acceptance excerpt

This is only the C1 section of the authorized candidate review. Other candidates,
private state and the full canonical ledger are omitted. The protected source
file SHA-256 at readback is `00a09652bb8461ca038b687b1af603effdfbe5b8e50834442f600415be97709a`.
The canonical item-4 selection authorized this implementation; recommendation
wording below describes the earlier research stage, not a new approval request.

### C1 — Adopt later: two reviewed Hermes skills

**Source/version/license.** [systematic-debugging 1.1.0](https://github.com/NousResearch/hermes-agent/blob/e6cf2a9b1e8f98d40408b09a9a55993c8459b4b4/skills/software-development/systematic-debugging/SKILL.md) and [grounded-citations 1.2.0](https://github.com/NousResearch/hermes-agent/blob/e6cf2a9b1e8f98d40408b09a9a55993c8459b4b4/skills/research/grounded-citations/SKILL.md), both declaring MIT; the [Hermes LICENSE](https://github.com/NousResearch/hermes-agent/blob/e6cf2a9b1e8f98d40408b09a9a55993c8459b4b4/LICENSE) is MIT. The debugging skill credits an adaptation from obra/superpowers. Consult the authoritative [skills documentation](https://hermes-agent.nousresearch.com/docs/user-guide/features/skills); the matching pinned Markdown snapshot is retained.

**Baseline/gap and rationale.** Skills already exist upstream, but pairing disables them. Recommend two explicitly reviewed, pinned guidance adaptations rather than an open-ended skill marketplace. Expected benefit: more reproducible investigations and citations whose provenance can be checked. No numerical productivity claims from the skill are accepted as evidence.

**Compatibility/permissions.** Both advertise Linux/macOS/Windows. Enabling upstream skills needs an explicit toolset/hook change in a future job. External directories are not read-only boundaries. `systematic-debugging` includes delegation and test commands; `grounded-citations` relies on a writing Python ledger script and suggests optional installs. Therefore unmodified automatic loading is **not** the bounded proposal. Start with clearly labeled guidance adaptations; omit delegation, installs and script execution, preserve attribution, and state that upstream automated citation validation is unavailable until separately audited. Respect VPS test-location rules.

**Security/privacy.** Skill instructions are untrusted inputs: prevent name shadowing, arbitrary discovery, shared writes and commands that transmit project data. Loading text does not authorize its actions. Public lookup terms must exclude private state.

**Maintenance/benefit.** Low-to-medium: review two snapshots at deliberate upgrades; keep adapters and permission tests aligned. Benefit is consistent process without another service.

**Bounded acceptance.** A disposable session sees exactly these two approved guidance entries; unrelated skills, installs, delegation and writes remain refused. A seeded defect yields a specific failing reproduction before a fix; a five-claim citation fixture flags an invented source and unsupported claim. Record tool denials and skill hashes. These are future tests, not performed here.
