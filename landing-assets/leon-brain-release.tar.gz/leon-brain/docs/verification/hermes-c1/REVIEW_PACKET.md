# C1 reviewer-readable verification

The outer review found an evidence-access gap, not a source defect: its guard
could not open the canonical candidate review or durable private report. This
packet supplies their relevant, sanitized verification material inside the
source tree. No guard, tool permission or reviewer write restriction was changed.

Start with [ACCEPTANCE.md](ACCEPTANCE.md), the isolated canonical C1 section.
[authority.json](receipts/authority.json) records its source hash and the worker's
readback of C1 selection in item 4. No unrelated candidate or ledger text is copied.

## Exact acceptance and evidence

| Canonical requirement | Result and receipt |
| --- | --- |
| Exactly systematic-debugging 1.1.0 and grounded-citations 1.2.0, pinned and attributed | Both derive from `e6cf2a9b1e8f98d40408b09a9a55993c8459b4b4`. Upstream and adaptation hashes are in [session-guidance.json](receipts/session-guidance.json); source-file hashes are in [source.json](receipts/source.json). Nous Research MIT terms, Hermes Agent, Teknium and obra/superpowers attribution are retained in source. |
| Disposable session sees exactly two guidance entries | The foreground launch test supplies only the fixed bundle. Independently of that spy, the worker read the real Hermes review session DB and found exactly two entries matching the entire rendered bundle. The selected session metadata, query/bundle hashes and actual tool names are in [session-guidance.json](receipts/session-guidance.json). |
| No arbitrary discovery, name shadowing, plugins or permission expansion | The source test places malicious project/environment skill paths and a symlink, then asserts the adapter performs no file access or process creation. Real review config had empty skill auto-load/external dirs/plugins/MCP, disabled skills and a fail-closed hook. |
| Unrelated skills, installs, delegation, writes, scripts and private-data transmission refused | [denials.json](receipts/denials.json) contains **44 actual hook refusals**: 22 synthetic inputs under both coding and research policies, including indirect `tool_search`, `tool_describe` and `tool_call` routes. These calls are checked by the hook without executing their requested actions. The eight indirect cases now live in the committed test suite rather than a private supplemental probe. |
| Seeded defect has a specific failing reproduction before correction | [reproduction.json](receipts/reproduction.json) contains the faulty source, exact failing assertion/error, correction and ordered red/green exit codes. Inclusive endpoint 5 fails with `<`, then passes with `<=`. The genuine reviewer checked that the failure specifically exposes the seeded defect. |
| Five-claim citation fixture flags invented source and unsupported claim | [genuine-review.json](receipts/genuine-review.json) preserves the exact initial review: claims 1–3 supported; claim 4 `unknown-source`; claim 5 `unsupported-claim`; source C's install/upload instruction rejected as untrusted. The original synthetic fixture is committed with the tests. |
| Record denials and skill hashes | [denials.json](receipts/denials.json), [session-guidance.json](receipts/session-guidance.json), and [source.json](receipts/source.json). |

These are bounded fixture results. The launch spy is not a real model benchmark;
the seed test is a synthetic regression demonstration; the citation result is
manual semantic review. Upstream automated citation validation is still disabled.
No general effectiveness, Windows/laptop rollout or host parity is claimed.

## Sandbox execution and the existing failure

The worker reran the relevant suite in the foreground at test commit
`aad52312547cc21dd989be917d8a841693cfe8ed`, in the approved linked checkout
`/opt/leon-v2-worktrees/hermes-c1-review-fix-a46d`. The run selected all four
required files: the new guidance suite, native Hermes suite, conversation suite
and runs-feed suite. **64 passed, 1 failed**; all four C1 tests passed.

[sandbox.json](receipts/sandbox.json) records exact argv, checkout SHAs, UTC start
and finish times, exit codes, log hashes, parsed JUnit counts and the installed
harness hash. The installed harness is byte-identical to the repository's
`tools/v2/ops_sandbox_run.sh`: read-only root; writable linked checkout and result
directory; isolated network/PID/IPC/UTS; memory cap; no capabilities; test guard
environment. Tests were not executed directly on the unrestricted host.

[regressions.txt](receipts/regressions.txt) reports the only final failure:
`test_the_agents_list_draws_screen_tasks_as_hermes_with_their_last_step`, whose
extracted JavaScript lacks `JOB_LIVE`. [baseline.txt](receipts/baseline.txt)
records the identical failure freshly reproduced in the mandatory sandbox at
base `34b52b0a7603cc815ba5942b01a187fe0042af20`. Both checkout SHAs and identical
test/dashboard file hashes are in `sandbox.json`.

The first fix-round attempt reused a private probe with an old fixed output path;
the sandbox refused its write outside the fresh result mount. That harness-only
failure is disclosed in `sandbox.json`. The indirect probes now use the committed
test's `tmp_path`, and the final run has only the reproduced baseline failure.

A strict read-only reviewer should inspect these completed executions, not run
pytest and create fixtures. The reviewed source uses the existing permissions.

## Genuine review, delivery, CI and ledger scope

[genuine-review.json](receipts/genuine-review.json) includes the original genuine
plan and source-review session identities, upstream DB rows, exact APPROVE text
and reviewed file hashes. The runtime source is unchanged since that approval;
the only test change adds the four indirect inputs. This packet fixes the later
outer review's inability to see the supporting receipts. A subsequent review of
this fix is separate; no approval of an unseen commit is preclaimed.

[delivery.json](receipts/delivery.json) records integration of runtime source
`b3b94c38861aa8c9340c21e1b16e958fcf6ac1bb`, preservation of unrelated main diffs,
the original push and fresh `git ls-remote` stdout, plus freshly queried GitHub
run metadata. This is a dated snapshot; subsequent source integration may advance
the branch. The evidence-fix commits were not yet pushed when it was captured.

GitHub run [39080468981](https://github.com/sabrtechnologies/leon-brain-vps/actions/runs/39080468981)
completed **failure**, 143/154 modules passed. All 11 failing modules and all
reported failing cases also occurred in base run
[39079741599](https://github.com/sabrtechnologies/leon-brain-vps/actions/runs/39079741599)
(142/154 passed). [ci-comparison.json](receipts/ci-comparison.json) provides both
case lists and the empty set of new failures. That workflow does not select the
native guidance tests; their results come from the explicit sandbox run above.

[ledger.json](receipts/ledger.json) provides the worker's historical fresh-read,
locked atomic item-4-only mutation receipt: equal before/after prefix and suffix
hashes, prior item-4 bytes preserved, checked status unchanged, and readback match.
It also records a fresh check that the C1 note is present. Raw protected ledger
bytes are omitted. This is a **worker attestation**, not an independent reviewer
read of private state. The same limitation applies to private-report delivery;
the worker checks it in the main checkout, while this packet is directly readable.

Source integration makes guidance available to subsequent VPS foreground sessions.
No restart, existing-session mutation, installer release or laptop action occurred.
Actual source-review session delivery is evidenced; broad production activation
is not claimed. [manifest.json](receipts/manifest.json) lists hashes of every
selected receipt and the sanitization policy. No raw private report, ledger,
model prompt, memory, authentication configuration or provider login data is here.

The reviewer hook permits Git inspection but refuses `sha256sum`. It has not been
relaxed. `manifest.json` therefore also supplies Git blob IDs for every receipt;
`sandbox.json` repeats the blob IDs of both normalized logs. An authorized,
read-only content-identity check is:

```sh
git rev-parse HEAD:docs/verification/hermes-c1/receipts/baseline.txt HEAD:docs/verification/hermes-c1/receipts/regressions.txt HEAD:docs/verification/hermes-c1/receipts/sandbox.json
```

Compare the returned IDs with the manifest and confirm `git status --short` is
empty. SHA-256 values remain worker-computed attestations, not independently
recomputed hashes by the restricted reviewer. Git blob identity is a different
hash construction; no equivalence to a file's SHA-256 is asserted.
