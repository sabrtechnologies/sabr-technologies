# Phone chat without the laptop

The phone page (`dashboard/mobile.html:139`) uses the same authenticated `/ws`
and `text_input` protocol as the dashboard. Both persistent and one-shot
reasoning resolve `claude` to `/usr/local/bin/claude`, which on this VPS is the
laptop relay in `tools/claude_bridge_client.py`. There was no reasoning fallback
for its explicit offline/no-request-submitted error. The generic WebSocket
error path could launch that relay again; the scheduler path instead returned
“I couldn't finish that response. Please try again.” The reported approximate
“can't talk right now, sorry” wording was not found verbatim.

The configured Ollama service at `127.0.0.1:11434` also returned an empty model
list. Its configured `qwen3.6:35b-a3b` model was absent. The existing free cloud
router answered some probes but returned an empty reply on another; it was not
chosen for deployment. The fallback tested here is CPU inference on the VPS
using `qwen2.5:3b-instruct-q4_K_M` (about 1.93 GB of weights).

## Change

- Only the relay's explicit **no request submitted** failure can select the
  configured backup, before any output, tool or confirmation request.
- Both CLI paths support that fallback. No quota/auth cooldown is set, so the
  next turn can use the bridge after recovery.
- Unknown submitted outcomes stop without replay, including at the WebSocket
  consumer. Backup failure, empty output and exceptions also stay terminal.
- Existing tool policy and user/daemon separation remain in effect. Desktop
  transport failure stays a failed tool result. Authentication is unchanged.
- One-shot stderr is drained before classifying a fast relay exit.
- If the configured local model is absent, the probe pins the installed model
  selected by the fallback chain, so text and tool requests use the same model.
  An installed preferred model still wins.

## Verification

Unit and endpoint regression entry point: `tests/test_bridge_offline_fallback.py`.
Before the fix, four tests failed because offline and ambiguous turns invoked a
second CLI. The same checks pass after the fix. Tests cover both CLI paths,
recovery, cancellation, failed/empty/throwing backups, prior tool activity,
daemon isolation, auth, response IDs and desktop failures.

The final regression run passed **202 tests** (11 existing deprecation/syntax
warnings). `git diff --check` passed. Neighboring suites cover survival/quota/auth, session lifecycle, admission,
cancellation and scheduler routing. `tests/test_turn_priority.py` contained a
pre-existing stale assertion that follow-up admission must call `abort()`.
It failed on the unchanged revision too. The test now checks the existing
queueing behavior: yield background work, preserve active user work, and leave
aborting to explicit Stop. No admission implementation changed.

Tests ran in this job's linked checkout with read-only `/`, an isolated network
and PID namespace, no capabilities, a cleared environment, synthetic auth,
temporary HOME/run/tmp, and a 1 GiB systemd memory limit. This preserves the
repository sandbox protections while using the user-required job checkout;
the stock wrapper only accepts the different `/opt/leon-v2-worktrees` root.
Unit tests never ran against production state. Both new regression modules
also passed via `tests/run_all.py` and are registered in its default CI list.

The real-provider probe is `tools/verify_bridge_offline.py`. Run it only in an
isolated checkout sandbox with loopback access to an explicitly configured
`LEON_OLLAMA_URL`, `LEON_LOCAL_MODEL`, `LEON_TEST_SANDBOX=1`, and synthetic
`LEON_API_KEY`. It mounts the real `/ws` router and auth middleware in an ASGI
test server without production startup hooks. Neurons and speech are fixtures;
reasoning and the model HTTP transport are real. The bridge fixture invokes
the real relay `connect()` against a reserved non-listening port, without
opening its token or contacting the laptop. Desktop failure also uses a real
refused connection. No generated answer is mocked.

The isolated Ollama daemon served on `127.0.0.1:11439`, loaded weights stored
inside this job, and was stopped and reaped after verification. The response
model was `local:qwen2.5:3b-instruct-q4_K_M`:

1. Phone `text_input`: “What is 17 plus 25? Answer in one short sentence.”
   Reply: “The sum of 17 plus 25 is 42.”
2. `screen_capture`: `ok=false`, `PC relay: ConnectionRefusedError`.
3. Another phone `text_input`: “What is 12 plus 8? Answer in one short sentence.”
   Reply: “The sum of 12 plus 8 equals 20.”

Both replies terminated with `brain_response_end`; no quota hold was set.
This tests the phone protocol, not a physical phone UI or a powered-off laptop.
Bridge recovery is covered by the subprocess regression, not by power-cycling
the real laptop.

## Activation

The tested model was installed into the live Ollama service. The operator
configuration still requests `qwen3.6:35b-a3b`, with mode `fallback` and URL
`http://127.0.0.1:11434`; that requested model is absent, so the installed
`qwen2.5:3b-instruct-q4_K_M` is selected. The initial development `.env` model
change was restored after confirming that live operator configuration takes
precedence. No credential or provider login files were changed. Normal
laptop/provider selection remains first; the smaller model only covers the
backup paths. It is less capable than the normal frontier provider.

The brain service is `leon.service`, running `start_vps.sh` from
`/opt/leon-brain`. Activation requires merging the job into `windows-conpty`
and restarting that service; a push alone does not activate this VPS checkout.
Keep the unrelated existing working-tree edits intact. Do not restart Ollama
or the laptop bridge, or replace brain state.

After the first activation, the actual laptop reasoning TCP listener was
unreachable. An authenticated synthetic `text_input` was sent to the **live**
brain at `127.0.0.1:8000/ws`. It returned **“42.”**, model
`local:qwen2.5:3b-instruct-q4_K_M`, and `brain_response_end` without an error.
See `live-endpoint-receipt.json`. The live `/healthz` also returned
`{"ok":true,"status":"alive"}`. No laptop outage was induced on production.
