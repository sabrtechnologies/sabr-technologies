# Item 17 delivery evidence

This packet answers the post-delivery Hermes request for evidence accessible
inside the repository. The collector refreshed these observations in the
foreground after that request. No application, workflow, guard or test changed
in this documentation follow-up, so verification was limited to the disputed
delivery facts and packet consistency; the regression suite was not rerun.

The delivered and tested commit is
`cf9e7b64ffec92dc1af47071fed10baf02913b40`, on `windows-conpty`.
[GitHub run 40944367613](https://github.com/sabrtechnologies/leon-brain-vps/actions/runs/40944367613)
completed successfully on that exact SHA: **158/158 modules in 340.07s**.

| Evidence | What it establishes |
| --- | --- |
| [github-run.json](github-run.json) | Fresh `gh run view` metadata: run ID, SHA, branch, completed/success state, job and step conclusions, timestamps, URL. |
| [github-suite-excerpt.log](github-suite-excerpt.log) | Exact selected lines from that run's freshly downloaded log, with original line numbers: final 158/158, browser 13 passed, snapshot/bridge/containment outcomes. |
| [provenance.json](provenance.json) | Collection time, source run, full-log SHA-256, extraction policy and trust limits. The fresh full log matched the previously retained full log byte-for-byte. |
| [deployment-observation.json](deployment-observation.json) | Remote/main SHA; hashes of six installed files compared with `git show` at the tested SHA; HTTP 200 and matching live link-script hash; unchanged service start observation. |
| [ledger-closure.json](ledger-closure.json) | Only item 17's closed checkbox, delivered SHA, successful run and result, plus source-line hash. The private ledger and other requests are excluded. |
| [prior-hermes-reviews.json](prior-hermes-reviews.json) | Two genuine prior APPROVE verdicts and session IDs. Both reviewed code/logs; neither executed tests. |

The first pushed run, 40942661188, failed 155/158. The final success followed the
reviewed CI-only correction; see [the ledger](../../ci-ledger-17.md).
Existing immutable-runtime and nested-containment skips remain. Browser tests
executed without skips. Nothing here claims live-confinement verification.

The live boundary is explicit: CI is deployed, and the corrected JavaScript is
served by the running application. Python changes are installed on disk, but no
service restart or loaded-code verification occurred. No installer release was
published. Item 17 closure concerns restoring meaningful green CI.

These files are worker-captured evidence for read-only reviewer inspection, not
independent reviewer execution or direct reviewer access to GitHub/production.
Documentation-only follow-up commits are separate from the tested SHA and do not
inherit its run identity. Full original logs and receipts remain in the private
item directory; this packet contains no credentials or private request content.
