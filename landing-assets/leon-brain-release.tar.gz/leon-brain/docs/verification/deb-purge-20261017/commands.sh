#!/bin/bash
# Invoked INSIDE the mandated sandbox, at source 392c485c0adbac4af34375ee360f0bcf57dae384.
set -euo pipefail
OUT=/opt/leon-v2-tools/test-results/deb-purge-cb3752f013b51072b77c44f4
export TMPDIR="$OUT/temp"
mkdir -p "$TMPDIR"
python3 -m pytest -q tests/test_installer_deb_purge_ownership.py -o "cache_dir=$OUT/cache" --basetemp="$OUT/final-fixed-fixtures" --junitxml="$OUT/final-fixed.xml" 2>&1 | tee "$OUT/final-fixed.txt"
set +e
DEB_MAINTAINER_WORKFLOW="$OUT/unsafe-build-installer.yml" python3 -m pytest -q tests/test_installer_deb_purge_ownership.py -o "cache_dir=$OUT/cache" --basetemp="$OUT/final-unsafe-fixtures" --junitxml="$OUT/final-unsafe.xml" > "$OUT/final-unsafe.txt" 2>&1
negative_status=$?
set -e
[ "$negative_status" = 1 ]
tail -n 13 "$OUT/final-unsafe.txt"
python3 -m pytest -q tests/test_installer_lifecycle_inventory.py tests/test_installer_lifecycle_retention.py tests/test_uninstall_sweeps_leftovers.py tests/test_uninstall_without_systemctl.py tests/test_uninstall_entrypoints.py -o "cache_dir=$OUT/cache" --basetemp="$OUT/final-related-fixtures" --junitxml="$OUT/final-related.xml" 2>&1 | tee "$OUT/final-related.txt"
