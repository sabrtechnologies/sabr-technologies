# Debian package purge archive preservation

Source fix: `392c485c0adbac4af34375ee360f0bcf57dae384`, on
`job/vps-cb3752f013b51072b77c44f4`. Locally committed, not integrated or pushed.
Customer release remains blocked by native acceptance.

The generated `postrm` no longer scans homes or unlinks matching backups.
It retains every customer archive, including the archive created by the current
package removal, and explains that archive ownership is not established.
Names, locations, Unix owners and customer-writable sidecars cannot authorize
archive deletion. This conservative policy matches `run_uninstall`'s existing
historical-archive retention behavior. The adjacent `prerm` now returns the
installer's nonzero status and explains that package removal stopped.

The regression extracts the actual maintainer-script bodies from the workflow;
only filesystem roots and external commands are redirected. Its bounded unlink
stub permits only fixture paths, including resolved parents. It never executes
a maintainer script with real `/root`, `/home`, package-binary or log targets.
The real Python uninstaller creates an archive in a disposable fixture with
process/startup effects disabled. No package manager or frozen installer runs.

## Fresh verification

All final tests ran through `/opt/leon-v2-tools/sandbox_run.sh`, with a 1 GiB
memory cap, isolated network/PID namespaces and read-only host mounts. Source was
a clean detached linked checkout at the source SHA above under
`/opt/leon-v2-worktrees/deb-purge-cb3752f013b51072b77c44f4`.
Fixtures, temporary logs, pytest cache and reports were directed under
`/opt/leon-v2-tools/test-results/deb-purge-cb3752f013b51072b77c44f4/`.

- New package regression: **11 passed**.
- Negative control: same 11 assertions against the original workflow at
  `391d804535b38ce6937173ab2613509e8a25fa97`: **11 failed as expected**.
  Nine preservation assertions caught deleted archives/links; two caught
  suppressed uninstall failures. These were behavioral assertion failures,
  not collection or environment errors.
- Related lifecycle/uninstall regressions: **74 passed, 10 skipped**. Skips
  are existing simulated platform combinations (`command belongs to another
  platform` and `Linux legacy desktop entry`), not native acceptance results.
- `git diff --check` passed. The workflow outside the maintainer-script region
  is byte-identical to the baseline; privacy, build, stamp and publication
  gates and installer runtime source are unchanged. No privacy build was rerun.

Coverage includes absent/malformed ownership, archives claiming this and another
installation, path-escape claims, unrelated files, matching directories, archive
links (including dangling links), symlinked homes and ancestors, repeat
remove/purge, actual fixture archive creation, and nonzero uninstall propagation.
The test uses the `test_installer*` name so the existing lifecycle workflow
collects it without a CI change. Exact sandbox invocation, commands, source
hashes, counts and raw log/XML locations are in `verification.json` and
`commands.sh`. The initial exploratory runs gave the same results; the recorded
final run additionally directs general temporary logs into the results tree.

## Prior evidence, ledger and review

Read all five files of `docs/verification/installer-native-20261017/` from
`036f4d14`, the native checklist, applicable repository instructions and canonical
item 2. The authenticated result of `vps-716477fcb68b17078838362e` confirms it is
done with genuine Hermes **APPROVE of the bounded blocker report**, not native
acceptance or publication. The fresh combined VPS/laptop board showed only this
job running, zero queued, and no source warnings. No infrastructure rediscovery,
children or cancellations were performed.

At the initial ledger read, item 2 contained the prior native-blocker note. At
the first locked update attempt that note was absent; the assertion stopped
before any write. The subsequent item-2-only append preserved all current item
bytes and restated the verified prior outcome with this repair status. It also
records this intervening change; its cause was not investigated. Readback and
hash receipts verify that this worker's update changed no bytes outside item 2.
The sanitized patch and receipt contain no unrelated ledger content.

The supplied genuine Hermes plan was followed. Naming the regression with the
existing CI prefix is the only implementation-plan adjustment. Final Hermes
review is performed by the paired runner after this worker returns; no current
review verdict is claimed. Integration/push is deferred until that review
approves the repair. No substitute reviewer or child job was launched.

## Still untested and not released

All **32 native platform/checklist combinations remain unperformed**. No
Windows, Linux desktop, macOS arm64 or Intel desktop acceptance target has been
authorized by this job. The prior absence of disposable targets is unchanged;
the VPS and personal laptop are not acceptance hosts. Real `.deb`
install/upgrade/remove/purge, desktop login/reboot, service behavior, frozen
binaries, signing, file locks and public-download bytes remain unverified.
This repair does not certify the remaining maintainer-script or native lifecycle
behavior. Item 2 remains open.

Nothing was installed, purged, published or restarted on this VPS or any customer
machine. A later source integration/push would run applicable CI, not publish
new installers; `build-installer.yml` publishes on release-tag paths, and no tag
or publication workflow was invoked. Customer publication still requires native
acceptance and separate approval.
