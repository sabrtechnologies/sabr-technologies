"""Getting a user turn onto the responder without a 30-second wall.

Extracted from the inline block in routers/websocket.py so the handoff is one
named, tested unit instead of six lines buried in a 400-line handler.

THE FIRST BUG (2026-08-05). Dean would randomly get back:

    "Something's wrong on my end — give me a second."

Not random. His turn tried the responder lock non-blocking, failed, called
`brain_api_responder.abort()`, then waited `acquire(timeout=30)` and emitted
that string when the wait expired. abort() could never free the lock, because
every autonomous holder — inner_voice, dreaming, the two consciousness
routines, the audio daemon, upgrade_awareness — calls
`respond_streaming(force_cli=True)`, and respond_streaming maps force_cli
straight to `daemon=True` ("those ride the sonnet daemon session"). Daemon
turns are immune to Stop in two separate places, both deliberate:

  * abort() interrupts only _LEON_SESSIONS["user"] — "Daemon sessions are left
    alone, Stop is a Dean-facing control"
  * the CLI loop's abort check is gated on `not daemon`

So the lever Dean's turn pulled was not connected to the thing holding the
lock. preempt_daemon() is the second lever, and pulling both fixed that case.

THE SECOND BUG (2026-08-07). The bounce came back the moment turns arrived
faster than they finished. Every user message parked its OWN thread in
`lock.acquire(timeout=30)`, and threading.Lock wakes an arbitrary waiter — so
when preemption freed the lock, a STALE turn from a minute ago (an echo, a
re-pasted line, an earlier utterance) would win it and start answering an old
message, while Dean's newest turn starved out its ceiling and bounced. In the
2026-08-07 log, 9 of 22 user turns died exactly this way, every preemption
reported killed=True, and the "yielded" success path had never fired once.
Dean then pasted the bounce line back into the chat to complain, which queued
MORE turns, which caused more bounces.

The fix is admission, not fairness: UserTurnGate makes the newest message the
only waiter. A new registration supersedes any turn still waiting (it exits
silently, leaving its text behind), and whichever turn takes the lock claims
EVERY pending text and answers them together — the way a person answers three
sentences said while they were mid-thought. Nothing Dean says is dropped;
nothing stale outruns him; and with one waiter the ceiling can be long enough
to out-wait a tool-heavy turn, so the scary message is reserved for a genuine
wedge.

THE THIRD BUG (2026-08-07, same evening). With the gate in place, turns
stopped losing races — and still waited out the full ceiling. The holder was
a background LOOP (dreaming's consolidation), which holds the lock across
MANY daemon CLI calls. Preemption killed its current subprocess, the loop
caught the failure and started its next call, and _respond_via_cli's daemon
branch CLEARED the preempt flag at turn start — erasing the request. The
levers all reported success while the lock never came free. The flag now
means "a user turn is waiting right now": daemon turns refuse to START while
it stands, and only the waiter lowers it (preempt_satisfied, called from
_wait_over here) when it is served or gives up. A superseding turn keeps it
pressed.

Stop and preemption remain different intentions with different levers:
Stop is Dean saying "be quiet", preemption is "a person is talking, yield".
Background work is meant to survive the first and never survive the second.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable, List, Optional, Tuple

#: One waiter max means a long ceiling cannot stack. 30s was calibrated for
#: chat turns; a tool-heavy turn (image generation, a build) routinely runs
#: past it while honouring the abort flag only between events, so out-waiting
#: it is correct and calling it broken is not.
USER_TURN_CEILING_S = 120.0

#: When a real wait develops, say something honest ONCE instead of silence
#: followed by a false alarm.
NOTIFY_AFTER_S = 12.0


class UserTurnGate:
    """Newest-user-message-wins admission for the responder lock."""

    #: A claimed text older than this is dropped, not answered — a message
    #: from a dead client tab ten minutes ago is noise, not a question.
    STALE_S = 600.0

    def __init__(self):
        self._mu = threading.Lock()
        self._seq = 0
        self._newest = 0
        self._pending: List[Tuple[int, float, str]] = []

    def register(self, text: str) -> int:
        """A user message wants the responder. Marks it newest; its text is
        pending until some winner claims it."""
        with self._mu:
            self._seq += 1
            self._newest = self._seq
            self._pending.append((self._seq, time.monotonic(), text))
            return self._seq

    def superseded(self, turn_id: int) -> bool:
        with self._mu:
            return turn_id != self._newest

    def claim(self) -> List[str]:
        """The lock winner takes every pending text, oldest first. Empty means
        a prior winner already answered this turn's text mid-wait."""
        now = time.monotonic()
        with self._mu:
            texts = [t for (_, ts, t) in self._pending if now - ts < self.STALE_S]
            self._pending.clear()
            return texts

    #: One "give me a second" per busy period, not one per waiting turn.
    #: Under supersession every follow-up message is a NEW turn with its own
    #: 12s clock — without this, Dean re-asking during one long busy stretch
    #: heard the note again every time ("leon keeps saying give me a second",
    #: 2026-08-07).
    NOTE_INTERVAL_S = 45.0

    def allow_note(self) -> bool:
        now = time.monotonic()
        with self._mu:
            if now - getattr(self, "_last_note", 0.0) < self.NOTE_INTERVAL_S:
                return False
            self._last_note = now
            return True


#: One gate per process — every user-input path (dashboard websocket, phone
#: websocket, voice wake) must go through the same one or supersession is
#: blind to half the turns.
USER_TURN_GATE = UserTurnGate()


def _pull_yield_levers(responder: Any) -> None:
    """Ask whatever holds the responder to yield. Both levers, because the
    holder may be either kind and asking the wrong one is the first bug:
      * a previous USER turn responds to abort()
      * a BACKGROUND turn responds only to preempt_daemon()
    """
    asked = []
    for name in ("abort", "preempt_daemon"):
        fn = getattr(responder, name, None)
        if not callable(fn):
            continue
        try:
            fn()
            asked.append(name)
        except Exception as e:                      # never let a lever failure
            print(f"[TURN] {name}() failed: {e}")   # turn into a lost turn
    if not asked:
        print("[TURN] responder exposes neither abort() nor preempt_daemon() "
              "— a user turn can only wait this one out")


def _wait_over(responder: Any) -> None:
    """This turn's wait is over (served, already answered, or gave up):
    lower the preemption request so background work may run again. The flag
    means "a user turn is waiting right now" — daemon turns refuse to START
    while it stands (claude_api_responder._respond_via_cli), which is what
    stops a background loop from re-taking the lock between its own calls
    and starving the user turn forever. Only the waiter may lower it; a
    superseding turn keeps it pressed."""
    fn = getattr(responder, "preempt_satisfied", None)
    if callable(fn):
        try:
            fn()
        except Exception as e:
            print(f"[TURN] preempt_satisfied() failed: {e}")


def acquire_user_turn(lock: Any, responder: Any, text: str, *,
                      gate: UserTurnGate = USER_TURN_GATE,
                      ceiling: float = USER_TURN_CEILING_S,
                      notify: Optional[Callable[[], None]] = None,
                      notify_after: float = NOTIFY_AFTER_S,
                      ) -> Tuple[str, List[str], float]:
    """Admission for ONE user message. Returns (status, texts, waited).

    status:
      "go"         — caller owns the lock and must release it; answer the
                     returned texts joined together (oldest first, this
                     message last).
      "superseded" — a newer user message arrived while waiting. Exit with
                     NO output: the newer turn claims and answers this text
                     too, and a second voice talking over it is the old bug.
      "answered"   — the lock came free, but a prior winner had already
                     claimed this text into its own answer. The lock has
                     been released here; exit with no output.
      "timeout"    — the ceiling expired with no supersession and no lock:
                     a genuine wedge, the only case worth announcing.
    """
    turn_id = gate.register(text)
    t0 = time.monotonic()
    if lock.acquire(blocking=False):
        _wait_over(responder)
        texts = gate.claim()
        if not texts:
            try:
                lock.release()
            except RuntimeError:
                pass
            return "answered", [], 0.0
        return "go", texts, 0.0

    _pull_yield_levers(responder)

    notified = False
    while True:
        if gate.superseded(turn_id):
            # NOT _wait_over: the superseding turn inherits the raised flag —
            # a user is still waiting, just a newer one.
            return "superseded", [], time.monotonic() - t0
        waited = time.monotonic() - t0
        if waited >= ceiling:
            _wait_over(responder)
            return "timeout", [], waited
        if notify is not None and not notified and waited >= notify_after:
            notified = True                 # this turn never nags twice
            if gate.allow_note():           # ...and one note per busy period
                try:
                    notify()
                except Exception as e:
                    print(f"[TURN] wait notify failed: {e}")
        # Short slices, so supersession is noticed within a second instead
        # of after a full blind wait — and no longer than the time to the
        # pending wait-note, so the note lands ON time, not a slice late.
        slice_s = min(1.0, max(0.05, ceiling - waited))
        if notify is not None and not notified:
            slice_s = min(slice_s, max(0.05, notify_after - waited))
        if lock.acquire(timeout=slice_s):
            _wait_over(responder)
            texts = gate.claim()
            if not texts:
                try:
                    lock.release()
                except RuntimeError:
                    pass
                return "answered", [], time.monotonic() - t0
            return "go", texts, time.monotonic() - t0
