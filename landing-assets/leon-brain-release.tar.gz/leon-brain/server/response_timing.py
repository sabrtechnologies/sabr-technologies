"""Timing receipts for one real response, including asynchronous speech.

Only IDs, durations and counts are recorded. The first audio timestamp means
audio was ready to broadcast; it does not assert that a browser played it.
"""
import json
import logging
from pathlib import Path
import threading
import time

log = logging.getLogger(__name__)
_WRITE_LOCK = threading.Lock()


def _append_record(record):
    with _WRITE_LOCK:
        path = Path("brain_state/reply_latency.jsonl")
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record) + "\n")


class ResponseTiming:
    def __init__(self, response_id, user_chars, *, source="text",
                 started_at=None, clock=time.monotonic, write=None):
        self.response_id = response_id
        self.clock = clock
        self.ts, self.started = started_at or (time.time(), clock())
        self.write = write if write is not None else _append_record
        self._lock = threading.Lock()
        self._written = set()
        self._values = {
            "ts": round(self.ts, 3), "rid": response_id,
            "source": source if source in ("text", "voice", "wake") else "voice",
            "first_s": None, "first_audio_s": None, "total_s": None,
            "admitted_s": None, "chars": 0, "user_chars": user_chars,
            "audio_chunks": 0,
        }

    def admitted(self):
        with self._lock:
            self._values["admitted_s"] = round(self.clock() - self.started, 3)

    def observe(self, payload):
        # Wait notices have their own response ID. Neither those nor fillers
        # are an answer, and they must not make a slow turn look fast.
        if payload.get("response_id") != self.response_id or payload.get("is_filler"):
            return
        try:
            with self._lock:
                elapsed = round(self.clock() - self.started, 3)
                kind = payload.get("type")
                values = self._values
                if kind == "brain_response_delta" and payload.get("text"):
                    values["chars"] += len(payload["text"])
                    if values["first_s"] is None:
                        values["first_s"] = elapsed
                elif kind == "brain_audio":
                    values["audio_chunks"] += 1
                    if values["first_audio_s"] is None:
                        values["first_audio_s"] = elapsed
                elif kind == "brain_response_end":
                    if values["total_s"] is None:
                        values["total_s"] = elapsed
                    self._record("response_end")
                elif kind == "brain_audio_complete":
                    self._record("audio_complete", audio_complete_s=elapsed)
        except Exception:
            # Disk-full/permissions diagnostics must never stop a reply.
            log.warning("Could not record response timing for %s", self.response_id,
                        exc_info=True)

    def _record(self, event, **extra):
        if event not in self._written:
            self.write({**self._values, "event": event, **extra})
            self._written.add(event)
