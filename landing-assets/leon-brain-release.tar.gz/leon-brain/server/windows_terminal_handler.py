"""
Windows terminal WebSocket handler — ConPTY bridging.

Manages WebSocket <-> HTTP bridging for Windows ConPTY terminals.
No local PTY, no tmux — direct streaming to Windows terminal service.
"""

import asyncio
import json
import logging
from typing import Optional

from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger("leon.windows_terminal_handler")


async def handle_windows_terminal(
    websocket: WebSocket,
    window: str,
    cwd: str,
    spawner,
) -> None:
    """
    Handle WebSocket terminal for Windows ConPTY.
    
    Flow:
      WebSocket → parse input → HTTP POST to Windows terminal service
      Windows terminal service → HTTP GET → WebSocket
    """
    session_id: Optional[str] = None
    read_task: Optional[asyncio.Task] = None
    
    try:
        await websocket.accept()
        logger.info(f"[Windows] Terminal connected: {window}")
        
        # Wait for initial resize message
        rows, cols = 40, 120
        try:
            first = await asyncio.wait_for(websocket.receive(), timeout=3.0)
            if first.get("text"):
                try:
                    data = json.loads(first["text"])
                    if data.get("type") == "resize":
                        rows = max(2, int(data.get("rows", rows)))
                        cols = max(20, int(data.get("cols", cols)))
                except Exception:
                    pass
        except asyncio.TimeoutError:
            pass
        
        # Spawn terminal on Windows
        try:
            session_id = await spawner.spawn(cwd, rows, cols, {})
            logger.info(f"[Windows] Spawned terminal {session_id} ({rows}x{cols})")
        except Exception as e:
            await websocket.send_bytes(f"Failed to spawn terminal: {e}\r\n".encode())
            await websocket.close()
            return
        
        # Task to read from terminal and send to WebSocket
        async def read_terminal_loop():
            while True:
                try:
                    data = await spawner.read(session_id, max_bytes=4096)
                    if data:
                        await websocket.send_bytes(data.encode() if isinstance(data, str) else data)
                    await asyncio.sleep(0.05)  # Small delay to batch reads
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"[Windows] Read error: {e}")
                    break
        
        # Start background read task
        read_task = asyncio.create_task(read_terminal_loop())
        
        # Handle WebSocket input
        try:
            while True:
                msg = await websocket.receive()
                
                if msg.get("type") == "websocket.disconnect":
                    break
                
                text = msg.get("text")
                if text:
                    try:
                        data = json.loads(text)
                        msg_type = data.get("type")
                        
                        if msg_type == "input":
                            payload = data.get("data", "")
                            if payload:
                                await spawner.write(session_id, payload)
                        
                        elif msg_type == "resize":
                            rows = max(2, int(data.get("rows", rows)))
                            cols = max(20, int(data.get("cols", cols)))
                            await spawner.resize(session_id, rows, cols)
                            logger.debug(f"[Windows] Resized to {rows}x{cols}")
                    
                    except Exception as e:
                        logger.error(f"[Windows] Parse error: {e}")
        
        except WebSocketDisconnect:
            logger.info(f"[Windows] WebSocket disconnected: {window}")
    
    finally:
        # Cleanup
        if read_task:
            read_task.cancel()
            try:
                await read_task
            except asyncio.CancelledError:
                pass
        
        if session_id:
            try:
                await spawner.close(session_id)
                logger.info(f"[Windows] Closed terminal {session_id}")
            except Exception as e:
                logger.error(f"[Windows] Close error: {e}")
        
        try:
            await websocket.close()
        except Exception:
            pass
