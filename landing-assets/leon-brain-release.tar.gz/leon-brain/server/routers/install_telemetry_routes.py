"""
/api/telemetry/* — per-step install telemetry from customer installers.

WHY
---
/api/onboarding/install-log (onboarding_routes.py) already exists and is the
right tool for ONE install: a support engineer opens it and reads a specific
customer's log. It answers nothing about the fleet. "Does the venv step fail
more on Windows 11 than on macOS?" and "did last night's release break the
deps step?" are questions about a THOUSAND installs, and free text in a
thousand files cannot answer them.

So this is the counterpart: six known steps, three known outcomes, one row
each, in a table you can GROUP BY. It is not a log and must never grow into
one — the moment a message string is accepted here, this becomes another
place customer paths and usernames accumulate.

WHAT A ROW MAY CONTAIN
----------------------
Platform, architecture, Python major.minor, installer build, step, status,
exception CLASS name, a duration, and a crash verdict. That is the whole
contract, enforced by _clean_event() below against fixed allowlists — an
unknown field is DROPPED, not stored, so a future installer that starts
sending something careless is contained by the server rather than by the
client that was already updated.

Explicitly never accepted: SI name, owner name, email, tenant/install token,
file paths, exception messages, tracebacks, hostnames. Note that
onboarding's install-log DOES take si_name — that is a per-customer support
artifact, a different bargain from a fleet-wide aggregate table.

run_id is generated per installer PROCESS and never persisted on the
customer's machine, so it groups the six steps of one run and nothing else.
It is not a device id and cannot be used to recognise a returning customer.

AUTH
----
Writes are unauthenticated, and have to be: the installer holds no server
key, and on a fresh box there is nothing to authenticate with. Same bargain
as /api/onboarding/install-log and /api/feedback.

Reads are admin-gated in-route, mirroring
onboarding_routes._fleet_admin_token / onboarding_list_tenants: bearer
compared with hmac.compare_digest, ONBOARDING_ADMIN_TOKEN preferred over
LEON_API_KEY, and 401 for everyone when neither is configured. Fail closed,
and do not trust the middleware alone.
"""

from __future__ import annotations

import hmac
import json
import logging
import os
import re
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

log = logging.getLogger("leon.install_telemetry")
router = APIRouter()


# ── Contract ──────────────────────────────────────────────────────────
#
# These tuples ARE the schema. installer/sabr_installer.py holds the same
# step list (TELEMETRY_STEPS); tests/test_install_telemetry_client.py pins
# the two against each other so they cannot drift apart silently.

STEPS = ("download", "extract", "venv", "deps", "service_setup", "first_boot")
STATUSES = ("ok", "fail")
CRASH_VERDICTS = ("healthy", "restart_loop", "fatal_boot_error", "unknown")

#: Identifiers only. An exception message would match none of this, which is
#: the point — error_class is a CLASS name and the regex is the enforcement.
_CLASS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]{0,63}$")
_RUN_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")

#: Free-ish text fields are still capped hard. Nothing here is displayed as
#: HTML, but an unbounded string is a disk-growth bug regardless.
_MAX_TEXT = 64

#: Ceiling on the table. A customer stuck in a retry loop, or anyone who
#: finds this unauthenticated endpoint, must not be able to fill the disk.
#: Past the cap the OLDEST rows go: a telemetry table's value is in the
#: recent shape of failures, and old rows are the cheap thing to lose.
MAX_ROWS = 200_000

#: Rows per run_id. Six steps, so anything past this is a client bug or an
#: abuser reusing one id. Enforced per insert.
MAX_ROWS_PER_RUN = 60

_write_lock = threading.Lock()


def _db_path() -> str:
    """Where the table lives. Env-overridable so tests never touch the real
    brain_state (and so an operator can move it off a small root volume).

    Read on every call rather than captured at import: a module-level
    constant here would make the env var untestable and would bind the path
    to import order.
    """
    override = (os.environ.get("SABR_TELEMETRY_DB") or "").strip()
    if override:
        return override
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "install_telemetry.db")


def _connect() -> sqlite3.Connection:
    path = _db_path()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS install_events (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            ts          REAL    NOT NULL,
            run_id      TEXT    NOT NULL,
            step        TEXT    NOT NULL,
            status      TEXT    NOT NULL,
            error_class TEXT    NOT NULL DEFAULT '',
            platform    TEXT    NOT NULL DEFAULT '',
            arch        TEXT    NOT NULL DEFAULT '',
            py          TEXT    NOT NULL DEFAULT '',
            version     TEXT    NOT NULL DEFAULT '',
            duration_ms INTEGER NOT NULL DEFAULT 0,
            crash       TEXT    NOT NULL DEFAULT ''
        )""")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_ev_ts ON install_events(ts)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_ev_run ON install_events(run_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_ev_step ON install_events(step, status)")
    conn.commit()
    return conn


# ── Validation ────────────────────────────────────────────────────────

def _text(value: Any) -> str:
    """A short, single-line, printable string. Never a path or a message.

    Control characters are stripped rather than escaped: this feeds a log
    line and an admin JSON payload, and a newline in a "platform" field is
    already a sign the caller is sending something it should not.
    """
    if value is None:
        return ""
    out = str(value)[:_MAX_TEXT]
    return "".join(ch for ch in out if ch.isprintable()).strip()


def _clean_crash(value: Any) -> str:
    """The crash object, reduced to the four fields we agreed to carry.

    Anything else in it is dropped. brain/crash_watch.detect() returns
    exactly this shape today; this function exists so that a future field
    added there does not silently start flowing into the database.
    """
    if not isinstance(value, dict):
        return ""
    verdict = _text(value.get("verdict"))
    if verdict not in CRASH_VERDICTS:
        return ""
    out: Dict[str, Any] = {"verdict": verdict}
    for key in ("boots_in_window", "failed_boots", "restarts"):
        raw = value.get(key)
        if isinstance(raw, int) and not isinstance(raw, bool) and 0 <= raw <= 100_000:
            out[key] = raw
    cls = _text(value.get("last_error_class"))
    if cls and _CLASS_RE.match(cls):
        out["last_error_class"] = cls
    return json.dumps(out, separators=(",", ":"))


def _clean_event(body: Any) -> Optional[Dict[str, Any]]:
    """Validate one event. None means reject — never "store it anyway".

    Allowlist, not denylist. Every field the table has is read by name from
    the body; nothing else in the body is looked at, so an installer that
    starts attaching extra keys cannot get them stored.
    """
    if not isinstance(body, dict):
        return None
    step = _text(body.get("step"))
    status = _text(body.get("status"))
    run_id = _text(body.get("run_id"))
    if step not in STEPS or status not in STATUSES:
        return None
    if not _RUN_ID_RE.match(run_id):
        return None

    error_class = _text(body.get("error_class"))
    if error_class and not _CLASS_RE.match(error_class):
        error_class = ""            # drop the field, keep the event

    try:
        duration_ms = int(body.get("duration_ms") or 0)
    except (TypeError, ValueError):
        duration_ms = 0
    duration_ms = max(0, min(duration_ms, 24 * 60 * 60 * 1000))

    return {
        "ts": time.time(),
        "run_id": run_id,
        "step": step,
        "status": status,
        "error_class": error_class,
        "platform": _text(body.get("platform")),
        "arch": _text(body.get("arch")),
        "py": _text(body.get("py")),
        "version": _text(body.get("version")),
        "duration_ms": duration_ms,
        "crash": _clean_crash(body.get("crash")),
    }


def _prune(conn: sqlite3.Connection) -> None:
    """Enforce MAX_ROWS. Cheap: a COUNT and, rarely, one DELETE."""
    total = conn.execute("SELECT COUNT(*) FROM install_events").fetchone()[0]
    if total <= MAX_ROWS:
        return
    conn.execute(
        "DELETE FROM install_events WHERE id IN "
        "(SELECT id FROM install_events ORDER BY id ASC LIMIT ?)",
        (total - MAX_ROWS,))


def record_event(body: Any) -> Dict[str, Any]:
    """Validate + store one event. Importable so tests need no HTTP client.

    Never raises. A telemetry table that can 500 is a telemetry table that
    can take the onboarding server down with it.
    """
    event = _clean_event(body)
    if event is None:
        return {"ok": False, "error": "invalid event"}
    try:
        with _write_lock:
            conn = _connect()
            try:
                n = conn.execute(
                    "SELECT COUNT(*) FROM install_events WHERE run_id = ?",
                    (event["run_id"],)).fetchone()[0]
                if n >= MAX_ROWS_PER_RUN:
                    return {"ok": True, "stored": False, "reason": "run-cap"}
                conn.execute(
                    "INSERT INTO install_events (ts, run_id, step, status, "
                    "error_class, platform, arch, py, version, duration_ms, crash) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (event["ts"], event["run_id"], event["step"], event["status"],
                     event["error_class"], event["platform"], event["arch"],
                     event["py"], event["version"], event["duration_ms"],
                     event["crash"]))
                _prune(conn)
                conn.commit()
            finally:
                conn.close()
    except Exception as exc:                     # pragma: no cover - disk/lock
        log.warning("[TELEMETRY] store failed: %s", type(exc).__name__)
        return {"ok": True, "stored": False, "reason": "unavailable"}
    return {"ok": True, "stored": True}


# ── Write (public, same bargain as /api/onboarding/install-log) ───────

@router.post("/api/telemetry/install-event")
async def install_event(req: dict):
    """Record one install step. Best-effort and never authoritative.

    Returns 400 only for a malformed event, so a broken installer build is
    visible in the access log instead of silently discarded. Every other
    failure answers ok — the installer must not retry, and must never treat
    a telemetry outcome as an install outcome.
    """
    result = record_event(req)
    if not result.get("ok"):
        return JSONResponse({"ok": False, "error": "invalid event"}, 400)
    return result


# ── Read (admin) ──────────────────────────────────────────────────────

def _admin_token() -> str:
    """The bearer that guards the summary.

    Identical rule to onboarding_routes._fleet_admin_token, deliberately:
    ONBOARDING_ADMIN_TOKEN when set (a dashboard-only secret that is not the
    server master key), otherwise LEON_API_KEY, and "" when neither exists —
    which the route below turns into 401 for everyone rather than open
    access. Read at call time, not import time, so a token added to the
    environment does not need a restart to take effect.
    """
    return (os.environ.get("ONBOARDING_ADMIN_TOKEN")
            or os.environ.get("LEON_API_KEY") or "").strip()


def _authorized(request: Request) -> bool:
    expected = _admin_token()
    auth = request.headers.get("authorization") or ""
    supplied = auth[7:].strip() if auth.startswith("Bearer ") else ""
    if not expected or not supplied:
        return False
    return hmac.compare_digest(supplied, expected)


def build_summary(days: int = 7, limit_failures: int = 50) -> Dict[str, Any]:
    """The aggregate. Importable so the admin gate can be tested separately
    from the arithmetic, and so a CLI can print it without an HTTP round
    trip."""
    days = max(1, min(int(days or 7), 365))
    limit_failures = max(0, min(int(limit_failures or 50), 500))
    since = time.time() - days * 86400

    conn = _connect()
    try:
        by_step: List[Dict[str, Any]] = []
        rows = conn.execute(
            "SELECT step, status, COUNT(*) FROM install_events "
            "WHERE ts >= ? GROUP BY step, status", (since,)).fetchall()
        tally: Dict[str, Dict[str, int]] = {s: {"ok": 0, "fail": 0} for s in STEPS}
        for step, status, count in rows:
            if step in tally and status in tally[step]:
                tally[step][status] = count
        # STEPS order, not COUNT order: this reads as an install, top to
        # bottom, so the step that fails first is the one you look at first.
        for step in STEPS:
            ok, fail = tally[step]["ok"], tally[step]["fail"]
            total = ok + fail
            by_step.append({
                "step": step, "ok": ok, "fail": fail, "total": total,
                "fail_rate": round(fail / total, 4) if total else 0.0,
            })

        top_errors = [
            {"step": s, "error_class": e, "count": c}
            for s, e, c in conn.execute(
                "SELECT step, error_class, COUNT(*) c FROM install_events "
                "WHERE ts >= ? AND status = 'fail' AND error_class != '' "
                "GROUP BY step, error_class ORDER BY c DESC LIMIT 20",
                (since,)).fetchall()]

        by_platform = [
            {"platform": p or "unknown", "ok": ok, "fail": f}
            for p, ok, f in conn.execute(
                "SELECT platform, "
                "SUM(status = 'ok'), SUM(status = 'fail') "
                "FROM install_events WHERE ts >= ? GROUP BY platform "
                "ORDER BY (SUM(status = 'ok') + SUM(status = 'fail')) DESC "
                "LIMIT 20", (since,)).fetchall()]

        recent = [
            {"ts": ts, "run_id": rid, "step": st, "error_class": ec,
             "platform": pf, "version": vr, "crash": cr}
            for ts, rid, st, ec, pf, vr, cr in conn.execute(
                "SELECT ts, run_id, step, error_class, platform, version, crash "
                "FROM install_events WHERE ts >= ? AND status = 'fail' "
                "ORDER BY ts DESC LIMIT ?", (since, limit_failures)).fetchall()]

        crashes = [
            {"verdict": v, "count": c}
            for v, c in conn.execute(
                "SELECT json_extract(crash, '$.verdict') v, COUNT(*) "
                "FROM install_events WHERE ts >= ? AND crash != '' "
                "GROUP BY v ORDER BY COUNT(*) DESC", (since,)).fetchall()
            if v]

        # Runs, not events: 300 events from 50 installs is 50 installs. A
        # run counts as failed if ANY step in it failed.
        total_runs = conn.execute(
            "SELECT COUNT(DISTINCT run_id) FROM install_events WHERE ts >= ?",
            (since,)).fetchone()[0]
        failed_runs = conn.execute(
            "SELECT COUNT(DISTINCT run_id) FROM install_events "
            "WHERE ts >= ? AND status = 'fail'", (since,)).fetchone()[0]
    finally:
        conn.close()

    return {
        "ok": True, "days": days,
        "runs": total_runs, "failed_runs": failed_runs,
        "run_fail_rate": round(failed_runs / total_runs, 4) if total_runs else 0.0,
        "by_step": by_step, "top_errors": top_errors,
        "by_platform": by_platform, "crash_signals": crashes,
        "recent_failures": recent,
    }


@router.get("/api/admin/install-telemetry/summary")
async def install_telemetry_summary(request: Request, days: int = 7,
                                    limit_failures: int = 50):
    """Fleet-wide install health. Admin-only, fail closed."""
    if not _authorized(request):
        return JSONResponse({"ok": False, "error": "unauthorized"}, 401)
    try:
        data = build_summary(days=days, limit_failures=limit_failures)
    except Exception as exc:
        log.error("[TELEMETRY] summary failed: %s", exc)
        return JSONResponse({"ok": False, "error": "telemetry unavailable"}, 500)
    return JSONResponse(data, headers={"Cache-Control": "no-store"})


# ── INTEGRATION POINTS (documented, deliberately NOT wired) ───────────
#
# server/__init__.py is another agent's file on this branch and is already
# modified there, so this router registers itself nowhere yet. Two edits,
# both in that file, both one line:
#
#   1. REGISTER. Beside the other include_router calls (~line 451, next to
#      _r_onboarding), using the same _safe_import helper so a bad import
#      here cannot take the whole app down:
#
#          _r_install_telemetry = _safe_import("install_telemetry_routes")
#          app.include_router(_r_install_telemetry.router)
#
#   2. EXEMPT THE WRITE PATH. Add to _AUTH_EXEMPT_PATHS (~line 109, right
#      beside "/api/onboarding/install-log", which is exempt for the exact
#      same reason — a customer's machine holds no server key):
#
#          "/api/telemetry/install-event",
#
#      ONLY that path. NOT a "/api/telemetry/" prefix, and never the
#      summary: /api/admin/install-telemetry/summary must stay behind the
#      middleware as well as behind the in-route bearer check above.
#
# Until (2) lands the installer's events get 401s. That is harmless by
# construction — telemetry_event() ignores every response — so the two
# edits can ship in either order.
