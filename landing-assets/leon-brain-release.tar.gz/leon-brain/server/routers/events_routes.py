"""
/api/webhooks/* + /api/events/* + /api/plugins — webhook registration,
event bus query/stream (SSE), plugin manifest.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged.
"""

import asyncio
import json
import logging
from typing import Optional

from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from brain.events import event_bus, webhook_manager
from brain.plugins import list_plugins

log = logging.getLogger("leon.server")
router = APIRouter()


# =============================================================================
# Webhooks
# =============================================================================

@router.post("/api/webhooks")
async def webhook_register(req: dict):
    url = (req.get("url") or "").strip()
    if not url or not url.startswith(("http://", "https://")):
        return {"ok": False, "error": "valid url is required"}
    event_types = req.get("event_types") or ["*"]
    secret = req.get("secret", "")
    wh = webhook_manager.register(url=url, event_types=event_types, secret=secret)
    return {"ok": True, "webhook": wh.to_dict()}


@router.get("/api/webhooks")
async def webhooks_list():
    return {"webhooks": [w.to_dict() for w in webhook_manager.list_webhooks()]}


@router.delete("/api/webhooks/{webhook_id}")
async def webhook_unregister(webhook_id: str):
    return {"ok": webhook_manager.unregister(webhook_id)}


# =============================================================================
# Event bus
# =============================================================================

@router.get("/api/events/recent")
async def events_recent(limit: int = 50, type: Optional[str] = None):
    return {"events": event_bus.recent(limit=limit, event_type=type)}


@router.get("/api/events/stream")
async def events_stream():
    event_queue: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_event_loop()

    def _on_event(ev):
        try:
            loop.call_soon_threadsafe(event_queue.put_nowait, ev)
        except Exception:
            pass

    unsub = event_bus.subscribe(_on_event)

    async def _gen():
        try:
            yield ": connected\n\n"
            while True:
                try:
                    ev = await asyncio.wait_for(event_queue.get(), timeout=30.0)
                    data = json.dumps(ev.to_dict())
                    yield f"event: {ev.type}\ndata: {data}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            unsub()

    return StreamingResponse(_gen(), media_type="text/event-stream")


# =============================================================================
# Plugins
# =============================================================================

@router.get("/api/plugins")
async def plugins_list():
    from dataclasses import asdict
    return {"plugins": [asdict(p) for p in list_plugins()]}
