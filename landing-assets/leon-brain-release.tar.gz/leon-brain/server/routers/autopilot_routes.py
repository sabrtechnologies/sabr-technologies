"""
Phase 17: Autopilot Operations API + /autopilot HTML page.

Autopilot is Leon's self-driving loop — scheduler ticks every N seconds,
classifies candidate actions by tier (auto-allowed / requires approval /
forbidden), and either executes, queues for Dean's approval, or refuses.
Executor handles approval/rejection/rollback flow. Planner scans
workspaces and ranks projects by priority.

Extracted from server/routers/mission.py 2026-06-08 per architecture
review. Behavior unchanged; routes import the same state surface.
"""

import asyncio
import os
from dataclasses import asdict

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, FileResponse

from brain.mission import Tier, classify_tier
from server import state

router = APIRouter()


@router.get("/autopilot")
async def autopilot_panel():
    # Was a bare FileResponse — ships the raw file off disk with its
    # hardcoded "<title>Leon — Autopilot Operations</title>" untouched. Every
    # other panel routes through server._branded_page() (see its docstring:
    # "which is exactly how ten panels kept saying LEON"); this one was
    # extracted into its own router file and missed that pass. Deferred
    # import avoids a circular import at module load time (server/__init__.py
    # imports this router).
    from server import _branded_page
    return _branded_page("autopilot.html")


@router.get("/api/autopilot/status")
async def autopilot_status():
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse(state.autopilot_scheduler.status())


@router.get("/api/autopilot/tick")
async def autopilot_tick(request: Request):
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    force = request.query_params.get("force", "false").lower() in ("true", "1", "yes")
    # Run in thread pool so it doesn't block the event loop (tick spawns subprocesses)
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, lambda: state.autopilot_scheduler.tick(force=force))
    return JSONResponse(result)


@router.get("/api/autopilot/approvals")
async def autopilot_approvals():
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse({"approvals": state.autopilot_executor.pending_approvals()})


@router.post("/api/autopilot/approve/{action_id}")
async def autopilot_approve(action_id: str, request: Request):
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass
    action = state.autopilot_executor.approve(action_id, body.get("approved_by", "Dean"))
    if not action:
        return JSONResponse({"error": "Action not found"}, 404)
    return JSONResponse(asdict(action))


@router.post("/api/autopilot/reject/{action_id}")
async def autopilot_reject(action_id: str, request: Request):
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass
    action = state.autopilot_executor.reject(action_id, body.get("reason", ""))
    if not action:
        return JSONResponse({"error": "Action not found"}, 404)
    return JSONResponse(asdict(action))


@router.post("/api/autopilot/rollback/{action_id}")
async def autopilot_rollback(action_id: str):
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    action = state.autopilot_executor.rollback(action_id)
    if not action:
        return JSONResponse({"error": "Action not found"}, 404)
    return JSONResponse(asdict(action))


@router.get("/api/autopilot/activity")
async def autopilot_activity(request: Request):
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    limit = int(request.query_params.get("limit", "50"))
    status = request.query_params.get("status")
    project_id = request.query_params.get("project_id")
    return JSONResponse({"actions": state.autopilot_executor.list_actions(
        status=status, project_id=project_id, limit=limit)})


@router.get("/api/autopilot/stats")
async def autopilot_stats():
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse(state.autopilot_executor.stats())


@router.get("/api/autopilot/report/generate")
async def autopilot_gen_report():
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse(state.autopilot_executor.generate_daily_report())


@router.get("/api/autopilot/report/{date_str}")
async def autopilot_get_report(date_str: str):
    if not state.autopilot_executor:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    report = state.autopilot_executor.get_daily_report(date_str)
    if not report:
        return JSONResponse({"error": "No report for that date"}, 404)
    return JSONResponse(report)


@router.get("/api/autopilot/classify")
async def autopilot_classify_action(request: Request):
    action = request.query_params.get("action", "")
    if not action:
        return JSONResponse({"error": "action parameter required"}, 400)
    tier = classify_tier(action)
    return JSONResponse({"action": action, "tier": tier.value, "tier_name": tier.name,
                         "auto_allowed": tier in (Tier.AUTO_ALLOWED, Tier.AUTO_WITH_ROLLBACK)})


@router.get("/api/autopilot/workspaces")
async def autopilot_workspaces():
    if not state.autopilot_planner:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    workspaces = state.autopilot_planner.scan_workspaces()
    stuck = state.autopilot_planner.detect_stuck_terminals()
    return JSONResponse({"terminals": workspaces, "stuck": stuck})


@router.get("/api/autopilot/plan")
async def autopilot_plan(request: Request):
    if not state.autopilot_planner:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    project_id = request.query_params.get("project_id")
    if project_id and state.mission_registry:
        proj = state.mission_registry.get(project_id) or state.mission_registry.get_by_name(project_id)
        if proj:
            return JSONResponse({"actions": state.autopilot_planner.plan_for_project(proj)})
        return JSONResponse({"error": "Project not found"}, 404)
    return JSONResponse({"actions": state.autopilot_planner.plan_all()})


@router.get("/api/autopilot/priority")
async def autopilot_priority():
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    ranked = state.autopilot_scheduler.priority.rank_projects()
    top = state.autopilot_scheduler.priority.top_recommendation()
    return JSONResponse({"ranking": ranked, "recommendation": top})


@router.get("/api/autopilot/github")
async def autopilot_github():
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    activity = state.autopilot_scheduler.github_watcher.scan_all_repos(state.mission_registry)
    return JSONResponse(activity)


@router.get("/api/autopilot/health")
async def autopilot_self_health():
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse(state.autopilot_scheduler.health_monitor.check())


@router.get("/api/autopilot/brain")
async def autopilot_brain_bridge():
    """See how the SNN drives autopilot behavior in real time."""
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse(state.autopilot_scheduler.brain_bridge.explain())


@router.get("/api/autopilot/consciousness")
async def autopilot_consciousness():
    """Leon's unified awareness -- pending observations, last spoke, status."""
    if not state.leon_consciousness:
        return JSONResponse({"error": "Consciousness not initialized"}, 500)
    return JSONResponse({
        **state.leon_consciousness.status(),
        "pending_observations": state.leon_consciousness.peek(),
    })


@router.get("/api/autopilot/terminals")
async def autopilot_terminals():
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse({"terminals": state.autopilot_scheduler.terminal_resurrector.resurrect_all()})


@router.get("/api/autopilot/morning")
async def autopilot_morning():
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse(state.autopilot_scheduler.morning_briefing.deliver())


@router.get("/api/autopilot/daily")
async def autopilot_daily_report():
    if not state.autopilot_scheduler:
        return JSONResponse({"error": "Autopilot not initialized"}, 500)
    return JSONResponse(state.autopilot_scheduler.daily_reporter.generate_and_deliver())
