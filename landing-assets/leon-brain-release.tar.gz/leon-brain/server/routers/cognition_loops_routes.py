"""
Cognition loops: sleep / dream / autobiography / goals / inner_voice /
self_tuning / stakes / ambient / opinions.

These are all the "passive cognition" surfaces — read-only state
queries + occasional targeted writes (add goal, form opinion, seed
dream, etc). All gated by middleware auth like the rest of /api/*.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged.
"""

import logging

from fastapi import APIRouter

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


# =============================================================================
# Sleep consolidation
# =============================================================================

@router.get("/api/sleep/status")
async def sleep_status():
    if state.sleep_consolidator is None:
        return {"ok": False, "error": "sleep consolidator not running"}
    return state.sleep_consolidator.status()


@router.get("/api/sleep/insights")
async def sleep_insights(limit: int = 20):
    if state.sleep_consolidator is None:
        return {"insights": []}
    return {"insights": state.sleep_consolidator.recent_insights(limit=limit)}


@router.post("/api/sleep/consolidate")
async def sleep_force_consolidation():
    if state.sleep_consolidator is None:
        return {"ok": False, "error": "sleep consolidator not running"}
    r = state.sleep_consolidator.consolidate()
    return {"ok": True, "pass": r.to_dict()}


@router.get("/api/sleep/history")
async def sleep_history(limit: int = 20):
    if state.sleep_consolidator is None:
        return {"history": []}
    return {"history": state.sleep_consolidator.history(limit=limit)}


# =============================================================================
# Dreams — SNN-level sleep cycles
# =============================================================================

@router.get("/api/dream/state")
async def dream_state():
    if state.dream_engine is None:
        return {"ok": False, "error": "dream engine not running"}
    return state.dream_engine.get_state()


@router.get("/api/dream/journal")
async def dream_journal(limit: int = 10):
    if state.dream_engine is None:
        return {"dreams": []}
    return {"dreams": state.dream_engine.recent_dreams(limit=limit)}


@router.post("/api/dream/seed")
async def dream_seed(data: dict = {}):
    """Inject a strong firing pattern into hippocampus to seed a memory.
    Call multiple times with different text to build up dream material."""
    if state.brain is None:
        return {"ok": False, "error": "brain not running"}
    hippo = state.brain.regions.get("hippocampus")
    if hippo is None:
        return {"ok": False, "error": "no hippocampus"}
    import numpy as np
    text = data.get("text", "")
    n = hippo.n_neurons
    h = hash(text) if text else np.random.randint(0, 2**31)
    pattern = np.zeros(n, dtype=np.float32)
    for i in range(n // 10):
        idx = (h + i * 7919) % n
        pattern[idx] = 20.0
    hippo.neurons.inject_current(pattern)
    fired = pattern > 0
    if np.sum(fired) >= 5:
        hippo.memory_buffer.append(fired)
        hippo._memory_strength.append(1.0 + abs(hash(text) % 100) / 100)
        hippo._memory_labels.append(text[:200] if text else "")
        if len(hippo.memory_buffer) > hippo.max_memories:
            weakest = int(np.argmin(hippo._memory_strength))
            hippo.memory_buffer.pop(weakest)
            hippo._memory_strength.pop(weakest)
    return {
        "ok": True,
        "memories_stored": len(hippo.memory_buffer),
        "neurons_activated": int(np.sum(fired)),
    }


@router.get("/api/dream/last")
async def dream_last():
    if state.dream_engine is None:
        return {"dream": None}
    return {"dream": state.dream_engine.last_dream()}


# =============================================================================
# Autobiography — episodic narrative timeline
# =============================================================================

@router.get("/api/autobiography/state")
async def autobiography_state():
    if state.autobiography is None:
        return {"ok": False, "error": "autobiography not running"}
    return state.autobiography.get_state()


@router.get("/api/autobiography/recent")
async def autobiography_recent(limit: int = 20, hours: float = 48):
    if state.autobiography is None:
        return {"events": []}
    return {"events": state.autobiography.recent(limit=limit)}


@router.get("/api/autobiography/narrative")
async def autobiography_narrative(hours: float = 24):
    if state.autobiography is None:
        return {"narrative": ""}
    return {"narrative": state.autobiography.recent_narrative(hours=hours)}


# =============================================================================
# Goals — persistent long-term desires
# =============================================================================

@router.get("/api/goals/state")
async def goals_state():
    if state.goal_system is None:
        return {"ok": False, "error": "goal system not running"}
    return state.goal_system.get_state()


@router.post("/api/goals/add")
async def goals_add(data: dict):
    if state.goal_system is None:
        return {"ok": False, "error": "goal system not running"}
    goal_type = data.get("type", "learn")
    description = data.get("description", "").strip()
    if not description:
        return {"ok": False, "error": "description required"}
    source = data.get("source", "dean")
    priority = float(data.get("priority", 0.5))
    g = state.goal_system.add(goal_type, description, source=source, priority=priority)
    if state.autobiography is not None:
        state.autobiography.record("goal", f"New goal: {description}")
    return {"ok": True, "goal": g.to_dict()}


@router.post("/api/goals/update")
async def goals_update(data: dict):
    if state.goal_system is None:
        return {"ok": False, "error": "goal system not running"}
    goal_id = data.get("id", "")
    progress = data.get("progress")
    note = data.get("note", "")
    if progress is not None:
        state.goal_system.update_progress(goal_id, float(progress), note)
    return {"ok": True}


@router.post("/api/goals/complete")
async def goals_complete(data: dict):
    if state.goal_system is None:
        return {"ok": False, "error": "goal system not running"}
    goal_id = data.get("id", "")
    state.goal_system.complete(goal_id, data.get("note", ""))
    return {"ok": True}


# =============================================================================
# Drives — Leon's biological-style motivation system
# =============================================================================

@router.get("/api/drives/state")
async def drives_state():
    """Live snapshot of Leon's drives + body state with English explanations.

    Useful for tuning gates like _social_reach_out's social_hunger >= 0.3.
    """
    if state.drive_system is None:
        return {"ok": False, "error": "drive system not running"}
    try:
        snap = state.drive_system.explain()
        d = state.drive_system.get_drives()
        # asdict-style dump of the live DriveState for tuning purposes
        from dataclasses import asdict as _asdict
        snap["drives_raw"] = _asdict(d)
        return {"ok": True, **snap}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# =============================================================================
# Inner Voice — stream of consciousness
# =============================================================================

@router.get("/api/inner_voice/state")
async def inner_voice_state():
    if state.inner_voice is None:
        return {"ok": False, "error": "inner voice not running"}
    return state.inner_voice.get_state()


@router.get("/api/inner_voice/thoughts")
async def inner_voice_thoughts(limit: int = 10):
    if state.inner_voice is None:
        return {"thoughts": []}
    return {"thoughts": state.inner_voice.recent_thoughts(limit=limit)}


# =============================================================================
# Self-Tuning — self-modifiable parameters
# =============================================================================

@router.get("/api/self_tuning/state")
async def self_tuning_state():
    if state.self_tuning is None:
        return {"ok": False, "error": "self-tuning not running"}
    return state.self_tuning.get_state()


@router.post("/api/self_tuning/adjust")
async def self_tuning_adjust(data: dict):
    if state.self_tuning is None:
        return {"ok": False, "error": "self-tuning not running"}
    param = data.get("parameter", "")
    value = data.get("value")
    reason = data.get("reason", "")
    source = data.get("source", "dean")
    if value is None:
        return {"ok": False, "error": "value required"}
    ok = state.self_tuning.adjust(param, float(value), reason, source)
    if ok:
        state.self_tuning.apply_to_brain(
            brain=state.brain,
            dream_engine=state.dream_engine,
            inner_voice=state.inner_voice,
        )
    return {"ok": ok, "values": state.self_tuning._values}


# =============================================================================
# Stakes — things Leon can lose
# =============================================================================

@router.get("/api/stakes/state")
async def stakes_state():
    if state.stakes_tracker is None:
        return {"ok": False, "error": "stakes tracker not running"}
    return state.stakes_tracker.get_state()


# =============================================================================
# Ambient Perception — continuous sensory awareness
# =============================================================================

@router.get("/api/ambient/state")
async def ambient_state():
    if state.ambient_perception is None:
        return {"ok": False, "error": "ambient perception not running"}
    return state.ambient_perception.get_state()


# =============================================================================
# Opinions — persistent preferences and judgments
# =============================================================================

@router.get("/api/opinions/state")
async def opinions_state():
    if state.opinion_tracker is None:
        return {"ok": False, "error": "opinion tracker not running"}
    return state.opinion_tracker.get_state()


@router.post("/api/opinions/form")
async def opinions_form(data: dict):
    if state.opinion_tracker is None:
        return {"ok": False, "error": "opinion tracker not running"}
    o = state.opinion_tracker.form_opinion(
        data.get("topic", ""),
        data.get("stance", ""),
        float(data.get("valence", 0)),
        float(data.get("confidence", 0.5)),
        source=data.get("source", "dean"),
    )
    return {"ok": True, "opinion": o.to_dict()}
