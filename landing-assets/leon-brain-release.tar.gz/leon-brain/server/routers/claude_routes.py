"""
/api/claude/* routes — Claude bridge surface: summary, insights, observe,
status, activity, learned, recall, search, semantic, knowledge, remember.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged; routes import the same dependencies they used to. Routed
into the app from server/__init__.py.
"""

import json
from brain import identity
import logging

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


@router.get("/api/claude/summary")
async def claude_summary():
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    try:
        result = state.claude_bridge.get_brain_summary()
        return JSONResponse(json.loads(json.dumps(result, default=str)))
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/claude/insights")
async def claude_insights():
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    try:
        result = state.claude_bridge.get_insights()
        return JSONResponse(json.loads(json.dumps(result, default=str)))
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.post("/api/claude/observe")
async def claude_observe(data: dict):
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    state.claude_bridge.send_observation(data)
    return {"status": "ok", "interaction_count": state.claude_bridge._interaction_count}


@router.get("/api/claude/conversation")
async def claude_conversation(limit: int = 60, since: float = 0.0):
    """Shared conversation transcript from the SQLite store — the single
    source of truth so every device (phone, desktop) renders the SAME
    history in real time. Returns chronological turns newer than `since`."""
    import os
    import sqlite3
    db = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                      "brain_state", "knowledge.db")

    def _text(content):
        try:
            obj = json.loads(content)
        except Exception:
            return content
        if isinstance(obj, list):
            out = []
            for b in obj:
                if isinstance(b, dict):
                    if b.get("type") == "text" and b.get("text"):
                        out.append(b["text"])
                elif isinstance(b, str):
                    out.append(b)
            return "\n".join(out) if out else (content if isinstance(content, str) else "")
        if isinstance(obj, str):
            return obj
        return content

    try:
        limit = max(1, min(int(limit), 300))
        # Display-only "clear" watermark: hide turns at/before the last Clear so
        # the on-screen log is fresh on every device. This filters ONLY what the
        # transcript endpoint returns — Leon's stored history and context are
        # completely untouched (Clear never wipes memory).
        cleared_before = 0.0
        try:
            _mp = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                               "brain_state", "conv_display_cleared")
            with open(_mp) as _mf:
                cleared_before = float(_mf.read().strip())
        except Exception:
            cleared_before = 0.0
        effective_since = max(float(since), cleared_before)
        con = sqlite3.connect(db, timeout=10)
        rows = con.execute(
            "SELECT ts, role, content FROM conversation_history "
            "WHERE session_id='default' AND model!='proactive' AND model!='birth' AND ts > ? "
            "ORDER BY id DESC LIMIT ?",
            (effective_since, limit),
        ).fetchall()
        con.close()
        turns = []
        for ts, role, content in reversed(rows):
            txt = (_text(content) or "").strip()
            if not txt:
                continue
            turns.append({"ts": ts, "role": role, "text": txt})
        return JSONResponse({"ok": True, "turns": turns},
                            headers={"Cache-Control": "no-store"})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)


@router.post("/api/claude/conversation/archive_clear")
async def archive_and_clear_conversation():
    """Clear button: ARCHIVE the whole conversation transcript to a timestamped
    file (so weeks of log aren't lost), then WIPE the active log for a fresh
    start. Only the raw chat transcript resets — Leon's durable memory (facts,
    knowledge.db) and brain_state are untouched."""
    import os
    import sqlite3
    import time
    base = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    db = os.path.join(base, "brain_state", "knowledge.db")
    archive_dir = os.path.join(base, "brain_state", "conversation_archives")

    def _extract_text(content):
        if isinstance(content, str) and content.startswith("__BLOCKS__"):
            content = content[len("__BLOCKS__"):]
        try:
            obj = json.loads(content)
        except Exception:
            return content if isinstance(content, str) else str(content)
        if isinstance(obj, list):
            out = []
            for b in obj:
                if isinstance(b, dict) and b.get("type") == "text" and b.get("text"):
                    out.append(b["text"])
                elif isinstance(b, str):
                    out.append(b)
            return "\n".join(out)
        return obj if isinstance(obj, str) else str(content)

    try:
        os.makedirs(archive_dir, exist_ok=True)
        con = sqlite3.connect(db, timeout=10)
        rows = con.execute(
            "SELECT ts, role, content FROM conversation_history "
            "WHERE session_id='default' ORDER BY id ASC"
        ).fetchall()
        stamp = time.strftime("%Y%m%d-%H%M%S")
        path = os.path.join(archive_dir, f"conversation-{stamp}.md")
        n = 0
        with open(path, "w") as f:
            f.write(f"# Leon conversation archive — {stamp}\n\n")
            for ts, role, content in rows:
                txt = (_extract_text(content) or "").strip()
                if not txt:
                    continue
                # identity.turn_labels() is the single source of truth for
                # these two — they were hardcoded, so an export from a
                # client SI attributed their own words to the owner.
                _u, _si = identity.turn_labels()
                speaker = (_u if role == "user" else _si).rstrip(":")
                tstr = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))
                f.write(f"**{speaker}** ({tstr}):\n{txt}\n\n")
                n += 1
        con.close()
        # DO NOT delete conversation_history or touch Leon's in-memory context —
        # that IS his memory, and Clear must never wipe it. Instead set a
        # DISPLAY-ONLY watermark: the transcript endpoint hides turns at/before
        # this ts on every device, so the on-screen log goes fresh while Leon
        # keeps his full context and durable memory. Reversible (delete marker).
        marker = os.path.join(base, "brain_state", "conv_display_cleared")
        with open(marker, "w") as mf:
            mf.write(str(time.time()))
        return JSONResponse({"ok": True, "archived_file": path, "turns_archived": n,
                             "note": "log archived + display cleared; Leon's memory untouched"})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)


@router.get("/api/claude/status")
async def claude_status():
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    s = state.claude_bridge.get_state()
    if state.screen_observer:
        s["screen_observer"] = state.screen_observer.get_state()
    if state.video_recorder:
        s["video_recorder"] = state.video_recorder.get_state()
    return JSONResponse(s)


@router.get("/api/claude/activity")
async def claude_activity():
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    return JSONResponse(state.claude_bridge.get_activity_log())


@router.get("/api/claude/learned")
async def claude_learned():
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    try:
        result = state.claude_bridge.get_learned_patterns()
        return JSONResponse(json.loads(json.dumps(result, default=str)))
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/claude/learned/summary")
async def claude_learned_summary():
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    try:
        text = state.claude_bridge.get_learning_summary()
        return JSONResponse({"summary": text})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/claude/recall")
async def claude_recall(q: str = "", limit: int = 10):
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    if not q:
        return JSONResponse({"error": "Query parameter 'q' is required"}, status_code=400)
    try:
        results = state.claude_bridge.recall(q, limit=limit)
        return JSONResponse({"query": q, "results": results, "count": len(results)})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/claude/search")
async def claude_search(q: str = "", limit: int = 20):
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    if not q:
        return JSONResponse({"error": "Query parameter 'q' is required"}, status_code=400)
    try:
        results = state.claude_bridge.search_knowledge(q, limit=limit)
        return JSONResponse({"query": q, "results": results, "count": len(results)})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/claude/semantic")
async def claude_semantic(q: str = "", limit: int = 10):
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    if not q:
        return JSONResponse({"error": "Query parameter 'q' is required"}, status_code=400)
    try:
        results = state.claude_bridge.knowledge.semantic_search(q, limit=limit)
        return JSONResponse({"query": q, "results": results, "count": len(results),
                             "mode": "semantic_tfidf"})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/claude/knowledge")
async def claude_knowledge():
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    try:
        stats = state.claude_bridge.get_knowledge_stats()
        recent = state.claude_bridge.get_recent_knowledge(limit=10)
        return JSONResponse({"stats": stats, "recent": recent})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.post("/api/claude/remember")
async def claude_remember(data: dict):
    if not state.claude_bridge:
        return JSONResponse({"error": "Bridge not initialized"}, status_code=503)
    text = data.get("text", "")
    if not text:
        return JSONResponse({"error": "text field is required"}, status_code=400)
    source = data.get("source", "claude")
    tags = data.get("tags", None)
    try:
        entry_id = state.claude_bridge.store_knowledge(text=text, source=source, tags=tags)
        return {"status": "stored", "id": entry_id}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
