"""
/api/screen/* + /api/video/* — screen observer + video recorder controls.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged.
"""

import logging
import os

from fastapi import APIRouter
from fastapi.responses import JSONResponse, FileResponse

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


# =============================================================================
# Screen Observation
# =============================================================================

@router.post("/api/screen/start")
async def start_screen():
    if not state.screen_observer:
        return JSONResponse({"error": "Screen observer not initialized"}, status_code=503)
    success = state.screen_observer.start()
    return {"status": "started" if success else "unavailable"}


@router.post("/api/screen/stop")
async def stop_screen():
    if state.screen_observer:
        state.screen_observer.stop()
    return {"status": "stopped"}


@router.get("/api/screen/state")
async def screen_state():
    if not state.screen_observer:
        return JSONResponse({"error": "Screen observer not initialized"}, status_code=503)
    return JSONResponse(state.screen_observer.get_state())


# =============================================================================
# Video Recording
# =============================================================================

@router.post("/api/video/start")
async def start_video():
    if not state.video_recorder:
        return JSONResponse({"error": "Video recorder not initialized"}, status_code=503)
    success = state.video_recorder.start()
    return {"status": "started" if success else "unavailable"}


@router.post("/api/video/stop")
async def stop_video():
    if state.video_recorder:
        state.video_recorder.stop()
    return {"status": "stopped"}


@router.get("/api/video/state")
async def video_state():
    if not state.video_recorder:
        return JSONResponse({"error": "Video recorder not initialized"}, status_code=503)
    return JSONResponse(state.video_recorder.get_state())


@router.get("/api/video/list")
async def video_list():
    if not state.video_recorder:
        return JSONResponse({"error": "Video recorder not initialized"}, status_code=503)
    return JSONResponse({"recordings": state.video_recorder.list_recordings()})


@router.post("/api/video/delete")
async def video_delete(data: dict):
    if not state.video_recorder:
        return JSONResponse({"error": "Video recorder not initialized"}, status_code=503)
    name = data.get("name")
    if not name:
        return JSONResponse({"error": "Missing 'name' field"}, status_code=400)
    success = state.video_recorder.delete_recording(name)
    return {"status": "deleted" if success else "not_found", "name": name}


@router.get("/api/video/recording/{filename}")
async def video_download(filename: str):
    if not state.video_recorder:
        return JSONResponse({"error": "Video recorder not initialized"}, status_code=503)
    if not filename.endswith(".mp4") or "/" in filename or "\\" in filename or ".." in filename:
        return JSONResponse({"error": "Invalid filename"}, status_code=400)
    path = os.path.join(state.video_recorder.output_dir, filename)
    if not os.path.isfile(path):
        return JSONResponse({"error": "Not found"}, status_code=404)
    return FileResponse(path, media_type="video/mp4", filename=filename)
