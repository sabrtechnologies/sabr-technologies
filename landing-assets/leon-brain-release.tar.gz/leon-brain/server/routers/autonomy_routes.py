"""
Autonomy surfaces: projects crawler, wake-word listener, region lesion
ablation, reminders, routines, presence, proactive ambient loop, abort.

These all share the theme of "Leon doing things on his own" — proactive
state queries + control over the autonomous loops.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged.
"""

import asyncio
import logging
import os

from fastapi import APIRouter, Request

from server import state
from server.helpers import _broadcast_threadsafe, _ensure_wake_orchestrator

log = logging.getLogger("leon.server")
router = APIRouter()


# =============================================================================
# Project crawler
# =============================================================================

@router.get("/api/projects/state")
async def project_crawler_state():
    if state.project_crawler is None:
        return {"ok": False, "error": "crawler not running"}
    return {"ok": True, **state.project_crawler.get_state()}


@router.post("/api/projects/recrawl")
async def project_crawler_recrawl():
    if state.project_crawler is None:
        return {"ok": False, "error": "crawler not running"}
    loop = asyncio.get_running_loop()
    stats = await loop.run_in_executor(None, state.project_crawler.crawl_once)
    return {"ok": True, **stats}


# =============================================================================
# Wake-word listener
# =============================================================================

@router.post("/api/wake/start")
async def wake_start():
    orch = _ensure_wake_orchestrator()
    if orch is None:
        return {"ok": False, "error": "wake stack unavailable (check openwakeword + sounddevice)"}
    if state.wake_listener.is_running():
        try:
            state.wake_listener.resume()
        except Exception:
            pass
        state.wake_user_enabled = True
        _broadcast_threadsafe({"type": "wake_listening", "listening": True})
        return {"ok": True, "already_running": True, **orch.get_state()}
    started = state.wake_listener.start()
    if not started:
        return {"ok": False, "error": state.wake_listener.stats.get("error") or "start failed"}
    # MASTER SWITCH (Dean, 2026-08-07): the dashboard wake button is the ONE
    # authority on whether "hey leon" works AT ALL. The PC-side Vosk loop in
    # sensor_relay never consulted it — it woke on Leon's own TTS while the
    # button was off. /api/relay/wake and /api/relay/heard now check this flag
    # and drop everything while it's False. Default after restart: False
    # (button off = deaf, by design).
    state.wake_user_enabled = True
    _broadcast_threadsafe({"type": "wake_listening", "listening": True})
    return {"ok": True, **orch.get_state()}


@router.post("/api/wake/stop")
async def wake_stop():
    # Master switch OFF first, unconditionally — even if pausing the local
    # listener fails, the relay-facing gates must go deaf immediately.
    state.wake_user_enabled = False
    if state.wake_listener is None or not state.wake_listener.is_running():
        return {"ok": True, "already_stopped": True}
    try:
        state.wake_listener.pause()
    except Exception as e:
        return {"ok": False, "error": f"pause failed: {e}"}
    _broadcast_threadsafe({"type": "wake_listening", "listening": False})
    return {"ok": True, "paused": True}


@router.get("/api/wake/state")
async def wake_state():
    if state.wake_orchestrator is None:
        # BRANDING LEAK (found 2026-08-12, Aiden's install of "Iris").
        # This literal is the ONE wake string that _brand_html() cannot reach:
        # every "hey leon" in dashboard/index.html is rewritten on the way out
        # (server/__init__.py, `_html.replace('hey leon', ...)`), but those are
        # only the JS *fallbacks* — `j.wake_word || 'hey leon'`. The value the
        # UI actually paints comes over the wire from THIS endpoint as JSON,
        # which is never branded. And this branch is precisely the fresh-client
        # case: no openwakeword/sounddevice yet means orchestrator is None, so
        # a brand-new SI named Iris told its owner it was listening for
        # "hey leon". brain/voice/wake_word_vosk.py already derives its default
        # from LEON_SI_NAME; do the same here so the two agree.
        _si = (os.environ.get("LEON_SI_NAME") or "SI").strip().lower() or "si"
        _ww = os.environ.get("LEON_WAKE_WORD") or f"hey {_si}"
        return {"ok": True, "available": True, "enabled": False, "wake_word": _ww}
    return {"ok": True, **state.wake_orchestrator.get_state()}


# =============================================================================
# Voluntary sleep / rest (commanded — bypasses the adenosine/circadian gates)
# =============================================================================

@router.post("/api/sleep/now")
async def sleep_now(request: Request):
    """Put Leon to sleep on command ('get some rest'). Couples brain._is_asleep
    so fatigue actually recovers; he wakes on a fresh message or a 30-min cap."""
    if state.dream_engine is None:
        return {"ok": False, "error": "dream engine not running"}
    reason = "commanded"
    try:
        body = await request.json()
        reason = (body or {}).get("reason", "commanded")
    except Exception:
        pass
    state.dream_engine.command_sleep(reason=reason)
    return {"ok": True, "sleep_state": state.dream_engine.sleep_state,
            "is_asleep": bool(getattr(state.brain, "_is_asleep", False))}


@router.post("/api/sleep/wake")
async def sleep_wake():
    """Wake Leon from a commanded sleep."""
    if state.dream_engine is None:
        return {"ok": False, "error": "dream engine not running"}
    state.dream_engine.command_wake(reason="api")
    return {"ok": True, "sleep_state": state.dream_engine.sleep_state,
            "is_asleep": bool(getattr(state.brain, "_is_asleep", False))}


@router.get("/api/sleep/state")
async def sleep_state_get():
    if state.dream_engine is None:
        return {"ok": False, "error": "dream engine not running"}
    return {"ok": True, "sleep_state": state.dream_engine.sleep_state,
            "is_asleep": bool(getattr(state.brain, "_is_asleep", False)),
            "commanded": bool(getattr(state.dream_engine, "_commanded_sleep", False))}


# =============================================================================
# Region lesion ablation
# =============================================================================

@router.post("/api/ablation/lesion")
async def ablation_lesion(request: Request):
    """Start a region lesion via API. Body: {"region": "anterior_cingulate", "duration_s": 1800}"""
    body = await request.json()
    region = body.get("region", "")
    duration_s = float(body.get("duration_s", 600))
    if not region:
        return {"ok": False, "error": "region required"}
    if state.brain is None:
        return {"ok": False, "error": "brain not initialized"}
    from brain.ablation.ablations.region_lesion import lesion_now
    ok = lesion_now(state.brain, region, duration_s)
    return {"ok": ok, "region": region, "duration_s": duration_s}


# =============================================================================
# Reminders
# =============================================================================

@router.get("/api/reminders")
async def reminders_state():
    if state.reminder_scheduler is None:
        return {"ok": False, "error": "scheduler not running"}
    return {"ok": True, **state.reminder_scheduler.get_state()}


@router.post("/api/reminders")
async def reminders_create(req: dict):
    if state.reminder_scheduler is None:
        return {"ok": False, "error": "scheduler not running"}
    text = (req.get("text") or "").strip()
    if not text:
        return {"ok": False, "error": "text is required"}
    in_secs = req.get("in_seconds")
    at_iso = req.get("at_iso")
    from brain.identity import si_name as _sn
    title = req.get("title") or _sn()
    in_secs_f = float(in_secs) if in_secs is not None else None
    at_unix = None
    if at_iso:
        import datetime as _dt
        try:
            at_unix = _dt.datetime.fromisoformat(str(at_iso)).timestamp()
        except Exception:
            return {"ok": False, "error": "invalid at_iso"}
    if in_secs_f is None and at_unix is None:
        return {"ok": False, "error": "specify in_seconds or at_iso"}
    rem = state.reminder_scheduler.add(text=text, in_seconds=in_secs_f, at_unix=at_unix, title=title)
    return {"ok": True, "id": rem.id, "due_ts": rem.due_ts}


@router.delete("/api/reminders/{rid}")
async def reminders_cancel(rid: str):
    if state.reminder_scheduler is None:
        return {"ok": False, "error": "scheduler not running"}
    return {"ok": state.reminder_scheduler.cancel(rid)}


# =============================================================================
# Routines
# =============================================================================

@router.get("/api/routines")
async def routines_list():
    if state.routine_scheduler is None:
        return {"ok": False, "error": "scheduler not running"}
    from brain.routines import routine_list
    return {"ok": True, "routines": routine_list()}


@router.post("/api/routines/{name}/run")
async def routines_run(name: str):
    if state.routine_scheduler is None:
        return {"ok": False, "error": "scheduler not running"}
    from brain.routines import routine_run_now
    try:
        return {"ok": True, "result": routine_run_now(name)}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


@router.post("/api/routines/{name}/enable")
async def routines_enable(name: str):
    if state.routine_scheduler is None:
        return {"ok": False, "error": "scheduler not running"}
    from brain.routines import routine_enable
    return {"ok": routine_enable(name)}


@router.post("/api/routines/{name}/disable")
async def routines_disable(name: str):
    if state.routine_scheduler is None:
        return {"ok": False, "error": "scheduler not running"}
    from brain.routines import routine_disable
    return {"ok": routine_disable(name)}


# =============================================================================
# Presence
# =============================================================================

@router.get("/api/presence/recent")
async def presence_recent(limit: int = 20):
    try:
        from brain.presence import EXTRA_TOOLS as _P
        fn = _P.get("presence.dashboard_log_recent")
        if fn is None:
            return {"ok": True, "events": []}
        return fn({"limit": limit})
    except Exception as e:
        return {"ok": False, "error": str(e), "events": []}


# =============================================================================
# Proactive ambient watch loop
# =============================================================================

@router.get("/api/proactive/state")
async def proactive_state():
    if state.proactive_loop is None:
        return {"ok": True, "available": False, "reason": "vision not loaded"}
    return {"ok": True, "available": True, **state.proactive_loop.get_state()}


@router.post("/api/abort")
async def abort_response():
    """Kill Leon's active response mid-stream."""
    # Playback stops here too, so the speaker interval ends here too —
    # at stop + SINK_DRAIN_S, since the sink keeps draining after the
    # abort. Same single rule as everything else; no bypass flag.
    try:
        from brain import audio_daemon as _ad
        _ad.barge_in()
    except Exception:
        pass
    if state.brain_api_responder is not None:
        state.brain_api_responder.abort()
        state._responder_stats["is_processing"] = False
        return {"ok": True, "aborted": True}
    return {"ok": False, "error": "no responder active"}


@router.post("/api/proactive/pause")
async def proactive_pause():
    if state.proactive_loop is None:
        return {"ok": False, "error": "proactive loop not running"}
    state.proactive_loop.pause()
    return {"ok": True, "paused": True}


@router.post("/api/proactive/resume")
async def proactive_resume():
    if state.proactive_loop is None:
        return {"ok": False, "error": "proactive loop not running"}
    state.proactive_loop.resume()
    return {"ok": True, "paused": False}


@router.post("/api/proactive/interval")
async def proactive_interval(req: Request):
    if state.proactive_loop is None:
        return {"ok": False, "error": "proactive loop not running"}
    try:
        body = await req.json()
        seconds = float(body.get("seconds", 60))
    except Exception as e:
        return {"ok": False, "error": f"bad request: {e}"}
    state.proactive_loop.set_interval(seconds)
    return {"ok": True, "interval_s": state.proactive_loop.interval_s}
