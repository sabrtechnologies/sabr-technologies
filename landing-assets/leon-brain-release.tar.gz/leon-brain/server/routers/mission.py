"""
Mission Control (Phase 15) API routes.

Autopilot (Phase 17) routes moved to autopilot_routes.py 2026-06-08.

Extracted from the monolithic server.py to keep things manageable.
All mutable state is accessed via ``from server import state``.
"""

import os
import asyncio
from dataclasses import asdict

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, FileResponse

from server import state
from brain.mission import ActionTier, classify_action

router = APIRouter()


# =============================================================================
# Legacy projects endpoint
# =============================================================================

@router.get("/api/projects")
async def get_projects_legacy():
    """Legacy endpoint -- returns Desktop dirs. See /api/mission/projects for real registry."""
    desktop = os.path.expanduser("~/Desktop")
    try:
        skip = {".git", "__pycache__", "node_modules", ".DS_Store"}
        dirs = sorted(
            n for n in os.listdir(desktop)
            if os.path.isdir(os.path.join(desktop, n)) and n not in skip and not n.startswith(".")
        )
        return JSONResponse({"projects": dirs})
    except Exception as e:
        return JSONResponse({"projects": [], "error": str(e)})


# =============================================================================
# Phase 15 (MC): Mission Control API
# =============================================================================

@router.get("/mission")
async def mission_panel():
    # Was a bare FileResponse — shipped raw bytes with the hardcoded title
    # "<title>Leon — Mission Control</title>" and footer "...Leon Phase 15"
    # straight to the client. Route through server._branded_page() like every
    # other panel (see its docstring). Deferred import avoids a circular
    # import at module load time (server/__init__.py imports this router).
    from server import _branded_page
    return _branded_page("mission.html")


# -- Project Registry --------------------------------------------------------

@router.get("/api/mission/projects")
async def mission_list_projects():
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse({"projects": state.mission_registry.list_all()})


@router.get("/api/mission/projects/summary")
async def mission_projects_summary():
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_registry.summary())


@router.get("/api/mission/projects/{project_id}")
async def mission_get_project(project_id: str):
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    proj = state.mission_registry.get(project_id) or state.mission_registry.get_by_name(project_id)
    if not proj:
        return JSONResponse({"error": "Project not found"}, 404)
    return JSONResponse(proj)


@router.post("/api/mission/projects/create")
async def mission_create_project(request: Request):
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    name = body.pop("name", None)
    if not name:
        return JSONResponse({"error": "name is required"}, 400)
    try:
        proj = state.mission_registry.create(name, **body)
        return JSONResponse(proj)
    except Exception as e:
        return JSONResponse({"error": str(e)}, 400)


@router.post("/api/mission/projects/{project_id}/update")
async def mission_update_project(project_id: str, request: Request):
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    proj = state.mission_registry.update(project_id, **body)
    if not proj:
        return JSONResponse({"error": "Project not found"}, 404)
    return JSONResponse(proj)


@router.post("/api/mission/projects/{project_id}/blocker")
async def mission_add_blocker(project_id: str, request: Request):
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    blocker = state.mission_registry.add_blocker(
        project_id, body.get("description", ""), body.get("severity", "medium"))
    if not blocker:
        return JSONResponse({"error": "Project not found"}, 404)
    return JSONResponse(blocker)


@router.post("/api/mission/projects/{project_id}/blocker/{blocker_id}/resolve")
async def mission_resolve_blocker(project_id: str, blocker_id: str):
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    ok = state.mission_registry.resolve_blocker(project_id, blocker_id)
    return JSONResponse({"ok": ok})


@router.get("/api/mission/projects/{project_id}/events")
async def mission_project_events(project_id: str):
    if not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse({"events": state.mission_registry.events(project_id)})


# -- Mission State Engine (checklists) --------------------------------------

@router.get("/api/mission/checklist/templates")
async def mission_list_templates():
    if not state.mission_state:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse({"templates": state.mission_state.list_templates()})


@router.post("/api/mission/checklist/{project_id}/apply")
async def mission_apply_template(project_id: str, request: Request):
    if not state.mission_state:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    template = body.get("template", "ios_deploy")
    items = state.mission_state.apply_template(project_id, template)
    return JSONResponse({"applied": len(items), "items": items})


@router.get("/api/mission/checklist/{project_id}")
async def mission_get_checklist(project_id: str):
    if not state.mission_state:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    items = state.mission_state.get_items(project_id)
    return JSONResponse({"items": items})


@router.get("/api/mission/checklist/{project_id}/readiness")
async def mission_readiness(project_id: str):
    if not state.mission_state:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_state.project_readiness(project_id))


@router.post("/api/mission/checklist/{project_id}/update")
async def mission_update_checklist_item(project_id: str, request: Request):
    if not state.mission_state:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    item_key = body.pop("item_key", None)
    if not item_key:
        return JSONResponse({"error": "item_key is required"}, 400)
    result = state.mission_state.update_item(project_id, item_key, **body)
    if not result:
        return JSONResponse({"error": "Item not found"}, 404)
    return JSONResponse(result)


@router.post("/api/mission/checklist/{project_id}/add")
async def mission_add_checklist_item(project_id: str, request: Request):
    if not state.mission_state:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    item_key = body.pop("item_key", None)
    label = body.pop("label", None)
    if not item_key or not label:
        return JSONResponse({"error": "item_key and label required"}, 400)
    result = state.mission_state.add_custom_item(project_id, item_key, label, **body)
    return JSONResponse(result)


@router.get("/api/mission/blockers")
async def mission_all_blockers():
    if not state.mission_state:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse({"blockers": state.mission_state.all_blockers()})


# -- External Connectors ----------------------------------------------------

@router.get("/api/mission/connectors/github/{owner}/{repo}")
async def mission_github_repo(owner: str, repo: str):
    if not state.mission_connectors:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_connectors.github_repo_info(owner, repo))


@router.get("/api/mission/connectors/github/{owner}/{repo}/pr/{pr_number}")
async def mission_github_pr(owner: str, repo: str, pr_number: int):
    if not state.mission_connectors:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_connectors.github_pr_status(owner, repo, pr_number))


@router.get("/api/mission/connectors/github/{owner}/{repo}/workflows")
async def mission_github_workflows(owner: str, repo: str):
    if not state.mission_connectors:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_connectors.github_workflow_runs(owner, repo))


@router.get("/api/mission/connectors/health")
async def mission_health_check(request: Request):
    if not state.mission_connectors:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    url = request.query_params.get("url", "")
    if not url:
        return JSONResponse({"error": "url parameter required"}, 400)
    return JSONResponse(state.mission_connectors.health_check(url))


@router.get("/api/mission/connectors/check/{project_id}")
async def mission_check_project(project_id: str):
    if not state.mission_connectors or not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    proj = state.mission_registry.get(project_id) or state.mission_registry.get_by_name(project_id)
    if not proj:
        return JSONResponse({"error": "Project not found"}, 404)
    return JSONResponse(state.mission_connectors.check_all_for_project(proj))


# -- Credential Awareness ---------------------------------------------------

@router.get("/api/mission/credentials")
async def mission_scan_creds():
    if not state.mission_creds:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_creds.scan())


@router.get("/api/mission/credentials/summary")
async def mission_creds_summary():
    if not state.mission_creds:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_creds.summary())


@router.get("/api/mission/credentials/project/{project_id}")
async def mission_project_creds(project_id: str):
    if not state.mission_creds or not state.mission_registry:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    proj = state.mission_registry.get(project_id) or state.mission_registry.get_by_name(project_id)
    if not proj:
        return JSONResponse({"error": "Project not found"}, 404)
    return JSONResponse(state.mission_creds.check_project_creds(proj))


# -- Decision Registry ------------------------------------------------------

@router.get("/api/mission/decisions")
async def mission_list_decisions(request: Request):
    if not state.mission_decisions:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    project_id = request.query_params.get("project_id")
    status = request.query_params.get("status")
    return JSONResponse({"decisions": state.mission_decisions.list_all(project_id, status)})


@router.get("/api/mission/decisions/summary")
async def mission_decisions_summary():
    if not state.mission_decisions:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse(state.mission_decisions.summary())


@router.get("/api/mission/decisions/{decision_id}")
async def mission_get_decision(decision_id: str):
    if not state.mission_decisions:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    d = state.mission_decisions.get(decision_id)
    if not d:
        return JSONResponse({"error": "Decision not found"}, 404)
    return JSONResponse(d)


@router.post("/api/mission/decisions/create")
async def mission_create_decision(request: Request):
    if not state.mission_decisions:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    title = body.pop("title", None)
    if not title:
        return JSONResponse({"error": "title is required"}, 400)
    d = state.mission_decisions.create(title, **body)
    return JSONResponse(d)


@router.post("/api/mission/decisions/{decision_id}/update")
async def mission_update_decision(decision_id: str, request: Request):
    if not state.mission_decisions:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    d = state.mission_decisions.update(decision_id, **body)
    if not d:
        return JSONResponse({"error": "Decision not found"}, 404)
    return JSONResponse(d)


@router.post("/api/mission/decisions/{decision_id}/decide")
async def mission_decide(decision_id: str, request: Request):
    if not state.mission_decisions:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    d = state.mission_decisions.decide(
        decision_id, body.get("decision", ""), body.get("rationale", ""),
        body.get("decided_by", "Dean"))
    if not d:
        return JSONResponse({"error": "Decision not found"}, 404)
    return JSONResponse(d)


@router.post("/api/mission/decisions/{decision_id}/comment")
async def mission_add_comment(decision_id: str, request: Request):
    if not state.mission_decisions:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    body = await request.json()
    c = state.mission_decisions.add_comment(
        decision_id, body.get("content", ""), body.get("author", "leon"))
    return JSONResponse(c)


# -- Ops Loop ---------------------------------------------------------------

@router.get("/api/mission/ops/tick")
async def mission_ops_tick(request: Request):
    if not state.mission_ops:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    force = request.query_params.get("force", "false").lower() in ("true", "1", "yes")
    return JSONResponse(state.mission_ops.tick(force=force))


@router.get("/api/mission/ops/summary")
async def mission_ops_summary():
    if not state.mission_ops:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    s = state.mission_ops.latest_summary()
    return JSONResponse(s or {"empty": True})


@router.get("/api/mission/ops/checks")
async def mission_ops_checks(request: Request):
    if not state.mission_ops:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    project_id = request.query_params.get("project_id")
    return JSONResponse({"checks": state.mission_ops.recent_checks(project_id)})


@router.get("/api/mission/ops/stale")
async def mission_stale_projects():
    if not state.mission_ops:
        return JSONResponse({"error": "Mission Control not initialized"}, 500)
    return JSONResponse({"stale": state.mission_ops.stale_projects()})


# -- Action Tiers -----------------------------------------------------------

@router.get("/api/mission/action/classify")
async def mission_classify_action(request: Request):
    action = request.query_params.get("action", "")
    if not action:
        return JSONResponse({"error": "action parameter required"}, 400)
    tier = classify_action(action)
    return JSONResponse({"action": action, "tier": tier.value,
                         "auto_allowed": tier in (ActionTier.READ_ONLY, ActionTier.SAFE_AUTOMATION)})


# -- Dashboard aggregate ----------------------------------------------------

@router.get("/api/mission/dashboard")
async def mission_dashboard():
    result = {}
    if state.mission_registry:
        result["project_summary"] = state.mission_registry.summary()
        all_project_blockers = []
        for p in state.mission_registry.list_all(active_only=True):
            for b in p.get("known_blockers", []):
                if not b.get("resolved"):
                    all_project_blockers.append({"project": p["name"], **b})
        result["all_blockers"] = all_project_blockers
    if state.mission_ops:
        s = state.mission_ops.latest_summary()
        result["ops_summary"] = s.get("summary") if s and "summary" in s else s
        result["recent_checks"] = state.mission_ops.recent_checks(limit=20)
    if state.mission_decisions:
        result["decisions_summary"] = state.mission_decisions.summary()
    if state.mission_creds:
        result["creds_summary"] = state.mission_creds.summary()
    return JSONResponse(result)



# Autopilot routes (/autopilot HTML + /api/autopilot/*) moved to
# server/routers/autopilot_routes.py (2026-06-08).
