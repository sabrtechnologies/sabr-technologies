"""Tesla routes — Phantom awareness surface.

POST /api/tesla/alert   loopback-only. Background watchers (tesla_watch.py, a
                        systemd timer) speak to Dean through Leon's own
                        unsolicited-speech gate instead of a side channel.
GET  /api/tesla/status  one-line vehicle status (read-only, never wakes the car).
"""
from __future__ import annotations
import asyncio, importlib.util, os, time, json
from fastapi import APIRouter, HTTPException, Request

router = APIRouter()
_CTL = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "brain", "integrations", "tesla_ctl.py")


def _ctl():
    spec = importlib.util.spec_from_file_location("tesla_ctl", _CTL)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def _loopback(request: Request) -> None:
    host = request.client.host if request.client else ""
    if host not in ("127.0.0.1", "::1"):
        raise HTTPException(status_code=403, detail="loopback only")


@router.post("/api/tesla/alert")
async def tesla_alert(request: Request):
    _loopback(request)
    data = await request.json()
    text = (data.get("text") or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="text required")
    from server.helpers import broadcast_response
    ok = broadcast_response(text, source="tesla-watch", user_label="(Phantom)", force=bool(data.get("force", True)))
    try:
        with open("/opt/leon-brain/brain_state/tesla_alerts.log", "a") as fh:
            fh.write(json.dumps({"ts": time.time(), "delivered": ok, "kind": data.get("kind"), "text": text}) + "\n")
    except Exception:
        pass
    return {"ok": ok}


@router.get("/api/tesla/status")
async def tesla_status():
    loop = asyncio.get_running_loop()
    try:
        txt = await loop.run_in_executor(None, _ctl().status_text)
    except Exception as e:
        txt = f"unavailable: {e}"
    return {"status": txt}
