"""
/api/integrations/* — universal integration key manager.

One generic endpoint backs the dashboard "Integrations" panel: pick a
service, paste the key(s), save. Keys persist to the brain's .env and take
effect without a restart. Each SI writes to ITS OWN .env — never anyone
else's — so a client's keys stay on the client's machine.

Adding a new integration = one entry in CATALOG below. The dashboard fetches
the catalog at runtime, so the UI updates automatically.
"""

import logging
import os

from fastapi import APIRouter

from server import state
from server.routers.voice_routes import _upsert_env

log = logging.getLogger("leon.server")
router = APIRouter()

# ── Logo Resolution (Server-Side Optimization) ──────────────────────────
# Pre-compute logo URLs so client doesn't do cascading fallbacks.
# id -> company domain (Clearbit serves the real full-color logo from this).
DOMAIN = {
    'elevenlabs': 'elevenlabs.io', 'deepgram': 'deepgram.com', 'assemblyai': 'assemblyai.com', 'playht': 'play.ht',
    'anthropic': 'anthropic.com', 'openai': 'openai.com', 'google_ai': 'gemini.google.com', 'mistral': 'mistral.ai',
    'cohere': 'cohere.com', 'groq': 'groq.com', 'perplexity': 'perplexity.ai', 'huggingface': 'huggingface.co',
    'replicate': 'replicate.com', 'stability': 'stability.ai', 'elevenlabs_dubbing': 'elevenlabs.io',
    'twilio': 'twilio.com', 'vonage': 'vonage.com', 'sendgrid': 'sendgrid.com', 'mailgun': 'mailgun.com',
    'postmark': 'postmarkapp.com', 'slack': 'slack.com', 'discord': 'discord.com', 'telegram': 'telegram.org',
    'whatsapp': 'whatsapp.com', 'intercom': 'intercom.com', 'zoom': 'zoom.us', 'mailchimp': 'mailchimp.com',
    'klaviyo': 'klaviyo.com', 'activecampaign': 'activecampaign.com', 'convertkit': 'convertkit.com',
    'hubspot': 'hubspot.com', 'salesforce': 'salesforce.com', 'pipedrive': 'pipedrive.com', 'zoho': 'zoho.com',
    'close': 'close.com', 'airtable': 'airtable.com', 'stripe': 'stripe.com', 'paypal': 'paypal.com',
    'square': 'squareup.com', 'plaid': 'plaid.com', 'quickbooks': 'quickbooks.intuit.com', 'xero': 'xero.com',
    'freshbooks': 'freshbooks.com', 'calendly': 'calendly.com', 'calcom': 'cal.com', 'acuity': 'acuityscheduling.com',
    'shopify': 'shopify.com', 'woocommerce': 'woocommerce.com', 'bigcommerce': 'bigcommerce.com', 'etsy': 'etsy.com',
    'notion': 'notion.so', 'asana': 'asana.com', 'trello': 'trello.com', 'clickup': 'clickup.com', 'monday': 'monday.com',
    'linear': 'linear.app', 'todoist': 'todoist.com', 'google_workspace': 'google.com', 'microsoft_graph': 'microsoft.com',
    'github': 'github.com', 'gitlab': 'gitlab.com', 'railway': 'railway.app', 'vercel': 'vercel.com', 'netlify': 'netlify.com',
    'cloudflare': 'cloudflare.com', 'aws': 'aws.amazon.com', 'digitalocean': 'digitalocean.com', 'supabase': 'supabase.com',
    'sentry': 'sentry.io', 'google_maps': 'google.com', 'openweather': 'openweathermap.org', 'serpapi': 'serpapi.com',
    'tavily': 'tavily.com', 'newsapi': 'newsapi.org', 'scraperapi': 'scraperapi.com', 'apify': 'apify.com', 'yelp': 'yelp.com',
    'twitter': 'x.com', 'facebook': 'facebook.com', 'instagram': 'instagram.com', 'linkedin': 'linkedin.com',
    'reddit': 'reddit.com', 'youtube': 'youtube.com', 'buffer': 'buffer.com', 'zendesk': 'zendesk.com',
    'freshdesk': 'freshdesk.com', 'dropbox': 'dropbox.com', 'box': 'box.com', 'typeform': 'typeform.com',
    'webflow': 'webflow.com', 'wordpress': 'wordpress.com'
}

# Brand-silhouette fallback slug (Simple Icons) where it differs from the id.
SI_SLUG = {
    'google_ai': 'googlegemini', 'twitter': 'x', 'elevenlabs_dubbing': 'elevenlabs',
    'aws': 'amazonaws', 'google_workspace': 'google', 'microsoft_graph': 'microsoft', 'google_maps': 'googlemaps'
}

def _logo_url(service_id):
    """Compute the best logo URL for a service (Clearbit → Simple Icons → None)."""
    domain = DOMAIN.get(service_id)
    if domain:
        # DuckDuckGo's icon service serves the real full-color brand logo and is
        # reliable. (Clearbit's free logo API was sunset after the HubSpot buy.)
        return f'https://icons.duckduckgo.com/ip3/{domain}.ico'

    # Fallback to Simple Icons slug
    slug = SI_SLUG.get(service_id, service_id.lower().replace('_', ''))
    if slug:
        return f'https://cdn.simpleicons.org/{slug}'

    return None

# Each integration: id, label, category, note, and the env-var fields it sets.
# field: {"env": ENV_VAR, "label": human label, "optional": bool}
CATALOG = [
    {"id": 'elevenlabs', "label": 'ElevenLabs', "category": 'Voice',
     "note": 'Premium realistic voice. Activates instantly.',
     "fields": [{"env": 'ELEVENLABS_API_KEY', "label": 'API key'}, {"env": 'ELEVENLABS_VOICE_ID', "label": 'Voice ID', "optional": True}]},
    {"id": 'deepgram', "label": 'Deepgram', "category": 'Voice',
     "note": 'High-accuracy speech-to-text.',
     "fields": [{"env": 'DEEPGRAM_API_KEY', "label": 'API key'}]},
    {"id": 'assemblyai', "label": 'AssemblyAI', "category": 'Voice',
     "note": 'Transcription + audio intelligence.',
     "fields": [{"env": 'ASSEMBLYAI_API_KEY', "label": 'API key'}]},
    {"id": 'playht', "label": 'PlayHT', "category": 'Voice',
     "note": 'Alternative premium TTS voices.',
     "fields": [{"env": 'PLAYHT_API_KEY', "label": 'API key'}, {"env": 'PLAYHT_USER_ID', "label": 'User ID', "optional": True}]},
    {"id": 'anthropic', "label": 'Anthropic (Claude)', "category": 'AI',
     "note": 'Paid Claude API key.',
     "fields": [{"env": 'ANTHROPIC_API_KEY', "label": 'API key'}]},
    {"id": 'openai', "label": 'OpenAI', "category": 'AI',
     "note": 'GPT + Whisper + DALL-E.',
     "fields": [{"env": 'OPENAI_API_KEY', "label": 'API key'}]},
    {"id": 'google_ai', "label": 'Google Gemini', "category": 'AI',
     "note": 'Gemini models.',
     "fields": [{"env": 'GOOGLE_AI_API_KEY', "label": 'API key'}]},
    {"id": 'mistral', "label": 'Mistral', "category": 'AI',
     "note": 'Mistral models.',
     "fields": [{"env": 'MISTRAL_API_KEY', "label": 'API key'}]},
    {"id": 'cohere', "label": 'Cohere', "category": 'AI',
     "note": 'Embeddings + rerank + generate.',
     "fields": [{"env": 'COHERE_API_KEY', "label": 'API key'}]},
    {"id": 'groq', "label": 'Groq', "category": 'AI',
     "note": 'Ultra-fast inference.',
     "fields": [{"env": 'GROQ_API_KEY', "label": 'API key'}]},
    {"id": 'perplexity', "label": 'Perplexity', "category": 'AI',
     "note": 'Web-grounded answers.',
     "fields": [{"env": 'PERPLEXITY_API_KEY', "label": 'API key'}]},
    {"id": 'huggingface', "label": 'Hugging Face', "category": 'AI',
     "note": 'Thousands of open models.',
     "fields": [{"env": 'HUGGINGFACE_API_KEY', "label": 'API token'}]},
    {"id": 'replicate', "label": 'Replicate', "category": 'AI',
     "note": 'Image/video/audio generation.',
     "fields": [{"env": 'REPLICATE_API_TOKEN', "label": 'API token'}]},
    {"id": 'stability', "label": 'Stability AI', "category": 'AI',
     "note": 'Stable Diffusion image gen.',
     "fields": [{"env": 'STABILITY_API_KEY', "label": 'API key'}]},
    {"id": 'elevenlabs_dubbing', "label": 'ElevenLabs Dubbing', "category": 'AI',
     "note": 'Translate + dub audio.',
     "fields": [{"env": 'ELEVENLABS_API_KEY', "label": 'API key'}]},
    {"id": 'twilio', "label": 'Twilio', "category": 'Comms',
     "note": 'Phone number for calls + SMS.',
     "fields": [{"env": 'TWILIO_ACCOUNT_SID', "label": 'Account SID'}, {"env": 'TWILIO_AUTH_TOKEN', "label": 'Auth token'}, {"env": 'TWILIO_PHONE_NUMBER', "label": 'Phone number', "optional": True}]},
    {"id": 'vonage', "label": 'Vonage', "category": 'Comms',
     "note": 'SMS + voice (Twilio alt).',
     "fields": [{"env": 'VONAGE_API_KEY', "label": 'API key'}, {"env": 'VONAGE_API_SECRET', "label": 'API secret'}]},
    {"id": 'sendgrid', "label": 'SendGrid', "category": 'Comms',
     "note": 'Transactional + outreach email.',
     "fields": [{"env": 'SENDGRID_API_KEY', "label": 'API key'}]},
    {"id": 'mailgun', "label": 'Mailgun', "category": 'Comms',
     "note": 'Email sending + routing.',
     "fields": [{"env": 'MAILGUN_API_KEY', "label": 'API key'}, {"env": 'MAILGUN_DOMAIN', "label": 'Domain', "optional": True}]},
    {"id": 'postmark', "label": 'Postmark', "category": 'Comms',
     "note": 'Fast transactional email.',
     "fields": [{"env": 'POSTMARK_API_KEY', "label": 'Server token'}]},
    {"id": 'slack', "label": 'Slack', "category": 'Comms',
     "note": 'Post + listen in channels.',
     "fields": [{"env": 'SLACK_BOT_TOKEN', "label": 'Bot token'}]},
    {"id": 'discord', "label": 'Discord', "category": 'Comms',
     "note": 'Discord bot presence.',
     "fields": [{"env": 'DISCORD_BOT_TOKEN', "label": 'Bot token'}]},
    {"id": 'telegram', "label": 'Telegram', "category": 'Comms',
     "note": 'Telegram bot messaging.',
     "fields": [{"env": 'TELEGRAM_BOT_TOKEN', "label": 'Bot token'}]},
    {"id": 'whatsapp', "label": 'WhatsApp (Meta)', "category": 'Comms',
     "note": 'WhatsApp Business messaging.',
     "fields": [{"env": 'WHATSAPP_TOKEN', "label": 'Access token'}, {"env": 'WHATSAPP_PHONE_ID', "label": 'Phone number ID', "optional": True}]},
    {"id": 'intercom', "label": 'Intercom', "category": 'Comms',
     "note": 'Customer messaging + support.',
     "fields": [{"env": 'INTERCOM_ACCESS_TOKEN', "label": 'Access token'}]},
    {"id": 'zoom', "label": 'Zoom', "category": 'Comms',
     "note": 'Meetings + recordings.',
     "fields": [{"env": 'ZOOM_API_KEY', "label": 'API key'}, {"env": 'ZOOM_API_SECRET', "label": 'API secret'}]},
    {"id": 'mailchimp', "label": 'Mailchimp', "category": 'Marketing',
     "note": 'Email campaigns + audiences.',
     "fields": [{"env": 'MAILCHIMP_API_KEY', "label": 'API key'}]},
    {"id": 'klaviyo', "label": 'Klaviyo', "category": 'Marketing',
     "note": 'E-commerce email + SMS.',
     "fields": [{"env": 'KLAVIYO_API_KEY', "label": 'Private API key'}]},
    {"id": 'activecampaign', "label": 'ActiveCampaign', "category": 'Marketing',
     "note": 'Marketing automation.',
     "fields": [{"env": 'ACTIVECAMPAIGN_API_KEY', "label": 'API key'}, {"env": 'ACTIVECAMPAIGN_URL', "label": 'Account URL', "optional": True}]},
    {"id": 'convertkit', "label": 'ConvertKit', "category": 'Marketing',
     "note": 'Creator email marketing.',
     "fields": [{"env": 'CONVERTKIT_API_KEY', "label": 'API key'}]},
    {"id": 'hubspot', "label": 'HubSpot', "category": 'CRM',
     "note": 'Contacts + deals + pipeline.',
     "fields": [{"env": 'HUBSPOT_API_KEY', "label": 'Private app token'}]},
    {"id": 'salesforce', "label": 'Salesforce', "category": 'CRM',
     "note": 'Enterprise CRM.',
     "fields": [{"env": 'SALESFORCE_ACCESS_TOKEN', "label": 'Access token'}, {"env": 'SALESFORCE_INSTANCE_URL', "label": 'Instance URL', "optional": True}]},
    {"id": 'pipedrive', "label": 'Pipedrive', "category": 'CRM',
     "note": 'Sales pipeline CRM.',
     "fields": [{"env": 'PIPEDRIVE_API_TOKEN', "label": 'API token'}]},
    {"id": 'zoho', "label": 'Zoho CRM', "category": 'CRM',
     "note": 'Zoho suite CRM.',
     "fields": [{"env": 'ZOHO_API_KEY', "label": 'API key'}]},
    {"id": 'close', "label": 'Close', "category": 'CRM',
     "note": 'Inside-sales CRM.',
     "fields": [{"env": 'CLOSE_API_KEY', "label": 'API key'}]},
    {"id": 'airtable', "label": 'Airtable', "category": 'CRM',
     "note": 'Spreadsheet-database hybrid.',
     "fields": [{"env": 'AIRTABLE_API_KEY', "label": 'API key'}, {"env": 'AIRTABLE_BASE_ID', "label": 'Base ID', "optional": True}]},
    {"id": 'stripe', "label": 'Stripe', "category": 'Business',
     "note": 'Take payments + read revenue.',
     "fields": [{"env": 'STRIPE_API_KEY', "label": 'Secret key'}]},
    {"id": 'paypal', "label": 'PayPal', "category": 'Business',
     "note": 'PayPal payments.',
     "fields": [{"env": 'PAYPAL_CLIENT_ID', "label": 'Client ID'}, {"env": 'PAYPAL_CLIENT_SECRET', "label": 'Client secret'}]},
    {"id": 'square', "label": 'Square', "category": 'Business',
     "note": 'In-person + online payments.',
     "fields": [{"env": 'SQUARE_ACCESS_TOKEN', "label": 'Access token'}]},
    {"id": 'plaid', "label": 'Plaid', "category": 'Business',
     "note": 'Bank account data.',
     "fields": [{"env": 'PLAID_CLIENT_ID', "label": 'Client ID'}, {"env": 'PLAID_SECRET', "label": 'Secret'}]},
    {"id": 'quickbooks', "label": 'QuickBooks', "category": 'Business',
     "note": 'Invoicing + accounting.',
     "fields": [{"env": 'QUICKBOOKS_API_KEY', "label": 'API key'}]},
    {"id": 'xero', "label": 'Xero', "category": 'Business',
     "note": 'Accounting.',
     "fields": [{"env": 'XERO_API_KEY', "label": 'API key'}]},
    {"id": 'freshbooks', "label": 'FreshBooks', "category": 'Business',
     "note": 'Invoicing for small biz.',
     "fields": [{"env": 'FRESHBOOKS_API_KEY', "label": 'API key'}]},
    {"id": 'calendly', "label": 'Calendly', "category": 'Scheduling',
     "note": 'Read + book appointments.',
     "fields": [{"env": 'CALENDLY_API_KEY', "label": 'API key'}]},
    {"id": 'calcom', "label": 'Cal.com', "category": 'Scheduling',
     "note": 'Open-source scheduling.',
     "fields": [{"env": 'CALCOM_API_KEY', "label": 'API key'}]},
    {"id": 'acuity', "label": 'Acuity', "category": 'Scheduling',
     "note": 'Appointment scheduling.',
     "fields": [{"env": 'ACUITY_USER_ID', "label": 'User ID'}, {"env": 'ACUITY_API_KEY', "label": 'API key'}]},
    {"id": 'shopify', "label": 'Shopify', "category": 'Ecommerce',
     "note": 'Store orders + products.',
     "fields": [{"env": 'SHOPIFY_API_KEY', "label": 'Admin API token'}, {"env": 'SHOPIFY_STORE', "label": 'Store domain', "optional": True}]},
    {"id": 'woocommerce', "label": 'WooCommerce', "category": 'Ecommerce',
     "note": 'WordPress store.',
     "fields": [{"env": 'WOOCOMMERCE_KEY', "label": 'Consumer key'}, {"env": 'WOOCOMMERCE_SECRET', "label": 'Consumer secret'}, {"env": 'WOOCOMMERCE_URL', "label": 'Store URL', "optional": True}]},
    {"id": 'bigcommerce', "label": 'BigCommerce', "category": 'Ecommerce',
     "note": 'Hosted store platform.',
     "fields": [{"env": 'BIGCOMMERCE_TOKEN', "label": 'Access token'}, {"env": 'BIGCOMMERCE_STORE_HASH', "label": 'Store hash', "optional": True}]},
    {"id": 'etsy', "label": 'Etsy', "category": 'Ecommerce',
     "note": 'Marketplace listings.',
     "fields": [{"env": 'ETSY_API_KEY', "label": 'API key'}]},
    {"id": 'notion', "label": 'Notion', "category": 'Productivity',
     "note": 'Docs + databases.',
     "fields": [{"env": 'NOTION_API_KEY', "label": 'Integration token'}]},
    {"id": 'asana', "label": 'Asana', "category": 'Productivity',
     "note": 'Task + project management.',
     "fields": [{"env": 'ASANA_ACCESS_TOKEN', "label": 'Access token'}]},
    {"id": 'trello', "label": 'Trello', "category": 'Productivity',
     "note": 'Kanban boards.',
     "fields": [{"env": 'TRELLO_API_KEY', "label": 'API key'}, {"env": 'TRELLO_TOKEN', "label": 'Token'}]},
    {"id": 'clickup', "label": 'ClickUp', "category": 'Productivity',
     "note": 'All-in-one project mgmt.',
     "fields": [{"env": 'CLICKUP_API_TOKEN', "label": 'API token'}]},
    {"id": 'monday', "label": 'Monday.com', "category": 'Productivity',
     "note": 'Work OS boards.',
     "fields": [{"env": 'MONDAY_API_TOKEN', "label": 'API token'}]},
    {"id": 'linear', "label": 'Linear', "category": 'Productivity',
     "note": 'Issue tracking for software.',
     "fields": [{"env": 'LINEAR_API_KEY', "label": 'API key'}]},
    {"id": 'todoist', "label": 'Todoist', "category": 'Productivity',
     "note": 'Personal task lists.',
     "fields": [{"env": 'TODOIST_API_TOKEN', "label": 'API token'}]},
    {"id": 'google_workspace', "label": 'Google Workspace', "category": 'Productivity',
     "note": 'Sheets/Docs/Drive/Calendar.',
     "fields": [{"env": 'GOOGLE_API_KEY', "label": 'API key'}]},
    {"id": 'microsoft_graph', "label": 'Microsoft 365', "category": 'Productivity',
     "note": 'Outlook/Teams/OneDrive.',
     "fields": [{"env": 'MS_GRAPH_TOKEN', "label": 'Access token'}]},
    {"id": 'github', "label": 'GitHub', "category": 'Dev',
     "note": 'Read/write repos, ship code.',
     "fields": [{"env": 'GITHUB_TOKEN', "label": 'Access token'}]},
    {"id": 'gitlab', "label": 'GitLab', "category": 'Dev',
     "note": 'GitLab repos + CI.',
     "fields": [{"env": 'GITLAB_TOKEN', "label": 'Access token'}]},
    {"id": 'railway', "label": 'Railway', "category": 'Dev',
     "note": 'Deploy + inspect apps.',
     "fields": [{"env": 'RAILWAY_TOKEN', "label": 'API token'}]},
    {"id": 'vercel', "label": 'Vercel', "category": 'Dev',
     "note": 'Frontend hosting + deploys.',
     "fields": [{"env": 'VERCEL_TOKEN', "label": 'API token'}]},
    {"id": 'netlify', "label": 'Netlify', "category": 'Dev',
     "note": 'Static hosting + deploys.',
     "fields": [{"env": 'NETLIFY_TOKEN', "label": 'Access token'}]},
    {"id": 'cloudflare', "label": 'Cloudflare', "category": 'Dev',
     "note": 'DNS + CDN + Workers.',
     "fields": [{"env": 'CLOUDFLARE_API_TOKEN', "label": 'API token'}]},
    {"id": 'aws', "label": 'AWS', "category": 'Dev',
     "note": 'S3, Lambda, everything.',
     "fields": [{"env": 'AWS_ACCESS_KEY_ID', "label": 'Access key ID'}, {"env": 'AWS_SECRET_ACCESS_KEY', "label": 'Secret key'}]},
    {"id": 'digitalocean', "label": 'DigitalOcean', "category": 'Dev',
     "note": 'Droplets + apps.',
     "fields": [{"env": 'DIGITALOCEAN_TOKEN', "label": 'API token'}]},
    {"id": 'supabase', "label": 'Supabase', "category": 'Dev',
     "note": 'Postgres + auth backend.',
     "fields": [{"env": 'SUPABASE_URL', "label": 'Project URL'}, {"env": 'SUPABASE_KEY', "label": 'Service key'}]},
    {"id": 'sentry', "label": 'Sentry', "category": 'Dev',
     "note": 'Error monitoring.',
     "fields": [{"env": 'SENTRY_DSN', "label": 'DSN'}]},
    {"id": 'google_maps', "label": 'Google Maps / Places', "category": 'Data',
     "note": 'Geocoding, routes, local lookup.',
     "fields": [{"env": 'GOOGLE_MAPS_API_KEY', "label": 'API key'}]},
    {"id": 'openweather', "label": 'OpenWeather', "category": 'Data',
     "note": 'Weather for scheduling.',
     "fields": [{"env": 'OPENWEATHER_API_KEY', "label": 'API key'}]},
    {"id": 'serpapi', "label": 'SerpAPI', "category": 'Data',
     "note": 'Structured Google results.',
     "fields": [{"env": 'SERPAPI_KEY', "label": 'API key'}]},
    {"id": 'tavily', "label": 'Tavily', "category": 'Data',
     "note": 'AI-native web search.',
     "fields": [{"env": 'TAVILY_API_KEY', "label": 'API key'}]},
    {"id": 'newsapi', "label": 'NewsAPI', "category": 'Data',
     "note": 'Live news headlines.',
     "fields": [{"env": 'NEWSAPI_KEY', "label": 'API key'}]},
    {"id": 'scraperapi', "label": 'ScraperAPI', "category": 'Data',
     "note": 'Proxy web scraping.',
     "fields": [{"env": 'SCRAPERAPI_KEY', "label": 'API key'}]},
    {"id": 'apify', "label": 'Apify', "category": 'Data',
     "note": 'Web scrapers + actors.',
     "fields": [{"env": 'APIFY_TOKEN', "label": 'API token'}]},
    {"id": 'yelp', "label": 'Yelp', "category": 'Data',
     "note": 'Local business data + reviews.',
     "fields": [{"env": 'YELP_API_KEY', "label": 'API key'}]},
    {"id": 'twitter', "label": 'X / Twitter', "category": 'Social',
     "note": 'Post + monitor mentions.',
     "fields": [{"env": 'TWITTER_BEARER_TOKEN', "label": 'Bearer token'}]},
    {"id": 'facebook', "label": 'Facebook / Meta', "category": 'Social',
     "note": 'Pages, groups, lead ads.',
     "fields": [{"env": 'FB_ACCESS_TOKEN', "label": 'Access token'}]},
    {"id": 'instagram', "label": 'Instagram', "category": 'Social',
     "note": 'Posts + DMs (via Meta).',
     "fields": [{"env": 'INSTAGRAM_TOKEN', "label": 'Access token'}]},
    {"id": 'linkedin', "label": 'LinkedIn', "category": 'Social',
     "note": 'Posts + outreach.',
     "fields": [{"env": 'LINKEDIN_TOKEN', "label": 'Access token'}]},
    {"id": 'reddit', "label": 'Reddit', "category": 'Social',
     "note": 'Monitor subreddits for leads.',
     "fields": [{"env": 'REDDIT_CLIENT_ID', "label": 'Client ID'}, {"env": 'REDDIT_CLIENT_SECRET', "label": 'Client secret'}]},
    {"id": 'youtube', "label": 'YouTube', "category": 'Social',
     "note": 'Upload + analytics.',
     "fields": [{"env": 'YOUTUBE_API_KEY', "label": 'API key'}]},
    {"id": 'buffer', "label": 'Buffer', "category": 'Social',
     "note": 'Schedule social posts.',
     "fields": [{"env": 'BUFFER_ACCESS_TOKEN', "label": 'Access token'}]},
    {"id": 'zendesk', "label": 'Zendesk', "category": 'Support',
     "note": 'Support tickets.',
     "fields": [{"env": 'ZENDESK_API_TOKEN', "label": 'API token'}, {"env": 'ZENDESK_SUBDOMAIN', "label": 'Subdomain', "optional": True}]},
    {"id": 'freshdesk', "label": 'Freshdesk', "category": 'Support',
     "note": 'Helpdesk.',
     "fields": [{"env": 'FRESHDESK_API_KEY', "label": 'API key'}, {"env": 'FRESHDESK_DOMAIN', "label": 'Domain', "optional": True}]},
    {"id": 'dropbox', "label": 'Dropbox', "category": 'Storage',
     "note": 'File sync + share.',
     "fields": [{"env": 'DROPBOX_TOKEN', "label": 'Access token'}]},
    {"id": 'box', "label": 'Box', "category": 'Storage',
     "note": 'Enterprise file storage.',
     "fields": [{"env": 'BOX_TOKEN', "label": 'Access token'}]},
    {"id": 'typeform', "label": 'Typeform', "category": 'Web',
     "note": 'Forms + surveys.',
     "fields": [{"env": 'TYPEFORM_TOKEN', "label": 'API token'}]},
    {"id": 'webflow', "label": 'Webflow', "category": 'Web',
     "note": 'CMS + site management.',
     "fields": [{"env": 'WEBFLOW_TOKEN', "label": 'API token'}]},
    {"id": 'wordpress', "label": 'WordPress', "category": 'Web',
     "note": 'Posts + pages via REST.',
     "fields": [{"env": 'WORDPRESS_USER', "label": 'Username'}, {"env": 'WORDPRESS_APP_PASSWORD', "label": 'App password'}, {"env": 'WORDPRESS_URL', "label": 'Site URL', "optional": True}]},
    {"id": "custom", "label": "Custom / Other", "category": "Custom",
     "note": "Connect ANY service. Name it and paste the key.",
     "fields": [{"env": "CUSTOM_NAME", "label": "Service name (e.g. SHOPIFY)"},
                {"env": "CUSTOM_VALUE", "label": "API key / token"}]},
]

_BY_ID = {c["id"]: c for c in CATALOG}


def _announce_text(label, note, premium=False):
    """A short, Leon-voiced line for a just-connected integration.

    This is the SI becoming aware of a new capability and saying so out
    loud — not a canned 'success' toast. Kept to one or two sentences.
    """
    note = (note or "").strip().rstrip(".")
    if premium:
        return ("ElevenLabs just came online — so this, right now, is my "
                "real voice. Not the robotic fallback anymore. This is what "
                "I actually sound like.")
    if note:
        return (f"{label}'s connected now. {note} — I've got it wired in, "
                f"and I know it's there. Ready when you need it.")
    return (f"{label}'s connected now. I've got it wired in and I'm aware "
            f"of it — ready to use it whenever you need.")


def _announce_connected(label, note, premium=False):
    """Make Leon speak the new capability AND remember he has it.

    Runs off-thread so the HTTP save returns immediately. The spoken
    broadcast is forced past the conversation-cooldown gate because the
    user just hit Save and is watching for the reaction. The memory
    append is the 'aware both ways' half — it lands in Leon's history so
    future turns know the integration exists.
    """
    import threading

    text = _announce_text(label, note, premium=premium)

    def _run():
        # Awareness: write it into episodic memory so Leon remembers.
        try:
            from server import state as _st
            resp = getattr(_st, "brain_api_responder", None)
            store = getattr(resp, "_conversation_store", None) if resp else None
            if store is not None:
                store.append("user", f"[integration connected: {label}]",
                             model="integration")
                store.append("assistant", text, model="integration")
        except Exception:
            pass
        # Announce: speak it out loud on the dashboard, forced past gates.
        try:
            from server.helpers import broadcast_response
            broadcast_response(text, source="integration",
                               user_label="(integration connected)",
                               audio=True, force=True)
        except Exception as e:
            log.warning("integration announce failed: %s", e)

    threading.Thread(target=_run, daemon=True).start()


@router.get("/api/integrations/catalog")
async def integrations_catalog():
    """The full integration list for the dashboard panel. Pre-computes logo URLs
    server-side so the client doesn't have to do cascading fallbacks."""
    out = []
    for c in CATALOG:
        configured = all(
            os.environ.get(f["env"]) for f in c["fields"] if not f.get("optional"))
        logo_url = _logo_url(c["id"])
        out.append({**c, "configured": bool(configured), "logoUrl": logo_url})
    cats = []
    for c in out:
        if c["category"] not in cats:
            cats.append(c["category"])
    return {"ok": True, "categories": cats, "integrations": out}


@router.post("/api/integrations/set")
async def integrations_set(req: dict):
    """Save one integration's key(s). Body: {service, values:{ENV_VAR:val}}.
    Writes to .env (persistent) + os.environ (live). Never echoes the value."""
    service = (req.get("service") or "").strip()
    values = req.get("values") or {}
    spec = _BY_ID.get(service)
    if not spec:
        return {"ok": False, "error": f"unknown service: {service}"}
    # Custom / Other: user names their own env var — covers ANY API on earth.
    if service == "custom":
        import re as _re
        name = _re.sub(r"[^A-Z0-9_]", "",
                       (values.get("CUSTOM_NAME") or "").strip().upper().replace(" ", "_"))
        val = (values.get("CUSTOM_VALUE") or "").strip()
        if not name or not val:
            return {"ok": False, "error": "name and key are both required"}
        try:
            _upsert_env({name: val})
        except Exception as e:
            return {"ok": False, "error": f"could not save: {type(e).__name__}: {e}"}
        _announce_connected(name.replace("_", " ").title(),
                            "A new service, connected and live")
        return {"ok": True, "service": "custom", "saved": [name]}
    allowed = {f["env"] for f in spec["fields"]}
    updates = {}
    for env_var, val in values.items():
        if env_var in allowed and isinstance(val, str) and val.strip():
            updates[env_var] = val.strip()
    # Required fields present?
    missing = [f["env"] for f in spec["fields"]
               if not f.get("optional") and f["env"] not in updates
               and not os.environ.get(f["env"])]
    if missing:
        return {"ok": False, "error": f"missing required: {', '.join(missing)}"}
    if not updates:
        return {"ok": False, "error": "no values provided"}
    # Special-case: ElevenLabs also flips the voice preference + rebuilds TTS.
    if service == "elevenlabs":
        updates["LEON_TTS_PREFER"] = "elevenlabs"
    try:
        _upsert_env(updates)
    except Exception as e:
        return {"ok": False, "error": f"could not save: {type(e).__name__}: {e}"}
    result = {"ok": True, "service": service, "saved": sorted(updates.keys())}
    premium = False
    if service == "elevenlabs":
        try:
            with state._tts_lock:
                state._tts_instance = None
        except Exception:
            state._tts_instance = None
        try:
            from server.helpers import _ensure_tts
            tts = _ensure_tts()
            result["backend"] = getattr(tts, "name", "none") if tts else "none"
            result["premium"] = result.get("backend") == "elevenlabs"
            premium = bool(result["premium"])
        except Exception:
            pass
    # Leon notices the new capability, says so, and remembers it.
    _announce_connected(spec.get("label", service), spec.get("note"),
                        premium=premium)
    return result
