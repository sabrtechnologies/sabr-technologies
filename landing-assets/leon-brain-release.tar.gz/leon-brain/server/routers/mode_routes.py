"""Leon autonomy MODE control — the credit/autonomy dial.

  GET  /api/mode       → current mode + the available modes (for the UI pill)
  POST /api/mode/set   → switch mode: rewrite the env preset + restart the brain

See brain/leon_modes.py for the presets. Switching restarts the brain so
systemd re-reads the EnvironmentFile and the new autonomy preset takes effect.
The restart is scheduled via systemd-run (a transient, decoupled unit) so it
survives the brain process dying mid-switch — falling back to a detached
setsid shell if systemd-run is unavailable.

Protected by the global LEON_API_KEY auth middleware like every other /api
route, so the restart endpoint can't be hit unauthenticated.
"""
import logging
import subprocess

from fastapi import APIRouter, Request

log = logging.getLogger("leon.server")
router = APIRouter()


def _schedule_restart(mode: str) -> str:
    """Restart leon.service ~2s from now, decoupled from this dying process."""
    # NO fixed --unit name: a fixed transient unit lingers 'inactive' after the
    # first switch, so a second switch collides on the name, systemd-run fails
    # (async, Popen doesn't raise), the fallback never fires, and the switch
    # silently doesn't restart (got stuck mid-Being 2026-06-21). Auto-named +
    # --collect units never collide.
    try:
        rc = subprocess.call(
            ["systemd-run", "--on-active=2", "--collect",
             "systemctl", "restart", "leon.service"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        if rc == 0:
            return "systemd-run"
        log.warning(f"[MODE] systemd-run exited {rc}; trying setsid")
    except Exception as e:
        log.warning(f"[MODE] systemd-run restart failed ({e}); trying setsid")
    try:
        subprocess.Popen(
            ["setsid", "bash", "-c", "sleep 2; systemctl restart leon.service"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
        return "setsid"
    except Exception as e:
        log.error(f"[MODE] restart scheduling failed entirely: {e}")
        return f"failed:{e}"


@router.get("/api/mode")
async def get_mode():
    from brain import leon_modes
    return {"ok": True, **leon_modes.describe()}


@router.post("/api/mode/set")
async def set_mode(request: Request):
    from brain import leon_modes
    try:
        body = await request.json()
    except Exception:
        body = {}
    mode = (body.get("mode") if isinstance(body, dict) else None) \
        or request.query_params.get("mode") or ""
    mode = mode.strip().lower()
    if mode not in leon_modes.MODES:
        return {"ok": False, "error": f"unknown mode '{mode}'",
                "modes": list(leon_modes.MODES)}

    cur = leon_modes.active_mode()
    try:
        # INSTANT — flip the in-process mode flag, no restart. The autonomy
        # gate in respond_streaming reads it on the next tick, so Focus stops
        # spending immediately and Being wakes up within a cycle.
        info = leon_modes.set_runtime_mode(mode)
    except Exception as e:
        log.error(f"[MODE] set_runtime_mode({mode}) failed: {e}")
        return {"ok": False, "error": str(e)}

    log.info(f"[MODE] switch {cur} -> {mode} (instant)")
    return {
        "ok": True,
        "mode": mode,
        "label": info["label"],
        "previous": cur,
        "restarting": False,
        "instant": True,
    }
