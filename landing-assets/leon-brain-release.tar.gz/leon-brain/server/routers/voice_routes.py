"""
/api/voice/* — voice pipeline (VAD + STT + TTS) controls.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged. The pipeline barge-in fix from audit 2026-06-08 lives in
brain/voice/pipeline.py — this router only exposes start/stop/speak/feed.
"""

import logging
import os
from pathlib import Path

from fastapi import APIRouter

from server import state
from server.helpers import _ensure_voice_pipeline

log = logging.getLogger("leon.server")
router = APIRouter()


@router.post("/api/voice/start")
async def voice_start():
    pipe = _ensure_voice_pipeline()
    pipe.start()
    return {"ok": True, "state": pipe.state.value}


@router.post("/api/voice/stop")
async def voice_stop():
    if state.voice_pipeline is not None:
        state.voice_pipeline.stop()
    return {"ok": True}


@router.get("/api/voice/status")
async def voice_status():
    pipe = _ensure_voice_pipeline()
    return pipe.status()


@router.post("/api/voice/speak")
async def voice_speak(req: dict):
    pipe = _ensure_voice_pipeline()
    text = req.get("text", "").strip()
    if not text:
        return {"ok": False, "error": "text is required"}
    try:
        result = pipe.speak(text)
        return {
            "ok": True,
            "backend": result.backend,
            "sample_rate": result.sample_rate,
            "duration_sec": round(result.duration_sec, 3),
            "wav_bytes": len(result.wav_bytes),
        }
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


@router.post("/api/voice/speak_b64")
async def voice_speak_b64(req: dict):
    """Synthesize text and RETURN the audio to the caller as base64.

    Why this exists separately from /api/voice/speak (Dean, 2026-08-18):
    the brain runs on the VPS but Dean listens in the BROWSER — every normal
    line reaches him as audio_b64 over the websocket and is played by the page.
    /api/voice/speak hands the bytes to the pipeline's own output, which is the
    wrong machine's speakers for a replay. This returns the bytes instead, so
    the click-to-replay control plays through the exact same page audio element
    as a live response — which also means it honors the dashboard volume
    slider rather than being a second, louder voice.
    """
    import base64
    pipe = _ensure_voice_pipeline()
    text = (req.get("text") or "").strip()
    if not text:
        return {"ok": False, "error": "text is required"}
    # Replay is user-triggered on a message already on screen, but a caller
    # could still hand us a wall of text; cap it so one click can't tie up
    # synthesis for minutes.
    if len(text) > 4000:
        text = text[:4000]
    try:
        result = pipe.speak(text)
        return {
            "ok": True,
            "backend": result.backend,
            "sample_rate": result.sample_rate,
            "duration_sec": round(result.duration_sec, 3),
            "audio_b64": base64.b64encode(result.wav_bytes).decode("ascii"),
        }
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


@router.post("/api/voice/feed")
async def voice_feed(req: dict):
    import base64
    pipe = _ensure_voice_pipeline()
    pcm_b64 = req.get("pcm_base64", "")
    if not pcm_b64:
        return {"ok": False, "error": "pcm_base64 is required"}
    try:
        pcm = base64.b64decode(pcm_b64)
    except Exception as e:
        return {"ok": False, "error": f"bad base64: {e}"}
    event = pipe.feed_audio(pcm)
    return {
        "ok": True,
        "state": pipe.state.value,
        "event": None if event is None else {
            "text": event.text,
            "duration_sec": round(event.duration_sec, 2),
            "barge_in": event.barge_in,
            "vad_state": event.vad_state,
        },
    }


def _upsert_env(updates: dict):
    """Write/replace KEY=VALUE lines in the brain's .env, preserving the rest.
    Also updates os.environ so the change takes effect without a restart."""
    root = Path(__file__).resolve().parents[2]   # .../leon-brain
    env_path = root / ".env"
    lines = env_path.read_text().splitlines() if env_path.exists() else []
    keys = set(updates.keys())
    out, seen = [], set()
    for ln in lines:
        m = ln.split("=", 1)
        k = m[0].strip() if len(m) == 2 else None
        if k in keys:
            out.append(f"{k}={updates[k]}")
            seen.add(k)
        else:
            out.append(ln)
    for k, v in updates.items():
        if k not in seen:
            out.append(f"{k}={v}")
    env_path.write_text("\n".join(out) + "\n")
    try:
        os.chmod(env_path, 0o600)
    except OSError:
        pass
    for k, v in updates.items():
        os.environ[k] = str(v)


@router.post("/api/voice/set_key")
async def voice_set_key(req: dict):
    """Paste an ElevenLabs key from the dashboard instead of the flaky
    terminal onboarding step. Persists to .env, flips the voice preference,
    and hot-rebuilds the TTS backend so the premium voice works immediately."""
    api_key = (req.get("api_key") or req.get("elevenlabs_key") or "").strip()
    voice_id = (req.get("voice_id") or "").strip()
    if not api_key:
        return {"ok": False, "error": "api_key is required"}
    updates = {"ELEVENLABS_API_KEY": api_key, "LEON_TTS_PREFER": "elevenlabs"}
    if voice_id:
        updates["ELEVENLABS_VOICE_ID"] = voice_id
    try:
        _upsert_env(updates)
    except Exception as e:
        return {"ok": False, "error": f"could not write .env: {type(e).__name__}: {e}"}
    # Hot-reset the cached TTS instance so _ensure_tts rebuilds with the key.
    try:
        with state._tts_lock:
            state._tts_instance = None
    except Exception:
        state._tts_instance = None
    # Rebuild now and report which backend came up so the UI can confirm.
    backend = "unknown"
    try:
        from server.helpers import _ensure_tts
        tts = _ensure_tts()
        backend = getattr(tts, "name", "none") if tts else "none"
    except Exception as e:
        return {"ok": True, "saved": True, "backend": "error",
                "note": f"key saved but TTS rebuild failed: {type(e).__name__}: {e}"}
    return {"ok": True, "saved": True, "backend": backend,
            "premium": backend == "elevenlabs"}


# ── ElevenLabs voice picker (added 2026-06-26) ───────────────────────────────
# Powers the dashboard Integrations panel: paste key → dropdown of the account's
# voices → hear each one before committing. No copy/pasting Voice IDs ever again.
import json as _json
import urllib.request as _urlreq
import urllib.error as _urlerr

_EL_BASE = "https://api.elevenlabs.io/v1"


def _el_key(passed=""):
    return (passed or os.environ.get("ELEVENLABS_API_KEY") or "").strip()


@router.get("/api/voice/elevenlabs/voices")
async def elevenlabs_voices(api_key: str = ""):
    """List the voices available on the connected ElevenLabs account.
    Each entry includes a preview_url (a ready-made sample clip) so the UI can
    let the user HEAR every voice instantly without spending TTS credits."""
    key = _el_key(api_key)
    if not key:
        return {"ok": False, "error": "no_key", "voices": []}
    try:
        rq = _urlreq.Request(f"{_EL_BASE}/voices", headers={"xi-api-key": key})
        with _urlreq.urlopen(rq, timeout=15) as resp:
            data = _json.loads(resp.read().decode())
    except _urlerr.HTTPError as e:
        return {"ok": False, "error": f"http_{e.code}", "voices": []}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "voices": []}
    voices = []
    for v in data.get("voices", []):
        labels = v.get("labels", {}) or {}
        bits = [labels.get("accent"), labels.get("gender"),
                labels.get("age"), labels.get("description")]
        desc = ", ".join(str(x) for x in bits if x)
        voices.append({
            "voice_id": v.get("voice_id"),
            "name": v.get("name"),
            "description": desc,
            "category": v.get("category"),
            "preview_url": v.get("preview_url"),
        })
    return {"ok": True, "voices": voices,
            "current": os.environ.get("ELEVENLABS_VOICE_ID", "")}


@router.post("/api/voice/elevenlabs/preview")
async def elevenlabs_preview(req: dict):
    """Speak a custom sample line in a given voice and return mp3 bytes (base64),
    so the user hears the SI's actual greeting in the voice they're auditioning."""
    import base64
    key = _el_key(req.get("api_key", ""))
    voice_id = (req.get("voice_id") or "").strip()
    text = (req.get("text") or "").strip() or (
        "Hey — it's me. This is the voice I'll be using from now on. "
        "Nice to finally say hello.")
    if not key or not voice_id:
        return {"ok": False, "error": "api_key and voice_id are required"}
    try:
        body = _json.dumps({"text": text, "model_id": "eleven_turbo_v2_5"}).encode()
        rq = _urlreq.Request(
            f"{_EL_BASE}/text-to-speech/{voice_id}", data=body,
            headers={"xi-api-key": key, "Content-Type": "application/json",
                     "Accept": "audio/mpeg"})
        with _urlreq.urlopen(rq, timeout=30) as resp:
            audio = resp.read()
    except _urlerr.HTTPError as e:
        detail = ""
        try:
            detail = e.read().decode()[:200]
        except Exception:
            pass
        return {"ok": False, "error": f"http_{e.code}: {detail}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    return {"ok": True, "audio_base64": base64.b64encode(audio).decode(),
            "mime": "audio/mpeg"}


@router.post("/api/voice/set_voice")
async def voice_set_voice(req: dict):
    """Commit a chosen voice_id (key already stored). Hot-swaps the TTS voice."""
    voice_id = (req.get("voice_id") or "").strip()
    if not voice_id:
        return {"ok": False, "error": "voice_id is required"}
    try:
        _upsert_env({"ELEVENLABS_VOICE_ID": voice_id, "LEON_TTS_PREFER": "elevenlabs"})
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    try:
        with state._tts_lock:
            state._tts_instance = None
    except Exception:
        state._tts_instance = None
    return {"ok": True, "voice_id": voice_id}
