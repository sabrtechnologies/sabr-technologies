"""
/api/cognition/{executive,tools,tool_health,skills,reflex,suggestions,
proposals,providers,soak,hypotheses,promote,demote,hierarchy}/* —
the routing + dispatch surface of Leon's cognition layer.

Executive plans + simulates next actions. tool_health/classifier ranks
tools by past success. skills + reflex deliver canned answers. Hypotheses
+ promote/demote control the shadow→active flip. providers manage LLM
fallback. soak summarizes 7-day reliability metrics.

Extracted from cognition.py 2026-06-08 per architecture review.
Behavior unchanged. _require_cognition + _phase13_missing duplicated
locally (same pattern as the other extracted cognition routers).
"""

import logging

from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


def _require_cognition():
    if state.cognition is None:
        return JSONResponse(
            {"ok": False, "error": "cognition layer not installed (LEON_COGNITION=off?)"},
            status_code=503,
        )
    return None


def _phase13_missing(attr: str):
    miss = _require_cognition()
    if miss is not None:
        return miss
    if getattr(state.cognition, attr, None) is None:
        return JSONResponse({"ok": False, "error": f"{attr} not installed"}, status_code=503)
    return None


# =============================================================================
# Hypothesis corroboration (Phase 12A)
# =============================================================================

@router.post("/api/cognition/hypotheses/verify")
async def cognition_hypotheses_verify_now():
    """Run one verification pass on-demand. Normally runs inside consolidate_pass."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    v = getattr(state.cognition, "verifier", None)
    if v is None:
        return JSONResponse({"ok": False, "error": "verifier not installed"}, status_code=503)
    try:
        return JSONResponse({"ok": True, "result": v.verify_pass()})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


@router.get("/api/cognition/hypotheses/verified")
async def cognition_hypotheses_verified(limit: int = 20):
    """Return hypotheses currently flagged 'corroborated'."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    v = getattr(state.cognition, "verifier", None)
    if v is None:
        return JSONResponse({"ok": False, "error": "verifier not installed"}, status_code=503)
    try:
        limit = max(1, min(int(limit), 100))
        return JSONResponse({"ok": True, "corroborated": v.corroborated_hypotheses(limit=limit)})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


@router.get("/api/cognition/hypotheses/summary")
async def cognition_hypotheses_summary():
    miss = _require_cognition()
    if miss is not None:
        return miss
    v = getattr(state.cognition, "verifier", None)
    if v is None:
        return JSONResponse({"ok": False, "error": "verifier not installed"}, status_code=503)
    try:
        return JSONResponse({"ok": True, "summary": v.summary()})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


# =============================================================================
# Auto-promote / demote (Phase 12B)
# =============================================================================

@router.get("/api/cognition/promote/readiness")
async def cognition_promote_readiness():
    miss = _require_cognition()
    if miss is not None:
        return miss
    p = getattr(state.cognition, "promoter", None)
    if p is None:
        return JSONResponse({"ok": False, "error": "promoter not installed"}, status_code=503)
    try:
        return JSONResponse({"ok": True, "report": p.readiness().to_dict()})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


@router.post("/api/cognition/promote")
async def cognition_promote_flip(reason: str = "manual"):
    miss = _require_cognition()
    if miss is not None:
        return miss
    p = getattr(state.cognition, "promoter", None)
    if p is None:
        return JSONResponse({"ok": False, "error": "promoter not installed"}, status_code=503)
    try:
        return JSONResponse(p.promote(reason=reason))
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


@router.post("/api/cognition/demote")
async def cognition_demote(reason: str = "manual"):
    miss = _require_cognition()
    if miss is not None:
        return miss
    p = getattr(state.cognition, "promoter", None)
    if p is None:
        return JSONResponse({"ok": False, "error": "promoter not installed"}, status_code=503)
    try:
        return JSONResponse(p.demote(reason=reason))
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


@router.get("/api/cognition/promote/history")
async def cognition_promote_history(limit: int = 20):
    miss = _require_cognition()
    if miss is not None:
        return miss
    p = getattr(state.cognition, "promoter", None)
    if p is None:
        return JSONResponse({"ok": False, "error": "promoter not installed"}, status_code=503)
    try:
        limit = max(1, min(int(limit), 200))
        return JSONResponse({"ok": True, "history": p.recent_history(limit=limit)})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


# =============================================================================
# Executive — plan / simulate / route trace / counters
# =============================================================================

@router.get("/api/cognition/executive/plan")
async def cognition_executive_plan(text: str = ""):
    miss = _phase13_missing("executive")
    if miss is not None:
        return miss
    try:
        plan = state.cognition.executive.plan(text or "")
        return JSONResponse({"ok": True, "plan": plan.to_dict()})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


@router.get("/api/cognition/executive/last")
async def cognition_executive_last():
    miss = _phase13_missing("executive")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, "plan": state.cognition.executive.last()})


@router.get("/api/cognition/executive/history")
async def cognition_executive_history(n: int = 20):
    miss = _phase13_missing("executive")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, "history": state.cognition.executive.history(n)})


@router.get("/api/cognition/executive/simulate")
async def cognition_executive_simulate(
    tools: str = "", skill_id: int = 0, strategy: str = "claude_fast"):
    miss = _phase13_missing("executive")
    if miss is not None:
        return miss
    tool_list = [t.strip() for t in tools.split(",") if t.strip()] if tools else []
    try:
        sim = state.cognition.executive.simulate(
            strategy=strategy,
            tools=tool_list or None,
            skill_id=skill_id or None,
        )
        return JSONResponse({"ok": True, "simulation": sim.to_dict()})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


@router.get("/api/cognition/executive/route_trace")
async def cognition_executive_route_trace(n: int = 50):
    miss = _phase13_missing("executive")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True,
                          "trace": state.cognition.executive.route_trace(n=n),
                          "counters": state.cognition.executive.counters()})


@router.get("/api/cognition/executive/counters")
async def cognition_executive_counters():
    miss = _phase13_missing("executive")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, "counters": state.cognition.executive.counters()})


# =============================================================================
# Tool health / classifier
# =============================================================================

@router.get("/api/cognition/tool_health")
async def cognition_tool_health(status: str = "", limit: int = 100):
    miss = _phase13_missing("tool_health")
    if miss is not None:
        return miss
    th = state.cognition.tool_health
    status = (status or "").strip().lower() or None
    rows = [s.to_dict() for s in th.all_stats(status=status, limit=limit)]
    return JSONResponse({
        "ok": True, "summary": th.summary(), "rows": rows,
    })


@router.get("/api/cognition/tool_health/{tool}")
async def cognition_tool_health_get(tool: str):
    miss = _phase13_missing("tool_health")
    if miss is not None:
        return miss
    s = state.cognition.tool_health.get(tool)
    return JSONResponse({"ok": True, "tool": s.to_dict() if s else None})


@router.get("/api/cognition/tools/classify")
async def cognition_tools_classify(force: bool = False):
    miss = _phase13_missing("tool_classifier")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True,
                          "snapshot": state.cognition.tool_classifier.classify_all(force=force)})


@router.get("/api/cognition/tools/preferred")
async def cognition_tools_preferred(intent: str = "", limit: int = 10):
    miss = _phase13_missing("tool_classifier")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "preferred": state.cognition.tool_classifier.preferred_for(intent, limit=limit),
    })


@router.get("/api/cognition/tools/dormant")
async def cognition_tools_dormant(limit: int = 100):
    miss = _phase13_missing("tool_classifier")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True,
                          "rows": state.cognition.tool_classifier.dormant(limit=limit)})


@router.get("/api/cognition/tools/redundant")
async def cognition_tools_redundant(limit: int = 100):
    miss = _phase13_missing("tool_classifier")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True,
                          "rows": state.cognition.tool_classifier.redundant(limit=limit)})


@router.get("/api/cognition/tools/visible")
async def cognition_tools_visible(include_legacy: bool = False):
    miss = _phase13_missing("tool_classifier")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "visible": state.cognition.tool_classifier.visible_tools(include_legacy=include_legacy),
        "hidden_count": state.cognition.tool_classifier.hidden_count(),
    })


@router.get("/api/cognition/tools/grouped")
async def cognition_tools_grouped(limit_per_family: int = 10):
    miss = _phase13_missing("tool_classifier")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "families": state.cognition.tool_classifier.group_dormant_by_family(
            limit_per_family=limit_per_family),
    })


@router.get("/api/cognition/tools/skill_for")
async def cognition_tools_skill_for(tool: str):
    miss = _phase13_missing("tool_classifier")
    if miss is not None:
        return miss
    sk_handle = getattr(state.cognition, "skills", None)
    return JSONResponse({
        "ok": True,
        "tool": tool,
        "skill": state.cognition.tool_classifier.skill_for(tool, skills_provider=sk_handle),
    })


# =============================================================================
# Skills (state machine + mining)
# =============================================================================

@router.get("/api/cognition/skills")
async def cognition_skills_list(limit: int = 50):
    miss = _phase13_missing("skills")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "stats": state.cognition.skills.stats(),
        "rows": [s.to_dict() for s in state.cognition.skills.all(limit=limit)],
    })


@router.post("/api/cognition/skills/mine")
async def cognition_skills_mine(req: Request):
    miss = _phase13_missing("skills")
    if miss is not None:
        return miss
    try:
        body = await req.json()
    except Exception:
        body = {}
    report = state.cognition.skills.mine(
        window_minutes=int(body.get("window_minutes", 60)),
        min_runs=int(body.get("min_runs", 2)),
        min_success_rate=float(body.get("min_success_rate", 0.7)),
    )
    return JSONResponse({"ok": True, "report": report})


@router.get("/api/cognition/skills/by_state")
async def cognition_skills_by_state(
    state_val: str = Query("reinforced", alias="state"),
    limit: int = 50,
):
    miss = _phase13_missing("skills")
    if miss is not None:
        return miss
    if not hasattr(state.cognition.skills, "by_state"):
        return JSONResponse({"ok": False,
                              "error": "skill state machine not available"})
    rows = state.cognition.skills.by_state(state_val, limit=limit)
    return JSONResponse({"ok": True,
                          "summary": state.cognition.skills.state_summary(),
                          "rows": [s.to_dict() for s in rows]})


# =============================================================================
# Reflex + suggestions
# =============================================================================

@router.get("/api/cognition/reflex")
async def cognition_reflex(text: str = ""):
    miss = _phase13_missing("reflex")
    if miss is not None:
        return miss
    r = state.cognition.reflex.respond(text or "")
    return JSONResponse({"ok": True, "answer": (r.to_dict() if r else None)})


@router.get("/api/cognition/suggestions")
async def cognition_suggestions(limit: int = 30):
    miss = _phase13_missing("suggestions")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "running": state.cognition.suggestions.is_running(),
        "recent": state.cognition.suggestions.recent(limit=limit),
    })


@router.post("/api/cognition/suggestions/tick")
async def cognition_suggestions_tick():
    miss = _phase13_missing("suggestions")
    if miss is not None:
        return miss
    out = state.cognition.suggestions.tick_now()
    return JSONResponse({"ok": True, "generated": [s.to_dict() for s in out]})


# =============================================================================
# Proposals (Phase 15)
# =============================================================================

@router.get("/api/cognition/proposals")
async def cognition_proposals_list(status: str = "", limit: int = 50):
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    r = state.cognition.reflection
    rows = r.proposals(status=(status or None), limit=limit)
    return JSONResponse({
        "ok": True, "stats": r.proposal_stats(), "rows": rows,
    })


@router.post("/api/cognition/proposals/{pid}/approve")
async def cognition_proposals_approve(pid: int, req: Request):
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    try:
        body = await req.json()
    except Exception:
        body = {}
    who = (body.get("by") or "dean")
    out = state.cognition.reflection.approve_proposal(int(pid), by=who)
    return JSONResponse(out)


@router.post("/api/cognition/proposals/{pid}/reject")
async def cognition_proposals_reject(pid: int, req: Request):
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    try:
        body = await req.json()
    except Exception:
        body = {}
    out = state.cognition.reflection.reject_proposal(
        int(pid),
        by=body.get("by") or "dean",
        note=body.get("note", ""))
    return JSONResponse(out)


# =============================================================================
# Providers (LLM fallback)
# =============================================================================

@router.get("/api/cognition/providers")
async def cognition_providers_list():
    miss = _phase13_missing("providers")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "fallback_enabled": state.cognition.providers.fallback_enabled(),
        "providers": state.cognition.providers.all(),
    })


@router.post("/api/cognition/providers/{name}/probe")
async def cognition_providers_probe(name: str):
    miss = _phase13_missing("providers")
    if miss is not None:
        return miss
    new_status = state.cognition.providers.probe(name)
    return JSONResponse({
        "ok": True, "name": name, "status": new_status,
        "state": (state.cognition.providers.state(name) or "").__dict__
                  if state.cognition.providers.state(name) else None,
    })


# =============================================================================
# Soak (7-day reliability metrics)
# =============================================================================

@router.get("/api/cognition/soak/summary")
async def cognition_soak_summary(days: int = 7):
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "summary": state.cognition.reflection.soak_summary(days=days),
    })


@router.post("/api/cognition/soak/record_now")
async def cognition_soak_record():
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    snap = state.cognition.reflection.record_daily_metrics()
    return JSONResponse({"ok": True, "recorded": snap})
