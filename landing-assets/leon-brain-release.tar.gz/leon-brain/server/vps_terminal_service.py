#!/usr/bin/env python3

import asyncio
import json
import logging
import os
import subprocess
import uuid
from typing import Dict
import signal

from aiohttp import web

# fcntl is POSIX-only. This whole service spawns PTY-backed shells
# (/bin/bash by default below) — it is a VPS-hosted cloud-terminal gateway,
# not something a Windows client install runs, and true PTY non-blocking
# I/O has no clean Windows equivalent worth building for a feature nothing
# currently imports. But an UNGUARDED module-scope import is a crash for
# whoever imports this NEXT on Windows, not just a limitation of what this
# file can do there (Aiden's report, 2026-08-24, item 2: si_mail_routes.py
# had exactly this shape and it took the entire server down on boot). Guard
# it here too, now, while it costs nothing — make_nonblocking simply isn't
# callable on a platform with no PTY story, and says so instead of dying at
# import time for every OTHER route sharing this process.
try:
    import fcntl
except ImportError:
    fcntl = None

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("vps-terminal-service")

TERMINALS: Dict[str, dict] = {}
TERMINAL_LOCK = asyncio.Lock()

def make_nonblocking(fd):
    """Make a file descriptor non-blocking. POSIX only — see module docstring."""
    if fcntl is None:
        raise RuntimeError(
            "vps_terminal_service needs fcntl (POSIX PTYs) — not available "
            "on this platform.")
    flags = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

async def spawn_terminal(request):
    """Spawn a new terminal session."""
    try:
        data = await request.json()
        session_id = str(uuid.uuid4())
        cwd = data.get("cwd", os.path.expanduser("~"))
        shell = data.get("shell", "/bin/bash")
        
        if not os.path.isdir(cwd):
            cwd = os.path.expanduser("~")
        
        async with TERMINAL_LOCK:
            try:
                # Spawn shell with binary pipes
                proc = subprocess.Popen(
                    [shell, "-i"],
                    cwd=cwd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    bufsize=0,
                    preexec_fn=os.setsid
                )
                
                # Make stdout non-blocking
                make_nonblocking(proc.stdout.fileno())
                
                TERMINALS[session_id] = {
                    "proc": proc,
                    "cwd": cwd,
                    "created": asyncio.get_event_loop().time()
                }
                logger.info(f"Spawned terminal {session_id} in {cwd} (PID {proc.pid})")
                return web.json_response({
                    "session_id": session_id,
                    "status": "ok",
                    "pid": proc.pid
                })
            except Exception as e:
                logger.error(f"Failed to spawn: {e}")
                return web.json_response({"error": str(e)}, status=500)
    except Exception as e:
        logger.error(f"Spawn error: {e}")
        return web.json_response({"error": str(e)}, status=400)

async def write_terminal(request):
    """Write data to terminal."""
    session_id = request.match_info["session_id"]
    try:
        data = await request.json()
        term_data = TERMINALS.get(session_id)
        
        if not term_data:
            return web.json_response({"error": "Terminal not found"}, status=404)
        
        proc = term_data["proc"]
        
        if proc.poll() is not None:
            del TERMINALS[session_id]
            return web.json_response({"error": "Terminal process exited"}, status=410)
        
        async with TERMINAL_LOCK:
            try:
                command = data.get("data", "")
                proc.stdin.write(command.encode('utf-8'))
                proc.stdin.flush()
                return web.json_response({"status": "ok"})
            except Exception as e:
                logger.error(f"Write error: {e}")
                return web.json_response({"error": str(e)}, status=400)
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def read_terminal(request):
    """Read output from terminal."""
    session_id = request.match_info["session_id"]
    try:
        term_data = TERMINALS.get(session_id)
        
        if not term_data:
            return web.json_response({"error": "Terminal not found"}, status=404)
        
        proc = term_data["proc"]
        
        if proc.poll() is not None:
            del TERMINALS[session_id]
            return web.json_response({"error": "Terminal process exited", "output": ""}, status=410)
        
        async with TERMINAL_LOCK:
            try:
                output_bytes = b""
                # Read all available output without blocking
                while True:
                    try:
                        chunk = proc.stdout.read(4096)
                        if not chunk:
                            break
                        output_bytes += chunk
                    except BlockingIOError:
                        break
                
                output = output_bytes.decode('utf-8', errors='replace')
                
                return web.json_response({
                    "session_id": session_id,
                    "output": output,
                    "status": "ok"
                })
            except Exception as e:
                logger.error(f"Read error: {e}")
                return web.json_response({"error": str(e)}, status=400)
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def list_terminals(request):
    """List all active terminal sessions."""
    try:
        sessions = []
        async with TERMINAL_LOCK:
            for session_id, term_data in list(TERMINALS.items()):
                proc = term_data["proc"]
                status = "running" if proc.poll() is None else "dead"
                if proc.poll() is not None:
                    del TERMINALS[session_id]
                else:
                    sessions.append({
                        "session_id": session_id,
                        "pid": proc.pid,
                        "cwd": term_data["cwd"],
                        "status": status
                    })
        
        return web.json_response({
            "sessions": sessions,
            "total": len(sessions)
        })
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def kill_terminal(request):
    """Terminate a terminal session."""
    session_id = request.match_info["session_id"]
    try:
        term_data = TERMINALS.get(session_id)
        
        if not term_data:
            return web.json_response({"error": "Terminal not found"}, status=404)
        
        proc = term_data["proc"]
        
        async with TERMINAL_LOCK:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                proc.wait()
            except Exception as e:
                logger.error(f"Kill error: {e}")
            
            del TERMINALS[session_id]
            logger.info(f"Killed terminal {session_id}")
            return web.json_response({"status": "ok", "session_id": session_id})
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def health_check(request):
    """Health check endpoint."""
    return web.json_response({
        "status": "ok",
        "service": "vps-terminal-service",
        "terminals": len(TERMINALS)
    })

async def init_app():
    app = web.Application()
    app.router.add_post("/api/terminal/spawn", spawn_terminal)
    app.router.add_post("/api/terminal/{session_id}/write", write_terminal)
    app.router.add_get("/api/terminal/{session_id}/read", read_terminal)
    app.router.add_get("/api/terminal/list", list_terminals)
    app.router.add_delete("/api/terminal/{session_id}/kill", kill_terminal)
    app.router.add_get("/api/health", health_check)
    return app

async def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=9102)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()
    
    app = await init_app()
    runner = web.AppRunner(app)
    await runner.setup()
    
    logger.info(f"Starting VPS Terminal Service on {args.host}:{args.port}")
    site = web.TCPSite(runner, args.host, args.port)
    await site.start()
    
    logger.info("Terminal service running. Press CTRL+C to stop.")
    
    try:
        await asyncio.Event().wait()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        await runner.cleanup()

if __name__ == "__main__":
    asyncio.run(main())
