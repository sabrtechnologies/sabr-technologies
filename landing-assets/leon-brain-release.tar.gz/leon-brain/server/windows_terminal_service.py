"""
Windows Terminal Service — ConPTY-based terminal spawning for Windows.

Runs on the Windows PC and exposes HTTP API for spawning ConPTY terminals.
The VPS calls this to spawn terminals instead of using SSH.

Usage:
    python windows_terminal_service.py --port 9101
"""

import asyncio
import json
import logging
import os
import sys
import uuid
from pathlib import Path
from typing import Dict, Optional

try:
    import winpty
    WINPTY_AVAILABLE = True
except ImportError:
    WINPTY_AVAILABLE = False

try:
    from aiohttp import web
except ImportError:
    print("Error: aiohttp not installed. Install with: pip install aiohttp")
    sys.exit(1)

logger = logging.getLogger("windows-terminal-service")
logging.basicConfig(level=logging.INFO)

# Active terminals: {session_id: {pty, process, ...}}
TERMINALS: Dict[str, dict] = {}


async def spawn_terminal(request: web.Request) -> web.Response:
    """
    Spawn a new ConPTY terminal.
    
    POST /api/terminal/spawn
    {
        "cwd": "/path/to/workdir",
        "rows": 24,
        "cols": 80,
        "env": {"KEY": "value"}
    }
    
    Returns:
    {
        "session_id": "uuid-here",
        "status": "ok"
    }
    """
    if not WINPTY_AVAILABLE:
        return web.json_response(
            {"error": "ConPTY not available (pywinpty not installed)"},
            status=500
        )
    
    try:
        data = await request.json()
    except Exception as e:
        return web.json_response({"error": f"Invalid JSON: {e}"}, status=400)
    
    cwd = data.get("cwd", os.path.expanduser("~"))
    rows = data.get("rows", 24)
    cols = data.get("cols", 80)
    env = data.get("env", {})
    
    session_id = str(uuid.uuid4())
    
    try:
        # Spawn ConPTY terminal
        pty = winpty.PtyProcess.spawn(
            "cmd.exe",
            env=env,
            cwd=cwd,
        )
        
        TERMINALS[session_id] = {
            "pty": pty,
            "cwd": cwd,
            "rows": rows,
            "cols": cols,
        }
        
        logger.info(f"Spawned terminal {session_id} in {cwd}")
        return web.json_response({"session_id": session_id, "status": "ok"})
    
    except Exception as e:
        logger.error(f"Failed to spawn terminal: {e}")
        return web.json_response({"error": str(e)}, status=500)


async def write_terminal(request: web.Request) -> web.Response:
    """
    Write data to a terminal.
    
    POST /api/terminal/{session_id}/write
    {
        "data": "command to send"
    }
    """
    session_id = request.match_info.get("session_id")
    if session_id not in TERMINALS:
        return web.json_response({"error": "Terminal not found"}, status=404)
    
    try:
        data = await request.json()
        text = data.get("data", "")
        TERMINALS[session_id]["pty"].write(text)
        return web.json_response({"status": "ok"})
    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)


async def read_terminal(request: web.Request) -> web.Response:
    """
    Read data from a terminal.
    
    GET /api/terminal/{session_id}/read?bytes=4096
    
    Returns:
    {
        "data": "terminal output"
    }
    """
    session_id = request.match_info.get("session_id")
    if session_id not in TERMINALS:
        return web.json_response({"error": "Terminal not found"}, status=404)
    
    try:
        max_bytes = int(request.query.get("bytes", 4096))
        pty = TERMINALS[session_id]["pty"]
        
        # Non-blocking read
        try:
            data = pty.read(max_bytes)
            return web.json_response({"data": data.decode("utf-8", errors="replace")})
        except:
            return web.json_response({"data": ""})
    
    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)


async def resize_terminal(request: web.Request) -> web.Response:
    """
    Resize a terminal.
    
    POST /api/terminal/{session_id}/resize
    {
        "rows": 24,
        "cols": 80
    }
    """
    session_id = request.match_info.get("session_id")
    if session_id not in TERMINALS:
        return web.json_response({"error": "Terminal not found"}, status=404)
    
    try:
        data = await request.json()
        rows = data.get("rows", 24)
        cols = data.get("cols", 80)
        
        pty = TERMINALS[session_id]["pty"]
        pty.setwinsize(rows, cols)
        
        return web.json_response({"status": "ok"})
    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)


async def close_terminal(request: web.Request) -> web.Response:
    """
    Close a terminal.
    
    POST /api/terminal/{session_id}/close
    """
    session_id = request.match_info.get("session_id")
    if session_id not in TERMINALS:
        return web.json_response({"error": "Terminal not found"}, status=404)
    
    try:
        term = TERMINALS[session_id]
        term["pty"].terminate()
        del TERMINALS[session_id]
        logger.info(f"Closed terminal {session_id}")
        return web.json_response({"status": "ok"})
    except Exception as e:
        return web.json_response({"error": str(e)}, status=500)


async def health_check(request: web.Request) -> web.Response:
    """Health check endpoint."""
    return web.json_response({
        "status": "ok",
        "conpty_available": WINPTY_AVAILABLE,
        "active_terminals": len(TERMINALS),
    })


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Windows Terminal Service")
    parser.add_argument("--port", type=int, default=9101, help="HTTP port")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address")
    args = parser.parse_args()
    
    if not WINPTY_AVAILABLE:
        print("Warning: pywinpty not installed. Install with: pip install pywinpty")
        print("Terminal spawning will not work until pywinpty is installed.")
    
    app = web.Application()
    app.router.add_post("/api/terminal/spawn", spawn_terminal)
    app.router.add_post("/api/terminal/{session_id}/write", write_terminal)
    app.router.add_get("/api/terminal/{session_id}/read", read_terminal)
    app.router.add_post("/api/terminal/{session_id}/resize", resize_terminal)
    app.router.add_post("/api/terminal/{session_id}/close", close_terminal)
    app.router.add_get("/health", health_check)
    
    logger.info(f"Starting Windows Terminal Service on {args.host}:{args.port}")
    logger.info(f"ConPTY available: {WINPTY_AVAILABLE}")
    
    web.run_app(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
