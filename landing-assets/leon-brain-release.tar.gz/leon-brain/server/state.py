"""
Shared mutable state for the Leon server.

All global variables live here so every router and module can import
`from server import state` and access `state.brain`, `state.cognition`, etc.

External code that does `import server; server.brain` works via the
package-level __getattr__ proxy in server/__init__.py.
"""

import asyncio
import os
import threading
import time
from typing import Any, Dict, Optional

from brain.claude_responder import BrainResponder
from brain.sleep_consolidation import SleepConsolidator

# ── Core brain objects ────────────────────────────────────────────────
brain = None
text_encoder = None
vision_encoder = None
audio_encoder = None
claude_bridge = None
screen_observer = None
video_recorder = None

# V1.3 agent (wired to knowledge store in init_brain)
agent = None

# V1.3 voice pipeline (lazy-init on first use)
voice_pipeline = None

# Brain responder — Claude-powered conversational responses.
brain_responder = BrainResponder()
brain_api_responder = None

# Phase 1 cognition bundle
cognition = None
leon_consciousness = None  # unified awareness

# ── HIGH-risk tool confirmation registry ──────────────────────────────
_pending_confirms: Dict[str, Dict[str, Any]] = {}
_pending_confirms_lock = threading.Lock()

# ── Webcam frame-pull registry ────────────────────────────────────────
_pending_webcam: Dict[str, Dict[str, Any]] = {}
_pending_webcam_lock = threading.Lock()
_webcam_clients: Dict[int, bool] = {}
_webcam_clients_lock = threading.Lock()

# TTL cleanup for pending registries (prevents unbounded growth from orphaned entries)
_PENDING_TTL_S = 300  # 5 minutes


def _cleanup_pending():
    """Remove stale entries from pending dicts. Call periodically."""
    import time
    now = time.time()
    with _pending_confirms_lock:
        stale = [k for k, v in _pending_confirms.items()
                 if now - v.get("ts", 0) > _PENDING_TTL_S]
        for k in stale:
            del _pending_confirms[k]
    with _pending_webcam_lock:
        stale = [k for k, v in _pending_webcam.items()
                 if now - v.get("ts", 0) > _PENDING_TTL_S]
        for k in stale:
            del _pending_webcam[k]

# ── V1.3 subsystems (populated in init_brain) ────────────────────────
sleep_consolidator: SleepConsolidator = None
conv_distiller = None
project_crawler = None
wake_listener = None
wake_orchestrator = None
reminder_scheduler = None
routine_scheduler = None

# ConceptMap — binds topics to hippocampal neuron patterns (Layer 2)
concept_map = None

# DaydreamEngine — spontaneous concept association (Layer 4)
daydream_engine = None

# DreamEngine — SNN-level sleep cycles with actual learning (Layer 5)
dream_engine = None

# Autobiography — episodic narrative timeline
autobiography = None

# Goals — persistent long-term desires
goal_system = None

# InnerVoice — stream of consciousness
inner_voice = None

# SelfTuning — self-modifiable parameters
self_tuning = None

# OpinionTracker — persistent opinions/preferences
opinion_tracker = None

# SelfReflection — periodic metacognition
self_reflection = None

# AmbientPerception — continuous sensory absorption
ambient_perception = None

# StakesTracker — things Leon can genuinely lose
stakes_tracker = None

# DriveSystem — homeostatic drives from real hardware telemetry
drive_system = None

# PersistentBrainState — consciousness that survives restarts
persistent_state = None

# Pre-warmed STT
_prewarmed_stt = None

# LocalVision (Moondream2)
_local_vision = None

# Step 8 — proactive ambient watch loop
proactive_loop = None

# Responder lock — shared by text, wake, and proactive paths
_responder_lock = threading.Lock()

# Captured at WebSocket layer, used by wake-word events
_main_event_loop: Optional[asyncio.AbstractEventLoop] = None

# Responder usage stats
_responder_stats = {
    "call_count": 0,
    "session_start": time.time(),
    "last_call_ts": None,
    "is_processing": False,
}

# ── Dashboard path (set in server.py after init) ────────────────────
dashboard_path: Optional[str] = None

# ── Simulation thread control ────────────────────────────────────────
sim_running = False
sim_thread = None
connected_clients = set()

# Auto-save interval
AUTO_SAVE_INTERVAL = 1800  # 30 min
_last_auto_save = 0

# ── Phase 15 (MC): Mission Control ──────────────────────────────────
mission_registry = None
mission_state = None
mission_connectors = None
mission_creds = None
mission_decisions = None
mission_ops = None

# ── Phase 17: Autopilot ─────────────────────────────────────────────
autopilot_executor = None
autopilot_planner = None
autopilot_scheduler = None

# ── TTS ──────────────────────────────────────────────────────────────
_TTS_MODEL_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "brain_state", "voice", "piper", "en_GB-alan-medium.onnx",
)
_tts_instance = None
_tts_lock = threading.Lock()

# ── Screen logging ───────────────────────────────────────────────────
_last_screen_log = 0
SCREEN_LOG_INTERVAL = 30

# ── Webcam frame cache ───────────────────────────────────────────────
_webcam_frame_cache: Dict[str, Any] = {}
_webcam_frame_ts: float = 0.0

# ── STT (lazy-init) ─────────────────────────────────────────────────
_stt_instance = None
_stt_lock = threading.Lock()
