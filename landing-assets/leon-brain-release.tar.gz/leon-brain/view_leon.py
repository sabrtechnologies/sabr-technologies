#!/usr/bin/env python3
"""
Leon World Viewer — Watch Leon in his home.

Opens a 3D MuJoCo viewer window showing Leon's humanoid body in his
5-room apartment. The brain simulation runs alongside — Leon's motor
cortex drives his joints, his sensors feed his SNN, and you watch
it all happen in real time.

Controls:
  Mouse drag: rotate camera
  Scroll: zoom
  Double-click body: track that body
  Right-click drag: pan
  Ctrl+click: select body
  Tab: toggle overlay info

Usage:
  python3 view_leon.py              # viewer only (no brain)
  python3 view_leon.py --brain      # viewer + brain simulation
  python3 view_leon.py --brain --neurons 1000  # smaller brain for speed
"""

import argparse
import sys
import threading
import time

import mujoco
import mujoco.viewer


def run_viewer_only(model_path: str):
    """Launch viewer without brain — just see the world."""
    model = mujoco.MjModel.from_xml_path(model_path)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)

    print(f"[VIEWER] World loaded: {model.nbody} bodies, {model.ngeom} geoms")
    print(f"[VIEWER] Leon at ({data.qpos[0]:.1f}, {data.qpos[1]:.1f}, {data.qpos[2]:.1f})")
    print(f"[VIEWER] Controls: drag=rotate, scroll=zoom, double-click=track")
    print(f"[VIEWER] Close window to exit")

    # Launch interactive viewer (blocks until window closed)
    mujoco.viewer.launch(model, data)


def run_with_brain(model_path: str, neurons: int):
    """Launch viewer with brain simulation running in background."""
    # Import brain components
    sys.path.insert(0, ".")
    from brain.brain import Brain
    from brain.embodiment import MuJoCoBody

    print(f"[VIEWER] Initializing brain with {neurons:,} neurons...")
    brain = Brain(total_neurons=neurons)
    body = MuJoCoBody()
    body.init_metabolic(brain)
    brain.simulated_body = body

    print(f"[VIEWER] Brain ready: {brain.total_neurons:,} neurons, "
          f"{brain.total_synapses:,} synapses")
    print(f"[VIEWER] Body: {body.model.nq} DOFs, {body.model.nu} actuators, "
          f"101 systems active")

    # Brain simulation thread
    sim_running = True
    tick_count = 0
    hz_display = 0.0

    def brain_loop():
        nonlocal tick_count, hz_display, sim_running
        t0 = time.time()
        while sim_running:
            brain.step()
            tick_count += 1
            # Update Hz display every second
            elapsed = time.time() - t0
            if elapsed > 1.0:
                hz_display = tick_count / elapsed
                tick_count = 0
                t0 = time.time()
            # Yield to prevent CPU monopoly
            if tick_count % 10 == 0:
                time.sleep(0.001)

    brain_thread = threading.Thread(target=brain_loop, daemon=True,
                                     name="brain-sim")
    brain_thread.start()
    print(f"[VIEWER] Brain simulation running in background")
    print(f"[VIEWER] Close window to exit")

    # Launch viewer with the body's MuJoCo model/data
    # The brain thread updates data.ctrl and mj_step runs in body.tick()
    try:
        mujoco.viewer.launch(body.model, body.data)
    finally:
        sim_running = False
        print(f"[VIEWER] Shutting down...")


def main():
    parser = argparse.ArgumentParser(description="Leon World Viewer")
    parser.add_argument("--brain", action="store_true",
                       help="Run brain simulation alongside viewer")
    parser.add_argument("--neurons", type=int, default=1000,
                       help="Number of neurons (default 1000 for speed)")
    args = parser.parse_args()

    import os
    model_path = os.path.join(os.path.dirname(__file__),
                              "brain", "leon_body.xml")

    if args.brain:
        os.chdir(os.path.dirname(__file__))
        run_with_brain(model_path, args.neurons)
    else:
        run_viewer_only(model_path)


if __name__ == "__main__":
    main()
