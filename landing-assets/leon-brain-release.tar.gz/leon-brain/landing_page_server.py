#!/usr/bin/env python3
"""
Simple HTTP server to serve the landing page
"""
import http.server
import socketserver
import os

PORT = 3333
CONTENT_DIR = '/opt/leon-brain/workspaces/landing-deploy'

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=CONTENT_DIR, **kwargs)

    def do_GET(self):
        # Serve cloud.html for root
        if self.path == '/':
            self.path = '/cloud.html'
        return super().do_GET()

if __name__ == '__main__':
    os.chdir(CONTENT_DIR)
    with socketserver.TCPServer(("0.0.0.0", PORT), MyHTTPRequestHandler) as httpd:
        print(f"Landing page server running on port {PORT}")
        print(f"Serving from: {CONTENT_DIR}")
        print(f"Access at: http://127.0.0.1:{PORT}/")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Server stopped")
