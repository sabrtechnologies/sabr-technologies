#!/bin/bash
# MOVED. The canonical installer is landing/bootstrap.sh (its own git repo).
# This copy was an orphan fork — 435 diff lines behind, missing the release
# digest pin, tenant identity, disk preflight and stop-before-replace. B11 and
# B12 were landed here by mistake on 2026-08-05 and then re-landed there.
# Deletion is Dean-supervised; this stub exists so nothing silently runs the
# dead copy.
echo "bootstrap.sh moved to landing/bootstrap.sh — run that instead." >&2
exit 1
