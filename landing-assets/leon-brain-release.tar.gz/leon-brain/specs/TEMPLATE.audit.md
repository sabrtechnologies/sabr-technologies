# AUDIT: <slug>

Auditor model family: (must differ from the builder's)
Assumption: this code is broken. Prove it.

FINDINGS (no fixes — findings only)
  1. severity / file:line / what breaks / concrete failing input

DRY? (no new findings this pass): no
