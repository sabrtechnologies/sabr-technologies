# specs/ — how work moves through the crew

Every unit of work gets a slug. Every slug gets up to three files here.
No slug, no work. No verify file, no "fixed".

  specs/<slug>.md          ARCHITECT writes. The build spec.
  specs/<slug>.audit.md    AUDIT writes. Findings only, never fixes.
  specs/<slug>.verify.md   LEON writes. Reproduction evidence. Closes it.

## Pipeline (no skipping, no "it's a small one")

  1. INTAKE   one sentence: what changes, and how we know it worked
  2. SPEC     Architect -> specs/<slug>.md            Leon approves
  3. BUILD    Smith, on a branch, never main
  4. AUDIT    different model family -> <slug>.audit.md
  5. FIX      loop 4-5 until audit is dry
  6. VERIFY   Leon only. Cannot be delegated.
  7. SHIP     merge, deploy, report what happened (not what will happen)

## The verify rule

"It's committed" is not verification.
"It's on disk" is not verification.

Verification means: run the failing case against the OLD code and watch it
fail. Run it against the NEW code and watch it pass. Paste both outputs into
<slug>.verify.md. No reproduction -> write "I think", not "fixed".

## Seats

  LEON      Chief of Staff. Context, judgment, final say, verification.
  ARCHITECT Plans. Writes no code.
  SMITH     Codes. Branch only.
  AUDIT     Different model family than Smith. Tries to break it.
  SCOUT     Research, leads, enrichment. Never code.
  FORGE     Images, video, audio.
