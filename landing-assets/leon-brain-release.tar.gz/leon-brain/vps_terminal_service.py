#!/usr/bin/env python3
"""
VPS Terminal Service — spawns and manages tmux sessions via WebSocket.
Runs on port 9102. One WebSocket connection per terminal window.
Protocol: JSON messages with {type: 'input'|'resize', ...}, binary response for PTY output.
"""

import asyncio
import json
import logging
import os
import pty
import shlex
import signal
import struct
import subprocess
import sys
import uuid
from pathlib import Path

import aiohttp
from aiohttp import web

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('vps-terminal-service')

SESSIONS = {}

class TerminalSession:
    """Wraps a tmux session and pty process."""
    def __init__(self, session_id, window_name):
        self.session_id = session_id
        self.window_name = window_name
        self.proc = None
        self.read_fd = None
        self.write_fd = None
        self.readers = set()
        self.closed = False

    async def spawn(self):
        """Spawn a new bash process via tmux."""
        try:
            # Use tmux so the shell persists across reconnects
            tmux_session = f"leon-{self.session_id[:8]}"

            # Kill any existing session
            subprocess.run(['tmux', 'kill-session', '-t', tmux_session],
                          stderr=subprocess.DEVNULL)

            # Create new tmux session with window
            # Use TERM=xterm-256color for better browser terminal compatibility
            env = os.environ.copy()
            env['TERM'] = 'xterm-256color'
            subprocess.run(['tmux', 'new-session', '-d', '-s', tmux_session,
                           '-n', 'main', '-c', os.path.expanduser('~')],
                          env=env, check=True)

            # Get the pty fd
            # Use 'tmux capture-pane -p -t session:window' to read output
            # and 'tmux send-keys -t session:window "cmd" Enter' to write input
            self.tmux_session = tmux_session
            self.tmux_window = f"{tmux_session}:main"
            logger.info(f"Spawned tmux session: {self.tmux_window}")

        except Exception as e:
            logger.error(f"Failed to spawn terminal: {e}")
            raise

    async def read_output(self):
        """Read available output from the tmux pane."""
        try:
            # Capture current pane output plus scrollback history (500 lines)
            result = subprocess.run(
                ['tmux', 'capture-pane', '-p', '-t', self.tmux_window, '-S', '-500'],
                capture_output=True, text=False
            )
            return result.stdout
        except Exception as e:
            logger.error(f"Failed to read output: {e}")
            return b''

    async def send_input(self, data):
        """Send input to the tmux pane."""
        try:
            # Convert newlines to Enter key presses for tmux
            # Split by \n and send each part with Enter
            if '\n' in data:
                # Send each line separately
                lines = data.split('\n')
                for i, line in enumerate(lines):
                    if line:  # Only send non-empty lines
                        subprocess.run(
                            ['tmux', 'send-keys', '-t', self.tmux_window, line],
                            check=False
                        )
                    # Send Enter after each line except possibly the last
                    if i < len(lines) - 1 or data.endswith('\n'):
                        subprocess.run(
                            ['tmux', 'send-keys', '-t', self.tmux_window, 'Enter'],
                            check=False
                        )
            else:
                # No newline, just send the data as-is
                subprocess.run(
                    ['tmux', 'send-keys', '-t', self.tmux_window, data],
                    check=False
                )
        except Exception as e:
            logger.error(f"Failed to send input: {e}")

    async def resize(self, rows, cols):
        """Resize the tmux pane."""
        try:
            subprocess.run(
                ['tmux', 'resize-pane', '-t', self.tmux_window, '-x', str(cols), '-y', str(rows)],
                check=False
            )
        except Exception as e:
            logger.error(f"Failed to resize: {e}")

    def close(self):
        """Clean up the session."""
        if self.closed:
            return
        self.closed = True
        try:
            if hasattr(self, 'tmux_session'):
                subprocess.run(['tmux', 'kill-session', '-t', self.tmux_session],
                              stderr=subprocess.DEVNULL)
        except:
            pass


async def handle_terminal_ws(request):
    """WebSocket handler for terminal."""
    window_name = request.match_info.get('window_name', 'default')

    # Find or create session
    session_id = None

    # First check in-memory sessions
    for sid, sess in SESSIONS.items():
        if sess.window_name == window_name and not sess.closed:
            session_id = sid
            break

    if not session_id:
        # Check if tmux window already exists by this name
        result = subprocess.run(
            ['tmux', 'list-windows', '-a', '-F', '#{window_name}:#{session_name}'],
            capture_output=True, text=True
        )
        existing_session = None
        if result.stdout:
            for line in result.stdout.strip().split('\n'):
                parts = line.split(':')
                if parts and parts[0] == window_name:
                    existing_session = parts[1] if len(parts) > 1 else None
                    logger.info(f"Found existing tmux session: {existing_session} with window {window_name}")
                    break

        if existing_session:
            # Attach to existing session
            session_id = str(uuid.uuid4())
            session = TerminalSession(session_id, window_name)
            session.tmux_session = existing_session
            session.tmux_window = f"{existing_session}:{window_name}"
            SESSIONS[session_id] = session
            logger.info(f"Attached to existing tmux session: {existing_session}:{window_name}")
        else:
            # Create new session
            session_id = str(uuid.uuid4())
            session = TerminalSession(session_id, window_name)
            try:
                await session.spawn()
                SESSIONS[session_id] = session
                logger.info(f"Created new session for window: {window_name}")
            except Exception as e:
                logger.error(f"Failed to create session: {e}")
                return web.Response(text="Failed to spawn terminal", status=500)
    else:
        session = SESSIONS[session_id]
        logger.info(f"Reusing existing in-memory session for window: {window_name}")

    ws = web.WebSocketResponse()
    try:
        await ws.prepare(request)
    except Exception as e:
        logger.error(f"Failed to prepare WebSocket: {e}")
        return web.Response(text="WebSocket prepare failed", status=500)

    session.readers.add(ws)
    logger.info(f"Client connected to terminal: {window_name} (session {session_id[:8]})")

    # Don't send initial prompt - wait for client commands
    try:
        async for msg in ws:
            logger.debug(f"Received message type {msg.type}")
            if msg.type == aiohttp.WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                    cmd = data.get('type')
                    logger.debug(f"Processing command: {cmd}")

                    if cmd == 'input':
                        input_data = data.get('data', '')
                        logger.debug(f"Sending input: {repr(input_data[:50])}")
                        await session.send_input(input_data)
                        # Give shell time to respond and output to appear in pane
                        await asyncio.sleep(0.15)  # increased delay for reliable capture
                        output = await session.read_output()
                        logger.debug(f"Captured {len(output) if output else 0} bytes from pane")
                        if output:
                            try:
                                await ws.send_bytes(output)
                                logger.debug(f"Sent {len(output)} bytes to client")
                            except Exception as e:
                                logger.error(f"Failed to send output: {e}")
                                try:
                                    await ws.send_str(f"ERROR: Failed to send output: {e}")
                                except:
                                    pass
                        else:
                            logger.warning(f"No output captured from pane")

                    elif cmd == 'resize':
                        rows = data.get('rows', 24)
                        cols = data.get('cols', 80)
                        logger.debug(f"Resizing to {rows}x{cols}")
                        await session.resize(rows, cols)

                except json.JSONDecodeError as e:
                    logger.warning(f"Invalid JSON: {msg.data}")
                    try:
                        await ws.send_str(f"ERROR: Invalid JSON: {e}")
                    except:
                        pass
                except Exception as e:
                    logger.error(f"Error handling message: {e}", exc_info=True)
                    try:
                        await ws.send_str(f"ERROR: {type(e).__name__}: {e}")
                    except:
                        pass

            elif msg.type == aiohttp.WSMsgType.ERROR:
                logger.error(f"WebSocket error: {ws.exception()}")
                break
    except Exception as e:
        logger.error(f"WebSocket handler error: {e}", exc_info=True)
    finally:
        session.readers.discard(ws)
        if not session.readers:
            # Only close if no more readers
            pass
        logger.info(f"Client disconnected from terminal: {window_name}")

    return ws


async def startup(app):
    """Startup handler."""
    logger.info("VPS Terminal Service starting on port 9102")
    logger.info("Available endpoints: ws://localhost:9102/ws/term/{window_name}")


async def cleanup(app):
    """Cleanup handler."""
    for session in list(SESSIONS.values()):
        session.close()
    logger.info("Cleaned up all terminal sessions")


app = web.Application()
app.router.add_get('/ws/term/{window_name}', handle_terminal_ws)
app.on_startup.append(startup)
app.on_cleanup.append(cleanup)

if __name__ == '__main__':
    logger.info("Starting VPS Terminal Service...")
    web.run_app(app, host='0.0.0.0', port=9102, access_log=logger)
