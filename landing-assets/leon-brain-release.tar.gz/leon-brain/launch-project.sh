#!/bin/bash
cd "$HOME/Desktop/Leon-V1.3-SOURCE" || exit 1

echo ""
echo "  ╔═══════════════════════════════════════════════════════════╗"
echo "  ║        SABR — LEON (LEON BRAIN)           ║"
echo "  ║        Neuromorphic AI Brain — Adolescent Stage           ║"
echo "  ╚═══════════════════════════════════════════════════════════╝"
echo ""
echo "  Last session:"
echo "  ─────────────"
tail -10 "$HOME/Desktop/Leon-V1.3-SOURCE/SESSION_LOG.md" 2>/dev/null
echo ""
echo "  Starting Claude Code..."
echo ""

claude-nomouse

echo ""
echo "  ╔═══════════════════════════════════════════════════════════╗"
echo "  ║  SESSION ENDED — Did you say 'log it' before closing?     ║"
echo "  ║  If not, run this launcher again and tell Claude:         ║"
echo "  ║  'Update the session log with what we did last time'      ║"
echo "  ╚═══════════════════════════════════════════════════════════╝"
echo ""
read -p "  Press Enter to close..."
